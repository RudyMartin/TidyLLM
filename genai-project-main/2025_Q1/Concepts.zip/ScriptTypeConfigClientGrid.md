
# 🔢 Script Types and Configuration/Client Usage Grid

This reference grid helps developers and students understand which configuration or client-loading method to use, depending on the type of script they are working with.

---

## 🎓 Numbered Script Types

| #️⃣ | **Script Type**         | **Example Files**                          | **Config / Client Pattern**                  | **Purpose / Notes**                                                                 |
|-----|--------------------------|--------------------------------------------|-----------------------------------------------|--------------------------------------------------------------------------------------|
| 1️⃣  | **UI / Streamlit App**   | `main.py`, `admin_demo.py`, `demo_main.py` | `get_config()` / `get_clients()`              | Interactive apps. Pulls config from session state. Safe and lazy-loaded clients.     |
| 2️⃣  | **CLI Debug Scripts**    | `debug_*.py`, `batch_runner.py`            | `get_config()` / `get_clients()`              | Standalone scripts. Safe to call loaders directly. Avoids circular imports.          |
| 3️⃣  | **Unit Tests / Notebooks** | `test_*.py`, `*.ipynb`                     | `load_config(CONFIG_PATH)` + mock clients     | Test-safe. Direct load from file or mocked clients. Ideal for automation.            |
| 4️⃣  | **Core Helpers / Utilities** | `s3_utils.py`, `faiss_helper.py`         | Receive `config`, `s3_client` as parameters   | Logic-only scripts. Never load config internally. Keeps code clean and testable.     |
| 5️⃣  | **Pipelines / Agents**   | `embedding_pipeline.py`, `agent_main.py`   | Use `get_config()` in top layer only          | Same as CLI, but internals follow #4 utility pattern.                                |

---

## 🧠 How to Use These Tags in Code

Whenever you add `get_config()` or `get_clients()` to a script, add a reference like this:

```python
config = get_config()
# 🔗 [Config Type 1️⃣: Streamlit App]
```

Or for clients:

```python
clients = get_clients()
s3 = clients["s3"]
# 🔗 [S3 Client Type 2️⃣: CLI Script]
```

This keeps your code clear, teachable, and easy to debug later.

---

✅ Stick to the grid, and your config/client logic will Just Work™.
