
# ✅ Client Management for AWS (S3, Bedrock)

This is the **unified pattern** for managing S3 and Bedrock clients across UI, CLI, and tests.

---

## 🧩 Goals

- ✅ Single place to manage AWS clients
- ✅ Lazy loading and caching
- ✅ Works in UI, CLI, and unit tests
- ✅ Easy to mock for testing

---

## 🔧 Use This Pattern

### 🔹 Step 1: Central Manager

```python
# core/client_manager.py
import boto3
from core.config_manager import get_config
from functools import lru_cache

@lru_cache
def get_clients():
    config = get_config()
    return {
        "s3": boto3.client("s3", region_name=config["aws_region"]),
        "bedrock": boto3.client("bedrock-runtime", region_name=config["aws_region"]),
    }
```

### 🔹 Step 2: Use It

```python
from core.client_manager import get_clients

clients = get_clients()
s3 = clients["s3"]
```

### 🔹 Optional Shortcut

```python
def get_client(name):
    return get_clients()[name]
```

---

## ✅ Why It Works

| Environment | Works? | Notes                           |
|-------------|--------|---------------------------------|
| Streamlit   | ✅      | Respects session state          |
| CLI         | ✅      | No need for separate env setup  |
| Unit Tests  | ✅      | Just mock `get_clients()`       |
| Docker      | ✅      | One image, no duplication       |

---

## 🔁 Best Practice

- In deep utilities, **pass the client** (like config):
```python
def list_files(bucket, prefix, s3_client): ...
```

---

**No more flavors. No more duplicated client bundles. One standard.**
