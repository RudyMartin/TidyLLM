
# ✅ Configuration Management (Simplified - 2025 Update)

This document outlines the **standardized, easy-to-use config pattern** used across VectorQA Sage.

---

## 🧩 Goals

- ✅ One consistent config load system across **UI**, **CLI**, and **tests**
- ✅ No circular imports
- ✅ Easy to mock or override in unit tests
- ✅ Avoids duplication or implicit state

---

## 🔧 What To Use

### 🔹 Top-Level Scripts (UI or CLI)

```python
from core.config_manager import get_config
config = get_config()
```

### 🔹 Deep Utilities

```python
def my_func(config, other_args):
    # Use config passed in
```

### 🔹 Tests

```python
from core.config_helper import load_config, CONFIG_PATH
config = load_config(CONFIG_PATH)
```

---

## 🔁 Lifecycle

```
UI / CLI
   └──> get_config()
           └──> initialize_config()
                   └──> st.session_state["CONFIG"]
```

---

## 🧪 Common Issues

| Symptom                          | Fix                                      |
|----------------------------------|-------------------------------------------|
| `KeyError: 'CONFIG'`             | Use `get_config()` not `load_config()` in top-level |
| Config doesn't refresh after change | Call `initialize_config()` again      |
| Core module needs config         | Pass it as a parameter                   |

---

Stick to this, and you'll avoid 90% of config chaos. 🧠
