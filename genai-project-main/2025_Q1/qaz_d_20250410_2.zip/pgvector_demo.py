"""
[File: pgvector_demo.py]
Description: Main Streamlit app for uploading PDFs, indexing into pgVector, and searching using embedded content.
"""

import streamlit as st
from tabs.upload_embed_tab import show_upload_tab
from tabs.index_pgvector_tab import show_index_tab
from tabs.search_pgvector_tab import show_search_tab
from tabs.instructions_tab import show_instructions_tab

st.set_page_config(page_title="PGVector Demo", layout="wide")

st.sidebar.title("🔍 PGVector Demo")
tab = st.sidebar.radio("Navigate", [
    "📄 Upload & Embed PDF",
    "🏢 Index to pgVector",
    "🔎 Search",
    "📘 Instructions"
])

if tab == "📄 Upload & Embed PDF":
    show_upload_tab()
elif tab == "🏢 Index to pgVector":
    show_index_tab()
elif tab == "🔎 Search":
    show_search_tab()
elif tab == "📘 Instructions":
    show_instructions_tab()