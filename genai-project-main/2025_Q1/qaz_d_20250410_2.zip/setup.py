"""
[File: setup.py]
Basic folders and libraries to run on AWS. Each env is dif - see requirements.
"""

import os
import sys
import subprocess
import argparse
import logging

# === Logging Setup ===
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# === Package Management ===
BAD_PACKAGES = [
    "autogluon", "autogluon-core", "autogluon-tabular", "autogluon-features", "autogluon-multimodal", "autogluon-timeseries",
    "dash", "dash-core-components", "dash-html-components", "dash-table",
    "jupyter-dash", "blis",  "datasets",
    "sparkmagic", "sagemaker-studio-analytics-extension", "s3fs",
    "fastai", "gluonts",  "langchain-aws", "evaluate", "thinc",
    "pathos", "multiprocess", "dill", "amazon-sagemaker-sql-magic"
]

def install_requirements(requirements_file="requirements.txt", quiet=True):
    if not os.path.exists(requirements_file):
        print(f"❌ Requirements file not found: {requirements_file}")
        sys.exit(1)
    pip_args = [sys.executable, "-m", "pip", "install", "-r", requirements_file]
    if quiet:
        pip_args.append("-q")
    try:
        logger.info(f"📦 Installing packages from {requirements_file}...")
        subprocess.check_call(pip_args)
        logger.info("✅ Package installation complete.")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ pip install failed: {e}")
        sys.exit(1)

def clean_conflicting_packages(package_list):
    for pkg in sorted(set(package_list)):
        logger.info(f"🔧 Uninstalling: {pkg}")
        try:
            subprocess.run(["pip", "uninstall", "-y", pkg], check=False)
        except Exception as e:
            logger.warning(f"⚠️ Failed to uninstall {pkg}: {e}")

def verify_environment():
    try:
        import pyarrow as pa
        logger.info(f"✅ pyarrow.Decimal32Type available: {hasattr(pa.lib, 'Decimal32Type')}")
    except ImportError:
        logger.error("❌ pyarrow is not installed.")
        sys.exit(1)

def create_log_dirs():
    log_paths = [
        "logs",
        "logs/faiss",
        "logs/indexing",
        "logs/repair"
    ]
    for path in log_paths:
        os.makedirs(path, exist_ok=True)
        logger.info(f"📁 Created: {path}")

def force_restart():
    if "ipykernel" in sys.modules:
        print("⚠️ Cannot auto-restart in Jupyter/SageMaker. Please restart manually.")
        return
    logger.info("🔁 Restarting Python interpreter without --restart flag...")
    new_args = [arg for arg in sys.argv if arg != "--restart"]
    os.execv(sys.executable, [sys.executable] + new_args)

# === CLI Entrypoint ===
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Setup script for QA-Z demo")
    parser.add_argument("--install", action="store_true", help="Install packages from requirements.txt")
    parser.add_argument("--clean", action="store_true", help="Uninstall conflicting packages")
    parser.add_argument("--check", action="store_true", help="Verify critical dependencies")
    parser.add_argument("--init-dirs", action="store_true", help="Create required log directories")
    parser.add_argument("--restart", action="store_true", help="Force interpreter restart after setup")
    args = parser.parse_args()

    if args.clean:
        clean_conflicting_packages(BAD_PACKAGES)

    if args.install:
        install_requirements("requirements.txt", quiet=False)
        if args.restart:
            force_restart()

    if args.check:
        verify_environment()

    if args.init_dirs:
        create_log_dirs()

    if not any(vars(args).values()):
        parser.print_help()
