"""
[File: tabs/completion_stats_tab.py]
Description: Tracks review completion metrics and submission trends across model development plans.
"""

import streamlit as st

def show_completion_stats_tab():
    st.title("📊 Review Completion Stats")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Governance teams need to track how many MDPs are submitted, reviewed, and finalized across departments.
    Without real-time visibility, bottlenecks and delays go unnoticed.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab displays dashboards showing submission rates, review status, and completion trends over time.
    It supports oversight, resourcing, and prioritization decisions.
    """)

    st.info("📊 Metric dashboard widgets will be added in R2 with organizational filters.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Review stats power the inventory dashboards.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                      |
    |--------------------|-----------------------------------------------|
    | Risk Committee     | Monitor overall governance throughput         |
    | Governance Lead    | Track reviews completed by function/team      |
    | PM / Ops           | Identify bottlenecks or overdue submissions   |
    """)