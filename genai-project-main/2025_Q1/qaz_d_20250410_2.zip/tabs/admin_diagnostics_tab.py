"""
[File: tabs/admin_diagnostics_tab.py]
Description: Admin-only tools to view index health, logs, and system diagnostics for FAISS/pgVector.
"""

import streamlit as st

def show_admin_diagnostics_tab():
    st.title("🛠 Admin & Diagnostics")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Model risk workflows depend on healthy vector stores (FAISS, pgVector), correct config settings,
    and access to clean logs. These components often break silently unless tracked proactively.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab provides visibility into system configuration, index health, and log metadata.
    Admins and devs can quickly debug issues, delete broken entries, and verify embedding activity.
    """)

    st.info("🧩 Planned widgets: FAISS/pgVector index table, config validator, JSON log viewer.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Admin-only diagnostics are shown here.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                      |
    |--------------------|-----------------------------------------------|
    | Model Developer    | View personal embedding/debug data            |
    | Validator / Auditor| Review FAISS/pgVector coverage stats          |
    | QA / LLM Engineer  | Debug agent logs, test config variants        |
    | Admin / DevOps     | Diagnose, clean, or reset vector indexes      |
    """)
