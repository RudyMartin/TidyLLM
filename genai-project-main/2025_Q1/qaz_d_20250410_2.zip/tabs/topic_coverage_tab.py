"""
[File: tabs/topic_coverage_tab.py]
Description: Visual heatmap and statistics of MDP section coverage to detect gaps and inconsistencies.
"""

import streamlit as st

def show_topic_coverage_tab():
    st.title("📚 Topic Coverage Heatmap")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Many MDP submissions skip or under-document key governance sections.
    Reviewers and PMs need visibility into which sections are consistently missed or disputed.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab shows a section-by-section heatmap across all submissions, helping identify recurring gaps,
    and target training or interventions to improve completeness.
    """)

    st.info("📊 Section completeness and topic scoring engine to be wired in Phase 2.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Topic trends power review triage and insight.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                     |
    |--------------------|----------------------------------------------|
    | Governance Lead    | Detect systemic topic omissions               |
    | Program Manager    | Monitor which MDP sections are flagged often  |
    | Trainer / SME      | Target weak topic areas in future templates   |
    """)
