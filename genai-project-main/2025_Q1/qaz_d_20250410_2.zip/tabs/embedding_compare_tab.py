"""
[File: tabs/embedding_compare_tab.py]
Description: Compare semantic similarity results across multiple embedding models for model QA.
"""

import streamlit as st

def show_embedding_compare_tab():
    st.title("🧬 Compare Embedding Models")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Different embedding models (Titan, Cohere, Claude, etc.) generate different search results.
    Governance teams need to compare these results side-by-side for fairness, accuracy, and performance.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab allows users to select an embedding model and compare top-k results for the same query.
    It helps model developers and auditors understand how embeddings affect search accuracy.
    """)

    st.warning("🧪 Visual diff and model-switch logic to be wired up in R2.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Embedding comparisons are critical to model transparency.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                     |
    |--------------------|----------------------------------------------|
    | Model Developer    | Validate which embedding performs best        |
    | LLM QA Engineer    | Run fairness/comparison tests                 |
    | Governance Reviewer| Check model behavior consistency by engine    |
    """)