"""
[File: tabs/demo_hub_tab.py]
Description: Launchpad hub for accessing separate demo apps or advanced features via hyperlinks or subprocess ports.
"""

import streamlit as st
from core.launch_utils import launch_local_streamlit_app

def show_demo_hub_tab():
    st.title("🧭 Demo Hub: Explore Modules")

    st.markdown("### 📌 What is the purpose of this hub?")
    st.markdown("""
    This page provides quick access to different demos and app modules, especially those that are
    too large or specialized to be bundled into a single tabbed interface.
    """)

    st.markdown("### 🚀 Launch Streamlit Demos (Local Server)")

    if st.button("📊 Launch Metrics Viewer (port 8508)"):
        launch_local_streamlit_app("apps/metrics_viewer.py", port=8508)

    if st.button("🔍 Launch Audit Log Explorer (port 8509)"):
        launch_local_streamlit_app("apps/audit_log_viewer.py", port=8509)

    st.markdown("### 🔗 External Prototype Demos")
    st.markdown("[📄 Launch Pre-Review App](https://your-pre-review-app.streamlit.app)", unsafe_allow_html=True)
    st.markdown("[🧠 Launch LLM Evaluator](https://your-llm-eval-app.streamlit.app)", unsafe_allow_html=True)

    st.markdown("---")
    st.caption("🛑 This hub links to prototype tools and does not represent final governance system architecture.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                              |
    |--------------------|----------------------------------------|
    | QA / LLM Engineer  | Compare prototype components           |
    | Program Manager    | Review modular demos across features   |
    | Stakeholders       | Understand benefits of each capability |
    """)
