"""
[File: tabs/section_review_tab.py]
Description: Provides section-by-section validation and commenting workflow for Model Development Plans.
"""

import streamlit as st

def show_section_review_tab():
    st.title("📝 Section Review & Feedback")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Model Development Plans (MDPs) often miss key sections required by governance standards.
    Reviewers need a structured way to assess each section, flag issues, and provide feedback.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab allows reviewers to view each MDP section, leave comments, and mark them as complete/incomplete.
    It builds a traceable feedback loop between model developers and governance validators.
    """)

    st.info("🚧 Interactive review UI is coming soon. This placeholder explains the value and structure.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Section-based feedback increases accountability.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                    |
    |--------------------|---------------------------------------------|
    | Reviewer / Auditor | Validate section completeness               |
    | Model Developer    | Respond to comments or revise submission    |
    | Program Manager    | Monitor comment volume and resolution rate |
    """)