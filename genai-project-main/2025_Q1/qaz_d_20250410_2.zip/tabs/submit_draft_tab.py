"""
[File: tabs/submit_draft_tab.py]
Description: Tab to submit draft Model Development Plans (MDPs) and upload content for automated validation.
"""

import streamlit as st

def show_submit_draft_tab():
    st.title("📄 Submit Draft MDP")

    st.markdown("### 📌 What is the problem?")
    st.markdown("""
    Model Developers need a secure and auditable way to upload their draft Model Development Plans.
    These drafts should integrate with automated tools for review and traceability.
    """)

    st.markdown("### 💡 How does this solve it?")
    st.markdown("""
    This tab lets users upload PDFs or JSON files of their MDPs directly to S3, storing them with version history.
    These files can then be processed by the review and feedback system.
    """)

    st.info("🚧 Upload + processing workflow in progress. This will be interactive in R1.")

    st.markdown("---")
    st.caption("This page is part of the VectorQA Risk Platform. Draft submission is the first step in review.")

    st.markdown("### 🧑‍💼 Who uses this tab?")
    st.markdown("""
    | Role               | Use Case                                      |
    |--------------------|-----------------------------------------------|
    | Model Developer    | Upload initial draft MDP for validation        |
    | Program Manager    | Confirm receipt and track versioning           |
    | Governance Reviewer| Monitor queue of submitted documents          |
    """)