"""
[File: core/pgvector_store.py]
Description: PGVector index management fully aligned with BaseVectorStore
"""
import json
import psycopg2
import numpy as np
from datetime import datetime
from core.vector_base import BaseVectorStore
from core.embedding_utils import data_collect
from core.pgvector_structured_indexer import structured_pgvector_index

class PGVectorStore(BaseVectorStore):
    def __init__(self, config, s3_client, logger):
        super().__init__(config=config, s3_client=s3_client, logger=logger)
        try:
            self.conn = psycopg2.connect(config["pgvector_conn_string"])
            self.cur = self.conn.cursor()
        except psycopg2.OperationalError as e:
            self.conn = None
            self.cur = None
            self.logger.warning(f"⚠️ PGVector DB connection failed: {e}")

    def list_indexes(self):
        if not self.conn:
            return []
        self.cur.execute("SELECT model_key, COUNT(*) FROM model_embeddings GROUP BY model_key")
        return [{"ModelKey": r[0], "Count": r[1]} for r in self.cur.fetchall()]

    def index_create(self, embeddings, model_key, metadata=None):
        if not self.conn:
            return []
        for i, vec in enumerate(embeddings):
            meta = metadata[i] if metadata else {}
            self.cur.execute(
                "INSERT INTO model_embeddings (model_key, embedding, metadata) VALUES (%s, %s, %s)",
                (model_key, vec.tolist(), json.dumps(meta))
            )
        self.conn.commit()

    def collect_embeddings_and_metadata(self, model_key, force=False):
        return data_collect(self.config, self.s3_client, model_key, self.logger, force=force)

    def embeddings_batch(self, model_keys, force=False):
        for key in model_keys:
            vecs, meta = self.collect_embeddings_and_metadata(key, force=force)
            if vecs:
                self.index_create(np.vstack(vecs).astype("float32"), key, meta)
        return [{"Model": k, "Status": "OK"} for k in model_keys]

    def validate(self, model_key):
        if not self.conn:
            return False
        self.cur.execute("SELECT COUNT(*) FROM model_embeddings WHERE model_key = %s", (model_key,))
        return self.cur.fetchone()[0] > 0

    def get_index_status(self):
        if not self.conn:
            return []
        self.cur.execute("SELECT model_key, COUNT(*) FROM model_embeddings GROUP BY model_key")
        return [
            {"Model": r[0], "Count": r[1], "Status": "🟢" if r[1] > 0 else "🔴"}
            for r in self.cur.fetchall()
        ]

    def query(self, query_embedding, top_k=3):
        if not self.conn:
            return []
        self.cur.execute(
            "SELECT metadata, (embedding <#> %s) AS distance FROM model_embeddings ORDER BY distance ASC LIMIT %s",
            (query_embedding, top_k)
        )
        return [{"score": r[1], "metadata": r[0]} for r in self.cur.fetchall()]

    def query_with_metadata(self, query_embedding, top_k=3, model_key=None):
        if not self.conn:
            return []
        self.cur.execute(
            """
            SELECT d.id, d.document_name, d.page_number, d.tags, (v.embedding <#> %s) AS score
            FROM pg_vec v
            JOIN pg_details d ON v.id = d.id
            WHERE d.model_key = %s
            ORDER BY score ASC
            LIMIT %s;
            """,
            (query_embedding, model_key, top_k)
        )
        return [
            {
                "id": str(row[0]),
                "document": row[1],
                "page": row[2],
                "tags": row[3],
                "score": row[4]
            }
            for row in self.cur.fetchall()
        ]

    def reindex(self):
        keys = list(self.config.get("model_options", {}).keys())
        use_structured = self.config.get("pgvector_mode", "default") == "structured"
        for key in keys:
            if use_structured:
                structured_pgvector_index(key)
            else:
                self.embeddings_batch([key], force=True)

    def delete_index(self):
        if self.conn:
            self.cur.execute("DELETE FROM model_embeddings")
            self.conn.commit()

    def load_index(self):
        self.logger.info("ℹ️ No-op for pgvector; live DB always used.")
        return True


__all__ = [
    "PGVectorStore",
]
