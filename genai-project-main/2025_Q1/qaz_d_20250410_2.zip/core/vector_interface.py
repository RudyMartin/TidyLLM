"""
[File: core/vector_interface.py]
Description: Unified abstraction layer for vector store operations (defaults to pgVector)
"""
from core.init_context import get_tab_context

# ---- Context Loader ----
# Used internally by all vector_* calls to initialize shared dependencies.
# Wraps get_tab_context() to provide config, vectorizer, and store manager
# without duplicating logic across every function.
def get_vector_context(store_type="pgvector", model_key=None):
    """
    Load core context components: clients, config, vectorizer, manager.
    Defaults to pgVector store unless overridden.
    """
    return get_tab_context(store_type=store_type, model_key=model_key)

# ---- Generic Vector Operation Aliases (CRUD-V) ----

# Create index from embedded data
def vector_index(model_key="titan_v2", store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type, model_key=model_key)
    return manager.index_documents()

# Query index with a single embedding vector
def vector_query(query_embedding, top_k=3, store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type)
    return manager.query(query_embedding, top_k=top_k)

# Validate if index exists for the given model_key
def vector_validate(model_key=None, store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type, model_key=model_key)
    return manager.validate(model_key)

# Delete the index from storage (FAISS or PGVector)
def vector_delete(store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type)
    return manager.delete_index()

# Rebuild index from stored JSONs or database rows
def vector_reindex(store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type)
    return manager.reindex()

# List available embedded JSON files in S3
def vector_list(store_type="pgvector"):
    clients, config, _, _ = get_tab_context(store_type=store_type)
    from core.s3_utils import list_json_files_s3
    return list_json_files_s3(
        bucket=config["bucket_name"],
        prefix=config["json_folder"]
    )

# Load index into memory if needed (FAISS only)
def vector_load(store_type="faiss"):
    _, _, _, manager = get_tab_context(store_type=store_type)
    return manager.load_index()

# Query with metadata join for rich context results
def vector_query_with_metadata(query_embedding, model_key, top_k=5, store_type="pgvector"):
    _, _, _, manager = get_tab_context(store_type=store_type, model_key=model_key)
    return manager.query_with_metadata(query_embedding, top_k=top_k, model_key=model_key)

# --- Exports ---
__all__ = sorted([
    "get_vector_context",
    "vector_delete",
    "vector_index",
    "vector_list",
    "vector_load",
    "vector_query",
    "vector_query_with_metadata",
    "vector_reindex",
    "vector_validate",
])

