"""
[File: core/faiss_log_writer.py]
Description:
  Writes structured audit logs to both FAISS and S3 (as JSON).

Responsibilities:
  - Create structured audit entries (text, metadata, timestamp, signature)
  - Store logs in S3 for traceability
  - Embed logs into FAISS for semantic retrieval

Version: DSPy 2.5.26
"""

import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

from core.config_helper import get_config
from core.client_helper import get_clients
from core.s3_utils import save_json_to_s3
from core.faiss_utils import generate_signature

logger = logging.getLogger("faiss_log_writer")
logger.setLevel(logging.DEBUG)

# --- Build entry for audit log ---
# Creates a structured dictionary containing the log text, metadata,
# a UTC timestamp, and a unique signature hash. This serves as the canonical
# entry format for all FAISS and S3 audit records.
def build_audit_log_entry(text: str, metadata: Dict[str, any]) -> Dict[str, any]:
    return {
        "text": text,
        "metadata": metadata,
        "timestamp": datetime.utcnow().isoformat(),
        "signature": generate_signature(text)
    }

# --- Write one log entry ---
# Takes a single audit message, embeds it using the configured vectorizer,
# then writes it to both FAISS (via VectorManager) and S3 for persistence and review.
def write_audit_log_entry(text: str, metadata: Dict[str, any], model_key: str, s3_prefix: Optional[str] = None):
    config = get_config()
    s3_client, _ = get_clients()
    from core.vector_manager import VectorManager  # lazy load to avoid circular import

    vector_manager = VectorManager(config, s3_client, logger)
    entry = build_audit_log_entry(text, metadata)

    # Embed and store to FAISS
    embedding = vector_manager.vectorizer.embed_text(text, model_key=model_key)
    vector_manager.store.add_vector(embedding, entry, model_key=model_key)
    logger.debug(f"Entry embedded and added to FAISS under model_key={model_key}")

    # Store to S3
    bucket = config["bucket_name"]
    s3_folder = s3_prefix or config.get("log_directory", "dev/logs")
    file_key = f"{s3_folder}/log_{entry['signature']}.json"
    save_json_to_s3(s3_client, bucket, file_key, [entry])
    logger.info(f"Audit log saved to S3: s3://{bucket}/{file_key}")

# --- Batch write logs ---
# Accepts a list of {text, metadata} pairs and writes each to both FAISS and S3.
# Ensures each message is properly embedded, signed, and stored individually
# with unique S3 keys for later lookup or traceability.
def batch_write_logs_to_s3(log_entries: List[Dict[str, any]], model_key: str, s3_prefix: Optional[str] = None):
    config = get_config()
    s3_client, _ = get_clients()
    from core.vector_manager import VectorManager

    vector_manager = VectorManager(config, s3_client, logger)
    bucket = config["bucket_name"]
    s3_folder = s3_prefix or config.get("log_directory", "dev/logs")

    for entry in log_entries:
        text = entry.get("text")
        metadata = entry.get("metadata", {})
        if not text:
            continue
        log_entry = build_audit_log_entry(text, metadata)

        # Embed + Add to FAISS
        embedding = vector_manager.vectorizer.embed_text(text, model_key=model_key)
        vector_manager.store.add_vector(embedding, log_entry, model_key=model_key)

        # Save to S3
        file_key = f"{s3_folder}/log_{log_entry['signature']}.json"
        save_json_to_s3(s3_client, bucket, file_key, [log_entry])
        logger.debug(f"Batch log saved: s3://{bucket}/{file_key}")

    logger.info(f"Batch of {len(log_entries)} logs written to FAISS and S3.")

__all__ = [
    "build_audit_log_entry",
    "write_audit_log_entry",
    "batch_write_logs_to_s3"
]
