"""
[File: core/init_context.py]
Descripton: Critical file for configuration
"""
from typing import NamedTuple, Optional
import logging

from core.config_helper import get_config
from core.client_manager import get_clients, ClientBundle

logger = logging.getLogger(__name__)

class TabContext(NamedTuple):
    clients: ClientBundle
    config: dict
    vectorizer: object  # ← Optional, set to None by default
    manager: object     # ← Optional, set to None by default

    def __getattr__(self, item):
        if item in self.config:
            return self.config[item]
        if hasattr(self.clients, item):
            return getattr(self.clients, item)
        raise AttributeError(f"'{item}' not found in TabContext")

def get_tab_context(store_type: str = "faiss", model_key: Optional[str] = None) -> TabContext:
    """
    Creates a context with only config + clients (no vectorizer or manager).
    """
    try:
        config = get_config()
        clients = get_clients()
        return TabContext(clients=clients, config=config, vectorizer=None, manager=None)
    except Exception as e:
        error_msg = f"Failed to initialize application context: {str(e)}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)


__all__ = [
    "TabContext",
    "get_tab_context",
]
