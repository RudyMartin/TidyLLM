"""
[File: core/vector_manager.py]
Description: Manager class that delegates all vector operations to the appropriate backend store.
"""
from core.faiss_store import FaissStore
from core.pgvector_store import PGVectorStore

class VectorManager:
    def __init__(self, config, s3_client, logger):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger
        self.store_type = config.get("store_type", "pgvector")

        if self.store_type == "faiss":
            self.store = FaissStore(config, s3_client, logger)
        elif self.store_type == "pgvector":
            self.store = PGVectorStore(config, s3_client, logger)
        else:
            raise ValueError(f"Unsupported vector store type: {self.store_type}")

    # Create a new index
    def index_documents(self):
        return self.store.reindex()

    # Query for nearest neighbors
    def query(self, query_embedding, top_k=3):
        return self.store.query(query_embedding, top_k=top_k)

    # Check if index exists and is valid
    def validate(self, model_key):
        return self.store.validate(model_key)

    # Delete index
    def delete_index(self):
        return self.store.delete_index()

    # Rebuild full index
    def reindex(self):
        return self.store.reindex()

    # Load index into memory (mainly for FAISS)
    def load_index(self):
        return self.store.load_index()

    def list_indexes(self):
        """Return available index metadata from the backend."""
        if hasattr(self.store, "list_indexes"):
            return self.store.list_indexes()
        self.logger.warning("⚠️ list_indexes() not implemented.")
        return []

    def index_create(self, embeddings, model_key, metadata=None):
        """Directly create a new index from embeddings + metadata."""
        if hasattr(self.store, "index_create"):
            return self.store.index_create(embeddings, model_key, metadata)
        self.logger.warning("⚠️ index_create() not implemented.")
        return None

    
    def collect_embeddings_and_metadata(self, model_key, force=False):
        """Collect embedded vectors + metadata from source (usually S3 JSON)."""
        if hasattr(self.store, "collect_embeddings_and_metadata"):
            return self.store.collect_embeddings_and_metadata(model_key, force=force)
        self.logger.warning("⚠️ collect_embeddings_and_metadata() not implemented.")
        return [], []

    def embeddings_batch(self, model_keys, force=False):
        """Perform bulk indexing across multiple model keys."""
        if hasattr(self.store, "embeddings_batch"):
            return self.store.embeddings_batch(model_keys, force=force)
        self.logger.warning("⚠️ embeddings_batch() not implemented.")
        return []

    def get_index_status(self):
        """Return health report of indexed model keys."""
        if hasattr(self.store, "get_index_status"):
            return self.store.get_index_status()
        self.logger.warning("⚠️ get_index_status() not implemented.")
        return []
        
    # Query with metadata join for rich context results    
    def query_with_metadata(self, query_embedding, top_k=3, model_key=None):
        """
        Optional: run ANN search and return metadata-rich results.
        Only supported in stores that implement it (e.g., PGVector).
        """
        if hasattr(self.store, "query_with_metadata"):
            return self.store.query_with_metadata(query_embedding, top_k=top_k, model_key=model_key)
        else:
            raise NotImplementedError(f"query_with_metadata not supported for {self.store_type}")

__all__ = [
    "VectorManager",
    "validate",
    "reindex",
    "query_with_metadata",
    "query",
    "list_indexes",
    "load_index",
    "index_documents",
    "index_create",
    "get_index_status",
    "embeddings_batch",
    "delete_index",
    "collect_embeddings_and_metadata"
]            
