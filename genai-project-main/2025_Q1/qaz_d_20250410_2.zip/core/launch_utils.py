"""
[File: core/launch_utils.py]
Description: Utilities for launching additional Streamlit apps in SageMaker via proxy port hacks.
"""

import subprocess
import webbrowser
import streamlit as st

# --- HARDCODED FOR SAGEMAKER PROXY BASE URL ---
BASE_PROXY_URL = "https://oilajldpsxb7rmg.studio.us-east-1.sagemaker.aws/jupyterlab/default/proxy"


def get_sagemaker_proxy_url(port: int) -> str:
    """Return full URL to access given port in SageMaker Studio via proxy."""
    return f"{BASE_PROXY_URL}/{port}/"


def launch_local_streamlit_app(script_path: str, port: int):
    """
    Launch a Streamlit app on specified port and open it in a new browser tab using SageMaker proxy.
    """
    try:
        subprocess.Popen([
            "streamlit", "run", script_path,
            "--server.port", str(port),
            "--server.headless", "true"
        ])
        url = get_sagemaker_proxy_url(port)
        webbrowser.open_new_tab(url)
        st.markdown(f"🔗 [App launched on port {port}]({url})", unsafe_allow_html=True)
    except Exception as e:
        st.error(f"🚫 Failed to launch app on port {port}: {e}")


__all__ = [
    "get_sagemaker_proxy_url",
    "launch_local_streamlit_app",
]
