"""
[File: core/reembed_manager.py]
Description: Handles watchlist-based re-embedding operations on flagged files.
"""

import os
import json
from pathlib import Path
from datetime import datetime

from core.model_key_utils import get_model_details
from core.embedding_helper import get_cached_vectorizer
from core.config_helper import get_config

# Constants
REEMBED_LIST_PATH = "reembed_list.json"
TEST_JSON_DIR = "test/json"
config = get_config()

def reembed_flag(logger):
    """Re-embed all files listed in the local watchlist and save updates to disk."""
    if not os.path.exists(REEMBED_LIST_PATH):
        logger.info("No flagged files to re-embed.")
        return

    try:
        with open(REEMBED_LIST_PATH, "r") as f:
            flagged = json.load(f)

        if not flagged:
            logger.info("Re-embed list is empty.")
            return

        logger.info(f"Re-embedding {len(flagged)} flagged files...")

        for item in flagged:
            file_path = Path(TEST_JSON_DIR) / item["file"]
            if not file_path.exists():
                logger.warning(f"File not found: {item['file']}")
                continue

            with open(file_path, "r") as f:
                data = json.load(f)

            model_key = item["model"]
            model_details = get_model_details(model_key, config["model_options"])
            vectorizer = get_cached_vectorizer()

            text = data.get("text", "") or " ".join([c.get("text", "") for c in data.get("chunks", [])])

            data.setdefault("metadata", {})
            data.setdefault("chunks", [])
            data.setdefault("embeddings", {})

            new_vector = vectorizer.generate_embedding(text)
            data["embeddings"][model_key] = {
                "id": model_details["id"],
                "dimensions": model_details["dimensions"],
                "embed_date": datetime.utcnow().isoformat() + "Z",
                "tags": new_vector
            }

            with open(file_path, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f"✅ Re-embedded: {item['file']}")

        os.remove(REEMBED_LIST_PATH)
        logger.info("🧹 Re-embed list cleared.")

    except Exception as e:
        logger.error(f"❌ Error during re-embedding: {e}")

def reembed_append(file, model_key, reason, logger):
    """Add a new file and reason to the local re-embed watchlist."""
    entry = {"file": file, "model": model_key, "reason": reason}
    try:
        if os.path.exists(REEMBED_LIST_PATH):
            with open(REEMBED_LIST_PATH, "r") as f:
                existing = json.load(f)
        else:
            existing = []

        existing.append(entry)
        with open(REEMBED_LIST_PATH, "w") as f:
            json.dump(existing, f, indent=2)

        logger.info(f"📌 Flagged {file} for re-embedding: {reason}")

    except Exception as e:
        logger.warning(f"⚠️ Could not update re-embed list for {file}: {e}")

# --- Exports ---
__all__ = [
    "reembed_flag",
    "reembed_append"
]
