"""
[File: core/pgvector_embedding_vectorizer.py]
Description: Read-only embedding retriever from pgVector (for inference, testing, or comparison)

USAGE:
  from core.pgvector_embedding_vectorizer import vectorize_from_pg
  embedding = vectorize_from_pg("sample text")

NOTE: This module does not generate embeddings — it simulates or retrieves them
      from an indexed pgVector table for test/demo/inference-only use.
"""
import psycopg2
import hashlib
from core.config_helper import get_config


def generate_signature(text: str) -> str:
    """Create a unique text hash to use as lookup key."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def vectorize_from_pg(text: str, model_key="titan_v2"):
    """
    Look up precomputed embedding from pg_details using text signature.
    """
    config = get_config()
    conn = psycopg2.connect(config["pgvector"]["genai"]["url"])
    cur = conn.cursor()

    signature = generate_signature(text)
    cur.execute(
        """
        SELECT v.embedding
        FROM pg_details d
        JOIN pg_vec v ON d.id = v.id
        WHERE d.model_key = %s AND d.signature = %s
        LIMIT 1;
        """,
        (model_key, signature)
    )
    row = cur.fetchone()
    if not row:
        raise ValueError(f"No embedding found for signature: {signature}")
    return row[0]


__all__ = [
    "generate_signature",
    "vectorize_from_pg",
]
