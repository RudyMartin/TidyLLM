"""
[File: core/faiss_utils.py]
Description: Shared FAISS utility functions used by store, writer, and reader.
"""
import faiss
import hashlib
import logging
from core.model_key_utils import get_model_details

# --- Save FAISS index to S3 ---
def save_faiss_index_to_s3(s3_client, config, model_key, index):
    try:
        info = get_model_details(model_key)
        fname = f"faiss_index_{info['id'].replace(':', '_')}_{info['dimensions']}.faiss"
        path = f"{config['prefix']}/{config['index_folder']}/{model_key}/{info['dimensions']}/{fname}"
        s3_client.put_object(
            Bucket=config["bucket_name"],
            Key=path,
            Body=faiss.serialize_index(index),
            ContentType="application/octet-stream"
        )
    except Exception as e:
        logging.error(f"❌ Failed to save FAISS index to S3: {e}")
        raise

# --- Load FAISS index from S3 ---
def load_faiss_index_from_s3(s3_client, config, model_key):
    try:
        info = get_model_details(model_key)
        fname = f"faiss_index_{info['id'].replace(':', '_')}_{info['dimensions']}.faiss"
        path = f"{config['prefix']}/{config['index_folder']}/{model_key}/{info['dimensions']}/{fname}"
        obj = s3_client.get_object(Bucket=config["bucket_name"], Key=path)
        return faiss.deserialize_index(obj["Body"].read())
    except Exception as e:
        logging.warning(f"⚠️ Could not load FAISS index from S3: {e}")
        return None

# --- Signature generator ---
def generate_signature(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

__all__ = [
    "save_faiss_index_to_s3",
    "load_faiss_index_from_s3",
    "generate_signature"
]
