"""
[File: core/client_manager.py]
Description: Delegates AWS client access to core/client_utils with safe fallback.
Includes optional ClientBundle for dot-access compatibility.

Now you can safely do multiple calls

clients = get_client_bundle()

clients.s3                     # dot-style ✅
clients["s3"]                  # dict-style ✅
clients.get("s3", None)        # fallback-style ✅
"""

from core.client_utils import get_clients, get_clients_flexible
from core.config_helper import get_config

# Optional typed wrapper for dot and dict-style access
class ClientBundle:
    def __init__(self, client_dict):
        self._dict = client_dict
        self.config = client_dict.get("config") or get_config()
        self.s3 = client_dict.get("s3")
        self.bedrock = client_dict.get("bedrock")

    def get(self, name, default=None):
        return self._dict.get(name, default)

    def __getitem__(self, key):
        return self._dict[key]

def get_client(name: str, config: dict = None):
    """
    Return a specific AWS client by name.
    Uses flexible config logic (e.g., from Streamlit session).
    Safe for non-cached usage.
    """
    return get_clients_flexible(config).get(name)

def default_s3_client():
    """Return the default cached S3 client."""
    return get_clients().get("s3")

def default_bedrock_client():
    """Return the default cached Bedrock client."""
    return get_clients().get("bedrock")

def get_client_bundle(config=None) -> ClientBundle:
    """
    Return a typed client wrapper with dot-access support (s3, bedrock, config).
    Can be used in Streamlit and CLI safely.
    """
    return ClientBundle(get_clients_flexible(config))


__all__ = [
    "ClientBundle",
    "default_bedrock_client",
    "default_s3_client",
    "get_client",
    "get_client_bundle",
]
