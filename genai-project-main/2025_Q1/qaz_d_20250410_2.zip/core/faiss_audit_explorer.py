"""
[File: core/faiss_audit_explorer.py]
Description:
  Retrieves and filters audit logs from S3. Supports semantic search with FAISS via VectorManager.

Responsibilities:
  - Load all audit logs from S3 (JSON)
  - Filter logs by signature, metadata, or timestamp
  - Perform semantic search over logs using VectorManager
  - Export selected logs to CSV
  - Format logs for readable output

Dependencies:
  - core/vector_manager.py
  - core/config_helper.py
  - core/client_helper.py
  - core/s3_utils.py
  - core/faiss_utils.py

Version: DSPy 2.5.26
"""

import logging
import csv
from datetime import datetime
from typing import List, Dict, Any

from core.config_helper import get_config
from core.client_helper import get_clients
from core.s3_utils import list_objects_s3, load_json_from_s3
from core.vector_manager import VectorManager

logger = logging.getLogger("faiss_audit_explorer")
logger.setLevel(logging.DEBUG)

# --- Load Logs from S3 ---
def load_all_logs_from_s3(prefix: str) -> List[Dict[str, Any]]:
    """Loads all JSON audit log files from the specified S3 prefix."""
    config = get_config()
    s3_client, _ = get_clients()
    bucket = config["bucket_name"]

    logs = []
    files = list_objects_s3(bucket, prefix, extension="json")
    for file_key in files:
        try:
            data = load_json_from_s3(bucket, file_key)
            logs.extend(data)
        except Exception as e:
            logger.warning(f"Failed to load {file_key}: {e}")
    return logs

# --- Filtering Utilities ---
def filter_logs_by_signature(logs: List[Dict[str, Any]], signature: str) -> List[Dict[str, Any]]:
    return [log for log in logs if log.get("signature") == signature]

def filter_logs_by_metadata_key(logs: List[Dict[str, Any]], key: str, value: Any) -> List[Dict[str, Any]]:
    return [log for log in logs if log.get("metadata", {}).get(key) == value]

def filter_logs_by_date_range(logs: List[Dict[str, Any]], start: datetime, end: datetime) -> List[Dict[str, Any]]:
    def within_range(log):
        ts_str = log.get("timestamp")
        if ts_str:
            try:
                ts = datetime.fromisoformat(ts_str)
                return start <= ts <= end
            except Exception as e:
                logger.debug(f"Invalid timestamp in log: {ts_str}")
        return False
    return [log for log in logs if within_range(log)]

# --- Semantic Search via VectorManager ---
def semantic_search_logs_s3(query: str, model_key: str, s3_prefix: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Embeds query using VectorManager and returns top matches from logs in S3.
    """
    logs = load_all_logs_from_s3(s3_prefix)
    texts = [log["text"] for log in logs if "text" in log]

    if not texts:
        logger.warning("No valid text entries found in logs.")
        return []

    vm = VectorManager()
    query_results = vm.semantic_compare(query, texts, model_key=model_key, top_k=top_k)

    matches = []
    for idx, score in query_results:
        matched_log = logs[idx]
        matched_log["score"] = score
        matches.append(matched_log)

    return matches

# --- Export Logs to CSV ---
def export_logs_to_csv(logs: List[Dict[str, Any]], file_path: str):
    """Exports structured logs to local CSV file."""
    keys = ["timestamp", "signature", "text", "metadata"]
    with open(file_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for log in logs:
            row = {key: log.get(key, "") for key in keys}
            row["metadata"] = str(row["metadata"])
            writer.writerow(row)
    logger.info(f"Logs exported to {file_path}")

# --- Format Log Output ---
def format_log_result(entry: Dict[str, Any]) -> str:
    ts = entry.get("timestamp", "unknown")
    meta = entry.get("metadata", {})
    score = entry.get("score", None)
    score_part = f" [score: {score:.3f}]" if score else ""
    return f"[{ts}]{score_part} → {entry['text'][:80]}... (meta: {meta})"

__all__ = [
    "load_all_logs_from_s3",
    "filter_logs_by_signature",
    "filter_logs_by_metadata_key",
    "filter_logs_by_date_range",
    "semantic_search_logs_s3",
    "export_logs_to_csv",
    "format_log_result"
]
