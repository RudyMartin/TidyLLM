"""
[File: core/faiss_log_reader.py]
Description:
  Reads and semantically queries FAISS audit logs.

Responsibilities:
  - Load FAISS audit log index from S3
  - Vectorize user query and compare to indexed logs
  - Return ranked results with original metadata

Version: DSPy 2.5.26
"""

import faiss
import numpy as np
from typing import List

from core.config_helper import get_config
from core.client_helper import get_clients
from core.faiss_utils import load_faiss_index_from_s3
from core.embedding_helper import get_cached_vectorizer

# --- Semantic log search ---
def query_faiss_audit_log(query_text: str, model_key: str, top_k: int = 5) -> List[dict]:
    """
    Vectorizes a user query and retrieves top-K matching audit log entries
    from the FAISS index stored in S3.
    """
    config = get_config()
    s3_client, _ = get_clients()
    index = load_faiss_index_from_s3(s3_client, config, model_key)

    if not index:
        return []

    vectorizer = get_cached_vectorizer(config)
    query_vector = np.array([vectorizer.embed_text(query_text, model_key=model_key)]).astype("float32")

    scores, indices = index.search(query_vector, top_k)
    return [
        {"rank": i + 1, "score": float(scores[0][i]), "match_index": int(indices[0][i])}
        for i in range(min(top_k, len(scores[0])))
    ]

__all__ = ["query_faiss_audit_log"]
