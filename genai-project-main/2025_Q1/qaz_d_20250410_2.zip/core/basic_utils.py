"""
[File: core/basic_utils.py]
Description: General utilities file.
"""

import os
import datetime

def generate_versioned_filename(base_name, extension=".csv", directory=".", timestamp_format="%Y%m%d"):
    """
    Appends current date to base_name, and auto-increments if the file exists.
    
    Args:
        base_name (str): Base file name without extension.
        extension (str): File extension (e.g., ".csv", ".md").
        directory (str): Directory to check for existing files.
        timestamp_format (str): Format for the date stamp. Default is YYYYMMDD.

    Returns:
        str: A unique, versioned filename like "report_20240408.csv" or "report_20240408_2.csv"
    """
    date_str = datetime.datetime.now().strftime(timestamp_format)
    candidate = f"{base_name}_{date_str}{extension}"
    counter = 1

    while os.path.exists(os.path.join(directory, candidate)):
        counter += 1
        candidate = f"{base_name}_{date_str}_{counter}{extension}"

    return candidate

##  there  are 1  utility functions in  this file

__all__ = [
    "generate_versioned_filename"
]       
