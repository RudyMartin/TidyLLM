"""
[File: tuning_utils.py]
Description: Provides tuning functions for sampling thresholds, nlist, and nprobe in FAISS indexing
"""
import math

def suggest_training_sample_count(total_embeddings: int, 
                                  max_samples: int = None, 
                                  min_number: int = 50, 
                                  max_percent: float = 0.80) -> int:
    """
    Suggests a training sample threshold based on the total number of embeddings,
    a specified minimum number, and a maximum percentage of the total embeddings.
    
    The function calculates the required samples as the maximum between the specified minimum number
    and the product of total_embeddings and max_percent. If max_samples is provided and is greater than 1,
    the result is capped at max_samples. Otherwise, no cap is applied.
    
    Args:
        total_embeddings (int): Total number of embedding vectors.
        max_samples (int, optional): Maximum number of samples allowed. If None or ≤ 1, no cap is applied.
        min_number (int): Minimum number of samples to use.
        max_percent (float): Maximum fraction of total embeddings to use. Defaults to 0.80.
    
    Returns:
        int: The suggested training sample count.
    """
    required = max(min_number, int(total_embeddings * max_percent))
    if max_samples is not None and max_samples > 1:
        return min(required, max_samples)
    return required


def calculate_nlist(vector_count: int, raw_nlist: int) -> int:
    """
    Calculate the number of clusters (nlist) for the FAISS index using a log-adjusted ratio.
    
    The function scales nlist using the ratio:
      nlist = raw_nlist * (log(vector_count + 1) / log(raw_nlist + 1))
    
    Since you cannot have more clusters than training vectors, the result is capped at vector_count.
    
    Args:
        vector_count (int): Total number of embedding vectors.
        raw_nlist (int): Configured nlist value.
    
    Returns:
        int: The computed nlist.
    """
    if vector_count <= 0:
        return 1
    ratio = np.log(vector_count + 1) / np.log(raw_nlist + 1)
    computed_nlist = int(round(raw_nlist * ratio))
    return min(computed_nlist, vector_count)


def calculate_nprobe(nlist: int) -> int:
    """
    Calculate the number of probes (nprobe) for the FAISS index as a fraction of nlist using a sigmoid function.
    
    For small nlist values, the ratio approaches 20% of nlist.
    For large nlist values, the ratio approaches 10% of nlist.
    At nlist = 512, the ratio is approximately 15%.
    
    Args:
        nlist (int): The number of clusters (nlist) used in the FAISS index.
    
    Returns:
        int: The computed nprobe value.
    """
    # Parameters for the sigmoid function.
    k = 0.01  # Steepness of the sigmoid.
    x0 = 512  # Midpoint: at nlist=512, the ratio is ~15%.
    
    # Sigmoid-based ratio: when nlist is much smaller than x0, the ratio approaches 0.2 (20%).
    # When nlist is much larger than x0, the ratio approaches 0.1 (10%).
    ratio = 0.1 + (0.1) / (1 + math.exp(k * (nlist - x0)))
    return max(1, int(round(ratio * nlist)))


def calculate_nprobe_with_cost(nlist: int, k: float, x0: int, cost_factor: float) -> int:
    """
    Calculate the number of probes (nprobe) for a FAISS index as a fraction of nlist using a sigmoid function,
    with an additional cost adjustment based on nlist.
    
    For small nlist values, the ratio approaches 20% of nlist.
    For large nlist values, the ratio approaches 10% of nlist.
    At nlist = x0, the ratio is approximately 15% before cost adjustment.
    
    A cost function is applied:
        cost = cost_factor * log(nlist + 1)
    and the effective ratio becomes:
        adjusted_ratio = base_ratio / (1 + cost)
    
    Args:
        nlist (int): The number of clusters (nlist) used in the FAISS index.
        k (float): The steepness parameter for the sigmoid function.
        x0 (int): The midpoint for the sigmoid function.
        cost_factor (float): A scaling factor for the cost function.
    
    Returns:
        int: The computed nprobe value.
    """
    if nlist <= 0:
        return 1


def get_tuning_metrics(vector_count: int, raw_nlist: int, max_samples: int) -> dict:
    """
    Computes and returns a dictionary of tuning metrics based on the given parameters.
    
    Metrics include:
      - Total embeddings available.
      - Suggested sample count.
      - Sampling ratio (suggested / total).
      - Computed nlist.
      - Computed nprobe.
    
    Args:
        vector_count (int): Total number of embedding vectors.
        raw_nlist (int): Configured nlist value.
        max_samples (int): Maximum number of samples allowed.
    
    Returns:
        dict: A dictionary containing the tuning metrics.
    """
    sample_count = suggest_training_sample_count(vector_count, max_samples)
    nlist = calculate_nlist(vector_count, raw_nlist)
    nprobe = calculate_nprobe(vector_count)
    cost_adj_nprobe = calculate_nprobe_with_cost(vector_count)
    sampling_ratio = sample_count / vector_count if vector_count > 0 else 0.0
    return {
        "total_embeddings": vector_count,
        "suggested_sample_count": sample_count,
        "sampling_ratio": sampling_ratio,
        "nlist": nlist,
        "nprobe": nprobe,
        "cost_adj_nprobe": cost_adj_nprobe,
    }

# EXAMPLE USAGE
# metrics = get_tuning_metrics(vector_count=300, raw_nlist=512, max_samples=240)
# print("Tuning Metrics:")
# for key, value in metrics.items():
#     print(f"{key}: {value}")    




__all__ = [
    "calculate_nlist",
    "calculate_nprobe",
    "calculate_nprobe_with_cost",
    "get_tuning_metrics",
    "suggest_training_sample_count",
]
