"""
[File: tools/extract_docstrings.py]
Description: Scans Python files for function/class names listed in __all__, and extracts inline comments as descriptions.
Outputs CSV rows: filename, function, description.
"""

import os
import ast
import csv


def extract_all_targets(file_path):
    """Extract __all__ names as list of strings from a Python file."""
    with open(file_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read(), filename=file_path)

    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "__all__":
                    if isinstance(node.value, (ast.List, ast.Call)):
                        values = getattr(node.value, 'elts', [])
                        return [elt.s for elt in values if isinstance(elt, ast.Str)]
    return []


def extract_function_descriptions(file_path, target_names):
    """Extract doc comments (inline or docstrings) for given function names."""
    with open(file_path, "r", encoding="utf-8") as f:
        source_lines = f.readlines()
        tree = ast.parse("".join(source_lines), filename=file_path)

    output = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in target_names:
            docstring = ast.get_docstring(node) or ""
            if not docstring:
                # Try inline comment above
                lineno = node.lineno - 2
                while lineno >= 0 and lineno > node.lineno - 5:
                    line = source_lines[lineno].strip()
                    if line.startswith("#"):
                        docstring = line.lstrip("# ").strip()
                        break
                    lineno -= 1
            output.append((node.name, docstring))
    return output


def generate_manifest(folder_path, output_csv):
    rows = []
    for filename in os.listdir(folder_path):
        if filename.endswith(".py") and not filename.startswith("_"):
            path = os.path.join(folder_path, filename)
            targets = extract_all_targets(path)
            if targets:
                func_info = extract_function_descriptions(path, targets)
                for name, desc in func_info:
                    rows.append({"filename": filename, "function": name, "description": desc})

    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["filename", "function", "description"])
        writer.writeheader()
        writer.writerows(rows)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Extract __all__ entries and nearby comments from Python files.")
    parser.add_argument("folder", help="Folder of Python scripts")
    parser.add_argument("--out", default="manifest_doc_comments.csv", help="CSV output path")
    args = parser.parse_args()

    generate_manifest(args.folder, args.out)
