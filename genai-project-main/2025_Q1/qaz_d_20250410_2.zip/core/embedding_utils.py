"""
[File: core/embedding_utils.py]
Description: Generic tools for embeddings.
"""

import os
import json
import numpy as np
from pathlib import Path
from datetime import datetime

from core.s3_utils import list_objects_s3
from core.extraction_helper import is_blank_page
from core.model_key_utils import get_model_details
from core.embedding_helper import get_cached_vectorizer
from core.config_helper import get_config
from core.client_manager import get_client_bundle

# --- Config + Client Setup ---
config = get_config()
clients = get_client_bundle()
s3 = clients.s3
bedrock = clients.bedrock

# --- Re-embedding + Testing Constants ---
REEMBED_LIST_PATH = "reembed_list.json"
TEST_JSON_DIR = "test/json"

def prepare_embedding_input(data, exclude_keys=None):
    """Prepare a cleaned JSON string from the input data, excluding embedding keys."""
    if exclude_keys is None:
        exclude_keys = ["embeddings"]
    data_filtered = {k: v for k, v in data.items() if k not in exclude_keys}
    return json.dumps(data_filtered, indent=2)

def build_embedding_metadata(data: dict, json_key: str, model_key: str, dim: int) -> dict:
    """Construct a metadata dictionary used to track model embedding parameters."""
    return {
        "json_key": json_key,
        "model_key": model_key,
        "dimensions": dim,
        "source": data.get("source", "unknown"),
        "tags_list": data.get("tags", [])
    }

def embeddings_flatten(data, model_key, config, logger, force=False):
    """Extract and reshape the embedding vector for a specific model from a JSON structure."""
    model_info = config["model_options"].get(model_key)
    if not model_info:
        logger.warning(f"Model key not found: {model_key}")
        return None

    model_embedding = data.get("embeddings", {}).get(model_key)
    vector = model_embedding.get("vector") if model_embedding else None

    if force or not vector or len(vector) != model_info["dimensions"]:
        return None

    try:
        return np.array(vector, dtype=np.float32).reshape(1, -1)
    except Exception as e:
        logger.error(f"Error reshaping embedding for model '{model_key}': {e}")
        return None

def data_collect(config, s3_client, model_key, logger, force=False):
    """Download JSON files from S3, extract or re-generate embeddings, and return them with metadata."""
    if not s3_client:
        logger.error("❌ S3 client not initialized. Cannot collect embeddings.")
        return [], []

    training_embeddings = []
    metadata = []
    json_keys = list_objects_s3(config["bucket_name"], config["json_folder"], extension=".json")

    for json_key in json_keys:
        try:
            obj = s3_client.get_object(Bucket=config["bucket_name"], Key=json_key)
            content = obj["Body"].read().decode("utf-8").strip()
            if not content:
                continue
            data = json.loads(content)
            text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])

            if "#blankpage" in data.get("tags", []) or is_blank_page(text, data.get("chunks", [])):
                continue

            embedding_vector = embeddings_flatten(data, model_key, config, logger, force=force)
            if embedding_vector is None and force:
                vectorizer = get_cached_vectorizer()
                model_info = config["model_options"][model_key]
                if not vectorizer.bedrock_boto3:
                    logger.error("❌ Missing Bedrock client. Cannot generate embeddings.")
                    continue
                new_vector = vectorizer.generate_embedding(text)
                embedding_vector = np.array(new_vector, dtype=np.float32).reshape(1, -1)

                data.setdefault("embeddings", {})[model_key] = {
                    "id": model_info["id"],
                    "dimensions": model_info["dimensions"],
                    "embed_date": datetime.utcnow().isoformat() + "Z",
                    "vector": new_vector
                }
                s3_client.put_object(
                    Bucket=config["bucket_name"],
                    Key=json_key,
                    Body=json.dumps(data, indent=2).encode("utf-8"),
                    ContentType="application/json"
                )

            if embedding_vector is not None:
                training_embeddings.append(embedding_vector)
                meta = build_embedding_metadata(data, json_key, model_key, config["model_options"][model_key]["dimensions"])
                metadata.append(meta)
        except Exception as e:
            logger.warning(f"Failed to process {json_key}: {e}")
            continue

    return training_embeddings, metadata

# --- Exports ---
__all__ = [
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "data_collect"
]

## `embedding_utils.py` Functions

# | Function | Purpose |
# |---------|---------|
# | `prepare_embedding_input` | Returns cleaned JSON string for embedding input |
# | `build_embedding_metadata` | Returns key metadata (model key, tags, dimensions) |
# | `embeddings_flatten` | Validates and flattens embedding into NumPy array |
# | `data_collect` | Gathers valid embedding data from S3 |
#  the  reembed  are now  in reembed_mmanager  file
# | `reembed_flag` | Reprocesses and updates all files marked for re-embedding |
# | `reembed_append` | Adds a file to the re-embedding queue |
# get_text_to_encode(data, exclude_keys=None):
# A simple wrapper that returns a cleaned JSON string for embedding input (typically calls prepare_embedding_input).
