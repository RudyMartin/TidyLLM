"""
[File: core/config_helper.py]
Description: Unified configuration manager for Streamlit and CLI applications.
Updated 4-8-2025

### 🧠 `config_helper.py` Usage Guidelines

#### 🟩 `get_config()`  
- ✅ For use **inside Streamlit**
- Uses global `_config_instance`
- Caches config in memory
- May touch `st.session_state`

#### 🟦 `load_config()`  
- ✅ For **CLI, batch, test environments**
- Loads fresh config every time
- Avoids session state
- More stateless and safe for headless runs

---

### ⚠️ Known Risk: Silent Config Failures

- **Missing or malformed `config.json`** must be:
  - ❌ Not silently ignored
  - ✅ Logged to `stderr` or a logfile
  - ✅ Raised as `FileNotFoundError` or `ValueError`
"""

import os
import json
import logging
from datetime import datetime

# Safe import of Streamlit (for UI usage only)
try:
    import streamlit as st
    if hasattr(st, "session_state"):
        try:
            if not isinstance(st.session_state, dict):
                st.session_state.clear()
                st.session_state = {}
        except Exception:
            pass
except ImportError:
    st = None

# Logging setup
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# Path Definitions
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "config.json")
DEFAULT_CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "default_config.json")
LOG_DIR = os.path.join(PROJECT_DIR, "logs")

class ConfigManager:
    def __init__(self, config_path: str = CONFIG_PATH):
        self.config_path = config_path
        self.default_path = DEFAULT_CONFIG_PATH
        self.config = None

    def _load_config(self, path: str) -> dict:
        """Safely loads a JSON configuration file from the given path."""
        if not os.path.exists(path):
            logger.error(f"Config file not found: {path}")
            raise FileNotFoundError(f"Config file not found: {path}")
        try:
            with open(path, "r") as f:
                config = json.load(f)
            logger.info(f"Config loaded from: {path}")
            return config
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in {path}: {e}")
            raise ValueError(f"Invalid config file format: {path}")

    def get_config(self) -> dict:
        """Lazily loads and returns the current configuration."""
        if self.config is None:
            self.config = self._load_config(self.config_path)
        return self.config

    def save_config(self, new_config: dict = None, path: str = None):
        """Saves the provided configuration dictionary to the specified path."""
        config_to_save = new_config or self.get_config()
        path = path or self.config_path
        try:
            with open(path, "w") as f:
                json.dump(config_to_save, f, indent=2)
            logger.info(f"Config saved to {path}")
            return path
        except Exception as e:
            logger.error(f"Failed to save config to {path}: {e}")
            raise

    def restore_defaults(self):
        """Restores and returns the default configuration."""
        default_config = self._load_config(self.default_path)
        self.save_config(default_config, self.config_path)
        self.log_config_change("Restored Defaults", default_config)
        self.config = default_config
        return default_config

    def log_config_change(self, action: str, config_data: dict):
        """Logs configuration changes to a file with a timestamp."""
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        log_path = os.path.join(LOG_DIR, f"config_change_{timestamp}.json")
        os.makedirs(LOG_DIR, exist_ok=True)
        try:
            with open(log_path, "w") as f:
                json.dump({"action": action, "timestamp": timestamp, "config": config_data}, f, indent=2)
            logger.info(f"Config change logged: {log_path}")
        except Exception as e:
            logger.error(f"Failed to log config change: {e}")
            raise

# Global Singleton
_config_instance = ConfigManager()

def get_config():
    return _config_instance.get_config()

def save_config(config):
    return _config_instance.save_config(config)

def restore_default_config():
    return _config_instance.restore_defaults()

def load_config(path=CONFIG_PATH):
    return ConfigManager(config_path=path).get_config()


__all__ = [
    "ConfigManager",
    "get_config",
    "load_config",
    "restore_default_config",
    "save_config",
]
