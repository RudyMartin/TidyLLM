"""
[File: embedding_helper.py]
Description: Handles vectorizer initialization and caching for Bedrock models.
Supports model_key abstraction, mapped to model_id from config.
"""
import logging
import json
import numpy as np

from core.config_helper import get_config
from core.client_manager import get_clients
from core.model_key_utils import get_model_details

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# -----------------------
# Embedding Vectorizer
# -----------------------

class AmazonEmbeddingVectorizer:
    def __init__(self, model_id, dimensions=1536, bedrock_client=None):
        self.model_id = model_id
        self.dimensions = dimensions
        self.bedrock_boto3 = bedrock_client or get_clients().get("bedrock")

    def generate_embedding(self, text: str) -> list:
        if not self.bedrock_boto3:
            raise RuntimeError("Bedrock client not initialized.")

        body = self._prepare_body(text)
        try:
            response = self.bedrock_boto3.invoke_model(
                body=json.dumps(body),
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            response_body = json.loads(response.get("body").read())
            vector = response_body.get("embedding", [])
            return self._normalize_vector(vector)
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            raise

    def _prepare_body(self, text: str) -> dict:
        if "amazon.titan-embed-text-v2" in self.model_id:
            return {"inputText": text, "dimensions": int(self.dimensions)}
        elif "amazon.titan-embed-text-v1" in self.model_id:
            return {"inputText": text}
        elif "cohere" in self.model_id:
            from core.config_helper import get_config
            limit = get_config().get("cohere_limit", 2048)
            return {"texts": [text[:limit]], "input_type": "search_document"}
        else:
            raise ValueError(f"Unsupported model type: {self.model_id}")

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    @classmethod
    def from_model_key(cls, model_key: str):
        """
        Instantiate vectorizer using a model_key from config,
        safely resolving model_id and dimensions.
        """
        config = get_config()
        clients = get_clients()
        model_details = get_model_details(model_key, config.get("model_options", {}))
        if not model_details:
            raise ValueError(f"Invalid model_key: {model_key}")

        return cls(
            model_id=model_details["id"],
            dimensions=model_details["dimensions"],
            bedrock_client=clients.get("bedrock")
        )

# -----------------------
# Cached Vectorizer Manager
# -----------------------

_vectorizer_cache = {}

def get_cached_vectorizer(model_key=None):
    """
    Returns a cached instance of the vectorizer for a given model_key.
    """
    model_key = model_key or get_config()["default_model"]
    if model_key not in _vectorizer_cache:
        logger.info(f"Initializing vectorizer for: {model_key}")
        _vectorizer_cache[model_key] = AmazonEmbeddingVectorizer.from_model_key(model_key)
    return _vectorizer_cache[model_key]

__all__ = [
    "AmazonEmbeddingVectorizer",
    "get_cached_vectorizer"
]
