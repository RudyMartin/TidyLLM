"""
[File: core/s3_utils.py]
Description: Utility functions for interacting with AWS S3 and FAISS index storage.
"""

import sys
import json
import logging
import boto3
import faiss
from typing import List, Optional
from io import BytesIO

from core.logging_helper import get_logger

# logger = get_logger("s3_utils")
# logger.setLevel(logging.DEBUG)

# --- CLI/Streamlit Awareness ---
def is_streamlit():
    return any("streamlit" in arg for arg in sys.argv)

# --- Lazy Client Initialization ---
def get_s3_client(config=None):
    from core.client_manager import get_clients
    return get_clients(config).get("s3")

def get_bedrock_client(config=None):
    from core.client_manager import get_clients
    return get_clients(config).get("bedrock")

# --- File and Object Operations ---
def upload_to_s3(bucket: str, key: str, data, content_type: str = "application/octet-stream", config=None, s3_client=None):
    s3 = s3_client or get_s3_client(config)
    try:
        s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
        logger.info(f"✅ Uploaded file to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to upload file to s3://{bucket}/{key}: {e}")

def load_json_from_s3(bucket: str, key: str, config=None, s3_client=None) -> dict:
    s3 = s3_client or get_s3_client(config)
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(response["Body"].read().decode("utf-8"))
    except Exception as e:
        logger.error(f"❌ Failed to load JSON from s3://{bucket}/{key}: {e}")
        return {}

def save_json_to_s3(bucket: str, key: str, data: dict, config=None, s3_client=None):
    s3 = s3_client or get_s3_client(config)
    try:
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        logger.info(f"✅ Saved JSON to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to save JSON to s3://{bucket}/{key}: {e}")

def delete_s3_object(bucket: str, key: str, config=None, s3_client=None) -> bool:
    s3 = s3_client or get_s3_client(config)
    try:
        s3.delete_object(Bucket=bucket, Key=key)
        logger.info(f"🗑️ Deleted s3://{bucket}/{key}")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to delete s3://{bucket}/{key}: {e}")
        return False

def check_s3_object_tag(bucket: str, key: str, tag_key: str, config=None, s3_client=None) -> bool:
    s3 = s3_client or get_s3_client(config)
    try:
        response = s3.get_object_tagging(Bucket=bucket, Key=key)
        tags = {tag["Key"]: tag["Value"] for tag in response.get("TagSet", [])}
        return tag_key in tags
    except s3.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "AccessDenied":
            logger.warning(f"⚠️ Access denied checking tags for {key}")
        else:
            logger.error(f"❌ Error checking tags for {key}: {e}")
        return False

# --- Listing Utilities ---
def list_objects_s3(bucket: str, prefix: str, extension: Optional[str] = None, config=None, s3_client=None) -> list:
    s3 = s3_client or get_s3_client(config)
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        if extension:
            keys = [key for key in keys if key.endswith(extension)]
        return keys
    except Exception as e:
        logger.error(f"❌ Error listing objects in s3://{bucket}/{prefix}: {e}")
        return []

def list_s3_files_with_extension(bucket: str, prefix: str, extension: str, config=None, s3_client=None) -> list:
    s3 = s3_client or get_s3_client(config)
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        return [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(extension)]
    except Exception as e:
        logger.error(f"❌ Failed to list files with extension {extension}: {e}")
        return []

def list_pdf_files_s3(bucket: str, prefix: str = "", config=None, s3_client=None) -> List[str]:
    return list_s3_files_with_extension(bucket, prefix, ".pdf", config, s3_client)

def list_json_files_s3(bucket: str, prefix: str = "", config=None, s3_client=None) -> List[str]:
    return list_s3_files_with_extension(bucket, prefix, ".json", config, s3_client)

def list_folders_s3(bucket: str, prefix: str = "", config=None, s3_client=None) -> List[str]:
    s3 = s3_client or get_s3_client(config)
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        return [cp["Prefix"] for cp in response.get("CommonPrefixes", [])]
    except Exception as e:
        logger.error(f"❌ Error listing folders under {prefix}: {e}")
        return []

# --- Public Exports ---
__all__ = [
    "upload_to_s3",
    "load_json_from_s3",
    "save_json_to_s3",
    "delete_s3_object",
    "check_s3_object_tag",
    "list_objects_s3",
    "list_s3_files_with_extension",
    "list_pdf_files_s3",
    "list_json_files_s3",
    "list_folders_s3",
    "get_s3_client",
    "get_bedrock_client"
]
