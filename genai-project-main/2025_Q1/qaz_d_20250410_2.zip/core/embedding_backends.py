"""
[File: core/embedding_backends.py]
Description: Backend classes for embedding generation via Bedrock. Includes AmazonBedrock and AmazonTitan.
"""

import json
import numpy as np
from core.client_manager import get_client_bundle
from core.logging_helper import get_logger
from core.model_key_utils import get_model_details
from core.config_helper import get_config

logger = get_logger("embedding_backends")

# --- Base class for shared behavior ---
class BaseEmbeddingBackend:
    def __init__(self, model_key, config, bedrock_client):
        self.model_key = model_key
        self.config = config
        self.model_details = get_model_details(model_key, config.get("model_options", {}))
        self.model_id = self.model_details["id"]
        self.dimensions = self.model_details.get("dimensions", 1536)
        self.bedrock = bedrock_client

    def generate_embedding(self, text: str) -> list:
        raise NotImplementedError("Subclasses must implement generate_embedding")

    def batch_generate(self, texts: list[str]) -> list[list[float]]:
        return [self.generate_embedding(t) for t in texts]

    def _normalize(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector


# --- AmazonBedrockEmbedding (Generic catch-all for Bedrock) ---
class AmazonBedrockEmbedding(BaseEmbeddingBackend):
    def generate_embedding(self, text: str) -> list:
        if not self.bedrock:
            raise RuntimeError("Bedrock client not initialized")

        body = {"inputText": text}
        if "v2" in self.model_id:
            body["dimensions"] = int(self.dimensions)

        try:
            response = self.bedrock.invoke_model(
                body=json.dumps(body),
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            response_body = json.loads(response.get("body").read())
            vector = response_body.get("embedding", [])
            return self._normalize(vector)
        except Exception as e:
            logger.error(f"❌ AmazonBedrock embedding failed: {e}")
            raise


# --- AmazonTitanEmbedding (Explicit Titan class for clarity) ---
class AmazonTitanEmbedding(AmazonBedrockEmbedding):
    pass


# --- AmazonEmbeddingVectorizer for compatibility or test mode ---
class AmazonEmbeddingVectorizer:
    def __init__(self, model_id, dimensions=1536, bedrock_client=None):
        self.model_id = model_id
        self.dimensions = dimensions
        self.bedrock_boto3 = bedrock_client or get_client_bundle().get("bedrock")

    def generate_embedding(self, text: str) -> list:
        if not self.bedrock_boto3:
            raise RuntimeError("Bedrock client not initialized.")

        body = self._prepare_body(text)
        try:
            response = self.bedrock_boto3.invoke_model(
                body=json.dumps(body),
                modelId=self.model_id,
                accept="application/json",
                contentType="application/json"
            )
            response_body = json.loads(response.get("body").read())
            vector = response_body.get("embedding", [])
            return self._normalize_vector(vector)
        except Exception as e:
            logger.error(f"Failed to generate embedding: {e}")
            raise

    def _prepare_body(self, text: str) -> dict:
        if "amazon.titan-embed-text-v2" in self.model_id:
            return {"inputText": text, "dimensions": int(self.dimensions)}
        elif "amazon.titan-embed-text-v1" in self.model_id:
            return {"inputText": text}
        elif "cohere" in self.model_id:
            limit = get_config().get("cohere_limit", 2048)
            return {"texts": [text[:limit]], "input_type": "search_document"}
        else:
            raise ValueError(f"Unsupported model type: {self.model_id}")

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    @classmethod
    def from_model_key(cls, model_key: str):
        config = get_config()
        clients = get_client_bundle()
        model_details = get_model_details(model_key, config.get("model_options", {}))
        if not model_details:
            raise ValueError(f"Invalid model_key: {model_key}")

        return cls(
            model_id=model_details["id"],
            dimensions=model_details["dimensions"],
            bedrock_client=clients.get("bedrock")
        )


# --- Optional placeholders ---
class CohereEmbedding(BaseEmbeddingBackend):
    def generate_embedding(self, text: str) -> list:
        raise NotImplementedError("CohereEmbedding not implemented yet")

class AnthropicEmbedding(BaseEmbeddingBackend):
    def generate_embedding(self, text: str) -> list:
        raise NotImplementedError("AnthropicEmbedding not implemented yet")


__all__ = [
    "AmazonBedrockEmbedding",
    "AmazonTitanEmbedding",
    "AmazonEmbeddingVectorizer",
    "CohereEmbedding",
    "AnthropicEmbedding",
    "BaseEmbeddingBackend"
]
