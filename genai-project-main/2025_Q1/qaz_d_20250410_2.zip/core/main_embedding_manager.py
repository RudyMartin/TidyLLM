"""
[File: embedding_manager.py]
Description: EmbeddingManager wraps Bedrock embedding logic and JSON updates per model_key.
"""
import json
from datetime import datetime
import numpy as np
import streamlit as st

from core.embedding_utils import (
    prepare_embedding_input,
    build_embedding_metadata,
    embeddings_flatten,
    data_collect,
    reembed_flag,
    reembed_append,
    get_text_to_encode,
)

from core.extraction_helper import is_blank_page
from core.s3_utils import list_objects_s3
from core.logging_helper import get_logger
from core.embedding_helper import AmazonEmbeddingVectorizer, get_cached_vectorizer
from core.model_key_utils import get_model_details
from core.client_manager import get_client_bundle

# ---------- Logging ----------
logger = get_logger("embedding_manager")

# ---------- Initialize ClientBundle ----------
clients = get_client_bundle()
config = clients.config
s3 = clients.s3
bedrock = clients.bedrock


# ---------- Metadata Logger ----------
def log_embedding_metadata(document_name, model_key, vector_length, tag_list):
    metadata = {
        "timestamp": datetime.utcnow().isoformat(),
        "document": document_name,
        "model": model_key,
        "dimensions": vector_length,
        "tags": tag_list,
    }
    logger.info(f" Embedding metadata: {json.dumps(metadata)}")

# ---------- EmbeddingManager Wrapper ----------
class EmbeddingManager:
    def __init__(self, clients=None, vectorizer=None, model_key=None):
        self.clients = clients or get_clients()
        self.config = self.clients["config"]
        self.s3 = self.clients["s3"]
        self.bedrock = self.clients.get("bedrock")
        self.model_key = model_key or self.config.get("default_model")
        self.vectorizer = vectorizer or self._initialize_vectorizer()

    def _initialize_vectorizer(self):
        if not self.bedrock:
            raise ValueError("Missing Bedrock client. Cannot initialize vectorizer.")
        return AmazonEmbeddingVectorizer.from_model_key(self.model_key)

    def generate(self, text: str) -> list:
        return self.vectorizer.generate_embedding(text)

    def flatten_embedding(self, data: dict) -> dict:
        return embeddings_flatten(data, self.model_key, self.config, logger)

    def collect_embeddings(self, force: bool = False):
        return data_collect(self.config, self.s3, self.model_key, logger, force=force)

    def reembed_flagged(self):
        return reembed_flag(logger)

    def append_to_reembed_list(self, file, reason):
        return reembed_append(file, self.model_key, reason, logger)

    def embed_and_update_json(self, json_data: dict, json_key: str, force=False):
        model_details = get_model_details(self.model_key, self.config["model_options"])
        full_key = f"{model_details['id']}_{model_details['dimensions']}"

        if not force and self.model_key in json_data.get("embeddings", {}):
            logger.info(f"🔁 Skipping {json_key} — already embedded with {self.model_key}")
            return

        text = json_data.get("text", "") or " ".join(
            chunk.get("text", "") for chunk in json_data.get("chunks", [])
        )
        if not text.strip():
            logger.warning(f"⚠️ No valid text found in {json_key}, skipping embedding.")
            return

        if not self.vectorizer.bedrock_boto3:
            logger.error("❌ Missing Bedrock client. Embedding skipped.")
            return

        if not self.s3:
            logger.error("❌ Missing S3 client. Cannot save embedding.")
            return

        vector = self.vectorizer.generate_embedding(text)
        json_data.setdefault("embeddings", {})
        json_data["embeddings"][self.model_key] = {
            "id": model_details["id"],
            "dimensions": model_details["dimensions"],
            "embed_date": datetime.utcnow().isoformat() + "Z",
            "vector": vector
        }

        self.s3.put_object(
            Bucket=self.config["bucket_name"],
            Key=json_key,
            Body=json.dumps(json_data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        logger.info(f"✅ Embedded and updated: {json_key} with model {self.model_key}")

# ---------- Re-exports ----------
__all__ = [
    "AmazonEmbeddingVectorizer",
    "get_cached_vectorizer",
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "data_collect",
    "reembed_flag",
    "reembed_append",
    "get_text_to_encode",
    "log_embedding_metadata",
    "get_logger",
    "get_model_details",
    "is_blank_page",
    "list_objects_s3",
    "EmbeddingManager",
]
