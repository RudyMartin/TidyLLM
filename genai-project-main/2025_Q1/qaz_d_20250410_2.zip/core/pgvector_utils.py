"""
[File: core/pgvector_utils.py]
Description: Optional utilities for pgVector backup, diagnostics, and round-trip tests.
USAGE:
  from core.pgvector_utils import pgvector_backup_index, pgvector_check_health, pgvector_roundtrip_test

  # Example: run a backup
  pgvector_backup_index(model_key="titan_v2")

  # Example: health check
  report = pgvector_check_health(model_key="titan_v2")
  print(report)

  # Example: embedding round-trip
  result = pgvector_roundtrip_test(model_key="titan_v2", sample_text="example")
"""

import json
import uuid
import psycopg2
from datetime import datetime
from core.config_helper import get_config, get_clients
from core.s3_utils import save_json_to_s3


def pgvector_backup_index(model_key: str):
    """
    Fetch all rows from pgVector index and back them up to S3 as JSON.
    """
    config = get_config()
    conn = psycopg2.connect(config["pgvector"]["genai"]["url"])
    cur = conn.cursor()

    cur.execute("SELECT id, embedding, embed_time FROM pg_vec")
    vectors = cur.fetchall()

    cur.execute("SELECT id, model_key, created_at, document_name, page_number, tags FROM pg_details")
    metadata = {row[0]: row[1:] for row in cur.fetchall()}

    all_records = []
    for rec in vectors:
        record_id, vector, embed_time = rec
        meta = metadata.get(record_id)
        all_records.append({
            "id": str(record_id),
            "embedding": vector,
            "embed_time": embed_time,
            "metadata": meta
        })

    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M")
    out_key = f"backups/pgvector_{model_key}_{timestamp}.json"
    save_json_to_s3(config["bucket_name"], out_key, all_records)
    print(f"✅ Backup saved to s3://{config['bucket_name']}/{out_key}")


def pgvector_check_health(model_key: str):
    """
    Check number of vectors and consistency for a model_key.
    """
    config = get_config()
    conn = psycopg2.connect(config["pgvector"]["genai"]["url"])
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM pg_vec")
    vec_count = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM pg_details WHERE model_key = %s", (model_key,))
    meta_count = cur.fetchone()[0]

    return {
        "model_key": model_key,
        "vector_count": vec_count,
        "metadata_count": meta_count,
        "status": "🟢 OK" if vec_count == meta_count else "🟡 Mismatch"
    }


def pgvector_roundtrip_test(model_key: str, sample_text: str):
    """
    Simulate an embedding and search against the pgvector index.
    """
    from core.embedding_helper import get_cached_vectorizer
    config = get_config()
    conn = psycopg2.connect(config["pgvector"]["genai"]["url"])
    cur = conn.cursor()

    vectorizer = get_cached_vectorizer(model_key)
    embedding = vectorizer.embed_text(sample_text)

    cur.execute(
        """
        SELECT id, (embedding <#> %s) AS distance
        FROM pg_vec
        ORDER BY embedding <#> %s
        LIMIT 5;
        """,
        (embedding, embedding)
    )
    return [
        {"id": str(row[0]), "distance": row[1]} for row in cur.fetchall()
    ]


__all__ = [
    "pgvector_backup_index",
    "pgvector_check_health",
    "pgvector_roundtrip_test",
]
