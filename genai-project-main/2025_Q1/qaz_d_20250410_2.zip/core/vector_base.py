"""
[File: core/vector_base.py]
Description: Base class for all vector store implementations.
"""
from abc import ABC, abstractmethod

class BaseVectorStore(ABC):
    """
    Abstract base class that defines the contract for vector store backends.
    This interface is used by VectorManager to delegate operations.
    """

    def __init__(self, config, s3_client, logger):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger

    @abstractmethod
    def list_indexes(self):
        """Return a list of index metadata or file keys."""
        pass

    @abstractmethod
    def index_create(self, embeddings, model_key, metadata=None):
        """Create and save an index from a batch of embeddings."""
        pass

    @abstractmethod
    def collect_embeddings_and_metadata(self, model_key, force=False):
        """Gather embedding vectors and associated metadata from S3 or local storage."""
        pass

    @abstractmethod
    def embeddings_batch(self, model_keys, force=False):
        """Run batch collection and indexing across multiple model keys."""
        pass

    @abstractmethod
    def validate(self, model_key):
        """Return True if index exists and is valid for a given model_key."""
        pass

    @abstractmethod
    def get_index_status(self):
        """Return detailed index status including vector count, last update, etc."""
        pass

    @abstractmethod
    def query(self, query_embedding, top_k=3):
        """Return top_k most similar vectors from the index."""
        pass

    @abstractmethod
    def reindex(self):
        """Rebuild the index from scratch using stored JSONs or database entries."""
        pass

    @abstractmethod
    def delete_index(self):
        """Delete index from S3 or database backend (optional)."""
        pass

    @abstractmethod
    def load_index(self):
        """Load the index from S3 or backend and make it ready for querying (optional)."""
        pass


__all__ = [
    "BaseVectorStore",
]
