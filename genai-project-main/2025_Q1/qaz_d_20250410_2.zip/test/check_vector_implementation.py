"""
check_vector_implementation.py

This script validates that all abstract methods defined in BaseVectorStore
are implemented in FaissStore and PGVectorStore.
"""

import inspect
from types import FunctionType

from core.vector_base import BaseVectorStore
from core.faiss_store import FaissStore
from core.pgvector_store import PGVectorStore


def extract_base_methods(cls):
    return {
        name
        for name, method in inspect.getmembers(cls)
        if isinstance(method, FunctionType) and not name.startswith("__")
    }


def extract_backend_methods(cls):
    return {
        name
        for name, method in inspect.getmembers(cls)
        if callable(method) and not name.startswith("__")
    }


def check_backend_against_base(base_methods, backend_methods, store_name):
    print(f"\nChecking {store_name} implementation:")
    for method in sorted(base_methods):
        if method in backend_methods:
            print(f"  ✅ {method}")
        else:
            print(f"  ❌ {method} MISSING!")


def main():
    base_methods = extract_base_methods(BaseVectorStore)
    faiss_methods = extract_backend_methods(FaissStore)
    pgvector_methods = extract_backend_methods(PGVectorStore)

    check_backend_against_base(base_methods, faiss_methods, "FaissStore")
    check_backend_against_base(base_methods, pgvector_methods, "PGVectorStore")


if __name__ == "__main__":
    main()
