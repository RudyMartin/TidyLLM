# [File: scripts/test_pgvector_flow.py]
# Description: CLI test to validate pgVector end-to-end integration

from core.pgvector_store import PGVectorStore
from core.config_helper import get_config, get_clients

if __name__ == "__main__":
    config = get_config()
    clients = get_clients()
    logger = clients.logger

    store = PGVectorStore(config=config, s3_client=clients.s3, logger=logger)

    # Test model_key
    model_key = config.get("default_model_option", "titan_v2")

    print(f"🔁 Reindexing pgVector for model: {model_key} (mode = {config.get('pgvector_mode')})")
    store.reindex()

    print("📊 Checking index status...")
    status = store.get_index_status()
    for row in status:
        print(f"  ➤ {row['Model']}: {row['Count']} vectors, Status {row['Status']}")

    print("🔍 Performing dummy query...")
    dummy_vector = [0.01] * config["embedding_dimension"]
    results = store.query(dummy_vector, top_k=3)
    for res in results:
        print(f"  ➤ Score: {res['score']:.4f} | Metadata: {res['metadata']}")
