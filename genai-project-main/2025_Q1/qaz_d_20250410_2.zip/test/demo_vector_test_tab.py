# [File: app/demo_vector_test_tab.py]
# Description: Streamlit demo tab to toggle between pgVector and FAISS indexing flows

import streamlit as st
from core.vector_interface import (
    vector_index, vector_query, vector_validate,
    vector_delete, vector_reindex, vector_list, vector_load
)

st.title("🧪 Vector Store Test Tab")

store_type = st.radio("Choose Vector Store Backend", ["pgvector", "faiss"], index=0)
model_key = st.text_input("Model Key", value="titan_v2")

st.markdown("---")

if st.button("Reindex Vector Store"):
    with st.spinner(f"Reindexing {store_type} for model {model_key}..."):
        vector_reindex(store_type=store_type)
    st.success("Reindex complete!")

if st.button("List Embedded Files"):
    items = vector_list(store_type=store_type)
    st.json(items)

if st.button("Validate Model Index"):
    result = vector_validate(model_key=model_key, store_type=store_type)
    st.success(f"Index valid: {result}")

if st.button("Delete Index"):
    vector_delete(store_type=store_type)
    st.warning("Index deleted.")

st.markdown("---")

st.subheader("🔍 Test Vector Query")
dummy_vector = [0.01] * 1024 if "v2" in model_key else [0.01] * 768

top_k = st.slider("Top K", min_value=1, max_value=10, value=3)
if st.button("Run Query"):
    results = vector_query(dummy_vector, top_k=top_k, store_type=store_type)
    st.write("Results:")
    st.json(results)
