
# VectorQA Sage (Option 2)

VectorQA Sage is a Streamlit-based application for evaluating LLM outputs using DSPy pipelines, FAISS indexing, and topic-based validation. It supports prompt strategy tuning, compiled modules, and performance visualization.

## 🧠 Features
- Upload and normalize labeled QA examples
- Train/test split and manual editing
- Prompt strategy configuration with DSPy/LLM toggle
- Compile DSPy modules with few-shot optimization
- Evaluate results (accuracy, confusion matrix, topic winners)
- View FAISS/model status
- Save/load DSPy pipelines

## 🚀 Quick Start

```bash
cd qaz
pip install -r requirements.txt

streamlit run vqa_app.py \
  --browser.gatherUsageStats False \
  --server.address 0.0.0.0

https://oilajldpsxb7rmg.studio.us-east-1.sagemaker.aws/jupyterlab/default/proxy/8501/


streamlit run demo_vector_sanity_app.py \
  --browser.gatherUsageStats False \
  --server.address 0.0.0.0

  

streamlit run demo_vector_sanity_app.py --server.enableCORS false --server.enableXsrfProtection false --server.address 0.0.0.0


streamlit run demo_vector_sanity_app.py  --browser.gatherUsageStats False --server.address  0.0.0.0

streamlit run demo_admin.py  --browser.gatherUsageStats False --server.address  0.0.0.0

streamlit run demo_main.py  --browser.gatherUsageStats False --server.address  0.0.0.0

streamlit run mock_demo_a.py  --browser.gatherUsageStats False --server.address  0.0.0.0

streamlit run mock_demo.py  --browser.gatherUsageStats False --server.address  0.0.0.0

```
https://gkqfn12jlopid0z.studio.us-east-1.sagemaker.aws/jupyterlab/default/proxy/8501/

https://oilajldpsxb7rmg.studio.us-east-1.sagemaker.aws/jupyterlab/default/proxy/8501/

## 📁 App Tabs
1. Upload & Normalize
2. Split Dataset
3. Edit Examples
4. Prompt Config (DSPy)
5. Evaluate Models
6. FAISS & Model Status
7. Compile DSPy Module

## 🧰 Requirements
See `requirements.txt` for full dependencies.

## 📄 License
MIT – Provided by Next Shift Consulting

## zipping files

zip -r qaz_20250401v2.zip /qaz

##  memory
free -h

du -sh * | sort -h