"""
[File: run_export_pipeline.py]
Description:
  Runs the full export process in sequence:
    1. Cleans logs and checks for incomplete code markers
    2. Runs structural diagnostics
    3. Builds and injects file index
    4. Creates a versioned ZIP archive of the cleaned project

Usage:
  $ python run_export_pipeline.py
      → runs everything with defaults

  $ python run_export_pipeline.py --manifest manifest.csv
      → uses a custom manifest file during header injection

  $ python run_export_pipeline.py --folder ./src --destination ./dev
      → runs on custom folder and saves to custom destination
"""

import os
import sys
import subprocess
import argparse

# Set root for internal tooling access
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# Optional: central SKIP_FOLDERS (used in diagnostics, indexer, cleaner)
SKIP_FOLDERS = {"__pycache__", ".git", ".ipynb_checkpoints", "dev"}

def run_script(cmd_list, label):
    print(f"\n🚀 Running: {label}")
    result = subprocess.run(cmd_list, capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print(f"⚠️ Errors during {label}:\n{result.stderr}")

def main():
    default_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    default_dest = os.path.join(default_folder, "dev")

    parser = argparse.ArgumentParser(description="Full export pipeline: clean + validate + zip.")
    parser.add_argument("--folder", default=default_folder, help="Folder to export (default: project root)")
    parser.add_argument("--destination", default=default_dest, help="Where to save ZIP (default: dev/)")
    parser.add_argument("--manifest", type=str, help="Optional manifest file to inject and update")
    args = parser.parse_args()

    folder = os.path.abspath(args.folder)
    destination = os.path.abspath(args.destination)

    os.makedirs(destination, exist_ok=True)

    # Step 1: Clean logs and incomplete markers
    run_script(["python", "clean_before_export.py", "--folder", folder], "🧼 Clean Incomplete + Logs")

    # Step 2: Run diagnostics
    run_script(["python", "project_diagnostics.py"], "🔍 Structural Diagnostics")

    # Step 3: Generate and inject manifest headers
    index_cmd = [
        "python", "generate_file_index.py",
        "--root", folder,
        "--inject_headers"
    ]
    if args.manifest:
        index_cmd += ["--manifest", args.manifest]
    run_script(index_cmd, "🗂️ File Index + Header Injection")

    # Step 4: Zip everything (excluding skipped folders)
    zip_cmd = [
        "python", "zip_for_export.py",
        "--folder", folder,
        "--destination", destination
    ]
    if args.manifest:
        zip_cmd += ["--manifest", args.manifest]
    run_script(zip_cmd, "📦 Final Zip Creation")

if __name__ == "__main__":
    main()

