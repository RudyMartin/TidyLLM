"""
[File: generate_file_index.py]
Description: Scans all files in a directory, uses manifest or header comments to describe them,
             and writes both CSV and Markdown outputs for reference. Optionally injects manifest-based
             headers into source files and syncs updates back into the manifest.

Usage:

$ cd admin

  $ python generate_file_index.py
  $ python generate_file_index.py --output "file_manifest.csv"


parser.add_argument("--root", type=str, default="..", help="Root folder to scan.")
    parser.add_argument("--manifest", type=str, help="Optional CSV file with file_name and file_description.")
    parser.add_argument("--output", type=str, default="file_index.csv", help="Output CSV filename.")
    parser.add_argument("--inject_headers", action="store_true", help="Insert manifest headers into source files.")
   
  
"""


import sys
import os
import csv
import argparse
from datetime import datetime

# Add root to sys.path
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from core.basic_utils import generate_versioned_filename

# 🔒 Centralized skip rule
SKIP_FOLDERS = {"__pycache__", ".git", ".ipynb_checkpoints", "dev"}

def should_skip_folder(dirpath):
    return any(skip in dirpath.split(os.sep) for skip in SKIP_FOLDERS)

def should_skip_file(filepath):
    parts = filepath.replace("\\", "/").split("/")
    return any(part in SKIP_FOLDERS for part in parts)

def extract_file_description(filepath):
    """
    Returns (description_str, update_manifest_flag)
    """
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            in_header = False
            capturing = False
            description_lines = []
            update_manifest = False

            for line in lines[:25]:
                stripped = line.strip()

                if stripped.startswith(('"""', "'''")):
                    in_header = not in_header
                    if not in_header and capturing:
                        break
                    continue

                if not in_header:
                    continue

                if not capturing:
                    if stripped.lower().startswith("description:"):
                        capturing = True
                        update_manifest = "# update_manifest" in stripped.lower()
                        desc_line = stripped.split(":", 1)[-1].split("#")[0].strip()
                        description_lines.append(desc_line)
                    continue

                if stripped == "":
                    break

                description_lines.append(stripped)

            return " ".join(description_lines).strip(), update_manifest
    except Exception as e:
        return f"⚠️ Failed to read file: {e}", False

def load_manifest(manifest_path):
    manifest = {}
    if not manifest_path or not os.path.exists(manifest_path):
        return manifest
    with open(manifest_path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            name = row["file_name"].strip().replace("\\", "/")
            desc = row.get("file_description", "").strip()
            if desc:
                manifest[name] = desc
    return manifest

def inject_manifest_header(file_path, description):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if "[File:" in content[:300]:  # skip if header already exists
            return False

        filename = os.path.basename(file_path)
        header = f'"""\n[File: {filename}]\nDescription: {description}\n"""\n\n'
        updated = header + content

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(updated)
        return True

    except Exception as e:
        print(f"⚠️ Failed to inject header into {file_path}: {e}")
        return False

def create_file_index(root_folder, output_csv="file_index.csv", write_md=True, manifest=None, inject_headers=False):
    manifest_map = load_manifest(manifest)
    file_data = []
    updated_manifest = {}

    for dirpath, _, filenames in os.walk(root_folder):
        if should_skip_folder(dirpath):
            continue

        for filename in filenames:
            full_path = os.path.join(dirpath, filename)
            if should_skip_file(full_path):
                continue

            name_lower = filename.lower()
            if (
                name_lower.startswith("z_")
                or name_lower.startswith("file_index")
                or "admin" in name_lower
                or "manifest" in name_lower
                or "__init__" in name_lower
                or ".pyc" in name_lower
            ):
                continue

            rel_path = os.path.relpath(full_path, root_folder).replace("\\", "/")
            description, update_flag = extract_file_description(full_path)
            description = manifest_map.get(rel_path, description)

            file_data.append({
                "file_name": rel_path,
                "file_description": description
            })

            if inject_headers and description and full_path.endswith(".py"):
                if inject_manifest_header(full_path, description):
                    print(f"✏️  Header injected into {rel_path}")

            if update_flag:
                updated_manifest[rel_path] = description

    file_data = sorted(file_data, key=lambda x: x["file_name"])
    output_csv = generate_versioned_filename("file_index", ".csv")

    with open(output_csv, "w", newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=["file_name", "file_description"])
        writer.writeheader()
        writer.writerows(file_data)
    print(f"✅ CSV file index written to {output_csv}")

    if write_md:
        output_md = output_csv.replace(".csv", ".md")
        asof = datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")

        with open(output_md, "w", encoding="utf-8") as f:
            f.write(f"# 📄 File Index Manifest\n\n")
            f.write(f"**As of:** `{asof}`\n\n")
            f.write("| file_name | file_description |\n")
            f.write("|-----------|------------------|\n")
            for row in file_data:
                name = row["file_name"].replace("|", "\\|")
                desc = row["file_description"].replace("|", "\\|")
                f.write(f"| {name} | {desc} |\n")
        print(f"✅ Markdown file index written to {output_md}")

    if updated_manifest and manifest:
        print("🔄 Updating manifest with flagged descriptions...")
        manifest_df = []
        with open(manifest, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                key = row["file_name"].strip().replace("\\", "/")
                if key in updated_manifest:
                    row["file_description"] = updated_manifest[key]
                    print(f"   ↪ {key} updated.")
                manifest_df.append(row)

        with open(manifest, "w", newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=["file_name", "file_description"])
            writer.writeheader()
            writer.writerows(manifest_df)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate file index CSV and Markdown.")
    parser.add_argument("--root", type=str, default="..", help="Root folder to scan.")
    parser.add_argument("--manifest", type=str, help="Optional CSV file with file_name and file_description.")
    parser.add_argument("--output", type=str, default="file_index.csv", help="Output CSV filename.")
    parser.add_argument("--inject_headers", action="store_true", help="Insert manifest headers into source files.")
    args = parser.parse_args()

    create_file_index(
        root_folder=args.root,
        output_csv=args.output,
        write_md=True,
        manifest=args.manifest,
        inject_headers=args.inject_headers
    )
   