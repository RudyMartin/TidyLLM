"""
[File: zip_for_export.py]
Description:
  Final export script that:
    - Creates a versioned ZIP archive of the cleaned project
    - Skips quarantined folders like dev/, .git/, .ipynb_checkpoints/
    - Assumes clean_before_export.py and generate_file_index.py have already been run

Usage:
  $ python zip_for_export.py
  $ python zip_for_export.py --folder ./src --destination ./output
  $ python zip_for_export.py --manifest manifest.csv
"""

import os
import sys
import zipfile
import datetime
import argparse

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from core.basic_utils import generate_versioned_filename

# 🧼 Central skip list
SKIP_FOLDERS = {"__pycache__", ".git", ".ipynb_checkpoints", "dev"}

def should_skip_folder(dirpath):
    return any(skip in dirpath.split(os.sep) for skip in SKIP_FOLDERS)

def zip_project(folder_to_zip, destination_path=".", skip_folder="dev"):
    base_name = os.path.basename(folder_to_zip.rstrip("/\\"))
    zip_filename = generate_versioned_filename(base_name, extension=".zip", directory=destination_path)
    zip_path = os.path.join(destination_path, zip_filename)

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(folder_to_zip):
            if should_skip_folder(root):
                continue
            for f in files:
                full_path = os.path.join(root, f)
                arcname = os.path.relpath(full_path, folder_to_zip)
                zf.write(full_path, arcname=arcname)

    print(f"\n✅ Zipped '{folder_to_zip}' into '{zip_path}' (skipped folders: {', '.join(SKIP_FOLDERS)}).")
    return zip_path

def main():
    default_folder = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    default_dest = os.path.join(default_folder, "dev")

    parser = argparse.ArgumentParser(
        description="Create a versioned ZIP archive of the cleaned project."
    )
    parser.add_argument("--folder", default=default_folder,
                        help="Folder to export (default: project root)")
    parser.add_argument("--destination", default=default_dest,
                        help="Where to save the ZIP (default: dev/)")
    parser.add_argument("--skip-folder", default="dev",
                        help="Legacy parameter, now handled by SKIP_FOLDERS")
    parser.add_argument("--manifest", type=str,
                        help="(Ignored) Path to manifest file [indexing is upstream now]")
    args = parser.parse_args()

    folder = os.path.abspath(args.folder)
    destination = os.path.abspath(args.destination)

    os.makedirs(destination, exist_ok=True)
    zip_project(folder, destination_path=destination, skip_folder=args.skip_folder)

if __name__ == "__main__":
    main()
