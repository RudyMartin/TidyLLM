# 📄 File Index Manifest

**As of:** `2025-04-10 13:57 UTC`

| file_name | file_description |
|-----------|------------------|
| README (3).md |  |
| admin/clean_before_export.py | This script prepares your project for export: 1. Scans for incomplete files with markers (e.g. 'STILL NEEDS WORK', 'WIP') 2. Removes .log files (outside protected folders like dev/) 3. Purges .ipynb_checkpoints/ and __pycache__/ folders |
| admin/generate_file_index.py | Scans all files in a directory, uses manifest or header comments to describe them, and writes both CSV and Markdown outputs for reference. Optionally injects manifest-based headers into source files and syncs updates back into the manifest. |
| admin/project_diagnostics.py | Scans the project root for known anti-patterns like banned filenames, unversioned index files, empty folders, and missing __init__.py files. Used to validate structure before releases or commits. Includes an optional auto-fix for __init__.py issues. |
| admin/run_export_pipeline.py | Runs the full export process in sequence: 1. Cleans logs and checks for incomplete code markers 2. Runs structural diagnostics 3. Builds and injects file index 4. Creates a versioned ZIP archive of the cleaned project |
| admin/zip_for_export.py | Final export script that: - Creates a versioned ZIP archive of the cleaned project - Skips quarantined folders like dev/, .git/, .ipynb_checkpoints/ - Assumes clean_before_export.py and generate_file_index.py have already been run |
| apps/audit_log_viewer.py | Standalone demo for inspecting audit logs and semantic matches in model governance workflow. |
| apps/metrics_viewer.py | Standalone demo viewer for governance-related model metrics and completion statistics. |
| config/config.json |  |
| config/instructions.json |  |
| core/basic_utils.py | General utilities file. |
| core/client_manager.py | Delegates AWS client access to core/client_utils with safe fallback. Includes optional ClientBundle for dot-access compatibility. |
| core/client_utils.py | Provides cached and flexible AWS client access for S3 and Bedrock using config or session state |
| core/config_helper.py | Unified configuration manager for Streamlit and CLI applications. Updated 4-8-2025 |
| core/embedding_backends.py | Backend classes for embedding generation via Bedrock. Includes AmazonBedrock and AmazonTitan. |
| core/embedding_manager.py | Unified EmbeddingManager that supports multiple backends (Titan, Cohere, Claude, AmazonBedrock), embedding lifecycle control, and JSON document updates. |
| core/embedding_utils.py | Generic tools for embeddings. |
| core/extract_docstrings.py | Scans Python files for function/class names listed in __all__, and extracts inline comments as descriptions. Outputs CSV rows: filename, function, description. |
| core/extraction_helper.py |  |
| core/faiss_audit_explorer.py | Retrieves and filters audit logs from S3. Supports semantic search with FAISS via VectorManager. |
| core/faiss_log_reader.py | Reads and semantically queries FAISS audit logs. |
| core/faiss_log_writer.py | Writes structured audit logs to both FAISS and S3 (as JSON). |
| core/faiss_store.py | FAISS index management using BaseVectorStore. |
| core/faiss_utils.py | Shared FAISS utility functions used by store, writer, and reader. |
| core/init_context.py |  |
| core/launch_utils.py | Utilities for launching additional Streamlit apps in SageMaker via proxy port hacks. |
| core/logging_helper.py | Provides functions to write, list, and read log files stored locally. |
| core/main_embedding_helper.py | Handles vectorizer initialization and caching for Bedrock models. Supports model_key abstraction, mapped to model_id from config. |
| core/main_embedding_manager.py | EmbeddingManager wraps Bedrock embedding logic and JSON updates per model_key. |
| core/model_key_utils.py | Utilities for validating, resolving, and formatting model keys and metadata. |
| core/pgvector_embedding_vectorizer.py | Read-only embedding retriever from pgVector (for inference, testing, or comparison) |
| core/pgvector_store.py | PGVector index management fully aligned with BaseVectorStore |
| core/pgvector_structured_indexer.py | Structured indexer for pgVector with support for two-table insertion. |
| core/pgvector_utils.py | Optional utilities for pgVector backup, diagnostics, and round-trip tests. USAGE: from core.pgvector_utils import pgvector_backup_index, pgvector_check_health, pgvector_roundtrip_test |
| core/reembed_manager.py | Handles watchlist-based re-embedding operations on flagged files. |
| core/s3_utils.py | Utility functions for interacting with AWS S3 and FAISS index storage. |
| core/tuning_utils.py | Provides tuning functions for sampling thresholds, nlist, and nprobe in FAISS indexing |
| core/untitled.py |  |
| core/untitled1.py | EmbeddingManager handles multiple backends (Titan, Cohere, Claude) via unified interface. |
| core/untitled2.py | Backend classes for embedding generation via Bedrock. Includes AmazonBedrock and AmazonTitan. |
| core/vector_base.py | Base class for all vector store implementations. |
| core/vector_interface.py | Unified abstraction layer for vector store operations (defaults to pgVector) |
| core/vector_manager.py | Manager class that delegates all vector operations to the appropriate backend store. |
| core/wip_comments.csv |  |
| core/za_faiss_helper.py | General-purpose FAISS helper module for indexing, searching, and managing vectors. |
| core/zw_pgvector_embedding_vectorizer.py | PgVectorEmbeddingVectorizer simulates embedding generation using PostgreSQL-stored vectors. It resolves model dimensions from config, normalizes embeddings, and allows retrieval via SQL queries. |
| core/zw_pgvector_helper.py |  |
| core/zw_pgvector_store.py |  |
| core/zw_pgvector_structured_indexer.py | Structured indexer for pgVector that loads JSON documents from S3, extracts embeddings by model_key, and inserts normalized data into pg_vec and pg_details PostgreSQL tables. Uses config and S3-aware ingestion flow for embedding persistence. |
| core/zw_vec_mgr.py |  |
| core/zw_vector_base.py |  |
| core/zw_vector_interface.py |  |
| core/zw_vector_manager.py |  |
| core/zz_init_context.py |  |
| core/zz_s3_utils.py | Utility functions for interacting with AWS S3 and FAISS index storage. |
| demo_vector_sanity.py | Streamlit tab to upload or select a PDF, process it, generate embeddings, index into FAISS and pgVector, and compare vector retrieval accuracy side-by-side. |
| pgvector_demo.py | Main Streamlit app for uploading PDFs, indexing into pgVector, and searching using embedded content. |
| pgvector_schema.txt | Contains PGVector PostgreSQL Schema |
| requirements.txt |  |
| setup.py |  |
| tabs-clean/demo_compare_models_tab.py | Tab to compare results from different embedding models on a shared input query. Useful for side-by-side accuracy or similarity testing across model configs. |
| tabs-clean/demo_insight_query_tab.py | Streamlit tab for querying documents stored in vector databases (FAISS + pgVector) and deriving insights using semantic search and optional LLM summarization via Bedrock. |
| tabs-clean/demo_overview_tab.py | Overview dashboard for the VectorQA - Model Risk Manager Tool. Presents the 3-key focus areas (Pre-Review, Inventory, Evaluation) to stakeholders. All lower-level utilities and diagnostics are accessed from Admin sidebar. |
| tabs-clean/demo_vector_logs_tab.py | Tab for viewing, filtering, and semantically querying FAISS audit logs. Useful for model debugging, traceability, and validation. |
| tabs-clean/index_pgvector_tab.py | Streamlit tab to index JSON-embedded documents into pgVector using Bedrock embeddings |
| tabs-clean/instructions_tab.py | Streamlit tab that loads and renders a markdown-style instruction file from S3 |
| tabs-clean/search_pgvector_tab.py | Streamlit tab to search for similar documents using pgVector and embedded query vectors |
| tabs-clean/upload_embed_tab.py | Streamlit tab for uploading PDFs, extracting text, embedding content, and uploading JSON chunks to S3 |
| tabs-clean/vector_sanity_tab.py | Streamlit tab to upload or select a PDF, process it, generate embeddings, index into FAISS and pgVector, and compare vector retrieval accuracy side-by-side. |
| tabs/agent_metrics_tab.py | Tracks DSPy/LLM agent performance, scoring accuracy and traceability for QA and governance. |
| tabs/completion_stats_tab.py | Tracks review completion metrics and submission trends across model development plans. |
| tabs/demo_hub_tab.py | Launchpad hub for accessing separate demo apps or advanced features via hyperlinks or subprocess ports. |
| tabs/embedding_compare_tab.py | Compare semantic similarity results across multiple embedding models for model QA. |
| tabs/section_review_tab.py | Provides section-by-section validation and commenting workflow for Model Development Plans. |
| tabs/set_page_config_Idea.py | Admin-only tools to view index health, logs, and system diagnostics for FAISS/pgVector. |
| tabs/submit_draft_tab.py | Tab to submit draft Model Development Plans (MDPs) and upload content for automated validation. |
| tabs/topic_coverage_tab.py | Visual heatmap and statistics of MDP section coverage to detect gaps and inconsistencies. |
| test/check_vector_implementation.py |  |
| test/demo_vector_test_tab.py |  |
| test/test_pgvector_flow.py |  |
| untitled.py |  |
| vqa_proposal.py |  |
| zw_demo_vector_sanity_app.py | Streamlit tab to upload or select a PDF, process it, generate embeddings, index into FAISS and pgVector, and compare vector retrieval accuracy side-by-side. |
