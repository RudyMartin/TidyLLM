"""
[File: clean_before_export.py]
Description:
  This script prepares your project for export:
    1. Scans for incomplete files with markers (e.g. 'STILL NEEDS WORK', 'WIP')
    2. Removes .log files (outside protected folders like dev/)
    3. Purges .ipynb_checkpoints/ and __pycache__/ folders

Usage:

$ cd admin

  $ python clean_before_export.py
  $ python clean_before_export.py --no-clean-logs
  $ python clean_before_export.py --folder ./src --markers TODO FIXME
"""

import os
import sys
import shutil
import argparse

# 📍 Root scope setup
ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

# 🛡️ Protected zones (never scanned or deleted from)
SKIP_FOLDERS = {".git", "dev"}

# 👮 Controller helpers
def should_skip_folder(dirpath):
    return any(skip in dirpath.split(os.sep) for skip in SKIP_FOLDERS)

def should_skip_file(filepath):
    parts = filepath.replace("\\", "/").split("/")
    return any(part in SKIP_FOLDERS for part in parts)

def find_incomplete_files(folder, markers=None):
    if markers is None:
        markers = ["STILL NEEDS WORK", "WIP"]

    incomplete = []
    for root, _, files in os.walk(folder):
        if should_skip_folder(root):
            continue
        for f in files:
            full_path = os.path.join(root, f)

            # 🧼 Skip this script and its checkpoints
            if "clean_before_export.py" in full_path or "-checkpoint.py" in full_path:
                continue

            if f.endswith(".py") or f.endswith(".txt"):
                try:
                    with open(full_path, "r", encoding="utf-8") as fh:
                        content = fh.read().lower()
                        if any(marker.lower() in content for marker in markers):
                            incomplete.append(full_path)
                except Exception as e:
                    print(f"⚠️ Could not read {full_path}: {e}")
    return incomplete

def remove_logs(folder):
    removed_count = 0
    checkpoint_count = 0
    pycache_count = 0

    for root, dirs, files in os.walk(folder, topdown=False):
        for d in dirs:
            if d == ".ipynb_checkpoints":
                path = os.path.join(root, d)
                print(f"🗑️ Removing checkpoint folder: {path}")
                try:
                    shutil.rmtree(path)
                    checkpoint_count += 1
                except Exception as e:
                    print(f"⚠️ Could not remove {path}: {e}")
            if d == "__pycache__":
                path = os.path.join(root, d)
                print(f"🧯 Removing pycache folder: {path}")
                try:
                    shutil.rmtree(path)
                    pycache_count += 1
                except Exception as e:
                    print(f"⚠️ Could not remove {path}: {e}")

        if should_skip_folder(root):
            continue

        for f in files:
            if f.endswith(".log"):
                fp = os.path.join(root, f)
                try:
                    os.remove(fp)
                    removed_count += 1
                except Exception as e:
                    print(f"⚠️ Could not remove {fp}: {e}")

    print(f"🗑️ Removed {removed_count} .log files (outside skipped folders).")
    print(f"🧼 Removed {checkpoint_count} .ipynb_checkpoints folders.")
    print(f"🧯 Removed {pycache_count} __pycache__ folders.")
    return removed_count + checkpoint_count + pycache_count

def main():
    script_dir = os.path.abspath(os.path.dirname(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, ".."))

    parser = argparse.ArgumentParser(
        description="Scan for incomplete files and optionally remove .log files."
    )
    parser.add_argument("--folder", default=parent_dir, help="Root folder to scan.")
    parser.add_argument("--skip-folder", default="dev", help="(Legacy) Folder to skip (now centralized).")
    parser.add_argument("--no-clean-logs", action="store_true", help="Skip .log cleanup.")
    parser.add_argument("--markers", nargs="*", help="Markers to check for (default: 'STILL NEEDS WORK' and 'WIP')")
    args = parser.parse_args()

    folder = os.path.abspath(args.folder)

    # 🔍 Step 1: Scan for WIP markers
    incomplete = find_incomplete_files(folder, markers=args.markers)
    if incomplete:
        print("🚫 These files need more work:")
        for f in incomplete:
            print("   -", os.path.relpath(f, folder))
        print("\nPlease fix these issues before exporting.")
        sys.exit(1)

    # 🧹 Step 2: Clean logs, checkpoints, pycache
    if not args.no_clean_logs:
        remove_logs(folder)

if __name__ == "__main__":
    main()
