# [File: tabs/demo_overview_tab.py]
"""
Description:
    Overview dashboard for the VectorQA - Model Risk Manager Tool.
    Presents the 3-key focus areas (Pre-Review, Inventory, Evaluation) to stakeholders.
    All lower-level utilities and diagnostics are accessed from Admin sidebar.
"""

import streamlit as st


def show_demo_overview_tab():
    st.set_page_config(page_title="VectorQA Overview", layout="wide")
    st.title("🧠 VectorQA – Model Risk Manager Tool")
    st.markdown("""
    Welcome to the VectorQA system. This tool supports model risk governance workflows, document reviews,
    audit pipelines, and LLM-assisted self-evaluation.

    👉 Use the **sidebar** to navigate through functional areas:
    """)

    # --- Primary Use Cases ---
    st.header("🔍 Core Use Cases")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.subheader("📄 Model Pre-Review")
        st.markdown("""
        - Upload a Model Development Plan (MDP)
        - Automatically extract and evaluate up to 82 sections
        - Adjust compliance strictness dial
        - Leave reviewer comments per section
        - Save annotated doc to S3 for tracking
        """)

    with col2:
        st.subheader("📊 Model Inventory & QA Dashboard")
        st.markdown("""
        - Track which models have passed pre-review
        - View topic coverage and missing sections
        - Explore emerging risk themes by topic
        - Export audit reports or metrics
        """)

    with col3:
        st.subheader("🧠 LLM Pipeline Self-Evaluation")
        st.markdown("""
        - Break down subagent (DSPy) components
        - Track success metrics and accuracy trends
        - Save this tool as a model for its own governance
        - Submit VectorQA for audit using its own framework
        """)

    # --- Lower Priority Features ---
    st.header("🛠 Admin & Developer Utilities")
    st.markdown("""
    The following tools are still available via the sidebar, grouped under Admin/Diagnostics:

    - Config & Model Management
    - FAISS/pgVector Index Health
    - Audit Log Explorer
    - Chunk Viewer and Raw Text Inspector
    - Clean-up Tools and Batch Embedding
    """)

    st.info("💡 Tip: Use this screen to guide demos, presentations, or onboarding walkthroughs.")


# Entry point for this module
if __name__ == "__main__":
    show_demo_overview_tab()
