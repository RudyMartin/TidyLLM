"""
[File: search_pgvector_tab.py]
Description: Streamlit tab to search for similar documents using pgVector and embedded query vectors
"""

# --- Search Using pgVector Tab ---

import streamlit as st
from core.config_helper import get_config, get_clients
from core.embedding_helper import get_cached_vectorizer
from core.pgvector_helper import search_pgvector_index


def show_search_tab():
    st.header("🔎 Search Using pgVector")

    query = st.text_input("Enter search query")
    if query:
        config = get_config()
        clients = get_clients()
        model_key = config["default_model_option"]
        vectorizer = get_cached_vectorizer(model_key)

        embedding = vectorizer.generate_embedding(query)
        if not embedding:
            st.warning("⚠️ No embedding generated for the query.")
            return

        try:
            results = search_pgvector_index(
                query=embedding,
                config=config,
                s3_client=clients.s3,
                bucket_name=config["bucket_name"],
                index_folder=config["index_folder"]
            )
            if not results:
                st.info("No similar results found.")
                return

            st.subheader("📋 Top Matches")
            for i, item in enumerate(results):
                st.markdown(f"**{i+1}.** {item['text'][:300]}...")
        except Exception as e:
            st.error(f"❌ Search failed: {e}")
