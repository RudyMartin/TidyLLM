"""
[File: demo_insight_query.py]
Description: Streamlit tab for querying documents stored in vector databases (FAISS + pgVector)
and deriving insights using semantic search and optional LLM summarization via Bedrock.
"""

import streamlit as st
from core.init_context import get_tab_context
from core.s3_utils import list_objects_s3, load_json_from_s3
from core.faiss_helper import search_faiss_index
from core.pgvector_helper import search_pgvector_index
from core.llm_bedrock import summarize_text_blocks  # Assume this wraps Bedrock Titan or Claude


def show_insight_query_tab():
    st.header("📘 Document Insight Query")

    model_key = st.selectbox("Select model for embedding", ["titan_v2", "titan_v1"])
    ctx = get_tab_context(model_key=model_key)

    zNAME = st.text_input("Enter your user ID", value="user_2025")
    user_prefix = f"dev/pdf2/{zNAME}/json"

    json_files = list_objects_s3(ctx.bucket_name, user_prefix, extension=".json")
    selected_file = st.selectbox("Select a JSON file to query", json_files)

    query = st.text_input("Ask a question about this document")
    top_k = st.slider("Top chunks to retrieve", 1, 10, 3)
    run_faiss = st.checkbox("Search FAISS", value=True)
    run_pgvector = st.checkbox("Search pgVector", value=True)
    summarize = st.checkbox("Summarize using LLM", value=True)

    if st.button("🔍 Run Insight Query") and query:
        embedding = ctx.vectorizer.generate_embedding(query)
        results = []

        if run_faiss:
            try:
                faiss_results = search_faiss_index(
                    query=embedding,
                    config=ctx.config,
                    s3_client=ctx.s3,
                    bucket_name=ctx.bucket_name,
                    index_folder=ctx.config["index_folder"],
                    model_key=model_key,
                    top_k=top_k
                )
                results.extend(faiss_results)
            except Exception as e:
                st.error(f"FAISS error: {e}")

        if run_pgvector:
            try:
                pgvector_results = search_pgvector_index(
                    query=embedding,
                    config=ctx.config,
                    s3_client=ctx.s3,
                    bucket_name=ctx.bucket_name,
                    index_folder=ctx.config["index_folder"],
                    top_k=top_k
                )
                results.extend(pgvector_results)
            except Exception as e:
                st.error(f"pgVector error: {e}")

        if results:
            st.subheader("📋 Retrieved Chunks")
            for i, chunk in enumerate(results[:top_k]):
                st.markdown(f"**Chunk {i+1}:** {chunk['text'][:500]}...")

            if summarize:
                try:
                    summary = summarize_text_blocks([r["text"] for r in results[:top_k]], query)
                    st.subheader("🧠 LLM Insight Summary")
                    st.markdown(summary)
                except Exception as e:
                    st.error(f"LLM summarization failed: {e}")
        else:
            st.info("No relevant results found.")
