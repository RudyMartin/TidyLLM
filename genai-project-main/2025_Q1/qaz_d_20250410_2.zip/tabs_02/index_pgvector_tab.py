"""
[File: index_pgvector_tab.py]
Description: Streamlit tab to index JSON-embedded documents into pgVector using Bedrock embeddings
"""

# --- Index to pgVector Tab ---

import streamlit as st
from core.config_helper import get_config, get_clients
from core.pgvector_helper import create_pgvector_index


def show_index_tab():
    st.header("🏢 Index JSON Files into pgVector")

    config = get_config()
    clients = get_clients()
    bucket = config["bucket_name"]
    json_folder = config["json_folder"]

    if st.button("🚀 Start Indexing JSON to pgVector"):
        try:
            index_name = create_pgvector_index(clients.s3, config, bucket, json_folder)
            st.success(f"✅ Indexed embeddings into pgVector. Index saved as: {index_name}")
        except Exception as e:
            st.error(f"❌ Failed to index: {e}")
