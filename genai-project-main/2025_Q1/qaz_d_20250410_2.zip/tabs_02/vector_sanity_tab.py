# [File: vector_sanity_tab.py]
"""
Description:
  Streamlit tab to upload or select a PDF, process it, generate embeddings,
  index into FAISS and pgVector, and compare vector retrieval accuracy side-by-side.

Updated: Uses vector_manager abstraction instead of old store-specific helpers.
"""

import streamlit as st
import uuid
import json

from core.vector_manager import VectorManager
from core.embedding_helper import get_cached_vectorizer
from core.s3_utils import list_objects_s3, load_json_from_s3, upload_to_s3
from core.extraction_helper import split_pdf_into_pages_s3, extract_text_to_json

# --- Entry point for Streamlit tab ---
def show_vector_sanity_tab():
    st.header("🧪 Vector Sanity Check Demo")

    # Lazy load to avoid circular dependency
    from core.init_context import get_tab_context
    clients, config, _, _ = get_tab_context()
    bucket = config["bucket_name"]

    # Input controls
    zNAME = st.text_input("Enter your user ID", value="user_2025")
    user_prefix = f"users/{zNAME}"
    model_key = st.selectbox("Choose embedding model", config["model_order"])
    mode = st.radio("Choose file source", ["Use existing S3 JSON", "Upload and process new PDF", "Upload PDF Only"])

    # --- Upload + Full Extraction Mode ---
    if mode == "Upload and process new PDF":
        uploaded_file = st.file_uploader("Upload a PDF", type="pdf")
        if uploaded_file and st.button("📄 Process PDF and Run Sanity Check"):
            raw_key = f"{user_prefix}/raw_pdfs/{uuid.uuid4().hex}.pdf"
            upload_to_s3(clients["s3"], bucket, raw_key, uploaded_file.read())
            split_pdf_into_pages_s3(raw_key, config=config, s3_client=clients["s3"])
            extract_text_to_json(config=config, s3_client=clients["s3"])
            st.success("✅ PDF processed into chunks. Now rerun from S3 mode after JSON is available.")

    # --- Use Pre-Processed JSON for Query ---
    elif mode == "Use existing S3 JSON":
        json_folder = f"{user_prefix}/json"
        json_files = list_objects_s3(bucket, json_folder, extension=".json")
        selected_file = st.selectbox("Select a JSON file", json_files)

        if st.button("🚀 Run Sanity Check"):
            data = load_json_from_s3(bucket, selected_file, config=config)
            chunks = data.get("chunks", [])
            st.write(f"Using {len(chunks)} chunks from: {selected_file}")

            # Get embedding for sample query text
            vectorizer = get_cached_vectorizer(config)
            sample_text = chunks[0]["text"] if chunks else ""
            query_embedding = vectorizer.generate_embedding(sample_text)

            col1, col2 = st.columns(2)

            # --- FAISS Results ---
            with col1:
                st.subheader("🔍 FAISS Results")
                try:
                    faiss_manager = VectorManager("faiss", config=config, clients=clients)
                    results = faiss_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**FAISS Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"FAISS query failed: {e}")

            # --- pgVector Results ---
            with col2:
                st.subheader("🧬 pgVector Results")
                try:
                    pg_manager = VectorManager("pgvector", config=config, clients=clients)
                    results = pg_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**pgVector Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"pgVector query failed: {e}")

    # --- Upload-Only Mode (No Extraction) ---
    elif mode == "Upload PDF Only":
        uploaded_file = st.file_uploader("Upload a PDF", type="pdf")
        if uploaded_file and st.button("📤 Upload PDF to S3 Only"):
            raw_key = f"{user_prefix}/raw_pdfs/{uuid.uuid4().hex}.pdf"
            upload_to_s3(clients["s3"], bucket, raw_key, uploaded_file.read())
            st.success(f"✅ PDF uploaded to: `{raw_key}`")

# Required tab entry point
show_vector_sanity_tab()
