# [File: tabs/demo_vector_logs_tab.py]
"""
Description:
  Tab for viewing, filtering, and semantically querying FAISS audit logs.
  Useful for model debugging, traceability, and validation.

Usage:
  Appears in sidebar navigation of main_vector_app.py
"""

import streamlit as st
from datetime import datetime
from core.faiss_audit_explorer import (
    load_all_logs_from_s3,
    semantic_search_logs_s3,
    filter_logs_by_signature,
    format_log_result
)
from core.init_context import get_tab_context

# --- Entry point ---
def show_vector_logs_tab():
    st.header("📜 Vector Log Explorer")

    clients, config, _, _ = get_tab_context()
    log_prefix = config.get("log_directory", "dev/logs")
    model_key = st.selectbox("Choose model for search:", config["model_order"])

    st.markdown("---")
    st.subheader("🔍 Semantic Search")
    query = st.text_input("Enter query for semantic search")
    top_k = st.slider("Top K Matches", min_value=1, max_value=10, value=5)
    if st.button("🔍 Search Logs"):
        with st.spinner("Searching logs semantically..."):
            results = semantic_search_logs_s3(query, model_key, log_prefix, top_k=top_k)
            if not results:
                st.warning("No matching logs found.")
            for r in results:
                st.markdown(format_log_result(r))

    st.markdown("---")
    st.subheader("📂 Browse All Logs")
    if st.checkbox("Show full log entries from S3"):
        logs = load_all_logs_from_s3(log_prefix)
        st.markdown(f"Loaded `{len(logs)}` total log entries from `{log_prefix}`")

        with st.expander("Preview Top 10 Logs"):
            for log in logs[:10]:
                st.code(log.get("text", "<no text>"))
                st.caption(log.get("timestamp", "<no timestamp>") + " • " + log.get("signature", "<no signature>"))

    st.markdown("---")
    st.subheader("🔎 Filter Options (Coming Soon)")
    st.text_input("Signature Filter (exact)", placeholder="Paste a full hash")
    st.text_input("Metadata Key", placeholder="e.g., source")
    st.text_input("Metadata Value", placeholder="e.g., file1.pdf")
    st.button("Apply Filters")

    st.markdown("---")
    st.subheader("📈 Export & Reports")
    st.download_button("📥 Download Results as CSV", data="Simulated, will export real logs soon", file_name="vector_logs.csv")

    # --- Design Documentation Footer ---
    st.markdown("---")
    st.markdown("### 📌 Goals")
    st.markdown("""
    - Allow search and browsing of audit logs stored in S3
    - Provide semantic matching for traceability and model validation
    - Serve as foundation for model governance and explainability UI
    """)

    st.markdown("### 📌 Current Status")
    st.markdown("""
    - Semantic search functional ✅
    - Log preview functional ✅
    - Filter UI placeholders added ⚠️
    - CSV export placeholder in place ⚠️
    """)

    st.markdown("### 📌 TODO / Future Features")
    st.markdown("""
    - Add filtering by date, signature, metadata fields
    - Integrate CSV + PDF export from search results
    - Add interactive log inspection and QA overlay
    - Option to label / flag logs manually
    """)
