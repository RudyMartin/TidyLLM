# [File: tabs/demo_compare_models_tab.py]
"""
Description:
  Tab to compare results from different embedding models on a shared input query.
  Useful for side-by-side accuracy or similarity testing across model configs.

Usage:
  Imported and launched from main_vector_app.py
"""

import streamlit as st
from core.init_context import get_tab_context
from core.embedding_helper import get_cached_vectorizer
from core.vector_manager import VectorManager

# --- Entry point ---
def show_compare_models_tab():
    st.header("📊 Compare Embedding Models")

    # Get context
    clients, config, _, _ = get_tab_context()
    model_options = config["model_order"]

    # --- Input Form ---
    st.subheader("🔍 Query Input")
    with st.form(key="model_compare_form"):
        test_query = st.text_area("Enter a query or sentence:", "What is the purpose of a risk model?")
        top_k = st.slider("Top K Matches", 1, 10, 3)
        submitted = st.form_submit_button("Run Model Comparison")

    # --- Comparison Results ---
    if submitted and test_query.strip():
        st.markdown("---")
        for model_key in model_options:
            st.subheader(f"🔬 Model: `{model_key}`")
            try:
                vectorizer = get_cached_vectorizer(config)
                embedding = vectorizer.generate_embedding(test_query, model_key=model_key)
                vm = VectorManager(config=config, clients=clients, store_type="pgvector")
                results = vm.query(embedding, top_k=top_k)

                if results:
                    for idx, (match_id, score) in enumerate(results):
                        st.markdown(f"{idx+1}. Match ID: `{match_id}` — Score: `{score:.4f}`")
                else:
                    st.info("No results returned for this model.")

            except Exception as e:
                st.error(f"❌ Failed for model `{model_key}`: {e}")

    elif submitted:
        st.warning("⚠️ Please enter a non-empty query.")

    # --- Design Documentation Footer ---
    st.markdown("---")
    st.markdown("### 📌 Goals")
    st.markdown("""
    - Allow side-by-side performance comparison across multiple embedding models
    - Support benchmarking and tuning by topic or query type
    - Provide intuitive top-K matching output
    """)

    st.markdown("### 📌 Current Status")
    st.markdown("""
    - Query input and form UI working ✅
    - Semantic retrieval using VectorManager ✅
    - Per-model output loop operational ✅
    """)

    st.markdown("### 📌 TODO / Future Features")
    st.markdown("""
    - Display top-K matched text from vector DB
    - Add FAISS vs pgVector toggle
    - Show average score + distance metrics across models
    - Visualize embeddings using PCA or UMAP
    - Integrate with labeling tab for per-model QA
    """)
