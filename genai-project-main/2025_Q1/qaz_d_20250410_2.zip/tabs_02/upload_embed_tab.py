"""
[File: upload_embed_tab.py]
Description: Streamlit tab for uploading PDFs, extracting text, embedding content, and uploading JSON chunks to S3
"""

# --- Upload & Embed Tab ---

import streamlit as st
import fitz  # PyMuPDF
import json
import uuid
from core.embedding_helper import get_cached_vectorizer
from core.s3_utils import upload_json_to_s3
from core.config_helper import get_config, get_clients
from datetime import datetime


def chunk_text(text, chunk_size=500):
    words = text.split()
    return [" ".join(words[i:i+chunk_size]) for i in range(0, len(words), chunk_size)]


def extract_text_from_pdf(uploaded_file):
    doc = fitz.open(stream=uploaded_file.read(), filetype="pdf")
    page_texts = [page.get_text() for page in doc]
    return "\n".join(page_texts)


def show_upload_tab():
    st.header("📄 Upload PDF & Generate Embeddings")

    uploaded_file = st.file_uploader("Choose a PDF file", type="pdf")
    if uploaded_file:
        raw_text = extract_text_from_pdf(uploaded_file)
        st.success("Text extracted. Chunking and embedding now...")

        chunks = chunk_text(raw_text)
        config = get_config()
        clients = get_clients()
        model_key = config["default_model_option"]
        vectorizer = get_cached_vectorizer(model_key)

        chunk_jsons = []
        for i, chunk in enumerate(chunks):
            embedding = vectorizer.generate_embedding(chunk)
            record = {
                "id": str(uuid.uuid4()),
                "chunk": chunk,
                "embedding": embedding,
                "metadata": {
                    "source_file": uploaded_file.name,
                    "chunk_index": i,
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
            chunk_jsons.append(record)

        # Upload to S3
        bucket = config["bucket_name"]
        prefix = config["json_folder"]
        for record in chunk_jsons:
            filename = f"{record['id']}.json"
            upload_json_to_s3(clients.s3, bucket, prefix, filename, record)

        st.success(f"✅ Uploaded {len(chunk_jsons)} chunks to S3")
