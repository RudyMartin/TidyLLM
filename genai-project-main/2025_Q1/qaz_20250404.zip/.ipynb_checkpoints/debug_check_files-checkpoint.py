import boto3

bucket = "sagemaker-us-east-1-188494237500"
prefix = "dev/pdf/arxiv_wellsfargo/"

s3 = boto3.client("s3")

response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
pdfs = [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(".pdf")]

print(f"{len(pdfs)} PDF(s) found.")
for pdf in pdfs[:10]:
    print(" -", pdf)

