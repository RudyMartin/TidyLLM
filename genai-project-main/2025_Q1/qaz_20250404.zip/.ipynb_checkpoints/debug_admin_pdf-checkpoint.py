"""
debug_admin_pdf.py

CLI tool to inspect, clean, and reprocess JSON files extracted from PDFs.
Adds split and extract functions to match Streamlit tab behavior.

Usage:
    python debug_admin_pdf.py --list
    python debug_admin_pdf.py --inspect FILE_NAME
    python debug_admin_pdf.py --fix FILE_NAME
    python debug_admin_pdf.py --fix-all
    python debug_admin_pdf.py --split-pdfs
    python debug_admin_pdf.py --extract-json
    python debug_admin_pdf.py --batch-all
"""

import os
import json
import argparse
from datetime import datetime

from core.config_helper import initialize_config_cli, get_config_cli
from core.s3_utils import list_objects_s3, load_json_from_s3, save_json_to_s3
from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    prepare_pdf_splits,
    extract_text_to_json,
)

# ✅ Initialize CLI context
initialize_config_cli()

# ✅ Get client bundle with config + S3
clients = get_client_bundle()
config = clients.config
s3 = clients.s3

BUCKET = config["bucket_name"]
PREFIX = config["json_folder"]

def list_all_json_files():
    keys = list_objects_s3(BUCKET, PREFIX, extension=".json")
    for key in keys:
        print("-", key)

def inspect_file(key):
    try:
        data = load_json_from_s3(BUCKET, key)
        print(f"\n📄 File: {key}")
        print(f"  Metadata: {data.get('metadata', {})}")
        print(f"  Chunks: {len(data.get('chunks', []))}")
        print(f"  Embeddings: {list(data.get('embeddings', {}).keys())}")
    except Exception as e:
        print(f"❌ Error reading {key}: {e}")

def fix_file(key):
    try:
        data = load_json_from_s3(BUCKET, key)
        modified = False

        data.setdefault("metadata", {})
        data.setdefault("chunks", [])
        data.setdefault("embeddings", {})

        cleaned_embeddings = {
            k: v for k, v in data["embeddings"].items()
            if isinstance(v, dict) and "vector" in v and isinstance(v["vector"], list)
        }
        data["embeddings"] = cleaned_embeddings

        if "page_number" in data.get("metadata", {}):
            try:
                data["metadata"]["page_number"] = int(data["metadata"]["page_number"])
            except:
                pass

        data["metadata"]["cleaned_date"] = datetime.utcnow().isoformat() + "Z"
        save_json_to_s3(BUCKET, key, data)
        print(f"✅ Fixed and saved {key}")
    except Exception as e:
        print(f"❌ Failed to fix {key}: {e}")

def fix_all():
    keys = list_objects_s3(BUCKET, PREFIX, extension=".json")
    for key in keys:
        fix_file(key)

def split_pdfs():
    print("⚙️ Splitting PDFs into individual pages...")
    count = prepare_pdf_splits()
    print(f"✅ Split {count} PDF(s) into pages.")

def extract_json():
    print("📄 Extracting text and saving JSON files...")
    count = prepare_pdf_splits()
    print(f"✅ Extracted and saved JSON from {count} page(s).")

def batch_all():
    print("⏳ Running full batch: Split PDFs -> Extract Text to JSON")
    split_pdfs()
    extract_json()
    print("🚀 Batch process completed.")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--list", action="store_true", help="List all JSON files in S3")
    parser.add_argument("--inspect", type=str, help="Inspect a specific JSON file by key")
    parser.add_argument("--fix", type=str, help="Fix a specific JSON file by key")
    parser.add_argument("--fix-all", action="store_true", help="Fix all JSON files")
    parser.add_argument("--split-pdfs", action="store_true", help="Split PDFs into pages")
    parser.add_argument("--extract-json", action="store_true", help="Extract text and save JSON")
    parser.add_argument("--batch-all", action="store_true", help="Split + Extract all")

    args = parser.parse_args()

    if args.list:
        list_all_json_files()
    elif args.inspect:
        inspect_file(args.inspect)
    elif args.fix:
        fix_file(args.fix)
    elif args.fix_all:
        fix_all()
    elif args.split_pdfs:
        split_pdfs()
    elif args.extract_json:
        extract_json()
    elif args.batch_all:
        batch_all()
    else:
        parser.print_help()
