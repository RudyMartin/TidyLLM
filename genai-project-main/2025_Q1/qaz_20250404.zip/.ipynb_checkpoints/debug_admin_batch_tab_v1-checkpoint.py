# debug_admin_batch_tab.py
"""
A simple debug script to test the steps from the admin_batch_tab.
It simulates the key actions (context retrieval, embedding, indexing, and status check)
by printing out the steps along the way.
"""

import streamlit as st

# Patch session_state for non-Streamlit-run environments
if not isinstance(st.session_state, dict):
    st.session_state = {}

print("Patched st.session_state to a plain dict.")
###########

import os
import json
import streamlit as st

def initialize_config():
    """
    Loads configuration from config/config.json and sets it in st.session_state under 'CONFIG'.
    This function should be called at the start of your script to prevent KeyErrors when accessing
    st.session_state['CONFIG'] in non-Streamlit-run contexts.
    """
    config_path = os.path.join(os.path.dirname(__file__), "config", "config.json")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        # Patch session_state if CONFIG key doesn't exist.
        if "CONFIG" not in st.session_state:
            st.session_state["CONFIG"] = config
            print("CONFIG initialized in session_state.")
        else:
            print("CONFIG already exists in session_state.")
    except Exception as e:
        print(f"Failed to load configuration: {e}")

# Initialize the configuration before any other imports that might use it.
initialize_config()

# # --- Standard Library Imports ---
# import logging
# #import streamlit as st
# from datetime import datetime

# # --- Project-level Imports ---
# #used  to unpack full context NEEDED!!
# from core.init_context import get_tab_context

# from core.extraction_helper import (
#     extract_text_from_pdf,
#     save_extracted_text_to_json,
#     prepare_pdf_splits,
#     extract_text_to_json,
# )
# from core.s3_utils import (
#     list_pdf_files_s3,
#     list_json_files_s3,
#     list_s3_files_with_extension
# )

# # --- Logging Settings ---
# logger = logging.getLogger(__name__)
# logger.setLevel(logging.INFO)


#####################
import logging
from datetime import datetime

# Ensure your project’s modules are in the PYTHONPATH before running this script
try:
    from core.init_context import get_tab_context
except ImportError:
    print("Error: Could not import get_tab_context. Ensure your PYTHONPATH is set correctly.")
    exit(1)


def debug_tab_functions():
    print("\n=== Debugging Admin Batch Tab Functions ===")
    print(f"Step 1: {datetime.now()} - Retrieving tab context...")
    try:
        # Retrieve the necessary context (clients, config, vectorizer, and manager)
        clients, config, vectorizer, manager = get_tab_context()
        print("  -> Successfully retrieved tab context.")
    except Exception as e:
        print(f"  -> Failed to retrieve tab context: {e}")
        return

    print("\nStep 2: Listing available model options...")
    try:
        model_options = list(config["model_options"].keys())
        print(f"  -> Available models: {model_options}")
    except Exception as e:
        print(f"  -> Error retrieving model options: {e}")
        return

    # For debugging purposes, simulate selecting all models
    selected_models = model_options
    print(f"\nStep 3: Selected models for processing: {selected_models}")

    print("\nStep 4: Running embedding process (validate_and_embed_missing)...")
    try:
        manager.validate_and_embed_missing(selected_models, vectorizer)
        print("  -> Embedding process completed successfully.")
    except Exception as e:
        print(f"  -> Embedding process failed: {e}")

    print("\nStep 5: Running indexing process (index_batch)...")
    try:
        manager.index_batch(selected_models)
        print("  -> Indexing process completed successfully.")
    except Exception as e:
        print(f"  -> Indexing process failed: {e}")

    print("\nStep 6: Retrieving FAISS index status...")
    try:
        status_list = manager.get_index_status()
        print("  -> Retrieved index status:")
        for entry in status_list:
            print(f"     - Model: {entry.get('Model', 'N/A')}, Vectors: {entry.get('Vectors', 'N/A')}, "
                  f"Last Modified: {entry.get('LastModified', 'N/A')}")
    except Exception as e:
        print(f"  -> Failed to retrieve index status: {e}")

    print("\n=== Debugging Completed ===\n")


if __name__ == "__main__":
    debug_tab_functions()
