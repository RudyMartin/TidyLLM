# debug_admin_batch_tab_v3.py
"""
CLI debug script to simulate admin_batch_tab actions.
Steps: context load, model listing, embedding, indexing.

Usage:
  python debug_admin_batch_tab_v3.py --all
  python debug_admin_batch_tab_v3.py --embed-only
  python debug_admin_batch_tab_v3.py --index-only
  python debug_admin_batch_tab_v3.py --force-embed
"""

import os
import json
import argparse
from datetime import datetime

# Patch Streamlit session state for CLI compatibility
import streamlit as st
if not isinstance(st.session_state, dict):
    st.session_state = {}
print("Patched st.session_state to a plain dict.")

# Load config manually (for CLI runs)
def initialize_config():
    config_path = os.path.join(os.path.dirname(__file__), "config", "config.json")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        if "CONFIG" not in st.session_state:
            st.session_state["CONFIG"] = config
            print("CONFIG initialized in session_state.")
        else:
            print("CONFIG already exists in session_state.")
    except Exception as e:
        print(f"Failed to load configuration: {e}")

initialize_config()

# Main logic
import logging
from core.init_context import get_tab_context

def run_embedding(manager, vectorizer, selected_models, force=False):
    print("\n🔁 Running embedding process (validate_and_embed_missing)...")
    try:
        manager.validate_and_embed_missing(selected_models, vectorizer, force=force)
        print("✅ Embedding completed.")
    except Exception as e:
        print(f"❌ Embedding failed: {e}")

def run_indexing(manager, selected_models):
    print("\n📇 Running indexing process (index_batch)...")
    try:
        manager.index_batch(selected_models)
        print("✅ Indexing completed.")
    except Exception as e:
        print(f"❌ Indexing failed: {e}")

def debug_tab_functions(embed=True, index=True, force=False):
    print("\n=== Debugging Admin Batch Tab Functions ===")
    print(f"Step 1: {datetime.now()} - Retrieving tab context...")
    try:
        clients, config, vectorizer, manager = get_tab_context()
        print("  -> Successfully retrieved tab context.")
    except Exception as e:
        print(f"  -> Failed to retrieve tab context: {e}")
        return

    print("\nStep 2: Listing available model options...")
    try:
        model_options = list(config["model_options"].keys())
        print(f"  -> Available models: {model_options}")
    except Exception as e:
        print(f"  -> Error retrieving model options: {e}")
        return

    selected_models = model_options
    print(f"\nStep 3: Selected models for processing: {selected_models}")

    if embed:
        run_embedding(manager, vectorizer, selected_models, force=force)
    if index:
        run_indexing(manager, selected_models)

    print("\n=== Debugging Completed ===\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Admin Batch Tab CLI Debug Tool")
    parser.add_argument("--all", action="store_true", help="Run both embedding and indexing")
    parser.add_argument("--embed-only", action="store_true", help="Run only the embedding process")
    parser.add_argument("--index-only", action="store_true", help="Run only the indexing process")
    parser.add_argument("--force-embed", action="store_true", help="Force re-embedding even if embeddings exist")
    args = parser.parse_args()

    force = args.force_embed

    if args.embed_only:
        debug_tab_functions(embed=True, index=False, force=force)
    elif args.index_only:
        debug_tab_functions(embed=False, index=True, force=force)
    else:
        debug_tab_functions(embed=True, index=True, force=force)
