"""
[File: pdf_tab.py]
Description: Provides the UI for PDF processing: splitting PDFs, extracting text,
and converting pages to JSON format.
  
TODO:
  - Enhance PDF processing logic with progress indicators and robust error handling.
  - Implement update/delete functionality if PDFs change.
  
FUTURE:
  - Integrate OCR for scanned PDFs and support multilingual extraction.
  - Develop a full CRUD interface for managing extracted document metadata and versioning.
"""

import streamlit as st

from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    extract_text_from_pdf,
    save_extracted_text_to_json,
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import list_pdf_files_s3, list_json_files_s3, list_objects_s3
from core.config_helper import get_config

def render():
    st.header("📁 PDF File Inventory")

    # Get config and client
    clients = get_client_bundle()
    config = clients.config
    s3_client = clients.s3
    st.write("✅ S3 Client Active:", s3_client is not None)


   # 🧭 Pull folder paths from config
    try:
        bucket_name = config["bucket_name"]
        page_folder = config["page_folder"]
        json_folder = config["json_folder"]
        pdf_folder = config["pdf_folder"]    
        pdf_subfolder = config.get("pdf_subfolder", "")  # use .get() to avoid KeyError
        pdf_path = f"{pdf_folder}/{pdf_subfolder}".strip("/")
    except KeyError as e:
        st.error(f"❌ Missing key in config: {e}")
        return

    st.markdown(f"📂 Checking: `s3://{bucket_name}/{pdf_path}/`")

    if "pdf_files" not in st.session_state:
        # Load default inventory
        st.session_state.pdf_files = list_pdf_files_s3(bucket_name, pdf_path)
    
    if st.button("🔍 List All PDFs in S3 Folder"):
        try:
            #pdf_files = list_objects_s3(bucket=bucket_name, prefix=pdf_path, extension=".pdf")
            pdf_files = list_pdf_files_s3(bucket=bucket_name, prefix=pdf_path)
            num_pdfs = len(pdf_files)

            st.success(f"✅ Found {num_pdfs} PDF(s) in `{pdf_path}`")
            for pdf_path in pdf_files:
                st.markdown(f"- `{pdf_path}`")
        except Exception as e:
            st.error(f"❌ Failed to list PDFs: {e}")
    
    # Minor buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("\u26A1 Batch Process (Split + Extract)", type="primary"):
            try:
                with st.spinner("Splitting PDFs into pages..."):
                    num_pdfs_processed = prepare_pdf_splits()

                with st.spinner("Extracting text and creating JSON files..."):
                    num_pages_processed = extract_text_to_json()

                st.success(
                    f"\u26A1 Batch completed successfully: "
                    f"{num_pdfs_processed} PDFs split, "
                    f"{num_pages_processed} PDF pages extracted and chunked into JSON."
                )
            except Exception as e:
                st.error(f"\u274C Batch extraction failed: {e}")

        if st.button("\U0001F4C4 1. Split PDFs into Pages", type="secondary"):
            try:
                num_processed = prepare_pdf_splits()
                st.success(f"\u2705 Successfully split {num_processed} PDFs into pages.")
            except Exception as e:
                st.error(f"\u274C Error splitting PDFs: {e}")

        if st.button("\U0001F9E0 2. Extract Content into JSON", type="secondary"):
            try:
                num_processed_pages = extract_text_to_json()
                st.success(f"\u2705 Successfully processed text from {num_processed_pages} PDF pages.")
            except Exception as e:
                st.error(f"\u274C Error extracting text: {e}")

    with col2:
        # if st.button("\U0001F50D List Full PDFs Files", type="secondary"):
        #     pdf_files = list_pdf_files_s3(bucket_name, pdf_folder)
        #     num_pdfs = len(pdf_files)
        #     st.info(f"\U0001F50E {num_pdfs} PDF(s) found in `{pdf_folder}`.")
        #     if num_pdfs > 0:
        #         st.write(pdf_files)

        config = get_config()
        bucket_name = config["bucket_name"]
        pdf_folder = f"{config['pdf_folder']}/{config['pdf_subfolder']}"
    
        if st.button("\U0001F50D List Full PDF Files", type="secondary"):
            pdf_files = list_pdf_files_s3(bucket_name, pdf_folder)
            num_pdfs = len(pdf_files)
    
            st.info(f"\U0001F4C4 {num_pdfs} PDF(s) found in `{pdf_folder}`")
    
            if num_pdfs > 0:
                for path in pdf_files:
                    st.markdown(f"• `{path}`")                

        if st.button("\U0001F4C2 List Split Pages", type="secondary"):
            pages = list_pdf_files_s3(bucket_name, page_folder)
            num_pages = len(pages)
            st.info(f"\U0001F4C2 {num_pages} PDF page(s) found in `{page_folder}`.")
            if num_pages > 0:
                st.write(pages)

        if st.button("\U0001F4D1 List JSON Content", type="secondary"):
            json_files = list_json_files_s3(bucket_name, json_folder)
            num_json_files = len(json_files)
            st.info(f"\U0001F4D1 {num_json_files} JSON file(s) found in `{json_folder}`.")
            if num_json_files > 0:
                st.write(json_files)


if __name__ == "__main__":
    render()
