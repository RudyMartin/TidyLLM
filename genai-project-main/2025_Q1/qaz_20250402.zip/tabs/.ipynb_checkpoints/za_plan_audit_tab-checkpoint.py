'''
[File: plan_audit_tab.py]
Version: DSPy 2.5.26 - Streamlit Plan Audit Tab (Updated with DSPy Truth Validation)

Description:
This tab allows users to upload a Model Development Plan (PDF, DOCX, or JSON),
run DSPy reasoning over it, and compare its extracted sections against stored
truth records from FAISS. Each section (e.g., Testing, Maintenance) is scored
for similarity and gaps.
'''

import os
import json
import streamlit as st
from core.logging_helper import get_logger
from dspy_signature_uploader import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_text_from_json,
    generate_signature_and_reasoning
)
from core.vector_manager import VectorManager
from core.text_utils import extract_sections, clean_text
from core.dspy_utils import audit_section_with_truth

logger = get_logger("plan_audit_tab")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
SECTIONS = [
    "Purpose and Scope", "Project Overview", "Stakeholders", "Timeline and Milestones",
    "Analysis and Requirements", "Design", "Implementation and Integration",
    "Testing", "Maintenance", "Risk Management"
]


def render():
    st.header("📋 Plan Audit - Model Development Validator")
    st.markdown("Upload your Model Development Plan to audit key sections against stored truths.")

    uploaded_file = st.file_uploader("Upload Document (PDF, DOCX, or JSON):", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()
        if ext == "pdf":
            text = extract_text_from_pdf(uploaded_file)
        elif ext == "docx":
            text = extract_text_from_docx(uploaded_file)
        elif ext == "json":
            text = extract_text_from_json(uploaded_file)
        else:
            st.error("Unsupported file type")
            return

        if not text:
            st.warning("No text found in document.")
            return

        st.text_area("📄 Extracted Text", text[:2000], height=200)
        st.markdown("---")
        st.subheader("🧠 DSPy Reasoning")
        reasoning_result = generate_signature_and_reasoning(text)
        st.code(reasoning_result.get("signature"), language="text")
        st.text_area("AI Reasoning", reasoning_result.get("reasoning", ""), height=200)

        st.markdown("---")
        st.subheader("✅ Section-by-Section Truth Audit")

        try:
            sections = extract_sections(text)
            vector_manager = VectorManager(store_type="faiss")
            model_key = vector_manager.config["embedding_model"]

            for section_title, section_content in sections.items():
                cleaned = clean_text(section_content)
                audit = audit_section_with_truth(cleaned, section_title, vector_manager, model_key)
                st.markdown(f"#### 📌 {section_title}")
                st.text_area("Section Text", cleaned[:1000], height=150)
                st.text_area("Closest Truth Match", audit["closest_match"], height=150)
                st.progress(audit["similarity"], text=f"Similarity Score: {round(audit['similarity'] * 100)}%")
        except Exception as e:
            st.error(f"Section audit failed: {e}")


if __name__ == "__main__":
    render()