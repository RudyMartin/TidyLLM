"""
[File: logs_tab.py]
Description: Provides a UI for viewing local log files.
Enables users to generate a test log, select a log file, and view its contents.

TODO:
  - Improve file selection, error handling, and display formatting.
  
FUTURE:
  - Integrate with centralized logging and add search/filter capabilities.
"""

import streamlit as st
import json
import os

from core.logging_helper import write_log, list_log_files, read_log_file

def render():
    st.header("\U0001F4C8 Logs & Analytics Viewer")

    # if st.button("🏠 Back to Home"):
    #     st.session_state["admin_tool"] = "None"
    #     st.experimental_rerun()

    if st.button("\U0001F4DD Generate Test Log"):
        log_path = write_log("Test log entry from Streamlit.", log_type="info")
        st.success(f"Test log written: {log_path}")
        st.rerun()

    log_files = list_log_files()
    if not log_files:
        st.info("No log files found.")
        return

    selected_log = st.selectbox("Select log file to view:", sorted(log_files, reverse=True))
    if selected_log:
        try:
            if selected_log.endswith(".json"):
                log_content = read_log_file(selected_log)
                st.json(log_content)
            else:
                with open(selected_log, "r") as f:
                    raw_content = f.read()
                st.text_area("Log Content", value=raw_content, height=400)
        except Exception as e:
            st.error(f"Error loading log: {e}")


if __name__ == "__main__":
    render()

