"""
[File: tabs/faiss_diagnostics_tab.py]
Description: Provides diagnostics UI for FAISS index and JSON embedding validation.
"""

import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
from collections import defaultdict

from core.init_context import get_tab_context
from core.logging_helper import summarize_errors


def show_faiss_diagnostics():
    st.title("\U0001F6E0 FAISS Diagnostics Tool")
    st.markdown("This tool validates JSON embeddings and optionally builds FAISS indexes.")

    clients, config, vectorizer, manager = get_tab_context()
    index_tool = manager.index_store

    # --- Sidebar Controls ---
    run_json_check = st.sidebar.checkbox("Run JSON Validation", value=True)
    run_faiss_build = st.sidebar.checkbox("Build FAISS Index", value=True)
    selected_models = st.sidebar.multiselect(
        "Select Models to Test",
        options=list(config["model_options"].keys()),
        default=list(config["model_options"].keys())
    )

    # --- Run Button ---
    if st.button("\U0001F680 Run Diagnostic"):
        results = []
        collected_errors = []
        progress = st.progress(0)
        total = len(selected_models)

        for i, model_key in enumerate(selected_models):
            model_info = config["model_options"][model_key]
            dim = model_info["dimensions"]
            full_model_key = f"{model_info['id']}_{dim}"

            valid_vectors, errors = [], []

            # Step 1: Validate JSON embeddings
            if run_json_check:
                valid_vectors, errors = index_tool.validate_json_embeddings(
                    model_key,
                    log_to_repair_list=True
                )
                collected_errors.extend(errors)

            # Step 2: Build FAISS index if valid vectors exist
            faiss_file = None
            if run_faiss_build and len(valid_vectors) > 0:
                try:
                    faiss_data = np.vstack(valid_vectors).astype(np.float32)
                    manager.index_store.create_faiss_index_from_embeddings(faiss_data, model_key)
                    faiss_file = f"{model_key}_{dim}.faiss"
                except Exception as e:
                    collected_errors.append((full_model_key, " FAISS index build failed", str(e)))

            results.append({
                "Model": full_model_key,
                "Vectors Valid": len(valid_vectors),
                "FAISS File": faiss_file or "N/A",
            })

            progress.progress((i + 1) / total)

        # Display results table
        df = pd.DataFrame(results)
        st.success("\u2705 Diagnostics complete.")
        st.dataframe(df)

        # Download results
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        csv_data = df.to_csv(index=False)
        st.download_button(
            "\U0001F4E5 Download CSV Summary",
            data=csv_data,
            file_name=f"diagnostics_summary_{timestamp}.csv"
        )

        # Grouped error report
        if collected_errors:
            grouped = defaultdict(list)
            for model_id, err_type, fname in collected_errors:
                grouped[err_type].append((model_id, fname))

            for err_type, records in grouped.items():
                with st.expander(f"{err_type} ({len(records)} files)"):
                    model_files = defaultdict(list)
                    for model_id, fname in records:
                        model_files[model_id].append(fname)
                    for model_id, files in model_files.items():
                        st.markdown(f"**{model_id}**")
                        for fname in files:
                            json_data = index_tool.load_json_from_test(fname)
                            st.markdown(f"`{fname}`")
                            st.code(json_data, language="json")

        summarize_errors(collected_errors)


if __name__ == "__main__":
    show_faiss_diagnostics()