"""
[File: guided_search_tab.py]
Description: Provides the UI for guided search and groundtruth selection. 
Allows users to select documents by risk category and run the DSPy pipeline.

TODO:
  - Persist groundtruth selections across sessions.
  - Improve UI elements for filtering and searching documents.
  
FUTURE:
  - Build a full CRUD interface for managing groundtruth training sets with persistent storage.
"""

import streamlit as st
from dsai.dspy_pipeline_controller import run_pipeline
from core.init_context import get_tab_context


def render():
    st.header("\U0001F50E Guided Search & Groundtruth Selection")
    # if st.button("🏠 Back to Home"):
    #     st.session_state["admin_tool"] = "None"
    #     st.rerun()
    st.markdown(
        """
        This section allows you to select groundtruth examples from your risk management documents.
        Documents are categorized as **Strategic**, **Operational**, or **Technical**.

        For now, select up to **5 documents** per category. You can also enter a query, report, and project details 
        to run the DSPy-based pipeline.
        """
    )

    clients, config, *_ = get_tab_context()
    mode = st.radio("Select Mode", options=["Documents", "Topics"], index=0)

    if mode == "Documents":
        risk_categories = config.get("risk_categories", ["Strategic", "Operational", "Technical"])
        risk_category = st.selectbox("Select Risk Category", options=risk_categories)
        st.markdown(f"**Selected Category:** {risk_category}")

        # Placeholder: Simulate a list of documents for the selected category.
        dummy_docs = [f"{risk_category}_doc_{i}" for i in range(1, 11)]
        selected_docs = st.multiselect("Select Groundtruth Documents (max 5)", options=dummy_docs)
        if len(selected_docs) > config.get("max_groundtruth_docs", 5):
            st.warning("Please select no more than 5 documents.")

        # Inputs for DSPy pipeline demonstration.
        query = st.text_input("Enter your query:", "Sample query to validate report")
        report = st.text_area("Enter the report content:", "Initial report content here...")
        details = st.text_area("Enter project details:", "Project details here...")

        if st.button("Run Pipeline"):
            result = run_pipeline(query, report, details)
            st.subheader("Query Processing Result")
            st.json(result["query_result"])
            st.subheader("Corrected Report")
            st.text_area("Corrected Report", value=result["corrected_report"], height=300)
            if result.get("signature_info"):
                st.subheader("Document Signature & Reasoning")
                st.json(result["signature_info"])

    else:
        st.info("Topic-based guided search is under development.")


if __name__ == "__main__":
    render()