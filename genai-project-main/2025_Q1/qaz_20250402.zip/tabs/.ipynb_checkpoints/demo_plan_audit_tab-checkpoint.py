"""
[File: tabs/demo_plan_audit_tab.py]
Version: DSPy 2.5.26 - Streamlit Plan Audit Tab (Demo Lockdown)

Description:
  Presentation-ready version of Plan Audit Tab.
  Audits uploaded Model Development Plans against standard groundtruth using DSPy.
  Provides per-section reasoning and similarity scores.
  Optimized for clarity and simplicity in demo.
"""

import os
import json
import streamlit as st
from core.logging_helper import get_logger
from dsai.dspy_signature_uploader import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_text_from_json,
    generate_signature_and_reasoning
)
from dsai.dspy_section_auditor import audit_plan_sections

logger = get_logger("demo_plan_audit_tab")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
GROUNDTRUTH_PATH = os.path.join(ROOT_DIR, "groundtruth", "model_development.json")


def render():
    st.header("📋 Plan Audit - Demo View")
    st.markdown("Upload a Model Development Plan to validate key sections against AI expectations.")

    uploaded_file = st.file_uploader("Upload Document (PDF, DOCX, or JSON):", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()
        if ext == "pdf":
            text = extract_text_from_pdf(uploaded_file)
        elif ext == "docx":
            text = extract_text_from_docx(uploaded_file)
        elif ext == "json":
            text = extract_text_from_json(uploaded_file)
        else:
            st.error("Unsupported file type")
            return

        if not text:
            st.warning("No text found in document.")
            return

        st.text_area("📄 Document Preview", text[:1000], height=150)

        result = generate_signature_and_reasoning(text)
        st.markdown("---")
        st.subheader("🧠 AI Summary")
        st.code(result.get("signature"), language="text")
        st.text_area("AI Reasoning", result.get("reasoning", ""), height=150)

        if os.path.exists(GROUNDTRUTH_PATH):
            with open(GROUNDTRUTH_PATH) as f:
                groundtruth = json.load(f)

            st.markdown("---")
            st.subheader("📊 Section-by-Section Audit")
            section_results = audit_plan_sections(text, groundtruth)

            for section_name, audit in section_results.items():
                with st.expander(f"📌 {section_name}", expanded=False):
                    st.markdown(f"**Score:** `{audit['similarity_score']:.2f}`")
                    st.info(audit['expected'])
                    st.warning(audit['found'])
        else:
            st.error("❌ Groundtruth file not found.")

if __name__ == "__main__":
    render()