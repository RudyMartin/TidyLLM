"""
[File: pdf_tab.py]
Description: Provides the UI for PDF processing: splitting PDFs, extracting text,
and converting pages to JSON format.
  
TODO:
  - Enhance PDF processing logic with progress indicators and robust error handling.
  - Implement update/delete functionality if PDFs change.
  
FUTURE:
  - Integrate OCR for scanned PDFs and support multilingual extraction.
  - Develop a full CRUD interface for managing extracted document metadata and versioning.
"""

import streamlit as st

from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    extract_text_from_pdf,
    save_extracted_text_to_json,
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import list_pdf_files_s3, list_json_files_s3

def render():
    st.header("\U0001F4C2 PDF Processing")

    config = get_client_bundle().config
    s3_client = get_client_bundle().s3

    bucket_name = config["bucket_name"]
    pdf_folder = config["pdf_folder"]
    page_folder = config["page_folder"]
    json_folder = config["json_folder"]

    # if st.button("🏠 Back to Main View"):
    #     st.session_state["admin_tool"] = "None"
    #     st.srerun()

    
    # Minor buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("\u26A1 Batch Process (Split + Extract)", type="primary"):
            try:
                with st.spinner("Splitting PDFs into pages..."):
                    num_pdfs_processed = prepare_pdf_splits()

                with st.spinner("Extracting text and creating JSON files..."):
                    num_pages_processed = extract_text_to_json()

                st.success(
                    f"\u26A1 Batch completed successfully: "
                    f"{num_pdfs_processed} PDFs split, "
                    f"{num_pages_processed} PDF pages extracted and chunked into JSON."
                )
            except Exception as e:
                st.error(f"\u274C Batch extraction failed: {e}")

        if st.button("\U0001F4C4 1. Split PDFs into Pages", type="secondary"):
            try:
                num_processed = prepare_pdf_splits()
                st.success(f"\u2705 Successfully split {num_processed} PDFs into pages.")
            except Exception as e:
                st.error(f"\u274C Error splitting PDFs: {e}")

        if st.button("\U0001F9E0 2. Extract Content into JSON", type="secondary"):
            try:
                num_processed_pages = extract_text_to_json()
                st.success(f"\u2705 Successfully processed text from {num_processed_pages} PDF pages.")
            except Exception as e:
                st.error(f"\u274C Error extracting text: {e}")

    with col2:
        if st.button("\U0001F50D List Full PDFs Files", type="secondary"):
            pdf_files = list_pdf_files_s3(bucket_name, pdf_folder)
            num_pdfs = len(pdf_files)
            st.info(f"\U0001F50E {num_pdfs} PDF(s) found in `{pdf_folder}`.")
            if num_pdfs > 0:
                st.write(pdf_files)

        if st.button("\U0001F4C2 List Split Pages", type="secondary"):
            pages = list_pdf_files_s3(bucket_name, page_folder)
            num_pages = len(pages)
            st.info(f"\U0001F4C2 {num_pages} PDF page(s) found in `{page_folder}`.")
            if num_pages > 0:
                st.write(pages)

        if st.button("\U0001F4D1 List JSON Content", type="secondary"):
            json_files = list_json_files_s3(bucket_name, json_folder)
            num_json_files = len(json_files)
            st.info(f"\U0001F4D1 {num_json_files} JSON file(s) found in `{json_folder}`.")
            if num_json_files > 0:
                st.write(json_files)


if __name__ == "__main__":
    render()
