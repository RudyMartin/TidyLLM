# tabs/admin_pdf_tab.py

import streamlit as st
from core.extraction_helper import prepare_pdf_splits, extract_text_to_json
from core.s3_utils import list_pdf_files_s3, list_json_files_s3, list_objects_s3

# 🔧 TEMP HARDCODED CONFIG
BUCKET_NAME = "sagemaker-us-east-1-188494237500"
PDF_PREFIX = "dev/pdf/arxiv_wellsfargo"
PAGE_FOLDER = "dev/page"
JSON_FOLDER = "dev/json"

def render():
    st.header("📁 PDF Processing & Inventory (Hardcoded Mode)")

    st.write("✅ Using hardcoded S3 config:")
    st.code(f"Bucket: {BUCKET_NAME}\nPDF Prefix: {PDF_PREFIX}")

    if st.button("🔍 List All PDFs"):
        try:
            pdf_files = list_objects_s3(BUCKET_NAME, PDF_PREFIX,"pdf")
            if pdf_files:
                st.success(f"✅ {len(pdf_files)} PDF(s) found.")
                for p in pdf_files:
                    st.markdown(f"- `{p}`")
            else:
                st.warning(f"⚠️ No PDFs found in `{PDF_PREFIX}`.")
        except Exception as e:
            st.error(f"❌ Failed to list PDFs: {e}")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("⚡ Batch Process (Split + Extract)", type="primary"):
            try:
                with st.spinner("Splitting PDFs..."):
                    split_count = prepare_pdf_splits()
                with st.spinner("Extracting & saving JSON..."):
                    extract_count = extract_text_to_json()
                st.success(f"✔️ {split_count} PDFs split, {extract_count} pages extracted.")
            except Exception as e:
                st.error(f"❌ Batch failed: {e}")

        if st.button("📄 Split PDFs Only", type="secondary"):
            try:
                count = prepare_pdf_splits()
                st.success(f"✅ Split {count} PDFs.")
            except Exception as e:
                st.error(f"❌ Split failed: {e}")

        if st.button("🧠 Extract to JSON", type="secondary"):
            try:
                count = extract_text_to_json()
                st.success(f"✅ Extracted {count} PDF pages to JSON.")
            except Exception as e:
                st.error(f"❌ Extraction failed: {e}")

    with col2:
        if st.button("📂 List Page Files", type="secondary"):
            try:
                pages = list_pdf_files_s3(BUCKET_NAME, PAGE_FOLDER)
                st.info(f"📄 {len(pages)} page(s) found.")
                if pages:
                    st.write(pages)
            except Exception as e:
                st.error(f"❌ Error listing page files: {e}")

        if st.button("📑 List JSON Files", type="secondary"):
            try:
                jsons = list_json_files_s3(BUCKET_NAME, JSON_FOLDER)
                st.info(f"📦 {len(jsons)} JSON file(s) found.")
                if jsons:
                    st.write(jsons)
            except Exception as e:
                st.error(f"❌ Error listing JSON files: {e}")

