"""
[File: pdf_tab.py]
Description: Provides the UI for PDF processing: splitting PDFs, extracting text,
and converting pages to JSON format.
  
TODO:
  - Enhance PDF processing logic with progress indicators and robust error handling.
  - Implement update/delete functionality if PDFs change.
  
FUTURE:
  - Integrate OCR for scanned PDFs and support multilingual extraction.
  - Develop a full CRUD interface for managing extracted document metadata and versioning.
"""

# tabs/admin_pdf_tab.py

import streamlit as st
from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import (
    list_pdf_files_s3,
    list_json_files_s3,
)

def render():
    st.header("📁 PDF Processing & Inventory")

    # Get config and clients
    clients = get_client_bundle()
    config = clients.config
    s3_client = clients.s3
    st.write("✅ S3 Client Active:", s3_client is not None)

    try:
        bucket = config["bucket_name"]
        pdf_folder = config["pdf_folder"]
        subfolder = config.get("pdf_subfolder", "")
        pdf_path = f"{pdf_folder}/{subfolder}".strip("/")
        page_folder = config["page_folder"]
        json_folder = config["json_folder"]
    except KeyError as e:
        st.error(f"❌ Missing config key: {e}")
        return

    st.markdown(f"📂 Active folder: `s3://{bucket}/{pdf_path}`")

    # File Listing
    if st.button("🔍 List All PDFs"):
        pdf_files = list_pdf_files_s3(bucket, pdf_path)
        if pdf_files:
            st.success(f"✅ {len(pdf_files)} PDF(s) found.")
            for p in pdf_files:
                st.markdown(f"- `{p}`")
        else:
            st.warning(f"⚠️ No PDFs found in `{pdf_path}`.")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("⚡ Batch Process (Split + Extract)", type="primary"):
            try:
                with st.spinner("Splitting PDFs..."):
                    split_count = prepare_pdf_splits()
                with st.spinner("Extracting & saving JSON..."):
                    extract_count = extract_text_to_json()
                st.success(f"✔️ {split_count} PDFs split, {extract_count} pages extracted.")
            except Exception as e:
                st.error(f"❌ Batch failed: {e}")

        if st.button("📄 Split PDFs Only", type="secondary"):
            try:
                count = prepare_pdf_splits()
                st.success(f"✅ Split {count} PDFs.")
            except Exception as e:
                st.error(f"❌ Split failed: {e}")

        if st.button("🧠 Extract to JSON", type="secondary"):
            try:
                count = extract_text_to_json()
                st.success(f"✅ Extracted {count} PDF pages to JSON.")
            except Exception as e:
                st.error(f"❌ Extraction failed: {e}")

    with col2:
        if st.button("📂 List Page Files", type="secondary"):
            pages = list_pdf_files_s3(bucket, page_folder)
            st.info(f"📄 {len(pages)} page(s) found.")
            if pages:
                st.write(pages)

        if st.button("📑 List JSON Files", type="secondary"):
            jsons = list_json_files_s3(bucket, json_folder)
            st.info(f"📦 {len(jsons)} JSON file(s) found.")
            if jsons:
                st.write(jsons)
