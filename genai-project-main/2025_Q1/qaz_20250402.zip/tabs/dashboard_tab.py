"""
[File: tabs/dashboard_tab.py]
Version: DSPy 2.5.26

Description:
  Streamlit dashboard tab for visualizing FAISS log index entries and similarity results.
  Allows querying the FAISS log store, viewing top matches, and filtering by section.
"""

import streamlit as st
from core.faiss_log_reader import query_faiss_log_store


def render():
    st.header("📊 Audit Log Dashboard")
    st.markdown("""
        This dashboard allows you to:
        - Search the FAISS audit log index using semantic similarity.
        - View top-matching audit records.
        - Explore stored metadata and flagged sections.
    """)

    query = st.text_input("🔎 Enter a query to search the audit log:", "Testing plan clarity")
    top_k = st.slider("Top K results", min_value=1, max_value=10, value=5)

    if st.button("Run Search"):
        with st.spinner("Querying FAISS log store..."):
            results = query_faiss_log_store(query, top_k=top_k)

        if results:
            for idx, match in enumerate(results):
                st.markdown(f"### 🔹 Match #{idx + 1} — Score: {match['score']:.4f}")
                st.code(match['chunk'][:1000], language="text")
                st.json(match['metadata'])
        else:
            st.warning("No results found. Try a different query.")


if __name__ == "__main__":
    render()