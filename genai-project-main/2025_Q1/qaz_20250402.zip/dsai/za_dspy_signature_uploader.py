'''
[File: dspy_signature_uploader.py]
Version: DSPy 2.5.26

Description:
  Uploads a PDF, DOCX, or JSON file, generates a SHA-256 hash to uniquely fingerprint the document content,
  and uses DSPy to explain the context or purpose of the document.

NOTE: In DSPy v2.5.26, there is no global `compile()` function. 
      You must use the optimizer's `.compile()` method directly.

FUTURE:
  - Integrate section parsing and similarity scoring.
  - Compare each major section (e.g., Testing, Maintenance) against groundtruth.
'''

import os
import json
import hashlib
import logging
from io import BytesIO

from dspy import Module, Predict, Signature, InputField, OutputField
from PyPDF2 import PdfReader
from docx import Document
import streamlit as st
from sentence_transformers import SentenceTransformer, util

from core.logging_helper import get_logger

logger = get_logger("signature_uploader")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
DOCS_PATH = os.path.join(ROOT_DIR, "docs")
DEFAULT_JSON = os.path.join(ROOT_DIR, "docs_fallback.json")
GROUNDTRUTH_PATH = os.path.join(ROOT_DIR, "groundtruth", "model_development.json")

model = SentenceTransformer("all-MiniLM-L6-v2")

# === DSPy Signature ===
class DocumentReasoningSignature(Signature):
    document = InputField()
    reasoning = OutputField(desc="AI-generated explanation of the document's purpose or content.")

# === DSPy Module ===
class DocumentReasoningModule(Module):
    def __init__(self):
        super().__init__()
        self.reasoner = Predict(DocumentReasoningSignature)

    def forward(self, document):
        return self.reasoner(document=document)

# === SECTION PARSING ===
def extract_sections(text):
    sections = {}
    headers = [
        "Purpose and Scope", "Project Overview", "Stakeholders", "Timeline", "Budget",
        "Analysis and Requirements", "Design", "Implementation and Integration",
        "Testing", "Maintenance", "Risk Management"
    ]
    current = None
    for line in text.splitlines():
        line_strip = line.strip()
        if line_strip in headers:
            current = line_strip
            sections[current] = []
        elif current:
            sections[current].append(line_strip)
    return {k: "\n".join(v) for k, v in sections.items()}

# === GROUNDTRUTH LOAD ===
def load_groundtruth():
    with open(GROUNDTRUTH_PATH, "r") as f:
        return json.load(f)

# === SIMILARITY CHECK ===
def score_similarity(section_text, groundtruth_list):
    if not section_text.strip():
        return ("", 0.0)
    section_embedding = model.encode(section_text, convert_to_tensor=True)
    best_score = 0.0
    best_input = ""
    for gt in groundtruth_list:
        input_text = gt.get("input", "")
        input_embedding = model.encode(input_text, convert_to_tensor=True)
        score = util.cos_sim(section_embedding, input_embedding).item()
        if score > best_score:
            best_score = score
            best_input = input_text
    return (best_input, round(best_score, 3))

# === SECTION AUDIT ===
def audit_sections(text):
    groundtruth = load_groundtruth()
    parsed = extract_sections(text)
    results = {}
    for section, content in parsed.items():
        similar_input, score = score_similarity(content, groundtruth)
        module = DocumentReasoningModule()
        reasoning = module(document=content).reasoning
        results[section] = {
            "text": content,
            "match_input": similar_input,
            "similarity_score": score,
            "reasoning": reasoning
        }
    return results

# === EXTRACTION FUNCTIONS ===
def extract_text_from_pdf(uploaded_file):
    try:
        pdf_stream = BytesIO(uploaded_file.read())
        reader = PdfReader(pdf_stream)
        full_text = "\n\n".join([page.extract_text() or "" for page in reader.pages])
        return full_text.strip()
    except Exception as e:
        logger.error(f"Failed to extract text from PDF: {e}")
        return ""

def extract_text_from_docx(uploaded_file):
    try:
        doc = Document(BytesIO(uploaded_file.read()))
        return "\n\n".join([para.text for para in doc.paragraphs])
    except Exception as e:
        logger.error(f"Failed to extract text from DOCX: {e}")
        return ""

def extract_text_from_json(uploaded_file):
    try:
        json_data = json.load(uploaded_file)
        return json.dumps(json_data, indent=2)
    except Exception as e:
        logger.error(f"Failed to extract text from JSON: {e}")
        return ""

# === MAIN FUNCTION ===
def handle_uploaded_doc():
    uploaded_file = st.file_uploader("Upload a document (PDF, DOCX, or JSON):", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()

        with st.spinner("Extracting text from file..."):
            if ext == "pdf":
                text = extract_text_from_pdf(uploaded_file)
            elif ext == "docx":
                text = extract_text_from_docx(uploaded_file)
            elif ext == "json":
                text = extract_text_from_json(uploaded_file)
            else:
                st.error("Unsupported file type.")
                text = ""

        if text:
            st.text_area("Extracted Text", text[:2000], height=200)

            with st.spinner("Auditing document against groundtruth..."):
                results = audit_sections(text)

            st.success("Audit complete!")
            for section, info in results.items():
                st.markdown(f"### 📌 {section}")
                st.markdown(f"**Similarity Score**: {info['similarity_score']}")
                st.markdown(f"**Closest Groundtruth Match:**\n{info['match_input'][:200]}...")
                st.text_area("DSPy Reasoning", value=info["reasoning"], height=150)

        else:
            st.error("Could not extract any text from the uploaded file.")
    else:
        if not os.path.exists(DOCS_PATH):
            st.info("📁 No /docs folder found. Using fallback example data.")
            if os.path.exists(DEFAULT_JSON):
                with open(DEFAULT_JSON, "r") as f:
                    fallback = json.load(f)
                example_text = fallback.get("example_text", "Example content unavailable.")
                st.text_area("Example Text (Local JSON)", example_text, height=150)
                if st.button("Run Reasoning on Example"):
                    result = generate_signature_and_reasoning(example_text)
                    st.code(result["signature"])
                    st.text_area("Reasoning", result["reasoning"], height=200)
        else:
            st.info("Please upload a PDF, DOCX, or JSON file to begin.")

# Optional standalone test
if __name__ == "__main__":
    import streamlit.web.cli as stcli
    import sys
    sys.argv = ["streamlit", "run", __file__]
    sys.exit(stcli.main())
