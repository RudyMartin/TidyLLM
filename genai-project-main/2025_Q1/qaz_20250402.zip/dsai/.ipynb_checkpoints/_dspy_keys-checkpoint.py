"""
[File: dspy_keys.py]
Description: Manages DSPy API keys by retrieving them from the configuration file as a list of lists.

TODO:
  - Enhance error handling for missing or malformed API keys.
FUTURE:
  - Implement dynamic key rotation or load balancing between multiple keys.
USAGE:
openai_key = get_dspy_api_key("openai")
random_key = get_dspy_api_key("openai", rotate=True)
"""

from core.config_helper import get_config
import random

def get_dspy_api_key(provider: str = None, rotate: bool = False) -> str:
    """
    Retrieves an API key from the config's dspy_config.api_keys list.

    Args:
        provider (str): Optional key to filter by provider name (e.g., 'openai', 'anthropic').
        rotate (bool): If True, randomly return a matching key (for load balancing).
    
    Returns:
        str: API key string or empty string if not found.
    """
    config = get_config()
    api_keys = config.get("dspy_config", {}).get("api_keys", [])

    if not isinstance(api_keys, list):
        raise ValueError("Invalid format: 'dspy_config.api_keys' must be a list.")

    if provider:
        matching_keys = [key[1] for key in api_keys if isinstance(key, list) and key[0].lower() == provider.lower()]
    else:
        matching_keys = [key[1] for key in api_keys if isinstance(key, list)]

    if not matching_keys:
        return ""

    return random.choice(matching_keys) if rotate else matching_keys[0]