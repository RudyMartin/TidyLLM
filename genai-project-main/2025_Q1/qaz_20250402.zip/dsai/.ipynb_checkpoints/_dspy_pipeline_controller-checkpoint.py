"""
[File: dspy_pipeline_controller.py]
Description: Orchestrates the end-to-end pipeline including DSPy query processing,
report correction, and document signature generation. Also includes CSV export functionality
for persisting pipeline run outputs.
"""

import logging
from datetime import datetime
import pandas as pd

from dsai.dspy_query_processing import process_query
from dsai.dspy_report_correction import correct_report
from dsai.dspy_signature_helper import generate_signature_and_reasoning

from core.logging_helper import *
from core.vector_manager import VectorManager

# ---------- Logger ----------
logger = logging.getLogger("pipeline_controller")


# ---------- Pipeline Runner ----------
def run_pipeline(query: str, report: str, details: str, document_text: str = None) -> dict:
    """
    Orchestrates the full DSPy-based processing pipeline:
      1. Processes the query.
      2. Optionally generates a document signature and reasoning.
      3. Produces a corrected version of the report.
    
    Args:
        query (str): The input query to process.
        report (str): The initial report content.
        details (str): Supplemental detail to include in report correction.
        document_text (str, optional): Optional full document for signature.

    Returns:
        dict: {
            query_result,
            corrected_report,
            signature_info
        }
    """
    logger.info(" Starting DSPy pipeline...")

    results = {}

    # Step 1: Run DSPy query processing
    try:
        results["query_result"] = process_query(query)
    except Exception as e:
        logger.error(f" DSPy query processing failed: {e}")
        results["query_result"] = {"error": str(e)}

    # Step 2: Optional document signature
    if document_text:
        try:
            results["signature_info"] = generate_signature_and_reasoning(document_text)
        except Exception as e:
            logger.error(f" Signature generation failed: {e}")
            results["signature_info"] = {"error": str(e)}
    else:
        results["signature_info"] = None

    # Step 3: Report correction
    try:
        results["corrected_report"] = correct_report(report, details)
    except Exception as e:
        logger.error(f" Report correction failed: {e}")
        results["corrected_report"] = f"Error: {e}"

    return results


# ---------- Exporter ----------
def export_pipeline_results_csv(results: list, filename: str = None) -> str:
    """
    Export pipeline run results to a CSV file.

    Args:
        results (list): A list of dictionaries representing pipeline runs.
        filename (str, optional): Optional override for filename.

    Returns:
        str: The name of the saved file.
    """
    if not filename:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"pipeline_results_{timestamp}.csv"

    try:
        df = pd.DataFrame(results)
        df.to_csv(filename, index=False)
        logger.info(f" Pipeline results exported to: {filename}")
    except Exception as e:
        logger.error(f" Failed to export CSV: {e}")
    return filename


# ---------- Optional Standalone Test ----------
if __name__ == "__main__":
    test_query = "What are the key risks in the project?"
    test_report = "Initial project report content."
    test_details = "Project details including operational and technical aspects."
    test_document = "Full text of a sample document for signature generation."

    # Use abstracted VectorManager for embedding
    manager = VectorManager(store_type="faiss")
    vectorizer = manager.clients.vectorizer

    embedding = vectorizer.generate_embedding(test_query)
    print(" Embedding vector:", embedding)

    result = run_pipeline(test_query, test_report, test_details, document_text=test_document)
    print(" Pipeline Output:")
    print(result)

    export_pipeline_results_csv([result])