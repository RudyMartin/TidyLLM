"""
[File: dspy_signature_helper.py]

Description:
  Generates a SHA-256 hash to uniquely fingerprint the document content,
  and uses DSPy to explain the context or purpose of the document.

TODO:
  - Persist signature + reasoning metadata to storage (e.g., S3 or database).
  - Allow optional metadata injection for enhanced explanations.

FUTURE:
  - Integrate versioned signatures into a full document audit system.
  - Support reasoning comparison across document versions.
"""

import dspy
import hashlib
import logging
from core.logging_helper import get_logger

logger = get_logger("signature_helper")


def generate_signature_and_reasoning(text: str) -> dict:
    """
    Generates a SHA-256 signature for the text and explains the reasoning using DSPy.

    Args:
        text (str): Full document or chunk to sign and annotate.

    Returns:
        dict: {
            "signature": SHA-256 string,
            "reasoning": AI-generated explanation of the content.
        }
    """
    try:
        # Step 1: Hash the content
        signature = hashlib.sha256(text.encode("utf-8")).hexdigest()
        logger.info(f"Generated SHA-256 signature: {signature[:10]}...")

        # Step 2: Use DSPy to generate reasoning
        module = dspy.ChainOfThought("document -> reasoning: str")
        output = module(document=text)
        reasoning = output.reasoning
        logger.info("DSPy reasoning successfully generated.")

        return {
            "signature": signature,
            "reasoning": reasoning
        }

    except Exception as e:
        logger.error(f" Failed to generate signature and reasoning: {e}")
        return {
            "signature": None,
            "reasoning": f"Error: {e}"
        }


# Optional test
if __name__ == "__main__":
    sample_text = "This document summarizes the key risks in the upcoming infrastructure project."
    result = generate_signature_and_reasoning(sample_text)
    print(" Signature and Reasoning:")
    print(result)
