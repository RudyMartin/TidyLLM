"""
[File: dspy_query_processing.py]
Description: Processes user queries using DSPy in the risk management domain.
  - Generates an embedding for the query.
  - Retrieves similar documents/insights via vector store (e.g., FAISS or pgvector).
  - Constructs a risk-specific prompt and processes it with a DSPy module.
  - (Placeholder) Uses DSPy optimizers like BootstrapFewShot to refine prompts.

🧠 Optional Next Steps:
Store the examples in CSV or JSON and load them dynamically.

Support multiple optimizers with a dropdown in Streamlit (BootstrapFewShot, ReAct, etc.)

Show which example was most influential (tracing or logging).

Want me to show how to make your few-shot training set dynamic (from file or UI input)?
  
"""

import dspy
import logging

from core.vector_manager import VectorManager
from core.logging_helper import get_logger


logger = get_logger("dspy_query_processing")

from dsai.modules.risk_module import RiskInsightModule

## from dspy import BootstrapFewShot, compile  version 26 and above

from dspy import BootstrapFewShot
from dspy.compiler import compile  # if it's in the compiler module in 2.5.26

# Add your few-shot training examples (manually for now)
EXAMPLES = [
    {
        "risk_query": "What are the top risks in cloud migration?",
        "insights": "Key risks include data loss, latency issues, cost overruns, and compliance failures."
    },
    {
        "risk_query": "What are strategic risks in AI adoption?",
        "insights": "Lack of governance, misaligned goals, ethical concerns, and model drift."
    },
    {
        "risk_query": "What are technical risks in implementing Kubernetes?",
        "insights": "Misconfigured clusters, poor scaling, security gaps, and high operational complexity."
    }
]


def process_query(query: str, model_key: str = "titan_v2") -> dict:
    """
    Processes a user query by:
      1. Generating an embedding for the query.
      2. Retrieving similar documents via the current vector store.
      3. Constructing a domain-specific prompt.
      4. Running DSPy module on the prompt.
      5. (Optional) Applying a DSPy optimizer.

    Args:
        query (str): The user query.
        model_key (str): Which model config to use for embedding & indexing.

    Returns:
        dict: {
            "query": str,
            "dspy_result": str,
            "retrieved_docs": list
        }
    """
    try:
        # Init vector manager and vectorizer
        manager = VectorManager(store_type="faiss")  # future-proofed
        vectorizer = manager.clients.vectorizer
        config = manager.config

        # Step 1: Generate embedding
        query_embedding = vectorizer.generate_embedding(query)
        logger.info(" Embedding generated.")

        # Step 2: Retrieve similar documents
        retrieved_docs = manager.index_store.retrieve_similar(query_embedding, model_key=model_key, top_k=5)
        logger.info(f" Retrieved {len(retrieved_docs)} documents for FAISS search.")

        # Step 3: Construct DSPy prompt
        dspy_prompt = (
            f"Risk Management Query: Given the query '{query}' and the following similar documents: "
            f"{retrieved_docs}, what are the key insights regarding potential risks, mitigation strategies, "
            "and operational impacts?"
        )

        logger.info(" Constructed DSPy prompt.")

        # Step 4: Optimize the DSPy module using BootstrapFewShot
        module = RiskInsightModule()
        
        try:
            optimizer = BootstrapFewShot()
            compiled_module = compile(
                module,
                trainset=EXAMPLES,
                optimizer=optimizer,
                max_bootstrapped_demos=3  # Optional: limits the # of demos used
            )
            output = compiled_module(risk_query=dspy_prompt)
            dspy_result = output.insights
            logger.info(" DSPy module compiled and executed.")
        except Exception as e:
            logger.error(f" DSPy optimization failed: {e}")
            dspy_result = "Optimization failed."


        # Step 5: (Placeholder) DSPy optimizer
        logger.debug(" DSPy optimizer placeholder (e.g., BootstrapFewShot)")

    except Exception as e:
        logger.error(f" Error in query processing pipeline: {e}")
        return {
            "query": query,
            "dspy_result": "Error occurred during processing.",
            "retrieved_docs": []
        }

    return {
        "query": query,
        "dspy_result": dspy_result,
        "retrieved_docs": retrieved_docs
    }


# Example test
if __name__ == "__main__":
    test_query = "What are the key risks in the project?"
    result = process_query(test_query)
    print("DSPy Query Processing Output:")
    print(result)
