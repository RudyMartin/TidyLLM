"""
[File: dspy_report_correction.py]
Description:
  Uses a DSPy Chain-of-Thought module to improve a report by aligning it with
  project-specific details in the risk management domain.

TODO:
  - Enhance DSPy prompt clarity and controllability (e.g., use structured prompt templates).
  - Log intermediate prompt structure and responses.
  
FUTURE:
  - Store versions of reports and deltas.
  - Add user feedback loop for RLHF-style correction scoring.
"""

import dspy
import logging
from core.logging_helper import get_logger

logger = get_logger("report_correction")


def correct_report(report: str, details: str) -> str:
    """
    Uses DSPy to improve a report by reconciling it with relevant project details.

    Args:
        report (str): Original report content.
        details (str): Additional project-specific context or metadata.

    Returns:
        str: Corrected and improved report.
    """
    try:
        #  Step 1: Define DSPy module signature
        module = dspy.ChainOfThought("report + details -> corrected_report: str")

        #  Step 2: Run the module
        output = module(report=report, details=details)

        #  Step 3: Return result
        corrected_report = output.corrected_report
        logger.info(" Report successfully corrected using DSPy.")

    except Exception as e:
        corrected_report = f"Error: {e}"
        logger.error(f" Report correction failed: {e}")

    return corrected_report


# Optional standalone test
if __name__ == "__main__":
    test_report = "The initial report contains limited assessment of supply chain delays."
    test_details = "The project has experienced supplier issues in Q2 and will shift vendors in Q3."
    
    result = correct_report(test_report, test_details)
    print(" Corrected Report:\n", result)