# demo_main.py
"""
Version: DSPy Plan Audit Demo (2025-04)
"""

import streamlit as st
st.set_page_config(page_title="DSPy Plan Audit Demo", layout="wide")

from tabs.demo_plan_audit_tab import render as plan_audit_tab
from tabs.demo_wizard_tab import render as wizard_tab
from tabs.demo_dashboard_tab import render as dashboard_tab
from tabs.demo_truth_viewer_tab import render as truth_viewer_tab
from tabs.demo_faiss_search_tab import render as faiss_search_tab
from tabs.demo_guided_search_tab import render as guided_search_tab
from tabs.admin_config_tab import render as config_tab
from tabs.admin_batch_tab import render as batch_tab
from tabs.admin_pdf_tab import render as pdf_tab

from core.init_context import get_tab_context
from core.vector_manager import VectorManager
from core.config_helper import get_config

# Load demo config
get_config(force_reload=True, path_override="config/config.json")

# Session defaults
if "tab" not in st.session_state:
    st.session_state.tab = "🧭 Wizard"
if "admin_enabled" not in st.session_state:
    st.session_state.admin_enabled = False

faiss_manager = VectorManager(store_type="faiss")

# --- Sidebar Navigation ---
st.sidebar.title("🔍 Demo Navigation")
st.sidebar.markdown("### 🌐 User Tabs")

def tab_button(label):
    highlight = "🟢" if st.session_state.tab == label else ""
    if st.sidebar.button(f"{highlight} {label}"):
        st.session_state.tab = label

tab_button("🧭 Wizard")
tab_button("📋 Plan Audit")
tab_button("📍 FAISS Search")
tab_button("🧠 Guided Search")
tab_button("📊 Dashboard")
tab_button("🧠 Groundtruth")

# --- Admin Tools ---
with st.sidebar.expander("⚙️ Admin Tools"):
    st.session_state.admin_enabled = st.checkbox("Enable Admin Mode", value=st.session_state.admin_enabled)
    if st.session_state.admin_enabled:
        tab_button("🧾 Config")
        tab_button("📂 Batch Embedding")
        tab_button("📄 PDF Debugger")

# --- Tab Routing ---
if st.session_state.tab == "🧭 Wizard":
    wizard_tab()
elif st.session_state.tab == "📋 Plan Audit":
    plan_audit_tab()
elif st.session_state.tab == "📍 FAISS Search":
    faiss_search_tab()
elif st.session_state.tab == "🧠 Guided Search":
    guided_search_tab()
elif st.session_state.tab == "📊 Dashboard":
    dashboard_tab()
elif st.session_state.tab == "🧠 Groundtruth":
    truth_viewer_tab()
elif st.session_state.tab == "🧾 Config":
    config_tab()
elif st.session_state.tab == "📂 Batch Embedding":
    batch_tab()
elif st.session_state.tab == "📄 PDF Debugger":
    pdf_tab()

# --- Footer ---
st.markdown("""
---
[Back to Full App](main.py) | [GitHub Repo](#)
""")
