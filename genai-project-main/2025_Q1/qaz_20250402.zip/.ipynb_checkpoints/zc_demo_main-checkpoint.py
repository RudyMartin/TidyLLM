# demo_main.py
"""
Version: DSPy Plan Audit Demo (2025-04)

Description:
  Minimal Streamlit app to showcase DSPy Plan Auditing features.
  Includes: Wizard, Plan Audit, Dashboard, Groundtruth Editor, FAISS integration.
"""

import streamlit as st
st.set_page_config(page_title="DSPy Plan Audit Demo", layout="wide")  # ✅ MUST BE FIRST

# Tab imports
from tabs.demo_plan_audit_tab import render as plan_audit_tab
from tabs.demo_wizard_tab import render as wizard_tab
from tabs.demo_dashboard_tab import render as dashboard_tab
from tabs.demo_truth_viewer_tab import render as truth_viewer_tab
from tabs.demo_faiss_search_tab import render as faiss_search_tab
from tabs.demo_guided_search_tab import render as guided_search_tab
from tabs.admin_config_tab import render as config_tab
from tabs.admin_batch_tab import render as batch_tab
from tabs.admin_pdf_tab import render as pdf_tab

# Optional context
from core.init_context import get_tab_context
from core.vector_manager import VectorManager
from core.config_helper import get_config

# Force-load demo config at startup
get_config(force_reload=True, path_override="config/config.json")

# Initialize session state defaults
if "tab" not in st.session_state:
    st.session_state.tab = "🧭 Wizard"

faiss_manager = VectorManager(store_type="faiss")

# Sidebar layout
st.sidebar.title("🔍 Demo Navigation")

st.sidebar.markdown("### 🌐 User Tabs")
if st.sidebar.button("🧭 Wizard"):
    st.session_state.tab = "🧭 Wizard"
if st.sidebar.button("📋 Plan Audit"):
    st.session_state.tab = "📋 Plan Audit"
if st.sidebar.button("📍 FAISS Search"):
    st.session_state.tab = "📍 FAISS Search"
if st.sidebar.button("🧠 Guided Search"):
    st.session_state.tab = "🧠 Guided Search"
if st.sidebar.button("📊 Dashboard"):
    st.session_state.tab = "📊 Dashboard"
if st.sidebar.button("🧠 Groundtruth"):
    st.session_state.tab = "🧠 Groundtruth"

st.sidebar.markdown("### ⚙️ Admin Tools")
if st.sidebar.button("🧾 Config"):
    st.session_state.tab = "🧾 Config"
if st.sidebar.button("📂 Batch Embedding"):
    st.session_state.tab = "📂 Batch Embedding"
if st.sidebar.button("📄 PDF Debugger"):
    st.session_state.tab = "📄 PDF Debugger"

# Tab Routing
if st.session_state.tab == "🧭 Wizard":
    wizard_tab()
elif st.session_state.tab == "📋 Plan Audit":
    plan_audit_tab()
elif st.session_state.tab == "📊 Dashboard":
    dashboard_tab()
elif st.session_state.tab == "🧠 Groundtruth":
    truth_viewer_tab()
elif st.session_state.tab == "📍 FAISS Search":
    faiss_search_tab()
elif st.session_state.tab == "🧠 Guided Search":
    guided_search_tab()
elif st.session_state.tab == "🧾 Config":
    config_tab()
elif st.session_state.tab == "📂 Batch Embedding":
    batch_tab()
elif st.session_state.tab == "📄 PDF Debugger":
    pdf_tab()

# Footer
st.markdown("""
---
[Back to Full App](main.py) | [GitHub Repo](#)
""")

