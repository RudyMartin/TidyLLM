# demo_main.py
"""
Version: DSPy Plan Audit Demo (2025-04)

Description:
  Minimal Streamlit app to showcase DSPy Plan Auditing features.
  Includes: Wizard, Plan Audit, Dashboard, Groundtruth Editor, FAISS integration.
"""

import streamlit as st
st.set_page_config(page_title="DSPy Plan Audit Demo", layout="wide")  # ✅ MUST BE FIRST

# Tab imports
from tabs.demo_plan_audit_tab import render as plan_audit_tab
from tabs.demo_wizard_tab import render as wizard_tab
from tabs.demo_dashboard_tab import render as dashboard_tab
from tabs.demo_truth_viewer_tab import render as truth_viewer_tab
from tabs.demo_faiss_search_tab import render as faiss_search_tab
from tabs.demo_guided_search_tab import render as guided_search_tab


# Optional context
from core.init_context import get_tab_context
from core.vector_manager import VectorManager

# Initialize once
if "tab" not in st.session_state:
    st.session_state.tab = "🧭 Wizard"

faiss_manager = VectorManager(store_type="faiss")

# Sidebar
st.sidebar.title("🔍 Demo Navigation")
st.session_state.tab = st.sidebar.radio("Go to:", [
    "🧭 Wizard",
    "📋 Plan Audit",
    "📍 FAISS Search",
    "🧠 Guided Search",
    "📊 Dashboard",
    "🧠 Groundtruth"
], index=[
    "🧭 Wizard", "📋 Plan Audit", "📍 FAISS Search", "🧠 Guided Search", "📊 Dashboard", "🧠 Groundtruth"
].index(st.session_state.tab))

# Routing
if st.session_state.tab == "🧭 Wizard":
    wizard_tab()
elif st.session_state.tab == "📋 Plan Audit":
    plan_audit_tab()
elif st.session_state.tab == "📊 Dashboard":
    dashboard_tab()
elif st.session_state.tab == "🧠 Groundtruth":
    truth_viewer_tab()
elif st.session_state.tab == "📍 FAISS Search":
    faiss_search_tab()
elif st.session_state.tab == "🧠 Guided Search":
    guided_search_tab()    

# Footer
st.markdown("""
---
[Back to Full App](main.py) | [GitHub Repo](#)
""")
