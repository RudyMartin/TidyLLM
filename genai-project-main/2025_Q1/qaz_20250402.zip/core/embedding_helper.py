"""
[File: core/embedding_helper.py]
Description: Embedding generator for Amazon Bedrock (Titan/Cohere) models.
Generates embeddings and stores them in JSON or uploads to S3.
"""

import os
import json
import logging
from datetime import datetime
from threading import Lock

import numpy as np
import streamlit as st

from core.config_helper import get_config
from core.client_bundle import get_clients
from core.model_key_utils import (
    validate_model_key,
    find_model_key_by_id,
    get_model_details,
)
from core.logging_helper import get_logger

logger = get_logger("embedding_helper")
logger.setLevel(logging.DEBUG)

# ---------- AmazonEmbeddingVectorizer ----------
class AmazonEmbeddingVectorizer:
    def __init__(self, config, selected_model_option=None, dimensions=None, bedrock_client=None):
        self.config = config
        selected = self._select_model(config, selected_model_option)
        self.model_id = selected["id"]

        if "anthropic" in self.model_id:
            raise ValueError(f"{self.model_id} does not support embeddings.")

        self.dimensions = dimensions or selected["dimensions"]
        self.bedrock_boto3 = bedrock_client
        self.query_cache = {}
        self.query_cache_lock = Lock()

        logger.info(f"Using Amazon Bedrock model: {self.model_id} with dimensions={self.dimensions}")

    @staticmethod
    def _select_model(config, model_key=None):
        model_options = config.get("model_options", {})
        model_key = model_key or config.get("default_model_option", "titan_v2")
        validated_key = validate_model_key(model_key, model_options)
        return model_options[validated_key]

    @property
    def model_key(self):
        model_details = get_model_details(find_model_key_by_id(self.model_id, self.dimensions, self.config["model_options"]))
        return model_details["full_model_key"] if model_details else f"{self.model_id}_{self.dimensions}"

    @classmethod
    def from_config(cls, config, bedrock_client=None):
        if not bedrock_client:
            _, bedrock_client = get_clients(config)
        return cls(config=config, bedrock_client=bedrock_client)

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    def generate_embedding(self, text, normalize=True):
        cache_key = (text, self.model_id, self.dimensions, normalize)
        with self.query_cache_lock:
            if cache_key in self.query_cache:
                logger.info(f" Using cached embedding for '{text}' ({self.model_id}, {self.dimensions}D)")
                return self.query_cache[cache_key]

        body = {}
        if "amazon.titan-embed-text-v2" in self.model_id:
            body = {"inputText": text, "dimensions": int(self.dimensions)}
        elif "amazon.titan-embed-text-v1" in self.model_id:
            body = {"inputText": text}
        elif "cohere" in self.model_id:
            limit = 2048
            trimmed = text[:limit]
            body = {"texts": [trimmed], "input_type": "search_document"}
        else:
            raise ValueError(f"Unknown or unsupported model type: {self.model_id}")

        try:
            response = self.bedrock_boto3.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body)
            )
            raw_body = response["Body"].read().decode("utf-8")
            response_body = json.loads(raw_body)
        except Exception as e:
            logger.error(f" Bedrock invoke_model failed: {e}", exc_info=True)
            raise

        embedding = response_body.get("embedding") or (response_body.get("embeddings") or [])[0]
        if not embedding:
            raise ValueError("No embedding found in response.")

        if normalize:
            embedding = self._normalize_vector(embedding)

        with self.query_cache_lock:
            self.query_cache[cache_key] = embedding

        return embedding

# ---------- Cached Vectorizer ----------
@st.cache_resource
def get_cached_vectorizer():
    config = get_config()
    _, bedrock_client = get_clients(config)
    return AmazonEmbeddingVectorizer.from_config(config, bedrock_client=bedrock_client)
