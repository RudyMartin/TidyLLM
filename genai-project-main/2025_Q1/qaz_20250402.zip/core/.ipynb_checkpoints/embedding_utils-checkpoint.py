import os
import json
import numpy as np
from pathlib import Path
from datetime import datetime

from core.s3_utils import list_objects_s3
from core.extraction_helper import is_blank_page

from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

# Constants (override with actual values or import from your constants module)
REEMBED_LIST_PATH = "reembed_list.json"
TEST_JSON_DIR = "test/json"

__all__ = [
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "data_collect",
    "reembed_flag",
    "reembed_append"
    "get_text_to_encode'"
]


def prepare_embedding_input(data, exclude_keys=None):
    """
    Prepare the JSON content for embedding by excluding specific keys.

    Args:
        data (dict): Full JSON content.
        exclude_keys (list, optional): Keys to exclude (default: ['embeddings']).

    Returns:
        str: Filtered and formatted JSON string for embedding.
    """
    if exclude_keys is None:
        exclude_keys = ["embeddings"]
    data_filtered = {k: v for k, v in data.items() if k not in exclude_keys}
    return json.dumps(data_filtered, indent=2)


def build_embedding_metadata(data: dict, json_key: str, model_key: str, dim: int) -> dict:
    """
    Extract metadata fields used for tracking embeddings.

    Args:
        data (dict): JSON content from file.
        json_key (str): S3 or local path identifier.
        model_key (str): Model key used to embed.
        dim (int): Dimension of the embedding.

    Returns:
        dict: Metadata dictionary.
    """
    return {
        "json_key": json_key,
        "model_key": model_key,
        "dimensions": dim,
        "source": data.get("source", "unknown"),
        "tags_list": data.get("tags", [])
    }


def embeddings_flatten(data, model_key, config, logger):
    """
    Extract and reshape a vector from stored embeddings using config-defined model info.

    Args:
        data (dict): JSON data containing embedding.
        model_key (str): Config-defined model key.
        config (dict): Loaded configuration.
        logger (logging.Logger): Logger instance.

    Returns:
        np.ndarray or None: 2D embedding array [1, dim] or None if invalid.
    """
    model_info = config["model_options"].get(model_key)
    if not model_info:
        logger.warning(f" Model key not found: {model_key}")
        return None

    model_id = model_info["id"]
    embeddings = data.get("embeddings", {})
    model_embedding = embeddings.get(model_id, {})
    vector = model_embedding.get("vector") or model_embedding.get("embedding_vector")

    if isinstance(vector, list) and len(vector) == model_info["dimensions"]:
        try:
            return np.array(vector, dtype=np.float32).reshape(1, -1)
        except Exception as e:
            logger.error(f" Error reshaping embedding for model '{model_id}': {e}")
    else:
        logger.warning(
            f" Wrong embedding vector dimension for {model_id}: "
            f"got {len(vector) if vector else 'None'}"
        )
    return None


def data_collect(config, s3_client, model_key, logger):
    """
    Collect embedding vectors and metadata from S3 JSON files.

    Args:
        config (dict): Global configuration.
        s3_client (boto3.client): AWS S3 client.
        model_key (str): Model key to match embedding format.
        logger (logging.Logger): Logger instance.

    Returns:
        tuple: (list of np.ndarray embeddings, list of metadata dicts)
    """
    training_embeddings = []
    metadata = []
    json_keys = list_objects_s3(config["bucket_name"], config["json_folder"], extension=".json")

    for json_key in json_keys:
        try:
            obj = s3_client.get_object(Bucket=config["bucket_name"], Key=json_key)
            content = obj["Body"].read().decode("utf-8").strip()
            if not content:
                continue
            data = json.loads(content)
            text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])

            if "#blankpage" in data.get("tags", []) or is_blank_page(text, data.get("chunks", [])):
                continue

            embedding_vector = embeddings_flatten(data, model_key, config, logger)
            if embedding_vector is not None:
                training_embeddings.append(embedding_vector)
                meta = metadata_extract(data, json_key, model_key, config["model_options"][model_key]["dimensions"])
                metadata.append(meta)
        except Exception as e:
            logger.warning(f" Failed to process {json_key}: {e}")
            continue

    return training_embeddings, metadata


def reembed_flag(logger):
    """
    Reprocess files marked in re-embed list, regenerate embeddings, and update JSONs.

    Args:
        logger (logging.Logger): Logger instance.
    """
    if not os.path.exists(REEMBED_LIST_PATH):
        logger.info(" No flagged files to re-embed.")
        return

    try:
        with open(REEMBED_LIST_PATH, "r") as f:
            flagged = json.load(f)

        if not flagged:
            logger.info(" Re-embed list is empty.")
            return

        logger.info(f" Re-embedding {len(flagged)} flagged files...")

        for item in flagged:
            file_path = Path(TEST_JSON_DIR) / item["file"]
            if not file_path.exists():
                logger.warning(f" File not found: {item['file']}")
                continue

            with open(file_path, "r") as f:
                data = json.load(f)

            model_key = item["model"]
            model_details = get_model_details(model_key)
            vectorizer = get_cached_vectorizer()

            text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])
            new_vector = vectorizer.generate_embedding(text)

            if "embeddings" not in data:
                data["embeddings"] = {}

            data["embeddings"][model_key] = {
                "dimensions": model_details["dimensions"],
                "embed_date": datetime.utcnow().isoformat() + "Z",
                "vector": new_vector
            }

            with open(file_path, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f" Re-embedded: {item['file']}")

        os.remove(REEMBED_LIST_PATH)
        logger.info(" All flagged files re-embedded and list cleared.")

    except Exception as e:
        logger.error(f" Error during re-embedding: {e}")


def reembed_append(file, model_key, reason, logger):
    """
    Append a JSON file to the re-embed list for future processing.

    Args:
        file (str): Filename to flag.
        model_key (str): Associated model key.
        reason (str): Reason for re-embedding.
        logger (logging.Logger): Logger instance.
    """
    entry = {"file": file, "model": model_key, "reason": reason}
    try:
        if os.path.exists(REEMBED_LIST_PATH):
            with open(REEMBED_LIST_PATH, "r") as f:
                existing = json.load(f)
        else:
            existing = []

        existing.append(entry)
        with open(REEMBED_LIST_PATH, "w") as f:
            json.dump(existing, f, indent=2)

    except Exception as e:
        logger.warning(f" Could not write to re-embed list: {e}")

## `embedding_utils.py` Functions

# | Function | Purpose |
# |---------|---------|
# | `get_text_to_encode` | Returns cleaned JSON string for embedding input |
# | `metadata_extract` | Returns key metadata (model key, tags, dimensions) |
# | `embeddings_flatten` | Validates and flattens embedding into NumPy array |
# | `data_collect` | Gathers valid embedding data from S3 |
# | `reembed_flag` | Reprocesses and updates all files marked for re-embedding |
# | `reembed_append` | Adds a file to the re-embedding queue |