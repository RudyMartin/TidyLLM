"""
[File: core/faiss_log_writer.py]
Version: DSPy 2.5.26

Description:
  Writes structured audit logs into a FAISS vector store for retrieval, analysis, or model comparison.

Requires:
  - core/vector_manager.py
  - Audit entries to include: text, metadata, timestamp, signature hash

Supports:
  - Configurable model_key per audit
  - Embedding caching or re-generation
"""
import pandas as pd
import time
import hashlib
from datetime import datetime
from core.vector_manager import VectorManager
from core.logging_helper import get_logger

from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = get_logger("faiss_log_writer")

def generate_signature(text: str) -> str:
    """Returns a SHA-256 hash for identifying a specific audit result."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def build_audit_vector_entry(text: str, audit_result: dict, metadata: dict = None) -> dict:
    """
    Packages audit result and metadata for vector store insertion.

    Args:
        text (str): The full input used during the audit.
        audit_result (dict): DSPy reasoning or comparison output.
        metadata (dict): Optional dictionary with project_name, section_name, etc.

    Returns:
        dict: Fully structured vector entry.
    """
    return {
        "text": text,
        "metadata": {
            "signature": generate_signature(text),
            "timestamp": datetime.utcnow().isoformat(),
            "result": audit_result,
            **(metadata or {})
        }
    }

def write_to_faiss(text: str, audit_result: dict, metadata: dict = None, model_key: str = "titan_v2") -> bool:
    """
    Embeds and stores audit record in FAISS vector store.

    Args:
        text (str): Raw input or section text.
        audit_result (dict): Resulting DSPy or similarity audit info.
        metadata (dict): Optional context info (section name, project, etc.)
        model_key (str): Which embedding model to use for indexing.

    Returns:
        bool: Success or failure.
    """
    try:
        vector_entry = build_audit_vector_entry(text, audit_result, metadata)

        manager = VectorManager(store_type="faiss")
        vectorizer = manager.clients.vectorizer

        embedding = vectorizer.generate_embedding(text)
        manager.index_store.add_vectors([embedding], [vector_entry], model_key=model_key)

        logger.info(f"✅ FAISS audit log written: {metadata.get('section_name', 'N/A')}")
        return True

    except Exception as e:
        logger.error(f"❌ Failed to write audit result to FAISS: {e}")
        return False

# Load FAISS logs from S3 (not the index itself, just metadata/logging)
def load_faiss_logs_as_df(log_store_path: str) -> pd.DataFrame:
    try:
        # Fetch the list of log files from S3
        s3_keys = list_objects_s3(log_store_path)
        logs = []
        
        # Load each log file from S3 and process
        for key in s3_keys:
            log_data = load_json_from_s3(key)
            if log_data:
                logs.append(log_data)
        
        if logs:
            # Convert the logs to a DataFrame
            df = pd.json_normalize(logs)
            return df
        else:
            logger.warning(f"No FAISS logs found in {log_store_path}.")
            return pd.DataFrame()  # Empty DataFrame if no logs found
    except Exception as e:
        logger.error(f"Error loading FAISS logs from S3: {e}")
        return pd.DataFrame()  # Return empty DataFrame in case of error
