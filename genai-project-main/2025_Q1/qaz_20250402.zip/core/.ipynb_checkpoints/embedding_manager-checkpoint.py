"""
[File: embedding_manager.py]

Embedding Manager
Unified import/export interface for embedding operations:
- Vectorizer: AmazonEmbeddingVectorizer
- Utilities: collect, re-embed, flatten, encode
"""

import json
from datetime import datetime
import streamlit as st

from core.embedding_utils import (
    prepare_embedding_input,
    build_embedding_metadata,
    embeddings_flatten,
    data_collect,
    reembed_flag,
    reembed_append,
)

from core.extraction_helper import is_blank_page
from core.s3_utils import list_objects_s3
from core.logging_helper import get_logger
from core.embedding_helper import AmazonEmbeddingVectorizer, get_cached_vectorizer
from core.model_key_utils import get_model_details  #  FROM model_key_utils, not config_manager
from core.config_helper import get_client_bundle  #  Mid-layer safe

# ---------- Initialize Clients + Vectorizer ----------
clients = get_client_bundle()
vectorizer = get_cached_vectorizer()
logger = get_logger("embedding_manager")


# ---------- Metadata Logger ----------
def log_embedding_metadata(document_name, model_key, vector_length, tag_list):
    """
    Logs metadata related to a generated embedding for traceability.
    """
    metadata = {
        "timestamp": datetime.utcnow().isoformat(),
        "document": document_name,
        "model": model_key,
        "dimensions": vector_length,
        "tags": tag_list,
    }
    logger.info(f" Embedding metadata: {json.dumps(metadata)}")


# ---------- Optional EmbeddingManager Wrapper ----------
class EmbeddingManager:
    def __init__(self, clients=clients, vectorizer=vectorizer):
        self.clients = clients
        self.vectorizer = vectorizer
        self.config = clients.config
        self.s3 = clients.s3

    def generate(self, text: str, model_key: str) -> list:
        model_details = get_model_details(model_key)
        return self.vectorizer(text)

    def flatten_embedding(self, data: dict, model_key: str):
        return embeddings_flatten(data, model_key, self.config, logger)

    def collect_embeddings(self, model_key: str):
        return data_collect(self.config, self.s3, model_key, logger)

    def reembed_flagged(self):
        return reembed_flag(logger)

    def append_to_reembed_list(self, file, model_key, reason):
        return reembed_append(file, model_key, reason, logger)


# ---------- Re-exports ----------
__all__ = [
    # Core vectorizer
    "AmazonEmbeddingVectorizer",
    "get_cached_vectorizer",

    # Embedding utilities
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "data_collect",
    "reembed_flag",
    "reembed_append",

    # Logging
    "log_embedding_metadata",
    "get_logger",

    # External utilities
    "get_model_details",
    "is_blank_page",
    "list_objects_s3",

    # Optional interface
    "EmbeddingManager",
]
