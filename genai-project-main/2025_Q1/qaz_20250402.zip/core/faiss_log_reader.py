"""
[File: core/faiss_log_reader.py]
Version: DSPy 2.5.26

Description:
  Queries stored FAISS audit records using semantic similarity.
  Useful for retrieving past audit evaluations, comparing outcomes,
  and building dashboards of recent model governance activity.

Requires:
  - core/vector_manager.py
  - Same embedding model used during write.
"""

import json
from core.vector_manager import VectorManager
from core.logging_helper import get_logger

logger = get_logger("faiss_log_reader")

import pandas as pd
import json
import boto3
from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = get_logger("faiss_log_loader")

def load_faiss_log_as_df(log_store_path: str) -> pd.DataFrame:
    """
    Loads the FAISS audit logs from S3 and converts them into a DataFrame.

    Args:
        log_store_path (str): The S3 path where FAISS logs are stored.

    Returns:
        pd.DataFrame: A DataFrame containing the audit logs.
    """
    s3_client = boto3.client('s3')
    bucket_name = 'your-bucket-name'  # replace with your bucket name
    prefix = log_store_path  # replace with your actual folder path in S3

    try:
        # Get list of objects in the log folder
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        log_files = [obj['Key'] for obj in response.get('Contents', [])]

        log_data = []
        for log_file in log_files:
            obj = s3_client.get_object(Bucket=bucket_name, Key=log_file)
            log_content = obj['Body'].read().decode('utf-8')
            log_entries = json.loads(log_content)
            log_data.extend(log_entries)

        # Convert the logs into a pandas DataFrame
        df = pd.json_normalize(log_data)

        if df.empty:
            logger.warning(f"No log data found in {log_store_path}")
        return df

    except Exception as e:
        logger.error(f"Failed to load FAISS logs from S3: {e}")
        return pd.DataFrame()

def search_audit_logs(query_text: str, top_k: int = 5, model_key: str = "titan_v2") -> list:
    """
    Searches FAISS index for audit logs most similar to the query.

    Args:
        query_text (str): Text of the section or audit prompt to search.
        top_k (int): How many similar records to return.
        model_key (str): Which embedding model to use.

    Returns:
        list of dict: Retrieved audit entries and metadata.
    """
    try:
        manager = VectorManager(store_type="faiss")
        vectorizer = manager.clients.vectorizer
        query_embedding = vectorizer.generate_embedding(query_text)

        results = manager.index_store.retrieve_similar(
            query_embedding, model_key=model_key, top_k=top_k
        )

        return results

    except Exception as e:
        logger.error(f"❌ Error querying FAISS audit log: {e}")
        return []

# Optional CLI
if __name__ == "__main__":
    sample_query = "How does the model handle post-deployment monitoring and retraining?"
    matches = search_audit_logs(sample_query, top_k=3)
    for i, match in enumerate(matches):
        print(f"\n[{i+1}] Score: {match.get('score', '?')}")
        print(f"Text: {match.get('text', '')[:300]}...")
        print(f"Metadata: {json.dumps(match.get('metadata', {}), indent=2)}")
