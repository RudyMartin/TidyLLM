# import boto3

# bucket = "sagemaker-us-east-1-188494237500"
# prefix = "dev/pdf/arxiv_wellsfargo/"

# s3 = boto3.client("s3")

# response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
# pdfs = [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(".pdf")]

# print(f"{len(pdfs)} PDF(s) found.")
# for pdf in pdfs[:10]:
#     print(" -", pdf)

def get_config():
    try:
        return st.session_state["CONFIG"]
    except Exception:
        # Allow fallback for non-Streamlit CLI use
        return {
            "bucket_name": "sagemaker-us-east-1-188494237500",
            "pdf_folder": "dev/pdf/arxiv_wellsfargo",
            "json_folder": "dev/json",
            "index_folder": "dev/idx",
            "prefix": "dev",
            "log_directory": "logs"
        }
from core.s3_utils import list_objects_s3
#from core.config_helper import get_config, get_clients

def count_pdfs():
    config = get_config()
    s3 = get_clients()["s3"]
    bucket = config["bucket_name"]
    folder = config["pdf_folder"]
    
    keys = list_objects_s3(bucket, folder, extension=".pdf")
    return len(keys), keys    

print(count_pdfs() )   