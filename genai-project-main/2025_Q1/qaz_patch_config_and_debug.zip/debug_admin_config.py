
import streamlit as st
from tabs import admin_config_tab
from core.config_helper import initialize_config

# Initialize config manually before rendering
initialize_config()

# Run the admin config UI
admin_config_tab.render()
