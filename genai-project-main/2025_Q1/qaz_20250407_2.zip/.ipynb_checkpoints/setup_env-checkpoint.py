# setup_env.py

import os
import subprocess
import sys

# Create necessary log directories
log_paths = [
    "/home/sagemaker-user/qaz/logs",
    "/home/sagemaker-user/qaz/logs/faiss",
    "/home/sagemaker-user/qaz/logs/indexing",
    "/home/sagemaker-user/qaz/logs/repair"
]

for path in log_paths:
    os.makedirs(path, exist_ok=True)
    print(f"✅ Created: {path}")

# Install requirements safely
try:
    print("📦 Installing Python packages from requirements.txt...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "-q"])
    print("✅ Package installation complete.")
except subprocess.CalledProcessError as e:
    print(f"❌ pip install failed: {e}")


import pyarrow as pa
print(hasattr(pa.lib, "Decimal32Type")) 