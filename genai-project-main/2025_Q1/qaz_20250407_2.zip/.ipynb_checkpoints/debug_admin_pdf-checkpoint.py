"""
debug_admin_pdf.py

CLI tool to inspect, clean, and reprocess JSON files extracted from PDFs.
Adds split and extract functions to match Streamlit tab behavior.

Usage:
    python debug_admin_pdf.py --list
    python debug_admin_pdf.py --list-json
    python debug_admin_pdf.py --list-pages
    python debug_admin_pdf.py --list-all-files
    python debug_admin_pdf.py --inspect FILE_NAME
    python debug_admin_pdf.py --fix FILE_NAME
    python debug_admin_pdf.py --fix-all
    python debug_admin_pdf.py --split-pdfs
    python debug_admin_pdf.py --extract-json
    python debug_admin_pdf.py --batch-all
    python debug_admin_pdf.py --delete-json FILE_NAME
    python debug_admin_pdf.py --delete-page FILE_NAME
    python debug_admin_pdf.py --delete-all-json
    python debug_admin_pdf.py --delete-all-pages
    python debug_admin_pdf.py --delete-all-files
"""

import os
import json
import argparse
from datetime import datetime

from core.config_helper import initialize_config_cli, get_config_cli
from core.s3_utils import list_objects_s3, load_json_from_s3, save_json_to_s3
from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    prepare_pdf_splits,
    extract_text_to_json,
)

# ✅ Initialize CLI context
initialize_config_cli()

# ✅ Get client bundle with config + S3
clients = get_client_bundle()
config = clients.config
s3 = clients.s3

# ✅ Bucket and folder paths
BUCKET = config["bucket_name"]
JSON_PREFIX = config["json_folder"]
PAGES_PREFIX = config["pages_folder"]

# ✅ Default legacy fallback
PREFIX = JSON_PREFIX


# === Utility Setup ===
def set_prefix_default(folder="json"):
    global PREFIX
    if folder == "pages":
        PREFIX = PAGES_PREFIX
    else:
        PREFIX = JSON_PREFIX


# === JSON Tools ===
def list_all_files():
    set_prefix_default("json")
    keys = list_objects_s3(BUCKET, PREFIX, extension=".json")
    for key in keys:
        print("-", key)
    print(f"✅ Total files listed in {PREFIX}: {len(keys)}")


def inspect_file(key):
    try:
        data = load_json_from_s3(BUCKET, key)
        print(f"\n📄 File: {key}")
        print(f"  Metadata: {data.get('metadata', {})}")
        print(f"  Chunks: {len(data.get('chunks', []))}")
        print(f"  Embeddings: {list(data.get('embeddings', {}).keys())}")
    except Exception as e:
        print(f"❌ Error reading {key}: {e}")


def fix_file(key):
    if not key.startswith(JSON_PREFIX):
        print(f"⚠️ Warning: {key} does not appear to be in json_folder ({JSON_PREFIX})")
    try:
        data = load_json_from_s3(BUCKET, key)

        data.setdefault("metadata", {})
        data.setdefault("chunks", [])
        data.setdefault("embeddings", {})

        cleaned_embeddings = {
            k: v for k, v in data["embeddings"].items()
            if isinstance(v, dict) and "vector" in v and isinstance(v["vector"], list)
        }
        data["embeddings"] = cleaned_embeddings

        if "page_number" in data["metadata"]:
            try:
                data["metadata"]["page_number"] = int(data["metadata"]["page_number"])
            except:
                pass

        data["metadata"]["cleaned_date"] = datetime.utcnow().isoformat() + "Z"
        save_json_to_s3(BUCKET, key, data)
        print(f"✅ Fixed and saved {key}")
    except Exception as e:
        print(f"❌ Failed to fix {key}: {e}")


def fix_all():
    set_prefix_default("json")
    keys = list_objects_s3(BUCKET, PREFIX, extension=".json")
    for key in keys:
        fix_file(key)
    print(f"✅ Total files fixed in {PREFIX}: {len(keys)}")


# === PDF Handling ===
def split_pdfs():
    print("⚙️ Splitting PDFs into individual pages...")
    count = prepare_pdf_splits()
    print(f"✅ Split {count} PDF(s) into pages.")


def extract_json():
    print("📄 Extracting text and saving JSON files...")
    count = extract_text_to_json(config=config, s3_client=s3)
    print(f"✅ Extracted and saved JSON from {count} page(s).")


def batch_all():
    print("⏳ Running full batch: Split PDFs -> Extract Text to JSON")
    split_pdfs()
    extract_json()
    print("🚀 Batch process completed.")


# === Dual-Folder Tools ===
def list_files(folder_name):
    keys = list_objects_s3(BUCKET, folder_name, extension=".json")
    print(f"\n📁 Listing files in: {folder_name}")
    for key in keys:
        print("-", key)
    print(f"✅ Total files listed in {folder_name}: {len(keys)}")


def list_all_files_combined():
    print("\n📂 Listing JSON files from both folders:")
    keys_json = list_objects_s3(BUCKET, JSON_PREFIX, extension=".json")
    keys_pages = list_objects_s3(BUCKET, PAGES_PREFIX, extension=".json")
    list_files(JSON_PREFIX)
    list_files(PAGES_PREFIX)
    print(f"✅ Total files listed: {len(keys_json) + len(keys_pages)} (json: {len(keys_json)}, pages: {len(keys_pages)})")


def delete_file(folder_name, key):
    s3_key = f"{folder_name.rstrip('/')}/{key}"
    try:
        s3.delete_object(Bucket=BUCKET, Key=s3_key)
        print(f"🗑️ Deleted {s3_key} from S3")
    except Exception as e:
        print(f"❌ Failed to delete {s3_key}: {e}")


def delete_all_files(folder_name):
    keys = list_objects_s3(BUCKET, folder_name, extension=".json")
    count = 0
    for key in keys:
        delete_file(folder_name, os.path.basename(key))
        count += 1
    print(f"✅ Deleted {count} files from {folder_name}")
    return count


def delete_all_files_combined():
    print("\n🗑️ Deleting all JSON files from both folders:")
    count_json = delete_all_files(JSON_PREFIX)
    count_pages = delete_all_files(PAGES_PREFIX)
    total = count_json + count_pages
    print(f"✅ Total files deleted: {total} (json: {count_json}, pages: {count_pages})")


# === CLI Entrypoint ===
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--list", action="store_true", help="List all JSON files (default json_folder)")
    parser.add_argument("--list-json", action="store_true", help="List all JSON files in json_folder")
    parser.add_argument("--list-pages", action="store_true", help="List all page-level JSON files in pages_folder")
    parser.add_argument("--list-all-files", action="store_true", help="List all files from both json_folder and pages_folder")

    parser.add_argument("--inspect", type=str, help="Inspect a specific JSON file by key")
    parser.add_argument("--fix", type=str, help="Fix a specific JSON file by key (in json_folder)")
    parser.add_argument("--fix-all", action="store_true", help="Fix all JSON files in json_folder")

    parser.add_argument("--split-pdfs", action="store_true", help="Split PDFs into pages")
    parser.add_argument("--extract-json", action="store_true", help="Extract text and save JSON")
    parser.add_argument("--batch-all", action="store_true", help="Split + Extract all")

    parser.add_argument("--delete-json", type=str, help="Delete a JSON file from json_folder")
    parser.add_argument("--delete-page", type=str, help="Delete a JSON file from pages_folder")
    parser.add_argument("--delete-all-json", action="store_true", help="Delete all JSON files in json_folder")
    parser.add_argument("--delete-all-pages", action="store_true", help="Delete all JSON files in pages_folder")
    parser.add_argument("--delete-all-files", action="store_true", help="Delete all JSON files from both folders")

    args = parser.parse_args()

    if args.list:
        list_all_files()
    elif args.list_json:
        list_files(JSON_PREFIX)
    elif args.list_pages:
        list_files(PAGES_PREFIX)
    elif args.list_all_files:
        list_all_files_combined()

    elif args.inspect:
        inspect_file(args.inspect)
    elif args.fix:
        fix_file(args.fix)
    elif args.fix_all:
        fix_all()

    elif args.split_pdfs:
        split_pdfs()
    elif args.extract_json:
        extract_json()
    elif args.batch_all:
        batch_all()

    elif args.delete_json:
        delete_file(JSON_PREFIX, args.delete_json)
        print(f"✅ Deleted 1 file from {JSON_PREFIX}")
    elif args.delete_page:
        delete_file(PAGES_PREFIX, args.delete_page)
        print(f"✅ Deleted 1 file from {PAGES_PREFIX}")
    elif args.delete_all_json:
        delete_all_files(JSON_PREFIX)
    elif args.delete_all_pages:
        delete_all_files(PAGES_PREFIX)
    elif args.delete_all_files:
        delete_all_files_combined()
    else:
        parser.print_help()
