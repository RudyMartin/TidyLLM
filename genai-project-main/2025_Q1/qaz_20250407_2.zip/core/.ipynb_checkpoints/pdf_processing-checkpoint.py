# [File: core/pdf_processing.py]
# Description: Provides PDF processing functions like splitting PDFs and extracting text.
# SUNDAY file needs review

import PyPDF2

def split_pdf(input_pdf: str, output_folder: str) -> int:
    """
    Splits a PDF into individual pages and saves them as separate PDF files.

    Args:
        input_pdf (str): Path to the input PDF file.
        output_folder (str): Directory where the split PDFs will be saved.

    Returns:
        int: The number of pages in the original PDF.
    """
    try:
        with open(input_pdf, "rb") as file:
            pdf_reader = PyPDF2.PdfReader(file)
            num_pages = len(pdf_reader.pages)
            for page_num in range(num_pages):
                pdf_writer = PyPDF2.PdfWriter()
                pdf_writer.add_page(pdf_reader.pages[page_num])
                output_pdf = f"{output_folder}/page_{page_num + 1}.pdf"
                with open(output_pdf, "wb") as output_file:
                    pdf_writer.write(output_file)
            return num_pages
    except Exception as e:
        print(f"Error splitting PDF: {e}")
        return 0

def extract_text_from_pdf(input_pdf: str) -> str:
    """
    Extracts text from a PDF file.

    Args:
        input_pdf (str): Path to the input PDF file.

    Returns:
        str: Extracted text from the PDF.
    """
    try:
        with open(input_pdf, "rb") as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
            return text
    except Exception as e:
        print(f"Error extracting text from PDF: {e}")
        return ""
