"""
[File: logging_helper.py]
Description: Provides functions to write, list, and read log files stored locally.

TODO:
  - Add update and delete functions for managing individual log files.

FUTURE:
  - Integrate with a centralized logging system or S3 for persistent, shared logging.
  - Build a searchable log dashboard.
"""

import os
import json
import logging
import pandas as pd
from datetime import datetime
import streamlit as st 

logger = logging.getLogger("logs_helper")
logger.setLevel(logging.DEBUG)

# Set the logs directory relative to the project root
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "logs")
os.makedirs(LOG_DIR, exist_ok=True)

# ---------- Utility Functions ----------
def get_model_log_path(model_key):
    filename = f"faiss_index_log_{model_key}.log"
    return os.path.join(LOG_DIR, filename)

def log_to_file(file_handle, message: str, level: str = "info"):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"[{timestamp}] {message}\n"
    file_handle.write(entry)
    getattr(logger, level)(message)

def get_first_chunk_text(data: dict) -> str:
    return data.get("chunks", [{}])[0].get("text", "") if data.get("chunks") else ""

def write_log(message: str, log_type: str = "info", filename: str = None) -> str:
    """
    Writes a log entry to a local file.
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if not filename:
        filename = f"log_{timestamp}.json"
    log_path = os.path.join(LOG_DIR, filename)
    log_entry = {
        "timestamp": timestamp,
        "type": log_type,
        "message": message
    }
    try:
        with open(log_path, "w") as f:
            json.dump(log_entry, f, indent=2)
        logger.info(f"Log written to {log_path}")
    except Exception as e:
        logger.error(f"Failed to write log: {e}")
    return log_path

def list_log_files(subfolders: list = None) -> list:
    """
    Lists log files under the logs directory or specified subfolders.
    """
    log_files = []
    base_dir = LOG_DIR
    if subfolders:
        for sub in subfolders:
            folder_path = os.path.join(base_dir, sub)
            if os.path.exists(folder_path):
                for root, _, files in os.walk(folder_path):
                    for file in files:
                        if file.endswith(".json") or file.endswith(".log"):
                            log_files.append(os.path.join(root, file))
            else:
                logger.warning(f"Subfolder {folder_path} does not exist.")
    else:
        for root, _, files in os.walk(base_dir):
            for file in files:
                if file.endswith(".json") or file.endswith(".log"):
                    log_files.append(os.path.join(root, file))
    return log_files

def read_log_file(filepath: str) -> dict:
    """
    Reads and returns the content of a log file as a dictionary.
    """
    try:
        with open(filepath, "r") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error reading log file {filepath}: {e}")
        return {}

def setup_module_logger(name: str, file_name: str = None, level=logging.INFO) -> logging.Logger:
    """
    Sets up and returns a module-specific logger.
    If file_name is not provided, uses name to generate a dynamic log file.
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    if not logger.handlers:
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

        safe_name = name.replace('.', '_')
        default_file_name = f"{safe_name}.log"
        file_path = os.path.join(LOG_DIR, file_name or default_file_name)

        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        file_handler = logging.FileHandler(file_path)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger

def summarize_errors(errors: list):
    """
    Summarizes a list of error records and displays grouped errors with optional download.
    Each error is a tuple: (model_id, error_type, filename)
    """
    if not errors:
        st.success(" No embedding errors found.")
        return

    df = pd.DataFrame(errors, columns=["model_id", "error_type", "filename"])

    # Summary Table
    summary = df.groupby(["model_id", "error_type"]).size().unstack(fill_value=0)
    st.subheader(" Embedding Error Summary")
    st.dataframe(summary)

    # Expanders for file listings
    for error_type in df["error_type"].unique():
        subset = df[df["error_type"] == error_type]
        with st.expander(f"{error_type} ({len(subset)} files)"):
            for model_id, group in subset.groupby("model_id"):
                st.markdown(f"**{model_id}**")
                for fname in group["filename"]:
                    st.write(f"- {fname}")

    # Download CSV
    csv_data = df.to_csv(index=False).encode("utf-8")
    st.download_button(
        label=" Download error details CSV",
        data=csv_data,
        file_name="embedding_error_details.csv",
        mime="text/csv"
    )

def get_logger(name: str = "app_logger", log_dir: str = "logs") -> logging.Logger:
    """
    Returns a logger instance with file and console handlers.

    Args:
        name (str): Name of the logger.
        log_dir (str): Directory where logs are stored.

    Returns:
        logging.Logger: Configured logger instance.
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # Avoid re-adding handlers in Streamlit reruns or multi-import cases
    if not logger.handlers:
        os.makedirs(log_dir, exist_ok=True)

        log_path = os.path.join(log_dir, f"{name}.log")

        # File handler for persistent logs
        file_handler = logging.FileHandler(log_path)
        file_handler.setLevel(logging.DEBUG)

        # Console (Stream) handler for UI or terminal
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # Formatter
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Add handlers
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

    # Optional: Add NullHandler for fallback in headless/test environments
    if not logger.hasHandlers():
        logger.addHandler(logging.NullHandler())

    return logger



def cleanup_logs() -> dict:
    """Deletes all .log/.txt files from the log directory."""
    log_dir = LOG_DIR 
    removed, failed, remaining = [], [], []

    try:
        for f in os.listdir(log_dir):
            path = os.path.join(log_dir, f)
            if os.path.isfile(path) and (f.endswith(".log") or f.endswith(".txt")):
                try:
                    os.remove(path)
                    removed.append(f)
                except Exception as e:
                    failed.append((f, str(e)))
            elif os.path.isfile(path):
                remaining.append(f)
        return {
            "removed": removed,
            "failed": failed,
            "remaining": remaining
        }
    except Exception as e:
        return {"error": str(e)}
