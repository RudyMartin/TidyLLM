#  core/FaissStore.py

import os
import io
import faiss
import json
import logging
import numpy as np
from datetime import datetime
import streamlit as st


from core.model_key_utils import (
    validate_model_key,
    get_model_details,
    get_faiss_s3_key,
    get_index_filename,
)
from core.embedding_helper import AmazonEmbeddingVectorizer
from core.logging_helper import get_logger, get_model_log_path, log_to_file
from core.s3_utils import list_objects_s3, load_json_from_s3, save_json_to_s3

from core.logging_helper import get_logger

from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = get_logger("faiss_store")
logger.setLevel(logging.DEBUG)

TEST_JSON_DIR = "test/json"
REEMBED_LIST_PATH = os.path.join("logs/faiss", "reembed_list.json")

## tuning utilities embedded here

# Tuning Utilities
def suggest_training_sample_count(total_embeddings: int, max_samples: int) -> int:
    """
    Suggests a training sample threshold based on the total number of embeddings
    and a maximum limit from the configuration.

    Args:
        total_embeddings (int): The total number of embeddings available.
        max_samples (int): The maximum number of training samples allowed from the configuration.

    Returns:
        int: The computed minimum number of embeddings required to proceed with training.
    """
    lower_bound = 50
    # Require at least 10% of the total embeddings or a lower bound of 50, whichever is higher.
    required = max(lower_bound, int(total_embeddings * 0.1))
    return min(required, max_samples)


class FaissStore:
    # 🔧 Initialization & Configuration ----------------------------------------
    def __init__(self, config, s3_client, logger):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger

    # 🏗️ Index Creation & Training ----------------------------------------
    def list_indexes(self):
        bucket = self.config["bucket_name"]
        prefix = self.config.get("index_folder", "idx")
    
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        items = response.get("Contents", [])
    
        return [
            {
                "Key": item["Key"],
                "LastModified": item["LastModified"].isoformat() if hasattr(item["LastModified"], "isoformat") else str(item["LastModified"]),
                "Size": item["Size"]
            }
            for item in items
        ]
    
    def index_create(self, embeddings, model_key, metadata=None):
        try:
            self.logger.info(f"❓ Creating FAISS index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            raw_nlist = self.config["nlist"]
            nlist = calculate_nlist(vector_count, raw_nlist)
            nprobe = calculate_nprobe(vector_count)
            self.logger.info(f"⚙️ Adjusted nlist: {nlist}, nprobe: {nprobe}, vector_count={vector_count}")
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_L2)
            if not index.is_trained:
                self.logger.info(f"📝 Training FAISS index for {model_key}...")
                index.train(embeddings)
                self.logger.info(f"✅ FAISS index trained for {model_key}.")
            index.add(embeddings)
            self.logger.info(f"✅ Added embeddings to FAISS index for {model_key}.")
            bucket = self.config["bucket_name"]
            prefix = self.config["prefix"]
            model_folder = f"{model_key}/{dim}"
            index_name = f"{model_key}_{dim}.faiss"
            self.logger.info(f"Saving FAISS index to S3 at: {model_folder}/{index_name}")
            save_faiss_index_to_s3(bucket, prefix, index, index_name, model_folder)
            self.logger.info(f"✅ FAISS index and metadata saved for {model_key}")
        except Exception as e:
            self.logger.error(f"❌ Error creating FAISS index for {model_key}: {e}")
            raise

    ## reinserted this per suggestion
    def collect_embeddings_and_metadata(self, full_model_key):
        """
        Collects embeddings and metadata for the given model key.
    
        This example assumes that embeddings are stored within JSON files in S3.
        It scans the JSON files from a specified folder, extracts the embedding 
        vector for the full_model_key, and collects associated metadata.
    
        Returns:
            training_embeddings (list of np.array): List of embedding vectors.
            metadata (list of dict): List of metadata dictionaries corresponding to each embedding.
        """
        import numpy as np
        training_embeddings = []
        metadata = []
        
        # Retrieve configuration values for S3 bucket and JSON folder.
        bucket = self.config["bucket_name"]
        json_folder = self.config.get("json_folder", "json")
        
        # List JSON files in the specified folder.
        json_keys = list_objects_s3(bucket, json_folder, extension=".json")
        self.logger.info(f"Found {len(json_keys)} JSON files for collecting embeddings.")
    
        for json_key in json_keys:
            try:
                data = load_json_from_s3(bucket, json_key)
                # Check if the embedding for the specified model exists in the JSON data.
                if "embeddings" in data and full_model_key in data["embeddings"]:
                    embed_info = data["embeddings"][full_model_key]
                    vector = embed_info.get("vector")
                    if vector and len(vector) == self.config["model_options"][full_model_key.split('_')[0]]["dimensions"]:
                        # Convert the vector list to a numpy array.
                        vector_np = np.array(vector, dtype=np.float32)
                        training_embeddings.append(vector_np)
                        metadata.append({
                            "source": json_key,
                            "embed_date": embed_info.get("embed_date", ""),
                            "model_key": full_model_key
                        })
            except Exception as e:
                self.logger.error(f"Error loading embeddings from {json_key}: {e}")
    
        self.logger.info(f"Collected {len(training_embeddings)} embeddings for model {full_model_key}.")
        return training_embeddings, metadata        

    def embeddings_batch(self, model_keys):
        summary_status = []
        for model_key in model_keys:
            model_info = self.config["model_options"][model_key]
            dim = model_info["dimensions"]
            full_model_key = f"{model_info['id']}_{dim}"
            log_path = get_model_log_path(full_model_key)
            with open(log_path, "w") as log_file:
                log_to_file(log_file, f"📘 Starting threading indexing for {full_model_key}")
                training_embeddings, metadata = self.collect_embeddings_and_metadata(full_model_key)
                sample_threshold = suggest_training_sample_count(len(training_embeddings), max_samples=self.config["num_training_samples"])
                if len(training_embeddings) < sample_threshold:
                    msg = f"❌ Not enough vectors for {full_model_key}. Found: {len(training_embeddings)}"
                    log_to_file(log_file, msg, "error")
                    summary_status.append({
                        "Model": full_model_key,
                        "Vectors Indexed": 0,
                        "FAISS Index Folder": "N/A",
                        "Error": msg
                    })
                    continue
                training_data = np.vstack(training_embeddings).astype(np.float32)
                faiss.omp_set_num_threads(multiprocessing.cpu_count())
                self.index_create(training_data, model_key, metadata)
                log_to_file(log_file, f"✅ Saved index for {full_model_key} with {training_data.shape[0]} vectors")

    # 📦 Index Management & Validation ----------------------------------------
    def index_load(self, model_key):
        model_info = self.config["model_options"][model_key]
        model_id = model_info["id"]
        expected_dim = model_info["dimensions"]
        index_key = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_id.replace(':', '_')}_{expected_dim}.faiss"
        try:
            response = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_key)
            index_bytes = response["Body"].read()
            index = faiss.deserialize_index(index_bytes)
            if not index.is_trained or index.d != expected_dim or index.ntotal == 0:
                self.logger.warning(f"⚠️ FAISS index for {model_key} is invalid. Rebuilding...")
                self.rebuild_faiss_index(model_key)
                return self.index_load(model_key)
            self.logger.info(f"✅ Loaded FAISS index for {model_key} from S3")
            return index
        except Exception as e:
            self.logger.warning(f"⚠️ No existing FAISS index for {model_key}: {e}. Rebuilding...")
            self.rebuild_faiss_index(model_key)
            return self.index_load(model_key)

    def get_index_status(self):
        status = []
        for model_key, model_info in self.config["model_options"].items():
            model_id = model_info["id"]
            dim = model_info["dimensions"]
            index_key = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_id.replace(':', '_')}_{dim}.faiss"
            def repair():
                self.embeddings_batch([model_key])
            try:
                response = self.s3_client.head_object(Bucket=self.config["bucket_name"], Key=index_key)
                last_modified = response["LastModified"].strftime("%Y-%m-%d %H:%M")
                obj = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_key)
                index_bytes = obj["Body"].read()
                index = faiss.deserialize_index(index_bytes)
                badge = "🟢" if index.is_trained and index.ntotal > 0 else "🟡" if index.is_trained else "🔴"
                status.append({
                    "Model": model_key,
                    "Trained": index.is_trained,
                    "Vectors": index.ntotal,
                    "Dim": index.d,
                    "Status": badge,
                    "LastModified": last_modified,
                    "Repair": repair
                })
            except Exception as e:
                status.append({
                    "Model": model_key,
                    "Trained": False,
                    "Vectors": 0,
                    "Dim": dim,
                    "Status": "🔴",
                    "LastModified": "N/A",
                    "Error": str(e),
                    "Repair": repair
                })
        return status

    def index_real(self, model_key):
        """Check if index file exists in S3 for given model_key."""
        model_info = self.config["model_options"].get(model_key)
        if not model_info:
            return False
        dim = model_info["dimensions"]
        index_file = f"{model_key}_{dim}.faiss"
        s3_keys = list_objects_s3(self.config["bucket_name"], f"{self.config['prefix']}/{self.config['index_folder']}")
        return f"{self.config['prefix']}/{self.config['index_folder']}/{index_file}" in s3_keys

    def index_empty(self, model_key):
        """
        Placeholder: Index files missing embeddings or with invalid vectors.
    
        TODO:
            - Identify documents missing the specified model_key embedding.
            - Optionally trigger auto-embedding or mark for reprocessing.
        """
        pass

    def validate_and_embed_missing_vectors(self, model_keys, vectorizer, clients, show_ui=True):
        """
        Validate that all expected embeddings exist for each model_key.
        If missing, generate and upload embeddings.
    
        Args:
            model_keys (List[str]): List of selected model keys.
            vectorizer (AmazonEmbeddingVectorizer or compatible): Embedding generator.
            clients (ClientBundle): Contains config and S3 client.
            show_ui (bool): If True, shows Streamlit status and messages.
        """
        config = clients.config
        s3_client = clients.s3
    
        bucket = config["bucket_name"]
        json_folder = config["json_folder"]
    
        json_keys = list_objects_s3(bucket, json_folder, extension=".json")
        if not json_keys:
            if show_ui:
                st.warning(f"⚠️ No JSON files found in `{json_folder}`.")
            return
    
        if show_ui:
            st.info(f"🔍 Validating {len(json_keys)} JSON files for missing embeddings...")
    
        for json_key in json_keys:
            try:
                obj = s3_client.get_object(Bucket=bucket, Key=json_key)
                content = obj["Body"].read().decode("utf-8").strip()
                if not content:
                    if show_ui:
                        st.warning(f"⚠️ Empty file: `{json_key}` — skipping.")
                    continue
    
                data = json.loads(content)
                modified = False
    
                for model_key in model_keys:
                    model_info = config["model_options"].get(model_key)
                    if not model_info:
                        continue
    
                    model_id = model_info["id"]
                    dim = model_info["dimensions"]
                    full_key = f"{model_id}_{dim}"
    
                    vector = data.get("embeddings", {}).get(full_key, {}).get("vector")
                    if vector and len(vector) == dim:
                        continue  # Already embedded correctly
    
                    text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])
                    if is_blank_page(text, data.get("chunks", [])):
                        if show_ui:
                            st.info(f"⏭️ Skipping blank page: `{json_key}`")
                        continue
    
                    new_vector = vectorizer.generate_embedding(text)
    
                    data.setdefault("embeddings", {})[full_key] = {
                        "dimensions": dim,
                        "embed_date": current_timestamp(),
                        "vector": new_vector
                    }
    
                    modified = True
    
                if modified:
                    s3_client.put_object(
                        Bucket=bucket,
                        Key=json_key,
                        Body=json.dumps(data, indent=2).encode("utf-8"),
                        ContentType="application/json"
                    )
                    if show_ui:
                        st.success(f"✅ Updated embeddings for `{json_key}`")
    
            except json.JSONDecodeError as e:
                if show_ui:
                    st.warning(f"⚠️ JSON error in `{json_key}`: {e}")
            except Exception as e:
                if show_ui:
                    st.warning(f"⚠️ Error in `{json_key}`: {e}")


    # 🔍 Index Search & Query ----------------------------------------
    def search_by(self, model_key: str, query_embedding: np.ndarray, k: int = 5) -> list:
        try:
            index = self.index_load(model_key)
            if query_embedding.ndim == 1:
                query_embedding = query_embedding.reshape(1, -1)
            if query_embedding.shape[1] != index.d:
                raise ValueError(f"Query embedding dim {query_embedding.shape[1]} ≠ index dim {index.d}")
            distances, indices = index.search(query_embedding, k)
            results = []
            for rank, (idx, dist) in enumerate(zip(indices[0], distances[0])):
                if idx == -1:
                    continue
                results.append({
                    "rank": rank + 1,
                    "index": int(idx),
                    "distance": float(dist)
                })
            self.logger.info(f"🔍 FAISS search completed for model '{model_key}' with {len(results)} results")
            return results
        except Exception as e:
            self.logger.error(f"❌ Error during FAISS search for model '{model_key}': {e}")
            return []



# 🔍 Standalone Top-K Search ----------------------------------------




# ⏱️ Utility Functions ----------------------------------------
def current_timestamp():
    return datetime.utcnow().isoformat() + "Z"
