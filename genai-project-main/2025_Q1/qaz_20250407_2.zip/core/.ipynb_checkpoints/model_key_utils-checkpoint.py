# core/model_key_utils.py

def validate_model_key(model_key: str, model_options: dict) -> str:
    """
    Validate the provided model_key against available options.
    """
    if not isinstance(model_key, str):
        raise TypeError(f"Model key must be a string, got: {type(model_key)}")
    if model_key not in model_options:
        raise ValueError(
            f" Invalid model_key: '{model_key}'. "
            f"Available options are: {list(model_options.keys())}"
        )
    return model_key


def find_model_key_by_id(model_id: str, dimensions: int, model_options: dict) -> str:
    """
    Find the model_key in model_options given a model_id and dimensions.
    """
    for key, val in model_options.items():
        if val["id"] == model_id and val["dimensions"] == dimensions:
            return key
    return None


def get_model_details(model_key: str, model_options: dict) -> dict:
    """
    Retrieve model details from provided model_options.
    """
    if not isinstance(model_key, str):
        raise TypeError("model_key must be a string.")
    if model_key not in model_options:
        return None
    model_info = model_options[model_key]
    return {
        "model_key": model_key,
        "id": model_info["id"],
        "dimensions": model_info["dimensions"],
        "full_model_key": f"{model_info['id']}_{model_info['dimensions']}"
    }

def get_index_filename(model_key: str) -> str:
    """
    Generate FAISS index filename based on model key.
    """
    model = get_model_details(model_key)
    if not model:
        raise ValueError(f"Model key '{model_key}' not found in config.")
    return f"faiss_index_{model['full_model_key'].replace(':', '_')}.faiss"

def get_faiss_s3_key(model_key: str, prefix: str = None) -> str:
    """
    Generate S3 key for saving FAISS index.
    """
    model = get_model_details(model_key)
    if not model:
        raise ValueError(f"Model key '{model_key}' not found in config.")
    index_name = get_index_filename(model_key)
    model_folder = f"{model['model_key']}/{model['dimensions']}"
    return f"{prefix}/{model_folder}/{index_name}".strip("/")
