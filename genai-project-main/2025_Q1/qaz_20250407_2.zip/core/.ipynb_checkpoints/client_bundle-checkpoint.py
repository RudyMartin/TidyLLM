# core/client_bundle.py

from core.config_helper import get_config, get_clients

class ClientBundle:
    def __init__(self, config=None):
        self.config = config or get_config()
        self.s3, self.bedrock = get_clients(self.config)

def get_client_bundle():
    return ClientBundle()