import os
import logging
import boto3  # just in cas
import numpy as np
import streamlit as st
import json
import logging
from datetime import datetime
from threading import Lock

from core.config_helper import get_config
from core.client_bundle import get_clients
from core.model_key_utils import (
    validate_model_key,
    find_model_key_by_id,
    get_model_details,
)
from core.logging_helper import get_logger


# Global fallback values (4x redundant with cache below)
config_default = get_config()
s3_default, bedrock_default = get_clients(config_default)

logger = logging.getLogger(__name__)

class AmazonEmbeddingVectorizer:
    def __init__(self, config=config_default, s3_client=s3_default, bedrock_client=bedrock_default, selected_model_option=None, dimensions=None):
        self._config = config
        self._bedrock_client = bedrock_client  # Initialize _bedrock_client
        self._s3_client = s3_client # Initialize _s3_client
        selected = self._select_model(config, selected_model_option)

        self.model_id = selected["id"]
        if "anthropic" in self.model_id:
            raise ValueError(f"{self.model_id} does not support embeddings.")

        self.dimensions = dimensions or selected["dimensions"]

        if self._bedrock_client is None:
            logger.info("Initializing Bedrock client...")
            try:
                self._bedrock_client = boto3.client('bedrock-runtime', region_name='us-east-1')  # Corrected client initialization
                logger.info("✅ Bedrock client initialized.")
            except Exception as e:
                logger.error(f"❌ Failed to initialize Bedrock client: {e}")
                raise ValueError("Failed to initialize Bedrock client.") from e

        if not self._bedrock_client:
            logger.error("❌ Missing Bedrock client. Cannot generate embeddings.")
            raise ValueError("Missing Bedrock client. Cannot generate embeddings.")

        logger.info(f"Using Amazon Bedrock model: {self.model_id} with dimensions={self.dimensions}")


        if self._s3_client is None:
            logger.info("Initializing S3 client...")
            try:
                self._s3_client = boto3.client('s3')
                logger.info("✅ S3 client initialized.")
            except Exception as e:
                logger.error(f"❌ Failed to initialize S3 client: {e}")
                raise ValueError("Failed to initialize S3 client.") from e

        if not self._s3_client:
            logger.error("❌ Missing S3 client. Cannot save embeddings.")
            raise ValueError("Missing S3 client. Cannot save embeddings.")

        logger.info("✅ S3 client initialized and active.")

    def generate_embedding(self, text, normalize=True, force=False):
        # Lowercase "body" fix
        body = {}
        if "amazon.titan-embed-text-v2" in self.model_id:
            body = {"inputText": text, "dimensions": int(self.dimensions)}
        elif "amazon.titan-embed-text-v1" in self.model_id:
            body = {"inputText": text}
        elif "cohere" in self.model_id:
            limit = self.config.get("cohere_limit", 2048)
            trimmed = text[:limit]
            body = {"texts": [trimmed], "input_type": "search_document"}
        else:
            raise ValueError(f"Unknown or unsupported model type: {self.model_id}")

        try:
            logger.info(f"🚀 Requesting embedding from Bedrock model: {self.model_id} | dims: {self.dimensions}")
            response = self.bedrock_boto3.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body)
            )
            
            if "body" not in response:
                logger.error("❌ Bedrock response missing 'body'. Check model ID or permissions.")
                return None
            
            raw_body = response["body"].read().decode("utf-8")
            response_body = json.loads(raw_body)
        except Exception as e:
            logger.error(f"❌ Bedrock invoke_model failed: {e}", exc_info=True)
            raise

        embedding = response_body.get("embedding") or (response_body.get("embeddings") or [None])[0]
        if not embedding:
            logger.warning("⚠️ No embedding found in Bedrock response.")
            raise ValueError("No embedding found in response.")

        if normalize:
            embedding = self._normalize_vector(embedding)

        logger.info(f"✅ Embedding retrieved: {len(embedding)} dimensions.")
        return embedding

    def _select_model(self, config, model_key=None):
        model_options = config.get("model_options", {})
        model_key = model_key or config.get("default_model_option", "titan_v2")
        validated_key = validate_model_key(model_key, model_options)
        return model_options[validated_key]

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    @classmethod
    def from_config(cls, config, bedrock_client=None):
        if not bedrock_client:
            _, bedrock_client = get_clients(config)
        return cls(config=config, bedrock_client=bedrock_client)

# ---------- Cached Vectorizer ----------
@st.cache_resource
def get_cached_vectorizer():
    config = get_config()
    _, bedrock_client = get_clients(config)
    return AmazonEmbeddingVectorizer.from_config(config, bedrock_client=bedrock_client)