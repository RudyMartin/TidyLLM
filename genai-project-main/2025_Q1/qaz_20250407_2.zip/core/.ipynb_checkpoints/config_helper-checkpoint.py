"""
[File: config_helper.py]
Description: Loads, saves, and manages the configuration settings from a JSON file.
Initializes AWS clients and provides configuration utilities.

TODO:
  - Add update/delete functions for individual configuration keys.
  - Validate configuration keys on update.

FUTURE:
  - Integrate persistent storage (e.g., S3 or a database) for configuration versioning and rollback.
  - Build an interactive admin UI for config CRUD operations.
"""

import os
import json
import boto3
import logging
from datetime import datetime
import streamlit as st

from core.logging_helper import *

logger = logging.getLogger(__name__)

# ---------- Paths ----------
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "config.json")
DEFAULT_CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "default_config.json")
LOG_DIR = os.path.join(PROJECT_DIR, "logs")


# ---------- Config Utilities ----------

# ✅ Safe for CLI: Patch session_state for non-Streamlit-run environments
if not isinstance(st.session_state, dict):
    st.session_state = {}
    print("Patched st.session_state to a plain dict.")


def initialize_config_cli():
    """
    CLI-safe initializer. Loads configuration from config/config.json
    and stores it in st.session_state["CONFIG"] if not already present.
    
    This should be used in CLI utilities (e.g., debug_admin_pdf.py)
    instead of the normal Streamlit lifecycle.
    """
    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "config.json")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        if "CONFIG" not in st.session_state:
            st.session_state["CONFIG"] = config
            print("CONFIG initialized in session_state (CLI mode).")
        else:
            print("CONFIG already exists in session_state.")
    except Exception as e:
        print(f"Failed to load configuration: {e}")


# ✅ CLI-safe version of get_config()
def get_config_cli():
    """
    Returns the CONFIG from session_state, using fallback if not present.
    """
    try:
        return st.session_state["CONFIG"]
    except Exception:
        initialize_config_cli()
        return st.session_state["CONFIG"]


def load_config(path: str) -> dict:
    """Loads a JSON config file from disk."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r") as f:
        return json.load(f)

def get_config(force_reload=False, path_override=None):
    """Return the active configuration, loading it into Streamlit session if needed."""
    import streamlit as st

    config_path = path_override or CONFIG_PATH
    if force_reload or "CONFIG" not in st.session_state:
        st.session_state["CONFIG"] = load_config(config_path)
    return st.session_state["CONFIG"]



def save_config(config, path=CONFIG_PATH):
    """Save configuration to a JSON file."""
    try:
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
        logger.info(f" Config saved to {path}")
    except Exception as e:
        logger.error(f" Failed to save config to {path}: {e}")


def restore_default_config():
    """Restore the default configuration."""
    return load_config(DEFAULT_CONFIG_PATH)


def log_config_change(action, config_data):
    """Log any change to the configuration."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_message = {
        "action": action,
        "timestamp": timestamp,
        "config_data": config_data
    }
    log_file = os.path.join(LOG_DIR, f"config_change_{timestamp}.json")
    try:
        with open(log_file, "w") as f:
            json.dump(log_message, f, indent=2)
        logger.info(f" Config {action} logged to: {log_file}")
    except Exception as e:
        logger.error(f" Failed to log config change: {e}")



def get_clients(config):
    """
    Initialize and return AWS clients, cached via Streamlit session state.
    """
    import streamlit as st
    if "s3_client" not in st.session_state or "bedrock_client" not in st.session_state:
        region = config.get("region_name", "us-east-1")
        st.session_state["s3_client"] = boto3.client("s3", region_name=region)
        st.session_state["bedrock_client"] = boto3.client("bedrock-runtime", region_name=region)
    return st.session_state["s3_client"], st.session_state["bedrock_client"]

def reload_config():
    """Force reload from disk and update session state."""
    import streamlit as st
    st.session_state["CONFIG"] = load_config(CONFIG_PATH)
    return st.session_state["CONFIG"]