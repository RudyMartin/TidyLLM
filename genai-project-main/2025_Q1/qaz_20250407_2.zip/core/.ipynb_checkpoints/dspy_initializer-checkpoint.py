# core/dspy_initializer.py

from core.embedding_manager import get_cached_vectorizer

def init_dspy_embedding_vectorizer():
    """
    Returns the shared cached vectorizer for DSPy pipelines.
    """
    return get_cached_vectorizer()

# Usage:
# vectorizer = init_dspy_embedding_vectorizer()