# core/pgvector_store.py

import psycopg2
import json
import numpy as np
from datetime import datetime

from core.model_key_utils import (
    validate_model_key,
    get_model_details,
    get_index_filename,     # optional if you're going to mimic FAISS naming
    get_faiss_s3_key,       # optional if needed for S3 persistence
)
from core.embedding_helper import AmazonEmbeddingVectorizer
from core.logging_helper import get_logger
from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = get_logger("pgvector_store")
logger.setLevel("DEBUG")

class PGVectorStore:
    def __init__(self, config, s3_client):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger  # use module-level logger

class PGVectorStore:
    def __init__(self, config, s3_client, logger):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger
        self.conn = psycopg2.connect(self.config["pgvector_conn_string"])
        self.cur = self.conn.cursor()

   
    # 🏗️ Index Creation & Training ----------------------------------------
    ## assumes you create a table  of vector_indexes
    def list_indexes(self):
        query = "SELECT model_key, table_name, dimension, created_at FROM vector_indexes"
        with self.pg_conn.cursor() as cur:
            cur.execute(query)
            rows = cur.fetchall()
            return [
                {
                    "ModelKey": row[0],
                    "TableName": row[1],
                    "Dimension": row[2],
                    "CreatedAt": row[3].isoformat() if hasattr(row[3], "isoformat") else str(row[3])
                }
                for row in rows
            ]
    
    def index_create(self, embeddings, model_key, metadata=None):
        """
        Create and store embeddings in PGVector.
        """
        try:
            self.logger.info(f"❓ Creating PGVector index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            self.logger.info(f"⚙️ Preparing to insert {vector_count} embeddings with dimension {dim}")
            for i in range(vector_count):
                self.cur.execute("""
                    INSERT INTO model_embeddings (model_key, embedding, metadata)
                    VALUES (%s, %s, %s)
                """, (model_key, embeddings[i].tobytes(), json.dumps(metadata[i]) if metadata else None))
            self.conn.commit()
            self.logger.info(f"✅ PGVector index created and embeddings added for {model_key}")
        except Exception as e:
            self.logger.error(f"❌ Error creating PGVector index for {model_key}: {e}")
            raise


    def embeddings_batch(self, model_keys):
       ## todo pgvector batch embedding

    
    # 📦 Index Management & Validation ----------------------------------------
    def index_load(self, model_key):
        """
        Check if the PGVector index exists for a given model_key.
        """
        try:
            self.cur.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM pg_catalog.pg_attribute WHERE attname = 'embedding' AND attrelid = (
                        SELECT oid FROM pg_catalog.pg_class WHERE relname = 'model_embeddings')
                );
            """)
            exists = self.cur.fetchone()[0]
            if not exists:
                self.logger.warning(f"⚠️ PGVector index for {model_key} does not exist. Rebuilding...")
                self.rebuild_pgvector_index(model_key)
            else:
                self.logger.info(f"✅ PGVector index for {model_key} is valid.")
        except Exception as e:
            self.logger.warning(f"⚠️ Error checking PGVector index for {model_key}: {e}")
            self.rebuild_pgvector_index(model_key)

    def get_index_status(self):
        """
        Get the status of PGVector indexes (whether they are valid).
        """
        status = []
        try:
            self.cur.execute("SELECT model_key, COUNT(*) FROM model_embeddings GROUP BY model_key;")
            results = self.cur.fetchall()
            for row in results:
                model_key = row[0]
                num_embeddings = row[1]
                status.append({
                    "Model": model_key,
                    "Indexed Embeddings": num_embeddings,
                    "Status": "🟢" if num_embeddings > 0 else "🔴"
                })
        except Exception as e:
            self.logger.error(f"❌ Error fetching PGVector index status: {e}")
        return status

    def index_real(self, model_key):
        """
        Placeholder: Index files with confirmed real embeddings.
    
        TODO:
            - Check vector presence and validate vector length against expected model dimension.
            - Only include entries that match the correct shape.
        """
        pass
    
    def index_empty(self, model_key):
        """
        Placeholder: Index files missing embeddings or with invalid vectors.
    
        TODO:
            - Identify documents missing the specified model_key embedding.
            - Optionally trigger auto-embedding or mark for reprocessing.
        """
        pass
        
    def validate_and_embed_missing_vectors(self, model_keys, vectorizer, clients, show_ui=True):
        """
        Validate and embed missing vectors for the given model_keys.
    
        TODO:
            - Enhance logic to perform dimensionality checks on existing vectors.
            - Validate that existing vectors match the expected size before skipping.
            - Optionally log mismatches and auto-repair corrupted entries.
        """
        pass

    def search_by(self, model_key: str, query_embedding: np.ndarray, k: int = 5):
        """
        Perform a search query on the PGVector database.
        """
        try:
            self.cur.execute("""
                SELECT embedding, metadata FROM model_embeddings
                WHERE model_key = %s
                ORDER BY embedding <-> %s
                LIMIT %s;
            """, (model_key, query_embedding.tobytes(), k))
            results = self.cur.fetchall()
            return [{
                "rank": i + 1,
                "distance": float(result[0]),  # Assume <-> is used for distance sorting
                "metadata": result[1]
            } for i, result in enumerate(results)]
        except Exception as e:
            self.logger.error(f"❌ Error during PGVector search for model '{model_key}': {e}")
            return []



# ⏱️ Utility Functions  ----------------------------------------

def current_timestamp():
    return datetime.utcnow().isoformat() + "Z"       