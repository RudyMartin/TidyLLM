# core/vector_manager.py


"""
Vector Manager

Abstract interface for managing vector operations across multiple backends.
Currently supports 'faiss' and 'pgvector', with room for extensions.
"""
import numpy as np
import logging

from core.logging_helper import get_logger, get_model_log_path, log_to_file

from core.config_manager import (
    get_config,
    get_client_bundle,
    get_model_details,
)

from core.client_bundle import get_client_bundle


clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

# --- Logging and Settings ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

class VectorManager:
    def __init__(self, store_type="faiss", config=None, clients=None):
        """
        Args:
            store_type (str): The vector backend to use ("faiss", "pgvector", etc.)
            config (dict): Optional configuration dictionary
            clients (object): Optional shared client bundle (s3, bedrock, pg, etc.)
        """
        self.store_type = store_type
        self.config = config or get_config()
        self.clients = clients or get_client_bundle()

        self.logger = get_logger("vector_manager")  # MUST be before _init_store()

        self.index_store = self._init_store()

    def _init_store(self):
        if self.store_type == "faiss":
            from core.faiss_store import FaissStore
            return FaissStore(self.config, self.clients.s3, self.logger) 
        elif self.store_type == "pgvector":
            from core.pgvector_store import PgVectorStore
            ## differs from above -  todo adjust later
            return PgVectorStore(self.config, self.clients)
        else:
            raise ValueError(
                f"Unsupported vector store: {self.store_type}. Supported stores: ['faiss', 'pgvector']"
            )

    # ---------- Embedding Validation & Indexing ----------
    def validate_and_embed_missing(self, selected_models, vectorizer, force=False, show_ui=True):
        return self.index_store.validate_and_embed_missing_vectors(
        model_keys=selected_models,
        vectorizer=vectorizer,
        clients=self.clients,
        force=force,  # Pass 'force' here
        show_ui=show_ui,
    )

    def index_batch(self, model_keys):
        return self.index_store.embeddings_batch(model_keys)

    def build_index_from_vectors(self, vectors, model_key):
        return self.index_store.create_faiss_index_from_embeddings(vectors, model_key)

    # ---------- Index Health ----------
    def get_index_status(self):
        return self.index_store.get_index_status()

    def get_index_stats(self):
        return self.index_store.get_vector_statistics()

    def index_health_summary(self):
        return self.index_store.health_summary()

    # ---------- Maintenance ----------
    def reset_index(self, model_key):
        return self.index_store.reset(model_key)

    def delete_index(self, model_key):
        return self.index_store.delete(model_key)

    def list_available_indexes(self):
        return self.index_store.list_indexes()

    # ---------- Optional (Advanced Validation) ----------
    def validate_model_embeddings(self, model_key, log_to_repair_list=False):
        if hasattr(self.index_store, "validate_json_embeddings"):
            return self.index_store.validate_json_embeddings(model_key, log_to_repair_list)
        else:
            raise NotImplementedError(
                f"{self.store_type} does not support embedding validation."
            )
