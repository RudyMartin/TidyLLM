"""
[File: core/faiss_log_writer.py]
Version: DSPy 2.5.26

Description:
  Writes structured audit logs into a FAISS vector store for retrieval, analysis, or model comparison.

Requires:
  - core/vector_manager.py
  - Audit entries to include: text, metadata, timestamp, signature hash

Supports:
  - Configurable model_key per audit
  - Embedding caching or re-generation
"""
import pandas as pd
import time
import hashlib
from datetime import datetime
import json

from core.vector_manager import VectorManager
from core.logging_helper import get_logger
from core.client_bundle import get_client_bundle
from core.s3_utils import list_objects_s3, load_json_from_s3  # Added imports

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = get_logger("faiss_log_writer")

def generate_signature(text: str) -> str:
    """Returns a SHA-256 hash for identifying a specific audit result."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def build_audit_vector_entry(text: str, audit_result: dict, metadata: dict = None) -> dict:
    """
    Packages audit result and metadata for vector store insertion.

    Args:
        text (str): The full input used during the audit.
        audit_result (dict): DSPy reasoning or comparison output.
        metadata (dict): Optional dictionary with project_name, section_name, etc.

    Returns:
        dict: Fully structured vector entry.
    """
    return {
        "text": text,
        "metadata": {
            "signature": generate_signature(text),
            "timestamp": datetime.utcnow().isoformat(),
            "result": audit_result,
            **(metadata or {})
        }
    }

def write_to_faiss(text: str, audit_result: dict, metadata: dict = None, model_key: str = "titan_v2") -> bool:
    """
    Embeds and stores an audit record in the FAISS vector store.

    Args:
        text (str): Raw input or section text.
        audit_result (dict): Resulting DSPy or similarity audit info.
        metadata (dict): Optional context info (section name, project, etc.)
        model_key (str): Which embedding model to use for indexing (short model key).

    Returns:
        bool: Success or failure.
    """
    try:
        vector_entry = build_audit_vector_entry(text, audit_result, metadata)
        manager = VectorManager(store_type="faiss")
        vectorizer = manager.clients.vectorizer
        embedding = vectorizer.generate_embedding(text)
        manager.index_store.add_vectors([embedding], [vector_entry], model_key=model_key)
        logger.info(f"✅ FAISS audit log written: {metadata.get('section_name', 'N/A')}")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to write audit result to FAISS: {e}")
        return False

def load_faiss_logs_as_df(log_store_path: str) -> pd.DataFrame:
    """
    Loads the FAISS audit logs from S3 and converts them into a DataFrame.

    Args:
        log_store_path (str): The S3 path (prefix) where FAISS logs are stored.

    Returns:
        pd.DataFrame: A DataFrame containing the audit logs.
    """
    try:
        # Use the shared s3_client and bucket from config
        response = s3_client.list_objects_v2(Bucket=config["bucket_name"], Prefix=log_store_path)
        log_files = [obj['Key'] for obj in response.get('Contents', [])]

        log_data = []
        for log_file in log_files:
            obj = s3_client.get_object(Bucket=config["bucket_name"], Key=log_file)
            log_content = obj['Body'].read().decode('utf-8')
            # Expecting each log file to contain a JSON list of log entries
            log_entries = json.loads(log_content)
            log_data.extend(log_entries)

        df = pd.json_normalize(log_data)
        if df.empty:
            logger.warning(f"No FAISS logs found in {log_store_path}")
        return df

    except Exception as e:
        logger.error(f"Error loading FAISS logs from S3: {e}")
        return pd.DataFrame()

# Optional CLI for testing the FAISS log writer functionality.
if __name__ == "__main__":
    sample_text = "Example audit text for FAISS log writer."
    sample_audit_result = {"status": "passed", "details": "All checks successful."}
    success = write_to_faiss(sample_text, sample_audit_result, metadata={"section_name": "Audit Section 1"}, model_key="titan_v2")
    print("Write to FAISS:", "Success" if success else "Failure")
