"""
[File: core/config_manager.py]

Description:
High-level configuration coordination layer.
Safe to use in tabs, pipelines, vector managers, and embedding agents.
Avoid importing this from lower-level core utilities.
"""

import logging
from core.client_bundle import get_client_bundle

from core.config_helper import (
    get_config,
    get_clients,
    reload_config,
)

from core.model_key_utils import (
    validate_model_key,
    get_model_details,
    get_index_filename,
    get_faiss_s3_key,
    find_model_key_by_id,
)

from core.embedding_helper import get_cached_vectorizer  # ✅ FIXED: import from correct module


# --- Logging and Settings ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# ---------- Public Accessors ----------
__all__ = [
    "get_config",
    "get_clients",
    "get_client_bundle",
    "get_cached_vectorizer",
    "validate_model_key",
    "get_model_details",
    "get_index_filename",
    "get_faiss_s3_key",
    "find_model_key_by_id",
    "reload_config",
]
