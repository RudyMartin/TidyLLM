'''
[File: truth_synthesizer_tab.py]
Version: DSPy 2.5.26 - Truth Synthesizer Tab

Description:
Streamlit tab that lets users upload guideline or policy documents
and generate structured ground truth statements using DSPy. These
truths are then stored for later use in auditing model development plans.
'''

# --- Standard Library Imports ---
import logging
import json
from datetime import datetimeimport

# --- Project-level Imports ---
from core.logging_helper import get_logger
from dspy_signature_uploader import extract_text_from_pdf, extract_text_from_docx, extract_text_from_json
from dspy_truth_generator import generate_truth_statements  # new DSPy function for truth synthesis
from core.faiss_utils import store_truth_embeddings

# --- Logging and Context Settings ---
logger = get_logger("truth_synthesizer_tab")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
DEFAULT_SAVE_PATH = os.path.join(ROOT_DIR, "truth_outputs")
os.makedirs(DEFAULT_SAVE_PATH, exist_ok=True)


def render():
    st.header("🔍 Truth Synthesizer - Ground Truth from Guidelines")
    st.markdown(
        """
        Upload modeling guidelines (PDF, DOCX, or JSON) to extract authoritative
        ground truth statements for auditing model development plans.
        These statements will be stored and indexed for fast access during audits.
        """
    )

    uploaded_file = st.file_uploader("Upload Guideline Document:", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()
        if ext == "pdf":
            raw_text = extract_text_from_pdf(uploaded_file)
        elif ext == "docx":
            raw_text = extract_text_from_docx(uploaded_file)
        elif ext == "json":
            raw_text = extract_text_from_json(uploaded_file)
        else:
            st.error("Unsupported file type.")
            return

        st.text_area("Extracted Text", raw_text[:3000], height=250)

        if st.button("🚀 Generate Truth Statements"):
            with st.spinner("Running DSPy to extract structured truths..."):
                truth_records = generate_truth_statements(raw_text)
                saved_path = os.path.join(DEFAULT_SAVE_PATH, f"truth_{uploaded_file.name}.json")
                with open(saved_path, "w") as f:
                    json.dump(truth_records, f, indent=2)
                store_truth_embeddings(truth_records)  # store in FAISS

            st.success("Truth synthesis complete!")
            st.markdown(f"Saved: `{saved_path}`")
            st.json(truth_records[:3])  # preview only


if __name__ == "__main__":
    render()
