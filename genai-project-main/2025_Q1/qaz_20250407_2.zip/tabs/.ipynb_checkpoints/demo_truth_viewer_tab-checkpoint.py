"""
[File: tabs/demo_truth_viewer_tab.py]
Version: DSPy 2.5.26 - Truth Viewer Tab (Demo)

Description:
  Streamlit tab to explore the full set of groundtruth records used
  for evaluating Model Development Plans.
  
  Allows users to browse, filter, and understand the criteria used
  for audit comparisons.
"""

# --- Standard Library Imports ---
import os
import json
import streamlit as st
import pandas as pd
import logging

# --- Project-level Imports ---
from core.logging_helper import get_logger

# --- Logging and Context Settings ---
logger = logging.getLogger(__name__)

ROOT_DIR = os.getenv("ROOT_DIR", ".")
TRUTH_PATH = os.path.join(ROOT_DIR, "groundtruth", "model_development.json")

def render():
    st.header("🔍 Groundtruth Viewer - Audit Criteria")

    if not os.path.exists(TRUTH_PATH):
        st.warning("Groundtruth file not found. Please upload or generate it.")
        return

    try:
        with open(TRUTH_PATH, "r") as f:
            truth_data = json.load(f)

        df = pd.DataFrame(truth_data)
        st.markdown("### 📚 Groundtruth Entries")
        st.dataframe(df, use_container_width=True)

        section_filter = st.selectbox("Filter by Section", ["All"] + sorted(df["section"].unique()))

        if section_filter != "All":
            df = df[df["section"] == section_filter]

        for i, row in df.iterrows():
            with st.expander(f"{row['section']} #{i+1}"):
                st.markdown("**Expected Insight:**")
                st.info(row['output'])
                if row.get("input"):
                    st.markdown("**Sample Input:**")
                    st.code(row['input'])

    except Exception as e:
        logger.error(f"Failed to load groundtruth viewer: {e}")
        st.error("Could not load or display the groundtruth records.")

if __name__ == "__main__":
    render()
