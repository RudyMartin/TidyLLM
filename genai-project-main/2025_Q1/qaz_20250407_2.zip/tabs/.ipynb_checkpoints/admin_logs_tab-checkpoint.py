"""
[File: tabs/admin_logs_tab.py]
Version: Simplified Log Viewer (2025-04)

Description:
  Streamlit tab to view log files and perform cleanup. 
  Log type filtering temporarily disabled.
"""

# --- Standard Library Imports ---
import logging
import streamlit as st
import os

from collections import Counter

# --- Project-level Imports ---
from core.logging_helper import (
    list_log_files,
    read_log_file,
    cleanup_logs,
    get_logger
)
from core.s3_utils import list_pdf_files_s3, list_json_files_s3,  list_s3_files_with_extension


from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

# --- Logging and Context Settings ---
logger = logging.getLogger(__name__)
logger = get_logger("logs_tab")

# -- Optional: Filter session state disabled
# if "log_type_filter" not in st.session_state:
#     st.session_state.log_type_filter = "ALL"

def render():
    st.header("📊 Logs & Diagnostics")
    st.markdown("View available log files and clean up old entries.")

    # st.markdown("### 🧪 Debug: S3 Raw Listing Test")

    # try:
    #     bucket = config["bucket_name"]
    #     prefix = "dev/pdf/arxiv_wellsfargo/"  # Replace if needed
    
    #     response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
    #     keys = [obj["Key"] for obj in response.get("Contents", [])]
        
    #     if not keys:
    #         st.warning("⚠️ No keys found under this prefix.")
    #     else:
    #         st.success(f"✅ Found {len(keys)} objects.")
    #         st.write(keys[:10])  # Limit to first 10 results
    
    # except Exception as e:
    #     st.error(f"❌ Failed to list objects: {e}")
    
    if st.button("🧹 Cleanup All Logs"):
        result = cleanup_logs()
    
        if result.get("error"):
            st.error(f"❌ Cleanup failed: {result['error']}")
        else:
            if result["removed"]:
                st.success(f"✅ Removed {len(result['removed'])} logs.")
            if result["failed"]:
                st.error(f"❌ Failed to delete: {[f for f, _ in result['failed']]}")
            if result["remaining"]:
                st.warning("⚠️ Cleanup attempted but logs remain:")
                st.code("\n".join(result["remaining"]))
            else:
                st.success("🧼 All logs successfully removed.")

    # 🔄 Refresh list AFTER cleanup
    log_files = list_log_files()


    selected_log = st.selectbox("📄 Select log file:", sorted(log_files, reverse=True))
    # log_type = st.radio("🧪 Filter by Type", ["ALL", "INFO", "WARNING", "ERROR"], index=0, key="log_type_filter")

    if selected_log:
        try:
            raw = read_log_file(selected_log)
            log_content = raw if isinstance(raw, str) else str(raw)

            # -- Entry counting still works
            entry_counts = Counter()
            for line in log_content.splitlines():
                if "[INFO]" in line:
                    entry_counts["INFO"] += 1
                elif "[WARNING]" in line:
                    entry_counts["WARNING"] += 1
                elif "[ERROR]" in line:
                    entry_counts["ERROR"] += 1

            st.markdown("### 🔢 Entry Counts")
            cols = st.columns(3)
            cols[0].metric("INFO", entry_counts.get("INFO", 0))
            cols[1].metric("WARNING", entry_counts.get("WARNING", 0))
            cols[2].metric("ERROR", entry_counts.get("ERROR", 0))

            # -- Disabled filtering for now
            # if log_type != "ALL":
            #     log_content = "\n".join(
            #         line for line in log_content.splitlines() if f"[{log_type}]" in line
            #     )

            st.markdown("### 📜 Log Content")
            st.text_area("Log Output", value=log_content, height=400)

        except Exception as e:
            st.error(f"❌ Error loading log file: {e}")
            logger.error(f"Error reading log file {selected_log}: {e}")

if __name__ == "__main__":
    render()
