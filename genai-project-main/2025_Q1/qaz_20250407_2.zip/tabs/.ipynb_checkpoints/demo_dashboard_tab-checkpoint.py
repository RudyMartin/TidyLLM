"""
# [File: tabs/demo_dashboard_tab.py]
Version: DSPy 2.5.26 - Demo Dashboard Tab

Description:
  Streamlit tab to summarize audit history and trends using stored FAISS logs.
  Visualizes recent activity, average section scores, and document-level stats.
Fixing the Demo Logic:
Let's separate the FAISS Index functionality and the FAISS Log functionality.

FAISS Index (for querying and storing vector embeddings):

Use FaissStore for managing FAISS indexes.

Create or load the FAISS index from S3 and perform vector similarity searches.

FAISS Logs (for tracking operations on the index):

Create separate logs when performing actions like embedding indexing, failure, or success logs, and store these logs in S3.

"""

# --- Standard Library Imports ---
import os
import streamlit as st
import pandas as pd
import logging

# --- Project-level Imports ---
from core.logging_helper import get_logger
from core.faiss_log_reader import load_faiss_log_as_df

# --- Logging and Settings ---
logger = logging.getLogger(__name__)

LOG_STORE_PATH = os.getenv("LOG_STORE_PATH", "faiss_logs")

def render():
    st.header("📊 Audit Dashboard - Activity & Scores")

    try:
        df = load_faiss_log_as_df(LOG_STORE_PATH)

        if df.empty:
            st.info("No audit logs available yet.")
            return

        st.markdown("### 📈 Summary Statistics")
        st.metric("Total Audits", len(df))
        st.metric("Average Similarity", round(df["similarity"].mean(), 2))

        st.markdown("### 🧾 Recent Audit Entries")
        st.dataframe(df.sort_values("timestamp", ascending=False).head(10))

        st.markdown("### 📌 Section-Level Scores")
        section_scores = df.groupby("section")["similarity"].mean().sort_values(ascending=False)
        st.bar_chart(section_scores)

    except Exception as e:
        logger.error(f"Dashboard rendering failed: {e}")
        st.error(f"Failed to load dashboard: {e}")
