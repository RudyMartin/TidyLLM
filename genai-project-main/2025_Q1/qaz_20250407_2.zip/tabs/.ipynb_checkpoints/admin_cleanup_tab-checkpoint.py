# tabs/cleanup_tab.py

import streamlit as st
import logging

from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    extract_text_from_pdf,
    save_extracted_text_to_json,
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import list_pdf_files_s3, list_json_files_s3,  list_s3_files_with_extension


clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

logger = logging.getLogger(__name__)

def cleanup_ingestion_folders(s3_client, config, dry_run: bool = True):
    bucket = config["bucket_name"]
    pages_folder = config["page_folder"]
    json_folder = config["json_folder"]
    pdf_folder = config["pdf_folder"]

   # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(bucket, pages_folder,"pdf")
    pdf_keys = list_s3_files_with_extension(bucket, pdf_folder,"pdf")
    json_keys = list_s3_files_with_extension(bucket, json_folder,"json")

    total_files = len(page_keys) + len(json_keys)

    if dry_run:
        st.info("**Dry Run Mode:** No files will be deleted. Here's what would be removed.")
        
        st.markdown(f"### PDF files to delete: `{len(page_keys)}`")
        st.write(page_keys or "No PDF files found.")

        st.markdown(f"### JSON files to delete: `{len(json_keys)}`")
        st.write(json_keys or "No JSON files found.")

        st.info(f"Total files identified for deletion: `{total_files}`")
    else:
        deleted = {"pdfs": 0, "jsons": 0}
        with st.spinner("Deleting files..."):
            for key in page_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["pdfs"] += 1

            for key in json_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["jsons"] += 1

        st.success(f"Cleanup complete: {deleted['pdfs']} PDF pages and {deleted['jsons']} JSONs removed.")


def render():
    st.header("Cleanup: Ingestion Artifacts")
    st.markdown(
        """
        Use this tool to remove intermediate **PDF pages** and **JSON chunk files** 
        from S3 after a successful FAISS indexing run.
        """
    )

    # Use the globally defined config and s3_client
    bucket = config["bucket_name"]
    pages_folder = config["page_folder"]
    json_folder = config["json_folder"]
    pdf_folder = config["pdf_folder"]

    # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(bucket, pages_folder,"pdf")
    pdf_keys = list_s3_files_with_extension(bucket, pdf_folder,"pdf")
    json_keys = list_s3_files_with_extension(bucket, json_folder,"json")

    st.info(f"Found `{len(page_keys)}` page PDFs and `{len(json_keys)}` JSONs ready for cleanup.")

    # Provide checkboxes for a dry run and confirmation.
    dry_run = st.checkbox("Preview files (dry run)", value=True)
    confirm = st.checkbox("Yes, I want to delete the above files permanently.")

    if st.button("Run Cleanup Now"):
        if not confirm and not dry_run:
            st.warning("Please confirm deletion to proceed.")
        else:
            cleanup_ingestion_folders(s3_client, config, dry_run=dry_run)

