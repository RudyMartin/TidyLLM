"""
[File: guided_search_tab.py]
Version: Streamlit UX Split (2025-04) DSPy 2.5.26
Description: Provides the UI for guided search and groundtruth selection. 
Now split into two visual modes with enhanced UX.

Tabs:
  - 📄 Document Picker: Choose by category and run DSPy.
  - 🧠 Topic Search: (Coming soon) semantic filtering and clustering.
"""

import streamlit as st
from dsai.dspy_pipeline_controller import run_pipeline
from core.init_context import get_tab_context

def render():
    st.header("🧭 Guided Search & Groundtruth Tools")
    mode = st.radio("Select Mode", options=["📄 Document Picker", "🧠 Topic Search"], index=0)

    if mode == "📄 Document Picker":
        render_document_picker()
    else:
        render_topic_search()

def render_document_picker():
    st.subheader("📄 Groundtruth by Document Category")

    st.markdown(
        """
        Select groundtruth examples from your **risk management** documents.
        Categories include:
        - **Strategic** – Long-term direction and goals
        - **Operational** – Day-to-day execution risks
        - **Technical** – Infrastructure, software, and architecture

        You may select up to **5 documents per category**.
        """
    )

    clients, config, *_ = get_tab_context()
    risk_categories = config.get("risk_categories", ["Strategic", "Operational", "Technical"])
    risk_category = st.selectbox("📂 Select Category", options=risk_categories)

    dummy_docs = [f"{risk_category}_doc_{i}" for i in range(1, 11)]
    selected_docs = st.multiselect("📑 Select Documents (max 5)", options=dummy_docs)

    if len(selected_docs) > config.get("max_groundtruth_docs", 5):
        st.warning("⚠️ Please select no more than 5 documents.")

    st.divider()
    st.markdown("### 🔍 DSPy Query Inputs")

    query = st.text_input("🧠 Query", "Sample query to validate report")
    report = st.text_area("📋 Report", "Initial report content here...")
    details = st.text_area("🛠️ Project Details", "Project details here...")

    if st.button("🚀 Run DSPy Pipeline"):
        result = run_pipeline(query, report, details)
        st.subheader("✅ Query Results")
        st.json(result["query_result"])
        st.subheader("📝 Corrected Report")
        st.text_area("Corrected Report", value=result["corrected_report"], height=300)

        if result.get("signature_info"):
            st.subheader("🔐 Document Signature & Reasoning")
            st.json(result["signature_info"])


def render_topic_search():
    st.subheader("🧠 Topic-Based Search (Coming Soon)")
    st.info("Explore your knowledge base using embeddings and clustering. This feature is under development.")





if __name__ == "__main__":
    render()
