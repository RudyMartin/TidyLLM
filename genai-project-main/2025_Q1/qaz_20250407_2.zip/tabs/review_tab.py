'''
[File: tabs/review_tab.py]
Version: Demo v1 – DSPy 2.5.26

Description:
  Streamlit tab to validate an uploaded document against predefined groundtruth criteria
  for model governance (Strategic, Operational, Technical). Uses DSPy to highlight
  alignment, gaps, and provide AI-based suggestions.
'''

# --- Standard Library Imports ---
import logging
import json
import streamlit as st
from datetime import datetimeimport
from pathlib import Path
import hashlib

# --- Project-level Imports ---
from core.logging_helper import get_logger
from dspy_signature_uploader import extract_text_from_pdf, extract_text_from_docx, extract_text_from_json
from dspy_truth_generator import generate_truth_statements  # new DSPy function for truth synthesis
from core.faiss_utils import store_truth_embeddings

# --- Logging Settings ---
logger = logging.getLogger(__name__)

# --  dspy-specific activities
from dspy import Example, Module, Predict, Signature, InputField, OutputField
from dspy_signature_uploader import extract_text_from_pdf, extract_text_from_docx, extract_text_from_json


# --- DSPy Signature ---
class ReviewSignature(Signature):
    document = InputField()
    criteria = InputField()
    assessment = OutputField(desc="Summary of alignment or gaps")

# --- DSPy Module ---
class DocumentReviewModule(Module):
    def __init__(self):
        super().__init__()
        self.reviewer = Predict(ReviewSignature)

    def forward(self, document, criteria):
        return self.reviewer(document=document, criteria=criteria)

# --- Load groundtruth from file ---
def load_groundtruth_examples(category):
    filepath = Path("groundtruth") / f"{category.lower()}_groundtruth.json"
    if not filepath.exists():
        return []
    with open(filepath, "r") as f:
        data = json.load(f)
    return data.get("examples", [])

# --- Simple scoring logic ---
def validate_against_groundtruth(text, groundtruth_list):
    matched = []
    missed = []
    for item in groundtruth_list:
        if item.lower() in text.lower():
            matched.append(item)
        else:
            missed.append(item)
    return matched, missed

# --- Render Tab ---
def render():
    st.header("📋 Review a Document Against Model Risk Criteria")

    uploaded_file = st.file_uploader("Upload a PDF, DOCX, or JSON report:", type=["pdf", "docx", "json"])
    category = st.selectbox("Select Groundtruth Category:", ["Strategic", "Operational", "Technical"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()

        if ext == "pdf":
            text = extract_text_from_pdf(uploaded_file)
        elif ext == "docx":
            text = extract_text_from_docx(uploaded_file)
        elif ext == "json":
            text = extract_text_from_json(uploaded_file)
        else:
            st.error("Unsupported file type.")
            return

        st.text_area("📄 Extracted Text", text[:2000], height=200)

        groundtruth = load_groundtruth_examples(category)
        if not groundtruth:
            st.warning("No groundtruth found for this category.")
            return

        matched, missed = validate_against_groundtruth(text, groundtruth)
        st.markdown(f"### ✅ Matches: {len(matched)} / {len(groundtruth)}")
        st.success("\n".join(matched) if matched else "No matches")

        if missed:
            st.markdown("### ⚠️ Missing Items")
            st.error("\n".join(missed))

        # Run DSPy for explanation
        module = DocumentReviewModule()
        result = module(document=text, criteria="\n".join(missed))
        st.markdown("### 🧠 AI Assessment")
        st.text_area("Assessment", result.assessment, height=250)

if __name__ == "__main__":
    render()
