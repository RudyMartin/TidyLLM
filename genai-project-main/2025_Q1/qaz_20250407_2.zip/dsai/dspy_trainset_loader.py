# [File: dsai/trainset_loader.py]
# Version: DSPy 2.5.26

from dspy import Example

def get_trainset():
    return [
        Example(risk_query="What are the top risks in AI adoption?",
                insights="Lack of governance, misaligned goals, ethical concerns, and model drift."),
        Example(risk_query="What are operational risks in cloud transformation?",
                insights="Downtime, vendor lock-in, unexpected cost spikes, and change resistance.")
    ]

def get_testset():
    return [
        Example(risk_query="What are technical risks in microservices migration?",
                insights="Service sprawl, monitoring complexity, and inconsistent interfaces.")
    ]

def evaluate_pipeline_metric(example, pred, trace=None):
    # Very simple string match scoring
    return float(example.insights.lower() in pred.insights.lower())
