'''
[File: dspy_signature_s3_reader.py]
Version: DSPy 2.5.26

Description:
  Reads a PDF file from S3, generates a SHA-256 hash to uniquely fingerprint the document content,
  and uses DSPy to explain the context or purpose of the document.

NOTE: In DSPy v2.5.26, there is no global `compile()` function. 
      You must use the optimizer's `.compile()` method directly.

TODO:
  - Persist signature + reasoning metadata back to S3 or database.
  - Allow batch mode for multiple files.
'''

import hashlib
import logging
from io import BytesIO
import boto3
from PyPDF2 import PdfReader
from dspy import Module, Predict, Signature, InputField, OutputField

from core.logging_helper import get_logger

logger = get_logger("signature_s3_reader")

# === DSPy Signature ===
class DocumentReasoningSignature(Signature):
    document = InputField()
    reasoning = OutputField(desc="AI-generated explanation of the document's purpose or content.")

# === DSPy Module ===
class DocumentReasoningModule(Module):
    def __init__(self):
        super().__init__()
        self.reasoner = Predict(DocumentReasoningSignature)

    def forward(self, document):
        return self.reasoner(document=document)

def read_pdf_from_s3(bucket: str, key: str) -> str:
    """
    Downloads a PDF from S3 and extracts its text.
    """
    try:
        s3 = boto3.client("s3")
        response = s3.get_object(Bucket=bucket, Key=key)
        pdf_stream = BytesIO(response['Body'].read())
        reader = PdfReader(pdf_stream)
        full_text = "\n\n".join([page.extract_text() or "" for page in reader.pages])
        return full_text.strip()
    except Exception as e:
        logger.error(f"Failed to read or parse PDF from S3: {e}")
        return ""

def generate_signature_and_reasoning(text: str) -> dict:
    try:
        signature = hashlib.sha256(text.encode("utf-8")).hexdigest()
        logger.info(f"Generated SHA-256 signature: {signature[:10]}...")

        module = DocumentReasoningModule()
        output = module(document=text)
        reasoning = output.reasoning
        logger.info("DSPy reasoning successfully generated.")

        return {
            "signature": signature,
            "reasoning": reasoning
        }

    except Exception as e:
        logger.error(f"Failed to generate signature and reasoning: {e}")
        return {
            "signature": None,
            "reasoning": f"Error: {e}"
        }

# Example usage
if __name__ == "__main__":
    bucket = "your-bucket-name"
    key = "path/to/your/document.pdf"

    logger.info("Reading PDF from S3...")
    text = read_pdf_from_s3(bucket, key)

    if text:
        result = generate_signature_and_reasoning(text)
        print("--- Result ---")
        print(f"SHA256: {result['signature']}")
        print(f"Reasoning: {result['reasoning']}")
    else:
        print("Failed to process the document.")
