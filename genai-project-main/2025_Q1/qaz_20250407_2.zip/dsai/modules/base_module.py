"""
[File: dsai/modules/base_module.py]
Version: DSPy 2.5.26

Description:
  A generic base DSPy Module that dynamically accepts any Signature definition.
  This allows reuse for multiple reasoning tasks by swapping signatures.
"""

from dspy import Module, Predict

class DynamicDSPyModule(Module):
    def __init__(self, signature_cls):
        super().__init__()
        self.signature_cls = signature_cls
        self.predict = Predict(signature_cls)

    def forward(self, **kwargs):
        return self.predict(**kwargs)