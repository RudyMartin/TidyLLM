'''
[File: dspy_signature_txt_reader.py]
Version: DSPy 2.5.26

Description:
  Reads *.txt files from a local folder (ROOT_DIR/docs), generates a SHA-256 hash
  to uniquely fingerprint the content, and uses DSPy to explain the document's purpose.

NOTE:
  - This script expects .txt files (UTF-8 encoded).
  - Uses DSPy v2.5.26 Predict + Signature approach (no compile()).
'''

import os
import hashlib
import logging
from dspy import Module, Predict, Signature, InputField, OutputField
from core.logging_helper import get_logger

logger = get_logger("signature_txt_reader")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
DOCS_PATH = os.path.join(ROOT_DIR, "docs")

# === DSPy Signature ===
class DocumentReasoningSignature(Signature):
    document = InputField()
    reasoning = OutputField(desc="AI-generated explanation of the document's purpose or content.")

# === DSPy Module ===
class DocumentReasoningModule(Module):
    def __init__(self):
        super().__init__()
        self.reasoner = Predict(DocumentReasoningSignature)

    def forward(self, document):
        return self.reasoner(document=document)

def generate_signature_and_reasoning(text: str) -> dict:
    try:
        signature = hashlib.sha256(text.encode("utf-8")).hexdigest()
        logger.info(f"Generated SHA-256: {signature[:10]}...")
        module = DocumentReasoningModule()
        output = module(document=text)
        return {
            "signature": signature,
            "reasoning": output.reasoning
        }
    except Exception as e:
        logger.error(f"Reasoning failed: {e}")
        return {"signature": None, "reasoning": f"Error: {e}"}

def process_txt_documents():
    logger.info(f"Scanning folder: {DOCS_PATH}")
    for filename in os.listdir(DOCS_PATH):
        if filename.endswith(".txt"):
            filepath = os.path.join(DOCS_PATH, filename)
            try:
                with open(filepath, "r", encoding="utf-8") as file:
                    content = file.read().strip()
                print(f"\n===== {filename} =====")
                result = generate_signature_and_reasoning(content)
                print(f"SHA-256: {result['signature'][:10]}... | Reasoning:\n{result['reasoning'][:300]}...")
            except Exception as e:
                logger.error(f"Error processing {filename}: {e}")

if __name__ == "__main__":
    process_txt_documents()
