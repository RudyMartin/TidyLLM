"""
[File: dspy_query_processing.py]
Version: DSPy 2.5.26

Description:
  Processes user queries using DSPy in the risk management domain.
  - Generates an embedding for the query.
  - Retrieves similar documents/insights via vector store (e.g., FAISS or pgvector).
  - Constructs a risk-specific prompt and processes it with a DSPy module.
  - Optimizes the prompt using BootstrapFewShot.

NOTE: In DSPy v2.5.26, there is no global `compile()` function. 
      You must use the optimizer’s `.compile()` method directly.
"""

import logging
from dspy import BootstrapFewShot
# DO NOT use: `from dspy import compile` in v2.5.26

from core.vector_manager import VectorManager
from core.logging_helper import get_logger
from dsai.modules.risk_module import RiskInsightModule

logger = get_logger("dspy_query_processing")

# Few-shot training examples
EXAMPLES = [
    {
        "risk_query": "What are the top risks in cloud migration?",
        "insights": "Key risks include data loss, latency issues, cost overruns, and compliance failures."
    },
    {
        "risk_query": "What are strategic risks in AI adoption?",
        "insights": "Lack of governance, misaligned goals, ethical concerns, and model drift."
    },
    {
        "risk_query": "What are technical risks in implementing Kubernetes?",
        "insights": "Misconfigured clusters, poor scaling, security gaps, and high operational complexity."
    }
]

def process_query(query: str, model_key: str = "titan_v2") -> dict:
    """
    Processes a user query using DSPy pipeline.

    Args:
        query (str): The user query.
        model_key (str): Model config used for embedding & indexing.

    Returns:
        dict: {
            "query": str,
            "dspy_result": str,
            "retrieved_docs": list
        }
    """
    try:
        # Step 1: Init vector manager and vectorizer
        manager = VectorManager(store_type="faiss")
        vectorizer = manager.clients.vectorizer
        query_embedding = vectorizer.generate_embedding(query)
        logger.info("Embedding generated.")

        # Step 2: Retrieve similar documents
        retrieved_docs = manager.index_store.retrieve_similar(query_embedding, model_key=model_key, top_k=5)
        logger.info(f"Retrieved {len(retrieved_docs)} documents for FAISS search.")

        # Step 3: Construct DSPy prompt
        dspy_prompt = (
            f"Risk Management Query: Given the query '{query}' and the following similar documents: "
            f"{retrieved_docs}, what are the key insights regarding potential risks, mitigation strategies, "
            "and operational impacts?"
        )
        logger.info("Constructed DSPy prompt.")

        # Step 4: DSPy compilation using BootstrapFewShot
        module = RiskInsightModule()
        booster = BootstrapFewShot()
        compiled_module = booster.compile(
            module,
            trainset=EXAMPLES,
            max_bootstrapped_demos=3
        )
        output = compiled_module(risk_query=dspy_prompt)
        dspy_result = output.insights
        logger.info("DSPy module compiled and executed.")

    except Exception as e:
        logger.error(f"Error in query processing pipeline: {e}")
        return {
            "query": query,
            "dspy_result": "Error occurred during processing.",
            "retrieved_docs": []
        }

    return {
        "query": query,
        "dspy_result": dspy_result,
        "retrieved_docs": retrieved_docs
    }

if __name__ == "__main__":
    test_query = "What are the key risks in the project?"
    result = process_query(test_query)
    print("DSPy Query Processing Output:")
    print(result)
