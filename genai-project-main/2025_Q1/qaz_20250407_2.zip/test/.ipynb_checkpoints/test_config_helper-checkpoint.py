import json
from core.config_helper import (
    get_config,
    get_model_details,
    get_index_filename,
    get_faiss_s3_key,
    validate_model_key,
    load_config,
    save_config,
    restore_default_config,
    log_config_change,
)

def run_all_tests():
    print(" Running config_helper tests...\n")

    # Test 1: Load config
    config = get_config()
    assert isinstance(config, dict), " get_config() did not return a dictionary"
    print(" Config loaded")

    # Test 2: Validate a known model key
    default_key = config.get("default_model_option", "titan_v2")
    model_key = validate_model_key(default_key, config["model_options"])
    assert model_key == default_key, " validate_model_key failed"
    print(f" Model key validated: {model_key}")

    # Test 3: Get model details
    model_details = get_model_details(model_key)
    assert model_details and "id" in model_details, " get_model_details returned incomplete data"
    print(f" Model details: {model_details}")

    # Test 4: Generate FAISS index filename
    faiss_file = get_index_filename(model_key)
    assert faiss_file.endswith(".faiss"), " Index filename format error"
    print(f" FAISS filename: {faiss_file}")

    # Test 5: Generate FAISS S3 key
    s3_key = get_faiss_s3_key(model_key, prefix="dev/idx")
    assert model_key in s3_key, " S3 key does not contain model_key"
    print(f" FAISS S3 key: {s3_key}")

    # Test 6: Save config
    config_copy = config.copy()
    config_copy["test_field"] = "test_value"
    save_config(config_copy)
    reloaded = load_config()
    assert reloaded.get("test_field") == "test_value", " Config save/load failed"
    print(" Config save/load verified")

    # Test 7: Restore default config (non-destructive check)
    default_config = restore_default_config()
    assert isinstance(default_config, dict), " restore_default_config failed"
    print(" Default config restored (loaded)")

    # Test 8: Log a dummy config change
    try:
        log_config_change("test_action", {"foo": "bar"})
        print(" Config change logged")
    except Exception as e:
        print(f" Logging config change failed: {e}")

    print("\n All config_helper tests completed.")


if __name__ == "__main__":
    run_all_tests()
