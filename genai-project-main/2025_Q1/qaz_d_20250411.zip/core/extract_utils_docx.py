"""
[File: core/extract_utils_docx.py]
Description: Handles Word-to-text extraction from S3-stored .docx files.
"""

import os
import io
from typing import Dict
import nltk
from docx import Document
from core.config_helper import get_config
from core.text_cleaning import clean_text
import logging

logger = logging.getLogger(__name__)

def extract_text_from_docx(page_key: str, config=None, s3_client=None, next_page_key: str = None) -> Dict:
    """Extracts text from .docx in S3. Based on extract_text_from_pdf_page_s3."""
    config = config or get_config()
    s3_client = s3_client or config.get("s3")

    try:
        bucket = config["bucket_name"]
        response = s3_client.get_object(Bucket=bucket, Key=page_key)
        doc_file = response["Body"].read()
        doc = Document(io.BytesIO(doc_file))

        text = "\n".join([p.text for p in doc.paragraphs if p.text.strip()])
        text = clean_text(text)
        page_number = 1  # .docx files are not paginated like PDFs

        # Optional: continuity recovery from next file
        if next_page_key:
            try:
                next_response = s3_client.get_object(Bucket=bucket, Key=next_page_key)
                next_doc = Document(io.BytesIO(next_response["Body"].read()))
                next_text = "\n".join([p.text for p in next_doc.paragraphs if p.text.strip()])
                if validate_page_continuity(text, next_text):
                    text += " " + nltk.sent_tokenize(next_text)[0]
            except Exception as e:
                logger.warning(f"Next page continuity failed: {e}")

        return {
            "document_name": os.path.basename(page_key),
            "page_number": page_number,
            "text": text.strip()
        }

    except Exception as e:
        logger.error(f"❌ Extract text from docx failed: {e}")
        return {"page_number": None, "text": ""}


__all__ = [
    "extract_text_from_docx"
]  
