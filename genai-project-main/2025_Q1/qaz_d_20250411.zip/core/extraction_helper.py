"""
[File: extraction_helper.py]
Description: Handles PDF-to-text extraction and structured JSON output.
"""

from core.config_helper import get_config
from core.s3_utils import (
    list_objects_s3,
    list_folders_s3,
    list_pdf_files_s3,
    list_json_files_s3,
    check_s3_object_tag,
    load_json_from_s3,
    save_json_to_s3,
    upload_to_s3,
    delete_s3_object,
)

from core.text_cleaning import (
    clean_text,
    clean_text_for_display 
)

import unicodedata
import os
import re
import io
import json
import logging
from pathlib import Path
from datetime import datetime
from functools import lru_cache
from typing import List, Dict
import nltk
from PyPDF2 import PdfReader, PdfWriter

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

LOG_DIR = "logs/indexing"
Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

@lru_cache(maxsize=1)
def ensure_nltk():
    try:
        nltk.data.find("tokenizers/punkt")
    except LookupError:
        nltk.download("punkt")

ensure_nltk()

def smart_chunking(text, max_words=200):
    sentences = nltk.sent_tokenize(text)
    chunks, current_chunk, current_length = [], [], 0

    for sentence in sentences:
        sentence_length = len(sentence.split())
        sub_sentences = (re.split(r'[;,:]|\\b(and|but|or|which|that)\\b', sentence)
                         if sentence_length > max_words else [sentence])

        for sub_sentence in [s.strip() for s in sub_sentences if s]:
            sub_length = len(sub_sentence.split())
            if current_length + sub_length > max_words:
                chunks.append(" ".join(current_chunk))
                current_chunk, current_length = [], 0
            current_chunk.append(sub_sentence)
            current_length += sub_length

    if current_chunk and len(" ".join(current_chunk).split()) > 5:
        chunks.append(" ".join(current_chunk))
    return chunks

def chunk_text_into_segments(pdf_page_data: Dict, max_words: int = None, config=None) -> List[Dict]:
    config = config or get_config()
    try:
        max_words = max_words or config["chunk_size"]
        text = pdf_page_data.get('text', '')
        if not text.strip():
            return []

        page_number = pdf_page_data.get("page_number", 1)
        document_name = pdf_page_data.get("document_name", "unknown.pdf").replace(".pdf", "")

        chunks = []
        for i, chunk_text in enumerate(smart_chunking(text, max_words)):
            chunks.append({"chunk_id": f"{document_name}_{page_number}_{i+1:03d}", "text": chunk_text})
        return chunks

    except Exception as e:
        logger.error(f" Error chunking text: {e}")
        return []


def save_page_chunks_as_json_s3(original_key: str, chunks: List[Dict], config, s3_client):
    try:
        bucket = config["bucket_name"]
        json_folder = config["json_folder"]
        document_name = os.path.splitext(os.path.basename(original_key))[0]
        match = re.search(r'_page_(\d+)', original_key)
        page_number = match.group(1) if match else "unknown"

        text_date = datetime.now().isoformat()

        page_json_structure = {
            "metadata": {
                "document_name": document_name,
                "page_number": page_number,
                "text_date": text_date,
                "tags": []
            },
            "chunks": chunks,
            "embeddings": {}
        }

        if not re.search(r'_page_\d+', document_name):
            document_name = f"{document_name}_page_{page_number}"

        chunk_key = f"{json_folder}/{document_name}.json"
        s3_client.put_object(Bucket=bucket, Key=chunk_key, Body=json.dumps(page_json_structure).encode('utf-8'))
        logger.info(f"✅ Saved chunks for {document_name} at {chunk_key}")

    except Exception as e:
        logger.error(f"❌ Error saving chunks for {original_key}: {e}")

def prepare_pdf_splits(config=None, s3_client=None):
    config = config or get_config()
    s3_client = s3_client or get_config().get("s3")
    count = 0
    try:
        pdf_keys = [k for k in list_objects_s3(config["bucket_name"], config["pdf_folder"]) if k.endswith(".pdf")]
        for key in pdf_keys:
            split_pdf_into_pages_s3(key, config, s3_client)
            count += 1
        return count
    except Exception as e:
        logger.error(f"❌ PDF split failed: {e}")
        return count

def split_pdf_into_pages_s3(pdf_key: str, config, s3_client, pages_per_file: int = None, pdf_password: str = None):
    try:
        bucket = config["bucket_name"]
        pages_folder = config["page_folder"]
        pages_per_file = pages_per_file or config.get("pages_per_file", 1)
        pdf_password = pdf_password or config.get("pdf_password")

        response = s3_client.get_object(Bucket=bucket, Key=pdf_key)
        pdf_bytes = response["Body"].read()
        reader = PdfReader(io.BytesIO(pdf_bytes))

        if reader.is_encrypted:
            if pdf_password:
                reader.decrypt(pdf_password)
            else:
                logger.warning(f"PDF is encrypted and no password was given: {pdf_key}")
                return

        for page_num in range(len(reader.pages)):
            writer = PdfWriter()
            writer.add_page(reader.pages[page_num])
            output = io.BytesIO()
            writer.write(output)
            output.seek(0)
            page_key = f"{pages_folder}/{os.path.splitext(os.path.basename(pdf_key))[0]}_page_{page_num+1}.pdf"
            s3_client.put_object(Bucket=bucket, Key=page_key, Body=output.read())
            logger.info(f"📝 Uploaded split page: {page_key}")

    except Exception as e:
        logger.error(f"❌ Error splitting {pdf_key}: {e}")

def validate_page_continuity(text_current: str, text_next: str) -> bool:
    sentences = nltk.sent_tokenize(text_current)
    if sentences and not sentences[-1].endswith(('.', '!', '?')):
        return True
    return False

def is_blank_page(text: str, chunks: List[Dict] = None, min_length: int = 10) -> bool:
    return (not text or len(text.strip()) < min_length or (chunks is not None and len(chunks) == 0))

def extract_text_from_pdf_page_s3(page_key: str, config=None, s3_client=None, next_page_key: str = None) -> Dict:
    config = config or get_config()
    s3_client = s3_client or get_config().get("s3")
    try:
        bucket = config["bucket_name"]
        response = s3_client.get_object(Bucket=bucket, Key=page_key)
        pdf_file = response["Body"].read()
        reader = PdfReader(io.BytesIO(pdf_file))
        text = reader.pages[0].extract_text() or ""
        text = clean_text(text)

        page_number = int(page_key.split("_")[-1].split(".")[0])

        if next_page_key:
            try:
                next_response = s3_client.get_object(Bucket=bucket, Key=next_page_key)
                next_pdf = next_response["Body"].read()
                next_reader = PdfReader(io.BytesIO(next_pdf))
                next_text = next_reader.pages[0].extract_text() or ""
                if validate_page_continuity(text, next_text):
                    text += " " + nltk.sent_tokenize(next_text)[0]
            except Exception as e:
                logger.warning(f"Next page fetch failed: {e}")

        return {"document_name": os.path.basename(page_key), "page_number": page_number, "text": text.strip()}

    except Exception as e:
        logger.error(f"❌ Extract text failed: {e}")
        return {"page_number": None, "text": ""}

def extract_text_to_json(config=None, s3_client=None):
    config = config or get_config()
    s3_client = s3_client or get_config().get("s3")
    pages = list_objects_s3(config["bucket_name"], config["page_folder"], extension=".pdf")
    count = 0
    for i, page_key in enumerate(pages):
        next_key = pages[i + 1] if i + 1 < len(pages) else None
        pdf_data = extract_text_from_pdf_page_s3(page_key, config, s3_client, next_key)
        chunks = chunk_text_into_segments(pdf_data, config=config)
        is_blank = is_blank_page(pdf_data.get("text", ""), chunks)

        document_name = os.path.splitext(os.path.basename(page_key))[0]
        match = re.search(r'_page_(\d+)', page_key)
        page_number = match.group(1) if match else "unknown"

        if not re.search(r'_page_\d+', document_name):
            document_name = f"{document_name}_page_{page_number}"

        chunk_key = f"{config['json_folder']}/{document_name}.json"
        json_data = {
            "metadata": {
                "document_name": pdf_data.get("document_name", "unknown.pdf"),
                "page_number": page_number,
                "text_date": datetime.now().isoformat(),
                "tags": [] if not is_blank else ["#blankpage"]
            },
            "chunks": chunks if not is_blank else [],
            "embeddings": {}
        }
        s3_client.put_object(Bucket=config["bucket_name"], Key=chunk_key, Body=json.dumps(json_data).encode("utf-8"))
        logger.info(f"✅ Saved {'blank' if is_blank else 'content'}: {chunk_key}")
        count += 1
    return count

def extract_text_from_pdf():
    return extract_text_to_json()

def save_extracted_text_to_json():
    return extract_text_to_json()

__all__ = [
    "chunk_text_into_segments",
    "extract_text_from_pdf",
    "extract_text_to_json",
    "extract_text_from_pdf_page_s3",
    "is_blank_page",
    "prepare_pdf_splits",
    "save_extracted_text_to_json",
    "save_page_chunks_as_json_s3",
    "smart_chunking",
    "split_pdf_into_pages_s3",
    "validate_page_continuity"
]  
