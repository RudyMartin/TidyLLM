"""
[File: core/faiss_store.py]
Description: FAISS index management using BaseVectorStore. 
"""
import os
import faiss
import json
import logging
import numpy as np
import multiprocessing
from datetime import datetime

from core.vector_base import BaseVectorStore
from core.model_key_utils import get_model_details
from core.logging_helper import get_model_log_path, log_to_file
from core.s3_utils import list_objects_s3
from core.tuning_utils import suggest_training_sample_count, calculate_nlist, calculate_nprobe
from core.embedding_utils import data_collect
from core.faiss_utils import save_faiss_index_to_s3, load_faiss_index_from_s3, generate_signature

class FaissStore(BaseVectorStore):
    
    # vector_list → list_indexes
    def list_indexes(self):
            bucket = self.config["bucket_name"]
            prefix = self.config.get("index_folder", "idx")
            response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
            items = response.get("Contents", [])
            return [
                {"Key": item["Key"], "LastModified": str(item["LastModified"]), "Size": item["Size"]}
                for item in items
            ]
    
    # internal helper for vector_index (via reindex)
    def index_create(self, embeddings, model_key, metadata=None):
            try:
                self.logger.info(f"🔧 Creating FAISS index for model: {model_key}")
                dim = embeddings.shape[1]
                nlist = calculate_nlist(len(embeddings), self.config["nlist"])
                quantizer = faiss.IndexFlatL2(dim)
                index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_L2)
                index.train(embeddings)
                index.add(embeddings)
                save_faiss_index_to_s3(self.s3_client, self.config, model_key, index)
            except Exception as e:
                self.logger.error(f"❌ Failed to create FAISS index: {e}")
                raise
    
    # used by reindex/embeddings_batch
    def collect_embeddings_and_metadata(self, model_key, force=False):
            return data_collect(self.config, self.s3_client, model_key, self.logger,generate_fn=self.generate, force=True)
        
    
    # part of vector_index → batch helper
    def embeddings_batch(self, model_keys, force=False):
            status = []
            for model_key in model_keys:
                log_path = get_model_log_path(model_key)
                with open(log_path, "w") as log_file:
                    log_to_file(log_file, f"📘 Starting FAISS indexing for {model_key}")
                    embeddings, metadata = self.collect_embeddings_and_metadata(model_key, force=force)
                    if not embeddings:
                        log_to_file(log_file, f"⚠️ No embeddings found for {model_key}", "error")
                        status.append({"Model": model_key, "Error": "No embeddings"})
                        continue
                    vectors = np.vstack(embeddings).astype(np.float32)
                    faiss.omp_set_num_threads(multiprocessing.cpu_count())
                    self.index_create(vectors, model_key, metadata)
                    log_to_file(log_file, f"✅ Indexed {len(vectors)} vectors for {model_key}")
            return status
    
    # vector_validate → validate
    def validate(self, model_key):
        model_info = self.config["model_options"].get(model_key)
        if not model_info:
            return False
        index_file = f"{model_key}_{model_info['dimensions']}.faiss"
        s3_keys = list_objects_s3(self.config["bucket_name"], f"{self.config['prefix']}/{self.config['index_folder']}")
        return f"{self.config['prefix']}/{self.config['index_folder']}/{index_file}" in s3_keys
    
    # optional: used in health checks
    def get_index_status(self):
            results = []
            for model_key, info in self.config["model_options"].items():
                dim = info["dimensions"]
                index_path = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_key}_{dim}.faiss"
                try:
                    obj = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_path)
                    idx = faiss.deserialize_index(obj["Body"].read())
                    badge = "🟢" if idx.is_trained and idx.ntotal > 0 else "🔴"
                    results.append({"Model": model_key, "Vectors": idx.ntotal, "Status": badge})
                except Exception as e:
                    results.append({"Model": model_key, "Vectors": 0, "Status": "❌", "Error": str(e)})
            return results
    
    # vector_index → reindex dispatcher
    def reindex(self):
            keys = list(self.config.get("model_options", {}).keys())
            return self.embeddings_batch(keys, force=True)
    
    # vector_delete → not supported in FAISS yet
    def delete_index(self):
            self.logger.warning("⚠️ Delete operation not implemented for FAISS store.")
            return False
    
    # vector_load → no-op for FAISS (on-demand load)
    def load_index(self):
            self.logger.info("ℹ️ FAISS index is loaded per query from S3 — no persistent memory cache.")
            return True
    
    # vector_query → standard FAISS similarity search
    def query(self, query_embedding, top_k=3):
            index = load_faiss_index_from_s3(self.s3_client, self.config, self.config.get("default_model"))
            if not index:
                self.logger.warning("⚠️ No FAISS index loaded.")
                return []
            scores, indices = index.search(np.array([query_embedding]).astype("float32"), top_k)
            return list(zip(indices[0], scores[0]))
    
#  passes three faiss utility functions forward
__all__ = [
    "FaissStore",
    "collect_embeddings_and_metadata",
    "create_faiss_index",
    "embeddings_batch",
    "generate_signature",
    "get_index_status",
    "index_create",
    "list_indexes",
    "load_faiss_index_from_s3",
    "query",
    "reindex",
    "save_faiss_index_to_s3",
    "validate"
]