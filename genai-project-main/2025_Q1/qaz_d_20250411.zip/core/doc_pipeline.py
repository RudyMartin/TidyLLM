"""
[File: core/doc_pipeline.py]
Description: Unified pipeline for processing .pdf and .docx files into JSON page structures with optional embedding.
"""

import uuid
from datetime import datetime

from core.s3_utils import upload_to_s3
from core.extraction_helper import chunk_text_into_segments, is_blank_page
from core.embedding_manager import EmbeddingManager
from docx import Document
from io import BytesIO

# --- Entry Point ---
def upload_doc_raw(uploaded_file, config, clients):
    """Upload .pdf or .docx to S3 and return key and doc info."""
    doc_id = str(uuid.uuid4())
    ext = uploaded_file.name.split(".")[-1].lower()
    file_key = f"{config['pdf_folder']}/{doc_id}.{ext}"
    upload_to_s3(clients.s3, config['bucket_name'], file_key, uploaded_file.read())
    return file_key, doc_id, uploaded_file.name

# --- File-Type Dispatcher ---
def extract_text_from_document(file_key, file_bytes, config, clients):
    if file_key.endswith(".pdf"):
        from core.pdf_pipeline import split_pdf_into_pages, extract_text_per_page
        split_pdf_into_pages(file_key, config, clients)
        return extract_text_per_page(config, clients)
    elif file_key.endswith(".docx"):
        return extract_text_from_docx_pipeline(file_key, file_bytes, config, clients)
    else:
        raise ValueError("Unsupported file type")

# --- DOCX Extraction ---
def extract_text_from_docx_pipeline(file_key, file_bytes, config, clients):
    """Simulates a one-page JSON for .docx with basic chunking."""
    doc = Document(BytesIO(file_bytes))
    paragraphs = [p.text.strip() for p in doc.paragraphs if p.text.strip()]
    full_text = "\n".join(paragraphs)

    chunks = chunk_text_into_segments(
        text=full_text,
        config=config,
        document_name=file_key.split("/")[-1],
        page_number=1
    )

    structured_page = {
        "metadata": {
            "document_name": file_key.split("/")[-1],
            "page_number": 1,
            "text_date": datetime.utcnow().isoformat(),
            "tags": ["#blankpage"] if is_blank_page(full_text, chunks) else []
        },
        "chunks": chunks,
        "embeddings": {}
    }
    return [structured_page]

# --- Optional Embedding ---
def embed_structured_pages(pages, model_key, clients):
    manager = EmbeddingManager(clients=clients, model_key=model_key)
    for page in pages:
        for chunk in page["chunks"]:
            vector = manager.generate(chunk["text"])
            page["embeddings"][model_key] = {
                "id": manager.vectorizer.model_id,
                "dimensions": manager.vectorizer.dimensions,
                "embed_date": datetime.utcnow().isoformat() + "Z",
                "vector": vector
            }
    return pages

# --- Save Pages ---
def save_structured_pages_to_s3(pages, config, clients):
    for page in pages:
        filename = f"{uuid.uuid4().hex}.json"
        upload_to_s3(clients.s3, config["bucket_name"], config["json_folder"], filename, page)

# --- Stub Future Orchestrator ---
class DocumentPipelineOrchestrator:
    def __init__(self, config, clients):
        self.config = config
        self.clients = clients

    def run(self, uploaded_file, model_key, do_embed=True):
        key, doc_id, name = upload_doc_raw(uploaded_file, self.config, self.clients)
        file_bytes = uploaded_file.read()
        structured = extract_text_from_document(key, file_bytes, self.config, self.clients)
        if do_embed:
            structured = embed_structured_pages(structured, model_key, self.clients)
        save_structured_pages_to_s3(structured, self.config, self.clients)
        return key, len(structured)
