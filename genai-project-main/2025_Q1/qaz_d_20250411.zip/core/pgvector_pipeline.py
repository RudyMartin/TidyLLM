"""
[File: core/pgvector_pipeline.py]
Description: Pipeline stages for processing JSON chunks and indexing them into pgVector.
"""

from core.s3_utils import list_objects_s3, load_json_from_s3
from core.pgvector_helper import store_pgvector_index
from core.model_key_utils import get_model_details
import uuid
from datetime import datetime

def load_embedded_chunks(config, clients, model_key):
    """Load JSON files containing embedded vectors for a specific model key."""
    json_keys = list_objects_s3(config["bucket_name"], config["json_folder"], extension=".json")
    filtered = []

    for key in json_keys:
        data = load_json_from_s3(config["bucket_name"], key, config=config)
        if model_key in data.get("embeddings", {}):
            vec_info = data["embeddings"][model_key]
            filtered.append({
                "id": str(uuid.uuid4()),
                "vector": vec_info.get("vector"),
                "text": data.get("text", "") or " ".join(chunk["text"] for chunk in data.get("chunks", [])),
                "meta": {
                    "source": data.get("metadata", {}).get("document_name", "unknown"),
                    "page": data.get("metadata", {}).get("page_number", -1),
                    "model_key": model_key,
                    "embed_date": vec_info.get("embed_date", datetime.utcnow().isoformat())
                }
            })
    return filtered

def index_to_pgvector(chunk_vectors, config, clients, model_key):
    """Send embedded records to pgVector index."""
    model_details = get_model_details(model_key, config["model_options"])
    store_pgvector_index(
        records=chunk_vectors,
        namespace=model_details["id"],
        config=config,
        s3_client=clients.s3
    )
    return len(chunk_vectors)

def run_pgvector_pipeline(config, clients, model_key):
    """Full end-to-end pipeline to load embedded chunks and push to pgVector."""
    chunks = load_embedded_chunks(config, clients, model_key)
    return index_to_pgvector(chunks, config, clients, model_key)
