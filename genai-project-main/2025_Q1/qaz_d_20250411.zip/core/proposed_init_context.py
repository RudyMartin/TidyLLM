"""
[File: core/proposed_init_context.py]
Description: Flexible context builder for Streamlit or script mode.
Returns config, clients, and optionally model-aware vector and embedding managers.
Steps: make a backup copy  of everything and test ALL code with this (1 week effort)
"""

from typing import NamedTuple, Optional
import logging

from core.config_helper import get_config
from core.client_manager import get_clients, ClientBundle
from core.vector_manager import get_vector_manager

logger = logging.getLogger(__name__)


class TabContext(NamedTuple):
    clients: ClientBundle
    config: dict
    vector_manager: Optional[object]  # Used for FAISS, PGVector, etc.
    embed_manager: Optional[object]   # Model-specific embedder (Titan, Cohere, etc.)

    def __getattr__(self, item):
        if item in self.config:
            return self.config[item]
        if hasattr(self.clients, item):
            return getattr(self.clients, item)
        raise AttributeError(f"'{item}' not found in TabContext")


def get_tab_context(store_type: str = "faiss", model_key: Optional[str] = None, with_tools: bool = False) -> TabContext:
    """
    Returns application context including config and clients, optionally with vector and embedding managers.
    Suitable for both Streamlit UI and CLI/script use.
    """
    try:
        config = get_config()
        clients = get_clients()

        vector_manager = None
        embed_manager = None

        if with_tools:
            vector_manager = get_vector_manager(store_type=store_type)
            model_key = model_key or config.get("default_model")
            embed_manager = vector_manager.get_embedder(model_key=model_key)

        return TabContext(
            clients=clients,
            config=config,
            vector_manager=vector_manager,
            embed_manager=embed_manager
        )

    except Exception as e:
        error_msg = f"Failed to initialize application context: {str(e)}"
        logger.error(error_msg)
        raise RuntimeError(error_msg)


__all__ = [
    "TabContext",
    "get_tab_context",
]
