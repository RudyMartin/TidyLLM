"""
[File: core/embedding_manager.py]
Description: Unified EmbeddingManager that supports multiple backends (Titan, Cohere, Claude, AmazonBedrock), embedding lifecycle control, and JSON document updates.
"""

import json
from datetime import datetime
import numpy as np

from core.embedding_utils import (
    prepare_embedding_input,
    build_embedding_metadata,
    embeddings_flatten,
    data_collect
)
from core.reembed_manager import (
    reembed_flag,
    reembed_append
)

from core.extraction_helper import is_blank_page
from core.s3_utils import list_objects_s3
from core.logging_helper import get_logger
from core.model_key_utils import get_model_details
from core.client_manager import get_client_bundle
from core.embedding_backends import (
    AmazonTitanEmbedding,
    AmazonBedrockEmbedding,
    CohereEmbedding,
    AnthropicEmbedding
)

logger = get_logger("embedding_manager")

class EmbeddingManager:
    def __init__(self, clients=None, model_key=None):
        self.clients = clients or get_client_bundle()
        self.config = self.clients.config
        self.s3 = self.clients.s3
        self.bedrock = self.clients.get("bedrock")
        self.model_key = model_key or self.config.get("default_model")
        self.vectorizer = self._init_backend()

    def _init_backend(self):
        if "titan" in self.model_key:
            return AmazonTitanEmbedding(self.model_key, self.config, self.bedrock)
        elif "amazon" in self.model_key:
            return AmazonBedrockEmbedding(self.model_key, self.config, self.bedrock)
        elif "cohere" in self.model_key:
            return CohereEmbedding(self.model_key, self.config)
        elif "claude" in self.model_key:
            return AnthropicEmbedding(self.model_key, self.config)
        else:
            raise ValueError(f"Unsupported model key: {self.model_key}")

    def generate(self, text: str) -> list:
        return self.vectorizer.generate_embedding(text)

    def batch_generate(self, texts: list[str]) -> list[list[float]]:
        return self.vectorizer.batch_generate(texts)

    def flatten_embedding(self, data: dict) -> dict:
        return embeddings_flatten(data, self.model_key, self.config, logger)

    def gather_unembedded_json(self, force: bool = False):
        return data_collect(self.config, self.s3, self.model_key, logger, generate_fn=self.generate, force=force)

    def get_reembedding_queue(self):
        return reembed_flag(logger)

    def flag_for_reembedding(self, file, reason):
        return reembed_append(file, self.model_key, reason, logger)

    def embed_json_and_save(self, json_data: dict, json_key: str, force=False):
        model_details = get_model_details(self.model_key, self.config["model_options"])
        full_key = f"{model_details['id']}_{model_details['dimensions']}"

        if not force and self.model_key in json_data.get("embeddings", {}):
            logger.info(f"🔁 Skipping {json_key} — already embedded with {self.model_key}")
            return

        text = json_data.get("text", "") or " ".join(
            chunk.get("text", "") for chunk in json_data.get("chunks", [])
        )
        if not text.strip():
            logger.warning(f"⚠️ No valid text found in {json_key}, skipping embedding.")
            return

        if not self.s3:
            logger.error("❌ Missing S3 client. Cannot save embedding.")
            return

        vector = self.generate(text)
        json_data.setdefault("embeddings", {})
        json_data[self.model_key] = {
            "id": model_details["id"],
            "dimensions": model_details["dimensions"],
            "embed_date": datetime.utcnow().isoformat() + "Z",
            "vector": vector
        }

        self.s3.put_object(
            Bucket=self.config["bucket_name"],
            Key=json_key,
            Body=json.dumps(json_data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        logger.info(f"✅ Embedded and updated: {json_key} with model {self.model_key}")

# --- Exports ---
__all__ = sorted([
    "EmbeddingManager",
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "gather_unembedded_json",
    "get_cached_vectorizer",
    "get_logger",
    "get_model_details",
    "get_reembedding_queue",
    "is_blank_page",
    "list_objects_s3",
    "prepare_embedding_input",
    "reembed_append",
    "reembed_flag",
    "embed_json_and_save"
])

# Summary of Renamed Methods
# New Method	Old Name	Purpose
# gather_unembedded_json()	collect_embeddings()	Get JSONs not yet embedded
# get_reembedding_queue()	reembed_flagged()	Return list of files to re-embed
# flag_file_for_reembedding()	append_to_reembed_list()	Add file to re-embedding list with reason
# embed_json_and_save()	embed_and_update_json()	Embed + write updated file to S3
