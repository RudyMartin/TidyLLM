"""
[File: core/text_cleaning.py]
Description: good clean regex!

"""
import re
import unicodedata

def clean_text(text: str) -> str:
    text = re.sub(r'\n{2,}', '\n', text)
    text = text.replace('0.00-10', '0.00')
    text = re.sub(r'\s+', ' ', text).strip()
    text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)
    return text.strip()

def clean_text_for_display(text):
    text = unicodedata.normalize("NFKD", text)
    text = text.encode('utf-8').decode('utf-8')
    text = text.replace('0.00-10', '0.00')
    text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)
    text = re.sub(r'\s+', ' ', text).strip()
    text = re.sub(r'\n{2,}', '\n', text)
    text = text.replace("\n", " ")
    text = re.sub(r'[^\w\s.,;!?%$-]', '', text)
    return text

__all__ = [
    "clean_text",
    "clean_text_for_display"
]      