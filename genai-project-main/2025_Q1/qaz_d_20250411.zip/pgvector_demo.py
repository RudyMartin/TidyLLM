"""
[File: pgvector_demo.py]
Description: Main Streamlit app for uploading PDFs, indexing into pgVector, and searching using embedded content.
"""

import streamlit as st
from tabs_03.upload_embed_tab import show_upload_tab
#from tabs_03.index_pgvector_tab import show_index_tab
from tabs_03.doc_pgvector_chat_tab import show_word_chat_tab
from tabs_03.search_pgvector_tab import show_search_tab
from tabs_03.instructions_tab import show_instructions_tab
from tabs_03.doc_pgvector_chat_tab import show_doc_chat_tab

st.set_page_config(page_title="PGVector Demo", layout="wide")

st.sidebar.title("🔍 PGVector Demo")
tab = st.sidebar.radio("Navigate", [
    "📄 Upload & Embed PDF",
    "🏢 Index to pgVector",
    "🔎 Search",
    "🤖 Chat with Document",
    "📘 Instructions"
])

if tab == "📄 Upload & Embed PDF":
    show_upload_tab()
elif tab == "🏢 Index to pgVector":
    show_word_chat_tab()
elif tab == "🔎 Search":
    show_search_tab()
elif tab == "🤖 Chat with Document":
    show_doc_chat_tab()    
elif tab == "📘 Instructions":
    show_instructions_tab()