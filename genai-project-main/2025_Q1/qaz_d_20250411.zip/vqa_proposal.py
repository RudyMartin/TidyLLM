"""
[File: tabs/demo_vector_sanity.py]
Description: App to show full functionalityy
"""
import streamlit as st

# --- VQA: Model Risk Management Demo App ---

from tabs.section_review_tab import show_section_review_tab
from tabs.submit_draft_tab import show_submit_draft_tab
from tabs.topic_coverage_tab import show_topic_coverage_tab
from tabs.completion_stats_tab import show_completion_stats_tab
from tabs.agent_metrics_tab import show_agent_metrics_tab
from tabs.embedding_compare_tab import show_embedding_compare_tab

from tabs.admin_diagnostics_tab import show_admin_diagnostics_tab
from tabs.demo_hub_tab import show_demo_hub_tab
# Optional: Add more as scaffolds expand

st.set_page_config(page_title="VectorQA - Model Risk Manager", layout="wide")

st.sidebar.title("VectorQA Proposal 🚧")

# --- Top-Level Tabs ---
tab_group = st.sidebar.radio("Choose Module", [
    "📄 Model Pre-Review",
    "📊 Inventory & Dashboards",
    "🧠 LLM Self-Evaluation",
    "🧬 Embedding Compare",
    "🛠 Admin & Diagnostics",
    "🧭 Demo Hub"
])

# --- Second-Level Tabs (per section) ---
if tab_group == "📄 Model Pre-Review":
    subtab = st.sidebar.radio("Pre-Review Tools", [
        "Submit Draft",
        "Section Review"
    ])
    if subtab == "Submit Draft":
        show_submit_draft_tab()
    elif subtab == "Section Review":
        show_section_review_tab()

elif tab_group == "📊 Inventory & Dashboards":
    subtab = st.sidebar.radio("Dashboards", [
        "Topic Coverage",
        "Review Completion"
    ])
    if subtab == "Topic Coverage":
        show_topic_coverage_tab()
    elif subtab == "Review Completion":
        show_completion_stats_tab()

elif tab_group == "🧠 LLM Self-Evaluation":
    show_agent_metrics_tab()

elif tab_group == "🧬 Embedding Compare":
    show_embedding_compare_tab()

elif tab_group == "🛠 Admin & Diagnostics":
    show_admin_diagnostics_tab()

elif tab_group == "🧭 Demo Hub":
    show_demo_hub_tab()

st.markdown("---")
st.caption("🛑 **Disclaimer:** This is a proposal for demonstration purposes. It does not represent final functionality, implementation scope, or compliance guarantees.")
