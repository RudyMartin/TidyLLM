## 🚀 Quick Start

```bash
cd qaz (or root folder with extracted files)

python setup.py  --install --clean --check --init-dirs --restart 

should start a new streamlit session at:

{your aws or local server}/jupyterlab/default/proxy/{latest proxy}/

Example

https://oilajldpsxb7rmg.studio.us-east-1.sagemaker.aws/jupyterlab/default/proxy/8501/


Utility Functions:

    ##  to check your free memory
    free -h
    ##  and file space usage
    du -sh * | sort -h