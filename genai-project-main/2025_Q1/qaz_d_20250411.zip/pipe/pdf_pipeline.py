"""
[File: pipe/pdf_pipeline.py]
Description:
Modular PDF pipeline for preprocessing and embedding:
✅ Upload raw PDF to S3
✅ Split PDF into pages
✅ Extract text per page
✅ Chunk extracted text into segments
✅ Generate embeddings using configured model (via get_tab_context)
✅ Upload embedded chunks as a single JSON file to S3
✅ Format output using metadata + chunks + embeddings structure
✅ Unified wrapper function to run full pipeline for app tabs
"""

import uuid
from datetime import datetime

from core.s3_utils import upload_to_s3, save_json_to_s3, list_objects_s3
from core.extraction_helper import split_pdf_into_pages_s3, extract_text_to_json, chunk_text_into_segments
from core.init_context import get_tab_context

# --- Stage 1: Upload Raw PDF ---
def upload_pdf_raw(uploaded_file, config, clients):
    """Save uploaded PDF to S3 and return its key."""
    raw_pdf_key = f"{config['pdf_folder']}/{uuid.uuid4().hex}.pdf"
    upload_to_s3(clients.s3, config['bucket_name'], raw_pdf_key, uploaded_file.read())
    return raw_pdf_key

# --- Stage 2: Split into Pages ---
def split_pdf_into_pages(pdf_key, config, clients):
    """Split the uploaded PDF into individual pages and return list of page keys."""
    return split_pdf_into_pages_s3(pdf_key, config=config, s3_client=clients.s3)

# --- Stage 3: Extract Text ---
def extract_text_per_page(config, clients):
    """Extract text from each page and return list of JSON keys."""
    return extract_text_to_json(config=config, s3_client=clients.s3)

# --- Stage 4: Chunk Text into Segments ---
def chunk_json_pages(json_keys, config, clients):
    """Chunk text from extracted JSONs into segments for embedding."""
    all_chunks = []
    for key in json_keys:
        chunks = chunk_text_into_segments(key, config=config, s3_client=clients.s3)
        all_chunks.extend(chunks)
    return all_chunks

# --- Stage 5: Generate Embeddings ---
def embed_chunks(chunk_list, model_key, clients):
    """Generate embeddings using the configured model."""
    clients, config, vector_manager, embed_manager = get_tab_context()
    embedded_records = []

    for chunk in chunk_list:
        text = chunk.get("text", "")
        embedding = embed_manager.generate(text)
        embedded_records.append({
            "chunk_id": chunk.get("chunk_id"),
            "text": text,
            "embedding": embedding,
            "tags": chunk.get("tags", []),
            "metadata": {
                "document_name": chunk.get("metadata", {}).get("document_name", "unknown.pdf"),
                "page_number": chunk.get("metadata", {}).get("page_number", 1),
                "text_date": chunk.get("metadata", {}).get("text_date", datetime.utcnow().isoformat())
            }
        })

    return embedded_records

# --- Shared: Build Standard Schema Format ---
def make_standard_schema(embedded_records, model_key="titan_v2", model_id="amazon.titan-embed-text-v2", dimensions=1536):
    """Construct a structured schema with metadata, chunks, and embeddings."""
    return {
        "metadata": {
            "document_name": embedded_records[0].get("metadata", {}).get("document_name", "unknown.pdf"),
            "page_number": embedded_records[0].get("metadata", {}).get("page_number", 1),
            "text_date": embedded_records[0].get("metadata", {}).get("text_date", datetime.utcnow().isoformat()),
            "tags": embedded_records[0].get("tags", [])
        },
        "chunks": [
            {
                "chunk_id": rec["chunk_id"],
                "text": rec["text"]
            } for rec in embedded_records
        ],
        "embeddings": {
            model_key: {
                "id": model_id,
                "dimensions": dimensions,
                "embed_date": datetime.utcnow().isoformat(),
                "vector": [rec["embedding"] for rec in embedded_records]
            }
        }
    }

# --- Stage 6: Save All Chunks as One File ---
def save_embedded_chunks(embedded_records, config, clients, file_id=None, model_key="titan_v2", model_id="amazon.titan-embed-text-v2", dimensions=1536):
    """Save all embedded chunk records as a single JSON file to S3 in standard format."""
    file_id = file_id or str(uuid.uuid4())
    filename = f"{file_id}_chunks.json"

    output_json = make_standard_schema(
        embedded_records, model_key=model_key, model_id=model_id, dimensions=dimensions
    )

    save_json_to_s3(
        s3_client=clients.s3,
        bucket=config["bucket_name"],
        folder=config["json_folder"],
        filename=filename,
        json_obj=output_json
    )
    return filename

# --- Wrapper: Full Pipeline Execution ---
def run_pdf_pipeline(uploaded_file, model_key):
    """Full end-to-end PDF pipeline: upload, split, extract, chunk, embed, save."""
    clients, config, _, _ = get_tab_context()

    pdf_key = upload_pdf_raw(uploaded_file, config, clients)
    split_pdf_into_pages(pdf_key, config, clients)
    json_keys = extract_text_per_page(config, clients)
    chunks = chunk_json_pages(json_keys, config, clients)
    embedded = embed_chunks(chunks, model_key=model_key, clients=clients)
    output_file = save_embedded_chunks(embedded, config, clients, model_key=model_key)

    return output_file, len(chunks), pdf_key
