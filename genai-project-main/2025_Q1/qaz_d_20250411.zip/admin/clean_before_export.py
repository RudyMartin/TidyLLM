"""
[File: clean_before_export.py]
Description:
  This script prepares your project for export:
    1. Scans for incomplete files with markers (e.g. 'STILL NEEDS WORK', 'WIP')
    2. Removes .log files (outside protected folders like dev/)
    3. Purges .ipynb_checkpoints/ and __pycache__/ folders
    4. Sweeps away files/folders containing 'untitled', starting with 'z', logs folders, and dev folders

Usage:
  $ python clean_before_export.py
  $ python clean_before_export.py --no-clean-logs
  $ python clean_before_export.py --folder ./src --markers TODO FIXME
"""

import os
import sys
import shutil
import argparse

ROOT_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

SKIP_FOLDERS = {".git", "dev", "admin"}

def should_skip_folder(dirpath):
    return any(skip in dirpath.split(os.sep) for skip in SKIP_FOLDERS)

def should_skip_file(filepath):
    parts = filepath.replace("\\", "/").split("/")
    return any(part in SKIP_FOLDERS for part in parts)

def find_incomplete_files(folder, markers=None):
    if markers is None:
        markers = ["STILL NEEDS WORK", "WIP"]

    incomplete = []
    for root, _, files in os.walk(folder):
        if should_skip_folder(root):
            continue
        for f in files:
            full_path = os.path.join(root, f)

            if "clean_before_export.py" in full_path or "-checkpoint.py" in full_path:
                continue

            if f.endswith(".py") or f.endswith(".txt"):
                try:
                    with open(full_path, "r", encoding="utf-8") as fh:
                        content = fh.read().lower()
                        if any(marker.lower() in content for marker in markers):
                            incomplete.append(full_path)
                except Exception as e:
                    print(f"⚠️ Could not read {full_path}: {e}")
    return incomplete

def remove_logs(folder):
    removed_count = checkpoint_count = pycache_count = 0

    for root, dirs, files in os.walk(folder, topdown=False):
        for d in dirs:
            if d in {".ipynb_checkpoints", "__pycache__"}:
                path = os.path.join(root, d)
                print(f"🗑️ Removing folder: {path}")
                try:
                    shutil.rmtree(path)
                    checkpoint_count += (d == ".ipynb_checkpoints")
                    pycache_count += (d == "__pycache__")
                except Exception as e:
                    print(f"⚠️ Could not remove {path}: {e}")

        if should_skip_folder(root):
            continue

        for f in files:
            file_path = os.path.join(root, f)
            lower_name = f.lower()

            if "untitled" in lower_name or lower_name.startswith('z') or lower_name.endswith(".log"):
                print(f"Removing file: {file_path}")
                try:
                    os.remove(file_path)
                    removed_count += 1
                except Exception as e:
                    print(f"⚠️ Could not remove {file_path}: {e}")

    print(f"🗑️ Removed {removed_count} files.")
    print(f"🧼 Removed {checkpoint_count} .ipynb_checkpoints folders.")
    print(f"🧯 Removed {pycache_count} __pycache__ folders.")
    return removed_count + checkpoint_count + pycache_count

def sweep_away(target_dir):
    for root, dirs, files in os.walk(target_dir, topdown=False):
        if should_skip_folder(root):
            continue

        for d in dirs:
            dir_path = os.path.join(root, d)
            if d in {"logs", "dev"} or "untitled" in d.lower() or d.lower().startswith('z'):
                print(f"Removing folder: {dir_path}")
                shutil.rmtree(dir_path, ignore_errors=True)

        for f in files:
            file_path = os.path.join(root, f)
            lower_name = f.lower()
            if "untitled" in lower_name or lower_name.endswith(".log") or lower_name.startswith('z'):
                print(f"Removing file: {file_path}")
                try:
                    os.remove(file_path)
                except Exception as e:
                    print(f"⚠️ Could not remove {file_path}: {e}")

def main():
    script_dir = os.path.abspath(os.path.dirname(__file__))
    parent_dir = os.path.abspath(os.path.join(script_dir, ".."))

    parser = argparse.ArgumentParser(description="Clean project before export.")
    parser.add_argument("--folder", default=parent_dir, help="Root folder to scan.")
    parser.add_argument("--no-clean-logs", action="store_true", help="Skip .log cleanup.")
    parser.add_argument("--markers", nargs="*", help="Markers to check for.")
    parser.add_argument("--no-sweep", action="store_true", help="Skip sweeping unwanted files.")
    args = parser.parse_args()

    folder = os.path.abspath(args.folder)

    incomplete = find_incomplete_files(folder, markers=args.markers)
    if incomplete:
        print("🚫 These files need more work:")
        for f in incomplete:
            print("   -", os.path.relpath(f, folder))
        print("\nPlease fix these issues before exporting.")
        sys.exit(1)

    if not args.no_clean_logs:
        remove_logs(folder)

    if not args.no_sweep:
        sweep_away(folder)

if __name__ == "__main__":
    main()
