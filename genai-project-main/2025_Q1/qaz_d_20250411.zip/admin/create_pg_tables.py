"""
[File: sql/create_pg_tables.py]
Description: Script to connect to PostgreSQL and create pg_vec and pg_details tables.
Handles connection errors and avoids UnboundLocalError on failure.
"""
import psycopg2
import os

os.environ["DB_HOST"] = "somewhere.us-east-1.rds.amazonaws.com"
os.environ["DB_NAME"] = "postgres" ## note the if blank in AWS panel use default db_name
os.environ["DB_USER"] = "someone"
os.environ["DB_PASSWORD"] = "something"


import psycopg2
import os

def create_tables(db_host, db_name, db_user, db_password):
    """
    Creates the pg_vec and pg_details tables in a PostgreSQL database.

    Args:
        db_host: The hostname or IP address of the database server.
        db_name: The name of the database.
        db_user: The database username.
        db_password: The database password.
    """

    sql_commands = [
        """CREATE EXTENSION IF NOT EXISTS vector;""",  # Enable the pgvector extension FIRST
        """
        CREATE TABLE IF NOT EXISTS pg_vec (
            id UUID PRIMARY KEY,
            embedding VECTOR(1536),
            embed_time TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
        );
        """,
        """
        CREATE TABLE IF NOT EXISTS pg_details (
            id UUID PRIMARY KEY REFERENCES pg_vec(id),
            model_key TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
            document_name TEXT,
            page_number INT,
            tags TEXT[]
        );
        """
    ]

    try:
        conn = psycopg2.connect(
            host=db_host,
            database=db_name,
            user=db_user,
            password=db_password
        )
        #Autocommit required for CREATE EXTENSION
        conn.autocommit = True
        cur = conn.cursor()

        for command in sql_commands:
            cur.execute(command)

        conn.commit() #ensure commit after extension created
        print("Tables created successfully!")

    except psycopg2.Error as e:
        print(f"Error creating tables: {e}")
    finally:
        if conn:
            cur.close()
            conn.close()

if __name__ == "__main__":
    # Replace with your actual database credentials
    db_host = os.environ.get("DB_HOST")  # Or hardcode, but not recommended for security
    db_name = os.environ.get("DB_NAME")
    db_user = os.environ.get("DB_USER")
    db_password = os.environ.get("DB_PASSWORD")

    if not all([db_host, db_name, db_user, db_password]):
        print("Error: Please set the DB_HOST, DB_NAME, DB_USER, and DB_PASSWORD environment variables.")
    else:
        create_tables(db_host, db_name, db_user, db_password)


