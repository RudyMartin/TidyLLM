"""
[File: sql/create_pg_database.py]
Description: Script to add db - assumes AWS roles.
Note: Not run =  good  luck
"""

import boto3

# Initialize the RDS client
rds = boto3.client('rds')

def create_postgres_instance(db_instance_identifier, db_name, db_user, db_password, instance_class, engine_version, allocated_storage, security_group_ids):
    """
    Creates an RDS PostgreSQL instance.

    Args:
        db_instance_identifier:  The unique name for your database instance.
        db_name: The name of the database to create.
        db_user:  The master username for the database.
        db_password: The password for the master user.
        instance_class:  The instance type (e.g., 'db.t3.micro').
        engine_version:  The PostgreSQL engine version (e.g., '15.3').
        allocated_storage:  The amount of storage to allocate (in GB).
        security_group_ids: A list of security group IDs to associate with the instance.

    Returns:
        The response from the RDS create_db_instance API call.  You can use this to check status.
    """

    try:
        response = rds.create_db_instance(
            DBInstanceIdentifier=db_instance_identifier,
            DBName=db_name,
            Engine='postgres',
            EngineVersion=engine_version,
            DBInstanceClass=instance_class,
            AllocatedStorage=allocated_storage,
            MasterUsername=db_user,
            MasterUserPassword=db_password,
            VpcSecurityGroupIds=security_group_ids,
            # Add other parameters as needed, such as:
            # DBSubnetGroupName='your_subnet_group_name',  # Required if using a VPC
            # AvailabilityZone='us-west-2a',
            # BackupRetentionPeriod=7,
            # PreferredBackupWindow='00:00-03:00',
            # PubliclyAccessible=False
        )
        return response
    except Exception as e:
        print(f"Error creating RDS instance: {e}")
        return None

# Example Usage (replace with your actual values)
instance_identifier = 'my-postgres-instance'
database_name = 'mydatabase'
username = 'admin'
password = 'your_secure_password'  # Use a strong password!
instance_type = 'db.t3.micro'
postgres_version = '15.3'
storage = 20  # GB
security_groups = ['sg-xxxxxxxxxxxxxxxxx']  # Replace with your security group ID

creation_response = create_postgres_instance(instance_identifier, database_name, username, password, instance_type, postgres_version, storage, security_groups)

if creation_response:
    print(f"RDS instance creation initiated.  Check status using describe_db_instances.")
    # You'll want to monitor the instance status (e.g., using describe_db_instances)
    # until it becomes available before attempting to connect.
else:
    print("RDS instance creation failed.")

