"""
[File: admin/only_in_ui.py]
Description: Possible component for universal init_context
"""

# If you want to retain caching logic for performance reasons (e.g. in a Streamlit app), you could create a thin wrapper like this in a UI-facing module:

# Only in app or tab

_vectorizer_cache = {}

def get_vectorizer(model_key):
    if model_key not in _vectorizer_cache:
        _vectorizer_cache[model_key] = EmbeddingManager(model_key=model_key)
    return _vectorizer_cache[model_key]