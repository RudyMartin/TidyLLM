"""
[File: setup.py]
Description: Basic folders and libraries to run on AWS. Each env is dif - see requirements.

options:
  -h, --help   show this help message and exit
  --install    Install packages from requirements.txt
  --clean      Uninstall conflicting packages
  --check      Verify critical dependencies
  --init-dirs  Create required log directories
  --restart    Force interpreter restart after setup
  --restart    Force interpreter restart after setup

Usage:

  python setup.py  --install --clean --check --init-dirs --restart 

  
"""

import os
import sys
import subprocess
import argparse
import logging

from admin.create_pg_tables import create_tables  

# === Developer Hack (expose to set these) ===
# os.environ["DB_HOST"] = "somewhere.us-east-1.rds.amazonaws.com"
# os.environ["DB_NAME"] = "postgres" ## note the if blank in AWS panel use default db_name
# os.environ["DB_USER"] = "someone"
# os.environ["DB_PASSWORD"] = "something"

# === Logging Setup ===
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

# === Package Management ===
BAD_PACKAGES = [
    "autogluon", "autogluon-core", "autogluon-tabular", "autogluon-features", "autogluon-multimodal", "autogluon-timeseries",
    "dash", "dash-core-components", "dash-html-components", "dash-table",
    "jupyter-dash", "blis",  "datasets",
    "sparkmagic", "sagemaker-studio-analytics-extension", "s3fs",
    "fastai", "gluonts",  "langchain-aws", "evaluate", "thinc",
    "pathos", "multiprocess", "dill", "amazon-sagemaker-sql-magic"
]

def install_requirements(requirements_file="requirements.txt", quiet=True):
    if not os.path.exists(requirements_file):
        print(f"❌ Requirements file not found: {requirements_file}")
        sys.exit(1)
    pip_args = [sys.executable, "-m", "pip", "install", "-r", requirements_file]
    if quiet:
        pip_args.append("-q")
    try:
        logger.info(f"📦 Installing packages from {requirements_file}...")
        subprocess.check_call(pip_args)
        logger.info("✅ Package installation complete.")
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ pip install failed: {e}")
        sys.exit(1)

def clean_conflicting_packages(package_list):
    for pkg in sorted(set(package_list)):
        logger.info(f"🔧 Uninstalling: {pkg}")
        try:
            subprocess.run(["pip", "uninstall", "-y", pkg], check=False)
        except Exception as e:
            logger.warning(f"⚠️ Failed to uninstall {pkg}: {e}")

def verify_environment():
    try:
        import pyarrow as pa
        logger.info(f"✅ pyarrow.Decimal32Type available: {hasattr(pa.lib, 'Decimal32Type')}")
    except ImportError:
        logger.error("❌ pyarrow is not installed.")
        sys.exit(1)

def create_log_dirs():
    log_paths = [
        "logs",
        "logs/faiss",
        "logs/indexing",
        "logs/repair"
    ]
    for path in log_paths:
        os.makedirs(path, exist_ok=True)
        logger.info(f"📁 Created: {path}")

      

def force_restart():
    if "ipykernel" in sys.modules:
        print("⚠️ Cannot auto-restart in Jupyter/SageMaker. Please restart manually.")
        return
    logger.info("🔁 Restarting Python interpreter without --restart flag...")
    new_args = [arg for arg in sys.argv if arg != "--restart"]
    os.execv(sys.executable, [sys.executable] + new_args)


def createdb():
    # these are hardcoded above
    db_host = os.environ.get("DB_HOST")
    db_name = os.environ.get("DB_NAME")
    db_user = os.environ.get("DB_USER")
    db_password = os.environ.get("DB_PASSWORD")

    if not all([db_host, db_name, db_user, db_password]):
        print("Error: Database environment variables not set.")
        return

    try:
        create_tables(db_host, db_name, db_user, db_password)
        print("Database tables created/verified successfully.")
    except Exception as e:
        print(f"Error during database setup: {e}")
        # Handle the error appropriately (e.g., log, exit, retry)
        return
    

# === CLI Entrypoint ===
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Setup script for QA-Z demo")
    parser.add_argument("--install", action="store_true", help="Install packages from requirements.txt")
    parser.add_argument("--clean", action="store_true", help="Uninstall conflicting packages")
    parser.add_argument("--check", action="store_true", help="Verify critical dependencies")
    parser.add_argument("--init-dirs", action="store_true", help="Create required log directories")
    parser.add_argument("--createdb", action="store_true", help="Create new postgres data tables")
    parser.add_argument("--restart", action="store_true", help="Force interpreter restart after setup")
    args = parser.parse_args()

    if args.clean:
        clean_conflicting_packages(BAD_PACKAGES)

    if args.install:
        install_requirements("requirements.txt", quiet=False)
        if args.restart:
            force_restart()

    if args.check:
        verify_environment()

    if args.init_dirs:
        create_log_dirs()

    if args.createdb:
        create_pg_tables()    

    if not any(vars(args).values()):
        parser.print_help()

    import streamlit as st
    from core.launch_utils import launch_local_streamlit_app
    launch_local_streamlit_app("pgvector_demo.py", port=8522)       
