"""
[File: tabs/demo_vector_sanity.py]
Description: Streamlit tab app to upload or select a PDF, process it, generate embeddings,
"""

import streamlit as st
import uuid

from core.init_context import get_tab_context
from core.embedding_helper import get_cached_vectorizer
from core.s3_utils import list_objects_s3, load_json_from_s3, upload_to_s3
from core.extraction_helper import split_pdf_into_pages_s3, extract_text_to_json
from core.vector_manager import VectorManager

st.set_page_config(page_title="Vector Sanity Demo", layout="wide")

def show_vector_sanity_tab():
    st.header("🧪 Vector Sanity Check Demo")

    # Get shared context
    clients, config, _, _ = get_tab_context()
    bucket = config["bucket_name"]

    # User & model selection
    zNAME = st.text_input("Enter your user ID", value="user_2025")
    user_prefix = f"dev/pdf2/{zNAME}"
    model_key = st.selectbox("Choose embedding model", config["model_order"])
    mode = st.radio("Choose file source", ["Use existing S3 JSON", "Upload and process new PDF"])

    if mode == "Upload and process new PDF":
        uploaded_file = st.file_uploader("Upload a PDF", type="pdf")
        if uploaded_file and st.button("📄 Process PDF"):
            raw_key = f"{user_prefix}/raw_pdfs/{uuid.uuid4().hex}.pdf"
            upload_to_s3(clients["s3"], bucket, raw_key, uploaded_file.read())
            split_pdf_into_pages_s3(raw_key, config=config, s3_client=clients["s3"])
            extract_text_to_json(config=config, s3_client=clients["s3"])
            st.success("✅ PDF processed. Rerun with 'Use existing JSON' mode.")
            st.info(f"Uploaded to S3: `{raw_key}`")
            st.info(f"Page folder: `{config['page_folder']}`")
            st.info(f"Expected JSON output to: `{config['json_folder']}`")

    elif mode == "Use existing S3 JSON":
        json_folder = f"{user_prefix}/json"
        json_files = list_objects_s3(bucket, json_folder, extension=".json")
        selected_file = st.selectbox("Select a JSON file", json_files)

        if st.button("🚀 Run Sanity Check"):
            data = load_json_from_s3(bucket, selected_file, config=config)
            chunks = data.get("chunks", [])
            st.info(f"Using {len(chunks)} chunks from: `{selected_file}`")

            vectorizer = get_cached_vectorizer(config, logger=st)
            sample_text = chunks[0]["text"] if chunks else ""
            query_embedding = vectorizer.generate_embedding(sample_text)

            col1, col2 = st.columns(2)

            # FAISS search using vector manager
            with col1:
                st.markdown("### 🔍 FAISS Results")
                try:
                    faiss_manager = VectorManager("faiss", config=config, clients=clients)
                    results = faiss_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**FAISS Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"FAISS query failed: {e}")

            # pgVector search using vector manager
            with col2:
                st.markdown("### 🧬 pgVector Results")
                try:
                    pg_manager = VectorManager("pgvector", config=config, clients=clients)
                    results = pg_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**pgVector Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"pgVector query failed: {e}")

# Required entry point
show_vector_sanity_tab()

Description:
  Streamlit tab to upload or select a PDF, process it, generate embeddings,
  index into FAISS and pgVector, and compare vector retrieval accuracy side-by-side.

Updated: Uses vector_manager abstraction for unified backend access.
"""

import streamlit as st
import uuid

from core.init_context import get_tab_context
from core.embedding_helper import get_cached_vectorizer
from core.s3_utils import list_objects_s3, load_json_from_s3, upload_to_s3
from core.extraction_helper import split_pdf_into_pages_s3, extract_text_to_json
from core.vector_manager import VectorManager

st.set_page_config(page_title="Vector Sanity Demo", layout="wide")

def show_vector_sanity_tab():
    st.header("🧪 Vector Sanity Check Demo")

    # Get shared context
    clients, config, _, _ = get_tab_context()
    bucket = config["bucket_name"]

    # User & model selection
    zNAME = st.text_input("Enter your user ID", value="user_2025")
    user_prefix = f"dev/pdf2/{zNAME}"
    model_key = st.selectbox("Choose embedding model", config["model_order"])
    mode = st.radio("Choose file source", ["Use existing S3 JSON", "Upload and process new PDF"])

    if mode == "Upload and process new PDF":
        uploaded_file = st.file_uploader("Upload a PDF", type="pdf")
        if uploaded_file and st.button("📄 Process PDF"):
            raw_key = f"{user_prefix}/raw_pdfs/{uuid.uuid4().hex}.pdf"
            upload_to_s3(clients["s3"], bucket, raw_key, uploaded_file.read())
            split_pdf_into_pages_s3(raw_key, config=config, s3_client=clients["s3"])
            extract_text_to_json(config=config, s3_client=clients["s3"])
            st.success("✅ PDF processed. Rerun with 'Use existing JSON' mode.")
            st.info(f"Uploaded to S3: `{raw_key}`")
            st.info(f"Page folder: `{config['page_folder']}`")
            st.info(f"Expected JSON output to: `{config['json_folder']}`")

    elif mode == "Use existing S3 JSON":
        json_folder = f"{user_prefix}/json"
        json_files = list_objects_s3(bucket, json_folder, extension=".json")
        selected_file = st.selectbox("Select a JSON file", json_files)

        if st.button("🚀 Run Sanity Check"):
            data = load_json_from_s3(bucket, selected_file, config=config)
            chunks = data.get("chunks", [])
            st.info(f"Using {len(chunks)} chunks from: `{selected_file}`")

            vectorizer = get_cached_vectorizer(config, logger=st)
            sample_text = chunks[0]["text"] if chunks else ""
            query_embedding = vectorizer.generate_embedding(sample_text)

            col1, col2 = st.columns(2)

            # FAISS search using vector manager
            with col1:
                st.markdown("### 🔍 FAISS Results")
                try:
                    faiss_manager = VectorManager("faiss", config=config, clients=clients)
                    results = faiss_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**FAISS Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"FAISS query failed: {e}")

            # pgVector search using vector manager
            with col2:
                st.markdown("### 🧬 pgVector Results")
                try:
                    pg_manager = VectorManager("pgvector", config=config, clients=clients)
                    results = pg_manager.query(query_embedding, top_k=3)
                    for r in results:
                        st.markdown(f"**pgVector Match ID:** {r[0]} | Score: {r[1]:.3f}")
                except Exception as e:
                    st.error(f"pgVector query failed: {e}")

# Required entry point
show_vector_sanity_tab()
