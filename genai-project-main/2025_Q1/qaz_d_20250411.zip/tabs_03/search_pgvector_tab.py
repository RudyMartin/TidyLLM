"""
[File: tabs_03/search_pgvector_tab.py]
Description:
✅ Search using PGVector semantic similarity
✅ Use `get_tab_context()` for unified config and managers
✅ Embed query with `embed_manager`
✅ Retrieve relevant chunks using `vector_manager.query()`
✅ Optionally summarize results with DSPy BootstrapFewShot
"""

import streamlit as st
import dspy
from dspy.teleprompt import BootstrapFewShot

from core.init_context import get_tab_context


# Simple DSPy Q&A
class SimpleQA(dspy.Signature):
    context = dspy.InputField(desc="Relevant document chunks")
    question = dspy.InputField()
    answer = dspy.OutputField(desc="Helpful, document-grounded answer")


def show_search_tab():
    st.header("🔎 Search PGVector + Ask with DSPy")

    # Load context
    clients, config, vector_manager, embed_manager = get_tab_context()
    model_key = config["default_model"]

    # Query input
    query = st.text_input("Enter a search query")
    use_dspy = st.checkbox("🤖 Use DSPy to generate a summarized answer")

    if query and st.button("🔍 Run Search"):
        try:
            # Embed query + search
            qvec = embed_manager.generate(query)
            results = vector_manager.query(qvec, model_key=model_key, top_k=5)

            if not results:
                st.info("No relevant results found.")
                return

            # Show raw chunks
            st.subheader("📋 Top Matches")
            for i, r in enumerate(results):
                st.markdown(f"**{i+1}.** {r.get('text', '')[:300]}...")

            # DSPy summary (optional)
            if use_dspy:
                context_text = "\n\n".join([r["text"] for r in results])
                if "search_qa_module" not in st.session_state:
                    dspy.settings.configure(openai="gpt-3.5-turbo")
                    st.session_state.search_qa_module = BootstrapFewShot(SimpleQA).compile()

                answer = st.session_state.search_qa_module(
                    context=context_text,
                    question=query
                )
                st.markdown("#### 🧠 DSPy Answer")
                st.success(answer.answer)

        except Exception as e:
            st.error(f"❌ Search failed: {e}")
