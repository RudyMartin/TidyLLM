"""
[File: tabs_03/instructions_tab.py]
Description:
Streamlit tab to:
✅ Load a markdown-style instruction file from S3
✅ Render sections dynamically with titles and markdown
✅ Uses get_config/get_clients to access app-wide config
"""

import streamlit as st
import json
from core.config_helper import get_config, get_clients
from core.s3_utils import load_json_from_s3


def show_instructions_tab():
    st.header("📘 Instructions")

    config = get_config()
    clients = get_clients()

    bucket = config["bucket_name"]
    instructions_key = config.get("instructions_file", "dev/docs/instructions.json")

    try:
        instructions = load_json_from_s3(clients.s3, bucket, instructions_key)
        for section in instructions.get("sections", []):
            st.subheader(section.get("title", "Untitled"))
            st.markdown(section.get("content", ""))
    except json.JSONDecodeError:
        st.error("⚠️ The instructions file is not valid JSON.")
    except Exception as e:
        st.error(f"❌ Failed to load instructions from S3: {e}")
