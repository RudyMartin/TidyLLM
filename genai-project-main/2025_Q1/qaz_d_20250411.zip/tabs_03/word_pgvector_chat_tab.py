"""
[File: tabs_03/word_pgvector_chat_tab.py]
Description: Word ➜ PGVector ➜ DSPy Chat tab (Simple DSPy Workflow).
"""

import streamlit as st
import uuid
from datetime import datetime
import dspy
from dspy.teleprompt import BootstrapFewShot

from core.init_context import get_tab_context
from core.extraction_helper import extract_text_from_docx, chunk_text_into_segments
from core.s3_utils import upload_to_s3
from core.json_schema import make_pgvector_json_from_chunks


# Simple DSPy QA Module
class SimpleQA(dspy.Signature):
    """Answer the user's question using the given context."""
    context = dspy.InputField(desc="Relevant text chunks")
    question = dspy.InputField()
    answer = dspy.OutputField(desc="A helpful and specific answer")


def show_word_pgvector_chat_tab():
    st.header("📄 Word ➜ PGVector ➜ DSPy Chat")

    clients, config, vector_manager, embed_manager = get_tab_context()
    bucket = config["bucket_name"]
    model_key = config["default_model"]

    uploaded_file = st.file_uploader("Upload a Word document (.docx)", type="docx")

    if uploaded_file and st.button("🚀 Process Word Document"):
        try:
            doc_id = str(uuid.uuid4())
            doc_key = f"{config['pdf_folder']}/{doc_id}.docx"
            upload_to_s3(clients.s3, bucket, doc_key, uploaded_file.read())
            st.success(f"✅ Uploaded to: `{doc_key}`")

            raw_text = extract_text_from_docx(uploaded_file)
            chunked = chunk_text_into_segments(
                raw_text, config=config, s3_client=clients.s3,
                doc_id=doc_id, doc_type="docx"
            )
            st.info(f"📚 Extracted {len(chunked)} chunks.")

            enriched_chunks = []
            for chunk in chunked:
                text = chunk["text"]
                embedding = embed_manager.generate(text)
                enriched_chunks.append({
                    "chunk_id": chunk["chunk_id"],
                    "text": text,
                    "embedding": embedding,
                    "tags": ["worddoc"],
                    "metadata": {
                        "document_name": uploaded_file.name,
                        "page_number": chunk.get("page_number", 1),
                        "text_date": datetime.utcnow().isoformat()
                    }
                })

            doc_json = make_pgvector_json_from_chunks(enriched_chunks, model_key=model_key)
            vector_manager.index(doc_json, model_key=model_key)

            st.success("✅ Document embedded and indexed to PGVector!")

        except Exception as e:
            st.error(f"❌ Processing failed: {e}")

    # DSPy Chat Interface
    st.divider()
    st.subheader("💬 Ask about your Word document (DSPy-powered)")

    query = st.text_input("Enter a question:")
    if query and st.button("🤖 Ask with DSPy"):
        try:
            # Embed query and search PGVector
            qvec = embed_manager.generate(query)
            top_chunks = vector_manager.query(qvec, model_key=model_key, top_k=5)
            context_text = "\n\n".join([c["text"] for c in top_chunks])

            # Initialize DSPy and run QA
            if "qa_module" not in st.session_state:
                dspy.settings.configure(openai="gpt-3.5-turbo")  # Or use Bedrock backend
                qa_module = BootstrapFewShot(SimpleQA, max_bootstrapped=4)
                st.session_state.qa_module = qa_module.compile()
            
            response = st.session_state.qa_module(
                context=context_text,
                question=query
            )

            st.markdown("#### 🧠 Answer")
            st.success(response.answer)

        except Exception as e:
            st.error(f"❌ DSPy query failed: {e}")
