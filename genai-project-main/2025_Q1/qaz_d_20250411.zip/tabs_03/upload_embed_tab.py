"""
[File: tabs_03/upload_embed_tab.py]
Description:
Streamlit tab to:
✅ Upload a PDF to S3
✅ Split into pages and extract text (via extraction_helper)
✅ Chunk, embed, and enrich text content
✅ Save all enriched chunks as a single JSON file to S3
✅ Index all enriched chunks into PGVector (vector_manager.index)
✅ Auto-redirect to 'Chat with Document' tab upon successful upload
"""

import streamlit as st
import uuid
import dspy
from datetime import datetime

from core.init_context import get_tab_context
from core.extraction_helper import (
    split_pdf_into_pages_s3,
    extract_text_to_json,
    chunk_text_into_segments
)
from core.s3_utils import upload_to_s3, save_json_to_s3
from pipe.pdf_pipeline import make_standard_schema


# Minimal DSPy Signature (optional preview)
class SimpleQA(dspy.Signature):
    context = dspy.InputField(desc="Extracted chunks from the PDF")
    question = dspy.InputField()
    answer = dspy.OutputField(desc="Relevant answer")


def show_upload_tab():
    st.header("📄 Upload PDF ➜ Embed ➜ PGVector ➜ DSPy Chat")

    uploaded_file = st.file_uploader("Upload a PDF", type="pdf")

    if uploaded_file and st.button("🚀 Process PDF"):
        try:
            # 1. Initialize context
            clients, config, vector_manager, embed_manager = get_tab_context()
            bucket = config["bucket_name"]
            model_key = config["default_model"]
            pdf_id = uuid.uuid4().hex
            pdf_key = f"{config['pdf_folder']}/{pdf_id}.pdf"

            # 2. Upload PDF to S3
            upload_to_s3(clients.s3, bucket, pdf_key, uploaded_file.read())
            st.success(f"✅ Uploaded PDF to `{pdf_key}`")

            # 3. Split into pages, extract text, and chunk
            split_pdf_into_pages_s3(pdf_key, config=config, s3_client=clients.s3)
            json_key = extract_text_to_json(config=config, s3_client=clients.s3)
            chunks = chunk_text_into_segments(json_key, config=config, s3_client=clients.s3)
            st.info(f"📚 Extracted {len(chunks)} chunks.")

            # 4. Embed and enrich each chunk
            enriched_chunks = []
            for chunk in chunks:
                text = chunk["text"]
                embedding = embed_manager.generate(text)
                enriched_chunks.append({
                    "chunk_id": chunk.get("chunk_id"),
                    "text": text,
                    "embedding": embedding,
                    "tags": ["pdf"],
                    "metadata": {
                        "source_file": uploaded_file.name,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                })

            # 5. Save all enriched chunks to a single JSON file
            json_filename = f"{pdf_id}_chunks.json"
            save_json_to_s3(
                s3_client=clients.s3,
                bucket=bucket,
                folder=config["json_folder"],
                filename=json_filename,
                json_obj={"chunks": enriched_chunks}
            )
            st.success(f"✅ Enriched chunks saved to `{json_filename}`")

            # 6. Index enriched chunks to PGVector
            pg_json = make_pgvector_json_from_chunks(enriched_chunks, model_key=model_key)
            vector_manager.index(pg_json, model_key=model_key)
            st.success("✅ Embedded chunks indexed into PGVector.")

            # 7. Auto-switch to chat tab
            st.success("🚀 Document ready for chat!")
            st.experimental_set_query_params(tab="chat")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Processing failed: {e}")
