"""
[File: tabs_03/doc_pgvector_chat_tab.py]
Description:
Streamlit tab to:
✅ Upload a Word document (.docx) and save to S3
✅ Extract and chunk the document into text segments
✅ Embed each chunk using the configured model
✅ Index enriched chunks into PGVector using vector_manager
✅ Provide a DSPy-powered chat interface for question answering
"""

import streamlit as st
import uuid
from datetime import datetime
import dspy
from dspy.teleprompt import BootstrapFewShot

from core.init_context import get_tab_context
from core.s3_utils import upload_to_s3
from core.extraction_helper import chunk_text_into_segments
from core.extract_utils_docx import extract_text_from_docx
from core.pgvector_utils import make_pgvector_json_from_chunks


# --- Minimal DSPy Signature ---
class SimpleQA(dspy.Signature):
    context = dspy.InputField(desc="Relevant document chunks")
    question = dspy.InputField()
    answer = dspy.OutputField(desc="Helpful, document-grounded answer")


def show_doc_pgvector_chat_tab():
    st.header("📄 Word ➜ PGVector ➜ DSPy Chat")

    # Step 0: Load context
    clients, config, vector_manager, embed_manager = get_tab_context()
    bucket = config["bucket_name"]
    model_key = config["default_model"]

    uploaded_file = st.file_uploader("Upload a Word (.docx) file", type="docx")

    if uploaded_file and st.button("🚀 Process Word Document"):
        try:
            # Step 1: Upload to S3
            doc_id = str(uuid.uuid4())
            raw_key = f"{config['pdf_folder']}/{doc_id}.docx"
            upload_to_s3(clients.s3, bucket, raw_key, uploaded_file.read())
            st.success(f"✅ Uploaded to S3 as: `{raw_key}`")

            # Step 2: Extract + Chunk
            text = extract_text_from_docx(uploaded_file)
            chunks = chunk_text_into_segments(
                text, config=config, s3_client=clients.s3,
                doc_id=doc_id, doc_type="docx"
            )
            st.info(f"📚 Extracted {len(chunks)} chunks")

            # Step 3: Embed and enrich
            enriched_chunks = []
            for chunk in chunks:
                text = chunk["text"]
                embedding = embed_manager.generate(text)
                enriched_chunks.append({
                    "chunk_id": chunk.get("chunk_id"),
                    "text": text,
                    "embedding": embedding,
                    "tags": ["worddoc"],
                    "metadata": {
                        "document_name": uploaded_file.name,
                        "page_number": chunk.get("page_number", 1),
                        "text_date": datetime.utcnow().isoformat()
                    }
                })

            # Step 4: Index to PGVector
            pg_json = make_pgvector_json_from_chunks(enriched_chunks, model_key=model_key)
            vector_manager.index(pg_json, model_key=model_key)
            st.success("✅ Embedded and indexed to PGVector")

        except Exception as e:
            st.error(f"❌ Processing failed: {e}")

    # Step 5: DSPy Q&A
    st.divider()
    st.subheader("💬 Ask about your Word document")

    query = st.text_input("Enter a question:")
    if query and st.button("🤖 Ask with DSPy"):
        try:
            qvec = embed_manager.generate(query)
            results = vector_manager.query(qvec, model_key=model_key, top_k=5)
            context_text = "\n\n".join([r["text"] for r in results])

            # Bootstrap DSPy module if not in session
            if "doc_qa_module" not in st.session_state:
                dspy.settings.configure(openai="gpt-3.5-turbo")  # Or use Bedrock provider
                qa_module = BootstrapFewShot(SimpleQA, max_bootstrapped=4)
                st.session_state.doc_qa_module = qa_module.compile()

            response = st.session_state.doc_qa_module(
                context=context_text,
                question=query
            )

            st.markdown("#### 🧠 Answer")
            st.success(response.answer)

        except Exception as e:
            st.error(f"❌ DSPy query failed: {e}")
