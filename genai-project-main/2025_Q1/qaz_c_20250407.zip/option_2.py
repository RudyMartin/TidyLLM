# option_2.py
import sys
import json
import numpy as np
from datetime import datetime

# Import our core managers
from core.vector_manager import VectorManager
from core.embedding_manager import EmbeddingManager

def cli_demo():
    """
    CLI demo that accepts arguments for storage backend, embedding model, and text to embed.
    It then generates an embedding and attempts to index it using the chosen storage.
    """
    parser = argparse.ArgumentParser(description="Vector & Embedding Manager CLI Demo")
    parser.add_argument(
        '--storage', 
        choices=['faiss', 'pgvector'], 
        default='faiss', 
        help="Select storage backend (faiss or pgvector)"
    )
    parser.add_argument(
        '--model_key', 
        type=str, 
        default='titan_v2', 
        help="Select embedding model key (e.g., 'titan_v2', 'cohere_4096', etc.)"
    )
    parser.add_argument(
        '--text', 
        type=str, 
        default="This is a sample text for embedding.", 
        help="Text to generate embedding for"
    )
    args = parser.parse_args()

    print(f"Using storage backend: {args.storage}")
    print(f"Using embedding model key: {args.model_key}")
    print(f"Text to embed: {args.text}\n")

    # Initialize the VectorManager (which sets up the appropriate store)
    vector_manager = VectorManager(store_type=args.storage)
    print("VectorManager initialized.")

    # Initialize the EmbeddingManager (which handles embeddings via Bedrock)
    embedding_manager = EmbeddingManager()
    print("EmbeddingManager initialized.")

    # Generate an embedding for the provided text
    try:
        embedding = embedding_manager.generate(args.text, args.model_key)
        print("Generated Embedding:")
        print(json.dumps(embedding, indent=2))
    except Exception as e:
        print("Error generating embedding:", e)
        return

    # Index the embedding using the selected storage backend
    try:
        if args.storage == "faiss":
            store = vector_manager.index_store
            # Convert embedding to a NumPy array of type float32 and reshape as needed.
            embedding_np = np.array([embedding], dtype=np.float32)
            store.index_create(embedding_np, args.model_key)
            print("FAISS index updated with the embedding.")
        elif args.storage == "pgvector":
            store = vector_manager.index_store
            embedding_np = np.array([embedding], dtype=np.float32)
            # Example metadata can be provided here.
            metadata = {"source": "CLI demo", "timestamp": datetime.utcnow().isoformat()}
            store.index_create(embedding_np, args.model_key, metadata)
            print("PGVector index updated with the embedding.")
    except Exception as e:
        print("Error indexing embedding:", e)

def streamlit_demo():
    """
    Streamlit demo that presents an interactive UI for selecting the storage backend,
    specifying an embedding model key, and inputting text to embed.
    """
    import streamlit as st

    st.title("Vector & Embedding Manager Demo")
    st.markdown("Choose your storage backend and embedding model, then enter text to generate an embedding.")

    # User selections
    storage_option = st.selectbox("Select Storage Backend", ["faiss", "pgvector"])
    model_key = st.text_input("Enter Embedding Model Key", value="titan_v2")
    text_input = st.text_area("Enter Text for Embedding", value="This is a sample text for embedding.")

    if st.button("Generate Embedding"):
        st.info("Initializing managers and generating embedding...")
        try:
            vector_manager = VectorManager(store_type=storage_option)
            embedding_manager = EmbeddingManager()
            embedding = embedding_manager.generate(text_input, model_key)
            st.success("Embedding generated successfully!")
            st.subheader("Generated Embedding:")
            st.json(embedding)
        except Exception as e:
            st.error(f"Error: {e}")

if __name__ == '__main__':
    # If the user passes the '--cli' flag, run CLI mode; otherwise default to Streamlit mode.
    # To run the CLI demo, execute: python demo.py --cli
    # To run the Streamlit demo, execute: streamlit run demo.py
    if len(sys.argv) > 1 and sys.argv[1] == "--cli":
        cli_demo()
    else:
        streamlit_demo()
