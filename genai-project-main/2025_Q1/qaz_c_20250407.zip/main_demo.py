# main_demo.py – Canonical version aligned to `concepts`

import streamlit as st
from packaging import version

# Core app modules
from core.config_manager import (
    get_config_state, get_s3, get_bedrock,
    validate_config_schema, get_tagging_grid
)
from core.client_manager import get_clients

# Admin tabs
from tabs import config_tab, logs_tab, faiss_diagnostics_tab, admin_cleanup_tab, pdf_tab, pgvector_index_tab

# User tabs
from tabs import (
    wizard_tab,
    plan_audit_tab,
    faiss_search_tab,
    guided_search_tab,
    dashboard_tab,
    groundtruth_tab,
    option2_audit_tab,
    option2_truth_tab,
    option2_dashboard_tab,
    option3_audit_tab,
    option3_synth_tab
)

# --- Streamlit Version Check ---
if version.parse(st.__version__) < version.parse("1.25.0"):
    st.error("Streamlit version too old. Please upgrade to 1.25.0 or higher.")
    st.stop()

# --- Config and Clients ---
if "config" not in st.session_state:
    st.session_state["config"] = get_config_state()
clients = get_clients()

# --- Sidebar: Admin Controls ---
st.sidebar.header(" Admin Tools")
if st.sidebar.button("🏠 Home"):
    st.session_state["admin_tool"] = "None"
    st.experimental_rerun()

st.sidebar.selectbox(
    "Select Admin Tool",
    ["None", "Config", "Logs Viewer", "FAISS Diagnostics", "Cleanup Tab", "PDF Extract", "pgVector Index"],
    key="admin_tool"
)

# --- Tab Routing ---
admin_tool = st.session_state.get("admin_tool", "None")
if admin_tool == "Config":
    config_tab.render()
elif admin_tool == "Logs Viewer":
    logs_tab.render()
elif admin_tool == "FAISS Diagnostics":
    faiss_diagnostics_tab.show_faiss_diagnostics()
elif admin_tool == "Cleanup Tab":
    admin_cleanup_tab.render()
elif admin_tool == "PDF Extract":
    pdf_tab.render()
elif admin_tool == "pgVector Index":
    pgvector_index_tab.render()
else:
    # --- DSPy Workflow Selector ---
    st.sidebar.markdown("### DSPy Workflow Mode")
    selected_dspy_mode = st.sidebar.radio(
        "Choose Workflow:",
        [
            "Option 1: FAISS (Simple)",
            "Option 2: DSPy + pgVector",
            "Option 3: Multi-Agent DSPy"
        ],
        key="dspy_workflow_mode"
    )

    if selected_dspy_mode == "Option 1: FAISS (Simple)":
        tabs = st.tabs(["🧠 Guided Search", "📍 FAISS Search"])
        with tabs[0]: guided_search_tab.render()
        with tabs[1]: faiss_search_tab.render()

    elif selected_dspy_mode == "Option 2: DSPy + pgVector":
        tabs = st.tabs(["📋 Plan Audit", "🧠 Groundtruth", "📊 Dashboard"])
        with tabs[0]: option2_audit_tab.render(vector_backend="pgvector")
        with tabs[1]: option2_truth_tab.render()
        with tabs[2]: option2_dashboard_tab.render()

    elif selected_dspy_mode == "Option 3: Multi-Agent DSPy":
        tabs = st.tabs(["📋 Agent Audit", "🧠 Synth", "📊 Dashboard", "🤖 Router"])
        with tabs[0]: option3_audit_tab.render()
        with tabs[1]: option3_synth_tab.render()
        with tabs[2]: option2_dashboard_tab.render()
        with tabs[3]: st.info("Coming soon: multi-agent DSPy orchestration.")
