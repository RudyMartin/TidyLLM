import os
import json
import logging
import numpy as np
from datetime import datetime

from core.config_helper import get_config
from core.client_helper import get_clients
from core.model_key_utils import (
    validate_model_key,
    get_model_details,
)
from core.logging_helper import get_logger

import streamlit as st

logger = get_logger("AmazonEmbeddingVectorizer")

class AmazonEmbeddingVectorizer:
    def __init__(self, config=None, s3_client=None, bedrock_client=None, selected_model_option=None, dimensions=None):
        self.config = config or get_config()
        self._s3_client, self._bedrock_client = s3_client, bedrock_client

        if not self._bedrock_client or not self._s3_client:
            logger.info("⏳ Initializing AWS clients...")
            s3, bedrock = get_clients(self.config)
            self._s3_client = self._s3_client or s3
            self._bedrock_client = self._bedrock_client or bedrock

        selected = self._select_model(self.config, selected_model_option)
        self.model_id = selected["id"]
        self.dimensions = dimensions or selected["dimensions"]

        if "anthropic" in self.model_id:
            raise ValueError(f"{self.model_id} does not support embeddings.")

        if not self._bedrock_client:
            raise ValueError("Missing Bedrock client. Cannot generate embeddings.")
        if not self._s3_client:
            raise ValueError("Missing S3 client. Cannot save embeddings.")

        logger.info(f"✅ Initialized Bedrock model: {self.model_id} (dims: {self.dimensions})")

    def generate_embedding(self, text, normalize=True, force=False):
        body = self._prepare_body(text)

        try:
            logger.info(f"🚀 Invoking Bedrock embedding model: {self.model_id}")
            response = self._bedrock_client.invoke_model(
                modelId=self.model_id,
                contentType="application/json",
                accept="application/json",
                body=json.dumps(body)
            )
            raw_body = response["body"].read().decode("utf-8")
            response_body = json.loads(raw_body)
        except Exception as e:
            logger.error(f"❌ Bedrock invoke_model failed: {e}", exc_info=True)
            raise

        embedding = response_body.get("embedding") or (response_body.get("embeddings") or [None])[0]
        if not embedding:
            raise ValueError("No embedding found in response.")

        return self._normalize_vector(embedding) if normalize else embedding

    def _prepare_body(self, text: str) -> dict:
        if "amazon.titan-embed-text-v2" in self.model_id:
            return {"inputText": text, "dimensions": int(self.dimensions)}
        elif "amazon.titan-embed-text-v1" in self.model_id:
            return {"inputText": text}
        elif "cohere" in self.model_id:
            limit = self.config.get("cohere_limit", 2048)
            return {"texts": [text[:limit]], "input_type": "search_document"}
        else:
            raise ValueError(f"Unsupported model type: {self.model_id}")

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    def _select_model(self, config, model_key=None):
        model_options = config.get("model_options", {})
        model_key = model_key or config.get("default_model_option", "titan_v2")
        validated_key = validate_model_key(model_key, model_options)
        return model_options[validated_key]

    @classmethod
    def from_config(cls, config=None):
        config = config or get_config()
        s3, bedrock = get_clients(config)
        return cls(config=config, s3_client=s3, bedrock_client=bedrock)

# ---------- Cached Vectorizer ----------
@st.cache_resource
def get_cached_vectorizer():
    return AmazonEmbeddingVectorizer.from_config()
