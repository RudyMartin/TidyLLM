# [File: core/vector_manager.py]
# Description: Vector Manager interface to support FAISS and pgVector backends.

import logging
from core.config_helper import get_config
from core.client_manager import get_clients
from core.logging_helper import get_logger
from core.model_key_utils import get_model_details  # Optional, used by helpers

class VectorManager:
    def __init__(self, store_type="faiss", config=None, clients=None):
        """
        Initialize the VectorManager for a specific backend store.

        Args:
            store_type (str): Which vector backend to use ("faiss", "pgvector").
            config (dict): Optional config override, else loads default.
            clients (dict): Optional clients override, else loads default.
        """
        self.config = config or get_config()
        self.clients = clients or get_clients(self.config)
        self.store_type = store_type
        self.logger = get_logger("vector_manager")
        self.index_store = self._init_store()

    def _init_store(self):
        """
        Create the appropriate vector store based on store_type.
        """
        if self.store_type == "faiss":
            from core.faiss_store import FaissStore
            return FaissStore(config=self.config, s3_client=self.clients["s3"], logger=self.logger)
        elif self.store_type == "pgvector":
            from core.pgvector_store import PGVectorStore
            return PGVectorStore(config=self.config, s3_client=self.clients["s3"])
        else:
            raise ValueError(f"Unsupported store_type: {self.store_type}. Choose 'faiss' or 'pgvector'.")

    @property
    def s3(self):
        return self.clients.get("s3")

    @property
    def bedrock(self):
        return self.clients.get("bedrock")
