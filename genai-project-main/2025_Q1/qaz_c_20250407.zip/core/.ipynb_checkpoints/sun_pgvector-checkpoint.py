import json
import logging
import psycopg2
from core.client_manager import get_clients

class PGVectorStore:
    def __init__(self, config, s3_client, bedrock_client):
        self.config = config
        self.s3_client = s3_client
        self.bedrock_client = bedrock_client
        self.logger = logging.getLogger(__name__)
        try:
            self.conn = psycopg2.connect(self.config["pgvector_conn_string"])
            self.cur = self.conn.cursor()
        except psycopg2.OperationalError as e:
            self.conn = None
            self.cur = None
            self.logger.warning(f"Could not connect to PGVector DB: {e}")

    def list_indexes(self):
        if not self.conn:
            self.logger.warning("PGVector DB connection not available.")
            return []
        try:
            query = """
                SELECT model_key, table_name, dimension, created_at
                FROM vector_indexes
            """
            self.cur.execute(query)
            rows = self.cur.fetchall()
            return [
                {
                    "ModelKey": row[0],
                    "TableName": row[1],
                    "Dimension": row[2],
                    "CreatedAt": row[3].isoformat() if hasattr(row[3], "isoformat") else str(row[3])
                }
                for row in rows
            ]
        except Exception as e:
            self.logger.error(f"Error fetching index list: {e}")
            return []

    def index_create(self, embeddings, model_key, metadata=None):
        if not self.conn:
            self.logger.warning("PGVector DB connection not available.")
            return
        try:
            self.logger.info(f"Creating PGVector index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            self.logger.info(f"Inserting {vector_count} embeddings of dimension {dim}")

            for i in range(vector_count):
                self.cur.execute(
                    """
                    INSERT INTO model_embeddings (model_key, embedding, metadata)
                    VALUES (%s, %s, %s)
                    """,
                    (
                        model_key,
                        embeddings[i].tobytes(),
                        json.dumps(metadata[i]) if metadata else None,
                    )
                )
            self.conn.commit()
            self.logger.info("Embeddings inserted into PGVector index.")
        except Exception as e:
            self.logger.error(f"Error creating PGVector index for {model_key}: {e}")
            raise

    def index_load(self, model_key):
        if not self.conn:
            self.logger.warning("PGVector DB connection not available.")
            return []
        try:
            self.cur.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM pg_catalog.pg_attribute 
                    WHERE attname = 'embedding' 
                      AND attrelid = (
                          SELECT oid FROM pg_catalog.pg_class WHERE relname = 'model_embeddings'
                      )
                );
            """)
            exists = self.cur.fetchone()[0]
            if not exists:
                self.logger.warning(f"PGVector index for {model_key} does not exist. Rebuilding...")
                self.rebuild_pgvector_index(model_key)
            else:
                self.logger.info(f"PGVector index for {model_key} is valid.")
        except Exception as e:
            self.logger.warning(f"Error checking PGVector index for {model_key}: {e}")
            self.rebuild_pgvector_index(model_key)

    def get_index_status(self):
        if not self.conn:
            self.logger.warning("PGVector DB connection not available.")
            return []
        status = []
        try:
            self.cur.execute("SELECT model_key, COUNT(*) FROM model_embeddings GROUP BY model_key;")
            results = self.cur.fetchall()
            for row in results:
                status.append({
                    "Model": row[0],
                    "Indexed Embeddings": row[1],
                    "Status": "🟢" if row[1] > 0 else "🔴"
                })
        except Exception as e:
            self.logger.error(f"Error fetching PGVector index status: {e}")
        return status