# core/pgvectore_store.py

import os
import json
import logging
import psycopg2
from datetime import datetime

from core.config_helper import get_config_state
config = get_config_state()

from core.client_manager import get_clients  # 🔗 [S3 Client Type 4️⃣ Core Utility: Inserted by patcher]

# --- Logging Setup ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


# Retrieve PGVector configuration values
pgvector_host = config.get("pgvector", {}).get("genai", {}).get("host", "default_host_value")
pgvector_port = config.get("pgvector", {}).get("genai", {}).get("port", "5432")
pgvector_user = config.get("pgvector", {}).get("genai", {}).get("user", "default_user_value")
pgvector_password = config.get("pgvector", {}).get("genai", {}).get("password", "default_password_value")

# Build the connection string
pgvector_conn_string = f"postgresql://{pgvector_user}:{pgvector_password}@{pgvector_host}:{pgvector_port}/your_dbname"

# Update the config with the PGVector connection string
if "pgvector_conn_string" not in config:
    config["pgvector_conn_string"] = pgvector_conn_string
    save_config(config, CONFIG_PATH)  # Save the updated config to the file

logger.info(f"PGVector connection string: {pgvector_conn_string}")

# --- Initialize AWS Clients ---
clients = get_clients()  # Pass the updated config to initialize clients
s3 = clients.get("s3")  # Access S3 client
bedrock = clients.get("bedrock")  # Access Bedrock client

# --- Initialize PostgreSQL Connection for PGVector ---
try:
    conn = psycopg2.connect(pgvector_conn_string)
    cur = conn.cursor()
except psycopg2.OperationalError as e:
    conn = None
    cur = None
    logger.warning(f"⚠️ PGVector database not available: {e}")

# PGVectorStore Class
class PGVectorStore:
    def __init__(self, config, s3_client):
        self.config = config
        self.s3_client = s3_client
        self.logger = logging.getLogger(__name__)

        try:
            self.conn = psycopg2.connect(self.config["pgvector_conn_string"])
            self.cur = self.conn.cursor()
        except psycopg2.OperationalError as e:
            self.conn = None
            self.cur = None
            self.logger.warning(f"⚠️ Could not connect to PGVector DB: {e}")
            
    def list_indexes(self):
        """Show all available vector indexes from PGVector."""
    
        if not self.conn:
            self.logger.warning("⚠️ PGVector DB connection not available — skipping list_indexes()")
            return []
    
        try:
            query = """
                SELECT model_key, table_name, dimension, created_at
                FROM vector_indexes
            """
            with self.conn.cursor() as cur:
                cur.execute(query)
                rows = cur.fetchall()
    
                return [
                    {
                        "ModelKey": row[0],
                        "TableName": row[1],
                        "Dimension": row[2],
                        "CreatedAt": row[3].isoformat() if hasattr(row[3], "isoformat") else str(row[3])
                    }
                    for row in rows
                ]
    
        except Exception as e:
            self.logger.error(f"❌ Error fetching vector index list: {e}", exc_info=True)
            return []


    def index_create(self, embeddings, model_key, metadata=None):
        """Create and store embeddings in PGVector."""
    
        if not self.conn:
            self.logger.warning("⚠️ PGVector DB connection not available — skipping index_create()")
            return []
    
        try:
            self.logger.info(f"❓ Creating PGVector index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            self.logger.info(f"⚙️ Preparing to insert {vector_count} embeddings with dimension {dim}")
    
            for i in range(vector_count):
                self.cur.execute(
                    """
                    INSERT INTO model_embeddings (model_key, embedding, metadata)
                    VALUES (%s, %s, %s)
                    """,
                    (
                        model_key,
                        embeddings[i].tobytes(),
                        json.dumps(metadata[i]) if metadata else None,
                    )
                )
    
            self.conn.commit()
            self.logger.info(f"✅ PGVector index created and embeddings added for {model_key}")
    
        except Exception as e:
            self.logger.error(f"❌ Error creating PGVector index for {model_key}: {e}", exc_info=True)
            raise


    def index_load(self, model_key):
        """Check if the PGVector index exists for a given model_key."""
        if not self.conn:
            self.logger.warning("⚠️ PGVector DB connection not available — skipping index_load()")
            return []
            
        try:
            self.cur.execute("""
                SELECT EXISTS (
                    SELECT 1 FROM pg_catalog.pg_attribute WHERE attname = 'embedding' AND attrelid = (
                        SELECT oid FROM pg_catalog.pg_class WHERE relname = 'model_embeddings')
                );
            """)
            exists = self.cur.fetchone()[0]
            if not exists:
                self.logger.warning(f"⚠️ PGVector index for {model_key} does not exist. Rebuilding...")
                self.rebuild_pgvector_index(model_key)
            else:
                self.logger.info(f"✅ PGVector index for {model_key} is valid.")
        except Exception as e:
            self.logger.warning(f"⚠️ Error checking PGVector index for {model_key}: {e}")
            self.rebuild_pgvector_index(model_key)

    def get_index_status(self):
        """Get the status of PGVector indexes."""
        if not self.conn:
            self.logger.warning("⚠️ PGVector DB connection not available — skipping get_index_status()")
            return []
            
        status = []
        try:
            self.cur.execute("SELECT model_key, COUNT(*) FROM model_embeddings GROUP BY model_key;")
            results = self.cur.fetchall()
            for row in results:
                model_key = row[0]
                num_embeddings = row[1]
                status.append({
                    "Model": model_key,
                    "Indexed Embeddings": num_embeddings,
                    "Status": "🟢" if num_embeddings > 0 else "🔴"
                })
        except Exception as e:
            self.logger.error(f"❌ Error fetching PGVector index status: {e}")
        return status

# Example of how to use PGVectorStore class
#pgvector_store = PGVectorStore(config, s3)

# Now, your setup should be working, and the PGVector connection parameters will be handled correctly
