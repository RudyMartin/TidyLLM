#  core/FaissStore.py
import os
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import io
import faiss
import json
import logging
import numpy as np
from datetime import datetime
import streamlit as st
import multiprocessing

from core.model_key_utils import (
    validate_model_key,
    get_model_details,
    get_faiss_s3_key,
    get_index_filename,
)
from core.embedding_helper import AmazonEmbeddingVectorizer
from core.logging_helper import get_logger, get_model_log_path, log_to_file
from core.s3_utils import list_objects_s3, load_json_from_s3, save_json_to_s3, save_faiss_index_to_s3
from core.tuning_utils import suggest_training_sample_count, calculate_nlist, calculate_nprobe
from core.client_bundle import get_client_bundle

from core.embedding_utils import data_collect

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

# --- Logging and Settings ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

TEST_JSON_DIR = "test/json"
REEMBED_LIST_PATH = os.path.join("logs/faiss", "reembed_list.json")

# list_indexes():
# Lists the FAISS index files stored in S3 based on a given prefix.

# index_create(embeddings, model_key, metadata=None):
# Creates and trains a FAISS index using the provided embeddings, then saves it to S3.

# collect_embeddings_and_metadata(model_key):
# Collects embeddings and metadata from JSON files in S3 for a specific model.
# (Updated to compute the full key using the config structure.)

# embeddings_batch(model_keys):
# Processes multiple model keys by collecting embeddings and creating the FAISS index for each.
# It logs detailed progress and returns a summary of the indexing status.

# index_load(model_key):
# Loads a FAISS index from S3, rebuilding it if necessary.

# get_index_status():
# Returns a status report for each model’s FAISS index, including whether it’s trained, the number of vectors, and the last modification time.

# index_real(model_key):
# Checks if a FAISS index file exists in S3 for the given model.

# index_empty(model_key):
# A placeholder for identifying indices that are missing embeddings or contain invalid vectors.

# validate_and_embed_missing_vectors(model_keys, vectorizer, clients, show_ui=True):
# Validates each JSON file to ensure it contains the required embedding; if missing, generates and uploads the embedding.

# search_by(model_key, query_embedding, k=5):
# Executes a similarity search on the FAISS index using a query embedding and returns the top-k results.

# current_timestamp():
# A utility function that returns the current UTC timestamp as an ISO-formatted string.



class FaissStore:
    # 🔧 Initialization & Configuration ----------------------------------------
    def __init__(self, config, s3_client, logger):
        self.config = config
        self.s3_client = s3_client
        self.logger = logger

    # 🏗️ Index Creation & Training ----------------------------------------
    def list_indexes(self):
        bucket = self.config["bucket_name"]
        prefix = self.config.get("index_folder", "idx")
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        items = response.get("Contents", [])
        return [
            {
                "Key": item["Key"],
                "LastModified": item["LastModified"].isoformat() if hasattr(item["LastModified"], "isoformat") else str(item["LastModified"]),
                "Size": item["Size"]
            }
            for item in items
        ]
    
    def index_create(self, embeddings, model_key, metadata=None):
        try:
            self.logger.info(f"❓ Creating FAISS index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            raw_nlist = self.config["nlist"]
            nlist = calculate_nlist(vector_count, raw_nlist)
            nprobe = calculate_nprobe(vector_count)
            self.logger.info(f"⚙️ Adjusted nlist: {nlist}, nprobe: {nprobe}, vector_count={vector_count}")
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_L2)
            if not index.is_trained:
                self.logger.info(f"📝 Training FAISS index for {model_key}...")
                index.train(embeddings)
                self.logger.info(f"✅ FAISS index trained for {model_key}.")
            index.add(embeddings)
            self.logger.info(f"✅ Added embeddings to FAISS index for {model_key}.")
            bucket = self.config["bucket_name"]
            prefix = self.config["prefix"]
            # Save the FAISS index using only 4 parameters.
            save_faiss_index_to_s3(bucket, prefix, index, model_key)
            self.logger.info(f"✅ FAISS index and metadata saved for {model_key}")
        except Exception as e:
            self.logger.error(f"❌ Error creating FAISS index for {model_key}: {e}")
            raise

    def collect_embeddings_and_metadata(self, model_key, force=False):
        return data_collect(self.config, self.s3_client, model_key, self.logger, force=force)
    
    # def collect_embeddings_and_metadata(self, model_key):
    #     """
    #     Collects embeddings and metadata for the given model key.
    #     Assumes embeddings in S3 JSON files are stored under a full key derived from config.
    #     """
    #     training_embeddings = []
    #     metadata = []
    #     bucket = self.config["bucket_name"]
    #     json_folder = self.config.get("json_folder", "json")
    #     json_keys = list_objects_s3(bucket, json_folder, extension=".json")
    #     total_files = len(json_keys)
    #     self.logger.info(f"Found {total_files} JSON files for collecting embeddings for {model_key}.")
    
    #     model_info = self.config["model_options"].get(model_key)
    #     if not model_info:
    #         self.logger.warning(f"Model key {model_key} not found in configuration.")
    #         return training_embeddings, metadata
    #     full_key = f"{model_info['id']}_{model_info['dimensions']}"
    
    #     for json_key in json_keys:
    #         try:
    #             data = load_json_from_s3(bucket, json_key)
    #             if "embeddings" in data and full_key in data["embeddings"]:
    #                 embed_info = data["embeddings"][full_key]
    #                 vector = embed_info.get("vector")
    #                 expected_dim = model_info["dimensions"]
    #                 if vector and len(vector) == expected_dim:
    #                     vector_np = np.array(vector, dtype=np.float32)
    #                     training_embeddings.append(vector_np)
    #                     metadata.append({
    #                         "source": json_key,
    #                         "embed_date": embed_info.get("embed_date", ""),
    #                         "model_key": model_key
    #                     })
    #                     self.logger.debug(f"Collected valid embedding from {json_key}.")
    #                 else:
    #                     self.logger.debug(f"Skipping {json_key}: invalid vector dimensions for {model_key}.")
    #             else:
    #                 self.logger.debug(f"No embedding for {model_key} in {json_key}.")
    #         except Exception as e:
    #             self.logger.error(f"Error loading embeddings from {json_key}: {e}")
    
    #     self.logger.info(f"Collected {len(training_embeddings)} embeddings for {model_key} out of {total_files} files.")
    #     return training_embeddings, metadata


    def embeddings_batch(self, model_keys, force=False):
        summary_status = []
        for model_key in model_keys:
            log_path = get_model_log_path(model_key)
            with open(log_path, "w") as log_file:
                log_to_file(log_file, f"\U0001F4D8 Starting batch indexing for {model_key}")
                training_embeddings, metadata = self.collect_embeddings_and_metadata(model_key, force=force)
                log_to_file(log_file, f"Collected {len(training_embeddings)} valid embeddings")
    
                sample_threshold = suggest_training_sample_count(len(training_embeddings), max_samples=self.config["num_training_samples"])
                if len(training_embeddings) < sample_threshold:
                    msg = f"❌ Not enough vectors. Required: {sample_threshold}, Found: {len(training_embeddings)}"
                    log_to_file(log_file, msg, "error")
                    summary_status.append({"Model": model_key, "Error": msg})
                    continue
    
                training_data = np.vstack(training_embeddings).astype(np.float32)
                faiss.omp_set_num_threads(multiprocessing.cpu_count())
                self.index_create(training_data, model_key, metadata)
                log_to_file(log_file, f"✅ Index saved for {model_key} with {training_data.shape[0]} vectors")
        return summary_status

    # 📦 Index Management & Validation ----------------------------------------
    def index_load(self, model_key):
        model_info = self.config["model_options"][model_key]
        expected_dim = model_info["dimensions"]
        # Use the short model_key for constructing the S3 key for the FAISS index file.
        index_key = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_key}_{expected_dim}.faiss"
        try:
            response = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_key)
            index_bytes = response["Body"].read()
            index = faiss.deserialize_index(index_bytes)
            if not index.is_trained or index.d != expected_dim or index.ntotal == 0:
                self.logger.warning(f"⚠️ FAISS index for {model_key} is invalid. Rebuilding...")
                self.rebuild_faiss_index(model_key)
                return self.index_load(model_key)
            self.logger.info(f"✅ Loaded FAISS index for {model_key} from S3")
            return index
        except Exception as e:
            self.logger.warning(f"⚠️ No existing FAISS index for {model_key}: {e}. Rebuilding...")
            self.rebuild_faiss_index(model_key)
            return self.index_load(model_key)

    def get_index_status(self):
        status = []
        for model_key, model_info in self.config["model_options"].items():
            expected_dim = model_info["dimensions"]
            index_key = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_key}_{expected_dim}.faiss"
            def repair():
                self.embeddings_batch([model_key])
            try:
                response = self.s3_client.head_object(Bucket=self.config["bucket_name"], Key=index_key)
                last_modified = response["LastModified"].strftime("%Y-%m-%d %H:%M")
                obj = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_key)
                index_bytes = obj["Body"].read()
                index = faiss.deserialize_index(index_bytes)
                badge = "🟢" if index.is_trained and index.ntotal > 0 else "🟡" if index.is_trained else "🔴"
                status.append({
                    "Model": model_key,
                    "Trained": index.is_trained,
                    "Vectors": index.ntotal,
                    "Dim": index.d,
                    "Status": badge,
                    "LastModified": last_modified,
                    "Repair": repair
                })
            except Exception as e:
                status.append({
                    "Model": model_key,
                    "Trained": False,
                    "Vectors": 0,
                    "Dim": expected_dim,
                    "Status": "🔴",
                    "LastModified": "N/A",
                    "Error": str(e),
                    "Repair": repair
                })
        return status

    def index_real(self, model_key):
        """Check if index file exists in S3 for given model_key."""
        model_info = self.config["model_options"].get(model_key)
        if not model_info:
            return False
        expected_dim = model_info["dimensions"]
        index_file = f"{model_key}_{expected_dim}.faiss"
        s3_keys = list_objects_s3(self.config["bucket_name"], f"{self.config['prefix']}/{self.config['index_folder']}")
        return f"{self.config['prefix']}/{self.config['index_folder']}/{index_file}" in s3_keys

    def index_empty(self, model_key):
        """
        Placeholder: Index files missing embeddings or with invalid vectors.
    
        TODO:
            - Identify documents missing the specified model_key embedding.
            - Optionally trigger auto-embedding or mark for reprocessing.
        """
        pass
    
    def validate_and_embed_missing_vectors(self, model_keys, vectorizer, clients, show_ui=True, force=False):
        """
        Validate that all expected embeddings exist for each model_key.
        If missing, generate and upload embeddings.
        
        Args:
            model_keys (List[str]): List of selected model keys.
            vectorizer (AmazonEmbeddingVectorizer or compatible): Embedding generator.
            clients (ClientBundle): Contains config and S3 client.
            show_ui (bool): If True, shows Streamlit status and messages.
            force (bool): Whether to force re-embedding even if embeddings already exist.
        """
        config = clients.config
        s3_client = clients.s3
        bucket = config["bucket_name"]
        json_folder = config["json_folder"]
        json_keys = list_objects_s3(bucket, json_folder, extension=".json")
        
        if not json_keys:
            if show_ui:
                st.warning(f"⚠️ No JSON files found in `{json_folder}`.")
            return

        
        if show_ui:
            st.info(f"🔍 Validating {len(json_keys)} JSON files for missing embeddings...")
            
        logger.info(f"🔍 Validating {len(json_keys)} JSON files for missing embeddings...fs_296")
        
        valid_embeddings = 0  # Keep track of valid embeddings collected
    
        for json_key in json_keys:
            try:
                obj = s3_client.get_object(Bucket=bucket, Key=json_key)
                content = obj["Body"].read().decode("utf-8").strip()
                
                if not content:
                    if show_ui:
                        st.warning(f"⚠️ Empty file: `{json_key}` — skipping.")
                    continue
    
                data = json.loads(content)
                modified = False
    
                # Process each model key for embeddings
                for model_key in model_keys:
                    model_info = config["model_options"].get(model_key)
                    if not model_info:
                        continue
                    dim = model_info["dimensions"]
                    full_key = f"{model_info['id']}_{dim}"
    
                    # Check if embedding exists or if force flag is set
                    if "embeddings" in data and full_key in data["embeddings"]:
                        vector = data["embeddings"][full_key].get("vector")
                        if vector and len(vector) == dim and not force:
                            continue  # Already embedded correctly and not forcing re-embedding
    
                    # Process text and generate new embedding if necessary
                    text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])
                    if is_blank_page(text, data.get("chunks", [])):
                        if show_ui:
                            st.info(f"⏭️ Skipping blank page: `{json_key}`")
                        continue
    
                    # DEBUGGING: Track the embedding generation
                    print(f"🚀 Generating embedding for `{json_key}` using model `{model_key}`...")
    
                    # Generate new vector (embedding)
                    new_vector = vectorizer.generate_embedding(text)
    
                    # DEBUGGING: Track the generated vector
                    print(f"✅ Generated new vector for `{json_key}`: {new_vector[:5]}...")  # Print first 5 elements for tracking
    
                    # Save the generated vector into the data
                    data.setdefault("embeddings", {})[full_key] = {
                        "dimensions": dim,
                        "embed_date": current_timestamp(),
                        "vector": new_vector
                    }
    
                    valid_embeddings += 1
                    modified = True
    
                # If there were any modifications, update the file on S3
                if modified:
                    s3_client.put_object(
                        Bucket=bucket,
                        Key=json_key,
                        Body=json.dumps(data, indent=2).encode("utf-8"),
                        ContentType="application/json"
                    )
                    if show_ui:
                        st.success(f"✅ Updated embeddings for `{json_key}`")
    
            except json.JSONDecodeError as e:
                if show_ui:
                    st.warning(f"⚠️ JSON error in `{json_key}`: {e}")
            except Exception as e:
                if show_ui:
                    st.warning(f"⚠️ Error in `{json_key}`: {e}")
        
        if valid_embeddings < 50:
            st.warning(f"⚠️ Only {valid_embeddings} valid embeddings found. At least 50 are required for indexing.")
        return valid_embeddings


    # 🔍 Index Search & Query ----------------------------------------
    def search_by(self, model_key: str, query_embedding: np.ndarray, k: int = 5) -> list:
        try:
            index = self.index_load(model_key)
            if query_embedding.ndim == 1:
                query_embedding = query_embedding.reshape(1, -1)
            if query_embedding.shape[1] != index.d:
                raise ValueError(f"Query embedding dim {query_embedding.shape[1]} ≠ index dim {index.d}")
            distances, indices = index.search(query_embedding, k)
            results = []
            for rank, (idx, dist) in enumerate(zip(indices[0], distances[0])):
                if idx == -1:
                    continue
                results.append({
                    "rank": rank + 1,
                    "index": int(idx),
                    "distance": float(dist)
                })
            self.logger.info(f"🔍 FAISS search completed for model '{model_key}' with {len(results)} results")
            return results
        except Exception as e:
            self.logger.error(f"❌ Error during FAISS search for model '{model_key}': {e}")
            return []


# ⏱️ Utility Functions ----------------------------------------
def current_timestamp():
    return datetime.utcnow().isoformat() + "Z"

