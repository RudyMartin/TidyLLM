# core/client_utils.py

import boto3
import os
import logging
from functools import lru_cache
from core.config_helper import get_config
import streamlit as st

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def get_clients_flexible(config=None):
    """
    Flexible version of get_clients: uses provided config,
    or Streamlit session_state, or get_config().
    Not cached.
    """
    if config is None and st and "config" in st.session_state:
        config = st.session_state["config"]

    if config is None:
        config = get_config()  # fallback to default disk config

    region = config.get("aws_region") or config.get("region_name") or os.environ.get("AWS_REGION", "us-east-1")
    logger.info(f"🌍 Initializing AWS clients for region: {region}")
    return {
        "s3": boto3.client("s3", region_name=region),
        "bedrock": boto3.client("bedrock-runtime", region_name=region),
    }

@lru_cache
def get_clients():
    """
    Cached version of get_clients using the default config only.
    This is safe for use with @st.cache_resource or @lru_cache.
    """
    return get_clients_flexible()

def get_s3():
    """Retrieve the S3 client."""
    return get_clients().get("s3")

def get_bedrock():
    """Retrieve the Bedrock client."""
    return get_clients().get("bedrock")
