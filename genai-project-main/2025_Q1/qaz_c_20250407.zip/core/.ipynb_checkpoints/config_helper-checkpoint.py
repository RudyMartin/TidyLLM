# [File: core/config_helper.py]
# Description: Centralized configuration helper.
# This module loads, saves, and manages configuration settings from JSON files.
# It includes both low-level file utilities and high-level accessors that handle
# environment overrides, fallbacks, and safe usage within Streamlit or CLI contexts.

import os
import json
import logging

# -------------------------------
# 🔧 Logging Setup
# -------------------------------
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# -------------------------------
# 📁 Path Definitions
# -------------------------------
# These define where your primary and fallback config files live.
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "config.json")
DEFAULT_CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "default_config.json")
LOG_DIR = os.path.join(PROJECT_DIR, "logs")

# -------------------------------
# 📘 Low-Level Disk Operations
# -------------------------------
# These functions directly load or save JSON files. They do not apply any environment
# logic or streamlit session handling. Use them if you know the exact path.

def load_config(path: str = CONFIG_PATH) -> dict:
    """
    Load a JSON config file from a given path (default is CONFIG_PATH).
    Use this only when you need to load a specific config file.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r") as f:
        return json.load(f)

def save_config(config, path=CONFIG_PATH):
    """
    Save a dictionary config to disk as JSON.
    This is a general-purpose save function; it can be pointed to any file.
    """
    try:
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
        logger.info(f"✅ Config saved to {path}")
    except Exception as e:
        logger.error(f"❌ Failed to save config to {path}: {e}")

def restore_default_config():
    """
    Restore configuration from the fallback default_config.json.
    This does not modify session state — it’s for recovery or manual override.
    """
    return load_config(DEFAULT_CONFIG_PATH)

# -------------------------------
# 🧠 High-Level Config Access
# -------------------------------
# This is the main way the app should access configuration.
# It supports environment variable overrides and safe fallbacks.
# Use this in any module that needs configuration context.

def get_config() -> dict:
    """
    Loads configuration from an environment override (CONFIG_PATH), or defaults to
    the main config file. If that fails, it falls back to default_config.json.

    This is the most reliable and recommended way to retrieve the current app config.
    """
    env_path = os.environ.get("CONFIG_PATH")
    if env_path and os.path.exists(env_path):
        logger.info(f"📦 Loading config from ENV path: {env_path}")
        return load_config(env_path)
    try:
        return load_config(CONFIG_PATH)
    except FileNotFoundError:
        logger.warning("⚠️ Config not found. Using default config.")
        return load_config(DEFAULT_CONFIG_PATH)
