# core/faiss_log_reader.py
"""
Description:
  Retrieves audit logs from S3 and optionally performs semantic similarity search using FAISS.

Version: DSPy 2.5.26

Responsibilities:
  - Load audit logs from S3 (JSON)
  - Filter by signature, metadata, or timestamp
  - Perform semantic search using VectorManager embeddings
  - Export logs to CSV

Dependencies:
  - core/vector_manager.py
  - core/config_helper.py
  - core/client_helper.py
  - core/s3_utils.py
"""

import logging
import csv
from datetime import datetime
from typing import List, Dict, Any

from core.config_helper import get_config
from core.client_helper import get_clients
from core.s3_utils import list_objects_s3, load_json_from_s3
from core.vector_manager import VectorManager

logger = logging.getLogger("faiss_log_reader")
logger.setLevel(logging.DEBUG)

# --- S3 Utilities ---

def load_all_logs_from_s3(prefix: str) -> List[Dict[str, Any]]:
    """
    Loads all audit log entries from JSON files in S3 under the specified prefix.
    """
    config = get_config()
    s3_client, _ = get_clients()
    bucket = config["bucket_name"]

    logs = []
    files = list_objects_s3(bucket, prefix, extension="json")
    for file_key in files:
        try:
            data = load_json_from_s3(bucket, file_key)
            logs.extend(data)
        except Exception as e:
            logger.warning(f"Failed to load {file_key}: {e}")
    return logs

# --- Filters ---

def filter_logs_by_signature(logs: List[Dict[str, Any]], signature: str) -> List[Dict[str, Any]]:
    return [log for log in logs if log.get("signature") == signature]

def filter_logs_by_metadata_key(logs: List[Dict[str, Any]], key: str, value: Any) -> List[Dict[str, Any]]:
    return [log for log in logs if log.get("metadata", {}).get(key) == value]

def filter_logs_by_date_range(logs: List[Dict[str, Any]], start: datetime, end: datetime) -> List[Dict[str, Any]]:
    def within_range(log):
        ts_str = log.get("timestamp")
        if ts_str:
            try:
                ts = datetime.fromisoformat(ts_str)
                return start <= ts <= end
            except Exception as e:
                logger.debug(f"Invalid timestamp in log: {ts_str}")
        return False

    return [log for log in logs if within_range(log)]

# --- Semantic Search ---

def semantic_search_logs_s3(query: str, model_key: str, s3_prefix: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """
    Perform semantic search over logs stored in S3.
    """
    logs = load_all_logs_from_s3(s3_prefix)
    texts = [log["text"] for log in logs if "text" in log]

    if not texts:
        logger.warning("No valid text entries found in logs.")
        return []

    vector_manager = VectorManager()
    query_results = vector_manager.semantic_compare(query, texts, model_key=model_key, top_k=top_k)

    matches = []
    for idx, score in query_results:
        matched_log = logs[idx]
        matched_log["score"] = score
        matches.append(matched_log)

    return matches

# --- Export ---

def export_logs_to_csv(logs: List[Dict[str, Any]], file_path: str):
    """
    Exports logs to a local CSV file.
    """
    keys = ["timestamp", "signature", "text", "metadata"]
    with open(file_path, mode="w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for log in logs:
            row = {key: log.get(key, "") for key in keys}
            row["metadata"] = str(row["metadata"])
            writer.writerow(row)
    logger.info(f"Logs exported to {file_path}")

# --- Formatter ---

def format_log_result(entry: Dict[str, Any]) -> str:
    ts = entry.get("timestamp", "unknown")
    meta = entry.get("metadata", {})
    score = entry.get("score", None)
    score_part = f" [score: {score:.3f}]" if score else ""
    return f"[{ts}]{score_part} → {entry['text'][:80]}... (meta: {meta})"
