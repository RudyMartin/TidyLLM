# [File: core/client_manager.py]
# Description: Delegates AWS client access to core/client_utils with safe fallback.

from core.client_utils import get_clients, get_clients_flexible

def get_client(name: str, config: dict = None):
    """
    Return a specific AWS client by name.
    Uses flexible config logic (e.g., from Streamlit session).
    Safe for non-cached usage.
    """
    return get_clients_flexible(config).get(name)

def default_s3_client():
    """Return the default cached S3 client."""
    return get_clients().get("s3")

def default_bedrock_client():
    """Return the default cached Bedrock client."""
    return get_clients().get("bedrock")
