# core/config_editor.py

import os
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
from datetime import datetime

CONFIG_PATH = "config/config.json"
DEFAULT_CONFIG_PATH = "config/default_config.json"

def save_config(new_config: dict, path: str = CONFIG_PATH):
    with open(path, "w") as f:
        json.dump(new_config, f, indent=2)

def log_config_change(action: str, new_config: dict):
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    log_path = f"logs/config_change_{timestamp}.json"
    os.makedirs("logs", exist_ok=True)
    with open(log_path, "w") as f:
        json.dump({"action": action, "config": new_config}, f, indent=2)

def restore_defaults() -> dict:
    """
    Loads default_config.json and replaces the active config.json with it.
    Also logs the change.
    
    Returns:
        dict: The restored default configuration.
    """
    try:
        with open(DEFAULT_CONFIG_PATH, "r") as f:
            default_config = json.load(f)
        save_config(default_config, CONFIG_PATH)
        log_config_change("Restored Defaults", default_config)
        return default_config
    except Exception as e:
        raise RuntimeError(f" Failed to restore default config: {e}")
