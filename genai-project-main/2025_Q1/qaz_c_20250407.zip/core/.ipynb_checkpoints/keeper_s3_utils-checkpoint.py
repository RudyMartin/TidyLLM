# [File: core/s3_utils.py]
# Utility functions for interacting with AWS S3.

import logging
import json
import boto3
import faiss
from typing import List
from core.logging_helper import get_logger  # Import logging utility

# Logging setup
logger = get_logger("s3_utils")
logger.setLevel(logging.DEBUG)

# --- Lazy Client Initialization ---
def get_s3_client(config=None):
    """Lazy initialization of S3 client."""
    from core.client_manager import get_clients  # Import here to avoid circular import
    clients = get_clients(config)
    return clients.get("s3")

def get_bedrock_client(config=None):
    """Lazy initialization of Bedrock client."""
    from core.client_manager import get_clients  # Import here to avoid circular import
    clients = get_clients(config)
    return clients.get("bedrock")

# --- S3 Utility Functions ---
def list_objects_s3(bucket: str, prefix: str, extension: str = None, config=None) -> list:
    """Lists objects in a specified S3 bucket with an optional file extension filter."""
    try:
        s3_client = get_s3_client(config)  # Use the lazy-loaded S3 client
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        if extension:
            keys = [key for key in keys if key.endswith(extension)]
        return keys
    except Exception as e:
        logger.error(f"❌ Error listing objects in bucket {bucket} with prefix {prefix}: {e}")
        return []

def list_pdf_files_s3(bucket: str, prefix: str = "", config=None) -> List[str]:
    """List PDF files in an S3 bucket."""
    return list_objects_s3(bucket, prefix, extension=".pdf", config=config)

def list_json_files_s3(bucket: str, prefix: str = "", config=None) -> List[str]:
    """List JSON files in an S3 bucket."""
    return list_objects_s3(bucket, prefix, extension=".json", config=config)

def list_s3_files_with_extension(bucket: str, prefix: str, extension: str = ".pdf", config=None) -> list:
    """List files with a specific extension in an S3 bucket."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        return [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(extension)]
    except Exception as e:
        logger.error(f"❌ Failed to list files with extension {extension}: {e}")
        return []

def list_folders_s3(bucket: str, prefix: str = "", config=None) -> List[str]:
    """List folder prefixes in an S3 bucket."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        return [cp["Prefix"] for cp in response.get("CommonPrefixes", [])]
    except Exception as e:
        logger.error(f"❌ Error listing folders under {prefix}: {e}")
        return []

def check_s3_object_tag(bucket: str, key: str, tag_key: str, config=None) -> bool:
    """Check if an S3 object has a specific tag."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        response = s3_client.get_object_tagging(Bucket=bucket, Key=key)
        tags = {tag["Key"]: tag["Value"] for tag in response.get("TagSet", [])}
        return tag_key in tags
    except s3_client.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "AccessDenied":
            logger.warning(f"⚠️ Access denied checking tags for {key}")
        else:
            logger.error(f"❌ Error checking tags for {key}: {e}")
        return False

def load_json_from_s3(bucket: str, key: str, config=None) -> dict:
    """Load JSON data from an S3 object."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        response = s3_client.get_object(Bucket=bucket, Key=key)
        return json.loads(response["Body"].read().decode("utf-8"))
    except Exception as e:
        logger.error(f"❌ Failed to load JSON from s3://{bucket}/{key}: {e}")
        return {}

def save_json_to_s3(bucket: str, key: str, data: dict, config=None):
    """Save JSON data to an S3 object."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        s3_client.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        logger.info(f"✅ Saved JSON to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to save JSON to s3://{bucket}/{key}: {e}")
        
# --- FAISS Index Operations ---
def save_faiss_index_to_s3(bucket, prefix, index, model_key, config=None):
    """Save FAISS index to S3."""
    s3_client = get_s3_client(config)  # Access S3 client lazily
    try:
        model_info = get_config_state()["model_options"][model_key]
        model_id = model_info["id"]
        dim = model_info["dimensions"]
        index_name = f"faiss_index_{model_id.replace(':', '_')}_{dim}.faiss"
        model_folder = f"{model_key}/{dim}"
        s3_key = f"{prefix}/{model_folder}/{index_name}".strip("/")
        index_bytes = faiss.serialize_index(index)
        s3_client.put_object(
            Bucket=bucket,
            Key=s3_key,
            Body=index_bytes,
            ContentType="application/octet-stream"
        )
        logger.info(f"✅ FAISS index saved to s3://{bucket}/{s3_key}")
    except Exception as e:
        logger.error(f"❌ Failed to save FAISS index: {e}")
        raise

def check_faiss_index_exists(bucket, prefix, model_key, config=None) -> bool:
    """
    Check if a FAISS index file exists in S3 for a given model_key.
    """
    s3_client = get_s3_client(config)
    try:
        from core.config_manager import get_config_state
        model_info = get_config_state()["model_options"][model_key]
        model_id = model_info["id"]
        dim = model_info["dimensions"]
        index_name = f"faiss_index_{model_id.replace(':', '_')}_{dim}.faiss"
        model_folder = f"{model_key}/{dim}"
        s3_key = f"{prefix}/{model_folder}/{index_name}".strip("/")

        s3_client.head_object(Bucket=bucket, Key=s3_key)
        logger.info(f"📦 FAISS index exists at s3://{bucket}/{s3_key}")
        return True

    except s3_client.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "404":
            logger.info(f"⚠️ FAISS index not found at s3://{bucket}/{s3_key}")
            return False
        logger.error(f"❌ Error checking FAISS index: {e}")
        return False


def load_faiss_index_from_s3(bucket, prefix, model_key, config=None):
    """
    Load a FAISS index from S3 given the model_key and prefix path.
    """
    s3_client = get_s3_client(config)
    try:
        from core.config_manager import get_config_state  # avoid circular imports
        model_info = get_config_state()["model_options"][model_key]
        model_id = model_info["id"]
        dim = model_info["dimensions"]
        index_name = f"faiss_index_{model_id.replace(':', '_')}_{dim}.faiss"
        model_folder = f"{model_key}/{dim}"
        s3_key = f"{prefix}/{model_folder}/{index_name}".strip("/")

        response = s3_client.get_object(Bucket=bucket, Key=s3_key)
        index_bytes = response["Body"].read()
        index = faiss.deserialize_index(index_bytes)
        logger.info(f"✅ Loaded FAISS index from s3://{bucket}/{s3_key}")
        return index

    except Exception as e:
        logger.error(f"❌ Failed to load FAISS index from s3://{bucket}/{prefix}: {e}")
        return None


 # ---------- J ----------
def upload_to_s3(bucket: str, key: str, data, content_type: str = "application/octet-stream"):
    s3 = get_s3_client()
    try:
        s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
        logger.info(f"✅ Uploaded file to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to upload file to s3://{bucket}/{key}: {e}")    

# --- Log File Cleanup Function ---
def cleanup_log_files(s3_client, config, dry_run: bool = True):
    log_folder = config["log_folder"]
    bucket = config["bucket_name"]

    # List log files in the S3 bucket folder
    log_files = list_s3_files_with_extension(bucket, log_folder, "log")

    if dry_run:
        print("**Dry Run Mode:** No files will be deleted. Here's what would be removed.")
        print(f"Log files to delete: {len(log_files)}")
        print(log_files or "No log files found.")
    else:
        deleted = 0
        for key in log_files:
            s3_client.delete_object(Bucket=bucket, Key=key)
            deleted += 1
        print(f"Cleanup complete: {deleted} log files removed.")   

def cleanup_ingestion_folders(s3_client, config, dry_run: bool = True):
    bucket = config["bucket_name"]
    pages_folder = config["page_folder"]
    json_folder = config["json_folder"]
    pdf_folder = config["pdf_folder"]

    # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(bucket, pages_folder, "pdf")
    pdf_keys = list_s3_files_with_extension(bucket, pdf_folder, "pdf")
    json_keys = list_s3_files_with_extension(bucket, json_folder, "json")

    total_files = len(page_keys) + len(json_keys)

    if dry_run:
        st.info("**Dry Run Mode:** No files will be deleted. Here's what would be removed.")
        st.markdown(f"### PDF files to delete: `{len(page_keys)}`")
        st.write(page_keys or "No PDF files found.")
        st.markdown(f"### JSON files to delete: `{len(json_keys)}`")
        st.write(json_keys or "No JSON files found.")
        st.info(f"Total files identified for deletion: `{total_files}`")
    else:
        deleted = {"pdfs": 0, "jsons": 0}
        with st.spinner("Deleting files..."):
            for key in page_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["pdfs"] += 1

            for key in json_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["jsons"] += 1

        st.success(f"Cleanup complete: {deleted['pdfs']} PDF pages and {deleted['jsons']} JSONs removed.")
       
