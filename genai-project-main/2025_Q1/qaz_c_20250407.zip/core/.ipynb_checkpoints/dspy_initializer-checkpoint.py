# core/dspy_initializer.py

from core.embedding_manager import get_cached_vectorizer
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")

def init_dspy_embedding_vectorizer():
    """
    Returns the shared cached vectorizer for DSPy pipelines.
    """
    return get_cached_vectorizer()

# Usage:
# vectorizer = init_dspy_embedding_vectorizer()