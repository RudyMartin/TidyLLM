# --- pgVector Helper Functions ---
# [File: core/pgvector_utils.py]
# Description: Provides helper functions for interacting with pgVector: creating indices,
# searching the index, and loading saved indexes.

import logging
from core.s3_utils import load_json_from_s3, list_s3_files_with_extension
from core.config_helper import get_config
from core.pgvector_store import PGVectorStore  # pgVector class to interact with pgvector DB or simulated index

config = get_config()
logger = logging.getLogger(__name__)

def pgvector_available(config=None) -> bool:
    """Check if the pgVector DB is available."""
    config = config or get_config()
    dsn = config.get("pgvector_conn_string")

    if not dsn:
        logger.warning("⚠️ No pgvector_conn_string found in config.")
        return False

    try:
        conn = psycopg2.connect(dsn)
        conn.close()
        return True
    except psycopg2.OperationalError as e:
        logger.warning(f"⚠️ PGVector DB not available: {e}")
        return False

def create_pgvector_index(s3_client, config, bucket_name, json_folder):
    """Create a pgVector index from JSON files stored in S3."""
    json_files = list_s3_files_with_extension(bucket_name, json_folder, "json")
    index_params = config.get("pgvector_index_params", {})  # Fetch pgVector index params from config
    index = PGVector(index_params)

    # Add vectors to the index
    for json_file in json_files:
        vectors = load_json_from_s3(s3_client, bucket_name, json_file)
        for vector in vectors:
            index.add_vector(vector)  # Add each vector to the index
    
    # Save the index to S3
    index_name = f"pgvector_index_{config['index_version']}.index"
    index.save_to_s3(s3_client, bucket_name, config["index_folder"], index_name)
    return index_name

def search_pgvector_index(query, config, s3_client, bucket_name, index_folder):
    """Search the pgVector index for similarity to the query."""
    index_name = f"pgvector_index_{config['index_version']}.index"
    index = load_pgvector_index(s3_client, bucket_name, index_folder, index_name)
    return index.search(query)

def load_pgvector_index(s3_client, bucket_name, index_folder, index_name):
    """Load an existing pgVector index from S3."""
    # Example logic to load index
    index = PGVector.load_from_s3(s3_client, bucket_name, index_folder, index_name)
    return index




