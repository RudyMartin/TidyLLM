"""
Updated Embedding Manager
Unified interface for embedding operations using the updated AmazonEmbeddingVectorizer.

This updated code integrates the suggested enhancements: • The AmazonEmbeddingVectorizer constructor now accepts config, s3_client, and bedrock_client.
• The generate_embedding() method always uses a model_key (defaulting if not provided) and validates the embedding dimensions.
• The EmbeddingManager wraps the vectorizer and exposes methods for generating embeddings and updating JSON data.

"""

import json
from datetime import datetime
import numpy as np
import streamlit as st

from core.config_helper import get_config
from core.client_manager import get_clients
from core.logging_helper import get_logger
from core.model_key_utils import get_model_details

# ---------- Updated AmazonEmbeddingVectorizer ----------
class AmazonEmbeddingVectorizer:
    def __init__(self, config, s3_client, bedrock_client):
        self.config = config
        self.s3 = s3_client
        self.bedrock = bedrock_client
        # Extract default model key from config; fallback to 'titan_v2_1024' if not provided
        self.default_model_key = config.get("default_model_key", "titan_v2_1024")
        self.logger = get_logger("AmazonEmbeddingVectorizer")

    def _call_bedrock(self, text, model_id):
        """
        This function should implement the call to the Bedrock embedding model.
        For demonstration purposes, it simulates a response.
        In production, replace this with the actual API call.
        """
        self.logger.info(f"Calling Bedrock model '{model_id}' for text embedding.")
        # Simulate an embedding vector as a list of floats.
        # The simulated dimension is determined by the model configuration.
        # For example, here we assume 1024 dimensions.
        simulated_dim = 1024
        simulated_embedding = [0.1] * simulated_dim
        return simulated_embedding

    def generate_embedding(self, text, model_key=None):
        """
        Generate an embedding for the given text using the specified model_key.
        If model_key is not provided, the default from config is used.
        Validates that the returned embedding matches the expected dimension.
        """
        model_key = model_key or self.default_model_key
        model_info = self.config["model_options"].get(model_key)
        if model_info is None:
            raise ValueError(f"Model key '{model_key}' not found in configuration.")
        model_id = model_info["id"]
        expected_dim = model_info["dimensions"]

        # Call the embedding model (via Bedrock)
        embedding = self._call_bedrock(text, model_id)

        if len(embedding) != expected_dim:
            raise ValueError(f"Embedding dimension mismatch. Expected {expected_dim}, got {len(embedding)}")
        return embedding

# ---------- Updated EmbeddingManager ----------
class EmbeddingManager:
    def __init__(self, config=None, clients=None, vectorizer=None):
        # Load configuration and clients if not provided
        self.config = config or get_config()
        self.clients = clients or get_clients(self.config)
        self.s3 = self.clients.get("s3")
        self.bedrock = self.clients.get("bedrock")
        # Initialize the AmazonEmbeddingVectorizer with new parameters
        self.vectorizer = vectorizer or AmazonEmbeddingVectorizer(self.config, self.s3, self.bedrock)
        self.logger = get_logger("EmbeddingManager")

    def generate(self, text, model_key=None):
        """
        Generate an embedding for the provided text using the specified model key.
        """
        try:
            embedding = self.vectorizer.generate_embedding(text, model_key)
            self.logger.info("Embedding generated successfully.")
            return embedding
        except Exception as e:
            self.logger.error(f"Error generating embedding: {e}")
            raise

    def flatten_embedding(self, data: dict, model_key: str):
        """
        Placeholder method for flattening embedding data.
        Replace with actual implementation if needed.
        """
        return data

    def collect_embeddings(self, model_key: str, force: bool = False):
        """
        Placeholder method for collecting embeddings.
        Replace with actual implementation if needed.
        """
        return []

    def reembed_flagged(self):
        """
        Placeholder for re-embedding flagged entries.
        """
        pass

    def append_to_reembed_list(self, file, model_key, reason):
        """
        Placeholder for appending entries to the re-embed list.
        """
        pass

    def embed_and_update_json(self, json_data: dict, json_key: str, model_key: str, force=False):
        """
        Generate an embedding and update the provided JSON object with the embedding data.
        """
        if not self.bedrock:
            self.logger.error("Missing Bedrock client. Embedding skipped.")
            return    

        model_info = get_model_details(model_key, self.config["model_options"])
        if not force and model_key in json_data.get("embeddings", {}):
            self.logger.info(f"Skipping {json_key} — already embedded with model '{model_key}'.")
            return

        text = json_data.get("text", "") or " ".join(
            chunk.get("text", "") for chunk in json_data.get("chunks", [])
        )
        if not text.strip():
            self.logger.warning(f"No valid text found in {json_key}; skipping embedding.")
            return

        vector = self.generate(text, model_key)

        json_data.setdefault("embeddings", {})
        json_data["embeddings"][model_key] = {
            "id": model_info["id"],
            "dimensions": model_info["dimensions"],
            "embed_date": datetime.utcnow().isoformat() + "Z",
            "vector": vector
        }

        # Save the updated JSON to S3
        self.s3.put_object(
            Bucket=self.config["bucket_name"],
            Key=json_key,
            Body=json.dumps(json_data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        self.logger.info(f"Embedded and updated '{json_key}' with model '{model_key}'.")

# Re-exports
__all__ = [
    "AmazonEmbeddingVectorizer",
    "EmbeddingManager"
]
