# core/faiss_helper.py
"""
Description:
  General-purpose FAISS helper module for indexing, searching, and managing vectors.

Version: DSPy 2.5.26

Responsibilities:
  - Add vectors to FAISS
  - Search vectors
  - Save/load FAISS index to/from S3
  - Maintain separation of config and clients (no top-level side effects)

Dependencies:
  - core/vector_manager.py
  - core/s3_utils.py
  - core/config_helper.py
  - core/client_helper.py

Ah — YES! 💡 You’re 100% right, Rudy.

Your FAISS audit logs are stored in S3 as structured JSON, and your workflow is:

Write audit entries to FAISS + save JSON to S3 (via faiss_log_writer.py)

Load + search those logs from S3 (not just from the in-memory FAISS index)

S3 is the ground truth; FAISS is the retrieval layer



  
"""

import logging
import hashlib
from datetime import datetime

from core.config_helper import get_config
from core.client_helper import get_clients
from core.vector_manager import VectorManager
from core.s3_utils import list_objects_s3, load_json_from_s3

logger = logging.getLogger("faiss_helper")
logger.setLevel(logging.DEBUG)

def generate_signature(text: str) -> str:
    """Returns a SHA-256 hash to uniquely identify text input."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def add_entry_to_faiss(text: str, metadata: dict, model_key: str, vector_manager: VectorManager):
    """
    Adds a single entry to FAISS after embedding.
    """
    logger.debug(f"Adding entry to FAISS for model_key: {model_key}")
    embedding = vector_manager.embed_text(text, model_key=model_key)
    vector_manager.add_vector(embedding, {
        "text": text,
        "metadata": metadata,
        "timestamp": datetime.utcnow().isoformat(),
        "signature": generate_signature(text)
    }, model_key=model_key)

def search_faiss(query: str, model_key: str, vector_manager: VectorManager, top_k: int = 5):
    """
    Search FAISS index using the given model_key and return top_k matches.
    """
    logger.debug(f"Searching FAISS with model_key: {model_key}")
    return vector_manager.search(query, model_key=model_key, top_k=top_k)

def reindex_faiss_from_s3(model_key: str, prefix: str):
    """
    Reindexes FAISS using all JSON entries stored at a given S3 prefix.
    """
    config = get_config()
    s3_client, _ = get_clients()
    bucket = config["bucket_name"]
    json_files = list_objects_s3(bucket, prefix, extension="json")
    vector_manager = VectorManager()

    for file_key in json_files:
        entries = load_json_from_s3(bucket, file_key)
        for entry in entries:
            if "text" in entry and "metadata" in entry:
                add_entry_to_faiss(entry["text"], entry["metadata"], model_key, vector_manager)

    logger.info(f"FAISS reindex completed for model_key={model_key} from prefix={prefix}")
