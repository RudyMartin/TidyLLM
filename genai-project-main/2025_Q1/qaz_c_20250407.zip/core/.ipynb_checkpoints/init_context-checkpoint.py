# [File: core/init_context.py]
# Description: Central context loader for Streamlit tabs

from typing import NamedTuple, Optional

from core.config_helper import get_config
from core.client_manager import get_clients
from core.embedding_helper import get_cached_vectorizer
from core.vector_manager import VectorManager

class TabContext(NamedTuple):
    clients: dict
    config: dict
    vectorizer: object
    manager: VectorManager

def get_tab_context(store_type: str = "faiss", model_key: Optional[str] = None) -> TabContext:
    """
    Initialize and return the shared context for Streamlit tabs.

    This loads the configuration, initializes AWS clients,
    prepares the cached vectorizer, and creates a vector store manager.
    """
    config = get_config()
    clients = get_clients(config)

    vectorizer = (
        get_cached_vectorizer() if model_key is None
        else get_cached_vectorizer(model_key=model_key)
    )

    manager = VectorManager(store_type, config, clients)

    return TabContext(clients=clients, config=config, vectorizer=vectorizer, manager=manager)


#  Includes A TabContext named tuple for cleaner unpacking.

# Optional model_key argument for future fine-tuned vectorizer selection.

# Key Points
# Unified Initialization: All tabs can call get_tab_context() to get a ready-to-use context. This function uses get_client_bundle() to initialize any required clients (database connections, APIs, etc.) and their shared config in one go, ensuring consistency across the app.
# Configuration Access: The config is obtained from the clients bundle (e.g. via a .config attribute). This makes the configuration easily accessible to other components without needing to load it separately.
# Vectorizer Setup: By calling get_cached_vectorizer(), the function ensures an embedding model (vectorizer) is loaded once and cached for reuse. This avoids redundant loading in each tab, keeping the module lightweight and efficient.
# Vector Store Manager: A VectorManager is instantiated with the specified store_type (defaulting to "faiss" for a FAISS-backed store). It receives the shared config and clients, and manages vector index operations accordingly. This design allows flexibility if you later support other store types (just pass a different store_type string).
# Simple Tuple Return: The function returns a plain tuple (clients, config, vectorizer, manager) for simplicity. This avoids using a namedtuple or custom container, reducing complexity and potential dependency issues. Each Streamlit tab can unpack this tuple to get all needed components in one line.
# Lightweight & Dependency-Safe: The module imports only the minimal functions/classes from the core package and does not perform any heavy computations itself. By leveraging caching (for the vectorizer) and existing initialization functions, it remains lightweight. There are no external dependencies introduced here, so it's safe to use in any tab without side-effects.
# No Circular Imports: Placing the shared setup in init_context.py eliminates cross-imports between tabs and core components. None of the imported modules (core.client_bundle, core.embedding_helper, or the module defining VectorManager) import init_context in return, so no circular import arises. This approach follows a common pattern of moving interdependent code into a single module to break cyclic dependencies​

#