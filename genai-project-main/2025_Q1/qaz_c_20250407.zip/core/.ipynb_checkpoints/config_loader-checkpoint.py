# core/config_loader.py
# core/config_loader.py
import json
import os
import streamlit as st
from datetime import datetime

# Paths to config files
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "config.json")
DEFAULT_CONFIG_PATH = os.path.join(PROJECT_DIR, "config", "default_config.json")
LOG_DIR = os.path.join(PROJECT_DIR, "logs")

def load_config(path: str = CONFIG_PATH) -> dict:
    """Load a JSON config file from disk."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"Config file not found: {path}")
    with open(path, "r") as f:
        return json.load(f)

def save_config(config, path=CONFIG_PATH):
    """Save configuration to a JSON file."""
    try:
        with open(path, "w") as f:
            json.dump(config, f, indent=2)
    except Exception as e:
        print(f"Failed to save config: {e}")

def restore_default_config():
    """Restore the default configuration."""
    return load_config(DEFAULT_CONFIG_PATH)

def log_config_change(action, config_data):
    """Log any change to the configuration."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_message = {
        "action": action,
        "timestamp": timestamp,
        "config_data": config_data
    }
    log_file = os.path.join(LOG_DIR, f"config_change_{timestamp}.json")
    try:
        with open(log_file, "w") as f:
            json.dump(log_message, f, indent=2)
    except Exception as e:
        print(f"Failed to log config change: {e}")
