# core/faiss_log_writer.py
"""
Description:
  Writes structured audit logs to both FAISS and S3 (as JSON).

Responsibilities:
  - Create structured audit entries (text, metadata, timestamp, signature)
  - Store logs in S3 for traceability
  - Embed logs into FAISS for semantic retrieval

Version: DSPy 2.5.26

Dependencies:
  - core/vector_manager.py
  - core/s3_utils.py
  - core/config_helper.py
  - core/client_helper.py
"""

import logging
import json
import hashlib
from datetime import datetime
from typing import Dict, List, Optional

from core.config_helper import get_config
from core.client_helper import get_clients
from core.vector_manager import VectorManager
from core.s3_utils import save_json_to_s3

logger = logging.getLogger("faiss_log_writer")
logger.setLevel(logging.DEBUG)

# --- Core Utilities ---

def generate_signature(text: str) -> str:
    """Returns SHA-256 hash to uniquely identify text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

def build_audit_log_entry(text: str, metadata: Dict[str, any]) -> Dict[str, any]:
    """Builds a structured log entry."""
    return {
        "text": text,
        "metadata": metadata,
        "timestamp": datetime.utcnow().isoformat(),
        "signature": generate_signature(text)
    }

# --- Write to FAISS and S3 ---

def write_audit_log_entry(text: str, metadata: Dict[str, any], model_key: str, s3_prefix: Optional[str] = None):
    """
    Creates, embeds, and stores a structured audit log entry to both FAISS and S3.
    """
    config = get_config()
    s3_client, _ = get_clients()
    vector_manager = VectorManager()

    entry = build_audit_log_entry(text, metadata)

    # Store to FAISS
    embedding = vector_manager.embed_text(text, model_key=model_key)
    vector_manager.add_vector(embedding, entry, model_key=model_key)
    logger.debug(f"Entry embedded and added to FAISS under model_key={model_key}")

    # Store to S3
    bucket = config["bucket_name"]
    s3_folder = s3_prefix or config.get("log_directory", "dev/logs")
    file_key = f"{s3_folder}/log_{entry['signature']}.json"
    save_json_to_s3(s3_client, bucket, file_key, [entry])
    logger.info(f"Audit log saved to S3: s3://{bucket}/{file_key}")

def batch_write_logs_to_s3(log_entries: List[Dict[str, any]], model_key: str, s3_prefix: Optional[str] = None):
    """
    Given a list of structured log entries, embed and store them in FAISS and S3.
    Each log entry must contain: text, metadata
    """
    config = get_config()
    s3_client, _ = get_clients()
    vector_manager = VectorManager()

    bucket = config["bucket_name"]
    s3_folder = s3_prefix or config.get("log_directory", "dev/logs")

    for entry in log_entries:
        text = entry.get("text")
        metadata = entry.get("metadata", {})
        if not text:
            continue

        log_entry = build_audit_log_entry(text, metadata)

        # Embed + Add to FAISS
        embedding = vector_manager.embed_text(text, model_key=model_key)
        vector_manager.add_vector(embedding, log_entry, model_key=model_key)

        # Save to S3
        file_key = f"{s3_folder}/log_{log_entry['signature']}.json"
        save_json_to_s3(s3_client, bucket, file_key, [log_entry])
        logger.debug(f"Batch log saved: s3://{bucket}/{file_key}")

    logger.info(f"Batch of {len(log_entries)} logs written to FAISS and S3.")
