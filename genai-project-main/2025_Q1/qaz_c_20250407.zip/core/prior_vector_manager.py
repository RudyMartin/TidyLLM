# [File: core/vector_manager.py]
# Description: Vector Manager interface to support FAISS and pgVector backends.

import logging
from core.config_helper import get_config
from core.client_manager import get_clients
from core.logging_helper import get_logger
from core.model_key_utils import get_model_details  # Optional, used by helpers

class VectorManager:
    def __init__(self, store_type="faiss", config=None, clients=None):
        """
        Initialize the VectorManager for a specific backend store.

        Args:
            store_type (str): Which vector backend to use ("faiss", "pgvector").
            config (dict): Optional config override, else loads default.
            clients (dict): Optional clients override, else loads default.
        """
        self.config = config or get_config()
        self.clients = clients or get_clients(self.config)
        self.store_type = store_type
        self.logger = get_logger("vector_manager")
        self.index_store = self._init_store()

    def _init_store(self):
        """
        Create the appropriate vector store based on store_type.
        """
        if self.store_type == "faiss":
            from core.faiss_store import FaissStore
            return FaissStore(config=self.config, s3_client=self.clients["s3"], logger=self.logger)
        elif self.store_type == "pgvector":
            from core.pgvector_store import PGVectorStore
            return PGVectorStore(config=self.config, s3_client=self.clients["s3"])
        else:
            raise ValueError(f"Unsupported store_type: {self.store_type}. Choose 'faiss' or 'pgvector'.")


    # ---------- Embedding Validation & Indexing ----------
    def validate_and_embed_missing(self, selected_models, vectorizer, force=False, show_ui=True):
        return self.index_store.validate_and_embed_missing_vectors(
        model_keys=selected_models,
        vectorizer=vectorizer,
        clients=self.clients,
        force=force,  # Pass 'force' here
        show_ui=show_ui,
    )

    def index_batch(self, model_keys):
        return self.index_store.embeddings_batch(model_keys)

    def build_index_from_vectors(self, vectors, model_key):
        return self.index_store.create_faiss_index_from_embeddings(vectors, model_key)

    # ---------- Index Health ----------
    def get_index_status(self):
        return self.index_store.get_index_status()

    def get_index_stats(self):
        return self.index_store.get_vector_statistics()

    def index_health_summary(self):
        return self.index_store.health_summary()

    # ---------- Maintenance ----------
    def reset_index(self, model_key):
        return self.index_store.reset(model_key)

    def delete_index(self, model_key):
        return self.index_store.delete(model_key)

    def list_available_indexes(self):
        return self.index_store.list_indexes()

    # ---------- Optional (Advanced Validation) ----------
    def validate_model_embeddings(self, model_key, log_to_repair_list=False):
        if hasattr(self.index_store, "validate_json_embeddings"):
            return self.index_store.validate_json_embeddings(model_key, log_to_repair_list)
        else:
            raise NotImplementedError(
                f"{self.store_type} does not support embedding validation."
            )
