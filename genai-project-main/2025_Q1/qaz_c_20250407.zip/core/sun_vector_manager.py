import logging
from core.config_helper import get_config
from core.client_manager import get_clients
from core.logging_helper import get_logger

class VectorManager:
    def __init__(self, store_type="faiss", config=None, clients=None):
        # Load configuration and clients if not provided
        self.config = config or get_config()
        self.clients = clients or get_clients(self.config)
        self.store_type = store_type
        self.logger = get_logger("vector_manager")
        self.index_store = self._init_store()

    def _init_store(self):
        # Initialize the appropriate store, passing both S3 and Bedrock clients
        if self.store_type == "faiss":
            from core.faiss_store import FaissStore
            return FaissStore(
                config=self.config,
                s3_client=self.clients["s3"],
                bedrock_client=self.clients["bedrock"],
                logger=self.logger
            )
        elif self.store_type == "pgvector":
            from core.pgvector_store import PGVectorStore
            return PGVectorStore(
                config=self.config,
                s3_client=self.clients["s3"],
                bedrock_client=self.clients["bedrock"]
            )
        else:
            raise ValueError(f"Unsupported store_type: {self.store_type}. Choose 'faiss' or 'pgvector'.")

    @property
    def s3(self):
        return self.clients.get("s3")

    @property
    def bedrock(self):
        return self.clients.get("bedrock")