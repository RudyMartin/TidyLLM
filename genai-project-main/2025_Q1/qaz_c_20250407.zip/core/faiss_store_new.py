# [File: core/faiss_store.py]
# Description: FAISS index management for vector embeddings.

import os
import faiss
import json
import logging
import numpy as np
import multiprocessing
from datetime import datetime
import streamlit as st

from core.model_key_utils import (
    validate_model_key,
    get_model_details,
    get_faiss_s3_key,
    get_index_filename,
)
from core.embedding_helper import AmazonEmbeddingVectorizer
from core.logging_helper import get_model_log_path, log_to_file
from core.s3_utils import (
    list_objects_s3,
    load_json_from_s3,
    save_json_to_s3,
    save_faiss_index_to_s3
)
from core.tuning_utils import (
    suggest_training_sample_count,
    calculate_nlist,
    calculate_nprobe
)
from core.embedding_utils import data_collect
from core.vector_base import BaseVectorStore

class FaissStore(BaseVectorStore):
    def __init__(self, config, s3_client, logger):
        super().__init__(config=config, s3_client=s3_client, logger=logger)

    def list_indexes(self):
        bucket = self.config["bucket_name"]
        prefix = self.config.get("index_folder", "idx")
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        items = response.get("Contents", [])
        return [
            {
                "Key": item["Key"],
                "LastModified": item["LastModified"].isoformat() if hasattr(item["LastModified"], "isoformat") else str(item["LastModified"]),
                "Size": item["Size"]
            }
            for item in items
        ]

    def index_create(self, embeddings, model_key, metadata=None):
        try:
            self.logger.info(f"❓ Creating FAISS index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            raw_nlist = self.config["nlist"]
            nlist = calculate_nlist(vector_count, raw_nlist)
            nprobe = calculate_nprobe(vector_count)
            self.logger.info(f"⚙️ Adjusted nlist: {nlist}, nprobe: {nprobe}, vector_count={vector_count}")

            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_L2)
            if not index.is_trained:
                self.logger.info(f"📝 Training FAISS index for {model_key}...")
                index.train(embeddings)
                self.logger.info(f"✅ FAISS index trained for {model_key}.")

            index.add(embeddings)
            self.logger.info(f"✅ Added embeddings to FAISS index for {model_key}.")

            bucket = self.config["bucket_name"]
            prefix = self.config["prefix"]
            save_faiss_index_to_s3(bucket, prefix, index, model_key)
            self.logger.info(f"✅ FAISS index and metadata saved for {model_key}")
        except Exception as e:
            self.logger.error(f"❌ Error creating FAISS index for {model_key}: {e}")
            raise

    def collect_embeddings_and_metadata(self, model_key, force=False):
        return data_collect(self.config, self.s3_client, model_key, self.logger, force=force)

    def embeddings_batch(self, model_keys, force=False):
        summary_status = []
        for model_key in model_keys:
            log_path = get_model_log_path(model_key)
            with open(log_path, "w") as log_file:
                log_to_file(log_file, f"📘 Starting batch indexing for {model_key}")
                training_embeddings, metadata = self.collect_embeddings_and_metadata(model_key, force=force)
                log_to_file(log_file, f"Collected {len(training_embeddings)} valid embeddings")

                sample_threshold = suggest_training_sample_count(len(training_embeddings), max_samples=self.config["num_training_samples"])
                if len(training_embeddings) < sample_threshold:
                    msg = f"❌ Not enough vectors. Required: {sample_threshold}, Found: {len(training_embeddings)}"
                    log_to_file(log_file, msg, "error")
                    summary_status.append({"Model": model_key, "Error": msg})
                    continue

                training_data = np.vstack(training_embeddings).astype(np.float32)
                faiss.omp_set_num_threads(multiprocessing.cpu_count())
                self.index_create(training_data, model_key, metadata)
                log_to_file(log_file, f"✅ Index saved for {model_key} with {training_data.shape[0]} vectors")
        return summary_status

    def index_load(self, model_key):
        model_info = self.config["model_options"][model_key]
        expected_dim = model_info["dimensions"]
        index_key = f"{self.config['prefix']}/{self.config['index_folder']}/faiss_index_{model_key}_{expected_dim}.faiss"
        try:
            response = self.s3_client.get_object(Bucket=self.config["bucket_name"], Key=index_key)
            index_bytes = response["Body"].read()
            index = faiss.deserialize_index(index_bytes)
            if not index.is_trained or index.d != expected_dim or index.ntotal == 0:
                self.logger.warning(f"⚠️ FAISS index for {model_key} is invalid. Rebuilding...")
                self.rebuild_faiss_index(model_key)
                return self.index_load(model_key)
            self.logger.info(f"✅ Loaded FAISS index for {model_key} from S3")
            return index
        except Exception as e:
            self.logger.warning(f"⚠️ No existing FAISS index for {model_key}: {e}. Rebuilding...")
            self.rebuild_faiss_index(model_key)
            return self.index_load(model_key)

    def get_index_status(self):
        # ... unchanged for brevity
        pass

    def search_by(self, model_key: str, query_embedding: np.ndarray, k: int = 5) -> list:
        try:
            index = self.index_load(model_key)
            if query_embedding.ndim == 1:
                query_embedding = query_embedding.reshape(1, -1)
            if query_embedding.shape[1] != index.d:
                raise ValueError(f"Query embedding dim {query_embedding.shape[1]} ≠ index dim {index.d}")
            distances, indices = index.search(query_embedding, k)
            return [
                {"rank": i+1, "index": int(idx), "distance": float(dist)}
                for i, (idx, dist) in enumerate(zip(indices[0], distances[0])) if idx != -1
            ]
        except Exception as e:
            self.logger.error(f"❌ Error during FAISS search for model '{model_key}': {e}")
            return []


def current_timestamp():
    return datetime.utcnow().isoformat() + "Z"
