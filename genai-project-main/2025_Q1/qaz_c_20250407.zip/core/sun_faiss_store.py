import faiss
import numpy as np
from datetime import datetime
from core.tuning_utils import calculate_nlist, calculate_nprobe
from core.s3_utils import save_faiss_index_to_s3
from core.vector_base import BaseVectorStore

class FaissStore(BaseVectorStore):
    def __init__(self, config, s3_client, bedrock_client, logger):
        # Initialize BaseVectorStore and save the Bedrock client reference
        super().__init__(config=config, s3_client=s3_client, logger=logger)
        self.bedrock_client = bedrock_client

    def list_indexes(self):
        bucket = self.config["bucket_name"]
        prefix = self.config.get("index_folder", "idx")
        response = self.s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        items = response.get("Contents", [])
        return [
            {
                "Key": item["Key"],
                "LastModified": item["LastModified"].isoformat() if hasattr(item["LastModified"], "isoformat") else str(item["LastModified"]),
                "Size": item["Size"]
            }
            for item in items
        ]

    def index_create(self, embeddings, model_key, metadata=None):
        try:
            self.logger.info(f"Creating FAISS index for model: {model_key}")
            dim = embeddings.shape[1]
            vector_count = embeddings.shape[0]
            raw_nlist = self.config["nlist"]
            nlist = calculate_nlist(vector_count, raw_nlist)
            nprobe = calculate_nprobe(vector_count)
            self.logger.info(f"Using nlist: {nlist}, nprobe: {nprobe} for {vector_count} vectors")

            # Create the FAISS index (IVFFlat with a flat L2 quantizer)
            quantizer = faiss.IndexFlatL2(dim)
            index = faiss.IndexIVFFlat(quantizer, dim, nlist, faiss.METRIC_L2)
            if not index.is_trained:
                self.logger.info("Training FAISS index...")
                index.train(embeddings)
                self.logger.info("FAISS index trained.")

            index.add(embeddings)
            self.logger.info("Embeddings added to FAISS index.")

            # Save the index to S3
            bucket = self.config["bucket_name"]
            prefix = self.config["prefix"]
            save_faiss_index_to_s3(bucket, prefix, index, model_key)
            self.logger.info("FAISS index saved to S3.")
        except Exception as e:
            self.logger.error(f"Error creating FAISS index for {model_key}: {e}")
            raise