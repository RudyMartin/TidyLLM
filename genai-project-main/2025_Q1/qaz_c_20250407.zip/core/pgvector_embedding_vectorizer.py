# core/pgvector_embedding_vectorizer.py

import numpy as np
import logging
import json
import psycopg2
from typing import Optional
from core.config_helper import get_config
from core.client_helper import get_clients
from core.model_key_utils import validate_model_key
from core.logging_helper import get_logger

logger = get_logger("PgVectorEmbeddingVectorizer")

class PgVectorEmbeddingVectorizer:
    def __init__(self, config=None, model_key=None, dimensions=None, connection=None):
        self.config = config or get_config()
        self.connection = connection or self._init_connection()
        self.model_key = model_key or self.config.get("default_model_option", "titan_v2")
        self.dimensions = dimensions or self._resolve_dimensions()

        logger.info(f"✅ Initialized pgVector vectorizer: model_key={self.model_key}, dims={self.dimensions}")

    def _init_connection(self):
        """Initialize the PostgreSQL connection using config settings."""
        try:
            db_settings = self.config["pgvector"]
            conn = psycopg2.connect(
                dbname=db_settings["database"],
                user=db_settings["user"],
                password=db_settings["password"],
                host=db_settings["host"],
                port=db_settings.get("port", 5432),
            )
            logger.info("✅ PostgreSQL connection established.")
            return conn
        except Exception as e:
            logger.error(f"❌ Failed to connect to PostgreSQL: {e}", exc_info=True)
            raise

    def _resolve_dimensions(self):
        model_options = self.config.get("model_options", {})
        validated_key = validate_model_key(self.model_key, model_options)
        return model_options[validated_key]["dimensions"]

    def generate_embedding(self, text: str, normalize: bool = True) -> list:
        """
        Simulated embedding generation using database-stored embeddings.
        This could later be replaced with an inference engine or SQL UDF.
        """
        with self.connection.cursor() as cur:
            cur.execute("SELECT embedding FROM embeddings WHERE text = %s LIMIT 1;", (text,))
            result = cur.fetchone()
            if not result:
                logger.warning("⚠️ No embedding found for the provided text.")
                return []

            embedding = result[0]  # Assuming pgvector column returns as Python list/array
            if normalize:
                embedding = self._normalize_vector(embedding)
            return embedding

    def _normalize_vector(self, vector):
        norm = np.linalg.norm(vector)
        return [x / norm for x in vector] if norm > 0 else vector

    def close(self):
        if self.connection:
            self.connection.close()
            logger.info("🔒 PostgreSQL connection closed.")

    @classmethod
    def from_config(cls, config=None):
        return cls(config=config or get_config())
