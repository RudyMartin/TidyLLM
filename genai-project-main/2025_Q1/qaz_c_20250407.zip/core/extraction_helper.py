"""
[File: extraction_helper.py]
Handles PDF-to-text extraction and structured JSON output.
"""

import unicodedata
from core.config_manager import get_config  # 🔗 [Config Type 4️⃣ Core Utility: Needs classification]
config = get_config()  # 🔗 [Config Type 4️⃣ Core Utility: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 4️⃣ Core Utility: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import os
import re
import io
import json
import logging
from pathlib import Path
from datetime import datetime
from functools import lru_cache
from typing import List, Dict, Optional

import nltk
from PyPDF2 import PdfReader, PdfWriter
from botocore.exceptions import ClientError
import boto3



from core.logging_helper import get_logger
from core.s3_utils import (
    list_objects_s3,
    save_json_to_s3,
    load_json_from_s3,
    upload_file_to_s3,
    delete_s3_object,
)

# Global fallback values
from core.client_bundle import get_client_bundle
clients = get_client_bundle()
config_default = clients.config
s3_client_default = clients.s3

from core.logging_helper import get_logger

# --- Logging and Settings ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

LOG_DIR = "logs/indexing"
Path(LOG_DIR).mkdir(parents=True, exist_ok=True)

# ---------- NLTK SETUP ----------
@lru_cache(maxsize=1)
def ensure_nltk():
    try:
        nltk.data.find("tokenizers/punkt")
    except LookupError:
        nltk.download("punkt")

ensure_nltk()


# ---------- TEXT CLEANING ----------

def clean_text(text: str) -> str:
    """
    Cleans extracted text by normalizing Unicode characters, removing newlines,
    tabs, and excessive whitespace. This helps to reduce artifacts from PDF extraction.
    """
    # Normalize unicode characters to a consistent form (NFKC)
    #text = unicodedata.normalize("NFKC", text)
    # Remove multiple newlines but **keep paragraph breaks**
    text = re.sub(r'\n{2,}', '\n', text)  # Keeps a single \n for meaningful breaks
    # Remove common PDF artifacts (e.g., incorrect range values)
    text = text.replace('0.00-10', '0.00')
    # Remove multiple spaces, newlines, and excessive whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    # Fix hyphenated line breaks (common in PDF text extraction)
    text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)
    return text.strip()

def clean_text_for_display(text):
    """
    Cleans extracted text by applying common text preprocessing steps.
    - Fixes common OCR artifacts
    - Standardizes formatting
    - Removes unwanted characters and excessive newlines
    """
    # Normalize Unicode characters (e.g., convert fancy quotes to ASCII)
    text = unicodedata.normalize("NFKD", text)
    
    # Encode and decode to normalize text before embedding
    text = text.encode('utf-8').decode('utf-8')

    # Remove common PDF artifacts (e.g., incorrect range values)
    text = text.replace('0.00-10', '0.00')

    # Fix hyphenated line breaks (common in PDF text extraction)
    text = re.sub(r'(\w+)-\s+(\w+)', r'\1\2', text)

    # Remove multiple spaces, newlines, and excessive whitespace
    text = re.sub(r'\s+', ' ', text).strip()

    # Remove multiple newlines but **keep paragraph breaks**
    text = re.sub(r'\n{2,}', '\n', text)  # Keeps a single \n for meaningful breaks

    # Optional: Remove all `\n` if not needed at all
    text = text.replace("\n", " ")

    # Remove special characters that don’t contribute to meaning
    text = re.sub(r'[^\w\s.,;!?%$-]', '', text)  # Keeps punctuation but removes junk

    return text



# ---------- CHUNKING + STRUCTURE ----------


def chunk_text_into_segments(pdf_page_data: Dict, max_words: int = None, config=config_default) -> List[Dict]:
    """Splits academic text into semantically meaningful chunks before embedding."""
    try:
        max_words = max_words or config["chunk_size"]
        text = pdf_page_data.get('text', '')

        if not text.strip():
            return []

        page_number = pdf_page_data.get("page_number", 1)
        document_name = pdf_page_data.get("document_name", "unknown.pdf").replace(".pdf", "")

        chunks = []
        chunked_texts = smart_chunking(text, max_words)  # Use smart chunking

        for i, chunk_text in enumerate(chunked_texts):
            chunk_id = f"{document_name}_{page_number}_{i+1:03d}"
            chunks.append({"chunk_id": chunk_id, "text": chunk_text})

        return chunks

    except Exception as e:
        logger.error(f" Error chunking text: {e}")
        return []


def smart_chunking(text, max_words=200):
    """Splits academic text into semantically meaningful chunks using sentence + sub-sentence splitting."""
    sentences = nltk.sent_tokenize(text)  # Split text into sentences
    chunks = []
    current_chunk = []
    current_length = 0

    for sentence in sentences:
        sentence_length = len(sentence.split())

        # If sentence is too long, attempt secondary splitting at logical points
        if sentence_length > max_words:
            sub_sentences = re.split(r'[;,:]|\\b(and|but|or|which|that)\\b', sentence)
            sub_sentences = [s.strip() for s in sub_sentences if s]  # Remove empty splits
        else:
            sub_sentences = [sentence]

        for sub_sentence in sub_sentences:
            sub_length = len(sub_sentence.split())

            # Start a new chunk if adding this sub-sentence exceeds max_words
            if current_length + sub_length > max_words:
                chunks.append(" ".join(current_chunk))
                current_chunk = []
                current_length = 0

            current_chunk.append(sub_sentence)
            current_length += sub_length

    if current_chunk and len(" ".join(current_chunk).split()) > 5:
        chunks.append(" ".join(current_chunk))

    return chunks


def save_page_chunks_as_json_s3(original_key: str, chunks: List[Dict], config, s3_client):
    """Saves all text chunks from a single page into one JSON file."""
    try:
        bucket = config["bucket_name"]
        json_folder = config["json_folder"]

        document_name = os.path.splitext(os.path.basename(original_key))[0]
        match = re.search(r'_page_(\\d+)', original_key)
        page_number = match.group(1) if match else "unknown"

        text_date = datetime.now().isoformat()

        page_json_structure = {
            "metadata": {
                "document_name": document_name,
                "page_number": page_number,
                "text_date": text_date,
                "tags": []
            },
            "chunks": chunks,
            "embeddings": {}
        }

        if not re.search(r'_page_\\d+', document_name):
            document_name = f"{document_name}_page_{page_number}"

        chunk_key = f"{json_folder}/{document_name}.json"

        s3_client.put_object(Bucket=bucket, Key=chunk_key, Body=json.dumps(page_json_structure).encode('utf-8'))

        logger.info(f" Saved all chunks for {document_name} in {chunk_key}")

    except Exception as e:
        logger.error(f" Error saving page chunks to JSON: {e}")

def prepare_pdf_splits(config=config_default, s3_client=s3_client_default):
    """Splits all PDFs in the configured S3 folder into pages and uploads them."""
    processed_count = 0
    try:
        pdf_keys = [k for k in list_objects_s3(config["bucket_name"], config["pdf_folder"]) if k.endswith(".pdf")]
        logger.info(f" Found {len(pdf_keys)} PDFs to split.")

        for pdf_key in pdf_keys:
            logger.info(f" Splitting PDF: {pdf_key}")
            split_pdf_into_pages_s3(pdf_key, config, clients.s3)
            processed_count += 1

        logger.info(f" Finished splitting all PDFs into pages. Total: {processed_count}")
        return processed_count

    except Exception as e:
        logger.error(f" Error splitting PDFs: {e}")
        return processed_count


def extract_text_from_pdf_page_s3(page_key: str, config=config_default, s3_client=s3_client_default, next_page_key: str = None) -> Dict:
    """Extracts text from a single-page PDF and optionally appends the first sentence of the next page."""
    try:
        bucket = config["bucket_name"]
        response = s3_client.get_object(Bucket=bucket, Key=page_key)
        pdf_file = response["Body"].read()

        reader = PdfReader(io.BytesIO(pdf_file))
        text = reader.pages[0].extract_text() or ""
        text = clean_text(text)  # Apply text cleaning before proceeding
        
        page_number = int(page_key.split("_")[-1].split(".")[0])

        # Try to capture page continuity if a next page exists
        if next_page_key:
            try:
                next_response = s3_client.get_object(Bucket=bucket, Key=next_page_key)
                next_pdf_file = next_response["Body"].read()
                next_reader = PdfReader(io.BytesIO(next_pdf_file))
                next_text = next_reader.pages[0].extract_text() or ""

                #  Fix: Actually append the first sentence from the next page
                if validate_page_continuity(text, next_text):
                    next_sentences = nltk.sent_tokenize(next_text)
                    if next_sentences:
                        text += " " + next_sentences[0]  # Append first sentence from the next page
                        logger.info(f" Appended first sentence from {next_page_key} to {page_key}")

            except Exception as e:
                logger.warning(f" Could not retrieve next page {next_page_key}: {e}")

        return {"document_name": os.path.basename(page_key), "page_number": page_number, "text": text.strip()}

    except Exception as e:
        logger.error(f" Error extracting text from {page_key}: {e}")
        return {"page_number": None, "text": ""}


def validate_page_continuity(text_current: str, text_next: str) -> bool:
    """Checks if the current page ends mid-sentence and suggests merging the next page's first sentence."""
    sentences = nltk.sent_tokenize(text_current)
    if sentences and not sentences[-1].endswith(('.', '!', '?')):
        logger.warning(" Possible broken sentence at page boundary. Consider appending the next page's first sentence.")
        return True
    return False

def is_blank_page(text: str, chunks: List[Dict] = None, min_length: int = 10) -> bool:
    """
    Determines if a PDF page is blank or contains no useful text.
    """
    if not text or len(text.strip()) < min_length:
        return True
    if chunks is not None and len(chunks) == 0:
        return True
    return False

## same as below currently but  different name (carefull!!)
def extract_text_from_pdf():
    extract_text_to_json

def save_extracted_text_to_json():
    extract_text_to_json()

def extract_text_to_json(config=config_default, s3_client=s3_client_default):
    """Processes each page in S3, extracts text, chunks it, and saves as JSON. Adds #blankpage tag for empty pages."""
    processed_pages = 0
    blank_pages = 0

    try:
        page_keys = list_objects_s3(config["bucket_name"], config["page_folder"], extension=".pdf")
        logger.info(f" Processing {len(page_keys)} PDF pages...")

        for i, page_key in enumerate(page_keys):
            next_page_key = page_keys[i + 1] if i + 1 < len(page_keys) else None

            pdf_page_data = extract_text_from_pdf_page_s3(page_key, config=config, s3_client=s3_client)
            chunks = chunk_text_into_segments(pdf_page_data, config["chunk_size"])

            text = pdf_page_data.get("text", "")
            is_blank = is_blank_page(text, chunks)

            document_name = os.path.splitext(os.path.basename(page_key))[0]
            match = re.search(r'_page_(\d+)', page_key)
            page_number = match.group(1) if match else "unknown"

            if not re.search(r'_page_\d+', document_name):
                document_name = f"{document_name}_page_{page_number}"

            chunk_key = f"{config['json_folder']}/{document_name}.json"


            page_json_structure = {
                "metadata": {
                    "document_name": pdf_page_data.get("document_name", "unknown.pdf"),
                    "page_number": page_number,
                    "text_date": datetime.now().isoformat(),
                    "tags": [] if not is_blank else ["#blankpage"]
                },
                "chunks": chunks if not is_blank else [],
                "embeddings": {}
            }

            s3_client.put_object(
                Bucket=config["bucket_name"],
                Key=chunk_key,
                Body=json.dumps(page_json_structure).encode("utf-8")
            )

            logger.info(f" Saved {'blank' if is_blank else 'content'} page to: {chunk_key}")
            processed_pages += 1

        logger.info(f" Extraction complete. Pages processed: {processed_pages}, blank pages: {blank_pages}")
        return processed_pages

    except Exception as e:
        logger.error(f" Error during text extraction: {e}")
        return processed_pages

def split_pdf_into_pages_s3(pdf_key: str, config=config_default, s3_client=s3_client_default, pages_per_file: int = None, pdf_password: str = None):
    """
    Splits a PDF from S3 into single-page files and uploads them back to S3.
    """
    try:
        bucket = config["bucket_name"]
        pages_folder = config["page_folder"]
        pages_per_file = pages_per_file or config.get("pages_per_file", 1)
        pdf_password = pdf_password or config.get("pdf_password")

        # Download the PDF from S3
        response = s3_client.get_object(Bucket=bucket, Key=pdf_key)
        pdf_bytes = response["Body"].read()
        reader = PdfReader(io.BytesIO(pdf_bytes))

        if reader.is_encrypted:
            if pdf_password:
                reader.decrypt(pdf_password)
                logger.info(f" Decrypted {pdf_key}")
            else:
                logger.warning(f" Skipping encrypted PDF {pdf_key} with no password.")
                return

        total_pages = len(reader.pages)
        base_name = os.path.splitext(os.path.basename(pdf_key))[0]

        for page_num in range(total_pages):
            writer = PdfWriter()
            writer.add_page(reader.pages[page_num])

            output_pdf = io.BytesIO()
            writer.write(output_pdf)
            output_pdf.seek(0)

            page_key = f"{pages_folder}/{base_name}_page_{page_num+1}.pdf"
            s3_client.put_object(Bucket=bucket, Key=page_key, Body=output_pdf.read())
            logger.info(f" Uploaded: {page_key}")

    except Exception as e:
        logger.error(f" Error splitting PDF {pdf_key}: {e}")
        
# ---------- S3 UTILITIES ----------

def list_objects_s3(bucket: str, prefix: str, extension: str = None, s3_client=s3_client_default) -> List[str]:
    """Lists all S3 objects under a prefix, optionally filtering by file extension."""
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        if extension:
            keys = [k for k in keys if k.endswith(extension)]
        return keys
    except Exception as e:
        logger.error(f" Error listing S3 objects: {e}")
        return []

def list_folders_s3(bucket: str, prefix: str = "", s3_client=s3_client_default) -> List[str]:
    """Lists all folders (common prefixes) under a given S3 prefix."""
    try:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        return [cp["Prefix"] for cp in response.get("CommonPrefixes", [])]
    except Exception as e:
        logger.error(f" Error listing S3 folders: {e}")
        return []

def list_pdf_files_s3(bucket: str, prefix: str = "", s3_client=s3_client_default) -> List[str]:
    """List all PDF files under a given S3 prefix."""
    return list_objects_s3(bucket, prefix, extension=".pdf")

def list_json_files_s3(bucket: str, prefix: str = "", s3_client=s3_client_default) -> List[str]:
    """List all JSON files under a given S3 prefix."""
    return list_objects_s3(bucket, prefix, extension=".json")

# this function requires ObjectTagging Read/Write permissions
def check_s3_object_tag(bucket: str, key: str, tag_key: str, s3_client=s3_client_default) -> bool:
    """Checks if an object in S3 has a specific tag key."""
    try:
        response = s3_client.get_object_tagging(Bucket=bucket, Key=key)
        tags = {tag["Key"]: tag["Value"] for tag in response.get("TagSet", [])}
        return tag_key in tags
    except s3_client.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'AccessDenied':
            logger.warning(f" Access denied when checking tags for {key}.")
            return False
        else:
            logger.error(f" Error checking tags for {key}: {e}")
            return False

def load_json_from_s3(bucket: str, key: str, s3_client=s3_client_default) -> dict:
    """Loads and returns JSON content from an S3 object."""
    response = s3_client.get_object(Bucket=bucket, Key=key)
    return json.loads(response["Body"].read().decode("utf-8"))

def save_json_to_s3(bucket: str, key: str, data: dict, s3_client=s3_client_default):
    """Saves a Python dict as JSON to an S3 object."""
    s3_client.put_object(
        Bucket=bucket,
        Key=key,
        Body=json.dumps(data).encode("utf-8")
    )

__all__ = [
    "clean_text",
    "clean_text_for_display",
    "chunk_text_into_segments",
    "smart_chunking",
    "save_page_chunks_as_json_s3",
    "prepare_pdf_splits",
    "extract_text_from_pdf_page_s3",
    "validate_page_continuity",
    "is_blank_page",
    "extract_text_from_pdf",
    "save_extracted_text_to_json",
    "extract_text_to_json",
    "split_pdf_into_pages_s3",
    "list_objects_s3",
    "list_folders_s3",
    "list_pdf_files_s3",
    "list_json_files_s3",
    "check_s3_object_tag",
    "load_json_from_s3",
    "save_json_to_s3",
]