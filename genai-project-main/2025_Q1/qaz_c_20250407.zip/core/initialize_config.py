import os
from core.config_manager import get_config  # 🔗 [Config Type 4️⃣ Core Utility: Needs classification]
config = get_config()  # 🔗 [Config Type 4️⃣ Core Utility: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 4️⃣ Core Utility: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
import streamlit as st
from datetime import datetime

# ✅ Patch Streamlit session_state for CLI compatibility
if not isinstance(st.session_state, dict):
    try:
        st.session_state.clear()
    except Exception:
        pass
    st.session_state = {}
    print("✅ Patched st.session_state to a plain dict.")


def initialize_config(config_file=None, return_config=False):
    """
    Loads config.json into st.session_state["CONFIG"].
    Also returns the config dictionary if return_config=True.
    """
    config_file = config_file or os.path.join(os.path.dirname(__file__), "config", "config.json")
    
    try:
        with open(config_file, "r") as f:
            config = json.load(f)

        if "CONFIG" not in st.session_state:
            st.session_state["CONFIG"] = config
            print(f"✅ CONFIG initialized from {config_file}.")
        else:
            print("ℹ️ CONFIG already exists in session_state.")

        return config if return_config else None

    except Exception as e:
        print(f"❌ Failed to load configuration from {config_file}: {e}")
        return {} if return_config else None
