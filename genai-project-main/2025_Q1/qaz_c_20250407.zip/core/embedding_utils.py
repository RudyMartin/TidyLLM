# [File: embedding_utils.py]

import os
from core.config_manager import get_config  # 🔗 [Config Type 4️⃣ Core Utility: Needs classification]
config = get_config()  # 🔗 [Config Type 4️⃣ Core Utility: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 4️⃣ Core Utility: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
import numpy as np
from pathlib import Path
from datetime import datetime

from core.s3_utils import list_objects_s3
from core.extraction_helper import is_blank_page
from core.client_bundle import get_client_bundle
from core.model_key_utils import get_model_details
from core.embedding_helper import get_cached_vectorizer

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

REEMBED_LIST_PATH = "reembed_list.json"
TEST_JSON_DIR = "test/json"

def prepare_embedding_input(data, exclude_keys=None):
    if exclude_keys is None:
        exclude_keys = ["embeddings"]
    data_filtered = {k: v for k, v in data.items() if k not in exclude_keys}
    return json.dumps(data_filtered, indent=2)

def build_embedding_metadata(data: dict, json_key: str, model_key: str, dim: int) -> dict:
    return {
        "json_key": json_key,
        "model_key": model_key,
        "dimensions": dim,
        "source": data.get("source", "unknown"),
        "tags_list": data.get("tags", [])
    }

def embeddings_flatten(data, model_key, config, logger, force=False):
    model_info = config["model_options"].get(model_key)
    if not model_info:
        logger.warning(f"Model key not found: {model_key}")
        return None

    model_embedding = data.get("embeddings", {}).get(model_key)
    vector = model_embedding.get("vector") if model_embedding else None

    if force or not vector or len(vector) != model_info["dimensions"]:
        return None

    try:
        return np.array(vector, dtype=np.float32).reshape(1, -1)
    except Exception as e:
        logger.error(f"Error reshaping embedding for model '{model_key}': {e}")
        return None

def data_collect(config, s3_client, model_key, logger, force=False):
    if not s3_client:
        logger.error("❌ S3 client not initialized. Cannot collect embeddings.")
        return [], []

    training_embeddings = []
    metadata = []
    json_keys = list_objects_s3(config["bucket_name"], config["json_folder"], extension=".json")

    for json_key in json_keys:
        try:
            obj = s3_client.get_object(Bucket=config["bucket_name"], Key=json_key)
            content = obj["Body"].read().decode("utf-8").strip()
            if not content:
                continue
            data = json.loads(content)
            text = data.get("text", "") or " ".join([c["text"] for c in data.get("chunks", []) if "text" in c])

            if "#blankpage" in data.get("tags", []) or is_blank_page(text, data.get("chunks", [])):
                continue

            embedding_vector = embeddings_flatten(data, model_key, config, logger, force=force)
            if embedding_vector is None and force:
                vectorizer = get_cached_vectorizer()
                model_info = config["model_options"][model_key]
                if not vectorizer.bedrock_boto3:
                    logger.error("❌ Missing Bedrock client. Cannot generate embeddings.")
                    continue
                new_vector = vectorizer.generate_embedding(text)
                embedding_vector = np.array(new_vector, dtype=np.float32).reshape(1, -1)

                data.setdefault("embeddings", {})[model_key] = {
                    "id": model_info["id"],
                    "dimensions": model_info["dimensions"],
                    "embed_date": datetime.utcnow().isoformat() + "Z",
                    "vector": new_vector
                }
                s3_client.put_object(
                    Bucket=config["bucket_name"],
                    Key=json_key,
                    Body=json.dumps(data, indent=2).encode("utf-8"),
                    ContentType="application/json"
                )

            if embedding_vector is not None:
                training_embeddings.append(embedding_vector)
                meta = build_embedding_metadata(data, json_key, model_key, config["model_options"][model_key]["dimensions"])
                metadata.append(meta)
        except Exception as e:
            logger.warning(f"Failed to process {json_key}: {e}")
            continue

    return training_embeddings, metadata

def reembed_flag(logger):
    if not os.path.exists(REEMBED_LIST_PATH):
        logger.info("No flagged files to re-embed.")
        return

    try:
        with open(REEMBED_LIST_PATH, "r") as f:
            flagged = json.load(f)

        if not flagged:
            logger.info("Re-embed list is empty.")
            return

        logger.info(f"Re-embedding {len(flagged)} flagged files...")

        for item in flagged:
            file_path = Path(TEST_JSON_DIR) / item["file"]
            if not file_path.exists():
                logger.warning(f"File not found: {item['file']}")
                continue

            with open(file_path, "r") as f:
                data = json.load(f)

            model_key = item["model"]
            model_details = get_model_details(model_key, config["model_options"])
            vectorizer = get_cached_vectorizer()

            text = data.get("text", "") or " ".join([c.get("text", "") for c in data.get("chunks", [])])

            data.setdefault("metadata", {})
            data.setdefault("chunks", [])
            data.setdefault("embeddings", {})

            new_vector = vectorizer.generate_embedding(text)
            data["embeddings"][model_key] = {
                "id": model_details["id"],
                "dimensions": model_details["dimensions"],
                "embed_date": datetime.utcnow().isoformat() + "Z",
                "tags": new_vector
            }

            with open(file_path, "w") as f:
                json.dump(data, f, indent=2)

            logger.info(f"✅ Re-embedded: {item['file']}")

        os.remove(REEMBED_LIST_PATH)
        logger.info("🧹 Re-embed list cleared.")

    except Exception as e:
        logger.error(f"❌ Error during re-embedding: {e}")

def reembed_append(file, model_key, reason, logger):
    entry = {"file": file, "model": model_key, "reason": reason}
    try:
        if os.path.exists(REEMBED_LIST_PATH):
            with open(REEMBED_LIST_PATH, "r") as f:
                existing = json.load(f)
        else:
            existing = []

        existing.append(entry)
        with open(REEMBED_LIST_PATH, "w") as f:
            json.dump(existing, f, indent=2)

        logger.info(f"📌 Flagged {file} for re-embedding: {reason}")

    except Exception as e:
        logger.warning(f"⚠️ Could not update re-embed list for {file}: {e}")

def get_text_to_encode(data, exclude_keys=None):
    return prepare_embedding_input(data, exclude_keys)

    
__all__ = [
    "prepare_embedding_input",
    "build_embedding_metadata",
    "embeddings_flatten",
    "data_collect",
    "reembed_flag",
    "reembed_append",
    "get_text_to_encode"
]


## `embedding_utils.py` Functions

# | Function | Purpose |
# |---------|---------|
# | `prepare_embedding_input` | Returns cleaned JSON string for embedding input |
# | `build_embedding_metadata` | Returns key metadata (model key, tags, dimensions) |
# | `embeddings_flatten` | Validates and flattens embedding into NumPy array |
# | `data_collect` | Gathers valid embedding data from S3 |
# | `reembed_flag` | Reprocesses and updates all files marked for re-embedding |
# | `reembed_append` | Adds a file to the re-embedding queue |
# get_text_to_encode(data, exclude_keys=None):
# A simple wrapper that returns a cleaned JSON string for embedding input (typically calls prepare_embedding_input).
