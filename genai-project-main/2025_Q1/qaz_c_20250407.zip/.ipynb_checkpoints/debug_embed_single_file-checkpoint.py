
# test_embed_single_file.py
#  python test_embed_single_file.py

"""
Test script to embed and update a single JSON file in S3 using a specified model.
"""

import json
from core.config_manager import get_config  # 🔗 [Config Type 2️⃣ CLI Script: Needs classification]
config = get_config()  # 🔗 [Config Type 2️⃣ CLI Script: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 2️⃣ CLI Script: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import streamlit as st

# Patch for CLI
if not isinstance(st.session_state, dict):
    st.session_state = {}
print("✅ Patched st.session_state to a plain dict.")

from core.client_bundle import get_client_bundle           # ✅ FIXED
from core.embedding_manager import EmbeddingManager

# ---------- CONFIG ----------
JSON_KEY = "1706.03762v7_attention_page_10.json"           # ← Your test file key
MODEL_KEY = "titan_v2"
FORCE = True

# ---------- INIT ----------
clients = get_client_bundle()
s3 = clients.s3
config = clients.config
full_key = f"{config['json_folder']}/{JSON_KEY}"

# ---------- LOAD ----------
print(f"📥 Loading from S3: {full_key}")
try:
    obj = s3.get_object(Bucket=config["bucket_name"], Key=full_key)
    json_data = json.loads(obj["Body"].read().decode("utf-8"))
except Exception as e:
    print(f"❌ Failed to load JSON: {e}")
    exit(1)

# ---------- EMBED ----------
manager = EmbeddingManager(clients=clients)
print(f"🚀 Embedding {JSON_KEY} with model: {MODEL_KEY} (force={FORCE})")
manager.embed_and_update_json(json_data, full_key, MODEL_KEY, force=FORCE)

print("✅ Embedding complete.")
