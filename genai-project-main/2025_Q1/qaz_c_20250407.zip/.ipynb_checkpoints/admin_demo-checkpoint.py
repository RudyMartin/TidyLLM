
"""
admin_demo.py

Purpose:
  Streamlit Admin Demo App for VectorQA Sage
  Includes only admin-focused tabs for diagnostics, configuration, logs, and batch processing.

Author: Rudy (Next Shift Consulting)
"""

import streamlit as st
from core.config_manager import get_config  # 🔗 [Config Type 1️⃣ Streamlit App: Needs classification]
config = get_config()  # 🔗 [Config Type 1️⃣ Streamlit App: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 1️⃣ Streamlit App: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import logging
import time
from packaging import version

from tabs import config_tab, logs_tab, faiss_diagnostics_tab, batch_tab
from core.config_helper import load_config, CONFIG_PATH

# --- Streamlit Setup ---
st.set_page_config(page_title="Admin Demo - VectorQA Sage", layout="wide")

# --- App Lifecycle Logging ---
logging.basicConfig(
    filename='app_lifecycle.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s'
)

if "app_start_time" not in st.session_state:
    st.session_state["app_start_time"] = time.time()
    logging.info("Admin Demo App started.")

# --- Streamlit Version Check ---
if version.parse(st.__version__) < version.parse("1.25.0"):
    st.error("Streamlit version too old. Please upgrade to 1.25.0 or higher.")
    st.stop()

# --- Load Config if not already loaded ---
if "config" not in st.session_state:
    st.session_state["config"] = load_config(CONFIG_PATH)

# --- Admin Tab Selection ---
st.sidebar.title("Admin Panel")
tab_option = st.sidebar.radio("Select a Tab", [
    "Batch Embedding",
    "FAISS Diagnostics",
    "Config Settings",
    "Logs"
])

if tab_option == "Batch Embedding":
    batch_tab.show()

elif tab_option == "FAISS Diagnostics":
    faiss_diagnostics_tab.show()

elif tab_option == "Config Settings":
    config_tab.show()

elif tab_option == "Logs":
    logs_tab.show()
