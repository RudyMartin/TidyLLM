import streamlit as st
import logging

from core.config_helper import get_config
from core.client_manager import get_clients

from tabs import (
    a_config_tab,
    a_logs_tab,
    a_faiss_diagnostics_tab,
    a_admin_cleanup_tab,
    a_pdf_tab,
    a_pgvector_index_tab
)

# --- Config & Clients ---
@st.cache_resource
def load_config():
    return get_config()

if "config" not in st.session_state:
    st.session_state["config"] = load_config()

# Use the cached client bundle
clients = get_clients()

# --- UI ---
st.sidebar.header(" Admin Panel")

admin_tool = st.sidebar.selectbox(
    "Select Admin Tool",
    ["Config", "Logs Viewer", "FAISS Diagnostics", "Cleanup Tab", "PDF Extract", "pgVector Index"]
)

if admin_tool == "Config":
    a_config_tab.render()
elif admin_tool == "Logs Viewer":
    a_logs_tab.render()
elif admin_tool == "FAISS Diagnostics":
    a_faiss_diagnostics_tab.show_faiss_diagnostics()
elif admin_tool == "Cleanup Tab":
    a_admin_cleanup_tab.render()
elif admin_tool == "PDF Extract":
    a_pdf_tab.render()
elif admin_tool == "pgVector Index":
    a_pgvector_index_tab.render()
