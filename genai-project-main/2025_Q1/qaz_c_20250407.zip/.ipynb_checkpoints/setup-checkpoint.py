#setup.py

import os
import subprocess
import sys
from core.config_helper import load_config  # Directly load the config
from core.client_manager import get_clients  # Get AWS clients from client_manager

# # Define the config file path (adjust if needed)
# CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config", "config.json")

# # Load the configuration directly from the file
# config = load_config(CONFIG_PATH)

# # Initialize AWS clients (Pass the whole config object to get_clients)
# clients = get_clients(config)  # Pass the full config to get_clients
# s3 = clients.get("s3")
# bedrock = clients.get("bedrock")


# # Create necessary log directories
# log_paths = [
#     "/home/sagemaker-user/qaz/logs",
#     "/home/sagemaker-user/qaz/logs/faiss",
#     "/home/sagemaker-user/qaz/logs/indexing",
#     "/home/sagemaker-user/qaz/logs/repair"
# ]

# for path in log_paths:
#     os.makedirs(path, exist_ok=True)
#     print(f"✅ Created: {path}")

# Install requirements safely
try:
    print("📦 Installing Python packages from requirements.txt...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "-q"])
    print("✅ Package installation complete.")
except subprocess.CalledProcessError as e:
    print(f"❌ pip install failed: {e}")

import pyarrow as pa
print(hasattr(pa.lib, "Decimal32Type"))
