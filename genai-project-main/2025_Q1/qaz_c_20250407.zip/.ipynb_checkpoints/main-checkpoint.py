#  main.py - refactored for client bundle
import streamlit as st
from core.config_manager import get_config  # 🔗 [Config Type 1️⃣ Streamlit App: Needs classification]
config = get_config()  # 🔗 [Config Type 1️⃣ Streamlit App: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 1️⃣ Streamlit App: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
from packaging import version
from datetime import datetime

from tabs import pdf_tab, batch_tab, guided_search_tab
from tabs import config_tab, logs_tab, faiss_diagnostics_tab

from core.client_bundle import get_client_bundle
from core.config_helper import load_config, CONFIG_PATH


def close_sidebar():
    st.markdown(
        """
        <script>
            const sidebar = window.parent.document.querySelector('section[data-testid="stSidebar"]');
            if (sidebar) sidebar.style.display = 'none';
        </script>
        """,
        unsafe_allow_html=True
    )

# --- Streamlit Version Check ---
if version.parse(st.__version__) < version.parse("1.25.0"):
    st.error(" Streamlit version too old. Please upgrade to 1.25.0 or higher.")
    st.stop()

# --- Load Config (only if not yet loaded) ---
if "config" not in st.session_state:
    st.session_state["config"] = load_config(CONFIG_PATH)

# --- Client Bundle Access ---
clients = get_client_bundle()
config = clients.config

# --- Sidebar Admin Panel ---
if st.sidebar.button("🏠 Home"):
    st.session_state["admin_tool"] = "None"
    st.rerun()

st.sidebar.header(" Admin Tools")

st.sidebar.selectbox(
    "Select Tool",
    ["None", "Config", "Logs Viewer", "FAISS Diagnostics"],
    key="admin_tool"
)

# --- Admin Tabs ---
admin_tool = st.session_state.get("admin_tool", "None")



if admin_tool == "Config":
    config_tab.render()
elif admin_tool == "Logs Viewer":
    logs_tab.render()
elif admin_tool == "FAISS Diagnostics":
    faiss_diagnostics_tab.show_faiss_diagnostics()
else:
    tab1, tab2, tab3 = st.tabs([" Guided Search", " Batch Processing", " PDF Processing"])
    with tab1:
        close_sidebar()
        guided_search_tab.render()
    with tab2:
        close_sidebar()
        batch_tab.render()
    with tab3:
        close_sidebar()
        pdf_tab.render()
