# debug_admin_batch_tab.py

"""
CLI debug script to simulate admin_batch_tab actions.
Steps: context load, model listing, embedding, indexing.

Usage:
  python debug_admin_batch_tab.py --all --force --log-file log.txt
  python debug_admin_batch_tab.py --embed-only
  python debug_admin_batch_tab.py --index-only --log-file output.log
"""

import os
from core.config_manager import get_config  # 🔗 [Config Type 2️⃣ CLI Script: Needs classification]
config = get_config()  # 🔗 [Config Type 2️⃣ CLI Script: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 2️⃣ CLI Script: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import sys
import json
import argparse
from datetime import datetime

# Patch Streamlit session_state for CLI compatibility
import streamlit as st
if not isinstance(st.session_state, dict):
    st.session_state = {}
print("✅ Patched st.session_state to a plain dict.")

# Load config into session_state for downstream compatibility
def initialize_config():
    config_path = os.path.join(os.path.dirname(__file__), "config", "config.json")
    try:
        with open(config_path, "r") as f:
            config = json.load(f)
        if "CONFIG" not in st.session_state:
            st.session_state["CONFIG"] = config
            print("✅ CONFIG initialized in session_state.")
        else:
            print("ℹ️ CONFIG already exists in session_state.")
    except Exception as e:
        print(f"❌ Failed to load configuration: {e}")

initialize_config()

# --- Core imports ---
from core.config_helper import get_config
from core.client_bundle import get_clients
from core.embedding_helper import AmazonEmbeddingVectorizer
from core.init_context import get_tab_context

# --- Load config and inject Bedrock client ---
config = get_config(force_reload=True)
clients_bundle, bedrock = get_clients(config)
vectorizer = AmazonEmbeddingVectorizer.from_config(config, bedrock_client=bedrock)

# --- Optional log redirect ---
def setup_logging(log_file):
    if log_file:
        sys.stdout = open(log_file, "w")
        sys.stderr = sys.stdout
        print(f"🔍 Logging redirected to {log_file}")

# --- Embedding and Indexing Execution ---
def run_embedding(manager, vectorizer, selected_models, force=False):
    print("\n🔁 Running embedding process (validate_and_embed_missing)...")
    try:
        # Run the embedding process
        result = manager.validate_and_embed_missing(selected_models, vectorizer, force=force)
        
        # Check if embeddings were created
        if not result or len(result) == 0:
            print("❌ No embeddings were created. Please check the input data or configuration.")
        else:
            print("✅ Embedding completed.")
    
    except Exception as e:
        print(f"❌ Embedding failed: {e}")

def run_indexing(manager, selected_models):
    print("\n📇 Running indexing process (index_batch)...")
    try:
        manager.index_batch(selected_models)
        print("✅ Indexing completed.")
    except Exception as e:
        print(f"❌ Indexing failed: {e}")

def debug_tab_functions(embed=True, index=True, force=False):
    print("\n=== Debugging Admin Batch Tab Functions ===")
    print(f"Step 1: {datetime.now()} - Retrieving tab context...")
    try:
        clients, config, vectorizer, manager = get_tab_context()
        print("  -> ✅ Successfully retrieved tab context.")
    except Exception as e:
        print(f"  -> ❌ Failed to retrieve tab context: {e}")
        return

    print("\nStep 2: Listing available model options...")
    try:
        model_options = list(config["model_options"].keys())
        print(f"  -> 📋 Available models: {model_options}")
    except Exception as e:
        print(f"  -> ❌ Error retrieving model options: {e}")
        return

    selected_models = model_options
    print(f"\nStep 3: Selected models for processing: {selected_models}")
    print(f"🔧 Force re-embedding: {force}")

    if embed:
        run_embedding(manager, vectorizer, selected_models, force=force)
    if index:
        run_indexing(manager, selected_models)

    print("\n=== ✅ Debugging Completed ===\n")

# --- CLI Handler ---
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Admin Batch Tab CLI Debug Tool")
    parser.add_argument("--all", action="store_true", help="Run both embedding and indexing")
    parser.add_argument("--embed-only", action="store_true", help="Run only the embedding process")
    parser.add_argument("--index-only", action="store_true", help="Run only the indexing process")
    parser.add_argument("--force", action="store_true", help="Force re-embedding even if embedding exists")
    parser.add_argument("--log-file", type=str, help="Save output to log file")

    args = parser.parse_args()

    setup_logging(args.log_file)

    if args.embed_only:
        debug_tab_functions(embed=True, index=False, force=args.force)
    elif args.index_only:
        debug_tab_functions(embed=False, index=True, force=args.force)
    else:
        debug_tab_functions(embed=True, index=True, force=args.force)
