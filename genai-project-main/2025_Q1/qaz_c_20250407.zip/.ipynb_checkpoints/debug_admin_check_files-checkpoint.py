import boto3
from core.config_manager import get_config  # 🔗 [Config Type 2️⃣ CLI Script: Needs classification]
config = get_config()  # 🔗 [Config Type 2️⃣ CLI Script: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 2️⃣ CLI Script: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")

bucket = "sagemaker-us-east-1-188494237500"
prefix = "dev/pdf/technical/"

s3 = boto3.client("s3")

response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
pdfs = [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(".pdf")]

print(f"{len(pdfs)} PDF(s) found.")
for pdf in pdfs[:10]:
    print(" -", pdf)

