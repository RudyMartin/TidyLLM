# demo_main.py
"""
Version: DSPy Plan Audit Demo (2025-04)

Description:
  Minimal Streamlit app to showcase DSPy Plan Auditing features.
  Includes: Wizard, Plan Audit, Dashboard, Groundtruth Editor, FAISS integration.
"""

import streamlit as st
from core.config_manager import get_config  # 🔗 [Config Type 1️⃣ Streamlit App: Needs classification]
config = get_config()  # 🔗 [Config Type 1️⃣ Streamlit App: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 1️⃣ Streamlit App: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
st.set_page_config(page_title="DSPy Plan Audit Demo", layout="wide")  # ✅ MUST BE FIRST

# === Logging and Shutdown Support ===
import logging
import time
import sys
import os
import signal

# Configure logging to track app lifecycle events
logging.basicConfig(
    filename='app_lifecycle.log',
    level=logging.INFO,
    format='%(asctime)s %(levelname)s: %(message)s'
)

# Record the app start time once using session state
if "app_start_time" not in st.session_state:
    st.session_state["app_start_time"] = time.time()
    logging.info("App started.")

def shutdown_app():
    st.warning("The app will shut down in 5 seconds...")
    logging.info("Shutdown event initiated by user.")
    time.sleep(5)
    # Compute uptime and log it
    uptime = time.time() - st.session_state["app_start_time"]
    logging.info("Shutting down now. App uptime was: %.2f seconds.", uptime)
    logging.shutdown()  # Ensure logs are flushed before exit
    # Terminate the process (choose one method)
    sys.exit()
    # Alternatively, you can use:
    # os.kill(os.getpid(), signal.SIGTERM)

# === Tab Imports ===
from tabs.demo_plan_audit_tab import render as plan_audit_tab
from tabs.demo_wizard_tab import render as wizard_tab
from tabs.demo_dashboard_tab import render as dashboard_tab
from tabs.demo_truth_viewer_tab import render as truth_viewer_tab
from tabs.demo_faiss_search_tab import render as faiss_search_tab
from tabs.demo_guided_search_tab import render as guided_search_tab
from tabs.admin_config_tab import render as config_tab
from tabs.admin_batch_tab import render as batch_tab
from tabs.admin_pdf_tab import render as pdf_tab
from tabs.admin_logs_tab import render as logs_tab
from tabs.admin_cleanup_tab import render as cleanup_tab

# === Optional Context Imports ===
from core.init_context import get_tab_context
from core.vector_manager import VectorManager
from core.config_helper import get_config
from core.client_bundle import get_client_bundle  # ✅ Use for unified config/client access

# Force-load demo config at startup
get_config(force_reload=True, path_override="config/config.json")

# Initialize session state defaults
if "tab" not in st.session_state:
    st.session_state.tab = "🧭 Wizard"

faiss_manager = VectorManager(store_type="faiss")

# === Sidebar Layout ===
st.sidebar.title("🔍 Demo Navigation")



# ✅ Show real-time S3 connection health
clients = get_client_bundle()
config = clients.config
s3 = clients.s3

try:
    bucket_test = config["bucket_name"]
    s3.list_objects_v2(Bucket=bucket_test, MaxKeys=1)
    st.sidebar.success(f"🟢 S3 Connected: `{bucket_test}`")
except Exception as e:
    st.sidebar.error("🔴 S3 Connection Failed")
    st.sidebar.caption(f"{e.__class__.__name__}: {e}")

st.sidebar.markdown("### 🌐 User Tabs")
user_tabs = [
    "🧭 Wizard",
    "📋 Plan Audit",
    "📍 FAISS Search",
    "🧠 Guided Search",
    "📊 Dashboard",
    "🧠 Groundtruth"
]
for tab in user_tabs:
    if st.sidebar.button(tab, key=f"btn_{tab}"):
        st.session_state.tab = tab

st.sidebar.markdown("### 🛠️ Admin Tools")
admin_tabs = [
    "⚙️ Config",
    "📦 Batch Embedding",
    "📑 PDF Debugger",
    "🧹 Cleanup",
    "📜 Logs Viewer"
]
for tab in admin_tabs:
    if st.sidebar.button(tab, key=f"admin_{tab}"):
        st.session_state.tab = tab

# === Tab Routing ===
if st.session_state.tab == "🧭 Wizard":
    wizard_tab()
elif st.session_state.tab == "📋 Plan Audit":
    plan_audit_tab()
elif st.session_state.tab == "📊 Dashboard":
    dashboard_tab()
elif st.session_state.tab == "🧠 Groundtruth":
    truth_viewer_tab()
elif st.session_state.tab == "📍 FAISS Search":
    faiss_search_tab()
elif st.session_state.tab == "🧠 Guided Search":
    guided_search_tab()
elif st.session_state.tab == "⚙️ Config":
    config_tab()
elif st.session_state.tab == "📦 Batch Embedding":
    batch_tab()
elif st.session_state.tab == "📑 PDF Debugger":
    pdf_tab()
elif st.session_state.tab == "📜 Logs Viewer":
    logs_tab()
elif st.session_state.tab == "🧹 Cleanup":
    cleanup_tab()
elif st.session_state.tab == "🚪 Shutdown App":
    shutdown_app()

# === Footer ===
st.markdown("""
---
[Back to Full App](main.py) | [GitHub Repo](https://github.com)
""")
