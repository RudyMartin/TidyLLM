# test/test_embedding_helper.py
import pytest
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
from unittest.mock import MagicMock
from core.embedding_helper import AmazonEmbeddingVectorizer

@pytest.fixture
def mock_vectorizer():
    config = {
        "model_options": {
            "titan_v2": {"id": "amazon.titan-embed-text-v2", "dimensions": 1024}
        },
        "default_model_option": "titan_v2",
        "region_name": "us-east-1"
    }

    mock_client = MagicMock()
    mock_client.invoke_model.return_value = {
        "body": MagicMock(read=lambda: b'{"embedding": [0.1, 0.2, 0.3]}')
    }

    return AmazonEmbeddingVectorizer(config, bedrock_client=mock_client)

def test_generate_embedding(mock_vectorizer):
    text = "Test embedding text"
    result = mock_vectorizer.generate_embedding(text)
    assert isinstance(result, list)
    assert result == [0.1, 0.2, 0.3]