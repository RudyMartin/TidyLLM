"""
[File: tabs/admin_batch_tab.py]
Description: Renders the Batch Embedding + Indexing tab using VectorManager abstraction.
"""

# --- Standard Library Imports ---
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import logging
import streamlit as st
from datetime import datetime
import numpy as np

# --- Project-level Imports ---
#used  to unpack full context NEEDED!!
from core.init_context import get_tab_context

from core.extraction_helper import (
    extract_text_from_pdf,
    save_extracted_text_to_json,
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import (
    list_pdf_files_s3,
    list_json_files_s3,
    list_s3_files_with_extension
)

# --- Logging Settings ---
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def render():
    """
    Render the Batch Embedding + Indexing tab using VectorManager abstraction.
    """
    clients, config, vectorizer, manager = get_tab_context()
    ##  not really used here - yet
    s3_client = clients.s3

    st.title("\U0001F4CA Model Indexing Dashboard")
    st.markdown("---")

    # --- Section: Model Selection ---
    st.subheader("\U0001F9E0 Vectorize & Index Content")
    model_options = list(config["model_options"].keys())
    selected_models = st.multiselect(
        "Pick one or all models:",
        model_options,
        default=model_options
    )

    if not selected_models:
        st.warning("Please select at least one model.")
        return

    st.markdown("2. Select Process to Run")
    col1, col2, col3 = st.columns(3)

    # --- A. Run All ---
    with col1:
        if st.button("\U0001F680 A. Run ALL", type="primary"):
            with st.spinner("\U0001F50D Embedding missing vectors..."):
                try:
                    manager.validate_and_embed_missing(selected_models, vectorizer)
                    st.success("\u2705 Embedding complete.")
                except Exception as e:
                    st.error(f"\u274C Embedding failed: {e}")
            with st.spinner("\u2696\ufe0f Indexing embeddings..."):
                try:
                    manager.index_batch(selected_models)
                    st.success("\u2705 Indexing complete.")
                except Exception as e:
                    st.error(f"\u274C Indexing failed: {e}")

    # --- B. Only Embedding ---
    with col2:
        if st.button("\U0001F680 B. Only Embedding", type="secondary"):
            with st.spinner("\U0001F50D Embedding missing vectors..."):
                try:
                    manager.validate_and_embed_missing(selected_models, vectorizer)
                    st.success("\u2705 Embedding complete.")
                except Exception as e:
                    st.error(f"\u274C Embedding failed: {e}")

    # --- C. Only Indexing ---
    with col3:
        if st.button("\u2699\ufe0f C. Only Indexing", type="secondary"):
            with st.spinner("\u2696\ufe0f Indexing embeddings..."):
                try:
                    manager.index_batch(selected_models)
                    st.success("\u2705 Indexing complete.")
                except Exception as e:
                    st.error(f"\u274C Indexing failed: {e}")

    st.markdown("---")

    # --- Section: FAISS Index Health Dashboard ---
    st.subheader("\U0001F4CA Index Health Overview")
    st.caption(f"Last checked: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    if st.button("\U0001F504 Refresh Index Status"):
        st.rerun()

    status_list = sorted(manager.get_index_status(), key=lambda x: x.get("LastModified", ""), reverse=True)

    st.markdown(f"**Total Models Tracked:** `{len(status_list)}`")
    missing = len([e for e in status_list if e.get("Vectors", 0) == 0])
    if missing:
        st.warning(f"\u26A0\ufe0f {missing} model(s) have no vectors indexed.")

    headers = st.columns([3, 1, 2, 2, 2, 1, 2])
    headers[0].markdown("**\U0001F9E0 Model**")
    headers[1].markdown("**Trained**")
    headers[2].markdown("**# Vectors**")
    headers[3].markdown("**Dim**")
    headers[4].markdown("**\U0001F552 Modified**")
    headers[5].markdown("**Status**")
    headers[6].markdown("**Action**")

    for entry in status_list:
        cols = st.columns([3, 1, 2, 2, 2, 1, 2])
        cols[0].markdown(f"`{entry['Model']}`")
        cols[1].write("\u2705" if entry["Trained"] else "\u274C")
        cols[2].write(entry["Vectors"])
        cols[3].write(entry["Dim"])

        last_mod = entry.get("LastModified", "N/A")
        if isinstance(last_mod, str):
            try:
                dt = datetime.strptime(last_mod, "%Y-%m-%d %H:%M")
                age_days = (datetime.now() - dt).days
                last_mod = f"{last_mod} ({age_days} days ago)"
            except:
                pass
        cols[4].write(last_mod)
        cols[5].write(entry["Status"])

        if cols[6].button("\u2696\ufe0f Repair", key=f"repair_{entry['Model']}"):
            if "Repair" in entry and callable(entry["Repair"]):
                entry["Repair"]()
                st.success(f"\u2705 Repaired FAISS index for {entry['Model']}")
                st.rerun()
            else:
                st.warning("\u26A0\ufe0f No repair handler.")

    # Optional: List older versions or index files
    st.markdown("---")
    st.subheader("\U0001F4C1 Stored FAISS Index Files")
    faiss_files = manager.list_available_indexes()
    if faiss_files:
        for f in faiss_files:
            st.code(f, language="none")
    else:
        st.info("No FAISS index files found.")

if __name__ == "__main__":
    render()