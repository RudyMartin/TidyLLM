"""
[File: tabs/playground_tab.py]
Version: DSPy 2.5.26

Description:
  Interactive playground to test various DSPy Signature modules dynamically.
  Users can select a task (signature), provide inputs, and view DSPy output.
"""


# --- Standard Library Imports ---
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import logging
import streamlit as st

# --- Project-level Imports ---
from dsai.modules.signatures import get_signature_names, get_signature_class
from dsai.modules.base_module import DynamicDSPyModule


def render():
    st.header("🧪 DSPy Playground")
    st.markdown("Select a reasoning task (Signature), provide inputs, and view the model-generated outputs.")

    selected_name = st.selectbox("Choose Task Type", get_signature_names())
    SignatureClass = get_signature_class(selected_name)
    st.caption(f"Using Signature: `{SignatureClass.__name__}`")

    # Instantiate dynamic DSPy module with selected signature
    module = DynamicDSPyModule(SignatureClass)
    
    input_fields = SignatureClass.input_fields()
    inputs = {}
    with st.form("dspy_playground_form"):
        for field in input_fields:
            inputs[field] = st.text_area(f"{field.title()} Input")
        submitted = st.form_submit_button("Run DSPy")

    if submitted:
        with st.spinner("Generating output with DSPy..."):
            try:
                result = module(**inputs)
                st.success("DSPy Output:")
                for k, v in result.dict().items():
                    st.markdown(f"**{k}**: {v}")
            except Exception as e:
                st.error(f"Error during DSPy execution: {e}")


if __name__ == "__main__":
    render()