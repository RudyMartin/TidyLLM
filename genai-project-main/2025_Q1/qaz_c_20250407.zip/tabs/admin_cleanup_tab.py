# tabs/admin_cleanup_tab.py


# --- Standard Library Imports ---
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import streamlit as st
import streamlit as st
import logging


# --- Project-level Imports ---
# this is used to pass s3_client and config values below
from core.init_context import get_tab_context
from core.s3_utils import list_pdf_files_s3, list_json_files_s3,  list_s3_files_with_extension

# --- Logging Settings ---
logger = logging.getLogger(__name__)



def cleanup_ingestion_folders(s3_client, config, dry_run: bool = True):
    bucket = config["bucket_name"]
    pages_folder = config["page_folder"]
    json_folder = config["json_folder"]
    pdf_folder = config["pdf_folder"]

   # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(bucket, pages_folder,"pdf")
    pdf_keys = list_s3_files_with_extension(bucket, pdf_folder,"pdf")
    json_keys = list_s3_files_with_extension(bucket, json_folder,"json")

    total_files = len(page_keys) + len(json_keys)

    if dry_run:
        st.info("**Dry Run Mode:** No files will be deleted. Here's what would be removed.")
        
        st.markdown(f"### PDF files to delete: `{len(page_keys)}`")
        st.write(page_keys or "No PDF files found.")

        st.markdown(f"### JSON files to delete: `{len(json_keys)}`")
        st.write(json_keys or "No JSON files found.")

        st.info(f"Total files identified for deletion: `{total_files}`")
    else:
        deleted = {"pdfs": 0, "jsons": 0}
        with st.spinner("Deleting files..."):
            for key in page_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["pdfs"] += 1

            for key in json_keys:
                s3_client.delete_object(Bucket=bucket, Key=key)
                deleted["jsons"] += 1

        st.success(f"Cleanup complete: {deleted['pdfs']} PDF pages and {deleted['jsons']} JSONs removed.")


def render():
    st.header("Cleanup: Ingestion Artifacts")
    st.markdown(
        """
        Use this tool to remove intermediate **PDF pages** and **JSON chunk files** 
        from S3 after a successful FAISS indexing run.
        """
    )

    clients, config, *_ = get_tab_context()
    ##  this is used  by function call below
    s3_client = clients.s3
    
    # Use the globally defined config and s3_client
    bucket = config["bucket_name"]
    pages_folder = config["page_folder"]
    json_folder = config["json_folder"]
    pdf_folder = config["pdf_folder"]

    # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(bucket, pages_folder,"pdf")
    pdf_keys = list_s3_files_with_extension(bucket, pdf_folder,"pdf")
    json_keys = list_s3_files_with_extension(bucket, json_folder,"json")

    st.info(f"Found `{len(page_keys)}` page PDFs and `{len(json_keys)}` JSONs ready for cleanup.")

    # Provide checkboxes for a dry run and confirmation.
    dry_run = st.checkbox("Preview files (dry run)", value=True)
    confirm = st.checkbox("Yes, I want to delete the above files permanently.")

    if st.button("Run Cleanup Now"):
        if not confirm and not dry_run:
            st.warning("Please confirm deletion to proceed.")
        else:
            cleanup_ingestion_folders(s3_client, config, dry_run=dry_run)

