"""
[File: tabs/demo_faiss_search_tab.py]
Version: DSPy 2.5.26 - Demo FAISS Search Tab

Description:
  Streamlit tab for semantic search over audit records stored in FAISS.
  Useful for exploring past audit evaluations and governance patterns.
"""

import streamlit as st
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
import tempfile
import os
from core.faiss_log_reader import search_audit_logs


def render():
    st.header("📍 Semantic Audit Log Search")
    st.markdown("""
    Enter a free-form question or phrase to search audit records using semantic similarity.
    Results will be retrieved from the FAISS vector store.
    """)

    query = st.text_input("🔍 Search Query", "How is post-deployment monitoring handled?")
    top_k = st.slider("Top K Matches", 1, 10, 5)
    model_key = st.selectbox("Embedding Model", ["titan_v2", "titan_v1"], index=0)

    if st.button("🔎 Run Semantic Search"):
        results = search_audit_logs(query_text=query, top_k=top_k, model_key=model_key)

        if not results:
            st.warning("No results found.")
        else:
            for i, entry in enumerate(results):
                with st.expander(f"Result #{i + 1} - Score: {entry.get('score', '?'):.2f}"):
                    st.markdown("**Matched Section Text:**")
                    st.write(entry.get("text", "[No Text Found]")[:1000])
                    st.markdown("**Metadata:**")
                    st.json(entry.get("metadata", {}))

            # Export Buttons
            with st.expander("📤 Export Results"):
                json_filename = f"semantic_results_{model_key}.json"
                json_str = json.dumps(results, indent=2)
                st.download_button(
                    label="💾 Download JSON",
                    file_name=json_filename,
                    mime="application/json",
                    data=json_str.encode("utf-8")
                )

                # Optional PDF export using fpdf
                try:
                    from fpdf import FPDF

                    pdf = FPDF()
                    pdf.set_auto_page_break(auto=True, margin=15)
                    pdf.add_page()
                    pdf.set_font("Arial", size=12)

                    pdf.cell(200, 10, txt="Semantic Audit Results", ln=True, align="C")

                    for idx, entry in enumerate(results):
                        pdf.ln(10)
                        pdf.multi_cell(0, 10, f"Result #{idx + 1} (Score: {entry.get('score', '?'):.2f})")
                        pdf.set_font("Arial", size=10)
                        pdf.multi_cell(0, 10, entry.get("text", "[No Text Found]")[:1000])
                        pdf.set_font("Arial", size=8)
                        metadata_str = json.dumps(entry.get("metadata", {}), indent=2)
                        pdf.multi_cell(0, 10, metadata_str)
                        pdf.set_font("Arial", size=12)

                    with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                        pdf.output(tmp.name)
                        tmp_path = tmp.name

                    with open(tmp_path, "rb") as f:
                        st.download_button(
                            label="📄 Download PDF",
                            file_name="semantic_audit_results.pdf",
                            mime="application/pdf",
                            data=f.read()
                        )

                    os.unlink(tmp_path)
                except ImportError:
                    st.warning("Install `fpdf` to enable PDF export.")

    st.markdown("---")
    st.markdown("Looking for groundtruth-guided results?")
    if st.button("🧠 Try Guided Search →"):
        st.session_state.update({"tab": "🧠 Guided Search"})


if __name__ == "__main__":
    render()
