# --- PDF Processing Tab ---
# [File: tabs/a_pdf_tab.py]
# Description: Provides the UI for PDF processing: splitting PDFs, extracting text,
# and converting pages to JSON format.

import logging
import streamlit as st

from core.pdf_processing import split_pdf, extract_text_from_pdf
from core.s3_utils import upload_to_s3
from core.logging_helper import get_logger

# --- Logging Setup ---
logger = get_logger("pdf_tab")
logger.setLevel(logging.INFO)

# --- Main PDF Processing Logic ---
def render():
    st.header("📄 PDF Processing")

    # Lazy import of get_tab_context to avoid circular imports
    from core.init_context import get_tab_context
    
    # Unified tab context
    clients, config, *_ = get_tab_context()
    s3_client = clients.s3

    bucket_name = config["bucket_name"]
    pdf_folder = config["pdf_folder"]
    page_folder = config["page_folder"]
    json_folder = config["json_folder"]

    # --- PDF Upload ---
    pdf_file = st.file_uploader("Upload a PDF file", type="pdf")
    
    if pdf_file:
        # Display PDF file details
        st.write(f"File name: {pdf_file.name}")
        st.write(f"File size: {pdf_file.size} bytes")

        # --- Process PDF File ---
        # Step 1: Split PDF into pages
        pages = split_pdf(pdf_file)

        # Step 2: Extract text from each page
        text_data = [extract_text_from_pdf(page) for page in pages]

        # Step 3: Convert text data to JSON format
        json_data = convert_text_to_json(text_data)

        # --- Display and Save Results ---
        st.markdown("### Text Extracted from PDF")
        st.json(json_data)

        # --- Option to Upload to S3 ---
        if st.button("Upload to S3"):
            upload_to_s3(s3_client, json_data, config["bucket_name"], config["json_folder"])
            st.success("PDF data uploaded to S3 successfully.")

# --- Helper Function to Convert Text Data to JSON Format ---
def convert_text_to_json(text_data):
    json_data = []
    for page_num, text in enumerate(text_data, start=1):
        json_data.append({
            "page_number": page_num,
            "text": text
        })
    return json_data

# --- CLI Mode - Process PDF from File ---
def process_pdf_cli(pdf_path):
    clients, config, *_ = get_tab_context()  # Unified config and client context
    s3_client = clients.s3

    # Step 1: Read PDF file
    with open(pdf_path, "rb") as pdf_file:
        pages = split_pdf(pdf_file)

    # Step 2: Extract text from each page
    text_data = [extract_text_from_pdf(page) for page in pages]

    # Step 3: Convert text data to JSON format
    json_data = convert_text_to_json(text_data)

    # Step 4: Upload to S3
    upload_to_s3(s3_client, json_data, config["bucket_name"], config["json_folder"])

    print(f"Processed PDF: {pdf_path}")
    print(f"Extracted JSON Data: {json_data[:2]}...")  # Print first 2 pages for preview

# --- Example for CLI Usage ---
if __name__ == "__main__":
    # Uncomment below line to run in CLI mode
    # process_pdf_cli("/path/to/pdf/file.pdf")
    render()
