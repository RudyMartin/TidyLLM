# --- Logs Tab ---
# [File: tabs/a_logs_tab.py]
# Version: Simplified Log Viewer (2025-04)
# Description: Streamlit tab to view log files and perform cleanup.

import streamlit as st
import json
import logging
from collections import Counter

from core.s3_utils import list_s3_files_with_extension, cleanup_log_files
from core.logging_helper import list_log_files, read_log_file, cleanup_logs, get_logger

# --- Logging Setup ---
logger = get_logger("logs_tab")
logger.setLevel(logging.INFO)

# --- Main Logs Tab Logic ---
def render():
    st.header("🧾 Log Viewer")

    # Lazy import of get_tab_context to avoid circular imports
    from core.init_context import get_tab_context

    # Unified context
    clients, config, *_ = get_tab_context()
    s3_client = clients.s3

    log_bucket = config["bucket_name"]
    log_prefix = config.get("log_directory", "dev/logs")

    # --- Log Cleanup ---
    dry_run = input("Would you like to perform a dry run? (yes/no): ").strip().lower() == 'yes'
    confirm = input("Do you want to delete the above log files permanently? (yes/no): ").strip().lower() == 'yes'
    
    if confirm or dry_run:
        cleanup_log_files(s3_client, config, dry_run=dry_run)

    # List log files from S3
    log_files = list_s3_files_with_extension(config["bucket_name"], config["log_folder"], "log")
    
    if not log_files:
        print("⚠️ No log files found.")
    else:
        print(f"✅ Found {len(log_files)} log files.")
        print(log_files[:10])  # Limit to first 10 results for display

    # --- Log File Selection ---
    selected_log = input("Enter the log file name to view (or 'exit' to quit): ").strip()
    
    if selected_log.lower() != "exit":
        try:
            raw = read_log_file(selected_log)
            log_content = raw if isinstance(raw, str) else str(raw)

            # Entry count for INFO, WARNING, ERROR
            entry_counts = Counter()
            for line in log_content.splitlines():
                if "[INFO]" in line:
                    entry_counts["INFO"] += 1
                elif "[WARNING]" in line:
                    entry_counts["WARNING"] += 1
                elif "[ERROR]" in line:
                    entry_counts["ERROR"] += 1

            print("### 🔢 Entry Counts")
            print(f"INFO: {entry_counts.get('INFO', 0)}")
            print(f"WARNING: {entry_counts.get('WARNING', 0)}")
            print(f"ERROR: {entry_counts.get('ERROR', 0)}")

            print("\n### 📜 Log Content")
            print(log_content)

        except Exception as e:
            print(f"❌ Error loading log file: {e}")
            logger.error(f"Error reading log file {selected_log}: {e}")

# Main function call
if __name__ == "__main__":
    render()
