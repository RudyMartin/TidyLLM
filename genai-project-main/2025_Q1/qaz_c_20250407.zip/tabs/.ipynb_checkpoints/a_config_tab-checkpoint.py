# [File: tabs/a_config_tab.py]
# Description: Provides UI for viewing and editing configuration settings.

import logging
import streamlit as st
import json
from core.logging_helper import get_logger

# --- Logging ---
logger = get_logger("config_tab")
logger.setLevel("INFO")

def render():
    st.header("⚙️ Configuration Settings")

    from core.init_context import get_tab_context
    
    # Unified context
    clients, config, *_ = get_tab_context()
    s3_client = clients.s3

    editable = st.session_state.get('editable', False)

    if not editable:
        st.markdown("### Current Config")
        st.json(config)
        st.toggle("✏️ Edit Config Mode", key="editable")
    else:
        st.markdown("### 🧪 Debug: S3 Raw Listing Test")
        try:
            bucket = config["bucket_name"]
            prefix = "dev/pdf/arxiv_wellsfargo/"
            response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
            keys = [obj["Key"] for obj in response.get("Contents", [])]

            if not keys:
                st.warning("⚠️ No keys found under this prefix.")
            else:
                st.success(f"✅ Found {len(keys)} objects.")
                st.write(keys[:10])  # Limit to first 10 results

        except Exception as e:
            st.error(f"❌ Failed to list objects: {e}")
            logger.error("S3 listing failed", exc_info=True)

        # Optionally allow JSON config edit here (future enhancement)
