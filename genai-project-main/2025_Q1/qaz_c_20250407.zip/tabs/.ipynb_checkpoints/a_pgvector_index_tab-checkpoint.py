# --- pgVector Indexing Tab ---
# [File: tabs/a_pgvector_index_tab.py]
# Description: UI for managing pgVector indexing and search over JSON-embedded content.

import streamlit as st
import logging

from core.pgvector_helper import (
    create_pgvector_index,
    search_pgvector_index,
    load_pgvector_index,
    pgvector_available
)
from core.s3_utils import upload_to_s3
from core.logging_helper import get_logger

# --- Logging Setup ---
logger = get_logger("pgvector_tab")
logger.setLevel(logging.INFO)

# --- Main pgVector Indexing Logic ---
def render():
    st.header("🔢 pgVector Indexing and Similarity Search")

    # Lazy import of get_tab_context to avoid circular imports
    from core.init_context import get_tab_context
    
    # Get context: clients + config
    clients, config, *_ = get_tab_context()
    s3_client = clients.s3

    bucket_name = config["bucket_name"]
    json_folder = config["json_folder"]
    index_folder = config["index_folder"]
    
    # if not pgvector_available():
    # st.warning("🔒 This feature is unavailable until PGVector is set up.")
    # st.stop()

   

    # if pgvector_available():
    #     st.success("🟢 PGVector database is online.")
    # else:
    #     st.warning("🔴 PGVector database not connected. Setup may still be in progress.")




    # --- pgVector Index Creation ---
    if st.button("📚 Create pgVector Index"):
        try:
            st.spinner("Creating pgVector index...")
            index_name = create_pgvector_index(s3_client, config, bucket_name, json_folder)
            st.success(f"✅ pgVector index `{index_name}` created successfully.")
        except Exception as e:
            st.error(f"❌ Failed to create pgVector index: {e}")

    # --- pgVector Search ---
    search_query = st.text_input("🔍 Enter Search Query:")
    if st.button("🔎 Search pgVector Index"):
        if search_query:
            try:
                st.spinner("Searching the index...")
                results = search_pgvector_index(search_query, config, s3_client, bucket_name, index_folder)
                st.success(f"✅ Search complete. Found {len(results)} results.")
                st.write(results)
            except Exception as e:
                st.error(f"❌ Error while searching: {e}")
        else:
            st.warning("⚠️ Please enter a search query.")
