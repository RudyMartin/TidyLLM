#  tabs/a_admin_cleanup_tab.py

from core.s3_utils import list_s3_files_with_extension, cleanup_ingestion_folders

def render():
    st.header("Cleanup: Ingestion Artifacts")
    st.markdown(
        """
        Use this tool to remove intermediate **PDF pages** and **JSON chunk files** 
        from S3 after a successful FAISS indexing run.
        """
    )
    
    # Lazy import of get_tab_context to avoid circular imports
    from core.init_context import get_tab_context

    # Unified context
    clients, config, *_ = get_tab_context()
    s3_client = clients.s3
    
    # Get lists of files to be cleaned up.
    page_keys = list_s3_files_with_extension(config["bucket_name"], config["page_folder"], "pdf")
    json_keys = list_s3_files_with_extension(config["bucket_name"], config["json_folder"], "json")

    st.info(f"Found `{len(page_keys)}` page PDFs and `{len(json_keys)}` JSONs ready for cleanup.")

    # Provide checkboxes for a dry run and confirmation.
    dry_run = st.checkbox("Preview files (dry run)", value=True)
    confirm = st.checkbox("Yes, I want to delete the above files permanently.")

    if st.button("Run Cleanup Now"):
        if not confirm and not dry_run:
            st.warning("Please confirm deletion to proceed.")
        else:
            cleanup_ingestion_folders(s3_client, config, dry_run=dry_run)
