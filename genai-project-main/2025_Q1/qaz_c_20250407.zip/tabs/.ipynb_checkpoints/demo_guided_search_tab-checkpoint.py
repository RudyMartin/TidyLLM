"""
[File: tabs/demo_guided_search_tab.py]
Version: DSPy 2.5.26 - Streamlit Guided Search (Demo)

Description:
  Demo version of the Guided Search tab for exploring risk categories
  and DSPy-powered validation of user-submitted reports.
"""

import streamlit as st
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
from dsai.dspy_pipeline_controller import run_pipeline


def render():
    st.header("\U0001F50E Guided Search (Demo)")
    st.markdown("""
    Select a **risk category** and enter a query, report, and project details.
    The DSPy engine will compare and improve your report using few-shot logic.
    """)

    risk_category = st.selectbox("Choose Risk Category:", ["Strategic", "Operational", "Technical"])

    query = st.text_input("Query", f"What are the risks for {risk_category.lower()} initiatives?")
    report = st.text_area("Draft Report", "This project introduces multiple uncertainties and requires close monitoring.")
    details = st.text_area("Project Details", "The project involves cloud migration across regions with tight compliance requirements.")

    if st.button("Run DSPy Validation"):
        result = run_pipeline(query, report, details)
        st.subheader("✅ DSPy Output")
        st.json(result.get("query_result"))

        st.subheader("📝 Refined Report")
        st.text_area("Corrected Report", result.get("corrected_report", "N/A"), height=200)

        if result.get("signature_info"):
            st.subheader("🔐 Signature & Reasoning")
            st.json(result["signature_info"])

    st.markdown("----")
    st.markdown("Want to review past audits?")
    if st.button("📍 View Similar Audits in FAISS →"):
        st.session_state.update({"tab": "📍 FAISS Search"})

if __name__ == "__main__":
    render()