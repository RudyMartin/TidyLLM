"""
[File: tabs/admmin/pdf_tab.py]
Description: Provides the UI for PDF processing: splitting PDFs, extracting text,
and converting pages to JSON format.
  
TODO:
  - Enhance PDF processing logic with progress indicators and robust error handling.
  - Implement update/delete functionality if PDFs change.
  
FUTURE:
  - Integrate OCR for scanned PDFs and support multilingual extraction.
  - Develop a full CRUD interface for managing extracted document metadata and versioning.
"""
# --- Standard Library Imports ---
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import streamlit as st
import logging

# --- Project-level Imports ---
from core.client_bundle import get_client_bundle
from core.extraction_helper import (
    extract_text_from_pdf,
    save_extracted_text_to_json,
    prepare_pdf_splits,
    extract_text_to_json,
)
from core.s3_utils import list_pdf_files_s3, list_json_files_s3,  list_s3_files_with_extension

# --- Logging and Context Settings ---
logger = logging.getLogger(__name__)

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config


def render():
    st.header("\U0001F4C2 PDF Processing")

    # config = get_client_bundle().config
    # s3_client = get_client_bundle().s3

    bucket_name = config["bucket_name"]
    pdf_folder = config["pdf_folder"]
    page_folder = config["page_folder"]
    json_folder = config["json_folder"]

    # if st.button("🏠 Back to Main View"):
    #     st.session_state["admin_tool"] = "None"
    #     st.srerun()

    st.markdown("### 🧪 Debug: S3 Raw Listing Test")
    

    try:
        bucket = config["bucket_name"]
        prefix = "dev/pdf/arxiv_wellsfargo/"  # Replace if needed
    
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        
        if not keys:
            st.warning("⚠️ No keys found under this prefix.")
        else:
            st.success(f"✅ Found {len(keys)} objects.")
            st.write(keys[:10])  # Limit to first 10 results
    
    except Exception as e:
        st.error(f"❌ Failed to list objects: {e}")

    
    
    # Minor buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("\u26A1 Batch Process (Split + Extract)", type="primary"):
            try:
                with st.spinner("Splitting PDFs into pages..."):
                    num_pdfs_processed = prepare_pdf_splits()

                with st.spinner("Extracting text and creating JSON files..."):
                    num_pages_processed = extract_text_to_json()

                st.success(
                    f"\u26A1 Batch completed successfully: "
                    f"{num_pdfs_processed} PDFs split, "
                    f"{num_pages_processed} PDF pages extracted and chunked into JSON."
                )
            except Exception as e:
                st.error(f"\u274C Batch extraction failed: {e}")

        if st.button("\U0001F4C4 1. Split PDFs into Pages", type="secondary"):
            try:
                num_processed = prepare_pdf_splits()
                st.success(f"\u2705 Successfully split {num_processed} PDFs into pages.")
            except Exception as e:
                st.error(f"\u274C Error splitting PDFs: {e}")

        if st.button("\U0001F9E0 2. Extract Content into JSON", type="secondary"):
            try:
                num_processed_pages = extract_text_to_json()
                st.success(f"\u2705 Successfully processed text from {num_processed_pages} PDF pages.")
            except Exception as e:
                st.error(f"\u274C Error extracting text: {e}")

    with col2:
        if st.button("\U0001F50D List Full PDFs Files", type="secondary"):
            #pdf_files = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
            pdf_files = list_s3_files_with_extension(bucket_name, prefix,"pdf")
            num_pdfs = len(pdf_files)
            st.info(f"\U0001F50E {num_pdfs} PDF(s) found in `{pdf_folder}`.")
            if num_pdfs > 0:
                st.write(pdf_files)

        if st.button("\U0001F4C2 List Split Pages", type="secondary"):
            #pages = s3_client.list_pdf_files_s3(bucket_name, page_folder)
            pages = list_s3_files_with_extension(bucket_name, page_folder,"pdf")
            num_pages = len(pages)
            st.info(f"\U0001F4C2 {num_pages} PDF page(s) found in `{page_folder}`.")
            if num_pages > 0:
                st.write(pages)

        if st.button("\U0001F4D1 List JSON Content", type="secondary"):
            #json_files = s3_client.list_json_files_s3(bucket_name, json_folder)
            json_files  = list_s3_files_with_extension(bucket_name, json_folder,"json")
            num_json_files = len(json_files)
            st.info(f"\U0001F4D1 {num_json_files} JSON file(s) found in `{json_folder}`.")
            if num_json_files > 0:
                st.write(json_files)


if __name__ == "__main__":
    render()
