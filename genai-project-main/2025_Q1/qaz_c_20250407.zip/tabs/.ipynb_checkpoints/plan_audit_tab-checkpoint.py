"""
[File: tabs/plan_audit_tab.py]
Version: DSPy 2.5.26 - Streamlit Plan Audit Tab (Advanced)

Description:
  Streamlit tab to audit uploaded Model Development Plans against
  standardized groundtruth using DSPy and semantic similarity scoring.
  
  Evaluates each key section of the plan individually and provides
  per-section match scores based on retrieved DSPy-enhanced reasoning.
"""

import os
from core.config_manager import get_config  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Needs classification]
config = get_config()  # 🔗 [Config Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 3️⃣ Unit Test / Notebook: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
import streamlit as st
from core.logging_helper import get_logger
from dsai.dspy_signature_uploader import (
    extract_text_from_pdf,
    extract_text_from_docx,
    extract_text_from_json,
    generate_signature_and_reasoning
)
from dsai.section_auditor import audit_plan_sections

logger = get_logger("plan_audit_tab")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
GROUNDTRUTH_PATH = os.path.join(ROOT_DIR, "groundtruth", "model_development.json")


def render():
    st.header("📋 Plan Audit - Model Development Validator")
    st.markdown("Upload a Model Development Plan to audit each section against AI-enriched expectations.")

    uploaded_file = st.file_uploader("Upload Document (PDF, DOCX, or JSON):", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()
        if ext == "pdf":
            text = extract_text_from_pdf(uploaded_file)
        elif ext == "docx":
            text = extract_text_from_docx(uploaded_file)
        elif ext == "json":
            text = extract_text_from_json(uploaded_file)
        else:
            st.error("Unsupported file type")
            return

        if not text:
            st.warning("No text found in document.")
            return

        st.text_area("📄 Extracted Text (Preview)", text[:2000], height=200)

        st.markdown("---")
        st.subheader("🧠 DSPy Reasoning Summary")
        result = generate_signature_and_reasoning(text)
        st.code(result.get("signature"), language="text")
        st.text_area("AI Reasoning", result.get("reasoning", ""), height=200)

        if os.path.exists(GROUNDTRUTH_PATH):
            with open(GROUNDTRUTH_PATH) as f:
                groundtruth = json.load(f)

            st.markdown("---")
            st.subheader("📊 Section-Level Evaluation")
            section_results = audit_plan_sections(text, groundtruth)

            for section_name, audit in section_results.items():
                with st.expander(f"📌 {section_name}"):
                    st.markdown(f"**Similarity Score:** `{audit['similarity_score']:.2f}`")
                    st.markdown("**Expected (Truth):**")
                    st.info(audit['expected'])
                    st.markdown("**Detected (From Plan):**")
                    st.warning(audit['found'])
        else:
            st.error("❌ Groundtruth file not found. Please upload or generate it first.")

if __name__ == "__main__":
    render()
