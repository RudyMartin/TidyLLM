"""
[File: dsai/modules/signatures.py]
Version: DSPy 2.5.26

Description:
  Central collection of DSPy Signature classes used across domain-specific modules.
  Includes SignatureRegistry and utilities for dynamic access in UI apps like Streamlit.
"""

from dspy import Signature, InputField, OutputField
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")


# ---- Signature Definitions ----

class RiskQuerySignature(Signature):
    risk_query = InputField()
    insights = OutputField(desc="Extracted insights about risks, mitigation, and operations.")

class RegulatoryRiskSignature(Signature):
    regulation = InputField()
    summary = OutputField(desc="Summary of regulatory risk and recommended actions.")

class ForecastingSignature(Signature):
    signal = InputField()
    projection = OutputField(desc="Predicted trend or quantitative outcome.")

class AuditSummarySignature(Signature):
    audit_log = InputField()
    summary = OutputField(desc="Key observations and anomalies from the audit.")

# ---- Registry ----

SignatureRegistry = {
    "Risk Query": RiskQuerySignature,
    "Regulatory Risk": RegulatoryRiskSignature,
    "Forecasting": ForecastingSignature,
    "Audit Summary": AuditSummarySignature
}

# ---- UI Helper ----

def get_signature_names() -> list[str]:
    """Returns a list of available signature display names for dropdowns."""
    return list(SignatureRegistry.keys())

def get_signature_class(name: str) -> type[Signature]:
    """Returns the Signature class given a display name."""
    return SignatureRegistry.get(name, RiskQuerySignature)  # fallback to RiskQuery


# Examples::
#  import streamlit as st
# from dsai.modules.signatures import get_signature_names, get_signature_class

# selected_signature_name = st.selectbox("Choose Task Type", get_signature_names())
# SignatureClass = get_signature_class(selected_signature_name)

#st.write(f"Selected Signature: `{SignatureClass.__name__}`")   
