"""
[File: dsai/modules/base_module.py]
Version: DSPy 2.5.26

Description:
  A generic base DSPy Module that dynamically accepts any Signature definition.
  This allows reuse for multiple reasoning tasks by swapping signatures.
"""

from dspy import Module, Predict
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")

class DynamicDSPyModule(Module):
    def __init__(self, signature_cls):
        super().__init__()
        self.signature_cls = signature_cls
        self.predict = Predict(signature_cls)

    def forward(self, **kwargs):
        return self.predict(**kwargs)