'''
[File: dsai/dspy_signature_uploader.py]
Version: DSPy 2.5.26

Description:
  Uploads a PDF, DOCX, or JSON file, generates a SHA-256 hash to uniquely fingerprint the document content,
  and uses DSPy to explain the context or purpose of the document.

NOTE: In DSPy v2.5.26, there is no global `compile()` function. 
      You must use the optimizer's `.compile()` method directly.

TODO:
  - Persist signature + reasoning metadata to storage (e.g., S3 or database).
  - Allow optional metadata injection for enhanced explanations.

FUTURE:
  - Integrate versioned signatures into a full document audit system.
  - Support reasoning comparison across document versions.
'''

import os
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
import hashlib
import logging
from io import BytesIO

from dspy import Module, Predict, Signature, InputField, OutputField
from PyPDF2 import PdfReader
from docx import Document
import streamlit as st

from core.logging_helper import get_logger

logger = get_logger("signature_uploader")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
DOCS_PATH = os.path.join(ROOT_DIR, "docs")
DEFAULT_JSON = os.path.join(ROOT_DIR, "docs_fallback.json")

# === DSPy Signature ===
class DocumentReasoningSignature(Signature):
    document = InputField()
    reasoning = OutputField(desc="AI-generated explanation of the document's purpose or content.")

# === DSPy Module ===
class DocumentReasoningModule(Module):
    def __init__(self):
        super().__init__()
        self.reasoner = Predict(DocumentReasoningSignature)

    def forward(self, document):
        return self.reasoner(document=document)

def extract_text_from_pdf(uploaded_file):
    try:
        pdf_stream = BytesIO(uploaded_file.read())
        reader = PdfReader(pdf_stream)
        full_text = "\n\n".join([page.extract_text() or "" for page in reader.pages])
        return full_text.strip()
    except Exception as e:
        logger.error(f"Failed to extract text from PDF: {e}")
        return ""

def extract_text_from_docx(uploaded_file):
    try:
        doc = Document(BytesIO(uploaded_file.read()))
        return "\n\n".join([para.text for para in doc.paragraphs])
    except Exception as e:
        logger.error(f"Failed to extract text from DOCX: {e}")
        return ""

def extract_text_from_json(uploaded_file):
    try:
        json_data = json.load(uploaded_file)
        return json.dumps(json_data, indent=2)
    except Exception as e:
        logger.error(f"Failed to extract text from JSON: {e}")
        return ""

def generate_signature_and_reasoning(text: str) -> dict:
    try:
        signature = hashlib.sha256(text.encode("utf-8")).hexdigest()
        logger.info(f"Generated SHA-256 signature: {signature[:10]}...")

        module = DocumentReasoningModule()
        output = module(document=text)
        reasoning = output.reasoning
        logger.info("DSPy reasoning successfully generated.")

        return {
            "signature": signature,
            "reasoning": reasoning
        }

    except Exception as e:
        logger.error(f"Failed to generate signature and reasoning: {e}")
        return {
            "signature": None,
            "reasoning": f"Error: {e}"
        }

def handle_uploaded_doc():
    uploaded_file = st.file_uploader("Upload a document (PDF, DOCX, or JSON):", type=["pdf", "docx", "json"])

    if uploaded_file:
        ext = uploaded_file.name.split(".")[-1].lower()

        with st.spinner("Extracting text from file..."):
            if ext == "pdf":
                text = extract_text_from_pdf(uploaded_file)
            elif ext == "docx":
                text = extract_text_from_docx(uploaded_file)
            elif ext == "json":
                text = extract_text_from_json(uploaded_file)
            else:
                st.error("Unsupported file type.")
                text = ""

        if text:
            st.text_area("Extracted Text", text[:2000], height=200)
            with st.spinner("Generating signature and reasoning..."):
                result = generate_signature_and_reasoning(text)
            st.success("Done!")
            st.code(result["signature"], language="text")
            st.text_area("AI Reasoning", result["reasoning"], height=200)
            st.caption(f"SHA Preview: {result['signature'][:10]}... vs length {len(result['signature'])}")
        else:
            st.error("Could not extract any text from the uploaded file.")
    else:
        if not os.path.exists(DOCS_PATH):
            st.info("\U0001F4C1 No /docs folder found. Using fallback example data.")
            if os.path.exists(DEFAULT_JSON):
                with open(DEFAULT_JSON, "r") as f:
                    fallback = json.load(f)
                example_text = fallback.get("example_text", "Example content unavailable.")
                st.text_area("Example Text (Local JSON)", example_text, height=150)
                if st.button("Run Reasoning on Example"):
                    result = generate_signature_and_reasoning(example_text)
                    st.code(result["signature"])
                    st.text_area("Reasoning", result["reasoning"], height=200)
        else:
            st.info("Please upload a PDF, DOCX, or JSON file to begin.")

# Optional standalone test
if __name__ == "__main__":
    import streamlit.web.cli as stcli
    import sys
    sys.argv = ["streamlit", "run", __file__]
    sys.exit(stcli.main())