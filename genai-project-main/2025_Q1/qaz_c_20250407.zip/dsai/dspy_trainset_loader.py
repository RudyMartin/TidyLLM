# [File: dsai/trainset_loader.py]
# Version: DSPy 2.5.26

from dspy import Example
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")

def get_trainset():
    return [
        Example(risk_query="What are the top risks in AI adoption?",
                insights="Lack of governance, misaligned goals, ethical concerns, and model drift."),
        Example(risk_query="What are operational risks in cloud transformation?",
                insights="Downtime, vendor lock-in, unexpected cost spikes, and change resistance.")
    ]

def get_testset():
    return [
        Example(risk_query="What are technical risks in microservices migration?",
                insights="Service sprawl, monitoring complexity, and inconsistent interfaces.")
    ]

def evaluate_pipeline_metric(example, pred, trace=None):
    # Very simple string match scoring
    return float(example.insights.lower() in pred.insights.lower())
