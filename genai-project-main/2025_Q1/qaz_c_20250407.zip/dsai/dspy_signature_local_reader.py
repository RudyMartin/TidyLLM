'''
[File: dspy_signature_local_reader.py]
Version: DSPy 2.5.26

Description:
  Reads *.txt and *.json files from a local folder (ROOT_DIR/docs), generates a SHA-256 hash
  to uniquely fingerprint the content, and uses DSPy to explain the document's purpose.

NOTE:
  - This script expects .txt (UTF-8 encoded) and .json (well-formed JSON) files.
  - Uses DSPy v2.5.26 Predict + Signature approach (no compile()).
'''

import os
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import hashlib
import json
import logging
from dspy import Module, Predict, Signature, InputField, OutputField
from core.logging_helper import get_logger

logger = get_logger("signature_local_reader")

ROOT_DIR = os.getenv("ROOT_DIR", ".")
DOCS_PATH = os.path.join(ROOT_DIR, "docs")

# === DSPy Signature ===
class DocumentReasoningSignature(Signature):
    document = InputField()
    reasoning = OutputField(desc="AI-generated explanation of the document's purpose or content.")

# === DSPy Module ===
class DocumentReasoningModule(Module):
    def __init__(self):
        super().__init__()
        self.reasoner = Predict(DocumentReasoningSignature)

    def forward(self, document):
        return self.reasoner(document=document)

def generate_signature_and_reasoning(text: str) -> dict:
    try:
        signature = hashlib.sha256(text.encode("utf-8")).hexdigest()
        logger.info(f"Generated SHA-256: {signature[:10]}...")
        module = DocumentReasoningModule()
        output = module(document=text)
        return {
            "signature": signature,
            "reasoning": output.reasoning
        }
    except Exception as e:
        logger.error(f"Reasoning failed: {e}")
        return {"signature": None, "reasoning": f"Error: {e}"}

def process_local_documents():
    logger.info(f"Scanning folder: {DOCS_PATH}")
    for filename in os.listdir(DOCS_PATH):
        filepath = os.path.join(DOCS_PATH, filename)
        try:
            if filename.endswith(".txt"):
                with open(filepath, "r", encoding="utf-8") as file:
                    content = file.read().strip()
            elif filename.endswith(".json"):
                with open(filepath, "r", encoding="utf-8") as file:
                    json_obj = json.load(file)
                    content = json.dumps(json_obj, indent=2)
            else:
                continue  # skip unsupported formats

            print(f"\n===== {filename} =====")
            result = generate_signature_and_reasoning(content)
            print(f"SHA-256: {result['signature'][:10]}... | Reasoning:\n{result['reasoning'][:300]}...")

        except Exception as e:
            logger.error(f"Error processing {filename}: {e}")

if __name__ == "__main__":
    process_local_documents()
