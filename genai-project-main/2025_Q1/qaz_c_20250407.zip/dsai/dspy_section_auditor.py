"""
[File: dsai/dspy_section_auditor.py]
Version: DSPy 2.5.26

Description:
  Parses a model development document into sections and audits each one against ground truth using FAISS.
  Computes similarity and runs DSPy reasoning for interpretation.

TODO:
  - Support PGVector retrieval (currently FAISS only).
  - Add thresholds for pass/fail scoring.
  - Log scores for dashboard.
"""

import re
from core.config_manager import get_config  # 🔗 [Config Type ❓ Unknown: Needs classification]
config = get_config()  # 🔗 [Config Type ❓ Unknown: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type ❓ Unknown: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
import json
from typing import List, Dict
from dspy import Module, Predict, Signature, InputField, OutputField
from core.logging_helper import get_logger
from core.vector_manager import VectorManager
from dsai.modules.base_module import DynamicDSPyModule

logger = get_logger("section_auditor")

# --- Signature ---
class SectionAuditSignature(Signature):
    section_text = InputField()
    truth_text = InputField()
    evaluation = OutputField(desc="Judgment on adequacy of section based on ground truth.")

# --- DSPy Module ---
class SectionAuditModule(Module):
    def __init__(self):
        super().__init__()
        self.predict = Predict(SectionAuditSignature)

    def forward(self, section_text, truth_text):
        return self.predict(section_text=section_text, truth_text=truth_text)

# --- Section Parser ---
def parse_sections(text: str) -> Dict[str, str]:
    """Heuristic splitter using numbered headers."""
    sections = {}
    current_section = "Introduction"
    buffer = []

    for line in text.splitlines():
        match = re.match(r"^(\d+(\.\d+)*)\s+(.*)", line)
        if match:
            if buffer:
                sections[current_section] = "\n".join(buffer).strip()
                buffer = []
            current_section = match.group(3)
        else:
            buffer.append(line)

    if buffer:
        sections[current_section] = "\n".join(buffer).strip()

    return sections

# --- Auditor ---
def audit_plan_sections(text: str, model_key: str = "titan_v2") -> List[Dict]:
    sections = parse_sections(text)
    vm = VectorManager(store_type="faiss")
    audit_module = SectionAuditModule()

    audit_results = []
    for title, content in sections.items():
        try:
            query_embedding = vm.clients.vectorizer.generate_embedding(content)
            retrieved = vm.index_store.retrieve_similar(query_embedding, model_key=model_key, top_k=1)
            top_truth = retrieved[0]["text"] if retrieved else ""

            result = audit_module(section_text=content, truth_text=top_truth)
            evaluation = result.evaluation

            audit_results.append({
                "section_title": title,
                "section_text": content,
                "matched_truth": top_truth,
                "evaluation": evaluation,
                "similarity_score": retrieved[0].get("score") if retrieved else 0
            })
        except Exception as e:
            logger.error(f"Audit failed for section '{title}': {e}")
            audit_results.append({
                "section_title": title,
                "error": str(e)
            })

    return audit_results
