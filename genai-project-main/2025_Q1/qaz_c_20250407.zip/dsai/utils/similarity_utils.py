# [File: dsai/utils/similarity_utils.py]
"""
Version: DSPy 2.5.26

Description:
Utility to compute top-K most similar items using FAISS index store and the VectorManager.
"""

import numpy as np
from core.config_manager import get_config  # 🔗 [Config Type 4️⃣ Core Utility: Needs classification]
config = get_config()  # 🔗 [Config Type 4️⃣ Core Utility: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 4️⃣ Core Utility: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
from core.vector_manager import VectorManager

def get_top_matches(index_store, query_text, vectorizer=None, top_k=5, model_key="titan_v2"):
    """
    Retrieve the most similar ground truth entries to a given text.

    Args:
        index_store: Initialized FAISSIndexStore from VectorManager.
        query_text (str): The query to compare.
        vectorizer: Optional external vectorizer; if None, use default from VectorManager.
        top_k (int): Number of similar results to return.
        model_key (str): Embedding model key.

    Returns:
        List[Dict]: Top-k matched results with similarity score and metadata.
    """
    if vectorizer is None:
        vectorizer = VectorManager(store_type="faiss").clients.vectorizer

    query_embedding = vectorizer.generate_embedding(query_text)
    results = index_store.retrieve_similar(query_embedding, model_key=model_key, top_k=top_k)

    return results
