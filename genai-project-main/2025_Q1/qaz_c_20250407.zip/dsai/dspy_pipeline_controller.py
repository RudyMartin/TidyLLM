"""
[File: dspy_pipeline_controller.py]
Description: DSPy pipeline orchestration for risk insights.
  - Version: DSPy 2.5.26
  - Defines the main DSPy Module wrapper (DSPipeline).
  - Supports training using BootstrapFewShot with train/test sets.
  - Includes runtime method for executing the pipeline from Streamlit or other UI.
"""

import dspy
from core.config_manager import get_config  # 🔗 [Config Type 5️⃣ Pipeline / Agent: Needs classification]
config = get_config()  # 🔗 [Config Type 5️⃣ Pipeline / Agent: Inserted by patcher]
from core.client_manager import get_clients  # 🔗 [S3 Client Type 5️⃣ Pipeline / Agent: Inserted by patcher]
clients = get_clients()
s3 = clients.get("s3")
bedrock = clients.get("bedrock")
from dsai.dspy_query_processing import process_query
from dsai.dspy_trainset_loader import get_trainset, get_testset, evaluate_pipeline_metric

class DSPipeline(dspy.Module):
    def __init__(self):
        super().__init__()
        self.query_processor = process_query

    def forward(self, query):
        return self.query_processor(query)

def run_pipeline():
    """
    Trains and compiles the DSPy pipeline using BootstrapFewShot.
    """
    trainset = get_trainset()
    testset = get_testset()

    pipeline = DSPipeline()
    booster = dspy.BootstrapFewShot(metric=evaluate_pipeline_metric)
    tuned_pipeline = dspy.Compile(
        pipeline,
        trainset=trainset,
        optimizer=booster,
        max_bootstrapped_demos=3,
        eval_kwargs={"testset": testset}
    )
    return tuned_pipeline

def run_pipeline(query: str, retrieved_chunks: list, model_name: str) -> dict:
    """
    Executes the DSPy query pipeline for a given input.

    Args:
        query (str): The user query.
        retrieved_chunks (List[Dict]): Chunks retrieved from the vector store.
        model_name (str): Model used for inference.

    Returns:
        dict: Result output dictionary.
    """
    print("[Pipeline Controller] Starting DSPy pipeline with model:", model_name)
    try:
        result = process_query(
            query=query,
            contexts=retrieved_chunks,
            model_key=model_name
        )
        print("[Pipeline Controller] DSPy pipeline completed successfully.")
        return result
    except Exception as e:
        print(f"[Pipeline Controller] DSPy pipeline failed: {e}")
        return {
            "error": str(e),
            "output": None,
            "query": query,
            "chunks_used": len(retrieved_chunks)
        }
