# 🧑‍💻 Developer Handbook

Guidance for contributors and maintainers.

## 1. Code Layout
- Main folders
- Key module purposes

## 2. Adding a Tab or Script
- How to create a new Streamlit tab
- How to add a debug script

## 3. Config and Clients
- Using `initialize_config()`
- Using `get_client_bundle()`

## 4. Naming Conventions
- Snake case for files
- Tab naming
- Logging practices

## 5. Testing
- Unit test recommendations
- CLI vs UI test tips