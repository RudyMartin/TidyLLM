# 🧪 How To: Tune FAISS Index

Instructions for adjusting vector similarity behavior.

## 1. Adjust Vector Embeddings
## 2. Rebuild FAISS Index
## 3. Use Log or Sigmoid Scaling
## 4. Compare Accuracy