# 📄 How To: Add a New PDF

Step-by-step guide to split, extract, and embed a new PDF.

## 1. Upload PDF
## 2. Split Pages
## 3. Extract Text
## 4. Create Chunks & Embed
## 5. Index & Test Search