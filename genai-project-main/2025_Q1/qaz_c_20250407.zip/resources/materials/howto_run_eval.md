# ✅ How To: Run an Evaluation

How to run comparisons across pipelines and models.

## 1. Setup Evaluation Input
## 2. Run Evaluation Tab
## 3. Interpret Metrics
## 4. Export Results