# Unified Config + Client Manager Pattern

## Overview
The **Unified Config + Client Manager** pattern is designed to streamline configuration management and client access (e.g., S3, Bedrock) across both **Streamlit UI** and **CLI** environments. This pattern provides a **clean separation of concerns**, ensuring that configuration and client management are handled independently, yet work together seamlessly.

## Key Principles
1. **Configuration Management**:
    - Configuration values (e.g., paths, parameters) are loaded from a central location (a configuration file) and are accessible across the application.
    - The `get_config()` function is used to load configuration from disk, and `get_config_state()` retrieves configuration from `st.session_state` in Streamlit UI or directly from the disk in CLI.

2. **Client Management**:
    - Clients (e.g., S3, Bedrock) are instantiated using the `get_clients()` function, which accepts the configuration and returns the appropriate clients.
    - Clients are cached for reuse throughout the application using **LRU caching** to improve performance.

3. **Streamlined Access**:
    - Both **UI** and **CLI** access configuration and clients in a consistent way, ensuring that the logic is **modular** and **easy to maintain**.

4. **Separation of Concerns**:
    - **Configuration** management is handled independently from **client** management.
    - This makes the code easier to extend and maintain, and ensures **clean modularity**.

## Benefits
- **Simplicity**: Centralizes configuration and client management, reducing duplication and making the system easier to maintain.
- **Modularity**: Decouples configuration from client logic, making it easy to change or extend either component without affecting the other.
- **Consistency**: Provides a consistent way to access configuration and clients across the application.
