# Configuration Management

## Overview
Configuration management is responsible for loading and managing configuration values across the system. The system uses the `get_config()` function to load configuration data from a configuration file (e.g., `config.json`), and `get_config_state()` is used to retrieve the configuration either from **Streamlit's session state** (UI mode) or directly from the file (CLI mode).

### Key Functions:
- **`get_config()`**: Loads configuration from the disk.
- **`get_config_state()`**: Retrieves the configuration from `st.session_state` if in Streamlit UI mode, or from the configuration file if in CLI mode.
- **Configuration Persistence**: Configuration is persistent in Streamlit through `st.session_state` but is directly accessed in CLI mode.

## Pattern Update
With the introduction of the **Unified Config + Client Manager** pattern, configuration management is now **separated from client management**. Clients (S3, Bedrock) are instantiated using configuration values, but client management logic resides in **`core/client_manager.py`**.
