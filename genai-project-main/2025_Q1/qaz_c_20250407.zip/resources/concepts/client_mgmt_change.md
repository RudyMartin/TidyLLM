# Client Management (S3 & Bedrock)

## Overview
The **Client Manager** is responsible for managing external clients such as **S3** and **Bedrock**. Clients are initialized based on the configuration and are made available for use throughout the application.

### Key Functions:
- **`get_clients()`**: Returns a dictionary of clients (S3, Bedrock) based on the configuration provided.
- **`get_client(name)`**: Retrieves a specific client by name (e.g., `s3`, `bedrock`).
- **Client Caching**: Clients are cached using **LRU cache** to avoid redundant initialization.

### Pattern Update
The **Unified Config + Client Manager** pattern ensures that **client management** is **separated** from configuration logic. The clients are now instantiated using the configuration provided by `get_config()`, and can be accessed consistently via `get_clients()`. This separation improves modularity and allows clients to be managed more easily.
