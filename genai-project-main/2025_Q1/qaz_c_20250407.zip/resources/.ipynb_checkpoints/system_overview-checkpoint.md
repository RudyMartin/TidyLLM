# 🧭 System Overview

This outlines the overall architecture and module flow.

## 1. High-Level Flow
- PDF ➝ Page ➝ JSON ➝ Embedding ➝ Index ➝ Search ➝ UI

## 2. Components
- Extraction modules
- Embedding helpers
- Index management
- UI/CLI interface

## 3. Data Flow Diagram
(Add diagram link or placeholder here)

## 4. Key Interfaces
- Streamlit session
- S3 file interface
- FAISS vector store