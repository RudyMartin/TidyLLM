
# 🧩 Configuration vs Client Bundles in This Project

This document explains how configuration and AWS client bundles are managed in a unified and scalable way.

---

## 🔄 How Client Bundles Fit into Your Config System

Your config system and client bundle system work **together**, but serve **distinct purposes** in your architecture:

| Layer             | Purpose                             | Key Function            | Example Output                        |
|------------------|-------------------------------------|-------------------------|----------------------------------------|
| 🧠 `initialize_config()` | Load configuration (from disk/session) | `dict` of settings       | `{ "bucket_name": ..., "region_name": ... }` |
| 🧰 `get_client_bundle()` | Initialize AWS clients using config  | Bundle of clients + config | `ClientBundle(config, s3, bedrock)`        |

---

## 🔧 Visual Layer Integration

```plaintext
[ CLI / UI / Agent ]
       │
       └──> config = initialize_config()
       │
       └──> clients = get_client_bundle()
              ├── clients.config     ✅ same config as above
              ├── clients.s3         ✅ boto3.client("s3")
              └── clients.bedrock    ✅ boto3.client("bedrock-runtime")
```

---

## 🔄 Relationship Between Config and Clients

| Feature                 | `config`                            | `clients` (`ClientBundle`)                     |
|------------------------|--------------------------------------|------------------------------------------------|
| Source of truth        | Yes                                  | No — uses config to create clients             |
| Session-patched        | ✅ via `initialize_config()`          | ✅ includes `st.session_state["CONFIG"]`        |
| Used in core utils     | ✅ (pass directly)                    | ❌ (don't pass client bundles to core files)    |
| Used in tabs/scripts   | ✅ or `get_config()`                  | ✅ preferred for multi-client apps              |
| Good for mocking       | ✅ via config override                | ✅ mock full bundle in unit tests               |

---

## 📦 Summary: When to Use What

| Use Case                | You Use This              | Why?                                             |
|-------------------------|---------------------------|--------------------------------------------------|
| UI Tabs / CLI Scripts   | `clients = get_client_bundle()` | Get everything in one shot                        |
| Pipelines / Agent Flow  | `clients = get_client_bundle()` | Clean access to config + clients                 |
| Core Utilities          | `config`, `s3_client`     | Avoid circular or high-level dependencies        |
| Unit Tests              | `mock clients.config`, etc. | Easier to patch `ClientBundle()` for testing     |

---

## 📄 Naming Convention

| Object Name | Type           | Description                            |
|-------------|----------------|----------------------------------------|
| `config`    | `dict`         | App-wide configuration dictionary      |
| `clients`   | `ClientBundle` | Unified access to config, S3, Bedrock  |
| `s3`        | `boto3.client` | From `clients.s3`                      |
| `bedrock`   | `boto3.client` | From `clients.bedrock`                 |

---

## 🧱 Configuration Management Overview

This section explains how configuration is handled consistently across the codebase using a layered approach.

---

### 🔧 Levels of Code and Config Usage

| **Level**         | **Examples**                         | **Config Source**         | **Notes**                                                                 |
|------------------|--------------------------------------|----------------------------|----------------------------------------------------------------------------|
| `UI`             | `admin_config_tab.py`, Streamlit tabs | `from config_manager import get_config()` | Uses global app config automatically from session or disk |
| `CLI Scripts`    | `debug_*.py`, batch runners           | `from config_manager import get_config()` | CLI-safe and centralized loading |
| `Pipelines`      | Vector embedding, agent orchestration | `from config_manager import get_config()` | Easy to switch or validate environment config |
| `Core Utils`     | `s3_utils.py`, `faiss_helper.py`      | `config` passed explicitly | Avoids circular imports, stays lightweight |
| `Model Modules`  | Vectorizers, chunkers, etc.           | `config` passed explicitly | Stay reusable, testable, decoupled from system context |

---

### 🧱 Config Loading Functions

| **Function**            | **Where Defined**         | **Purpose**                                 | **Who Should Use It**             |
|-------------------------|---------------------------|----------------------------------------------|-----------------------------------|
| `initialize_config()`   | `core/config_helper.py`   | Loads and patches `session_state["CONFIG"]` | Used internally everywhere        |
| `get_config()`          | `core/config_manager.py`  | Calls `initialize_config()` and returns config | UI, CLI, and pipelines            |
| `save_config()`         | `core/config_helper.py`   | Writes config to disk                        | UI/admin tools only               |
| `reload_config()`       | (Deprecated)              | ✅ Replaced by `initialize_config()`         | —                                 |

---

### 🧭 Naming Convention for Clarity

| **Name Pattern**        | **Used For**              | **Comment**                                    |
|-------------------------|---------------------------|------------------------------------------------|
| `get_config()`          | High-level config entry   | Safe for pipelines, CLI, and UI                |
| `initialize_config()`   | Low-level setup           | Internal bootstrapping; called only once       |
| `config`                | Local variable name       | Holds the final loaded dictionary              |

---

### 🔄 Flowchart of a Typical Load

```plaintext
UI/CLI Entry
   │
   └──> get_config()          ← Recommended
         │
         └──> initialize_config()
                 │
                 └──> st.session_state["CONFIG"]
```

---

### 🧪 Debugging Config Issues

| **Symptom**                             | **Possible Cause**                            | **Fix**                                      |
|-----------------------------------------|-----------------------------------------------|----------------------------------------------|
| `KeyError: 'CONFIG'`                    | `initialize_config()` not called              | Always use `get_config()` in UI/CLI          |
| `ImportError from config_helper`        | Using deprecated `get_config()` or `reload_config()` | Replace with `initialize_config()` or `get_config()` |
| Config not updating after UI changes    | `session_state["CONFIG"]` not refreshed       | Call `initialize_config()` again             |
