
# 📚 Project Documentation

Welcome to the documentation hub for this project. Below is a guide to key architectural components and how to use them.

---

## 📁 Configuration & Clients

| Topic | Description |
|-------|-------------|
| [Configuration vs Client Bundles](config_vs_clients.md) | Understand how config is loaded and how AWS clients are bundled together for consistent use. |

---

## 📂 Coming Soon

| Topic | Description |
|-------|-------------|
| Data Flow Overview | Visual map of how data moves through PDF > JSON > FAISS. |
| Embedding Strategies | Overview of how different embedding models are plugged in. |
| Tab Responsibilities | Which Streamlit tab does what and how it connects. |

---

## 🧠 DSPy and Multi-Agent Workflows

| Topic | Description |
|-------|-------------|
| [DSPy Workflow Options](materials/dspy_workflow_options.md) | Comparison of three DSPy workflow strategies |
| [Evaluation Metrics for DSPy](materials/dspy_evaluation_metrics.md) | How to evaluate DSPy pipelines and outputs |
| [DSPy Multi-Agent Resources](materials/dspy_multi_agent_resources.md) | Notes and models supporting DSPy agent design |
| [DSPy Requirements](materials/dspy_requirements.md) | Baseline requirements and recommendations |
| [DSPy Components Used](materials/dspy_components_used.md) | Inventory of key DSPy modules and methods |

---

## 📊 FAISS Index Tuning

| Topic | Description |
|-------|-------------|
| [Log Adjusted FAISS Index](materials/faiss_tuning_log_adjusted.md) | Experiments with log-distance adjustment |
| [Sigmoid FAISS Index Strategy](materials/faiss_tuning_sigmoid.md) | Strategy involving sigmoid adjustment |
| [Sigmoid Cost Function FAISS](materials/faiss_tuning_sigmoid_cost.md) | Tuning FAISS using cost-based sigmoid weights |

---

## 📚 Corpus and Citation Sources

| Topic | Description |
|-------|-------------|
| [Corpus Governance Sources](materials/corpus_governance_sources.md) | Citation notes on dataset sourcing and attribution |
| [Sparse Embeddings Research](materials/sparse_embeddings_research.md) | Research references for sparse vector indexing |
| [Model Drivers Corpus](materials/model_drivers_corpus.md) | Papers and findings behind corpus design |

---

## 📘 App Overview

| Topic | Description |
|-------|-------------|
| [About This App](materials/about_this_app.md) | High-level overview of what the app does and how it's structured |
| [About the Demo](materials/about_the_demo.md) | Explanation of the interactive demo components and workflows |
