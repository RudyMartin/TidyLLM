# 🚀 Setup Guide

This guide walks through setting up the environment and running the app.

## 1. Prerequisites
- Python version
- Required packages
- AWS credentials / S3 setup

## 2. Install Instructions
- Clone repo
- Run `pip install -e .`
- Config setup

## 3. Running the App
- Run Streamlit UI
- Run CLI scripts
- Example config

## 4. Optional
- Running in SageMaker
- Embedding test mode