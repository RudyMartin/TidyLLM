
# 🚀 Deployment Instructions for VectorQA Sage

## ✅ 1. Local Development (Recommended First Run)

### Requirements:
- Python 3.8+
- pip / virtualenv (optional but recommended)

### Instructions:

```bash
# Step 1: Unzip and enter project
unzip vectorqa_option_3.zip
cd vectorqa_reconstructed

# Step 2: (Optional) Virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Step 3: Install dependencies
pip install -r requirements.txt

# Step 4: Launch Streamlit app
streamlit run app/fewshot_qa_app.py
```

---

## ☁️ 2. Deploy to Streamlit Cloud

- Go to: https://streamlit.io/cloud
- Sign in with GitHub
- Choose your repo and entry file: `app/fewshot_qa_app.py`
- Click **Deploy**

Streamlit will:
- Auto-install `requirements.txt`
- Launch your app at a public URL

---

## 🧠 3. Run on SageMaker Studio Lab / JupyterHub

- Upload project to JupyterLab
- Open a terminal and run:

```bash
pip install -r requirements.txt
streamlit run app/fewshot_qa_app.py
```

Use a public link to open the Streamlit app if running remotely.

---

## 🧳 4. Optional Production Deployment

- Host on AWS EC2 or GCP VM
- Use Docker for containerization
- Use `setup.py` to expose CLI tools
- Enable S3 access for full FAISS + model storage integration

---

## 📫 Support

- **Author**: Rudy Alvarez Martin
- **Company**: Next Shift Consulting
- **LinkedIn**: [linkedin.com/in/rudymartin](https://linkedin.com/in/rudymartin)

