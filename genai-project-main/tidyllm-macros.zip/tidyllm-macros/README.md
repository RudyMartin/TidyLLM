# TidyLLM Macros

Advanced workflow macros for TidyLLM - tidyverse-style data pipelines with LLM integration.

## Overview

TidyLLM Macros provides powerful workflow automation and pipeline orchestration for LLM operations, bringing tidyverse-style data manipulation patterns to AI workflows.

## Features

- **Tidyverse-style Pipelines**: Chain LLM operations with familiar `|>` syntax
- **MVR Integration**: Multi-step verification and review workflows
- **MCP Support**: Model Control Protocol integration for standardized tool interfaces  
- **Built-in Personas**: Specialized LLM personas for different workflow stages
- **Monitoring**: Real-time workflow monitoring and performance tracking

## Installation

```bash
pip install tidyllm-macros
pip install tidyllm-macros[all]  # With all optional dependencies
```

## Quick Start

```python
from tidyllm_macros import macro_pipeline, mvr_workflow
from tidyllm import llm_message, claude

# Basic macro pipeline
result = (
    llm_message("Analyze quarterly data")
    |> macro_pipeline("data_analysis") 
    |> mvr_workflow(claude())
)

# Advanced workflow with built-in personas
analysis = (
    llm_message("Review financial report", "report.pdf")
    |> macro_pipeline("financial_review")
    |> apply_persona("financial_analyst")
    |> verify_with_persona("risk_manager") 
    |> finalize_review()
)
```

## Workflows

### MVR (Multi-step Verification Review)
- Automated peer review simulation
- Multi-persona validation
- Quality assurance pipelines

### Data Analysis Macros
- Statistical analysis workflows
- Report generation pipelines
- Visualization automation

### Enterprise Integration
- Cost tracking and monitoring
- Audit trail generation
- Compliance workflows

## License

CC0 1.0 Universal (Public Domain Dedication)