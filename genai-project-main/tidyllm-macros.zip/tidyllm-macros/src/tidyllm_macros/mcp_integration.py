#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Macros MCP Integration

Makes macros available as MCP tools that can be called by LLMs directly,
bridging the gap between [macro] syntax and standard MCP protocol.
"""

import logging
import json
from typing import Dict, List, Any, Optional
from dataclasses import asdict

from .core import MacroRegistry, MacroProcessor
from .engine import MacroEngine
from .monitoring import AHAMacroMonitor

logger = logging.getLogger(__name__)

class MacroMCPServer:
    """
    MCP server that exposes macros as callable tools
    
    Allows LLMs to call macros like:
    {
        "type": "function", 
        "function": {
            "name": "analyze_two_documents",
            "parameters": {
                "files": ["doc1.pdf", "doc2.pdf"],
                "analysis_type": "comprehensive"
            }
        }
    }
    """
    
    def __init__(self, registry: MacroRegistry = None):
        self.registry = registry or MacroRegistry()
        self.processor = MacroProcessor(self.registry)
        self.engine = MacroEngine(AHAMacroMonitor())
        
    def get_available_tools(self) -> List[Dict[str, Any]]:
        """
        Get MCP tool definitions for all registered macros
        
        Returns tool schema that LLMs can use to call macros
        """
        tools = []
        
        for macro_name, macro_def in self.registry.macros.items():
            # Convert macro to MCP tool schema
            tool_schema = {
                "type": "function",
                "function": {
                    "name": macro_name,
                    "description": macro_def.get('description', f'Execute {macro_name} macro workflow'),
                    "parameters": {
                        "type": "object",
                        "properties": self._get_macro_parameters(macro_def),
                        "required": self._get_required_parameters(macro_def)
                    }
                }
            }
            tools.append(tool_schema)
        
        return tools
    
    def _get_macro_parameters(self, macro_def: Dict[str, Any]) -> Dict[str, Any]:
        """Extract parameters schema from macro definition"""
        parameters = {
            "files": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Files to process with this macro"
            },
            "context": {
                "type": "object", 
                "description": "Additional context for macro execution"
            }
        }
        
        # Add macro-specific parameters
        expected_inputs = macro_def.get('expected_inputs', [])
        for input_type in expected_inputs:
            if input_type not in parameters:
                parameters[input_type] = {
                    "type": "string",
                    "description": f"Input of type {input_type}"
                }
        
        return parameters
    
    def _get_required_parameters(self, macro_def: Dict[str, Any]) -> List[str]:
        """Get required parameters for macro"""
        expected_inputs = macro_def.get('expected_inputs', [])
        required = []
        
        # Files are typically required for document macros
        if any('document' in inp for inp in expected_inputs):
            required.append('files')
            
        return required
    
    async def execute_tool_call(self, tool_name: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute macro as MCP tool call
        
        Args:
            tool_name: Name of macro to execute
            parameters: Tool call parameters
            
        Returns:
            MCP tool response with results
        """
        
        try:
            # Validate tool exists
            macro_def = self.registry.get_macro(tool_name)
            if not macro_def:
                return {
                    "error": f"Unknown macro: {tool_name}",
                    "type": "tool_error"
                }
            
            # Create execution from parameters
            user_prompt = f"Execute [{tool_name}] with parameters: {json.dumps(parameters)}"
            executions = self.processor.process_prompt(f"[{tool_name}]")
            
            if not executions:
                return {
                    "error": f"Failed to create execution for {tool_name}",
                    "type": "execution_error"
                }
            
            execution = executions[0]
            
            # Add files to context if provided
            if 'files' in parameters:
                # This would need to be handled by the execution context
                execution.metadata = execution.metadata or {}
                execution.metadata['files'] = parameters['files']
            
            # Execute the macro
            result = await self.engine.execute_macro(execution)
            
            # Format as MCP response
            if result.is_successful():
                return {
                    "type": "tool_result",
                    "content": [
                        {
                            "type": "text",
                            "text": str(result.primary_output)
                        }
                    ],
                    "metadata": {
                        "execution_id": result.execution_id,
                        "duration_seconds": result.duration_seconds,
                        "steps_completed": result.steps_completed,
                        "health_score": result.health_score,
                        "generated_files": result.generated_files
                    }
                }
            else:
                return {
                    "error": f"Macro execution failed: {result.success_message}",
                    "type": "execution_error",
                    "metadata": {
                        "execution_id": result.execution_id,
                        "safety_issues": result.safety_issues
                    }
                }
                
        except Exception as e:
            logger.error(f"MCP tool call failed: {e}")
            return {
                "error": f"Tool execution error: {str(e)}",
                "type": "system_error"
            }
    
    def get_tool_help(self, tool_name: str) -> Dict[str, Any]:
        """
        Get detailed help for a specific tool (like --help)
        
        Returns comprehensive help including workflow steps, parameters,
        examples, and expected behavior.
        """
        macro_def = self.registry.get_macro(tool_name)
        if not macro_def:
            return {"error": f"Tool '{tool_name}' not found"}
        
        steps = macro_def.get('workflow_steps', [])
        
        return {
            "tool_name": tool_name,
            "description": macro_def.get('description', ''),
            "workflow_steps": len(steps),
            "step_details": [
                {
                    "step": i + 1,
                    "name": step.get('name', ''),
                    "description": step.get('human_description', step.get('description', '')),
                    "operation": step.get('operation', '')
                }
                for i, step in enumerate(steps)
            ],
            "parameters": {
                "required": self._get_required_parameters(macro_def),
                "optional": [p for p in self._get_macro_parameters(macro_def).keys() 
                           if p not in self._get_required_parameters(macro_def)],
                "details": self._get_macro_parameters(macro_def)
            },
            "expected_inputs": macro_def.get('expected_inputs', []),
            "expected_outputs": macro_def.get('expected_outputs', []),
            "safety_checks": macro_def.get('health_checks', []),
            "example_usage": {
                "human_interface": f"Please [{tool_name}] to process your documents",
                "mcp_interface": {
                    "type": "function",
                    "function": {
                        "name": tool_name,
                        "parameters": {
                            "files": ["document1.pdf", "document2.pdf"],
                            "context": {"analysis_type": "comprehensive"}
                        }
                    }
                }
            }
        }
    
    def list_available_tools(self) -> Dict[str, Any]:
        """List all available tools with brief descriptions (like ls or help command)"""
        tools_summary = {}
        
        for macro_name, macro_def in self.registry.macros.items():
            description = macro_def.get('description', f'Execute {macro_name} workflow')
            steps_count = len(macro_def.get('workflow_steps', []))
            
            # Categorize
            category = "General"
            if 'document' in macro_name or 'analyze' in macro_name:
                category = "Document Analysis"
            elif 'report' in macro_name or 'summary' in macro_name:
                category = "Report Generation"
            elif 'research' in macro_name or 'literature' in macro_name:
                category = "Research Pipeline"
            elif 'compliance' in macro_name or 'qa' in macro_name:
                category = "Quality Assurance"
            
            if category not in tools_summary:
                tools_summary[category] = []
            
            tools_summary[category].append({
                "name": macro_name,
                "description": description[:80] + "..." if len(description) > 80 else description,
                "steps": steps_count,
                "complexity": "Simple" if steps_count <= 3 else "Moderate" if steps_count <= 6 else "Complex"
            })
        
        return {
            "total_tools": len(self.registry.macros),
            "categories": tools_summary,
            "help_command": f"Use get_tool_help('<tool_name>') for detailed information about any tool"
        }

    def get_mcp_manifest(self) -> Dict[str, Any]:
        """Generate MCP server manifest with comprehensive help"""
        return {
            "name": "tidyllm-macros",
            "version": "1.0.0", 
            "description": "TidyLLM Macros as MCP tools - Transparent, monitored workflows with AHA safety",
            "tools": self.get_available_tools(),
            "capabilities": {
                "tools": True,
                "resources": False,
                "prompts": False,
                "help": True  # We provide comprehensive help
            },
            "help_methods": {
                "list_tools": "list_available_tools() - Show all available tools by category",
                "tool_help": "get_tool_help('<tool_name>') - Detailed help for specific tool",
                "manifest": "get_mcp_manifest() - This comprehensive server information"
            },
            "metadata": {
                "author": "TidyLLM Team",
                "license": "MIT",
                "categories": ["document-analysis", "report-generation", "workflow-automation", "research-pipeline"],
                "features": [
                    "Dual interface (human [macro] + MCP calls)",
                    "AHA safety monitoring", 
                    "Step-by-step transparency",
                    "Sparse agreements integration",
                    "Comprehensive help system"
                ]
            }
        }

def create_mcp_server(registry: MacroRegistry = None) -> MacroMCPServer:
    """Create MCP server for macros"""
    from .macros import populate_default_macros
    
    if registry is None:
        registry = MacroRegistry()
        populate_default_macros(registry)
    
    server = MacroMCPServer(registry)
    logger.info(f"Created MCP server with {len(registry.macros)} available tools")
    
    return server

# Example MCP integration usage
async def demo_mcp_integration():
    """Demonstrate MCP integration"""
    
    server = create_mcp_server()
    
    # Get available tools (what LLM sees)
    tools = server.get_available_tools()
    print("Available MCP Tools:")
    for tool in tools[:3]:  # Show first 3
        print(f"  - {tool['function']['name']}: {tool['function']['description']}")
    
    # Simulate LLM calling a tool
    tool_call = {
        "name": "analyze_two_documents",
        "parameters": {
            "files": ["document1.pdf", "document2.pdf"],
            "context": {"analysis_type": "comparative"}
        }
    }
    
    print(f"\nSimulating LLM tool call: {tool_call['name']}")
    result = await server.execute_tool_call(tool_call['name'], tool_call['parameters'])
    print(f"MCP Response: {result.get('type', 'unknown')}")

if __name__ == "__main__":
    import asyncio
    asyncio.run(demo_mcp_integration())

__all__ = [
    'MacroMCPServer',
    'create_mcp_server'
]