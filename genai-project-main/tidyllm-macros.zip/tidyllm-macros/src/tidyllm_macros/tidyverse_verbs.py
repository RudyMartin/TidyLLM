#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Tidyverse-Style Verbs for Macro Workflows

Real tidyverse-style data manipulation using pipe operator (|) for LLM data types.
Like R's dplyr verbs (filter, select, mutate, summarise, arrange) but for:
- Documents, PDFs, Images
- LLM responses and embeddings  
- Research papers and citations
- Analysis results and reports

Examples:
    documents | filter(file_type="pdf") | load.auto() | summarise(method="key_points")
    papers | arrange(by="citation_count") | select("title", "abstract") | mutate(ai_summary=chat())
    attachments | filter(size_mb < 10) | reshape(format="markdown") | chat(claude())
"""

from typing import Union, List, Dict, Any, Optional, Callable, Iterator
from dataclasses import dataclass
from datetime import datetime
import pandas as pd

# Import base types
try:
    from ..mcp.workers.pdf_processing_worker import PDFProcessingWorker
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

try:
    from tidyllm import attach, chat, claude, load, present
    LLMDATA_AVAILABLE = True
except ImportError:
    LLMDATA_AVAILABLE = False

@dataclass
class TidyData:
    """Base class for tidy data collections that support pipe operations"""
    data: Any
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
    
    def __or__(self, verb_func: Callable) -> 'TidyData':
        """Support pipe operator |"""
        return verb_func(self)

@dataclass 
class DocumentCollection(TidyData):
    """Collection of documents supporting tidyverse operations"""
    data: List[Dict[str, Any]] = None
    
    def __post_init__(self):
        super().__post_init__()
        if self.data is None:
            self.data = []

@dataclass
class PaperCollection(TidyData):
    """Collection of research papers"""
    data: List[Dict[str, Any]] = None
    
@dataclass
class AnalysisCollection(TidyData):
    """Collection of analysis results"""  
    data: List[Dict[str, Any]] = None

@dataclass
class ResponseCollection(TidyData):
    """Collection of LLM responses"""
    data: List[Dict[str, Any]] = None

# =============================================================================
# TIDYVERSE VERBS - Core Data Manipulation
# =============================================================================

class filter:
    """Filter rows/items based on conditions - like dplyr::filter()"""
    
    def __init__(self, condition: Union[str, Callable, dict] = None, **kwargs):
        self.condition = condition
        self.filters = kwargs
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Apply filter to tidy data collection"""
        if not tidy_data.data:
            return tidy_data
            
        filtered_data = []
        
        for item in tidy_data.data:
            if self._matches_filters(item):
                filtered_data.append(item)
        
        # Return same type with filtered data
        result = type(tidy_data)(data=filtered_data, metadata=tidy_data.metadata.copy())
        result.metadata['filter_applied'] = self.filters or str(self.condition)
        result.metadata['original_count'] = len(tidy_data.data)
        result.metadata['filtered_count'] = len(filtered_data)
        
        return result
    
    def _matches_filters(self, item: Dict[str, Any]) -> bool:
        """Check if item matches filter conditions"""
        
        # Custom condition function
        if callable(self.condition):
            return self.condition(item)
        
        # Keyword filters
        for key, expected_value in self.filters.items():
            if key not in item:
                return False
                
            actual_value = item[key]
            
            # Handle different comparison types
            if isinstance(expected_value, str):
                if expected_value not in str(actual_value):
                    return False
            elif isinstance(expected_value, (int, float)):
                if actual_value != expected_value:
                    return False
            elif isinstance(expected_value, list):
                if actual_value not in expected_value:
                    return False
        
        return True

class select:
    """Select specific columns/fields - like dplyr::select()"""
    
    def __init__(self, *columns):
        self.columns = columns
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Select specified columns from data"""
        if not tidy_data.data:
            return tidy_data
            
        selected_data = []
        
        for item in tidy_data.data:
            selected_item = {}
            for col in self.columns:
                if col in item:
                    selected_item[col] = item[col]
            selected_data.append(selected_item)
        
        result = type(tidy_data)(data=selected_data, metadata=tidy_data.metadata.copy())
        result.metadata['selected_columns'] = self.columns
        
        return result

class mutate:
    """Add new columns/fields - like dplyr::mutate()"""
    
    def __init__(self, **new_columns):
        self.new_columns = new_columns
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Add new columns to data"""
        if not tidy_data.data:
            return tidy_data
            
        mutated_data = []
        
        for item in tidy_data.data:
            new_item = item.copy()
            
            for col_name, col_func in self.new_columns.items():
                if callable(col_func):
                    new_item[col_name] = col_func(item)
                else:
                    new_item[col_name] = col_func
                    
            mutated_data.append(new_item)
        
        result = type(tidy_data)(data=mutated_data, metadata=tidy_data.metadata.copy()) 
        result.metadata['added_columns'] = list(self.new_columns.keys())
        
        return result

class arrange:
    """Sort/order data - like dplyr::arrange()"""
    
    def __init__(self, by: Union[str, List[str]], ascending: bool = True):
        self.by = [by] if isinstance(by, str) else by
        self.ascending = ascending
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Sort data by specified columns"""
        if not tidy_data.data:
            return tidy_data
        
        # Sort by multiple keys
        sorted_data = sorted(
            tidy_data.data,
            key=lambda item: [item.get(col, 0) for col in self.by],
            reverse=not self.ascending
        )
        
        result = type(tidy_data)(data=sorted_data, metadata=tidy_data.metadata.copy())
        result.metadata['sorted_by'] = self.by
        result.metadata['ascending'] = self.ascending
        
        return result

class summarise:
    """Summarize/aggregate data - like dplyr::summarise()"""
    
    def __init__(self, method: str = "count", **agg_functions):
        self.method = method
        self.agg_functions = agg_functions
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Summarize the data collection"""
        if not tidy_data.data:
            return tidy_data
        
        summary_data = []
        
        if self.method == "count":
            summary_data = [{"total_items": len(tidy_data.data)}]
        
        elif self.method == "key_points":
            # Extract key information from each item
            for item in tidy_data.data:
                key_info = {}
                # Extract meaningful fields
                for key, value in item.items():
                    if key in ['title', 'name', 'filename', 'summary', 'content']:
                        key_info[key] = value
                if key_info:
                    summary_data.append(key_info)
        
        elif self.method == "group_by":
            # Group by field and count
            group_field = self.agg_functions.get('group_by', 'type')
            groups = {}
            for item in tidy_data.data:
                group_value = item.get(group_field, 'unknown')
                groups[group_value] = groups.get(group_value, 0) + 1
            
            summary_data = [{"group": k, "count": v} for k, v in groups.items()]
        
        result = type(tidy_data)(data=summary_data, metadata=tidy_data.metadata.copy())
        result.metadata['summarise_method'] = self.method
        result.metadata['original_count'] = len(tidy_data.data)
        result.metadata['summary_count'] = len(summary_data)
        
        return result

# =============================================================================
# LLM-SPECIFIC VERBS - Custom for TidyLLM
# =============================================================================

class reshape:
    """Reshape/transform data format - custom LLM verb"""
    
    def __init__(self, format: str = "markdown", **options):
        self.format = format
        self.options = options
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Reshape data into different format"""
        if not tidy_data.data:
            return tidy_data
        
        reshaped_data = []
        
        for item in tidy_data.data:
            if self.format == "markdown":
                reshaped_item = self._to_markdown(item)
            elif self.format == "json":
                reshaped_item = {"json_content": json.dumps(item, indent=2)}
            elif self.format == "summary":
                reshaped_item = self._to_summary(item)
            else:
                reshaped_item = item
            
            reshaped_data.append(reshaped_item)
        
        result = type(tidy_data)(data=reshaped_data, metadata=tidy_data.metadata.copy())
        result.metadata['reshaped_format'] = self.format
        
        return result
    
    def _to_markdown(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert item to markdown format"""
        md_content = []
        
        # Title/name
        if 'title' in item:
            md_content.append(f"# {item['title']}")
        elif 'name' in item:
            md_content.append(f"# {item['name']}")
        elif 'filename' in item:
            md_content.append(f"# {item['filename']}")
        
        # Content sections
        for key, value in item.items():
            if key not in ['title', 'name', 'filename']:
                md_content.append(f"## {key.replace('_', ' ').title()}")
                md_content.append(str(value))
                md_content.append("")
        
        return {"markdown_content": "\n".join(md_content)}
    
    def _to_summary(self, item: Dict[str, Any]) -> Dict[str, Any]:
        """Convert item to summary format"""
        summary_fields = ['title', 'name', 'filename', 'summary', 'abstract', 'description']
        summary_data = {}
        
        for field in summary_fields:
            if field in item:
                summary_data[field] = item[field]
        
        return summary_data

class extract:
    """Extract specific information - custom LLM verb"""
    
    def __init__(self, target: str = "content", method: str = "auto"):
        self.target = target
        self.method = method
    
    def __call__(self, tidy_data: TidyData) -> TidyData:
        """Extract information from data"""
        if not tidy_data.data:
            return tidy_data
        
        extracted_data = []
        
        for item in tidy_data.data:
            extracted_item = {}
            
            if self.target == "content" and PDF_AVAILABLE:
                # Extract text content from PDFs
                if item.get('file_type') == 'pdf':
                    # Would use PDF worker here
                    extracted_item['extracted_content'] = "PDF content would be extracted here"
                else:
                    extracted_item['extracted_content'] = item.get('content', '')
            
            elif self.target == "metadata":
                # Extract just metadata
                metadata_fields = ['title', 'author', 'date', 'size', 'type', 'filename']
                for field in metadata_fields:
                    if field in item:
                        extracted_item[field] = item[field]
            
            else:
                # Extract specific field
                if self.target in item:
                    extracted_item[self.target] = item[self.target]
            
            extracted_data.append(extracted_item)
        
        result = type(tidy_data)(data=extracted_data, metadata=tidy_data.metadata.copy())
        result.metadata['extracted_target'] = self.target
        result.metadata['extraction_method'] = self.method
        
        return result

# =============================================================================
# LLM INTEGRATION VERBS
# =============================================================================

class llm_chat:
    """Send data to LLM for processing - integrates with chat()"""
    
    def __init__(self, prompt: str = None, provider: str = "claude", model: str = None):
        self.prompt = prompt
        self.provider = provider
        self.model = model
    
    def __call__(self, tidy_data: TidyData) -> ResponseCollection:
        """Send tidy data to LLM for processing"""
        
        # Prepare content for LLM
        content_parts = []
        
        if self.prompt:
            content_parts.append(self.prompt)
        
        # Add data content
        content_parts.append("Data to analyze:")
        for i, item in enumerate(tidy_data.data, 1):
            content_parts.append(f"\n{i}. {item}")
        
        full_prompt = "\n".join(content_parts)
        
        # Create response (would integrate with actual LLM)
        response_data = [{
            "prompt": full_prompt,
            "provider": self.provider,
            "model": self.model,
            "response": f"LLM analysis of {len(tidy_data.data)} items would go here",
            "timestamp": datetime.now().isoformat(),
            "input_metadata": tidy_data.metadata
        }]
        
        return ResponseCollection(data=response_data)

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def collect(tidy_data: TidyData) -> List[Dict[str, Any]]:
    """Collect results into Python list - like R's collect()"""
    return tidy_data.data

def print_data(tidy_data: TidyData) -> TidyData:
    """Print data for debugging - like R's print()"""
    print(f"\n{type(tidy_data).__name__} with {len(tidy_data.data)} items:")
    print(f"Metadata: {tidy_data.metadata}")
    
    for i, item in enumerate(tidy_data.data[:5], 1):  # Show first 5
        print(f"  {i}. {item}")
    
    if len(tidy_data.data) > 5:
        print(f"  ... and {len(tidy_data.data) - 5} more items")
    
    return tidy_data

# =============================================================================
# DEMO EXAMPLES
# =============================================================================

def demo_tidyverse_style():
    """Demonstrate tidyverse-style operations"""
    
    print("🎯 TIDYVERSE-STYLE LLM DATA MANIPULATION")
    print("=" * 60)
    
    # Create sample document collection
    docs = DocumentCollection(data=[
        {"filename": "report1.pdf", "size_mb": 2.5, "file_type": "pdf", "title": "Q1 Analysis"},
        {"filename": "report2.pdf", "size_mb": 15.2, "file_type": "pdf", "title": "Annual Report"}, 
        {"filename": "summary.docx", "size_mb": 0.8, "file_type": "docx", "title": "Executive Summary"},
        {"filename": "data.csv", "size_mb": 0.1, "file_type": "csv", "title": "Raw Data"},
        {"filename": "huge_file.pdf", "size_mb": 50.0, "file_type": "pdf", "title": "Complete Dataset"}
    ])
    
    print("📊 Original Documents:")
    docs | print_data
    
    print("\n🔍 TIDYVERSE PIPELINE:")
    print("docs | filter(file_type='pdf', size_mb < 10) | select('title', 'filename') | arrange('size_mb')")
    
    # Classic tidyverse pipeline
    result = (docs 
              | filter(file_type="pdf", size_mb=lambda size: size < 10)
              | select("title", "filename", "size_mb")
              | arrange("size_mb"))
    
    result | print_data
    
    print("\n📝 RESHAPE TO MARKDOWN:")
    print("result | reshape(format='markdown')")
    
    markdown_result = result | reshape(format="markdown")
    markdown_result | print_data
    
    print("\n📈 SUMMARISE DATA:")
    print("docs | summarise(method='group_by', group_by='file_type')")
    
    summary = docs | summarise(method="group_by", group_by="file_type")
    summary | print_data

if __name__ == "__main__":
    demo_tidyverse_style()