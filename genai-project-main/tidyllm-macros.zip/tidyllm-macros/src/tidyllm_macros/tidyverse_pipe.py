#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Native R Pipe Operator | Implementation

Uses R 4.1.0+ native pipe syntax | for TidyLLM workflows.
Pure Python implementation - NO PANDAS, NO NUMPY dependencies.

R Tidyverse equivalent:
    data | filter(size < 10) | select(title, filename) | arrange(size)

TidyLLM Python equivalent:
    data | filter(size_mb=lambda x: x < 10) | select("title", "filename") | arrange("size_mb")

Custom | operator implementation using Python operator overloading.
"""

from typing import List, Dict, Any, Callable, Union, Optional
from dataclasses import dataclass
from datetime import datetime
import json
import operator

class PipeOperator:
    """Custom | pipe operator for R-style data flow"""
    
    def __init__(self, data):
        self.data = data
    
    def __or__(self, func: Callable) -> 'PipeOperator':
        """Override | to create | pipe behavior"""
        # Apply function to data and return new PipeOperator
        result = func(self.data)
        return PipeOperator(result)
    
    def __rshift__(self, func: Callable) -> 'PipeOperator':
        """Alternative >> operator for piping"""
        result = func(self.data) 
        return PipeOperator(result)
    
    def collect(self):
        """Extract final result - like R's collect()"""
        return self.data

def pipe(data) -> PipeOperator:
    """Start a pipe chain - creates | operator"""
    return PipeOperator(data)

# Monkey patch any object to support | 
def add_pipe_support(cls):
    """Add | pipe support to any class"""
    def __or__(self, func):
        return PipeOperator(func(self))
    
    def __rshift__(self, func):  
        return PipeOperator(func(self))
    
    cls.__or__ = __or__
    cls.__rshift__ = __rshift__
    return cls

@add_pipe_support
@dataclass
class TidyData:
    """Base tidy data with native | pipe support"""
    data: List[Dict[str, Any]]
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.data is None:
            self.data = []

@add_pipe_support  
@dataclass
class DocumentCollection(TidyData):
    """Document collection with | pipe support"""
    pass

@add_pipe_support
@dataclass
class PaperCollection(TidyData):
    """Research papers with | pipe support"""
    pass

@add_pipe_support
@dataclass  
class ResponseCollection(TidyData):
    """LLM responses with | pipe support"""
    pass

@add_pipe_support
@dataclass
class AnalysisCollection(TidyData):
    """Analysis results with | pipe support"""
    pass

# =============================================================================
# R TIDYVERSE VERBS - Native | Pipe Style
# =============================================================================

def filter(**conditions) -> Callable:
    """
    R-style filter() verb
    
    R: data | filter(size < 10, type == "pdf")
    Python: data | filter(size_mb=lambda x: x < 10, file_type="pdf")
    """
    def _filter_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda filtered: type(tidy_data)(
                data=filtered, 
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda filtered: filtered
        
        filtered_items = []
        
        for item in items:
            keep_item = True
            
            for field, condition in conditions.items():
                if field not in item:
                    keep_item = False
                    break
                
                value = item[field]
                
                if callable(condition):
                    if not condition(value):
                        keep_item = False
                        break
                elif value != condition:
                    keep_item = False  
                    break
            
            if keep_item:
                filtered_items.append(item)
        
        return create_result(filtered_items)
    
    return _filter_func

def select(*fields) -> Callable:
    """
    R-style select() verb
    
    R: data | select(title, filename, size)  
    Python: data | select("title", "filename", "size_mb")
    """
    def _select_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda selected: type(tidy_data)(
                data=selected,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda selected: selected
        
        selected_items = []
        
        for item in items:
            selected_item = {}
            for field in fields:
                if field in item:
                    selected_item[field] = item[field]
            selected_items.append(selected_item)
        
        return create_result(selected_items)
    
    return _select_func

def mutate(**new_fields) -> Callable:
    """
    R-style mutate() verb
    
    R: data | mutate(size_gb = size_mb / 1024)
    Python: data | mutate(size_gb=lambda x: x['size_mb'] / 1024)
    """
    def _mutate_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda mutated: type(tidy_data)(
                data=mutated,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda mutated: mutated
        
        mutated_items = []
        
        for item in items:
            new_item = item.copy()
            
            for field_name, field_func in new_fields.items():
                if callable(field_func):
                    new_item[field_name] = field_func(item)
                else:
                    new_item[field_name] = field_func
            
            mutated_items.append(new_item)
        
        return create_result(mutated_items)
    
    return _mutate_func

def arrange(*sort_fields, desc: bool = False) -> Callable:
    """
    R-style arrange() verb
    
    R: data | arrange(size, desc(year))
    Python: data | arrange("size_mb", "year", desc=True)
    """
    def _arrange_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda sorted_items: type(tidy_data)(
                data=sorted_items,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda sorted_items: sorted_items
        
        def sort_key(item):
            return [item.get(field, 0) for field in sort_fields]
        
        sorted_items = sorted(items, key=sort_key, reverse=desc)
        
        return create_result(sorted_items)
    
    return _arrange_func

def summarise(method: str = "count", **kwargs) -> Callable:
    """
    R-style summarise() verb
    
    R: data | group_by(type) | summarise(count = n())
    Python: data | summarise("group_by", group_field="file_type")
    """
    def _summarise_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda summary: type(tidy_data)(
                data=summary,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda summary: summary
        
        if method == "count":
            summary_data = [{"n": len(items)}]
        
        elif method == "group_by":
            group_field = kwargs.get("group_field", "type")
            groups = {}
            for item in items:
                group_value = item.get(group_field, "unknown")
                groups[group_value] = groups.get(group_value, 0) + 1
            
            summary_data = [{"group": k, "n": v} for k, v in groups.items()]
        
        elif method == "stats":
            field = kwargs.get("field", "value")
            values = [item.get(field, 0) for item in items if field in item and isinstance(item.get(field), (int, float))]
            
            if values:
                summary_data = [{
                    "field": field,
                    "n": len(values),
                    "min": min(values),
                    "max": max(values), 
                    "mean": sum(values) / len(values),
                    "sum": sum(values)
                }]
            else:
                summary_data = [{"field": field, "n": 0}]
        
        else:
            summary_data = [{"method": method, "n": len(items)}]
        
        return create_result(summary_data)
    
    return _summarise_func

# =============================================================================
# TIDYLLM CUSTOM VERBS
# =============================================================================

def reshape(format: str = "markdown") -> Callable:
    """
    TidyLLM custom reshape() verb for data transformation
    
    Usage: data | reshape("markdown") | reshape("json")
    """
    def _reshape_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda reshaped: type(tidy_data)(
                data=reshaped,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda reshaped: reshaped
        
        reshaped_items = []
        
        for item in items:
            if format == "markdown":
                md_parts = []
                
                # Title
                title_fields = ['title', 'name', 'filename']
                for field in title_fields:
                    if field in item:
                        md_parts.append(f"# {item[field]}")
                        break
                
                # Content  
                for key, value in item.items():
                    if key not in title_fields:
                        md_parts.append(f"## {key.replace('_', ' ').title()}")
                        md_parts.append(str(value))
                        md_parts.append("")
                
                reshaped_items.append({"content": "\n".join(md_parts)})
            
            elif format == "json":
                reshaped_items.append({"json": json.dumps(item, indent=2)})
            
            else:
                reshaped_items.append(item)
        
        return create_result(reshaped_items)
    
    return _reshape_func

def extract(target: str) -> Callable:
    """
    TidyLLM custom extract() verb
    
    Usage: data | extract("content") | extract("metadata")
    """
    def _extract_func(tidy_data):
        if hasattr(tidy_data, 'data'):
            items = tidy_data.data
            create_result = lambda extracted: type(tidy_data)(
                data=extracted,
                metadata=getattr(tidy_data, 'metadata', {})
            )
        else:
            items = tidy_data
            create_result = lambda extracted: extracted
        
        extracted_items = []
        
        for item in items:
            if target in item:
                extracted_items.append({target: item[target]})
            else:
                extracted_items.append({target: None})
        
        return create_result(extracted_items)
    
    return _extract_func

# =============================================================================
# UTILITY FUNCTIONS  
# =============================================================================

def glimpse(tidy_data):
    """Show data structure - like R's glimpse()"""
    # Handle PipeOperator results
    if isinstance(tidy_data, PipeOperator):
        actual_data = tidy_data.data
    else:
        actual_data = tidy_data
    
    if hasattr(actual_data, 'data'):
        items = actual_data.data
        print(f"{type(actual_data).__name__}: {len(items)} observations")
        if hasattr(actual_data, 'metadata'):
            print(f"Metadata: {actual_data.metadata}")
    else:
        items = actual_data
        print(f"List: {len(items)} items")
    
    if items:
        print("\nVariables:")
        all_fields = set()
        for item in items:
            if isinstance(item, dict):
                all_fields.update(item.keys())
        
        for field in sorted(all_fields):
            sample_values = []
            for item in items[:3]:
                if isinstance(item, dict) and field in item:
                    sample_values.append(str(item[field]))
            
            print(f"  {field}: {', '.join(sample_values[:3])}")
    
    return tidy_data

# =============================================================================
# DEMO
# =============================================================================

def demo_native_r_pipe():
    """Demonstrate native R | pipe operator"""
    
    print("🎯 NATIVE R PIPE OPERATOR | IN PYTHON")
    print("=" * 50)
    print("Using R 4.1.0+ native pipe syntax")
    print()
    
    # Sample data
    docs = DocumentCollection(data=[
        {"filename": "report1.pdf", "size_mb": 2.5, "file_type": "pdf", "title": "Q1 Report", "year": 2023},
        {"filename": "analysis.pdf", "size_mb": 8.3, "file_type": "pdf", "title": "Data Analysis", "year": 2024},
        {"filename": "summary.docx", "size_mb": 0.8, "file_type": "docx", "title": "Executive Summary", "year": 2024},
        {"filename": "data.csv", "size_mb": 0.1, "file_type": "csv", "title": "Raw Data", "year": 2023}
    ])
    
    print("📊 Original data:")
    glimpse(docs)
    
    print("\n🔗 R NATIVE PIPE CHAIN:")
    print("docs | filter(file_type='pdf') | filter(size_mb < 10) | select('title', 'size_mb') | arrange('size_mb')")
    print()
    
    # Native R-style pipe chain (using | since Python doesn't support |)
    result = (docs 
              | filter(file_type="pdf")
              | filter(size_mb=lambda x: x < 10) 
              | select("title", "filename", "size_mb")
              | arrange("size_mb"))
    
    glimpse(result)
    
    print("\n📈 ADD COMPUTED FIELD:")
    print("result | mutate(size_category=lambda x: 'small' if x['size_mb'] < 5 else 'medium')")
    print()
    
    enhanced = (result 
                | mutate(size_category=lambda x: "small" if x["size_mb"] < 5 else "medium"))
    
    glimpse(enhanced)
    
    print("\n📊 SUMMARISE:")
    print("docs | summarise('group_by', group_field='file_type')")
    print()
    
    summary = docs | summarise("group_by", group_field="file_type")
    glimpse(summary)
    
    print("\n📝 RESHAPE:")  
    print("result | reshape('markdown')")
    print()
    
    markdown = result | reshape("markdown")
    # Handle PipeOperator result
    if isinstance(markdown, PipeOperator):
        markdown_data = markdown.data
    else:
        markdown_data = markdown
    
    if hasattr(markdown_data, 'data') and markdown_data.data:
        print("Sample markdown:")
        print(markdown_data.data[0]["content"][:150] + "...")
    
    print(f"\n✨ SUCCESS: Native R | pipe working in Python!")
    print("✅ Pure Python - no external dependencies")
    print("✅ R 4.1.0+ native pipe syntax")
    print("✅ Full tidyverse verbs: filter, select, mutate, arrange, summarise")
    print("✅ Custom TidyLLM verbs: reshape, extract")

if __name__ == "__main__":
    demo_native_r_pipe()