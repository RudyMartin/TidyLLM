#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Macros System

Combines Sparse Agreements with AHA monitoring to create transparent, 
monitored, tidyverse-style workflows that humans can see and understand.

Features:
- [macro] syntax in prompts that triggers TidyLLM workflows
- AHA system monitoring for safety and health awareness
- Human-readable workflow execution with step-by-step visibility
- Dynamic macro expansion based on sparse agreements
- Report pipeline automation without hardcoded flows
- Dual interface: Human-friendly [macro] syntax AND MCP function calls

🎯 DUAL INTERFACE ARCHITECTURE:

Human Interface:
    prompt = "Please [analyze_two_documents] to create a comprehensive report"
    
    # This expands to:
    # 1. Load documents -> attach() | load.auto() 
    # 2. Extract content -> analyze.content()
    # 3. Compare findings -> chat(claude("Compare these documents"))  
    # 4. Generate report -> generate_report()
    # 5. Export results -> save_to_file()
    
    # All monitored by AHA for health and safety

MCP Interface (for LLMs):
    {
        "type": "function",
        "function": {
            "name": "analyze_two_documents", 
            "parameters": {
                "files": ["doc1.pdf", "doc2.pdf"],
                "context": {"analysis_type": "comprehensive"}
            }
        }
    }
    
    # Same workflow, structured for LLM tool calls

🎯 R-STYLE TIDYVERSE PIPES - NO EXTERNAL DEPENDENCIES:

TidyLLM Macros includes pure Python implementation of R 4.1.0+ native pipe syntax.
Perfect for data scientists who already know tidyverse but need LLM-specific operations.

    from backend.macros import DocumentCollection, filter, select, arrange, mutate

    # R-style pipes for LLM data (pure Python, no pandas/numpy!)
    documents | filter(size_mb < 10) | select("title", "content") | arrange("size_mb")
    papers | filter(year > 2020) | mutate(ai_summary=chat()) | summarise()
    responses | arrange("timestamp") | reshape("markdown") | glimpse()

KEY ADVANTAGES OVER ALTERNATIVES:
✅ Zero learning curve - uses exact R tidyverse syntax data scientists know
✅ Pure Python - no external dependencies, no pandas/numpy karma issues
✅ LLM-native - custom verbs for documents, papers, responses, analysis
✅ Current with R 4.1.0+ standards - not outdated %>% approach  
✅ Extensible - easy to add domain-specific verbs like reshape(), extract()
✅ Readable - complex workflows read like stories: filter → select → mutate → arrange

Why not method chaining (.filter().select())? Less familiar to R users.
Why not external libraries (dfply, siuba)? Dependencies and pandas requirements.
Why not pandas pipes? Requires pandas and not designed for LLM data types.

*See [Why R-Style Pipes](docs/WHY_R_STYLE_PIPES.md) for detailed comparison.*

🆘 HELP SYSTEM - BETTER THAN TRADITIONAL APIs:

Unlike traditional APIs that require memorizing parameters and endpoints,
TidyLLM Macros MCP integration provides:

    server = create_mcp_server()
    
    # 📋 LIST ALL TOOLS (like "ls" or "help")
    tools = server.list_available_tools()
    # Returns categorized tools with complexity indicators:
    # 📂 Document Analysis:
    #   🟡 analyze_two_documents (6 steps) - Comprehensive analysis...
    #   🟢 quick_summary (3 steps) - Generate quick summary...
    
    # 🔧 DETAILED HELP (like "man page") 
    help_info = server.get_tool_help("analyze_two_documents")
    # Returns step-by-step breakdown, parameters, examples, I/O specs
    
    # 📜 COMPLETE SERVER INFO
    manifest = server.get_mcp_manifest()
    # Returns capabilities, categories, help methods

KEY BENEFITS OVER TRADITIONAL APIs:
✅ No parameter memorization - help tells you exactly what's needed
✅ Visual complexity indicators (🟢 Simple / 🟡 Moderate / 🔴 Complex)  
✅ Step-by-step workflow transparency - see what happens before running
✅ Dual interface examples - both human [macro] and MCP function calls
✅ Smart categorization - find the right tool quickly
✅ Expected I/O specifications - know what goes in, what comes out
✅ Safety information - health checks and monitoring details
✅ Usage examples included - no guesswork needed
"""

__version__ = "0.1.0"
__author__ = "TidyLLM Macros Team"

# Core components
from .core import (
    MacroProcessor,
    MacroRegistry,
    MacroExecution,
    MacroStep,
    MacroResult
)

# Execution engine
from .engine import (
    MacroEngine,
    ExecutionContext,
    StepExecutor
)

# AHA integration
from .monitoring import (
    AHAMacroMonitor, 
    MacroHealthChecker,
    ExecutionSafeguard
)

# Built-in macro definitions
from .macros import (
    document_analysis_macros,
    report_generation_macros,
    research_pipeline_macros,
    quality_assurance_macros
)

# Sparse integration
from .sparse_integration import (
    SparseAgreementLoader,
    MacroExpander
)

# MCP integration - dual interface architecture
from .mcp_integration import (
    MacroMCPServer,
    create_mcp_server
)

# Tidyverse-style pipe operations - R 4.1.0+ native syntax
from .tidyverse_pipe import (
    DocumentCollection,
    PaperCollection, 
    ResponseCollection,
    AnalysisCollection,
    filter, select, mutate, arrange, summarise,
    reshape, extract, glimpse
)

__all__ = [
    # Core
    "MacroProcessor",
    "MacroRegistry", 
    "MacroExecution",
    "MacroStep",
    "MacroResult",
    
    # Engine
    "MacroEngine",
    "ExecutionContext",
    "StepExecutor",
    
    # Monitoring
    "AHAMacroMonitor",
    "MacroHealthChecker", 
    "ExecutionSafeguard",
    
    # Built-in macros
    "document_analysis_macros",
    "report_generation_macros",
    "research_pipeline_macros",
    "quality_assurance_macros",
    
    # Sparse integration
    "SparseAgreementLoader",
    "MacroExpander",
    
    # MCP integration
    "MacroMCPServer",
    "create_mcp_server",
    
    # Tidyverse pipe operations
    "DocumentCollection",
    "PaperCollection",
    "ResponseCollection", 
    "AnalysisCollection",
    "filter", "select", "mutate", "arrange", "summarise",
    "reshape", "extract", "glimpse"
]

# Package info
__package_info__ = {
    "name": "tidyllm-macros",
    "description": "Transparent, monitored, tidyverse-style workflow macros",
    "keywords": ["macros", "workflows", "aha", "sparse", "tidyllm"],
    "dependencies": ["llmdata>=0.1.0", "tidyllm-papers>=0.1.0"],
}

print("🔧 TidyLLM Macros System loaded with AHA monitoring")