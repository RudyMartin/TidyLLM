#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Built-in TidyLLM Macro Definitions

Pre-defined macros for common workflows including the two-document analysis
report pipeline requested by the user.
"""

import logging
from typing import Dict, List, Any
from .core import MacroRegistry

logger = logging.getLogger(__name__)

def register_document_analysis_macros(registry: MacroRegistry):
    """Register document analysis macros"""
    
    # Two-document analysis macro - the main requested feature
    registry.register_macro(
        name="analyze_two_documents",
        description="Comprehensive analysis and comparison of two documents with report generation",
        workflow_steps=[
            {
                'name': 'Attach Documents',
                'description': 'Load the two documents for analysis',
                'operation': 'attach',
                'parameters': {
                    'files': []  # Will be populated from context
                },
                'expected_output': 'AttachmentCollection with both documents',
                'human_description': '📎 Loading and attaching your two documents for analysis'
            },
            {
                'name': 'Auto-Load Content',
                'description': 'Automatically detect and load document content',
                'operation': 'load_auto',
                'parameters': {},
                'expected_output': 'Processed attachment collection with extracted content',
                'human_description': '🔍 Extracting text, images, and data from documents'
            },
            {
                'name': 'Format as Markdown',
                'description': 'Format content for structured analysis',
                'operation': 'present_markdown',
                'parameters': {},
                'expected_output': 'Markdown-formatted content ready for analysis',
                'human_description': '📝 Formatting content for better readability'
            },
            {
                'name': 'Compare Documents',
                'description': 'Perform intelligent comparison of the two documents',
                'operation': 'compare_documents',
                'parameters': {
                    'prompt': 'Perform a comprehensive comparison of these two documents. Analyze:\n1. Key similarities and differences\n2. Content structure and organization\n3. Data points and findings\n4. Methodologies or approaches\n5. Conclusions and recommendations\n\nProvide specific examples and actionable insights.'
                },
                'expected_output': 'Detailed comparison analysis',
                'human_description': '🔬 Analyzing similarities, differences, and key insights between documents'
            },
            {
                'name': 'Generate Report',
                'description': 'Create comprehensive analysis report',
                'operation': 'generate_report',
                'parameters': {
                    'title': 'Two-Document Comparative Analysis Report',
                    'template': 'comparative_analysis'
                },
                'expected_output': 'Formatted report document',
                'human_description': '📊 Generating comprehensive comparative analysis report'
            },
            {
                'name': 'Save Report',
                'description': 'Save the final report to file',
                'operation': 'save_file',
                'parameters': {
                    'filename': 'two_document_analysis_report.md',
                    'content': None  # Will be populated from previous step
                },
                'expected_output': 'File path of saved report',
                'human_description': '💾 Saving your analysis report to file'
            }
        ],
        expected_inputs=['document_file_1', 'document_file_2'],
        expected_outputs=['analysis_report', 'comparison_insights'],
        health_checks=['file_size_check', 'content_extraction_check', 'llm_response_check']
    )
    
    # Single document analysis macro
    registry.register_macro(
        name="analyze_document",
        description="Comprehensive analysis of a single document",
        workflow_steps=[
            {
                'name': 'Attach Document',
                'description': 'Load the document for analysis',
                'operation': 'attach',
                'parameters': {'files': []},
                'expected_output': 'AttachmentCollection with document',
                'human_description': '📎 Loading your document for analysis'
            },
            {
                'name': 'Extract Content',
                'description': 'Extract and process document content',
                'operation': 'load_auto',
                'parameters': {},
                'expected_output': 'Processed document content',
                'human_description': '🔍 Extracting and processing document content'
            },
            {
                'name': 'Analyze Content',
                'description': 'Perform deep content analysis',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'model': 'claude-3-5-sonnet'
                },
                'expected_output': 'Content analysis results',
                'human_description': '🧠 Performing intelligent content analysis'
            },
            {
                'name': 'Generate Summary Report',
                'description': 'Create analysis summary report',
                'operation': 'generate_report',
                'parameters': {
                    'title': 'Document Analysis Report',
                    'template': 'single_document_analysis'
                },
                'expected_output': 'Analysis report',
                'human_description': '📋 Creating comprehensive analysis summary'
            }
        ],
        expected_inputs=['document_file'],
        expected_outputs=['analysis_report', 'key_insights'],
        health_checks=['file_size_check', 'content_extraction_check']
    )
    
    # Quick document summary macro
    registry.register_macro(
        name="quick_summary",
        description="Generate quick summary of document(s)",
        workflow_steps=[
            {
                'name': 'Load Documents',
                'description': 'Load and process documents',
                'operation': 'attach',
                'parameters': {'files': []},
                'expected_output': 'Document collection',
                'human_description': '⚡ Quick-loading your documents'
            },
            {
                'name': 'Extract Key Points',
                'description': 'Extract key information quickly',
                'operation': 'load_auto',
                'parameters': {},
                'expected_output': 'Extracted content',
                'human_description': '🎯 Extracting key points and information'
            },
            {
                'name': 'Generate Summary',
                'description': 'Create concise summary',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'prompt': 'Provide a concise summary highlighting the key points, main findings, and important takeaways from these documents.'
                },
                'expected_output': 'Document summary',
                'human_description': '📝 Creating concise summary of key points'
            }
        ],
        expected_inputs=['document_files'],
        expected_outputs=['summary'],
        health_checks=['basic_content_check']
    )

def register_report_generation_macros(registry: MacroRegistry):
    """Register report generation macros"""
    
    # Executive summary macro
    registry.register_macro(
        name="executive_summary",
        description="Generate executive summary from analysis results",
        workflow_steps=[
            {
                'name': 'Gather Analysis Data',
                'description': 'Collect and organize analysis results',
                'operation': 'custom_operation',
                'parameters': {
                    'code': 'gather_analysis_data',
                    'data_sources': ['previous_analysis', 'document_content']
                },
                'expected_output': 'Organized analysis data',
                'human_description': '📊 Gathering and organizing analysis data'
            },
            {
                'name': 'Create Executive Summary',
                'description': 'Generate high-level executive summary',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'prompt': 'Create an executive summary that highlights: 1) Key findings, 2) Strategic implications, 3) Recommended actions, 4) Risk considerations. Keep it concise and actionable for senior leadership.'
                },
                'expected_output': 'Executive summary',
                'human_description': '👔 Creating executive-level summary with strategic insights'
            },
            {
                'name': 'Format Report',
                'description': 'Format as professional report',
                'operation': 'generate_report',
                'parameters': {
                    'title': 'Executive Summary Report',
                    'template': 'executive'
                },
                'expected_output': 'Formatted executive report',
                'human_description': '📄 Formatting as professional executive report'
            }
        ],
        expected_inputs=['analysis_results'],
        expected_outputs=['executive_summary'],
        health_checks=['content_completeness_check']
    )
    
    # Detailed technical report macro
    registry.register_macro(
        name="technical_report",
        description="Generate detailed technical analysis report",
        workflow_steps=[
            {
                'name': 'Technical Analysis',
                'description': 'Perform detailed technical analysis',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'model': 'claude-3-5-sonnet',
                    'prompt': 'Perform a detailed technical analysis covering: 1) Methodology, 2) Data analysis, 3) Technical findings, 4) Limitations, 5) Technical recommendations. Include specific details and technical depth.'
                },
                'expected_output': 'Technical analysis',
                'human_description': '🔬 Performing detailed technical analysis'
            },
            {
                'name': 'Generate Technical Report',
                'description': 'Create comprehensive technical report',
                'operation': 'generate_report',
                'parameters': {
                    'title': 'Technical Analysis Report',
                    'template': 'technical'
                },
                'expected_output': 'Technical report',
                'human_description': '📋 Creating comprehensive technical report'
            }
        ],
        expected_inputs=['raw_data', 'analysis_context'],
        expected_outputs=['technical_report'],
        health_checks=['technical_depth_check']
    )

def register_research_pipeline_macros(registry: MacroRegistry):
    """Register research pipeline macros using TidyLLM-Papers"""
    
    # Research literature review macro
    registry.register_macro(
        name="literature_review",
        description="Comprehensive literature review on a research topic",
        workflow_steps=[
            {
                'name': 'Discover Papers',
                'description': 'Search and discover relevant research papers',
                'operation': 'papers_discover',
                'parameters': {
                    'query': '',  # Will be populated from user input
                    'limit': 15,
                    'type': 'arxiv'
                },
                'expected_output': 'Collection of research papers',
                'human_description': '🔍 Discovering relevant research papers'
            },
            {
                'name': 'Analyze Paper Content',
                'description': 'Analyze abstracts and metadata',
                'operation': 'papers_analyze',
                'parameters': {
                    'type': 'abstracts'
                },
                'expected_output': 'Analyzed paper collection',
                'human_description': '📚 Analyzing paper abstracts and content'
            },
            {
                'name': 'Extract Citations',
                'description': 'Extract and analyze citation networks',
                'operation': 'papers_cite',
                'parameters': {
                    'type': 'extract_references'
                },
                'expected_output': 'Citation analysis',
                'human_description': '🔗 Analyzing citations and references'
            },
            {
                'name': 'Generate Literature Review',
                'description': 'Create comprehensive literature review',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'prompt': 'Based on the research papers analyzed, create a comprehensive literature review that includes: 1) Overview of the field, 2) Key themes and trends, 3) Important findings, 4) Research gaps, 5) Future directions.'
                },
                'expected_output': 'Literature review',
                'human_description': '📖 Creating comprehensive literature review'
            },
            {
                'name': 'Save Literature Review',
                'description': 'Save the literature review report',
                'operation': 'save_file',
                'parameters': {
                    'filename': 'literature_review_report.md',
                    'content': None
                },
                'expected_output': 'Saved literature review file',
                'human_description': '💾 Saving literature review report'
            }
        ],
        expected_inputs=['research_topic'],
        expected_outputs=['literature_review_report', 'paper_analysis'],
        health_checks=['paper_discovery_check', 'analysis_depth_check']
    )
    
    # Research trend analysis macro
    registry.register_macro(
        name="research_trends",
        description="Analyze trends in research literature over time",
        workflow_steps=[
            {
                'name': 'Discover Recent Papers',
                'description': 'Find recent papers in the field',
                'operation': 'papers_discover',
                'parameters': {
                    'query': '',
                    'type': 'recent',
                    'days': 90
                },
                'expected_output': 'Recent paper collection',
                'human_description': '🕒 Finding recent research papers'
            },
            {
                'name': 'Analyze Trends',
                'description': 'Analyze metadata for trends',
                'operation': 'papers_analyze',
                'parameters': {
                    'type': 'metadata'
                },
                'expected_output': 'Trend analysis data',
                'human_description': '📈 Analyzing research trends and patterns'
            },
            {
                'name': 'Generate Trend Report',
                'description': 'Create trend analysis report',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'prompt': 'Analyze the research trends data and create a report covering: 1) Emerging topics, 2) Publication patterns, 3) Author collaboration trends, 4) Institutional contributions, 5) Future predictions.'
                },
                'expected_output': 'Trend analysis report',
                'human_description': '📊 Creating research trend analysis report'
            }
        ],
        expected_inputs=['research_field'],
        expected_outputs=['trend_report', 'trend_data'],
        health_checks=['trend_data_check']
    )

def register_quality_assurance_macros(registry: MacroRegistry):
    """Register QA and compliance macros"""
    
    # Document compliance check macro
    registry.register_macro(
        name="compliance_check",
        description="Check document compliance against standards",
        workflow_steps=[
            {
                'name': 'Load Compliance Standards',
                'description': 'Load relevant compliance standards and criteria',
                'operation': 'load_file',
                'parameters': {
                    'filename': 'dev_configs/qa_criteria_full.yaml'
                },
                'expected_output': 'Compliance criteria',
                'human_description': '📋 Loading compliance standards and criteria'
            },
            {
                'name': 'Analyze Document Compliance',
                'description': 'Check document against compliance criteria',
                'operation': 'chat',
                'parameters': {
                    'provider': 'claude',
                    'prompt': 'Analyze the document for compliance with the loaded criteria. Check for: 1) Required sections, 2) Content completeness, 3) Format compliance, 4) Quality standards, 5) Regulatory requirements.'
                },
                'expected_output': 'Compliance analysis',
                'human_description': '✅ Checking document compliance against standards'
            },
            {
                'name': 'Generate Compliance Report',
                'description': 'Create compliance assessment report',
                'operation': 'generate_report',
                'parameters': {
                    'title': 'Compliance Assessment Report',
                    'template': 'compliance'
                },
                'expected_output': 'Compliance report',
                'human_description': '📊 Creating compliance assessment report'
            }
        ],
        expected_inputs=['document_to_check'],
        expected_outputs=['compliance_report', 'compliance_score'],
        health_checks=['compliance_criteria_check']
    )

# Registry population functions
def get_document_analysis_macros() -> Dict[str, Dict[str, Any]]:
    """Get document analysis macro definitions"""
    registry = MacroRegistry()
    register_document_analysis_macros(registry)
    return registry.macros

def get_report_generation_macros() -> Dict[str, Dict[str, Any]]:
    """Get report generation macro definitions"""
    registry = MacroRegistry()
    register_report_generation_macros(registry)
    return registry.macros

def get_research_pipeline_macros() -> Dict[str, Dict[str, Any]]:
    """Get research pipeline macro definitions"""
    registry = MacroRegistry()
    register_research_pipeline_macros(registry)
    return registry.macros

def get_quality_assurance_macros() -> Dict[str, Dict[str, Any]]:
    """Get QA macro definitions"""
    registry = MacroRegistry()
    register_quality_assurance_macros(registry)
    return registry.macros

def populate_default_macros(registry: MacroRegistry):
    """Populate registry with all default macros"""
    register_document_analysis_macros(registry)
    register_report_generation_macros(registry)
    register_research_pipeline_macros(registry)
    register_quality_assurance_macros(registry)
    
    logger.info(f"Populated registry with {len(registry.macros)} default macros")

# Export individual macro collections
document_analysis_macros = get_document_analysis_macros()
report_generation_macros = get_report_generation_macros()
research_pipeline_macros = get_research_pipeline_macros()
quality_assurance_macros = get_quality_assurance_macros()

__all__ = [
    'document_analysis_macros',
    'report_generation_macros', 
    'research_pipeline_macros',
    'quality_assurance_macros',
    'populate_default_macros'
]