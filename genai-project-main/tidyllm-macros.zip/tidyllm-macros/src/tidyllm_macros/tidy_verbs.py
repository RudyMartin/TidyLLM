#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Pure Python TidyLLM Verbs - R-style %>% pipe operator for LLM data

NO PANDAS. NO NUMPY. Pure Python standard library only.

Implements R tidyverse-style data manipulation with pipe operator (|) for LLM data types:
- filter(), select(), mutate(), summarise(), arrange() - just like R dplyr
- Works with documents, papers, LLM responses, analysis results
- Pure Python - no external dependencies, no pandas/numpy karma issues

Examples:
    documents | filter(size_mb < 10) | select("title", "filename") | arrange("size_mb")
    papers | filter(year > 2020) | mutate(ai_summary=lambda p: f"AI: {p['title']}") | summarise()
    responses | select("content", "timestamp") | arrange("timestamp", desc=True)
"""

from typing import List, Dict, Any, Callable, Union
from dataclasses import dataclass
from datetime import datetime
import json

@dataclass
class TidyData:
    """Base class for tidy data that supports R-style pipe operator |"""
    data: List[Dict[str, Any]]
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}
        if self.data is None:
            self.data = []
    
    def __or__(self, verb_func: Callable) -> 'TidyData':
        """R-style pipe operator %>% using Python |"""
        return verb_func(self)
    
    def __len__(self) -> int:
        return len(self.data)
    
    def __iter__(self):
        return iter(self.data)
    
    def __getitem__(self, index):
        return self.data[index]

@dataclass
class DocumentCollection(TidyData):
    """Documents - PDFs, Word docs, etc."""
    pass

@dataclass  
class PaperCollection(TidyData):
    """Research papers and citations"""
    pass

@dataclass
class ResponseCollection(TidyData):
    """LLM responses and chat results"""
    pass

@dataclass
class AnalysisCollection(TidyData):
    """Analysis results and reports"""
    pass

# =============================================================================
# R TIDYVERSE VERBS - Pure Python Implementation
# =============================================================================

def filter(**conditions) -> Callable[[TidyData], TidyData]:
    """
    Filter rows based on conditions - like R's dplyr::filter()
    
    Usage:
        data | filter(size_mb < 10, file_type="pdf")
        data | filter(year=lambda y: y > 2020)
    """
    def _filter(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        filtered_items = []
        
        for item in tidy_data.data:
            keep_item = True
            
            for field, condition in conditions.items():
                if field not in item:
                    keep_item = False
                    break
                
                value = item[field]
                
                # Handle different condition types
                if callable(condition):
                    if not condition(value):
                        keep_item = False
                        break
                elif isinstance(condition, (str, int, float, bool)):
                    if value != condition:
                        keep_item = False
                        break
                elif hasattr(condition, '__contains__'):  # list, set, etc.
                    if value not in condition:
                        keep_item = False
                        break
            
            if keep_item:
                filtered_items.append(item)
        
        # Create new instance of same type
        result = type(tidy_data)(
            data=filtered_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata.update({
            'filter_applied': str(conditions),
            'original_count': len(tidy_data.data),
            'filtered_count': len(filtered_items)
        })
        
        return result
    
    return _filter

def select(*fields) -> Callable[[TidyData], TidyData]:
    """
    Select specific columns/fields - like R's dplyr::select()
    
    Usage:
        data | select("title", "filename", "size_mb")
        data | select("title", "author")
    """
    def _select(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        selected_items = []
        
        for item in tidy_data.data:
            selected_item = {}
            for field in fields:
                if field in item:
                    selected_item[field] = item[field]
            selected_items.append(selected_item)
        
        result = type(tidy_data)(
            data=selected_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata['selected_fields'] = fields
        
        return result
    
    return _select

def mutate(**new_fields) -> Callable[[TidyData], TidyData]:
    """
    Add new columns/fields - like R's dplyr::mutate()
    
    Usage:
        data | mutate(size_gb=lambda x: x['size_mb'] / 1024)
        data | mutate(summary=lambda x: f"File: {x['title']}")
    """
    def _mutate(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        mutated_items = []
        
        for item in tidy_data.data:
            new_item = item.copy()
            
            for field_name, field_func in new_fields.items():
                if callable(field_func):
                    new_item[field_name] = field_func(item)
                else:
                    new_item[field_name] = field_func
            
            mutated_items.append(new_item)
        
        result = type(tidy_data)(
            data=mutated_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata['added_fields'] = list(new_fields.keys())
        
        return result
    
    return _mutate

def arrange(*sort_fields, desc: bool = False) -> Callable[[TidyData], TidyData]:
    """
    Sort/arrange data - like R's dplyr::arrange()
    
    Usage:
        data | arrange("size_mb")
        data | arrange("year", "title", desc=True)
    """
    def _arrange(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        def sort_key(item):
            return [item.get(field, 0) for field in sort_fields]
        
        sorted_items = sorted(tidy_data.data, key=sort_key, reverse=desc)
        
        result = type(tidy_data)(
            data=sorted_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata.update({
            'sorted_by': sort_fields,
            'descending': desc
        })
        
        return result
    
    return _arrange

def summarise(method: str = "count", **kwargs) -> Callable[[TidyData], TidyData]:
    """
    Summarize/aggregate data - like R's dplyr::summarise()
    
    Usage:
        data | summarise()  # count
        data | summarise("group_by", group_field="file_type")
        data | summarise("stats", field="size_mb")
    """
    def _summarise(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        if method == "count":
            summary_data = [{"total_count": len(tidy_data.data)}]
        
        elif method == "group_by":
            group_field = kwargs.get("group_field", "type")
            groups = {}
            for item in tidy_data.data:
                group_value = item.get(group_field, "unknown")
                groups[group_value] = groups.get(group_value, 0) + 1
            
            summary_data = [{"group": k, "count": v} for k, v in groups.items()]
        
        elif method == "stats":
            field = kwargs.get("field", "size")
            values = [item.get(field, 0) for item in tidy_data.data if field in item]
            if values:
                summary_data = [{
                    "field": field,
                    "count": len(values),
                    "min": min(values),
                    "max": max(values),
                    "sum": sum(values),
                    "avg": sum(values) / len(values)
                }]
            else:
                summary_data = [{"field": field, "count": 0}]
        
        else:
            summary_data = [{"method": method, "items": len(tidy_data.data)}]
        
        result = type(tidy_data)(
            data=summary_data,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata.update({
            'summarise_method': method,
            'original_count': len(tidy_data.data)
        })
        
        return result
    
    return _summarise

# =============================================================================
# CUSTOM LLM VERBS - Beyond R tidyverse
# =============================================================================

def reshape(format: str = "markdown", **options) -> Callable[[TidyData], TidyData]:
    """
    Reshape/transform data format - custom verb for LLM data
    
    Usage:
        data | reshape("markdown")
        data | reshape("json", indent=2)
        data | reshape("summary")
    """
    def _reshape(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        reshaped_items = []
        
        for item in tidy_data.data:
            if format == "markdown":
                md_parts = []
                
                # Title
                title_fields = ['title', 'name', 'filename']
                for field in title_fields:
                    if field in item:
                        md_parts.append(f"# {item[field]}")
                        break
                
                # Content
                for key, value in item.items():
                    if key not in title_fields:
                        md_parts.append(f"## {key.replace('_', ' ').title()}")
                        md_parts.append(str(value))
                        md_parts.append("")
                
                reshaped_items.append({"markdown": "\n".join(md_parts)})
            
            elif format == "json":
                indent = options.get("indent", 2)
                reshaped_items.append({"json": json.dumps(item, indent=indent)})
            
            elif format == "summary":
                summary_fields = ["title", "name", "filename", "summary", "abstract"]
                summary_item = {}
                for field in summary_fields:
                    if field in item:
                        summary_item[field] = item[field]
                reshaped_items.append(summary_item)
            
            else:
                reshaped_items.append(item)
        
        result = type(tidy_data)(
            data=reshaped_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata['reshaped_format'] = format
        
        return result
    
    return _reshape

def extract(target: str = "content") -> Callable[[TidyData], TidyData]:
    """
    Extract specific information - custom verb for LLM data
    
    Usage:
        data | extract("content")
        data | extract("metadata") 
        data | extract("title")
    """
    def _extract(tidy_data: TidyData) -> TidyData:
        if not tidy_data.data:
            return tidy_data
        
        extracted_items = []
        
        for item in tidy_data.data:
            if target == "metadata":
                metadata_fields = ["title", "author", "date", "size", "type", "filename"]
                extracted_item = {}
                for field in metadata_fields:
                    if field in item:
                        extracted_item[field] = item[field]
                extracted_items.append(extracted_item)
            
            elif target in item:
                extracted_items.append({target: item[target]})
            
            else:
                # Try to find similar field
                for key in item.keys():
                    if target.lower() in key.lower():
                        extracted_items.append({key: item[key]})
                        break
                else:
                    extracted_items.append({target: None})
        
        result = type(tidy_data)(
            data=extracted_items,
            metadata=tidy_data.metadata.copy()
        )
        result.metadata['extracted_target'] = target
        
        return result
    
    return _extract

# =============================================================================
# UTILITY FUNCTIONS
# =============================================================================

def collect(tidy_data: TidyData) -> List[Dict[str, Any]]:
    """Convert tidy data back to plain Python list - like R's collect()"""
    return tidy_data.data

def glimpse(tidy_data: TidyData) -> TidyData:
    """Show structure of data - like R's glimpse()"""
    print(f"\n{type(tidy_data).__name__}: {len(tidy_data.data)} items")
    print(f"Metadata: {tidy_data.metadata}")
    
    if tidy_data.data:
        print("\nFirst few items:")
        for i, item in enumerate(tidy_data.data[:3], 1):
            print(f"  {i}. {item}")
        
        if len(tidy_data.data) > 3:
            print(f"  ... and {len(tidy_data.data) - 3} more")
        
        # Show field summary
        all_fields = set()
        for item in tidy_data.data:
            all_fields.update(item.keys())
        print(f"\nFields: {sorted(all_fields)}")
    
    return tidy_data  # Return for chaining

# =============================================================================
# DEMO
# =============================================================================

def demo_pure_python_tidyverse():
    """Demonstrate pure Python tidyverse-style operations"""
    
    print("🎯 PURE PYTHON TIDYVERSE - NO PANDAS, NO NUMPY")
    print("=" * 60)
    print("R-style %>% pipe operator using Python |")
    print()
    
    # Create sample documents
    docs = DocumentCollection(data=[
        {"filename": "report1.pdf", "size_mb": 2.5, "file_type": "pdf", "title": "Q1 Analysis", "year": 2023},
        {"filename": "report2.pdf", "size_mb": 15.2, "file_type": "pdf", "title": "Annual Report", "year": 2023}, 
        {"filename": "summary.docx", "size_mb": 0.8, "file_type": "docx", "title": "Executive Summary", "year": 2024},
        {"filename": "data.csv", "size_mb": 0.1, "file_type": "csv", "title": "Raw Data", "year": 2024},
        {"filename": "huge_file.pdf", "size_mb": 50.0, "file_type": "pdf", "title": "Complete Dataset", "year": 2022}
    ])
    
    print("📊 Original Documents:")
    docs | glimpse
    
    print("\n🔍 R-STYLE TIDYVERSE PIPELINE:")
    print('docs | filter(file_type="pdf") | filter(size_mb=lambda s: s < 20) | select("title", "size_mb") | arrange("size_mb")')
    print()
    
    # Classic tidyverse pipeline - just like R!
    result = (docs 
              | filter(file_type="pdf") 
              | filter(size_mb=lambda s: s < 20)
              | select("title", "filename", "size_mb", "year")
              | arrange("size_mb"))
    
    result | glimpse
    
    print("\n📈 ADD NEW FIELD WITH MUTATE:")
    print('result | mutate(size_category=lambda x: "small" if x["size_mb"] < 5 else "large")')
    print()
    
    mutated = result | mutate(
        size_category=lambda x: "small" if x["size_mb"] < 5 else "large",
        summary=lambda x: f"{x['title']} ({x['size_mb']}MB)"
    )
    
    mutated | glimpse
    
    print("\n📊 SUMMARISE BY GROUP:")
    print('docs | summarise("group_by", group_field="file_type")')
    print()
    
    summary = docs | summarise("group_by", group_field="file_type")
    summary | glimpse
    
    print("\n📝 RESHAPE TO MARKDOWN:")
    print('result | reshape("markdown")')
    print()
    
    markdown = result | reshape("markdown") 
    print("Sample markdown output:")
    if markdown.data:
        print(markdown.data[0]["markdown"][:200] + "...")
    
    print("\n✨ BENEFITS:")
    print("  ✅ Pure Python - no external dependencies")
    print("  ✅ No pandas karma issues")  
    print("  ✅ No numpy problems")
    print("  ✅ R-style %>% pipe operator using |")
    print("  ✅ Full tidyverse verbs: filter, select, mutate, arrange, summarise")
    print("  ✅ Custom LLM verbs: reshape, extract")
    print("  ✅ Works with documents, papers, responses, analysis")

if __name__ == "__main__":
    demo_pure_python_tidyverse()