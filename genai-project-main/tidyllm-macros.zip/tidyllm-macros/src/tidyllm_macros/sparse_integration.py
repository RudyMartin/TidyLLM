#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sparse Agreements Integration for TidyLLM Macros

Integrates existing sparse agreements system with macro expansion
to provide intelligent [macro] interpretation and execution.
"""

import logging
import yaml
import re
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path

from .core import MacroRegistry, MacroProcessor

logger = logging.getLogger(__name__)

class SparseAgreementLoader:
    """
    Loads and processes sparse agreements for macro expansion
    
    Integrates with the existing sparse agreements system to provide
    intelligent macro interpretation and parameter expansion.
    """
    
    def __init__(self, agreements_path: str = None):
        self.agreements_path = Path(agreements_path) if agreements_path else self._find_agreements_path()
        self.agreements: Dict[str, Any] = {}
        self.bracket_mappings: Dict[str, str] = {}
        self.tool_mappings: Dict[str, Dict[str, Any]] = {}
        
        self._load_agreements()
    
    def _find_agreements_path(self) -> Path:
        """Find sparse agreements file in the project"""
        possible_paths = [
            Path("sparse/sparse_agreements.yaml"),
            Path("../../../sparse/sparse_agreements.yaml"), 
            Path("../../../../sparse/sparse_agreements.yaml"),
            Path.cwd() / "sparse" / "sparse_agreements.yaml"
        ]
        
        for path in possible_paths:
            if path.exists():
                return path
        
        logger.warning("Sparse agreements file not found")
        return Path("sparse_agreements.yaml")  # Default fallback
    
    def _load_agreements(self):
        """Load sparse agreements from YAML file"""
        if not self.agreements_path.exists():
            logger.warning(f"Sparse agreements file not found: {self.agreements_path}")
            return
        
        try:
            with open(self.agreements_path, 'r') as f:
                data = yaml.safe_load(f)
            
            self.agreements = data.get('agreements', {})
            self.tool_mappings = data.get('tool_mapping', {})
            
            # Build bracket mappings for quick lookup
            self._build_bracket_mappings()
            
            logger.info(f"Loaded {len(self.agreements)} sparse agreement categories")
            
        except Exception as e:
            logger.error(f"Failed to load sparse agreements: {e}")
    
    def _build_bracket_mappings(self):
        """Build mapping of [bracket] patterns to sparse encodings"""
        for category, agreements in self.agreements.items():
            for bracket_pattern, agreement_data in agreements.items():
                if bracket_pattern.startswith('[') and bracket_pattern.endswith(']'):
                    # Clean bracket pattern
                    clean_pattern = bracket_pattern[1:-1].lower().replace(' ', '_')
                    
                    self.bracket_mappings[clean_pattern] = {
                        'category': category,
                        'original_pattern': bracket_pattern,
                        'sparse_encoding': agreement_data.get('sparse_encoding', ''),
                        'expanded_meaning': agreement_data.get('expanded_meaning', ''),
                        'action': agreement_data.get('action', ''),
                        'parameters': agreement_data.get('parameters', []),
                        'tools_to_use': agreement_data.get('tools_to_use', []),
                        'expected_output': agreement_data.get('expected_output', '')
                    }
    
    def find_sparse_agreement(self, macro_name: str) -> Optional[Dict[str, Any]]:
        """Find sparse agreement for a macro name"""
        clean_name = macro_name.lower().replace(' ', '_')
        
        # Direct lookup
        if clean_name in self.bracket_mappings:
            return self.bracket_mappings[clean_name]
        
        # Fuzzy matching
        for pattern, agreement in self.bracket_mappings.items():
            if clean_name in pattern or pattern in clean_name:
                return agreement
        
        return None
    
    def expand_macro_with_sparse(self, macro_name: str, context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """
        Expand macro using sparse agreements
        
        Converts sparse agreement into macro workflow steps
        """
        agreement = self.find_sparse_agreement(macro_name)
        if not agreement:
            return None
        
        context = context or {}
        
        # Create macro definition from sparse agreement
        macro_def = {
            'name': macro_name,
            'description': agreement['expanded_meaning'],
            'sparse_encoding': agreement['sparse_encoding'],
            'workflow_steps': self._convert_sparse_to_workflow_steps(agreement, context),
            'expected_outputs': [agreement['expected_output']],
            'health_checks': ['sparse_agreement_check']
        }
        
        return macro_def
    
    def _convert_sparse_to_workflow_steps(self, agreement: Dict[str, Any], context: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Convert sparse agreement tools to workflow steps"""
        steps = []
        tools = agreement.get('tools_to_use', [])
        action = agreement.get('action', '')
        parameters = agreement.get('parameters', [])
        
        # Convert tools to TidyLLM operations
        for i, tool in enumerate(tools):
            step = self._map_tool_to_step(tool, action, parameters, i)
            if step:
                steps.append(step)
        
        # If no specific tools, create generic step based on action
        if not steps and action:
            steps.append({
                'name': f'Execute {action}',
                'description': agreement.get('expanded_meaning', ''),
                'operation': 'custom_operation',
                'parameters': {
                    'action': action,
                    'parameters': parameters
                },
                'expected_output': agreement.get('expected_output', ''),
                'human_description': f"🔧 Executing {action} based on sparse agreement"
            })
        
        return steps
    
    def _map_tool_to_step(self, tool: str, action: str, parameters: List[str], step_index: int) -> Optional[Dict[str, Any]]:
        """Map sparse agreement tool to TidyLLM workflow step"""
        tool_mappings = {
            'codebase_search': {
                'operation': 'custom_operation',
                'human_description': '🔍 Searching codebase for relevant information'
            },
            'file_search': {
                'operation': 'load_file',
                'human_description': '📂 Searching and loading relevant files'
            },
            'grep_search': {
                'operation': 'custom_operation', 
                'human_description': '🔎 Searching content with pattern matching'
            },
            'read_file': {
                'operation': 'load_file',
                'human_description': '📖 Reading and processing files'
            },
            'edit_file': {
                'operation': 'save_file',
                'human_description': '✏️ Editing and saving files'
            },
            'pdf_extraction': {
                'operation': 'load_auto',
                'human_description': '📄 Extracting content from PDF files'
            },
            'file_upload': {
                'operation': 'attach',
                'human_description': '📎 Uploading and attaching files'
            }
        }
        
        mapping = tool_mappings.get(tool)
        if not mapping:
            # Generic mapping for unknown tools
            mapping = {
                'operation': 'custom_operation',
                'human_description': f'🔧 Executing {tool} operation'
            }
        
        return {
            'name': f'{tool.replace("_", " ").title()} Step',
            'description': f'Execute {tool} as part of {action}',
            'operation': mapping['operation'],
            'parameters': {
                'tool': tool,
                'action': action,
                'sparse_parameters': parameters
            },
            'expected_output': f'Results from {tool}',
            'human_description': mapping['human_description']
        }

class MacroExpander:
    """
    Expands macros using both registry definitions and sparse agreements
    
    Provides intelligent macro expansion that can fall back to sparse
    agreements when macro definitions are not available.
    """
    
    def __init__(self, registry: MacroRegistry = None, sparse_loader: SparseAgreementLoader = None):
        self.registry = registry or MacroRegistry()
        self.sparse_loader = sparse_loader or SparseAgreementLoader()
        self.expansion_cache: Dict[str, Dict[str, Any]] = {}
        
    def expand_macro(self, macro_name: str, user_prompt: str, context: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """
        Expand macro using registry or sparse agreements
        
        Priority order:
        1. Registry definition (explicit macro)
        2. Sparse agreement mapping 
        3. Intelligent interpretation based on name
        """
        context = context or {}
        
        # Check cache first
        cache_key = f"{macro_name}_{hash(str(context))}"
        if cache_key in self.expansion_cache:
            return self.expansion_cache[cache_key]
        
        # Try registry first
        macro_def = self.registry.get_macro(macro_name)
        if macro_def:
            logger.info(f"Using registry definition for macro: {macro_name}")
            self.expansion_cache[cache_key] = macro_def
            return macro_def
        
        # Try sparse agreements
        sparse_def = self.sparse_loader.expand_macro_with_sparse(macro_name, context)
        if sparse_def:
            logger.info(f"Using sparse agreement for macro: {macro_name}")
            self.expansion_cache[cache_key] = sparse_def
            return sparse_def
        
        # Try intelligent interpretation
        interpreted_def = self._intelligent_interpretation(macro_name, user_prompt, context)
        if interpreted_def:
            logger.info(f"Using intelligent interpretation for macro: {macro_name}")
            self.expansion_cache[cache_key] = interpreted_def
            return interpreted_def
        
        logger.warning(f"No expansion found for macro: {macro_name}")
        return None
    
    def _intelligent_interpretation(self, macro_name: str, user_prompt: str, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """
        Intelligently interpret unknown macro based on name and context
        
        Uses heuristics to create reasonable macro definitions for
        unknown [macro] patterns.
        """
        
        # Common macro patterns
        patterns = {
            'analyze': self._create_analysis_macro,
            'compare': self._create_comparison_macro,
            'generate': self._create_generation_macro,
            'extract': self._create_extraction_macro,
            'search': self._create_search_macro,
            'process': self._create_processing_macro
        }
        
        for pattern, creator in patterns.items():
            if pattern in macro_name.lower():
                return creator(macro_name, user_prompt, context)
        
        # Generic fallback
        return self._create_generic_macro(macro_name, user_prompt, context)
    
    def _create_analysis_macro(self, macro_name: str, user_prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Create analysis-type macro"""
        return {
            'name': macro_name,
            'description': f'Intelligent analysis workflow for {macro_name}',
            'workflow_steps': [
                {
                    'name': 'Load Content',
                    'operation': 'attach',
                    'parameters': {'files': []},
                    'human_description': '📎 Loading content for analysis'
                },
                {
                    'name': 'Process Content', 
                    'operation': 'load_auto',
                    'parameters': {},
                    'human_description': '🔍 Processing and extracting content'
                },
                {
                    'name': 'Perform Analysis',
                    'operation': 'chat',
                    'parameters': {
                        'provider': 'claude',
                        'prompt': f'Perform detailed analysis as requested in: {user_prompt}'
                    },
                    'human_description': '🧠 Performing intelligent analysis'
                }
            ],
            'expected_outputs': ['analysis_results']
        }
    
    def _create_comparison_macro(self, macro_name: str, user_prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Create comparison-type macro"""
        return {
            'name': macro_name,
            'description': f'Intelligent comparison workflow for {macro_name}',
            'workflow_steps': [
                {
                    'name': 'Load Items to Compare',
                    'operation': 'attach',
                    'parameters': {'files': []},
                    'human_description': '📎 Loading items for comparison'
                },
                {
                    'name': 'Process Content',
                    'operation': 'load_auto', 
                    'parameters': {},
                    'human_description': '🔍 Processing content for comparison'
                },
                {
                    'name': 'Perform Comparison',
                    'operation': 'compare_documents',
                    'parameters': {
                        'prompt': f'Compare these items as requested: {user_prompt}'
                    },
                    'human_description': '⚖️ Performing detailed comparison'
                }
            ],
            'expected_outputs': ['comparison_results']
        }
    
    def _create_generation_macro(self, macro_name: str, user_prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Create generation-type macro"""
        return {
            'name': macro_name,
            'description': f'Content generation workflow for {macro_name}',
            'workflow_steps': [
                {
                    'name': 'Gather Source Material',
                    'operation': 'attach',
                    'parameters': {'files': []},
                    'human_description': '📚 Gathering source material'
                },
                {
                    'name': 'Generate Content',
                    'operation': 'chat',
                    'parameters': {
                        'provider': 'claude',
                        'prompt': f'Generate content as requested: {user_prompt}'
                    },
                    'human_description': '✨ Generating requested content'
                },
                {
                    'name': 'Format Output',
                    'operation': 'generate_report',
                    'parameters': {
                        'title': f'Generated {macro_name.replace("_", " ").title()}'
                    },
                    'human_description': '📋 Formatting final output'
                }
            ],
            'expected_outputs': ['generated_content']
        }
    
    def _create_generic_macro(self, macro_name: str, user_prompt: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Create generic macro for unknown patterns"""
        return {
            'name': macro_name,
            'description': f'Generic workflow for {macro_name}',
            'workflow_steps': [
                {
                    'name': 'Process Request',
                    'operation': 'chat',
                    'parameters': {
                        'provider': 'claude',
                        'prompt': f'Handle the request for [{macro_name}] as described in: {user_prompt}'
                    },
                    'human_description': f'🔧 Processing {macro_name} request'
                }
            ],
            'expected_outputs': ['processed_result']
        }

# Integration functions
def create_integrated_macro_processor(agreements_path: str = None) -> MacroProcessor:
    """Create macro processor with sparse agreements integration"""
    
    # Load sparse agreements
    sparse_loader = SparseAgreementLoader(agreements_path)
    
    # Create registry and populate with defaults
    registry = MacroRegistry()
    from .macros import populate_default_macros
    populate_default_macros(registry)
    
    # Create expander with both registry and sparse integration
    expander = MacroExpander(registry, sparse_loader)
    
    # Create processor
    processor = MacroProcessor(registry)
    
    # Replace default expansion with integrated expansion
    original_create_execution = processor._create_execution
    
    def integrated_create_execution(macro_name, user_prompt, macro_def, context):
        # Try to get better definition from expander
        expanded_def = expander.expand_macro(macro_name, user_prompt, context)
        if expanded_def:
            macro_def = expanded_def
        
        return original_create_execution(macro_name, user_prompt, macro_def, context)
    
    processor._create_execution = integrated_create_execution
    
    logger.info("Created integrated macro processor with sparse agreements")
    return processor

__all__ = [
    'SparseAgreementLoader',
    'MacroExpander', 
    'create_integrated_macro_processor'
]