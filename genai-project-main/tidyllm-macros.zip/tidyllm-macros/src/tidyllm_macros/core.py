#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Macros Core Classes

Core data structures for macro processing, execution tracking, and results.
"""

import logging
import json
from typing import Dict, List, Any, Optional, Callable, Union
from datetime import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
import uuid

logger = logging.getLogger(__name__)

class MacroStatus(Enum):
    """Macro execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    AHA_BLOCKED = "aha_blocked"  # Blocked by AHA system

class StepStatus(Enum):
    """Individual step execution status"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    AHA_INTERVENTION = "aha_intervention"

class ComplexityLevel(Enum):
    """Progressive complexity levels for macros"""
    SIMPLE = "simple"
    ENHANCED = "enhanced"
    ADVANCED = "advanced"

@dataclass
class MacroStep:
    """
    Individual step in a macro execution
    
    Represents a single TidyLLM operation like chat(), attach(), analyze(), etc.
    """
    step_id: str
    name: str
    description: str
    operation: str  # TidyLLM operation name (e.g., "chat", "attach", "analyze")
    parameters: Dict[str, Any]
    expected_output: str
    status: StepStatus = StepStatus.PENDING
    
    # Execution tracking
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_ms: Optional[int] = None
    
    # Results
    output: Any = None
    error_message: Optional[str] = None
    
    # AHA monitoring
    health_score: float = 1.0
    aha_warnings: List[str] = field(default_factory=list)
    aha_interventions: List[str] = field(default_factory=list)
    
    # Human visibility
    human_readable_description: str = ""
    progress_message: str = ""
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        data = asdict(self)
        # Convert datetime objects to ISO strings
        if self.started_at:
            data['started_at'] = self.started_at.isoformat()
        if self.completed_at:
            data['completed_at'] = self.completed_at.isoformat()
        return data
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'MacroStep':
        """Create from dictionary"""
        # Convert ISO strings back to datetime objects
        if data.get('started_at'):
            data['started_at'] = datetime.fromisoformat(data['started_at'])
        if data.get('completed_at'):
            data['completed_at'] = datetime.fromisoformat(data['completed_at'])
        
        return cls(**data)

@dataclass
class MacroExecution:
    """
    Complete macro execution tracking
    
    Tracks the full execution of a macro from start to finish with
    AHA monitoring and human-visible progress.
    """
    execution_id: str
    macro_name: str
    user_prompt: str
    expanded_workflow: str
    status: MacroStatus = MacroStatus.PENDING
    
    # Steps
    steps: List[MacroStep] = field(default_factory=list)
    current_step: int = 0
    
    # Execution metadata
    created_at: datetime = field(default_factory=datetime.now)
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    total_duration_ms: Optional[int] = None
    
    # Results
    final_result: Any = None
    output_files: List[str] = field(default_factory=list)
    
    # AHA monitoring
    overall_health_score: float = 1.0
    aha_alerts: List[Dict[str, Any]] = field(default_factory=list)
    safety_interventions: List[str] = field(default_factory=list)
    
    # Human visibility
    progress_percentage: float = 0.0
    current_operation: str = ""
    user_visible_log: List[str] = field(default_factory=list)
    
    def add_step(self, step: MacroStep):
        """Add a step to the execution"""
        self.steps.append(step)
    
    def get_current_step(self) -> Optional[MacroStep]:
        """Get currently executing step"""
        if 0 <= self.current_step < len(self.steps):
            return self.steps[self.current_step]
        return None
    
    def advance_step(self):
        """Move to next step"""
        if self.current_step < len(self.steps) - 1:
            self.current_step += 1
            self.progress_percentage = (self.current_step / len(self.steps)) * 100
    
    def add_user_log(self, message: str):
        """Add message to user-visible log"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.user_visible_log.append(f"[{timestamp}] {message}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization"""
        data = asdict(self)
        # Convert datetime objects to ISO strings
        data['created_at'] = self.created_at.isoformat()
        if self.started_at:
            data['started_at'] = self.started_at.isoformat()
        if self.completed_at:
            data['completed_at'] = self.completed_at.isoformat()
        
        # Convert steps to dictionaries
        data['steps'] = [step.to_dict() for step in self.steps]
        
        return data
    
    def save_to_file(self, filepath: str):
        """Save execution to JSON file"""
        with open(filepath, 'w') as f:
            json.dump(self.to_dict(), f, indent=2)
        logger.info(f"Saved macro execution to {filepath}")

@dataclass
class MacroResult:
    """
    Final result of a macro execution
    
    Contains all outputs, files generated, and summary information
    for user consumption.
    """
    execution_id: str
    macro_name: str
    status: MacroStatus
    
    # Results
    primary_output: Any
    generated_files: List[str]
    intermediate_results: Dict[str, Any]
    
    # Summary
    execution_summary: str
    steps_completed: int
    total_steps: int
    duration_seconds: float
    
    # Health and safety
    health_score: float
    safety_issues: List[str]
    aha_recommendations: List[str]
    
    # Human-readable summary
    user_summary: str
    success_message: str
    
    def is_successful(self) -> bool:
        """Check if execution was successful"""
        return self.status == MacroStatus.COMPLETED
    
    def has_safety_issues(self) -> bool:
        """Check if there were safety issues"""
        return len(self.safety_issues) > 0 or self.health_score < 0.8

@dataclass
class MacroDefinition:
    """
    Complete definition of a macro with progressive complexity levels
    """
    name: str
    description: str
    trigger_patterns: List[str]  # e.g., ["[MVR Peer Review]", "[MVR Review]"]
    complexity_levels: Dict[ComplexityLevel, Dict[str, Any]]
    input_types: List[str]  # Expected input data types
    output_type: str  # Expected output data type
    tags: List[str] = field(default_factory=list)
    author: str = "TidyLLM User"
    version: str = "1.0.0"
    
    def get_complexity_level(self, level: Union[str, ComplexityLevel]) -> Dict[str, Any]:
        """Get configuration for a specific complexity level"""
        if isinstance(level, str):
            level = ComplexityLevel(level)
        return self.complexity_levels.get(level, {})
    
    def list_complexity_levels(self) -> List[str]:
        """List available complexity levels"""
        return [level.value for level in self.complexity_levels.keys()]

class MacroRegistry:
    """
    Registry for macro definitions and their TidyLLM workflows
    
    Manages the mapping between [macro] names and their corresponding
    TidyLLM pipeline operations.
    """
    
    def __init__(self):
        self.macros: Dict[str, Dict[str, Any]] = {}
        self._load_default_macros()
    
    def register_macro(self, 
                      name: str,
                      description: str,
                      workflow_steps: List[Dict[str, Any]],
                      parameters: Dict[str, Any] = None,
                      expected_inputs: List[str] = None,
                      expected_outputs: List[str] = None,
                      health_checks: List[str] = None):
        """
        Register a new macro
        
        Args:
            name: Macro name (without brackets)
            description: Human-readable description
            workflow_steps: List of TidyLLM operations to execute
            parameters: Default parameters
            expected_inputs: Required input types
            expected_outputs: Expected output types  
            health_checks: AHA health checks to perform
        """
        
        self.macros[name] = {
            'name': name,
            'description': description,
            'workflow_steps': workflow_steps,
            'parameters': parameters or {},
            'expected_inputs': expected_inputs or [],
            'expected_outputs': expected_outputs or [],
            'health_checks': health_checks or [],
            'registered_at': datetime.now().isoformat()
        }
        
        logger.info(f"Registered macro: {name}")
    
    def get_macro(self, name: str) -> Optional[Dict[str, Any]]:
        """Get macro definition by name"""
        return self.macros.get(name)
    
    def list_macros(self) -> List[str]:
        """List all registered macro names"""
        return list(self.macros.keys())
    
    def find_macros_in_text(self, text: str) -> List[str]:
        """Find all [macro] references in text"""
        import re
        
        # Find all [macro_name] patterns
        pattern = r'\[([a-zA-Z_][a-zA-Z0-9_]*)\]'
        matches = re.findall(pattern, text)
        
        # Filter to only registered macros
        found_macros = []
        for match in matches:
            if match in self.macros:
                found_macros.append(match)
        
        return found_macros
    
    def _load_default_macros(self):
        """Load default macro definitions"""
        try:
            from .built_ins import BUILT_IN_MACROS
            
            # Load all built-in macros
            for macro_name, macro_factory in BUILT_IN_MACROS.items():
                try:
                    macro_def = macro_factory()
                    self.register_macro_definition(macro_def)
                    logger.info(f"Loaded built-in macro: {macro_name}")
                except Exception as e:
                    logger.warning(f"Failed to load built-in macro {macro_name}: {e}")
                    
        except ImportError:
            logger.info("No built-in macros found")
    
    def register_macro_definition(self, macro_def):
        """Register a MacroDefinition object"""
        # Convert MacroDefinition to registry format
        for trigger in macro_def.trigger_patterns:
            # Remove brackets from trigger pattern for internal storage
            clean_name = trigger.strip('[]')
            
            self.macros[clean_name] = {
                'name': macro_def.name,
                'description': macro_def.description,
                'trigger_patterns': macro_def.trigger_patterns,
                'complexity_levels': macro_def.complexity_levels,
                'input_types': macro_def.input_types,
                'output_type': macro_def.output_type,
                'tags': macro_def.tags,
                'author': macro_def.author,
                'version': macro_def.version
            }
    
    def export_to_file(self, filepath: str):
        """Export macro registry to JSON file"""
        with open(filepath, 'w') as f:
            json.dump(self.macros, f, indent=2)
        logger.info(f"Exported macro registry to {filepath}")
    
    def import_from_file(self, filepath: str):
        """Import macros from JSON file"""
        with open(filepath, 'r') as f:
            imported_macros = json.load(f)
        
        for name, macro_def in imported_macros.items():
            self.macros[name] = macro_def
        
        logger.info(f"Imported {len(imported_macros)} macros from {filepath}")

class MacroProcessor:
    """
    Main processor for handling macro expansion and execution
    
    Converts [macro] references in user prompts into executable
    TidyLLM workflows with AHA monitoring.
    """
    
    def __init__(self, registry: MacroRegistry = None):
        self.registry = registry or MacroRegistry()
        self.active_executions: Dict[str, MacroExecution] = {}
        
    def process_prompt(self, user_prompt: str, context: Dict[str, Any] = None) -> List[MacroExecution]:
        """
        Process user prompt for macro references
        
        Args:
            user_prompt: User's prompt text
            context: Additional context for macro expansion
            
        Returns:
            List of macro executions to run
        """
        context = context or {}
        
        # Find all macros in the prompt
        macro_names = self.registry.find_macros_in_text(user_prompt)
        
        if not macro_names:
            logger.info("No macros found in prompt")
            return []
        
        executions = []
        
        for macro_name in macro_names:
            logger.info(f"Processing macro: {macro_name}")
            
            # Get macro definition
            macro_def = self.registry.get_macro(macro_name)
            if not macro_def:
                logger.warning(f"Unknown macro: {macro_name}")
                continue
            
            # Create execution
            execution = self._create_execution(macro_name, user_prompt, macro_def, context)
            executions.append(execution)
            
            # Track active execution
            self.active_executions[execution.execution_id] = execution
        
        return executions
    
    def _create_execution(self, 
                         macro_name: str,
                         user_prompt: str, 
                         macro_def: Dict[str, Any],
                         context: Dict[str, Any]) -> MacroExecution:
        """Create macro execution from definition"""
        
        execution_id = str(uuid.uuid4())
        
        execution = MacroExecution(
            execution_id=execution_id,
            macro_name=macro_name,
            user_prompt=user_prompt,
            expanded_workflow=macro_def['description']
        )
        
        # Convert workflow steps to MacroStep objects
        for i, step_def in enumerate(macro_def['workflow_steps']):
            step = MacroStep(
                step_id=f"{execution_id}_step_{i}",
                name=step_def.get('name', f'Step {i+1}'),
                description=step_def.get('description', ''),
                operation=step_def.get('operation', ''),
                parameters=step_def.get('parameters', {}),
                expected_output=step_def.get('expected_output', ''),
                human_readable_description=step_def.get('human_description', step_def.get('description', ''))
            )
            
            execution.add_step(step)
        
        execution.add_user_log(f"🔧 Created execution plan for [{macro_name}]")
        execution.add_user_log(f"📋 {len(execution.steps)} steps planned")
        
        return execution
    
    def get_execution(self, execution_id: str) -> Optional[MacroExecution]:
        """Get active execution by ID"""
        return self.active_executions.get(execution_id)
    
    def list_active_executions(self) -> List[MacroExecution]:
        """Get list of active executions"""
        return list(self.active_executions.values())

__all__ = [
    'MacroStatus',
    'StepStatus', 
    'MacroStep',
    'MacroExecution',
    'MacroResult',
    'MacroRegistry',
    'MacroProcessor'
]