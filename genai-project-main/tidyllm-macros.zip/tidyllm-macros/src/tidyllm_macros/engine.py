#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Macros Execution Engine

Executes macro workflows with AHA monitoring and human-visible progress.
Integrates with existing LLMData and TidyLLM-Papers functionality.
"""

import logging
import asyncio
import time
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
from pathlib import Path
import traceback

from .core import MacroExecution, MacroStep, MacroResult, MacroStatus, StepStatus
from .monitoring import AHAMacroMonitor, ExecutionSafeguard
from .tidyverse_pipe import DocumentCollection, PaperCollection, ResponseCollection, AnalysisCollection, add_pipe_support

logger = logging.getLogger(__name__)

# Integration with existing LLMData ecosystem
try:
    import tidyllm
    from tidyllm.attachments_enhanced import attach, load, present, refine
    from tidyllm import llm_message, chat, claude, openai
    LLMDATA_AVAILABLE = True
except ImportError:
    LLMDATA_AVAILABLE = False
    logger.warning("LLMData not available - macro execution limited")

# Integration with TidyLLM-Papers
try:
    import sys
    from pathlib import Path
    tidyllm_papers_path = Path(__file__).parent.parent.parent.parent / 'tidyllm-papers'
    if str(tidyllm_papers_path) not in sys.path:
        sys.path.insert(0, str(tidyllm_papers_path))
    
    from tidyllm_papers import papers, discover, analyze, cite
    TIDYLLM_PAPERS_AVAILABLE = True
except ImportError:
    TIDYLLM_PAPERS_AVAILABLE = False
    logger.warning("TidyLLM-Papers not available - paper macros limited")

class ExecutionContext:
    """
    Context for macro execution with state management
    
    Maintains state across steps and provides access to
    intermediate results and shared resources.
    """
    
    def __init__(self, execution: MacroExecution):
        self.execution = execution
        self.shared_state: Dict[str, Any] = {}
        self.intermediate_results: Dict[str, Any] = {}
        self.file_attachments: List[str] = []
        self.temp_files: List[str] = []
        
        # TidyLLM state
        self.current_message = None
        self.current_attachments = None
        self.paper_collection = None
        
        # Error handling
        self.error_count = 0
        self.max_retries = 3
        
    def set_result(self, step_id: str, result: Any):
        """Store result from a step"""
        self.intermediate_results[step_id] = result
        
    def get_result(self, step_id: str) -> Any:
        """Get result from a previous step"""
        return self.intermediate_results.get(step_id)
    
    def add_attachment(self, file_path: str):
        """Add file attachment"""
        if Path(file_path).exists():
            self.file_attachments.append(file_path)
        
    def cleanup_temp_files(self):
        """Clean up temporary files"""
        for temp_file in self.temp_files:
            try:
                if Path(temp_file).exists():
                    Path(temp_file).unlink()
            except Exception as e:
                logger.warning(f"Failed to cleanup {temp_file}: {e}")

class StepExecutor:
    """
    Executes individual macro steps with operation-specific handlers
    
    Maps TidyLLM operations to actual function calls with proper
    error handling and AHA monitoring.
    """
    
    def __init__(self, aha_monitor: AHAMacroMonitor = None):
        self.aha_monitor = aha_monitor
        self.operation_handlers = self._setup_operation_handlers()
        
    def _setup_operation_handlers(self) -> Dict[str, Callable]:
        """Setup handlers for different TidyLLM operations"""
        return {
            # LLMData operations
            'attach': self._handle_attach,
            'load_auto': self._handle_load_auto,
            'present_markdown': self._handle_present_markdown,
            'chat': self._handle_chat,
            'llm_message': self._handle_llm_message,
            
            # TidyLLM-Papers operations
            'papers_discover': self._handle_papers_discover,
            'papers_analyze': self._handle_papers_analyze,
            'papers_cite': self._handle_papers_cite,
            
            # File operations
            'save_file': self._handle_save_file,
            'load_file': self._handle_load_file,
            
            # Report generation
            'generate_report': self._handle_generate_report,
            'compare_documents': self._handle_compare_documents,
            
            # Generic operations
            'custom_operation': self._handle_custom_operation
        }
    
    async def execute_step(self, step: MacroStep, context: ExecutionContext) -> Any:
        """
        Execute a single macro step
        
        Args:
            step: The step to execute
            context: Execution context with state
            
        Returns:
            Step execution result
        """
        
        step.started_at = datetime.now()
        step.status = StepStatus.RUNNING
        
        # Add human-visible progress
        context.execution.add_user_log(f"🔄 {step.human_readable_description}")
        context.execution.current_operation = step.name
        
        try:
            # AHA health check before execution
            if self.aha_monitor:
                health_check = await self.aha_monitor.check_step_health(step, context)
                if not health_check.is_safe:
                    step.status = StepStatus.AHA_INTERVENTION
                    step.aha_interventions.extend(health_check.interventions)
                    context.execution.add_user_log(f"⚠️ AHA intervention: {health_check.reason}")
                    return None
            
            # Execute the operation
            handler = self.operation_handlers.get(step.operation)
            if not handler:
                raise ValueError(f"Unknown operation: {step.operation}")
            
            result = await handler(step, context)
            
            # Store result
            step.output = result
            step.status = StepStatus.COMPLETED
            context.set_result(step.step_id, result)
            
            # Success message
            context.execution.add_user_log(f"✅ {step.name} completed")
            
            return result
            
        except Exception as e:
            step.status = StepStatus.FAILED
            step.error_message = str(e)
            context.execution.add_user_log(f"❌ {step.name} failed: {str(e)}")
            logger.error(f"Step execution failed: {e}\n{traceback.format_exc()}")
            raise
        
        finally:
            step.completed_at = datetime.now()
            if step.started_at:
                duration = step.completed_at - step.started_at
                step.duration_ms = int(duration.total_seconds() * 1000)
    
    # Operation handlers
    
    async def _handle_attach(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle attach() operation"""
        if not LLMDATA_AVAILABLE:
            raise RuntimeError("LLMData not available for attach operation")
        
        files = step.parameters.get('files', context.file_attachments)
        if not files:
            raise ValueError("No files to attach")
        
        attachment_collection = attach(*files)
        context.current_attachments = attachment_collection
        
        return attachment_collection
    
    async def _handle_load_auto(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle load.auto() operation"""
        if not context.current_attachments:
            raise ValueError("No attachments to load")
        
        processed = context.current_attachments | load.auto()
        context.current_attachments = processed
        
        return processed
    
    async def _handle_present_markdown(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle present.markdown() operation"""
        if not context.current_attachments:
            raise ValueError("No attachments to present")
        
        presented = context.current_attachments | present.markdown()
        context.current_attachments = presented
        
        return presented
    
    async def _handle_llm_message(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle llm_message() operation"""
        if not LLMDATA_AVAILABLE:
            raise RuntimeError("LLMData not available for llm_message")
        
        message_content = step.parameters.get('content', step.parameters.get('message', ''))
        if not message_content:
            raise ValueError("No message content provided")
        
        # Create LLM message with attachments if available
        if context.file_attachments:
            message = llm_message(message_content, *context.file_attachments)
        else:
            message = llm_message(message_content)
        
        context.current_message = message
        return message
    
    async def _handle_chat(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle chat() operation"""
        if not LLMDATA_AVAILABLE:
            raise RuntimeError("LLMData not available for chat")
        
        if not context.current_message:
            raise ValueError("No message to send to chat")
        
        # Get provider from parameters
        provider_name = step.parameters.get('provider', 'claude')
        model = step.parameters.get('model', None)
        
        if provider_name == 'claude':
            provider = claude(model=model) if model else claude()
        elif provider_name == 'openai':
            provider = openai(model=model) if model else openai()
        else:
            raise ValueError(f"Unknown provider: {provider_name}")
        
        # Execute chat
        response = context.current_message | chat(provider)
        context.current_message = response
        
        return response
    
    async def _handle_papers_discover(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle papers discovery operations"""
        if not TIDYLLM_PAPERS_AVAILABLE:
            raise RuntimeError("TidyLLM-Papers not available")
        
        query = step.parameters.get('query', step.parameters.get('search_query', ''))
        if not query:
            raise ValueError("No search query provided")
        
        limit = step.parameters.get('limit', 10)
        discovery_type = step.parameters.get('type', 'arxiv')
        
        if discovery_type == 'arxiv':
            paper_collection = papers(query) | discover.arxiv(limit=limit)
        elif discovery_type == 'recent':
            days = step.parameters.get('days', 30)
            paper_collection = papers(query) | discover.recent(days=days)
        else:
            paper_collection = papers(query) | discover.arxiv(limit=limit)
        
        context.paper_collection = paper_collection
        return paper_collection
    
    async def _handle_papers_analyze(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle papers analysis operations"""
        if not context.paper_collection:
            raise ValueError("No paper collection to analyze")
        
        analysis_type = step.parameters.get('type', 'content')
        
        if analysis_type == 'content':
            result = context.paper_collection | analyze.content()
        elif analysis_type == 'abstracts':
            result = context.paper_collection | analyze.abstracts()
        elif analysis_type == 'metadata':
            result = context.paper_collection | analyze.metadata()
        else:
            result = context.paper_collection | analyze.content()
        
        context.paper_collection = result
        return result
    
    async def _handle_save_file(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle file saving operations"""
        content = step.parameters.get('content')
        filename = step.parameters.get('filename')
        
        if not content or not filename:
            raise ValueError("Content and filename required for save_file")
        
        filepath = Path(filename)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            if isinstance(content, str):
                f.write(content)
            else:
                f.write(str(content))
        
        context.execution.output_files.append(str(filepath))
        return str(filepath)
    
    async def _handle_generate_report(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle report generation"""
        template = step.parameters.get('template', 'default')
        title = step.parameters.get('title', 'Analysis Report')
        
        # Gather content from context
        report_sections = []
        
        # Add header
        report_sections.append(f"# {title}")
        report_sections.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report_sections.append("")
        
        # Add attachments summary if available
        if context.current_attachments and hasattr(context.current_attachments, 'text_content'):
            report_sections.append("## Document Analysis")
            report_sections.append(context.current_attachments.text_content)
            report_sections.append("")
        
        # Add LLM analysis if available
        if context.current_message and hasattr(context.current_message, 'content'):
            report_sections.append("## Analysis Results")
            report_sections.append(context.current_message.content)
            report_sections.append("")
        
        # Add paper analysis if available
        if context.paper_collection:
            report_sections.append("## Research Analysis")
            report_sections.append(context.paper_collection.summary())
            report_sections.append("")
        
        report_content = '\n'.join(report_sections)
        return report_content
    
    async def _handle_compare_documents(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle document comparison"""
        if not context.current_attachments:
            raise ValueError("No documents to compare")
        
        comparison_prompt = step.parameters.get('prompt', 
            "Compare these documents and highlight key differences, similarities, and insights.")
        
        # Create comparison message
        message = llm_message(comparison_prompt)
        if hasattr(context.current_attachments, 'text_content'):
            message.content += "\n\n" + context.current_attachments.text_content
        
        # Get comparison result
        provider = claude()  # Default to Claude for comparisons
        result = message | chat(provider)
        
        return result
    
    async def _handle_custom_operation(self, step: MacroStep, context: ExecutionContext) -> Any:
        """Handle custom operations defined in macro"""
        operation_code = step.parameters.get('code', '')
        if not operation_code:
            raise ValueError("No custom operation code provided")
        
        # Simple eval-based execution (could be enhanced with safer execution)
        # For now, just return the parameters as result
        return step.parameters

class MacroEngine:
    """
    Main engine for executing macro workflows
    
    Orchestrates the execution of macro steps with AHA monitoring,
    progress tracking, and error handling.
    """
    
    def __init__(self, aha_monitor: AHAMacroMonitor = None):
        self.aha_monitor = aha_monitor or AHAMacroMonitor()
        self.step_executor = StepExecutor(self.aha_monitor)
        self.active_executions: Dict[str, ExecutionContext] = {}
        
    async def execute_macro(self, execution: MacroExecution) -> MacroResult:
        """
        Execute a complete macro workflow
        
        Args:
            execution: The macro execution to run
            
        Returns:
            MacroResult with execution results and status
        """
        
        execution.started_at = datetime.now()
        execution.status = MacroStatus.RUNNING
        execution.add_user_log(f"🚀 Starting macro execution: {execution.macro_name}")
        
        context = ExecutionContext(execution)
        self.active_executions[execution.execution_id] = context
        
        try:
            # Execute each step
            for i, step in enumerate(execution.steps):
                execution.current_step = i
                execution.progress_percentage = (i / len(execution.steps)) * 100
                
                logger.info(f"Executing step {i+1}/{len(execution.steps)}: {step.name}")
                
                try:
                    result = await self.step_executor.execute_step(step, context)
                    
                except Exception as e:
                    # Handle step failure
                    execution.add_user_log(f"🔥 Step failed: {step.name}")
                    if context.error_count < context.max_retries:
                        context.error_count += 1
                        execution.add_user_log(f"🔄 Retrying step ({context.error_count}/{context.max_retries})")
                        continue
                    else:
                        execution.status = MacroStatus.FAILED
                        raise
            
            # All steps completed successfully
            execution.status = MacroStatus.COMPLETED
            execution.completed_at = datetime.now()
            execution.progress_percentage = 100.0
            
            # Calculate total duration
            if execution.started_at:
                duration = execution.completed_at - execution.started_at
                execution.total_duration_ms = int(duration.total_seconds() * 1000)
            
            execution.add_user_log("🎉 Macro execution completed successfully!")
            
        except Exception as e:
            execution.status = MacroStatus.FAILED
            execution.completed_at = datetime.now()
            execution.add_user_log(f"💥 Macro execution failed: {str(e)}")
            logger.error(f"Macro execution failed: {e}\n{traceback.format_exc()}")
        
        finally:
            # Cleanup
            context.cleanup_temp_files()
            
            # Remove from active executions
            if execution.execution_id in self.active_executions:
                del self.active_executions[execution.execution_id]
        
        # Create result
        result = self._create_result(execution, context)
        return result
    
    def _create_result(self, execution: MacroExecution, context: ExecutionContext) -> MacroResult:
        """Create final result from execution"""
        
        completed_steps = sum(1 for step in execution.steps if step.status == StepStatus.COMPLETED)
        
        # Determine primary output
        primary_output = None
        if context.current_message:
            primary_output = context.current_message.content
        elif context.paper_collection:
            primary_output = context.paper_collection.summary()
        elif context.intermediate_results:
            primary_output = list(context.intermediate_results.values())[-1]
        
        # Calculate health score
        health_scores = [step.health_score for step in execution.steps if step.health_score < 1.0]
        overall_health = min(health_scores) if health_scores else execution.overall_health_score
        
        # Create summary
        duration_sec = (execution.total_duration_ms / 1000.0) if execution.total_duration_ms else 0
        
        if execution.status == MacroStatus.COMPLETED:
            success_msg = f"✅ Macro [{execution.macro_name}] completed successfully in {duration_sec:.1f} seconds"
        else:
            success_msg = f"❌ Macro [{execution.macro_name}] failed after {completed_steps} steps"
        
        return MacroResult(
            execution_id=execution.execution_id,
            macro_name=execution.macro_name,
            status=execution.status,
            primary_output=primary_output,
            generated_files=execution.output_files,
            intermediate_results=context.intermediate_results,
            execution_summary=f"Executed {completed_steps}/{len(execution.steps)} steps",
            steps_completed=completed_steps,
            total_steps=len(execution.steps),
            duration_seconds=duration_sec,
            health_score=overall_health,
            safety_issues=execution.safety_interventions,
            aha_recommendations=[alert.get('recommendation', '') for alert in execution.aha_alerts],
            user_summary=f"Macro [{execution.macro_name}] processed with {completed_steps} steps completed",
            success_message=success_msg
        )
    
    def get_execution_status(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Get current execution status"""
        context = self.active_executions.get(execution_id)
        if not context:
            return None
        
        execution = context.execution
        return {
            'execution_id': execution_id,
            'status': execution.status.value,
            'progress_percentage': execution.progress_percentage,
            'current_step': execution.current_step,
            'total_steps': len(execution.steps),
            'current_operation': execution.current_operation,
            'user_log': execution.user_visible_log[-10:],  # Last 10 messages
            'health_score': execution.overall_health_score
        }

__all__ = [
    'ExecutionContext',
    'StepExecutor', 
    'MacroEngine'
]