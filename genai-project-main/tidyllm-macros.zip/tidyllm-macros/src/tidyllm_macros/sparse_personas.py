#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Sparse Persona System - Peer Review and Multi-Expert Analysis

Integrates sparse agreements with persona-based peer review for multi-perspective
analysis. Enables programmatic second opinions and expert validation.
"""

from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime
import logging

from .core import MacroStep, MacroExecution, MacroResult
from .sparse_integration import SparseAgreementLoader, MacroExpander
from .tidyverse_pipe import TidyData, DocumentCollection, PaperCollection, ResponseCollection

logger = logging.getLogger(__name__)

@dataclass
class PersonaDefinition:
    """Definition of an expert persona for review/analysis"""
    name: str
    expertise_domains: List[str]
    perspective: str
    validation_criteria: List[str]
    bias_tendencies: List[str] = None
    confidence_factors: Dict[str, float] = None
    
    def __post_init__(self):
        if self.bias_tendencies is None:
            self.bias_tendencies = []
        if self.confidence_factors is None:
            self.confidence_factors = {}

@dataclass
class PersonaAnalysis:
    """Result of persona-based analysis"""
    persona_name: str
    analysis_score: float
    confidence_level: float
    key_findings: List[str]
    concerns_raised: List[str]
    recommendations: List[str]
    bias_adjustments: Dict[str, float] = None
    
    def __post_init__(self):
        if self.bias_adjustments is None:
            self.bias_adjustments = {}

class PersonaRegistry:
    """Registry of expert personas for peer review"""
    
    def __init__(self):
        self.personas: Dict[str, PersonaDefinition] = {}
        self._populate_default_personas()
    
    def register_persona(self, persona: PersonaDefinition):
        """Register an expert persona"""
        self.personas[persona.name] = persona
        logger.info(f"Registered persona: {persona.name}")
    
    def get_persona(self, name: str) -> Optional[PersonaDefinition]:
        """Get persona by name"""
        return self.personas.get(name)
    
    def _populate_default_personas(self):
        """Populate with built-in expert personas"""
        
        # Legal Expert
        self.register_persona(PersonaDefinition(
            name="Legal Expert",
            expertise_domains=["contracts", "compliance", "regulatory", "liability", "intellectual_property"],
            perspective="legal_analysis",
            validation_criteria=["legal_soundness", "regulatory_compliance", "risk_exposure", "enforceability"],
            bias_tendencies=["conservative_risk_assessment", "regulatory_focus"],
            confidence_factors={"contract_analysis": 0.95, "compliance_check": 0.90, "general_legal": 0.85}
        ))
        
        # Risk Analyst
        self.register_persona(PersonaDefinition(
            name="Risk Analyst", 
            expertise_domains=["risk_assessment", "probability", "impact_analysis", "mitigation", "scenario_planning"],
            perspective="risk_management",
            validation_criteria=["risk_quantification", "scenario_coverage", "mitigation_adequacy"],
            bias_tendencies=["pessimistic_scenarios", "quantitative_focus"],
            confidence_factors={"risk_assessment": 0.92, "probability_analysis": 0.88, "general_risk": 0.80}
        ))
        
        # Technical Reviewer
        self.register_persona(PersonaDefinition(
            name="Technical Reviewer",
            expertise_domains=["methodology", "implementation", "accuracy", "feasibility", "best_practices"],
            perspective="technical_validation", 
            validation_criteria=["technical_correctness", "methodology_soundness", "implementation_feasibility"],
            bias_tendencies=["perfectionism", "methodology_focus"],
            confidence_factors={"technical_analysis": 0.94, "code_review": 0.96, "methodology": 0.88}
        ))
        
        # Business Analyst
        self.register_persona(PersonaDefinition(
            name="Business Analyst",
            expertise_domains=["business_value", "roi", "market_analysis", "strategy", "operations"],
            perspective="business_impact",
            validation_criteria=["business_value", "market_viability", "operational_impact", "strategic_alignment"],
            bias_tendencies=["roi_focus", "market_driven"],
            confidence_factors={"business_analysis": 0.87, "market_analysis": 0.82, "roi_calculation": 0.90}
        ))
        
        # Academic Peer Reviewer  
        self.register_persona(PersonaDefinition(
            name="Academic Peer Reviewer",
            expertise_domains=["research_methodology", "statistical_analysis", "literature_review", "academic_writing"],
            perspective="academic_rigor",
            validation_criteria=["methodological_rigor", "statistical_validity", "literature_coverage", "reproducibility"],
            bias_tendencies=["methodological_perfectionism", "statistical_conservatism"],
            confidence_factors={"methodology_review": 0.93, "statistical_analysis": 0.89, "literature_review": 0.91}
        ))
        
        # Ethics Reviewer
        self.register_persona(PersonaDefinition(
            name="Ethics Reviewer",
            expertise_domains=["ethical_implications", "bias_detection", "fairness", "privacy", "safety"],
            perspective="ethical_analysis",
            validation_criteria=["ethical_soundness", "bias_absence", "fairness_assessment", "privacy_protection"],
            bias_tendencies=["cautious_approach", "stakeholder_focus"],
            confidence_factors={"ethics_review": 0.86, "bias_detection": 0.84, "privacy_analysis": 0.88}
        ))

class PersonaInvoker:
    """Invokes expert personas for peer review and analysis"""
    
    def __init__(self, persona_registry: PersonaRegistry = None, sparse_loader: SparseAgreementLoader = None):
        self.persona_registry = persona_registry or PersonaRegistry()
        self.sparse_loader = sparse_loader or SparseAgreementLoader()
        self.analysis_cache: Dict[str, PersonaAnalysis] = {}
    
    def invoke_persona(self, persona_name: str, data: TidyData, context: Dict[str, Any] = None) -> TidyData:
        """Invoke an expert persona to analyze data"""
        
        context = context or {}
        persona = self.persona_registry.get_persona(persona_name)
        
        if not persona:
            # Try to find in sparse agreements
            sparse_def = self.sparse_loader.find_sparse_agreement(persona_name)
            if sparse_def:
                persona = self._create_persona_from_sparse(persona_name, sparse_def)
            else:
                # Create intelligent persona based on name
                persona = self._create_intelligent_persona(persona_name)
        
        if not persona:
            logger.warning(f"Could not create or find persona: {persona_name}")
            return data
        
        # Apply persona perspective to data
        analysis = self._apply_persona_analysis(persona, data, context)
        
        # Add persona analysis to data
        enhanced_data = self._enhance_data_with_persona_analysis(data, persona_name, analysis)
        
        return enhanced_data
    
    def multi_persona_review(self, persona_names: List[str], data: TidyData, consensus_threshold: float = 0.7) -> TidyData:
        """Get reviews from multiple personas and calculate consensus"""
        
        persona_analyses = {}
        
        # Get analysis from each persona
        for persona_name in persona_names:
            try:
                enhanced_data = self.invoke_persona(persona_name, data)
                # Extract persona analysis from enhanced data
                analysis_key = f"{persona_name.lower().replace(' ', '_')}_analysis"
                if hasattr(enhanced_data, 'data') and enhanced_data.data:
                    for item in enhanced_data.data:
                        if analysis_key in item:
                            persona_analyses[persona_name] = item[analysis_key]
                            break
            except Exception as e:
                logger.error(f"Error invoking persona {persona_name}: {e}")
        
        # Calculate consensus
        consensus_data = self._calculate_consensus(persona_analyses, consensus_threshold)
        
        # Add consensus analysis to data
        final_data = self._enhance_data_with_consensus(data, consensus_data, persona_analyses)
        
        return final_data
    
    def _create_persona_from_sparse(self, persona_name: str, sparse_def: Dict[str, Any]) -> PersonaDefinition:
        """Create persona from sparse agreement definition"""
        
        return PersonaDefinition(
            name=persona_name,
            expertise_domains=sparse_def.get('tools_to_use', []),
            perspective=sparse_def.get('action', 'general_analysis'),
            validation_criteria=sparse_def.get('parameters', []),
            bias_tendencies=[],
            confidence_factors={"general": 0.85}
        )
    
    def _create_intelligent_persona(self, persona_name: str) -> PersonaDefinition:
        """Create persona based on intelligent name analysis"""
        
        name_lower = persona_name.lower()
        
        # Define persona patterns
        persona_patterns = {
            'legal': {
                'domains': ['contracts', 'compliance', 'legal'],
                'perspective': 'legal_analysis',
                'criteria': ['legal_soundness', 'compliance']
            },
            'risk': {
                'domains': ['risk_assessment', 'mitigation', 'analysis'],
                'perspective': 'risk_management', 
                'criteria': ['risk_quantification', 'mitigation']
            },
            'technical': {
                'domains': ['methodology', 'implementation', 'accuracy'],
                'perspective': 'technical_validation',
                'criteria': ['technical_correctness', 'feasibility']
            },
            'business': {
                'domains': ['business_value', 'strategy', 'operations'],
                'perspective': 'business_impact',
                'criteria': ['business_value', 'strategic_alignment']
            },
            'academic': {
                'domains': ['research', 'methodology', 'peer_review'],
                'perspective': 'academic_rigor',
                'criteria': ['methodological_rigor', 'reproducibility']
            },
            'ethics': {
                'domains': ['ethics', 'fairness', 'bias', 'safety'],
                'perspective': 'ethical_analysis',
                'criteria': ['ethical_soundness', 'fairness']
            }
        }
        
        # Match persona name to pattern
        for pattern, definition in persona_patterns.items():
            if pattern in name_lower:
                return PersonaDefinition(
                    name=persona_name,
                    expertise_domains=definition['domains'],
                    perspective=definition['perspective'],
                    validation_criteria=definition['criteria'],
                    bias_tendencies=[],
                    confidence_factors={"general": 0.80}
                )
        
        # Generic fallback
        return PersonaDefinition(
            name=persona_name,
            expertise_domains=['general_analysis'],
            perspective='general_review',
            validation_criteria=['quality_check'],
            bias_tendencies=[],
            confidence_factors={"general": 0.75}
        )
    
    def _apply_persona_analysis(self, persona: PersonaDefinition, data: TidyData, context: Dict[str, Any]) -> PersonaAnalysis:
        """Apply persona's perspective to analyze data"""
        
        # Simulate persona analysis (in real implementation, this would invoke LLM with persona context)
        analysis_score = self._calculate_persona_score(persona, data, context)
        confidence_level = self._calculate_confidence(persona, data, context)
        
        key_findings = self._extract_key_findings(persona, data)
        concerns_raised = self._identify_concerns(persona, data)
        recommendations = self._generate_recommendations(persona, data)
        
        return PersonaAnalysis(
            persona_name=persona.name,
            analysis_score=analysis_score,
            confidence_level=confidence_level,
            key_findings=key_findings,
            concerns_raised=concerns_raised,
            recommendations=recommendations
        )
    
    def _calculate_persona_score(self, persona: PersonaDefinition, data: TidyData, context: Dict[str, Any]) -> float:
        """Calculate persona-specific analysis score"""
        
        # Simplified scoring based on persona expertise and data characteristics
        base_score = 0.75
        
        # Adjust based on persona expertise alignment with data type
        if hasattr(data, 'data') and data.data:
            sample_item = data.data[0] if data.data else {}
            
            # Check alignment with expertise domains
            expertise_match = 0.0
            for domain in persona.expertise_domains:
                if any(domain in str(value).lower() for value in sample_item.values()):
                    expertise_match += 0.1
            
            base_score = min(base_score + expertise_match, 1.0)
        
        return base_score
    
    def _calculate_confidence(self, persona: PersonaDefinition, data: TidyData, context: Dict[str, Any]) -> float:
        """Calculate persona confidence in analysis"""
        
        # Use persona confidence factors
        data_type = type(data).__name__.lower()
        
        for factor_type, confidence in persona.confidence_factors.items():
            if factor_type in data_type or any(domain in data_type for domain in persona.expertise_domains):
                return confidence
        
        return persona.confidence_factors.get("general", 0.80)
    
    def _extract_key_findings(self, persona: PersonaDefinition, data: TidyData) -> List[str]:
        """Extract key findings from persona perspective"""
        
        findings = []
        
        # Generate persona-specific findings based on expertise
        if "legal" in persona.perspective:
            findings.append("Legal compliance assessment completed")
            findings.append("Contract terms reviewed for enforceability")
        elif "risk" in persona.perspective:
            findings.append("Risk factors identified and quantified")
            findings.append("Mitigation strategies evaluated")
        elif "technical" in persona.perspective:
            findings.append("Technical methodology validated")
            findings.append("Implementation feasibility confirmed")
        elif "business" in persona.perspective:
            findings.append("Business value proposition assessed")
            findings.append("Strategic alignment evaluated")
        else:
            findings.append(f"Analysis completed from {persona.perspective} perspective")
        
        return findings
    
    def _identify_concerns(self, persona: PersonaDefinition, data: TidyData) -> List[str]:
        """Identify concerns from persona perspective"""
        
        concerns = []
        
        # Generate persona-specific concerns based on bias tendencies
        for bias in persona.bias_tendencies:
            if "conservative" in bias:
                concerns.append("Recommend conservative approach due to uncertainty")
            elif "perfectionism" in bias:
                concerns.append("Additional validation recommended for completeness")
            elif "pessimistic" in bias:
                concerns.append("Consider worst-case scenarios in planning")
        
        return concerns
    
    def _generate_recommendations(self, persona: PersonaDefinition, data: TidyData) -> List[str]:
        """Generate recommendations from persona perspective"""
        
        recommendations = []
        
        # Generate persona-specific recommendations
        for criterion in persona.validation_criteria:
            if "compliance" in criterion:
                recommendations.append("Ensure full regulatory compliance before proceeding")
            elif "risk" in criterion:
                recommendations.append("Implement recommended risk mitigation measures")
            elif "technical" in criterion:
                recommendations.append("Validate technical approach with additional testing")
            elif "business" in criterion:
                recommendations.append("Assess business impact and ROI before implementation")
        
        return recommendations
    
    def _enhance_data_with_persona_analysis(self, data: TidyData, persona_name: str, analysis: PersonaAnalysis) -> TidyData:
        """Add persona analysis results to data"""
        
        if not hasattr(data, 'data') or not data.data:
            return data
        
        # Add persona analysis to each data item
        enhanced_items = []
        analysis_key = f"{persona_name.lower().replace(' ', '_')}_analysis"
        
        for item in data.data:
            enhanced_item = item.copy()
            enhanced_item[analysis_key] = {
                "score": analysis.analysis_score,
                "confidence": analysis.confidence_level,
                "findings": analysis.key_findings,
                "concerns": analysis.concerns_raised,
                "recommendations": analysis.recommendations
            }
            enhanced_items.append(enhanced_item)
        
        # Create new instance with enhanced data
        result = type(data)(data=enhanced_items, metadata=data.metadata.copy())
        result.metadata[f"{persona_name}_reviewed"] = True
        result.metadata[f"{persona_name}_score"] = analysis.analysis_score
        
        return result
    
    def _calculate_consensus(self, persona_analyses: Dict[str, Any], threshold: float) -> Dict[str, Any]:
        """Calculate consensus across multiple persona analyses"""
        
        if not persona_analyses:
            return {"consensus_reached": False, "consensus_score": 0.0}
        
        # Extract scores from analyses
        scores = []
        for persona_name, analysis in persona_analyses.items():
            if isinstance(analysis, dict) and "score" in analysis:
                scores.append(analysis["score"])
        
        if not scores:
            return {"consensus_reached": False, "consensus_score": 0.0}
        
        # Calculate consensus metrics
        avg_score = sum(scores) / len(scores)
        score_variance = sum((score - avg_score) ** 2 for score in scores) / len(scores)
        consensus_score = avg_score * (1 - score_variance)  # Penalize high variance
        
        return {
            "consensus_reached": consensus_score >= threshold,
            "consensus_score": consensus_score,
            "average_score": avg_score,
            "score_variance": score_variance,
            "persona_count": len(persona_analyses)
        }
    
    def _enhance_data_with_consensus(self, data: TidyData, consensus_data: Dict[str, Any], persona_analyses: Dict[str, Any]) -> TidyData:
        """Add consensus analysis to data"""
        
        if not hasattr(data, 'data') or not data.data:
            return data
        
        enhanced_items = []
        
        for item in data.data:
            enhanced_item = item.copy()
            enhanced_item["consensus_analysis"] = consensus_data
            enhanced_item["persona_count"] = len(persona_analyses)
            enhanced_item["multi_persona_validated"] = consensus_data["consensus_reached"]
            enhanced_items.append(enhanced_item)
        
        result = type(data)(data=enhanced_items, metadata=data.metadata.copy())
        result.metadata["multi_persona_review"] = True
        result.metadata["consensus_score"] = consensus_data["consensus_score"]
        
        return result

# Convenience functions for pipeline integration
def invoke_persona(persona_name: str) -> Callable[[TidyData], TidyData]:
    """Create pipeline verb for invoking a persona"""
    def _invoke(tidy_data: TidyData) -> TidyData:
        invoker = PersonaInvoker()
        return invoker.invoke_persona(persona_name, tidy_data)
    return _invoke

def multi_persona_review(persona_names: List[str], consensus_threshold: float = 0.7) -> Callable[[TidyData], TidyData]:
    """Create pipeline verb for multi-persona review"""
    def _multi_review(tidy_data: TidyData) -> TidyData:
        invoker = PersonaInvoker()
        return invoker.multi_persona_review(persona_names, tidy_data, consensus_threshold)
    return _multi_review

__all__ = [
    'PersonaDefinition',
    'PersonaAnalysis', 
    'PersonaRegistry',
    'PersonaInvoker',
    'invoke_persona',
    'multi_persona_review'
]