#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TidyLLM Macros AHA Monitoring Integration

Integrates AHA system monitoring with macro execution to ensure
safe, healthy, and transparent workflow execution.
"""

import logging
from typing import Dict, List, Any, Optional, Callable
from datetime import datetime
from dataclasses import dataclass
from pathlib import Path

from .core import MacroExecution, MacroStep, StepStatus

logger = logging.getLogger(__name__)

# Integration with existing AHA system
try:
    import sys
    aha_path = Path(__file__).parent.parent / 'health'
    if str(aha_path) not in sys.path:
        sys.path.insert(0, str(aha_path))
    
    from aha_system import AHAMonitor, AHAMode, HealthTrend, AHAAlert
    from reorg_department import ReorgDepartment, HealthStatus
    AHA_AVAILABLE = True
except ImportError:
    AHA_AVAILABLE = False
    logger.warning("AHA system not available - monitoring limited")

@dataclass
class HealthCheck:
    """Result of a health check on macro step"""
    is_safe: bool
    health_score: float
    reason: str
    warnings: List[str]
    interventions: List[str]
    recommendations: List[str]

@dataclass
class ExecutionSafeguard:
    """Safeguards for macro execution"""
    max_steps: int = 50
    max_duration_minutes: int = 30
    max_file_size_mb: int = 100
    max_memory_mb: int = 512
    allowed_operations: List[str] = None
    blocked_operations: List[str] = None
    
    def __post_init__(self):
        if self.allowed_operations is None:
            self.allowed_operations = [
                'attach', 'load_auto', 'present_markdown', 'chat', 'llm_message',
                'papers_discover', 'papers_analyze', 'papers_cite',
                'save_file', 'load_file', 'generate_report', 'compare_documents'
            ]
        
        if self.blocked_operations is None:
            self.blocked_operations = [
                'system_call', 'file_delete', 'network_request', 'database_modify'
            ]

class MacroHealthChecker:
    """
    Health checker specifically for macro operations
    
    Provides safety checks, resource monitoring, and operation validation
    for macro execution steps.
    """
    
    def __init__(self, safeguards: ExecutionSafeguard = None):
        self.safeguards = safeguards or ExecutionSafeguard()
        self.health_history: Dict[str, List[float]] = {}
        
    def check_step_safety(self, step: MacroStep, context: Any) -> HealthCheck:
        """
        Check if a macro step is safe to execute
        
        Args:
            step: The macro step to check
            context: Execution context
            
        Returns:
            HealthCheck with safety assessment
        """
        
        warnings = []
        interventions = []
        recommendations = []
        is_safe = True
        health_score = 1.0
        
        # Check operation whitelist/blacklist
        if step.operation in self.safeguards.blocked_operations:
            is_safe = False
            interventions.append(f"Operation '{step.operation}' is blocked for safety")
            health_score = 0.0
        
        elif step.operation not in self.safeguards.allowed_operations:
            warnings.append(f"Operation '{step.operation}' not in allowed list")
            health_score = 0.8
        
        # Check resource limits
        resource_check = self._check_resource_limits(step, context)
        if not resource_check['safe']:
            warnings.extend(resource_check['warnings'])
            health_score = min(health_score, resource_check['health_score'])
        
        # Check parameter safety
        param_check = self._check_parameter_safety(step)
        if not param_check['safe']:
            warnings.extend(param_check['warnings'])
            health_score = min(health_score, param_check['health_score'])
        
        # Generate recommendations
        if health_score < 0.9:
            recommendations.append("Consider reviewing step parameters for optimization")
        
        if warnings:
            recommendations.append("Monitor execution closely due to safety warnings")
        
        return HealthCheck(
            is_safe=is_safe,
            health_score=health_score,
            reason="Step safety assessment completed",
            warnings=warnings,
            interventions=interventions,
            recommendations=recommendations
        )
    
    def _check_resource_limits(self, step: MacroStep, context: Any) -> Dict[str, Any]:
        """Check resource limits for step execution"""
        warnings = []
        safe = True
        health_score = 1.0
        
        # Check file size limits (if working with files)
        if 'files' in step.parameters:
            files = step.parameters['files']
            if isinstance(files, list):
                for file_path in files:
                    if Path(file_path).exists():
                        size_mb = Path(file_path).stat().st_size / (1024 * 1024)
                        if size_mb > self.safeguards.max_file_size_mb:
                            warnings.append(f"File {file_path} ({size_mb:.1f}MB) exceeds limit")
                            health_score = min(health_score, 0.7)
        
        # Check execution time estimates
        if hasattr(context, 'execution'):
            execution = context.execution
            if execution.started_at:
                elapsed = (datetime.now() - execution.started_at).total_seconds() / 60
                if elapsed > self.safeguards.max_duration_minutes:
                    warnings.append(f"Execution time ({elapsed:.1f}min) approaching limit")
                    health_score = min(health_score, 0.6)
        
        return {
            'safe': safe,
            'health_score': health_score,
            'warnings': warnings
        }
    
    def _check_parameter_safety(self, step: MacroStep) -> Dict[str, Any]:
        """Check safety of step parameters"""
        warnings = []
        safe = True
        health_score = 1.0
        
        # Check for suspicious parameters
        suspicious_patterns = ['../', 'rm ', 'del ', 'DROP ', 'DELETE ']
        
        for param_name, param_value in step.parameters.items():
            if isinstance(param_value, str):
                for pattern in suspicious_patterns:
                    if pattern in param_value:
                        warnings.append(f"Suspicious pattern '{pattern}' in {param_name}")
                        health_score = min(health_score, 0.5)
        
        return {
            'safe': safe,
            'health_score': health_score,
            'warnings': warnings
        }
    
    def track_step_health(self, step_id: str, health_score: float):
        """Track health score history for a step"""
        if step_id not in self.health_history:
            self.health_history[step_id] = []
        
        self.health_history[step_id].append(health_score)
        
        # Keep only recent history
        if len(self.health_history[step_id]) > 10:
            self.health_history[step_id] = self.health_history[step_id][-10:]
    
    def get_health_trend(self, step_id: str) -> Optional[str]:
        """Get health trend for a step"""
        if step_id not in self.health_history or len(self.health_history[step_id]) < 3:
            return None
        
        recent_scores = self.health_history[step_id][-3:]
        
        if all(recent_scores[i] > recent_scores[i-1] for i in range(1, len(recent_scores))):
            return "improving"
        elif all(recent_scores[i] < recent_scores[i-1] for i in range(1, len(recent_scores))):
            return "degrading"
        else:
            return "stable"

class AHAMacroMonitor:
    """
    AHA system integration for macro monitoring
    
    Provides continuous monitoring, health alerts, and intervention
    capabilities for macro execution workflows.
    """
    
    def __init__(self, codebase_root: str = None, mode: str = "active"):
        self.codebase_root = Path(codebase_root) if codebase_root else Path.cwd()
        self.health_checker = MacroHealthChecker()
        self.alerts: List[AHAAlert] = []
        
        # Initialize AHA system if available
        self.aha_monitor = None
        if AHA_AVAILABLE:
            try:
                aha_mode = AHAMode.ACTIVE if mode == "active" else AHAMode.PASSIVE
                self.aha_monitor = AHAMonitor(str(self.codebase_root), aha_mode)
                logger.info("AHA system initialized for macro monitoring")
            except Exception as e:
                logger.warning(f"Failed to initialize AHA system: {e}")
        
    async def check_step_health(self, step: MacroStep, context: Any) -> HealthCheck:
        """
        Comprehensive health check for macro step
        
        Combines macro-specific checks with AHA system monitoring
        """
        
        # Basic macro health check
        macro_health = self.health_checker.check_step_safety(step, context)
        
        # AHA system health check if available
        if self.aha_monitor:
            try:
                # Run AHA health check on codebase
                aha_report = self.aha_monitor.reorg_dept.run_health_check()
                
                # Incorporate AHA findings
                if aha_report.overall_status != HealthStatus.HEALTHY:
                    macro_health.warnings.append(f"AHA system reports: {aha_report.overall_status.value}")
                    macro_health.health_score = min(macro_health.health_score, 0.8)
                
                # Check for critical AHA violations
                critical_violations = [v for v in aha_report.violations if v.severity == HealthStatus.CRITICAL]
                if critical_violations:
                    macro_health.interventions.append("Critical AHA violations detected - execution may be unsafe")
                    macro_health.is_safe = False
                
            except Exception as e:
                logger.warning(f"AHA health check failed: {e}")
                macro_health.warnings.append("AHA health check unavailable")
        
        # Track health score
        self.health_checker.track_step_health(step.step_id, macro_health.health_score)
        
        return macro_health
    
    def monitor_execution_progress(self, execution: MacroExecution) -> Dict[str, Any]:
        """
        Monitor overall execution health and progress
        
        Returns health metrics and recommendations for the execution
        """
        
        monitoring_data = {
            'execution_id': execution.execution_id,
            'overall_health_score': execution.overall_health_score,
            'current_step': execution.current_step,
            'progress_percentage': execution.progress_percentage,
            'alerts': [],
            'recommendations': []
        }
        
        # Check execution duration
        if execution.started_at:
            duration_minutes = (datetime.now() - execution.started_at).total_seconds() / 60
            if duration_minutes > 15:  # 15 minute warning
                monitoring_data['alerts'].append({
                    'type': 'duration_warning',
                    'message': f'Execution running for {duration_minutes:.1f} minutes'
                })
        
        # Check step health scores
        unhealthy_steps = [step for step in execution.steps if step.health_score < 0.8]
        if unhealthy_steps:
            monitoring_data['alerts'].append({
                'type': 'health_warning',
                'message': f'{len(unhealthy_steps)} steps have low health scores'
            })
        
        # Generate recommendations
        if execution.progress_percentage < 50 and duration_minutes > 10:
            monitoring_data['recommendations'].append('Consider optimizing slow-running steps')
        
        if len(unhealthy_steps) > len(execution.steps) * 0.3:
            monitoring_data['recommendations'].append('Review macro definition for safety improvements')
        
        return monitoring_data
    
    def create_alert(self, 
                    severity: str,
                    title: str, 
                    description: str,
                    execution_id: str,
                    recommendations: List[str] = None) -> Dict[str, Any]:
        """Create AHA-style alert for macro execution"""
        
        alert = {
            'alert_id': f"macro_{execution_id}_{len(self.alerts)}",
            'timestamp': datetime.now().isoformat(),
            'severity': severity,
            'category': 'macro_execution',
            'title': title,
            'description': description,
            'execution_id': execution_id,
            'recommendations': recommendations or [],
            'auto_fixable': False
        }
        
        self.alerts.append(alert)
        logger.warning(f"AHA Macro Alert: {title} - {description}")
        
        return alert
    
    def get_execution_health_summary(self, execution: MacroExecution) -> Dict[str, Any]:
        """Get comprehensive health summary for execution"""
        
        completed_steps = [step for step in execution.steps if step.status == StepStatus.COMPLETED]
        failed_steps = [step for step in execution.steps if step.status == StepStatus.FAILED]
        aha_interventions = [step for step in execution.steps if step.status == StepStatus.AHA_INTERVENTION]
        
        avg_health_score = 0.0
        if execution.steps:
            avg_health_score = sum(step.health_score for step in execution.steps) / len(execution.steps)
        
        return {
            'execution_id': execution.execution_id,
            'macro_name': execution.macro_name,
            'overall_status': execution.status.value,
            'health_score': avg_health_score,
            'steps_summary': {
                'total': len(execution.steps),
                'completed': len(completed_steps),
                'failed': len(failed_steps),
                'aha_interventions': len(aha_interventions)
            },
            'duration_seconds': execution.total_duration_ms / 1000 if execution.total_duration_ms else 0,
            'alerts_count': len([alert for alert in self.alerts if alert.get('execution_id') == execution.execution_id]),
            'safety_score': 1.0 - (len(failed_steps) + len(aha_interventions)) / len(execution.steps) if execution.steps else 1.0
        }

# Utility functions for macro monitoring
def create_safe_execution_environment() -> ExecutionSafeguard:
    """Create conservative safeguards for macro execution"""
    return ExecutionSafeguard(
        max_steps=20,
        max_duration_minutes=15,
        max_file_size_mb=50,
        max_memory_mb=256,
        allowed_operations=[
            'attach', 'load_auto', 'present_markdown', 'chat', 'llm_message',
            'save_file', 'load_file', 'generate_report', 'compare_documents'
        ],
        blocked_operations=[
            'system_call', 'file_delete', 'network_request', 'database_modify',
            'custom_operation'  # Block custom operations in safe mode
        ]
    )

def create_development_environment() -> ExecutionSafeguard:
    """Create permissive safeguards for development/testing"""
    return ExecutionSafeguard(
        max_steps=100,
        max_duration_minutes=60,
        max_file_size_mb=200,
        max_memory_mb=1024,
        # More permissive settings for development
    )

__all__ = [
    'HealthCheck',
    'ExecutionSafeguard', 
    'MacroHealthChecker',
    'AHAMacroMonitor',
    'create_safe_execution_environment',
    'create_development_environment'
]