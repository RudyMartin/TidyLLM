"""
Built-in TidyLLM Macros

This module contains the built-in macros that come pre-installed with the TidyLLM Macros system.
Each macro demonstrates progressive complexity and tidyverse-style workflows.
"""

from .mvr_peer_review import create_mvr_peer_review_macro, mvr_peer_review_pipeline

# Registry of all built-in macros
BUILT_IN_MACROS = {
    "mvr_peer_review": create_mvr_peer_review_macro,
    # Add more built-in macros here as they are created
}

def get_built_in_macro(name: str):
    """Get a built-in macro by name"""
    if name in BUILT_IN_MACROS:
        return BUILT_IN_MACROS[name]()
    else:
        raise ValueError(f"Unknown built-in macro: {name}")

def list_built_in_macros():
    """List all available built-in macros"""
    return list(BUILT_IN_MACROS.keys())

__all__ = [
    'BUILT_IN_MACROS',
    'get_built_in_macro', 
    'list_built_in_macros',
    'create_mvr_peer_review_macro',
    'mvr_peer_review_pipeline'
]