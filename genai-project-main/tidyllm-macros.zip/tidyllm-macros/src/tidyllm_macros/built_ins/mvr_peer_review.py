"""
MVR Peer Review Macro - Automated Model Validation Report Peer Review

Converts the sparse agreement "Automated MVR Peer Review Prompt" into a TidyLLM macro
with progressive complexity levels and tidyverse-style workflows.

Now enhanced with enterprise governance through TidyLLM Gateway integration.
"""
from typing import Dict, List, Any, Optional
from ..core import MacroDefinition, MacroStep, ComplexityLevel
from ..tidyverse_pipe import DocumentCollection

# Import enterprise context management
try:
    from tidyllm import set_enterprise_context, get_enterprise_context
    ENTERPRISE_CONTEXT_AVAILABLE = True
except ImportError:
    ENTERPRISE_CONTEXT_AVAILABLE = False

def create_mvr_peer_review_macro(user_id: str = None, department: str = None) -> MacroDefinition:
    """
    Create the MVR Peer Review macro with progressive complexity levels
    
    Args:
        user_id: User ID for enterprise audit trails
        department: Department for governance controls
    """
    
    # Set enterprise context if available
    if ENTERPRISE_CONTEXT_AVAILABLE and (user_id or department):
        set_enterprise_context(
            user_id=user_id or "mvr_analyst",
            department=department or "model_validation",
            audit_reason="MVR peer review macro execution",
            macro_name="mvr_peer_review"
        )
    
    # Simple Level - Basic compliance checking
    simple_steps = [
        MacroStep(
            step_id="parse_toc_001",
            name="parse_toc",
            description="Parse Table of Contents to section level 1.1.1.1",
            operation="extract",
            parameters={
                "field": "table_of_contents",
                "method": "structured_parsing",
                "depth": "1.1.1.1"
            },
            expected_output="List of section identifiers"
        ),
        MacroStep(
            step_id="identify_sections_002",
            name="identify_sections",
            description="Create ordered list of section identifiers",
            operation="mutate",
            parameters={
                "section_ids": "lambda x: extract_section_identifiers(x['table_of_contents'])",
                "total_sections": "lambda x: len(x['section_ids'])",
                "current_section": "lambda x: x['section_ids'][0] if x['section_ids'] else None"
            },
            expected_output="Section metadata with identifiers"
        ),
        MacroStep(
            step_id="extract_model_context_003",
            name="extract_model_context",
            description="Extract model type, risk tier, and validation scope",
            operation="mutate", 
            parameters={
                "model_type": "lambda x: extract_from_executive_summary(x, 'model_type')",
                "risk_tier": "lambda x: extract_from_executive_summary(x, 'risk_tier')",
                "validation_scope": "lambda x: determine_validation_scope(x)"
            },
            expected_output="Model context information"
        ),
        MacroStep(
            step_id="basic_compliance_check_004",
            name="basic_compliance_check",
            description="Perform basic MVS compliance assessment",
            operation="mutate",
            parameters={
                "compliance_status": "lambda x: basic_mvs_compliance_check(x)",
                "missing_sections": "lambda x: identify_missing_required_sections(x)",
                "completion_percentage": "lambda x: calculate_completion_percentage(x)"
            },
            expected_output="Basic compliance status"
        ),
        MacroStep(
            step_id="generate_basic_report_005",
            name="generate_basic_report",
            description="Generate basic compliance summary report",
            operation="reshape",
            parameters={
                "format": "compliance_summary",
                "include_fields": ["model_type", "risk_tier", "compliance_status", "completion_percentage"]
            },
            expected_output="Compliance summary report"
        )
    ]
    
    # Enhanced Level - Evidence tracing and logic analysis
    enhanced_steps = simple_steps + [
        MacroStep(
            step_id="section_analysis_006",
            name="section_by_section_analysis",
            description="Perform detailed section-by-section analysis with evidence tracing",
            operation="mutate",
            parameters={
                "section_analysis": "lambda x: analyze_sections_sequentially(x)",
                "evidence_mapping": "lambda x: map_conclusions_to_evidence(x)",
                "logic_trace": "lambda x: trace_logical_reasoning(x)"
            },
            expected_output="Detailed section analysis with evidence mapping"
        ),
        MacroStep(
            step_id="peer_review_challenges_007",
            name="peer_review_challenges",
            description="Generate peer review challenges and assess confidence levels",
            operation="mutate",
            parameters={
                "internal_contradictions": "lambda x: find_internal_contradictions(x)",
                "logic_gaps": "lambda x: identify_logic_gaps(x)",
                "peer_challenges": "lambda x: generate_peer_review_challenges(x)",
                "confidence_scores": "lambda x: calculate_confidence_scores(x)"
            },
            expected_output="Peer review challenges and confidence assessments"
        ),
        MacroStep(
            step_id="compliance_matrix_008",
            name="compliance_matrix",
            description="Create detailed compliance matrix with peer review insights",
            operation="reshape",
            parameters={
                "format": "detailed_matrix",
                "columns": [
                    "mvr_section", "mvs_requirements", "vst_sections", 
                    "review_narrative", "contradiction_summary", 
                    "peer_review_challenge", "conclusion", "confidence_score"
                ]
            },
            expected_output="Detailed compliance matrix"
        )
    ]
    
    # Advanced Level - AI-powered analysis with external validation
    advanced_steps = enhanced_steps + [
        MacroStep(
            step_id="external_search_009",
            name="external_contradiction_search",
            description="Search for external contradictions and regulatory conflicts",
            operation="mutate",
            parameters={
                "regulatory_updates": "lambda x: search_regulatory_updates(x)",
                "enforcement_actions": "lambda x: search_enforcement_actions(x)",
                "industry_criticism": "lambda x: search_industry_criticism(x)",
                "external_contradictions": "lambda x: identify_external_contradictions(x)"
            },
            expected_output="External contradiction analysis"
        ),
        MacroStep(
            step_id="advanced_persona_010",
            name="advanced_peer_analysis",
            description="Advanced AI-powered peer review with regulatory awareness",
            operation="invoke_persona",
            parameters={
                "persona": "MVR Validation Expert",
                "analysis_type": "advanced_peer_review",
                "include_external_evidence": True,
                "confidence_calibration": "regulatory_aware"
            },
            expected_output="AI-powered peer review analysis"
        ),
        MacroStep(
            step_id="monitoring_setup_011",
            name="real_time_monitoring",
            description="Setup real-time compliance monitoring and alerts",
            operation="mutate",
            parameters={
                "monitoring_alerts": "lambda x: setup_compliance_monitoring(x)",
                "risk_indicators": "lambda x: calculate_risk_indicators(x)",
                "escalation_triggers": "lambda x: identify_escalation_triggers(x)"
            },
            expected_output="Monitoring configuration"
        ),
        MacroStep(
            step_id="comprehensive_report_012",
            name="comprehensive_output",
            description="Generate comprehensive report with interactive dashboard",
            operation="reshape",
            parameters={
                "format": "comprehensive_report",
                "include_visualizations": True,
                "export_formats": ["csv", "excel", "pdf"],
                "interactive_dashboard": True
            },
            expected_output="Comprehensive validation report"
        )
    ]
    
    return MacroDefinition(
        name="MVR Peer Review",
        description="Automated Model Validation Report peer review with progressive complexity",
        trigger_patterns=[
            "[MVR Peer Review]",
            "[MVR Review]", 
            "[Model Validation Peer Review]",
            "[Automated MVR Review]"
        ],
        complexity_levels={
            ComplexityLevel.SIMPLE: {
                "name": "Basic Compliance Check",
                "description": "TOC parsing, section identification, basic compliance assessment",
                "steps": simple_steps,
                "estimated_time": "2-5 minutes",
                "suitable_for": "Quick compliance overview, initial assessment"
            },
            ComplexityLevel.ENHANCED: {
                "name": "Evidence-Focused Review", 
                "description": "Detailed evidence tracing, logic analysis, peer review challenges",
                "steps": enhanced_steps,
                "estimated_time": "10-20 minutes",
                "suitable_for": "Thorough peer review, quality assurance validation"
            },
            ComplexityLevel.ADVANCED: {
                "name": "AI-Powered Comprehensive Review",
                "description": "External contradiction search, regulatory compliance, real-time monitoring",
                "steps": advanced_steps,
                "estimated_time": "20-45 minutes", 
                "suitable_for": "Critical model validation, regulatory submissions, audit preparation"
            }
        },
        input_types=[DocumentCollection],
        output_type="ValidationReport",
        tags=["validation", "compliance", "peer-review", "MVS", "VST", "model-risk"],
        author="TidyLLM Macros System",
        version="1.0.0"
    )


def mvr_peer_review_pipeline(mvr_document: DocumentCollection, complexity: str = "enhanced") -> DocumentCollection:
    """
    Execute MVR Peer Review using tidyverse-style pipeline
    
    Args:
        mvr_document: DocumentCollection containing MVR document(s)
        complexity: "simple", "enhanced", or "advanced"
    
    Returns:
        DocumentCollection with peer review analysis
    """
    
    if complexity == "simple":
        return (mvr_document
            | filter(document_type="mvr")  # Only MVR documents
            | select("filename", "content", "metadata", "pages")
            | mutate(
                # Step 0: Initialization
                section_ids=lambda x: parse_toc_to_sections(x["content"]),
                current_section=lambda x: x["section_ids"][0] if x["section_ids"] else None,
                
                # Step 1: Model Context Extraction  
                model_type=lambda x: extract_model_type(x["content"][:10]),
                risk_tier=lambda x: extract_risk_tier(x["content"][:10]),
                validation_scope=lambda x: determine_scope(x["content"]),
                
                # Step 2: Basic Compliance
                mvs_requirements=lambda x: get_mvs_requirements(x["model_type"], x["risk_tier"]),
                compliance_status=lambda x: basic_compliance_check(x),
                completion_percentage=lambda x: calculate_completion(x["section_ids"])
            )
            | arrange("completion_percentage", desc=True)
            | reshape("compliance_summary")
        )
    
    elif complexity == "enhanced":
        return (mvr_document
            | filter(document_type="mvr")
            | select("filename", "content", "metadata", "pages", "sections")
            | mutate(
                # Enhanced analysis with evidence tracing
                section_ids=lambda x: parse_toc_to_sections(x["content"]),
                model_context=lambda x: extract_comprehensive_context(x),
                
                # Section-by-section analysis
                section_analysis=lambda x: analyze_all_sections(x["sections"], x["model_context"]),
                evidence_mapping=lambda x: map_conclusions_to_evidence(x["section_analysis"]),
                logic_trace=lambda x: trace_logical_reasoning(x["section_analysis"]),
                
                # Peer review challenges
                internal_contradictions=lambda x: find_contradictions(x["section_analysis"]),
                peer_challenges=lambda x: generate_challenges(x["logic_trace"]),
                confidence_scores=lambda x: calculate_confidence(x["evidence_mapping"])
            )
            | mutate(
                # Compliance matrix generation
                compliance_matrix=lambda x: create_compliance_matrix(x),
                defect_types=lambda x: categorize_defects(x["internal_contradictions"]),
                review_quality_score=lambda x: assess_review_quality(x)
            )
            | arrange("review_quality_score", desc=True)
            | reshape("detailed_matrix", 
                columns=["mvr_section", "mvs_requirements", "review_narrative", 
                        "contradiction_summary", "peer_review_challenge", 
                        "conclusion", "confidence_score", "defect_type"])
        )
    
    elif complexity == "advanced":
        return (mvr_document
            | filter(document_type="mvr")
            | select("filename", "content", "metadata", "pages", "sections", "references")
            | mutate(
                # Advanced context and external analysis
                comprehensive_context=lambda x: extract_advanced_context(x),
                regulatory_updates=lambda x: search_recent_regulatory_updates(x["model_type"]),
                enforcement_actions=lambda x: search_enforcement_database(x["model_type"]),
                industry_standards=lambda x: get_current_industry_standards(x["model_type"])
            )
            | invoke_persona("MVR Validation Expert")  # AI-powered analysis
            | invoke_persona("Regulatory Compliance Expert") 
            | invoke_persona("Risk Management Expert")
            | multi_persona_review([
                "MVR Validation Expert",
                "Regulatory Compliance Expert", 
                "Risk Management Expert"
            ], consensus_threshold=0.8)
            | mutate(
                # Advanced analytics
                external_contradictions=lambda x: identify_external_conflicts(x),
                regulatory_compliance_score=lambda x: calculate_reg_compliance(x),
                real_time_alerts=lambda x: setup_monitoring_alerts(x),
                risk_indicators=lambda x: calculate_risk_metrics(x),
                
                # Comprehensive scoring
                overall_validation_score=lambda x: calculate_overall_score(x["consensus_analysis"]),
                escalation_needed=lambda x: x["overall_validation_score"] < 0.7,
                audit_readiness=lambda x: assess_audit_readiness(x)
            )
            | filter(multi_persona_validated=True)  # Only consensus-validated results
            | arrange("overall_validation_score", desc=True)
            | reshape("comprehensive_report", 
                include_visualizations=True,
                export_formats=["csv", "excel", "pdf"])
        )
    
    else:
        raise ValueError(f"Unknown complexity level: {complexity}")


# Helper functions for the MVR peer review workflow

def parse_toc_to_sections(content: str) -> List[str]:
    """Parse table of contents to extract section IDs"""
    # Implementation would parse TOC structure
    return ["0", "0.1", "0.2", "1", "1.1", "1.2", "2", "2.1", "3"]

def extract_model_type(content: str) -> str:
    """Extract model type from executive summary"""
    # Implementation would use NLP to extract model type
    return "Credit Risk Model"

def extract_risk_tier(content: str) -> str:
    """Extract risk tier classification"""
    # Implementation would identify risk tier
    return "Tier 1 - High Risk"

def basic_compliance_check(document: Dict[str, Any]) -> str:
    """Perform basic MVS compliance assessment"""
    # Implementation would check against MVS requirements
    return "Partially Compliant"

def analyze_all_sections(sections: List[Dict], context: Dict) -> List[Dict]:
    """Analyze each section for compliance and quality"""
    # Implementation would perform detailed section analysis
    return [{"section_id": "1.1", "analysis": "Compliant", "evidence": "Strong"}]

def create_compliance_matrix(analysis: Dict[str, Any]) -> List[Dict]:
    """Create the compliance matrix output"""
    # Implementation would generate the matrix format
    return [
        {
            "mvr_section": "4",
            "mvs_requirements": "MVS 5.4.3, 5.4.3.1–3, 5.12.1; VST Conceptual Soundness",
            "review_narrative": "Section covers methodology, segmentation, variable selection...",
            "contradiction_summary": "No contradictions. Devil's advocate: reliance on SHAP...",
            "peer_review_challenge": "Rationale for SHAP-based feature selection not fully supported...",
            "conclusion": "✅",
            "confidence_score": "Highly Confident",
            "defect_type": "N/A"
        }
    ]


# Example usage demonstrating the tidyverse-style workflow
if __name__ == "__main__":
    from ..tidyverse_pipe import DocumentCollection
    
    # Sample MVR document
    mvr_data = [
        {
            "filename": "credit_model_validation_report.pdf",
            "document_type": "mvr",
            "content": "Model Validation Report for Credit Risk Model...",
            "pages": 85,
            "sections": [
                {"id": "1", "title": "Executive Summary", "content": "..."},
                {"id": "2", "title": "Model Overview", "content": "..."},
                {"id": "4", "title": "Conceptual Soundness", "content": "..."}
            ]
        }
    ]
    
    # Create document collection
    mvr_docs = DocumentCollection(data=mvr_data)
    
    # Example workflows for each complexity level
    
    print("=== SIMPLE: Basic Compliance Check ===")
    basic_review = mvr_peer_review_pipeline(mvr_docs, complexity="simple")
    basic_review | glimpse()
    
    print("\n=== ENHANCED: Evidence-Focused Review ===") 
    detailed_review = mvr_peer_review_pipeline(mvr_docs, complexity="enhanced")
    detailed_review | glimpse()
    
    print("\n=== ADVANCED: AI-Powered Comprehensive Review ===")
    comprehensive_review = mvr_peer_review_pipeline(mvr_docs, complexity="advanced") 
    comprehensive_review | glimpse()