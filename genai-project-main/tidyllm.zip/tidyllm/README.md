# TidyLLM - Python TidyLLM Ecosystem

A Python equivalent of tidyLLM with enhanced capabilities for enterprise LLM workflows. Provides a verb-based interface for LLM operations with DataTable backend, MLFlow Gateway integration, and **TidyMart** numerical computing.

## ✨ Features

- **TidyLLM-style verb interface**: `llm_message() | chat(provider())`
- **Enhanced file processing** with Attachments grammar
- **DataTable backend** for high-performance data operations (not pandas!)
- **MLFlow Gateway** for centralized LLM management  
- **TidyMart integration** - Enterprise NumPy alternative with graceful fallback
- **MCP integration** for standardized tool interfaces
- **Enterprise governance** and experiment tracking

## 🧮 TidyMart Numerical Computing

TidyLLM integrates with **TidyMart** - an enterprise-grade NumPy alternative with tidyverse syntax:

```python
import tidyllm

# Automatic backend selection
data = [100, 200, 300, 400, 500]
mean_val = tidyllm.np.mean(data)  # Works with TidyMart OR built-in functions

# Check which backend is active
if tidyllm.TIDYMART_AVAILABLE:
    print("🎯 Using TidyMart enterprise features")
else:
    print("🔧 Using built-in numerical functions")
```

**Backend Strategy:**
1. **Try TidyMart first** - If installed, use enterprise package
2. **Graceful fallback** - Use built-in `numpy_compat` if TidyMart unavailable  
3. **Identical interface** - Your code works regardless of backend

## 🚀 Quick Start

### Installation

```bash
pip install tidyllm[all]

# Optional: Install TidyMart for enhanced numerical computing
pip install tidymart  # (When available)
```

### Local Development Installation

```bash
# Clone the repository
git clone https://github.com/tidyllm/tidyllm.git
cd tidyllm

# Install in development mode
pip install -e .

# Run the quickstart demo
python examples/01_quickstart_demo.py
```

### Basic Usage

```python
from tidyllm import llm_message, chat, claude

# Simple chat (tidyLLM-style)
response = (llm_message("Explain machine learning")
           | chat(claude(model="claude-3-5-sonnet")))

# With file attachments (enhanced beyond tidyLLM)
analysis = (llm_message("Analyze quarterly data", "sales.csv", "charts.pdf")
           | chat(claude()))

# Data analysis workflow with numerical computing
import tidyllm.np as np
data_summary = np.mean([1000, 1500, 2000])  # Uses TidyMart or fallback

insights = (llm_message(f"Revenue average is ${data_summary}")
           | analyze_data("large_dataset.csv", claude())
           | chat(openai(model="gpt-4o")))
```

## 🎯 Examples

### Enterprise Compliance Workflow
```python
from tidyllm import llm_message, chat, claude, send_batch

# Batch compliance analysis
questions = [
    llm_message("Check financial controls", "controls.csv"),
    llm_message("Audit findings summary", "audit.pdf"),
    llm_message("Risk assessment", "risks.json")
]

results = send_batch(questions, claude(temperature=0.0))
```

### High-Performance Data Analysis
```python
import tidyllm.dt as dt
import tidyllm.np as np

# Load and analyze large datasets
df = dt.fread("sales_data.csv")  # Fast CSV reading
summary = (df.select("revenue", "region")
           .group_by("region") 
           .summarise(avg_revenue="mean(revenue)")
           .arrange("avg_revenue", ascending=False))

# Statistical analysis
quarterly_data = [125000, 150000, 175000, 200000]
trend = np.mean(np.diff(quarterly_data))  # Growth trend

report = (llm_message(f"Q4 shows {trend:+.0f} growth trend")
         | chat(claude()))
```

## 📁 Documentation

- **[Examples Directory](examples/)** - Working examples and demos
  - `01_quickstart_demo.py` - Basic functionality overview
  - `02_enterprise_workflow.py` - Enterprise compliance example  
  - `03_data_analysis_pipeline.py` - Data science workflow
- **[Package Architecture](tidyllm/)** - Core package modules
- **[TidyMart Integration](#-tidymart-numerical-computing)** - Numerical computing docs

## 🏢 Enterprise Features

- **MLFlow Gateway Integration** - Centralized LLM management
- **Experiment Tracking** - Automatic logging and versioning
- **Rate Limiting & Quotas** - Cost and usage control
- **Multi-provider Failover** - Reliability across providers
- **Audit Trails** - Compliance and governance
- **DataTable Backend** - Handle millions of rows efficiently

## 🔧 Architecture

```
tidyllm/
├── __init__.py          # Main API and TidyMart integration
├── core.py              # LLMMessage, Provider classes
├── verbs.py             # chat(), embed(), analyze_data()
├── gateway.py           # MLFlow Gateway integration
├── numpy_compat.py      # NumPy fallback functions (TidyMart backend)
├── dt.py                # Enhanced DataTable with tidyverse syntax
└── examples/            # Working demonstrations
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Add tests for new functionality
4. Submit a pull request

## 📄 License

MIT License - See [LICENSE](LICENSE) file for details.

## 🌟 Roadmap

- [ ] **TidyMart Package** - Extract numerical computing as separate package
- [ ] **MCP Server Integration** - Full Model Context Protocol support  
- [ ] **Enhanced Attachments** - Advanced file processing capabilities
- [ ] **Real-time Streaming** - Live chat and data analysis
- [ ] **Docker Deployment** - Containerized enterprise deployment