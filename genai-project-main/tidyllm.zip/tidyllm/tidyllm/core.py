#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Core - Core classes and utilities

Provides the foundation classes for the LLMData ecosystem:
- LLMMessage: Container for messages with file attachments
- Provider: Configuration for LLM providers
- Convenience functions for provider creation
"""

from typing import List, Any, Dict, Optional, Union
from pathlib import Path

class LLMMessage:
    """
    Container for LLM messages with optional file attachments.
    
    Supports tidyLLM-style workflows with pipe operators and file attachments.
    
    Examples:
        Basic message:
            msg = LLMMessage("Hello world")
            
        Message with files:
            msg = LLMMessage("Analyze these", "data.csv", "report.pdf")
            
        Pipeline usage:
            response = LLMMessage("Analyze model") | chat(claude())
    """
    
    def __init__(self, content: str, *files, **metadata):
        self.content = content
        self.files = list(files) if files else []
        self.metadata = metadata
        
        # Convert string file paths to Path objects
        self.files = [Path(f) if isinstance(f, str) else f for f in self.files]
    
    def __or__(self, other):
        """Pipeline operator for tidyLLM-style workflows"""
        if callable(other):
            return other(self)
        else:
            raise TypeError(f"Cannot pipe LLMMessage to {type(other)}")
    
    def __str__(self):
        files_str = f" +{len(self.files)} files" if self.files else ""
        return f"LLMMessage('{self.content[:50]}...'{files_str})"
    
    def __repr__(self):
        return self.__str__()
    
    def add_file(self, file_path: Union[str, Path]):
        """Add a file attachment to the message"""
        self.files.append(Path(file_path))
        return self
    
    def has_files(self) -> bool:
        """Check if message has file attachments"""
        return len(self.files) > 0
    
    def get_files_info(self) -> List[Dict[str, Any]]:
        """Get information about attached files"""
        file_info = []
        for file_path in self.files:
            if file_path.exists():
                file_info.append({
                    'path': str(file_path),
                    'name': file_path.name,
                    'size': file_path.stat().st_size,
                    'extension': file_path.suffix,
                    'exists': True
                })
            else:
                file_info.append({
                    'path': str(file_path),
                    'name': file_path.name,
                    'exists': False
                })
        return file_info


class Provider:
    """
    Configuration for LLM providers.
    
    Encapsulates provider-specific settings while providing a uniform interface
    for different LLM services (Claude, OpenAI, Ollama, etc.).
    
    Examples:
        Basic provider:
            provider = Provider("claude")
            
        Provider with model:
            provider = Provider("openai", model="gpt-4o")
            
        Provider with custom config:
            provider = Provider("claude", temperature=0.1, max_tokens=1000)
    """
    
    def __init__(self, provider: str, model: str = None, **config):
        self.provider = provider.lower()
        self.model = model
        self.config = config
    
    def __str__(self):
        model_str = f":{self.model}" if self.model else ""
        return f"Provider({self.provider}{model_str})"
    
    def __repr__(self):
        return self.__str__()
    
    def get_config(self) -> Dict[str, Any]:
        """Get full provider configuration"""
        config = {
            'provider': self.provider,
            'model': self.model,
            **self.config
        }
        return {k: v for k, v in config.items() if v is not None}
    
    def with_model(self, model: str) -> 'Provider':
        """Create a new provider with specified model"""
        return Provider(self.provider, model, **self.config)
    
    def with_config(self, **config) -> 'Provider':
        """Create a new provider with additional configuration"""
        merged_config = {**self.config, **config}
        return Provider(self.provider, self.model, **merged_config)


# Convenience functions for creating providers
def claude(model: str = "claude-3-5-sonnet", **kwargs) -> Provider:
    """
    Create Claude provider configuration.
    
    Args:
        model: Claude model name (default: claude-3-5-sonnet)
        **kwargs: Additional configuration (temperature, max_tokens, etc.)
    
    Examples:
        claude()  # Default model
        claude("claude-3-haiku")  # Specific model
        claude(temperature=0.1, max_tokens=1000)  # With config
    """
    return Provider("claude", model, **kwargs)


def openai(model: str = "gpt-4o", **kwargs) -> Provider:
    """
    Create OpenAI provider configuration.
    
    Args:
        model: OpenAI model name (default: gpt-4o)
        **kwargs: Additional configuration
    
    Examples:
        openai()  # Default GPT-4o
        openai("gpt-3.5-turbo")  # GPT-3.5
        openai(temperature=0.2, max_tokens=500)  # With config
    """
    return Provider("openai", model, **kwargs)


def ollama(model: str = "llama3.1", **kwargs) -> Provider:
    """
    Create Ollama provider configuration for local models.
    
    Args:
        model: Ollama model name (default: llama3.1)
        **kwargs: Additional configuration
    
    Examples:
        ollama()  # Default Llama3.1
        ollama("mistral")  # Mistral model
        ollama(temperature=0.8, num_ctx=2048)  # With config
    """
    return Provider("ollama", model, **kwargs)


def gemini(model: str = "gemini-pro", **kwargs) -> Provider:
    """
    Create Google Gemini provider configuration.
    
    Args:
        model: Gemini model name (default: gemini-pro)
        **kwargs: Additional configuration
    """
    return Provider("gemini", model, **kwargs)


# Convenience function for creating messages
def llm_message(content: str, *files, **metadata) -> LLMMessage:
    """
    Create an LLM message with optional file attachments.
    
    Args:
        content: The message content
        *files: File paths to attach
        **metadata: Additional metadata
    
    Examples:
        llm_message("Hello")
        llm_message("Analyze data", "data.csv", "report.pdf")
        llm_message("Question", file1="doc.pdf", priority="high")
    """
    return LLMMessage(content, *files, **metadata)


# Package exports
__all__ = [
    'LLMMessage',
    'Provider', 
    'llm_message',
    'claude',
    'openai',
    'ollama',
    'gemini'
]