"""
TidyLLM Native Onboarding System
================================

Onboarding application using TidyLLM's native interface components.
Replaces direct Streamlit usage with TidyLLM wrappers and interfaces.
"""

import sys
from pathlib import Path

# Add TidyLLM package path for clean, portable imports
sys.path.insert(0, r'C:\Users\marti\AI-Scoring')

# Import TidyLLM components
from tidyllm.interfaces.web import TidyLLMWebInterface
from tidyllm.gateways.gateway_registry import get_global_registry
# DISABLED: from tidyllm.infrastructure.session.unified import UnifiedSessionManager
# Using extended session manager from app.py instead
from tidyllm.web.components.dropzone_monitor import DropzoneMonitor
from tidyllm.web.utils.dashboard_helpers import DashboardUtils, ConfigManager

import streamlit as st

# Import TidyLLM-based UI components
from ui.components.tidyllm_sidebar import TidyLLMSidebar
from ui.pages.tidyllm_chat import TidyLLMChatInterface
from ui.pages.tidyllm_config import TidyLLMConfigInterface
from ui.pages.tidyllm_knowledge import TidyLLMKnowledgeInterface
from ui.pages.tidyllm_workflows import TidyLLMWorkflowInterface
from ui.pages.tidyllm_testing import TidyLLMTestingSuite

# Import existing pages (to be replaced gradually)
from ui.pages import (
    render_connection_page,
    render_setup_page,
    render_knowledge_page,
    render_workflows_page,
    render_testing_page,
    render_dashboard_page,
    render_guided_setup_page
)
from ui.pages.initialize import render_initialize_page

# Load AWS credentials using TidyLLM
try:
    from tidyllm.admin.credential_loader import set_aws_environment
    num_vars_set = set_aws_environment(verbose=True)
    print(f"[TIDYLLM] Loaded {num_vars_set} AWS environment variables")
except Exception as e:
    print(f"[TIDYLLM] Failed to load AWS credentials: {e}")

class TidyLLMOnboardingApp:
    """Main TidyLLM onboarding application."""
    
    def __init__(self):
        """Initialize TidyLLM application."""
        self.web_interface = TidyLLMWebInterface()
        self.registry = get_global_registry()
        self.session_manager = None
        self.sidebar = None
        self.chat_interface = None
        self._init_session()
    
    def _init_session(self):
        """Initialize TidyLLM session."""
        # Get or create session manager
        if 'tidyllm_session_manager' not in st.session_state:
            # Use extended session manager from app.py instead
            self.session_manager = st.session_state.get('tidyllm_session_manager')
            st.session_state.tidyllm_session_manager = self.session_manager
            
            # Try to initialize with MLflow extension
            try:
                from session_manager_extension import extend_session_manager_with_mlflow
                self.session_manager = extend_session_manager_with_mlflow(self.session_manager)
                st.session_state.tidyllm_session_manager = self.session_manager
                print("[TIDYLLM] Session manager extended with MLflow")
            except:
                print("[TIDYLLM] Running without MLflow extension")
        else:
            self.session_manager = st.session_state.tidyllm_session_manager
        
        # Initialize components
        self.sidebar = TidyLLMSidebar(self.session_manager)
        self.chat_interface = TidyLLMChatInterface()
        self.config_interface = TidyLLMConfigInterface()
        self.knowledge_interface = TidyLLMKnowledgeInterface()
        self.workflow_interface = TidyLLMWorkflowInterface()
        self.testing_suite = TidyLLMTestingSuite()
        
        # Initialize dashboard utils
        if 'dashboard_utils' not in st.session_state:
            st.session_state.dashboard_utils = DashboardUtils()
            st.session_state.config_manager = ConfigManager()
        
        # Auto-configure gateways
        if 'gateways_configured' not in st.session_state:
            try:
                self.registry.auto_configure()
                st.session_state.gateways_configured = True
            except Exception as e:
                st.session_state.gateways_configured = False
                st.session_state.gateway_error = str(e)
    
    def run(self):
        """Run the TidyLLM onboarding application."""
        
        # Configure page
        st.set_page_config(
            page_title="TidyLLM Enterprise Platform",
            page_icon="🚀",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        # Apply TidyLLM styling
        self._apply_tidyllm_style()
        
        # Render header
        st.markdown(
            '<div class="tidyllm-header">🚀 TidyLLM Enterprise AI Platform</div>',
            unsafe_allow_html=True
        )
        
        # Render sidebar and get selected page
        selected_page = self.sidebar.render()
        
        # Route to appropriate page
        self._route_to_page(selected_page)
    
    def _apply_tidyllm_style(self):
        """Apply TidyLLM-specific styling."""
        st.markdown("""
        <style>
            .tidyllm-header {
                font-size: 2.5rem;
                font-weight: bold;
                background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
                color: white;
                text-align: center;
                padding: 1.5rem;
                border-radius: 10px;
                margin-bottom: 2rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            
            .tidyllm-card {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                padding: 1.5rem;
                margin: 1rem 0;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            }
            
            .tidyllm-status-success {
                color: #22c55e;
                font-weight: bold;
            }
            
            .tidyllm-status-error {
                color: #ef4444;
                font-weight: bold;
            }
            
            .tidyllm-status-warning {
                color: #f59e0b;
                font-weight: bold;
            }
            
            .tidyllm-gateway-badge {
                display: inline-block;
                padding: 0.25rem 0.75rem;
                border-radius: 9999px;
                font-size: 0.875rem;
                font-weight: 600;
                margin: 0.25rem;
            }
            
            .tidyllm-gateway-active {
                background: #dcfce7;
                color: #166534;
            }
            
            .tidyllm-gateway-inactive {
                background: #fee2e2;
                color: #991b1b;
            }
        </style>
        """, unsafe_allow_html=True)
    
    def _route_to_page(self, selected_page: str):
        """Route to the appropriate page based on selection."""
        
        # Map page names to renderers
        page_map = {
            "🚀 Initialize System": self._render_initialize_page,
            "🔧 System Configuration": self._render_setup_page,
            "🎯 Quick Start": self._render_guided_setup,
            "🔌 Gateway Management": self._render_gateway_page,
            "🧠 AI Processing": self._render_ai_chat,
            "📚 Knowledge Systems": self._render_knowledge_page,
            "⚙️ Workflow Automation": self._render_workflow_page,
            "📊 Analytics Dashboard": self._render_dashboard,
            "🧪 Testing Suite": self._render_testing_page
        }
        
        # Get renderer and execute
        renderer = page_map.get(selected_page)
        if renderer:
            renderer()
        else:
            st.error(f"Unknown page: {selected_page}")
    
    def _render_initialize_page(self):
        """Render initialization page with TidyLLM components."""
        st.title("🚀 Initialize TidyLLM System")
        
        # Show gateway status
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("### Gateway Status")
            
            services = self.registry.list_services()
            
            if not services:
                st.warning("No gateways configured. Click 'Auto-Configure' to set up.")
            else:
                for service in services:
                    service_type = service.get('service_type', 'unknown')
                    initialized = service.get('initialized', False)
                    
                    if initialized:
                        badge_html = f'<span class="tidyllm-gateway-badge tidyllm-gateway-active">✅ {service_type}</span>'
                    else:
                        badge_html = f'<span class="tidyllm-gateway-badge tidyllm-gateway-inactive">❌ {service_type}</span>'
                    
                    st.markdown(badge_html, unsafe_allow_html=True)
        
        with col2:
            st.markdown("### Actions")
            
            if st.button("🔄 Auto-Configure", type="primary", use_container_width=True):
                with st.spinner("Configuring gateways..."):
                    try:
                        self.registry.auto_configure()
                        st.success("✅ Gateways configured successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Failed to configure: {e}")
            
            if st.button("🔍 Test Connection", use_container_width=True):
                self._test_connections()
        
        # Use existing initialize page for detailed view
        render_initialize_page()
    
    def _render_setup_page(self):
        """Render configuration page with TidyLLM interface."""
        self.config_interface.render()
    
    def _render_guided_setup(self):
        """Render guided setup."""
        render_guided_setup_page()
    
    def _render_gateway_page(self):
        """Render gateway management page with TidyLLM components."""
        st.title("🔌 Gateway Management")
        st.markdown("**TidyLLM 4-Gateway Architecture**")
        
        # Display gateway architecture
        st.markdown("""
        <div class="tidyllm-card">
            <h3>🏗️ Gateway Architecture</h3>
            <p>TidyLLM uses a 4-gateway design for enterprise AI:</p>
            <ul>
                <li><b>🤖 Corporate LLM Gateway</b> - Managed LLM access</li>
                <li><b>🧠 AI Processing Gateway</b> - Advanced AI operations</li>
                <li><b>⚙️ Workflow Optimizer</b> - Process automation</li>
                <li><b>💾 Database Gateway</b> - Knowledge management</li>
            </ul>
        </div>
        """, unsafe_allow_html=True)
        
        # Use existing connection page for details
        render_connection_page()
    
    def _render_ai_chat(self):
        """Render AI chat with TidyLLM interface."""
        self.chat_interface.render()
    
    def _render_knowledge_page(self):
        """Render knowledge systems page with TidyLLM interface."""
        self.knowledge_interface.render()
    
    def _render_workflow_page(self):
        """Render workflow automation page with TidyLLM interface."""
        self.workflow_interface.render()
    
    def _render_dashboard(self):
        """Render analytics dashboard with TidyLLM components."""
        st.title("📊 Analytics Dashboard")
        
        # Use dashboard utils
        utils = st.session_state.dashboard_utils
        
        # Render metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Requests", "1,234", "+12%")
        
        with col2:
            st.metric("Active Workflows", "42", "+5")
        
        with col3:
            st.metric("Knowledge Items", "8,901", "+234")
        
        with col4:
            st.metric("System Uptime", "99.9%", "+0.1%")
        
        # Use existing dashboard for detailed view
        render_dashboard_page()
    
    def _render_testing_page(self):
        """Render testing suite page with TidyLLM interface."""
        self.testing_suite.render()
    
    def _test_connections(self):
        """Test TidyLLM connections."""
        with st.spinner("Testing connections..."):
            results = []
            
            # Test S3
            try:
                s3_client = self.session_manager.get_s3_client()
                s3_client.list_buckets()
                results.append("✅ S3 Connection: Success")
            except Exception as e:
                results.append(f"❌ S3 Connection: {str(e)}")
            
            # Test Bedrock
            try:
                bedrock_client = self.session_manager.get_bedrock_client()
                results.append("✅ Bedrock Connection: Success")
            except Exception as e:
                results.append(f"❌ Bedrock Connection: {str(e)}")
            
            # Display results
            for result in results:
                if "✅" in result:
                    st.success(result)
                else:
                    st.error(result)


def main():
    """Main entry point for TidyLLM onboarding."""
    app = TidyLLMOnboardingApp()
    app.run()


if __name__ == "__main__":
    main()