"""
TidyLLM Onboarding System - Main Application
============================================

Clean, normalized Streamlit application for TidyLLM corporate onboarding.
"""

import sys
from pathlib import Path

# Add TidyLLM package path for clean, portable imports
sys.path.insert(0, r'C:\Users\marti\AI-Scoring')

# Apply startup optimizations using environment variables only
import os
os.environ['AWS_SDK_LOAD_CONFIG'] = 'false'  # Skip SDK config file loading
os.environ['AWS_DEFAULT_REGION'] = 'us-east-1'  # Set default region
# Note: AWS_PROFILE is handled by UnifiedSessionManager - don't override it

# Import TidyLLM web interface instead of direct Streamlit
from tidyllm.interfaces.web import TidyLLMWebInterface
import streamlit as st  # Still needed for session state

# V2 Unified session management
from tidyllm.core.state import set_current_portal

# Lazy load AWS credentials - only when needed
_aws_credentials_loaded = False

def _load_aws_credentials_lazy():
    """Load AWS credentials only when needed (lazy loading)"""
    global _aws_credentials_loaded
    if _aws_credentials_loaded:
        return True
    
    try:
        from tidyllm.admin.credential_loader import set_aws_environment
        set_aws_environment(verbose=False)  # Reduced verbosity for faster startup
        _aws_credentials_loaded = True
        print("[STREAMLIT] AWS credentials loaded")
        return True
    except Exception as e:
        print(f"[STREAMLIT] Using environment variables for AWS credentials: {e}")
        _aws_credentials_loaded = True  # Mark as attempted
        return False

# Import TidyLLM session management with MLflow extension
_global_session_manager = None


# Cache MLflow service to avoid re-initialization
_cached_mlflow_service = None

def _init_foundational_mlflow(session_manager):
    """Initialize MLflow as the foundational service for LLM Gateway (cached)."""
    global _cached_mlflow_service
    
    # Return cached service if available
    if _cached_mlflow_service is not None:
        print("[MLFLOW] Using cached MLflow service")
        return _cached_mlflow_service
    
    try:
        from tidyllm.services.mlflow_integration_service import MLflowIntegrationService, MLflowConfig
        
        print("[MLFLOW] Initializing MLflow service (first time)...")
        
        # Use direct database connection with optimized settings
        database_uri = "postgresql://vectorqa_user:Fujifuji500!@vectorqa-cluster.cluster-cu562e4m02nq.us-east-1.rds.amazonaws.com:5432/vectorqa?sslmode=require"
        config = MLflowConfig(gateway_uri=database_uri)
        
        # CRITICAL: Ensure MLflowIntegrationService uses our extended session manager
        from tidyllm.infrastructure.session.unified import _global_session_manager as global_var
        global_var = session_manager
        
        mlflow_service = MLflowIntegrationService(config)
        
        # Quick availability check (non-blocking with timeout)
        try:
            import signal
            
            def timeout_handler(signum, frame):
                raise TimeoutError("Connection check timed out")
            
            # Set a 5-second timeout for connection check
            signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(5)
            
            try:
                if mlflow_service.is_available():
                    print(f"[MLFLOW] LIVE connection verified")
                else:
                    print(f"[MLFLOW] Database connection failed - using offline mode")
            finally:
                signal.alarm(0)  # Cancel the alarm
                
        except TimeoutError:
            print(f"[MLFLOW] Connection check timed out - using offline mode")
        except Exception as e:
            print(f"[MLFLOW] Connection check failed: {e} - using offline mode")
        
        # Cache the service for future use
        _cached_mlflow_service = mlflow_service
        print("[MLFLOW] MLflow service cached for fast access")
        return mlflow_service
            
    except Exception as e:
        print(f"[MLFLOW] Service initialization failed: {e}")
        return None

def init_streamlit_session_state():
    """Initialize Streamlit session state using ONE GLOBAL UnifiedSessionManager with MLflow support (lazy)."""
    global _global_session_manager
    
    # Return cached session manager if available
    if 'tidyllm_session_manager' in st.session_state:
        return st.session_state.tidyllm_session_manager
    
    # Create ONE global session manager if it doesn't exist
    if _global_session_manager is None:
        print("[SESSION] Creating UnifiedSessionManager (first time)...")
        
        from tidyllm.infrastructure.session.unified import UnifiedSessionManager
        from session_manager_extension import extend_session_manager_with_mlflow
        
        # CRITICAL: Create ONE session manager and extend it immediately
        _global_session_manager = UnifiedSessionManager()
        print("[SESSION] Created ONE UnifiedSessionManager")
        
        # Extend the session manager with MLflow support
        _global_session_manager = extend_session_manager_with_mlflow(_global_session_manager)
        print("[SESSION] Extended session manager with MLflow support")
        
        # CRITICAL: Set the extended session manager as the global one
        from tidyllm.infrastructure.session.unified import _global_session_manager as global_var
        global_var = _global_session_manager
        print("[SESSION] Extended session manager set as global")
        
        # CRITICAL: Inject extended session manager into global registry
        from tidyllm.gateways.gateway_registry import get_global_registry
        registry = get_global_registry()
        if hasattr(registry, 'session_manager'):
            registry.session_manager = _global_session_manager
            print("[SESSION] Extended session manager injected into GatewayRegistry")
        
        # CRITICAL: Initialize MLflow as foundational service for LLM Gateway (lazy)
        _init_foundational_mlflow(_global_session_manager)
    
    # Store it in Streamlit session state
    st.session_state.tidyllm_session_manager = _global_session_manager
    print("[SESSION] Session manager cached in Streamlit session state")
    
    return st.session_state.tidyllm_session_manager
from tidyllm_system_status import TidyLLMSystemStatus, render_tidyllm_status_summary, render_tidyllm_refresh_controls
from tidyllm.web.components.dropzone_monitor import DropzoneMonitor
from tidyllm.web.utils.dashboard_helpers import DashboardUtils
from ui.components.sidebar import render_sidebar
from ui.pages import (
    render_connection_page,
    render_setup_page,
    render_chat_page,
    render_knowledge_page,
    render_workflows_page,
    render_testing_page,
    render_dashboard_page,
    render_guided_setup_page
)
from ui.pages.initialize import render_initialize_page

# Streamlit configuration with hardcoded development settings
st.set_page_config(
    page_title="TidyLLM Enterprise AI Platform | Corporate Showcase",
    page_icon=":office:",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Streamlit configuration is handled by command line arguments
# No need to set conflicting options here

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
        border-bottom: 3px solid #1f77b4;
        padding-bottom: 1rem;
    }
    
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        color: #2c3e50;
        margin-top: 2rem;
        margin-bottom: 1rem;
        border-left: 4px solid #1f77b4;
        padding-left: 1rem;
    }
    
    .status-success {
        color: #27ae60;
        font-weight: bold;
    }
    
    .status-error {
        color: #e74c3c;
        font-weight: bold;
    }
    
    .status-warning {
        color: #f39c12;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

def main():
    """Main application entry point using TidyLLM interface (optimized)."""
    import time

    # Set current portal for unified session management
    set_current_portal("onboarding")

    # Start performance timer
    startup_start = time.time()
    
    # Render header immediately for faster perceived loading
    st.markdown('<div class="main-header">🏢 TidyLLM Enterprise AI Platform</div>', unsafe_allow_html=True)
    
    # Show loading indicator while initializing
    with st.spinner("Initializing TidyLLM system..."):
        # Initialize TidyLLM web interface (lazy)
        if 'tidyllm_interface' not in st.session_state:
            tidyllm_interface = TidyLLMWebInterface()
            st.session_state.tidyllm_interface = tidyllm_interface
        else:
            tidyllm_interface = st.session_state.tidyllm_interface
        
        # Load AWS credentials only when needed (lazy)
        _load_aws_credentials_lazy()
        
        # Initialize session state (lazy)
        init_streamlit_session_state()
        
        # Get TidyLLM system health through interface (lazy)
        if 'system_health' not in st.session_state:
            system_health = TidyLLMSystemStatus.get_system_health()
            st.session_state.system_health = system_health
        else:
            system_health = st.session_state.system_health
        
        # Initialize TidyLLM components (lazy)
        if 'dashboard_utils' not in st.session_state:
            dashboard_utils = DashboardUtils()
            st.session_state.dashboard_utils = dashboard_utils
        else:
            dashboard_utils = st.session_state.dashboard_utils
        
        # TidyLLM native compatibility - populate session state with TidyLLM data (lazy)
        if system_health['status'] != 'error' and 'gateways' not in st.session_state:
            # Get gateways and services through USM (maintains ONE SESSION MANAGER RULE)
            session_manager = st.session_state.get('tidyllm_session_manager')
            if session_manager:
                try:
                    st.session_state.gateways = session_manager.get_gateways()
                    st.session_state.services = session_manager.get_services()
                    print(f"[SESSION] Initialized {len(st.session_state.gateways)} gateways: {list(st.session_state.gateways.keys())}")
                except Exception as e:
                    print(f"[SESSION] Gateway initialization failed: {e}")
                    st.session_state.gateways = {}
                    st.session_state.services = []
    
    # Calculate and display startup time
    startup_time = time.time() - startup_start
    st.success(f"TidyLLM system initialized successfully! (Startup: {startup_time:.2f}s)")
    
    # TidyLLM feature showcase intro - COMMENTED OUT
    # st.markdown("""
    # <div style="text-align: center; margin-bottom: 2rem; padding: 1rem; background-color: #f0f2f6; border-radius: 10px;">
    #     <h3 style="color: #1f77b4; margin-bottom: 0.5rem;">Complete Enterprise AI Solution</h3>
    #     <p style="margin: 0; color: #2c3e50;">
    #         Experience TidyLLM's <strong>4-Gateway Architecture</strong> • <strong>Knowledge Systems</strong> • <strong>Workflow Automation</strong> • <strong>Corporate-Safe Validation</strong>
    #     </p>
    # </div>
    # """, unsafe_allow_html=True)
    
    # Render sidebar
    selected_page = render_sidebar()
    
    # Render main content based on selection - TidyLLM Feature Showcase
    if selected_page == "Initialize System":
        render_initialize_page()
    elif selected_page == "Quick Start (Guided Setup)":
        render_guided_setup_page()
    elif selected_page == "🔌 Gateway Architecture":
        render_connection_page()
    elif selected_page == "🧠 AI Chat & Processing":
        render_chat_page()
    elif selected_page == "📚 Knowledge Systems":
        render_knowledge_page()
    elif selected_page == "Workflow Automation":
        render_workflows_page()
    elif selected_page == "Analytics Dashboard":
        render_dashboard_page()
    elif selected_page == "🔧 System Configuration":
        render_setup_page()
    elif selected_page == "🧪 Testing Suite":
        render_testing_page()
    else:
        st.error(f"Unknown page: {selected_page}")

if __name__ == "__main__":
    main()
