"""
Onboarding Portal Package
=========================

Corporate onboarding and setup portal for TidyLLM.

Features:
- AWS connection configuration
- Database setup and testing
- AI model testing and validation
- Knowledge management setup
- System health monitoring
"""

from .launcher import launch_onboarding_portal

__all__ = ['launch_onboarding_portal']