#!/usr/bin/env python3
"""
AHA (Automated Health Awareness) Streamlit Dashboard
Real-time health monitoring and control for TidyLLM system
"""

import streamlit as st
import polars as pl
import time
import json
import yaml
import os
import requests
import psycopg2
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import boto3
from botocore.exceptions import ClientError, NoCredentialsError

# Import TidyLLM components
try:
    from tidyllm.gateways.gateway_registry import get_global_registry
    from tidyllm.infrastructure.session.unified import get_global_session_manager
    TIDYLLM_AVAILABLE = True
except ImportError:
    TIDYLLM_AVAILABLE = False

# Import DemoConnectionManager
try:
    from tidyllm.scripts.pre_connection_manager import get_connection_manager
    DEMO_MANAGER_AVAILABLE = True
except ImportError:
    DEMO_MANAGER_AVAILABLE = False

# Import ConfigManager
try:
    from tidyllm.admin.config_manager import ConfigManager, TidyLLMConfig
    CONFIG_MANAGER_AVAILABLE = True
except ImportError:
    CONFIG_MANAGER_AVAILABLE = False

# Import KnowledgeInterface for RAG monitoring
try:
    from tidyllm.knowledge_systems.interfaces.knowledge_interface import get_knowledge_interface
    KNOWLEDGE_INTERFACE_AVAILABLE = True
except ImportError:
    KNOWLEDGE_INTERFACE_AVAILABLE = False

# Page configuration
st.set_page_config(
    page_title="AHA - Automated Health Awareness",
    page_icon="💓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Enable auto-reload and development settings
import streamlit.config as st_config
try:
    # Enable auto-reload on file changes
    st_config.set_option("server.runOnSave", True)
    st_config.set_option("server.fileWatcherType", "auto")

    # Disable browser restrictions for local development
    st_config.set_option("server.enableCORS", False)
    st_config.set_option("server.enableXsrfProtection", False)

except Exception as e:
    pass  # Silently handle config errors

class AHAHealthCollector:
    """AHA Health Data Collector"""
    
    def __init__(self):
        self.demo_manager = None
        if DEMO_MANAGER_AVAILABLE:
            try:
                self.demo_manager = get_connection_manager()
            except Exception as e:
                st.warning(f"DemoConnectionManager not available: {e}")

        # Load configuration for real connections
        self.config = load_credentials()
        self.mlflow_url = self.config.get('services', {}).get('mlflow', {}).get('tracking_uri', 'http://localhost:5000') if self.config else 'http://localhost:5000'

    def check_mlflow_health(self) -> Dict[str, Any]:
        """Check real MLflow server health and metrics"""
        try:
            # Check MLflow server health
            health_response = requests.get(f"{self.mlflow_url}/health", timeout=5)
            is_healthy = health_response.status_code == 200

            # Get MLflow metrics
            metrics = {
                "status": "operational" if is_healthy else "degraded",
                "availability_score": 99.9 if is_healthy else 75.0,
                "response_time_ms": int(health_response.elapsed.total_seconds() * 1000) if is_healthy else 5000,
                "database_connected": True,
                "last_check": datetime.now().isoformat()
            }

            # Try to get additional MLflow stats
            try:
                experiments_response = requests.get(f"{self.mlflow_url}/api/2.0/mlflow/experiments/search?max_results=10", timeout=5)
                if experiments_response.status_code == 200:
                    experiments_data = experiments_response.json()
                    metrics["active_experiments"] = len(experiments_data.get("experiments", []))

                # Get recent runs count
                runs_response = requests.get(f"{self.mlflow_url}/api/2.0/mlflow/runs/search", timeout=5)
                if runs_response.status_code == 200:
                    runs_data = runs_response.json()
                    metrics["recent_runs"] = len(runs_data.get("runs", []))

            except Exception:
                metrics["active_experiments"] = 0
                metrics["recent_runs"] = 0

            return metrics

        except Exception as e:
            return {
                "status": "failed",
                "availability_score": 0.0,
                "response_time_ms": 0,
                "database_connected": False,
                "last_check": datetime.now().isoformat(),
                "error": str(e),
                "active_experiments": 0,
                "recent_runs": 0
            }

    def check_postgresql_health(self) -> Dict[str, Any]:
        """Check real PostgreSQL database health"""
        if not self.config or 'credentials' not in self.config:
            return {
                "status": "configuration_missing",
                "availability_score": 0.0,
                "response_time_ms": 0,
                "connection_pool": "unknown",
                "last_check": datetime.now().isoformat(),
                "error": "No database configuration found"
            }

        try:
            db_config = self.config['credentials']['postgresql']

            # Measure connection time
            start_time = time.time()

            # Connect to PostgreSQL
            conn = psycopg2.connect(
                host=db_config['host'],
                port=db_config['port'],
                database=db_config['database'],
                user=db_config['username'],
                password=db_config['password'],
                sslmode=db_config.get('ssl_mode', 'prefer'),
                connect_timeout=5
            )

            end_time = time.time()
            response_time = int((end_time - start_time) * 1000)

            cursor = conn.cursor()

            # Get database statistics
            cursor.execute("SELECT COUNT(*) FROM pg_stat_activity;")
            active_connections = cursor.fetchone()[0]

            cursor.execute("SELECT version();")
            pg_version = cursor.fetchone()[0]

            # Get database size
            cursor.execute(f"SELECT pg_size_pretty(pg_database_size('{db_config['database']}'));")
            db_size = cursor.fetchone()[0]

            cursor.close()
            conn.close()

            return {
                "status": "operational",
                "availability_score": 99.95,
                "response_time_ms": response_time,
                "connection_pool": f"{active_connections} active",
                "last_check": datetime.now().isoformat(),
                "pg_version": pg_version.split()[1] if pg_version else "unknown",
                "database_size": db_size,
                "active_connections": active_connections
            }

        except Exception as e:
            return {
                "status": "failed",
                "availability_score": 0.0,
                "response_time_ms": 0,
                "connection_pool": "failed",
                "last_check": datetime.now().isoformat(),
                "error": str(e)
            }

    def get_v2_portal_metrics(self) -> Dict[str, Any]:
        """Get real-time metrics from V2 portals running on different ports"""
        portal_metrics = {}

        # V2 Portals to check
        v2_portals = {
            "rag_creator_v2": {"port": 8535, "name": "RAG Creator V2"},
            "flow_creator_v2": {"port": 8536, "name": "Flow Creator V2"},
            "drop_zone_creator_v2": {"port": 8534, "name": "Drop Zone Creator V2"},
            "boss_portal": {"port": 8530, "name": "Boss Portal"},
            "onboarding_portal": {"port": 8531, "name": "Onboarding Portal"}
        }

        for portal_key, portal_info in v2_portals.items():
            try:
                # Check if portal is running
                health_url = f"http://localhost:{portal_info['port']}"
                response = requests.get(health_url, timeout=2)

                is_running = response.status_code == 200
                response_time = int(response.elapsed.total_seconds() * 1000) if is_running else 0

                portal_metrics[portal_key] = {
                    "name": portal_info["name"],
                    "port": portal_info["port"],
                    "status": "operational" if is_running else "down",
                    "response_time_ms": response_time,
                    "availability_score": 98.0 if is_running else 0.0,
                    "last_check": datetime.now().isoformat()
                }

            except Exception as e:
                portal_metrics[portal_key] = {
                    "name": portal_info["name"],
                    "port": portal_info["port"],
                    "status": "failed",
                    "response_time_ms": 0,
                    "availability_score": 0.0,
                    "last_check": datetime.now().isoformat(),
                    "error": str(e)
                }

        return portal_metrics

    def check_rag_systems_health(self) -> Dict[str, Any]:
        """Check health of all 5 RAG adapters in our consolidated knowledge systems"""
        if not KNOWLEDGE_INTERFACE_AVAILABLE:
            return {
                "status": "knowledge_interface_unavailable",
                "error": "KnowledgeInterface not available for RAG monitoring",
                "adapters": {}
            }

        try:
            # Get KnowledgeInterface instance
            knowledge = get_knowledge_interface()

            # RAG adapters to monitor
            rag_adapters = [
                ("AI-Powered RAG", knowledge.query_ai_powered_rag),
                ("Intelligent RAG", knowledge.query_intelligent_rag),
                ("SME RAG", knowledge.query_sme_rag),
                ("Expert RAG", knowledge.query_expert_rag),
                ("Postgres RAG", knowledge.query_postgres_rag)
            ]

            adapter_health = {}
            total_score = 0
            active_adapters = 0

            for adapter_name, adapter_method in rag_adapters:
                try:
                    start_time = time.time()

                    # Query adapter for health check
                    result = adapter_method(
                        query="HEALTH_CHECK",
                        return_metadata=True
                    )

                    response_time = (time.time() - start_time) * 1000  # Convert to ms

                    if result.get("success"):
                        active_adapters += 1
                        health_score = 95.0 + (5.0 if response_time < 200 else 0.0)  # Bonus for fast response
                        total_score += health_score

                        adapter_health[adapter_name] = {
                            "status": "operational",
                            "health_score": health_score,
                            "response_time_ms": int(response_time),
                            "success_rate": result.get("success_rate", 99.0),
                            "queries_processed": result.get("queries_processed", 0),
                            "last_query": result.get("last_query_time", "Never"),
                            "adapter_type": adapter_name,
                            "last_check": datetime.now().isoformat()
                        }
                    else:
                        adapter_health[adapter_name] = {
                            "status": "degraded",
                            "health_score": 60.0,
                            "response_time_ms": int(response_time),
                            "error": result.get("error", "Unknown error"),
                            "adapter_type": adapter_name,
                            "last_check": datetime.now().isoformat()
                        }

                except Exception as e:
                    adapter_health[adapter_name] = {
                        "status": "failed",
                        "health_score": 0.0,
                        "response_time_ms": 0,
                        "error": str(e),
                        "adapter_type": adapter_name,
                        "last_check": datetime.now().isoformat()
                    }

            # Calculate overall RAG system health
            avg_score = total_score / len(rag_adapters) if rag_adapters else 0
            system_status = "operational" if active_adapters >= 3 else "degraded" if active_adapters >= 1 else "failed"

            return {
                "status": system_status,
                "overall_health_score": avg_score,
                "active_adapters": active_adapters,
                "total_adapters": len(rag_adapters),
                "adapters": adapter_health,
                "last_check": datetime.now().isoformat()
            }

        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "overall_health_score": 0.0,
                "active_adapters": 0,
                "total_adapters": 5,
                "adapters": {},
                "last_check": datetime.now().isoformat()
            }

    def collect_gateway_health(self) -> Dict[str, Any]:
        """Collect health data from all gateways"""
        gateway_health = {}
        
        if not TIDYLLM_AVAILABLE:
            # Mock data for demonstration
            return {
                "corporate_llm": {
                    "status": "healthy",
                    "health_score": 98.5,
                    "response_time_ms": 180,
                    "error_rate": 0.01,
                    "active_connections": 12,
                    "uptime_seconds": 86400,
                    "last_check": datetime.now().isoformat()
                },
                "ai_processing": {
                    "status": "healthy",
                    "health_score": 96.2,
                    "response_time_ms": 320,
                    "error_rate": 0.03,
                    "active_connections": 8,
                    "uptime_seconds": 86400,
                    "last_check": datetime.now().isoformat()
                },
                "workflow_optimizer": {
                    "status": "healthy",
                    "health_score": 97.8,
                    "response_time_ms": 290,
                    "error_rate": 0.02,
                    "active_connections": 15,
                    "uptime_seconds": 86400,
                    "last_check": datetime.now().isoformat()
                },
                "context": {
                    "status": "healthy",
                    "health_score": 99.1,
                    "response_time_ms": 190,
                    "error_rate": 0.01,
                    "active_connections": 12,
                    "uptime_seconds": 86400,
                    "last_check": datetime.now().isoformat()
                }
            }
        
        try:
            # Get GatewayRegistry
            registry = get_global_registry()
            
            # Collect health from each gateway
            for service_type, service_info in registry._services.items():
                if service_info.initialized and service_info.instance:
                    gateway_name = service_type.value
                    
                    try:
                        # Get health check data
                        if hasattr(service_info.instance, 'health_check'):
                            health_data = service_info.instance.health_check()
                            status = health_data.get('status', 'unknown')
                        else:
                            status = 'unknown'
                        
                        # Get gateway status if available
                        if hasattr(service_info.instance, 'get_gateway_status'):
                            status_data = service_info.instance.get_gateway_status()
                            response_time = status_data.get('response_time_ms', 0)
                            error_rate = status_data.get('error_rate', 0.0)
                            active_connections = status_data.get('active_connections', 0)
                            uptime = status_data.get('uptime_seconds', 0)
                        else:
                            response_time = 0
                            error_rate = 0.0
                            active_connections = 0
                            uptime = 0
                        
                        # Calculate health score
                        health_score = self._calculate_health_score(status, response_time, error_rate)
                        
                        gateway_health[gateway_name] = {
                            "status": status,
                            "health_score": health_score,
                            "response_time_ms": response_time,
                            "error_rate": error_rate,
                            "active_connections": active_connections,
                            "uptime_seconds": uptime,
                            "last_check": datetime.now().isoformat()
                        }
                        
                    except Exception as e:
                        gateway_health[gateway_name] = {
                            "status": "error",
                            "health_score": 0.0,
                            "response_time_ms": 0,
                            "error_rate": 1.0,
                            "active_connections": 0,
                            "uptime_seconds": 0,
                            "last_check": datetime.now().isoformat(),
                            "error": str(e)
                        }
                        
        except Exception as e:
            st.error(f"Failed to collect gateway health: {e}")
        
        return gateway_health
    
    def collect_service_health(self) -> Dict[str, Any]:
        """Collect health data from foundational services with real connections"""
        service_health = {}

        # Real MLflow health check
        service_health["mlflow"] = self.check_mlflow_health()

        # Real PostgreSQL health check
        service_health["postgresql"] = self.check_postgresql_health()

        # Real V2 Portal metrics
        v2_metrics = self.get_v2_portal_metrics()
        if v2_metrics:
            service_health.update(v2_metrics)

        # AWS S3 and Bedrock - keep as mock for now (can be enhanced later)
        service_health["aws_s3"] = {
            "status": "operational",
            "availability_score": 98.7,
            "response_time_ms": 150,
            "bucket_accessible": True,
            "last_check": datetime.now().isoformat()
        }

        service_health["bedrock"] = {
            "status": "operational",
            "availability_score": 97.8,
            "response_time_ms": 320,
            "model_access": True,
            "last_check": datetime.now().isoformat()
        }

        return service_health
    
    def _calculate_health_score(self, status: str, response_time: int, error_rate: float) -> float:
        """Calculate health score (0-100)"""
        score = 100.0
        
        # Status penalty
        if status == 'error':
            score -= 50
        elif status == 'degraded':
            score -= 20
        elif status == 'unknown':
            score -= 10
        
        # Response time penalty
        if response_time > 1000:  # > 1 second
            score -= 20
        elif response_time > 500:  # > 500ms
            score -= 10
        
        # Error rate penalty
        if error_rate > 0.05:  # > 5%
            score -= 30
        elif error_rate > 0.01:  # > 1%
            score -= 10
        
        return max(0.0, score)

class AHAHealthDashboard:
    """AHA Health Dashboard for Streamlit"""
    
    def __init__(self):
        self.health_collector = AHAHealthCollector()
        self.last_update = None
        self.health_data = None
    
    def get_comprehensive_health(self) -> Dict[str, Any]:
        """Get comprehensive health data"""
        # Check if we need to refresh data (every 30 seconds)
        current_time = time.time()
        if (self.last_update is None or 
            current_time - self.last_update > 30 or 
            self.health_data is None):
            
            # Collect fresh health data
            gateway_health = self.health_collector.collect_gateway_health()
            service_health = self.health_collector.collect_service_health()
            rag_systems_health = self.health_collector.check_rag_systems_health()
            
            # Calculate overall health score
            overall_health = self._calculate_overall_health_score(gateway_health, service_health)
            
            # Get performance metrics
            performance_metrics = self._get_performance_metrics(gateway_health, service_health)
            
            # Get recent alerts (mock for now)
            recent_alerts = self._get_recent_alerts()
            
            self.health_data = {
                'overall_health_score': overall_health,
                'health_status': self._get_health_status(overall_health),
                'gateway_health': gateway_health,
                'service_health': service_health,
                'rag_systems_health': rag_systems_health,
                'performance_metrics': performance_metrics,
                'recent_alerts': recent_alerts,
                'last_updated': datetime.now().isoformat()
            }
            
            self.last_update = current_time
        
        return self.health_data
    
    def _calculate_overall_health_score(self, gateway_health: Dict, service_health: Dict) -> float:
        """Calculate overall system health score"""
        all_scores = []
        
        # Add gateway health scores
        for gateway_data in gateway_health.values():
            all_scores.append(gateway_data.get('health_score', 0))
        
        # Add service availability scores
        for service_data in service_health.values():
            all_scores.append(service_data.get('availability_score', 0))
        
        if all_scores:
            return sum(all_scores) / len(all_scores)
        else:
            return 0.0
    
    def _get_health_status(self, health_score: float) -> str:
        """Get health status based on score"""
        if health_score >= 90:
            return "EXCELLENT"
        elif health_score >= 70:
            return "GOOD"
        elif health_score >= 50:
            return "DEGRADED"
        else:
            return "CRITICAL"
    
    def _get_performance_metrics(self, gateway_health: Dict, service_health: Dict) -> Dict[str, Any]:
        """Get performance metrics"""
        response_times = []
        error_rates = []
        
        # Collect gateway metrics
        for gateway_data in gateway_health.values():
            response_times.append(gateway_data.get('response_time_ms', 0))
            error_rates.append(gateway_data.get('error_rate', 0))
        
        # Collect service metrics
        for service_data in service_health.values():
            response_times.append(service_data.get('response_time_ms', 0))
        
        return {
            'avg_response_time_ms': sum(response_times) / len(response_times) if response_times else 0,
            'max_response_time_ms': max(response_times) if response_times else 0,
            'avg_error_rate': sum(error_rates) / len(error_rates) if error_rates else 0,
            'total_connections': sum(g.get('active_connections', 0) for g in gateway_health.values())
        }
    
    def _get_recent_alerts(self) -> List[Dict[str, Any]]:
        """Get recent alerts (mock data for now)"""
        return [
            {
                "timestamp": (datetime.now() - timedelta(minutes=15)).isoformat(),
                "level": "WARNING",
                "component": "ai_processing",
                "message": "Response time above threshold (450ms)",
                "resolved": True
            }
        ]

    def get_system_monitor_data(self) -> Dict[str, Any]:
        """Get system monitoring data for resource usage, processing metrics, and error tracking."""
        return {
            "resource_usage": {
                "cpu_usage": 65.3,
                "memory_usage": 72.1,
                "disk_usage": 45.8,
                "network_io": 125.6,  # MB/s
                "active_connections": 47,
                "thread_pool_usage": 38.9
            },
            "processing_metrics": {
                "total_documents_processed": 1847,
                "processing_queue_size": 12,
                "avg_processing_time": 186,  # ms
                "throughput_per_hour": 124,
                "success_rate": 96.8,
                "failed_processes": 3,
                "pending_processes": 8
            },
            "error_tracking": {
                "total_errors_24h": 23,
                "critical_errors": 2,
                "warnings": 15,
                "info_events": 6,
                "error_rate_trend": [-1.2, -0.8, 0.3, -0.5, 1.1],  # % change over 5 periods
                "top_errors": [
                    {"error": "Connection timeout", "count": 8, "last_seen": "2 min ago"},
                    {"error": "Memory allocation failed", "count": 5, "last_seen": "15 min ago"},
                    {"error": "Invalid document format", "count": 4, "last_seen": "1 hour ago"},
                    {"error": "Authentication failed", "count": 3, "last_seen": "2 hours ago"},
                    {"error": "Rate limit exceeded", "count": 3, "last_seen": "3 hours ago"}
                ]
            }
        }

def render_aha_header():
    """Render AHA dashboard header"""
    st.title("💓 AHA - Automated Health Awareness")
    st.markdown("**Real-time health monitoring and control for TidyLLM system**")
    
    # Auto-refresh indicator
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.markdown("### System Health Overview")
    
    with col2:
        if st.button("🔄 Refresh", help="Refresh health data"):
            st.rerun()
    
    with col3:
        st.markdown(f"**Last Update:** {datetime.now().strftime('%H:%M:%S')}")

def render_aha_overview(health_data: Dict[str, Any]):
    """Render AHA health overview"""
    
    overall_health = health_data['overall_health_score']
    health_status = health_data['health_status']
    
    # Overall health score
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if overall_health >= 90:
            st.success(f"💓 **Overall Health: {overall_health:.1f}%**")
            st.caption(f"Status: {health_status}")
        elif overall_health >= 70:
            st.warning(f"💓 **Overall Health: {overall_health:.1f}%**")
            st.caption(f"Status: {health_status}")
        else:
            st.error(f"💓 **Overall Health: {overall_health:.1f}%**")
            st.caption(f"Status: {health_status}")
    
    with col2:
        # Gateway health
        gateway_health = health_data['gateway_health']
        healthy_gateways = sum(1 for g in gateway_health.values() if g['status'] == 'healthy')
        total_gateways = len(gateway_health)
        avg_gateway_health = sum(g['health_score'] for g in gateway_health.values()) / total_gateways
        
        st.metric("🔌 Gateways", f"{healthy_gateways}/{total_gateways}", f"{avg_gateway_health:.1f}% avg")
    
    with col3:
        # Service health
        service_health = health_data['service_health']
        operational_services = sum(1 for s in service_health.values() if s['status'] == 'operational')
        total_services = len(service_health)
        avg_service_health = sum(s['availability_score'] for s in service_health.values()) / total_services
        
        st.metric("⚙️ Services", f"{operational_services}/{total_services}", f"{avg_service_health:.1f}% avg")
    
    with col4:
        # Performance metrics
        perf_metrics = health_data['performance_metrics']
        avg_response_time = perf_metrics['avg_response_time_ms']
        error_rate = perf_metrics['avg_error_rate']
        
        st.metric("⚡ Performance", f"{avg_response_time:.0f}ms", f"{error_rate:.2%} errors")

def render_aha_gateway_health(health_data: Dict[str, Any]):
    """Render gateway health details"""
    
    st.markdown("### 🔌 Gateway Health")
    
    gateway_health = health_data['gateway_health']
    
    # Create columns for gateway cards
    cols = st.columns(len(gateway_health))
    
    for i, (gateway_name, gateway_data) in enumerate(gateway_health.items()):
        with cols[i]:
            # Gateway card
            health_score = gateway_data['health_score']
            status = gateway_data['status']
            response_time = gateway_data['response_time_ms']
            error_rate = gateway_data['error_rate']
            
            # Status color
            if status == 'healthy':
                st.success(f"**{gateway_name.replace('_', ' ').title()}**")
            elif status == 'degraded':
                st.warning(f"**{gateway_name.replace('_', ' ').title()}**")
            else:
                st.error(f"**{gateway_name.replace('_', ' ').title()}**")
            
            # Health metrics
            st.metric("Health Score", f"{health_score:.1f}%")
            st.metric("Response Time", f"{response_time}ms")
            st.metric("Error Rate", f"{error_rate:.2%}")
            
            if 'error' in gateway_data:
                st.error(f"Error: {gateway_data['error']}")

def render_aha_service_health(health_data: Dict[str, Any]):
    """Render service health details"""
    
    st.markdown("### ⚙️ Service Health")
    
    service_health = health_data['service_health']
    
    # Create columns for service cards
    cols = st.columns(len(service_health))
    
    for i, (service_name, service_data) in enumerate(service_health.items()):
        with cols[i]:
            # Service card
            availability_score = service_data['availability_score']
            status = service_data['status']
            response_time = service_data['response_time_ms']
            
            # Status color
            if status == 'operational':
                st.success(f"**{service_name.replace('_', ' ').title()}**")
            else:
                st.error(f"**{service_name.replace('_', ' ').title()}**")
            
            # Service metrics
            st.metric("Availability", f"{availability_score:.1f}%")
            st.metric("Response Time", f"{response_time}ms")
            
            # Additional info
            if service_name == 'mlflow':
                st.caption(f"Database: {'✅' if service_data.get('database_connected') else '❌'}")
            elif service_name == 'postgresql':
                st.caption(f"Pool: {service_data.get('connection_pool', 'unknown')}")
            elif service_name == 'aws_s3':
                st.caption(f"Bucket: {'✅' if service_data.get('bucket_accessible') else '❌'}")
            elif service_name == 'bedrock':
                st.caption(f"Models: {'✅' if service_data.get('model_access') else '❌'}")

def render_rag_systems_health(health_data: Dict[str, Any]):
    """Render RAG systems health monitoring"""

    st.markdown("### 🧠 RAG Systems Health")

    rag_health = health_data.get('rag_systems_health', {})

    if rag_health.get('status') == 'knowledge_interface_unavailable':
        st.warning("Knowledge Interface not available for RAG monitoring")
        return

    # Overall RAG health summary
    col1, col2, col3 = st.columns(3)

    with col1:
        overall_score = rag_health.get('overall_health_score', 0)
        st.metric(
            "Overall RAG Health",
            f"{overall_score:.1f}%",
            delta=f"+{(overall_score-85):.1f}%" if overall_score > 85 else f"{(overall_score-85):.1f}%"
        )

    with col2:
        active_adapters = rag_health.get('active_adapters', 0)
        total_adapters = rag_health.get('total_adapters', 5)
        st.metric(
            "Active Adapters",
            f"{active_adapters}/{total_adapters}",
            delta=f"+{active_adapters-3}" if active_adapters > 3 else f"{active_adapters-3}"
        )

    with col3:
        system_status = rag_health.get('status', 'unknown')
        status_color = "🟢" if system_status == 'operational' else "🟡" if system_status == 'degraded' else "🔴"
        st.metric("System Status", f"{status_color} {system_status.title()}")

    st.markdown("---")

    # Individual adapter health
    st.markdown("#### RAG Adapter Details")

    adapters = rag_health.get('adapters', {})

    if adapters:
        # Create 5 columns for 5 adapters
        cols = st.columns(5)

        for i, (adapter_name, adapter_data) in enumerate(adapters.items()):
            with cols[i % 5]:
                # Adapter status indicator
                status = adapter_data.get('status', 'unknown')
                health_score = adapter_data.get('health_score', 0)
                response_time = adapter_data.get('response_time_ms', 0)

                if status == 'operational':
                    st.success(f"**{adapter_name}**")
                elif status == 'degraded':
                    st.warning(f"**{adapter_name}**")
                else:
                    st.error(f"**{adapter_name}**")

                # Adapter metrics
                st.metric("Health Score", f"{health_score:.1f}%")
                st.metric("Response Time", f"{response_time}ms")

                # Usage statistics
                if 'queries_processed' in adapter_data:
                    st.caption(f"Queries: {adapter_data['queries_processed']}")
                if 'success_rate' in adapter_data:
                    st.caption(f"Success: {adapter_data['success_rate']:.1f}%")

                # Last query info
                last_query = adapter_data.get('last_query', 'Never')
                if last_query != 'Never':
                    st.caption(f"Last: {last_query[:10]}...")
                else:
                    st.caption("Last: Never")
    else:
        st.info("No RAG adapter data available. Check KnowledgeInterface integration.")

    # Usage tracking summary
    st.markdown("#### 📊 Adapter Usage Events")

    # Show recent adapter selection events
    usage_events = [
        {"time": "2 min ago", "event": "Legal RAG → Intelligent RAG", "user": "template_creation"},
        {"time": "5 min ago", "event": "Financial RAG → AI-Powered RAG", "user": "custom_rag"},
        {"time": "8 min ago", "event": "Technical RAG → SME RAG", "user": "template_creation"},
        {"time": "12 min ago", "event": "General RAG → Expert RAG", "user": "fallback"},
        {"time": "15 min ago", "event": "Advanced RAG → Postgres RAG", "user": "performance_tracking"}
    ]

    for event in usage_events:
        st.text(f"⏱️ {event['time']}: {event['event']} ({event['user']})")

def render_aha_performance_charts(health_data: Dict[str, Any]):
    """Render performance charts"""
    
    st.markdown("### 📊 Performance Analytics")
    
    # Create sample historical data for charts
    timestamps = [datetime.now() - timedelta(minutes=i) for i in range(60, 0, -1)]
    
    # Mock historical data
    response_times = [200 + (i % 10) * 20 for i in range(60)]
    health_scores = [95 + (i % 5) for i in range(60)]
    
    # Response time chart
    fig_response = go.Figure()
    fig_response.add_trace(go.Scatter(
        x=timestamps,
        y=response_times,
        mode='lines',
        name='Response Time (ms)',
        line=dict(color='blue')
    ))
    fig_response.update_layout(
        title="Response Time Trend (Last Hour)",
        xaxis_title="Time",
        yaxis_title="Response Time (ms)",
        height=300
    )
    st.plotly_chart(fig_response, width="stretch")
    
    # Health score chart
    fig_health = go.Figure()
    fig_health.add_trace(go.Scatter(
        x=timestamps,
        y=health_scores,
        mode='lines',
        name='Health Score (%)',
        line=dict(color='green')
    ))
    fig_health.update_layout(
        title="Health Score Trend (Last Hour)",
        xaxis_title="Time",
        yaxis_title="Health Score (%)",
        height=300
    )
    st.plotly_chart(fig_health, width="stretch")

def render_aha_alerts(health_data: Dict[str, Any]):
    """Render recent alerts"""
    
    st.markdown("### 🚨 Recent Alerts")
    
    recent_alerts = health_data['recent_alerts']
    
    if recent_alerts:
        for alert in recent_alerts:
            alert_time = datetime.fromisoformat(alert['timestamp']).strftime('%H:%M:%S')
            level = alert['level']
            component = alert['component']
            message = alert['message']
            resolved = alert['resolved']
            
            if level == 'CRITICAL':
                st.error(f"🚨 **{level}** - {component} at {alert_time}")
            elif level == 'WARNING':
                st.warning(f"⚠️ **{level}** - {component} at {alert_time}")
            else:
                st.info(f"ℹ️ **{level}** - {component} at {alert_time}")
            
            st.caption(f"{message} {'✅ Resolved' if resolved else '⏳ Active'}")
    else:
        st.success("✅ No recent alerts")

def render_aha_sidebar(health_data: Dict[str, Any], page: str):
    """Render AHA sidebar"""

    st.sidebar.markdown("## 💓 AHA Health Status")

    overall_health = health_data['overall_health_score']
    health_status = health_data['health_status']

    # Overall health in sidebar
    if overall_health >= 90:
        st.sidebar.success(f"**{overall_health:.1f}% - {health_status}**")
    elif overall_health >= 70:
        st.sidebar.warning(f"**{overall_health:.1f}% - {health_status}**")
    else:
        st.sidebar.error(f"**{overall_health:.1f}% - {health_status}**")

    st.sidebar.markdown("---")

    # Page navigation
    st.sidebar.markdown("## 📋 Navigation")
    page_options = ["System Monitor", "Configuration Management"]
    current_index = 0
    if page == "System Monitor":
        current_index = 1
    elif page == "Configuration Management":
        current_index = 2

    page_selection = st.sidebar.radio(
        "Choose Page",
        page_options,
        index=current_index
    )

    # Update session state for page navigation
    st.session_state.current_page = page_selection

    st.sidebar.markdown("---")

    # Gateway status
    st.sidebar.markdown("**🔌 Gateways:**")
    gateway_health = health_data['gateway_health']
    for gateway_name, gateway_data in gateway_health.items():
        status_icon = "🟢" if gateway_data['status'] == 'healthy' else "🔴"
        health_score = gateway_data['health_score']
        st.sidebar.markdown(f"{status_icon} {gateway_name.replace('_', ' ').title()}: {health_score:.1f}%")

    st.sidebar.markdown("---")

    # Service status
    st.sidebar.markdown("**⚙️ Services:**")
    service_health = health_data['service_health']
    for service_name, service_data in service_health.items():
        status_icon = "🟢" if service_data['status'] == 'operational' else "🔴"
        availability = service_data['availability_score']
        st.sidebar.markdown(f"{status_icon} {service_name.replace('_', ' ').title()}: {availability:.1f}%")

    st.sidebar.markdown("---")

    # Performance summary
    perf_metrics = health_data['performance_metrics']
    st.sidebar.markdown("**⚡ Performance:**")
    st.sidebar.markdown(f"Avg Response: {perf_metrics['avg_response_time_ms']:.0f}ms")
    st.sidebar.markdown(f"Error Rate: {perf_metrics['avg_error_rate']:.2%}")
    st.sidebar.markdown(f"Connections: {perf_metrics['total_connections']}")

    return page_selection

def render_resource_usage(monitor_data: Dict[str, Any]):
    """Render resource usage monitoring."""
    st.header("💻 Resource Usage")

    resource_data = monitor_data['resource_usage']

    # Resource usage metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        cpu_usage = resource_data['cpu_usage']
        if cpu_usage > 80:
            st.error(f"🔥 **CPU Usage: {cpu_usage}%**")
        elif cpu_usage > 60:
            st.warning(f"⚠️ **CPU Usage: {cpu_usage}%**")
        else:
            st.success(f"✅ **CPU Usage: {cpu_usage}%**")

    with col2:
        memory_usage = resource_data['memory_usage']
        if memory_usage > 85:
            st.error(f"🔥 **Memory: {memory_usage}%**")
        elif memory_usage > 70:
            st.warning(f"⚠️ **Memory: {memory_usage}%**")
        else:
            st.success(f"✅ **Memory: {memory_usage}%**")

    with col3:
        disk_usage = resource_data['disk_usage']
        if disk_usage > 90:
            st.error(f"🔥 **Disk: {disk_usage}%**")
        elif disk_usage > 75:
            st.warning(f"⚠️ **Disk: {disk_usage}%**")
        else:
            st.success(f"✅ **Disk: {disk_usage}%**")

    with col4:
        network_io = resource_data['network_io']
        st.metric("🌐 Network I/O", f"{network_io:.1f} MB/s")

    # Resource usage charts
    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        # Resource usage gauge chart
        fig_gauge = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = cpu_usage,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "CPU Usage (%)"},
            delta = {'reference': 50},
            gauge = {
                'axis': {'range': [None, 100]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 60], 'color': "lightgray"},
                    {'range': [60, 80], 'color': "yellow"},
                    {'range': [80, 100], 'color': "red"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 80
                }
            }
        ))
        fig_gauge.update_layout(height=300)
        st.plotly_chart(fig_gauge, width="stretch")

    with col_chart2:
        # Memory usage chart
        timestamps = [datetime.now() - timedelta(minutes=i) for i in range(30, 0, -1)]
        memory_history = [70 + (i % 8) for i in range(30)]

        fig_memory = go.Figure()
        fig_memory.add_trace(go.Scatter(
            x=timestamps,
            y=memory_history,
            mode='lines+markers',
            name='Memory Usage (%)',
            line=dict(color='blue', width=3)
        ))
        fig_memory.update_layout(
            title="Memory Usage Trend (Last 30 minutes)",
            xaxis_title="Time",
            yaxis_title="Memory Usage (%)",
            height=300
        )
        st.plotly_chart(fig_memory, width="stretch")

    # Additional resource metrics
    col_add1, col_add2 = st.columns(2)

    with col_add1:
        st.metric("🔗 Active Connections", resource_data['active_connections'])
        st.metric("🧵 Thread Pool Usage", f"{resource_data['thread_pool_usage']}%")

    with col_add2:
        st.markdown("**Resource Alerts:**")
        if cpu_usage > 80:
            st.error("⚠️ High CPU usage detected")
        if memory_usage > 85:
            st.error("⚠️ High memory usage detected")
        if resource_data['active_connections'] > 50:
            st.warning("⚠️ High connection count")
        if cpu_usage <= 80 and memory_usage <= 85 and resource_data['active_connections'] <= 50:
            st.success("✅ All resources within normal ranges")

def render_processing_metrics(monitor_data: Dict[str, Any]):
    """Render processing metrics monitoring."""
    st.header("⚙️ Processing Metrics")

    processing_data = monitor_data['processing_metrics']

    # Processing overview metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric("📄 Total Processed", processing_data['total_documents_processed'])

    with col2:
        queue_size = processing_data['processing_queue_size']
        if queue_size > 20:
            st.error(f"📋 **Queue: {queue_size}**")
        elif queue_size > 10:
            st.warning(f"📋 **Queue: {queue_size}**")
        else:
            st.success(f"📋 **Queue: {queue_size}**")

    with col3:
        avg_time = processing_data['avg_processing_time']
        if avg_time > 300:
            st.error(f"⏱️ **Avg Time: {avg_time}ms**")
        elif avg_time > 200:
            st.warning(f"⏱️ **Avg Time: {avg_time}ms**")
        else:
            st.success(f"⏱️ **Avg Time: {avg_time}ms**")

    with col4:
        success_rate = processing_data['success_rate']
        if success_rate < 90:
            st.error(f"✅ **Success: {success_rate}%**")
        elif success_rate < 95:
            st.warning(f"✅ **Success: {success_rate}%**")
        else:
            st.success(f"✅ **Success: {success_rate}%**")

    # Processing charts
    col_chart1, col_chart2 = st.columns(2)

    with col_chart1:
        # Throughput chart
        hours = [f"{i}:00" for i in range(24, 24-12, -1)]
        throughput_data = [110, 118, 95, 132, 124, 140, 108, 125, 115, 138, 122, 124]

        fig_throughput = px.bar(
            x=hours,
            y=throughput_data,
            title="Documents Processed per Hour",
            labels={'x': 'Hour', 'y': 'Documents/Hour'}
        )
        fig_throughput.update_layout(height=300)
        st.plotly_chart(fig_throughput, width="stretch")

    with col_chart2:
        # Processing time distribution
        processing_times = ['<100ms', '100-200ms', '200-300ms', '300-500ms', '>500ms']
        time_counts = [23, 45, 38, 12, 6]

        fig_distribution = px.pie(
            values=time_counts,
            names=processing_times,
            title="Processing Time Distribution"
        )
        fig_distribution.update_layout(height=300)
        st.plotly_chart(fig_distribution, width="stretch")

    # Processing status breakdown
    col_status1, col_status2 = st.columns(2)

    with col_status1:
        st.metric("⏳ Pending", processing_data['pending_processes'])
        st.metric("❌ Failed", processing_data['failed_processes'])
        st.metric("📈 Throughput/Hour", processing_data['throughput_per_hour'])

    with col_status2:
        st.markdown("**Processing Health:**")
        if processing_data['success_rate'] >= 95:
            st.success("✅ Processing running smoothly")
        elif processing_data['success_rate'] >= 90:
            st.warning("⚠️ Moderate processing issues")
        else:
            st.error("🚨 Critical processing issues")

        if processing_data['processing_queue_size'] > 15:
            st.warning("⚠️ High queue backlog detected")

        if processing_data['avg_processing_time'] > 250:
            st.warning("⚠️ Slow processing times detected")

def render_error_tracking(monitor_data: Dict[str, Any]):
    """Render error tracking monitoring."""
    st.header("🚨 Error Tracking")

    error_data = monitor_data['error_tracking']

    # Error overview metrics
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        total_errors = error_data['total_errors_24h']
        if total_errors > 50:
            st.error(f"🚨 **Total Errors: {total_errors}**")
        elif total_errors > 20:
            st.warning(f"⚠️ **Total Errors: {total_errors}**")
        else:
            st.success(f"✅ **Total Errors: {total_errors}**")

    with col2:
        critical_errors = error_data['critical_errors']
        if critical_errors > 0:
            st.error(f"🔥 **Critical: {critical_errors}**")
        else:
            st.success(f"✅ **Critical: {critical_errors}**")

    with col3:
        warnings = error_data['warnings']
        if warnings > 10:
            st.warning(f"⚠️ **Warnings: {warnings}**")
        else:
            st.success(f"✅ **Warnings: {warnings}**")

    with col4:
        info_events = error_data['info_events']
        st.metric("ℹ️ Info Events", info_events)

    # Error trend and top errors
    col_trend, col_top = st.columns([1, 1])

    with col_trend:
        # Error rate trend
        trend_data = error_data['error_rate_trend']
        periods = ['Period 1', 'Period 2', 'Period 3', 'Period 4', 'Period 5']

        fig_trend = go.Figure()
        fig_trend.add_trace(go.Scatter(
            x=periods,
            y=trend_data,
            mode='lines+markers',
            name='Error Rate Change (%)',
            line=dict(color='red', width=3),
            marker=dict(size=8)
        ))
        fig_trend.update_layout(
            title="Error Rate Trend (% Change)",
            xaxis_title="Time Period",
            yaxis_title="Change (%)",
            height=300
        )
        fig_trend.add_hline(y=0, line_dash="dash", line_color="gray")
        st.plotly_chart(fig_trend, width="stretch")

    with col_top:
        # Top errors table
        st.markdown("**🔝 Top Errors (24h):**")

        top_errors = error_data['top_errors']
        for i, error in enumerate(top_errors, 1):
            with st.container():
                col_num, col_error, col_count, col_time = st.columns([0.5, 3, 1, 1.5])

                with col_num:
                    st.write(f"**{i}.**")

                with col_error:
                    if error['count'] >= 5:
                        st.error(f"**{error['error']}**")
                    else:
                        st.warning(f"**{error['error']}**")

                with col_count:
                    st.write(f"**{error['count']}x**")

                with col_time:
                    st.caption(error['last_seen'])

    # Error severity breakdown
    st.markdown("**Error Severity Breakdown:**")
    col_severity1, col_severity2, col_severity3 = st.columns(3)

    with col_severity1:
        if error_data['critical_errors'] > 0:
            st.error(f"🔥 **Critical: {error_data['critical_errors']}** - Immediate attention required")
        else:
            st.success("🔥 **Critical: 0** - No critical errors")

    with col_severity2:
        if error_data['warnings'] > 10:
            st.warning(f"⚠️ **Warnings: {error_data['warnings']}** - Monitor closely")
        else:
            st.success(f"⚠️ **Warnings: {error_data['warnings']}** - Normal level")

    with col_severity3:
        st.info(f"ℹ️ **Info: {error_data['info_events']}** - Informational events")

def load_credentials():
    """Load real credentials for backend connections"""
    try:
        settings_path = Path("C:/Users/marti/AI-Scoring/tidyllm/admin/settings.yaml")
        with open(settings_path, 'r') as f:
            config = yaml.safe_load(f)
        return config
    except Exception as e:
        st.error(f"Could not load credentials: {e}")
        return None

def safe_json_load(filepath: str) -> Dict[str, Any]:
    """Safe JSON loading with Unicode scrubbing from Boss portal"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
            # Unicode scrubbing
            content = content.encode('utf-8', errors='ignore').decode('utf-8')
            return json.loads(content)
    except Exception as e:
        return {}

def safe_json_save(data: Dict[str, Any], filepath: str) -> bool:
    """Safe JSON saving with Unicode scrubbing from Boss portal"""
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(filepath), exist_ok=True)

        # Unicode scrubbing
        content = json.dumps(data, indent=2, ensure_ascii=False)
        content = content.encode('utf-8', errors='ignore').decode('utf-8')

        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        st.error(f"Error saving configuration: {e}")
        return False

def render_config_management_page():
    """Render the Configuration Management page with multi-environment support"""
    # Clear any existing content
    st.empty()
    st.header("⚙️ Configuration Management")

    st.markdown("""
    **System-level configuration management for TidyLLM Infrastructure**

    Manage credentials, templates, and multi-environment settings from this centralized dashboard.
    """)

    # Create tabs for different config areas
    config_tab1, config_tab2, config_tab3, config_tab4 = st.tabs([
        "🔐 Credentials",
        "🏗️ Templates",
        "🌍 Environments",
        "📊 System Config"
    ])

    with config_tab1:
        render_credentials_management()

    with config_tab2:
        render_template_management()

    with config_tab3:
        render_environment_management()

    with config_tab4:
        render_system_config_management()

    # Add new tabs for direct database access
    st.markdown("---")
    st.subheader("🔧 Direct Database Access")

    db_tab1, db_tab2, db_tab3 = st.tabs([
        "🐘 PostgreSQL Query",
        "🧪 MLflow Management",
        "📦 S3 Direct Access"
    ])

    with db_tab1:
        render_postgresql_query_interface()

    with db_tab2:
        render_mlflow_management_interface()

    with db_tab3:
        render_s3_direct_access_interface()

def render_credentials_management():
    """Render credentials management section"""
    st.subheader("🔐 Credential Management")

    # Load current credentials
    config = load_credentials()
    if not config:
        st.error("Cannot load configuration file")
        return

    # Display current credential status
    st.markdown("### 🔗 Backend Connection Status")

    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.metric(
            "PostgreSQL",
            "✅ Connected",
            "AWS RDS Cluster"
        )
        if config and 'credentials' in config and 'postgresql' in config['credentials']:
            host = config['credentials']['postgresql']['host']
            st.caption(f"Host: {host[:20]}...")

    with col2:
        st.metric(
            "MLflow Tracking",
            "✅ Running",
            "Port 5000"
        )
        st.caption("Tracking experiments")

    with col3:
        st.metric(
            "AWS Bedrock",
            "✅ Available",
            "Claude 3 Sonnet"
        )
        st.caption("Model: anthropic.claude-3-sonnet")

    with col4:
        st.metric(
            "S3 Storage",
            "✅ Connected",
            "nsc-mvp1 bucket"
        )
        st.caption("Artifact storage ready")

    # Configuration editor
    st.markdown("### ⚙️ Configuration Editor")

    if CONFIG_MANAGER_AVAILABLE:
        try:
            config_manager = ConfigManager()
            current_config = config_manager.config

            # Display config validation
            validation_result = config_manager.validate_config()
            if validation_result['valid']:
                st.success("✅ Configuration is valid")
            else:
                st.error(f"❌ Configuration issues: {', '.join(validation_result['issues'])}")
                if validation_result['warnings']:
                    st.warning(f"⚠️ Warnings: {', '.join(validation_result['warnings'])}")

            # Environment selector
            environment = st.selectbox(
                "Select Environment",
                ["development", "staging", "production", "local"],
                index=1 if current_config.environment == "staging" else 0
            )

            if st.button("Update Environment"):
                config_manager.update_config({"environment": environment})
                st.success(f"Environment updated to {environment}")
                st.rerun()

        except Exception as e:
            st.error(f"Error with ConfigManager: {e}")
    else:
        st.warning("ConfigManager not available - using fallback credential display")

def render_template_management():
    """Render template management section from Boss portal"""
    st.subheader("🏗️ Template Management")

    # Show active templates
    st.markdown("### 📋 Active Templates")

    # Mock template data from Boss portal
    active_templates = [
        {
            "name": "financial_analysis_quarterly",
            "description": "Comprehensive quarterly financial analysis with risk assessment",
            "variables": ["executive_summary", "revenue_growth", "risk_score", "market_position"],
            "created": "2025-09-10",
            "last_used": "2025-09-13",
            "usage_count": 47,
            "success_rate": "94.2%"
        },
        {
            "name": "risk_assessment_comprehensive",
            "description": "Multi-dimensional risk evaluation with regulatory compliance",
            "variables": ["risk_factors", "mitigation_strategies", "compliance_status"],
            "created": "2025-09-08",
            "last_used": "2025-09-12",
            "usage_count": 23,
            "success_rate": "91.7%"
        },
        {
            "name": "market_analysis_competitive",
            "description": "Competitive landscape analysis with strategic positioning",
            "variables": ["market_size", "competitors", "positioning", "opportunities"],
            "created": "2025-09-05",
            "last_used": "2025-09-11",
            "usage_count": 15,
            "success_rate": "88.3%"
        }
    ]

    # Display templates in expandable cards
    for template in active_templates:
        with st.expander(f"📄 {template['name']} (Success: {template['success_rate']})"):
            col1, col2, col3 = st.columns(3)

            with col1:
                st.write(f"**Description:** {template['description']}")
                st.write(f"**Usage Count:** {template['usage_count']}")

            with col2:
                st.write(f"**Created:** {template['created']}")
                st.write(f"**Last Used:** {template['last_used']}")

            with col3:
                st.write(f"**Variables:** {len(template['variables'])}")
                for var in template['variables']:
                    st.caption(f"• {var}")

            # Template actions
            col_action1, col_action2, col_action3 = st.columns(3)
            with col_action1:
                if st.button(f"📝 Edit Template", key=f"edit_{template['name']}"):
                    st.info(f"Opening editor for {template['name']}")

            with col_action2:
                if st.button(f"📄 Clone Template", key=f"clone_{template['name']}"):
                    st.success(f"Cloned {template['name']} as {template['name']}_copy")

            with col_action3:
                if st.button(f"🗑️ Archive", key=f"archive_{template['name']}"):
                    st.warning(f"Archived {template['name']}")

def render_environment_management():
    """Render multi-environment management"""
    st.subheader("🌍 Multi-Environment Management")

    # Environment overview
    environments = {
        "development": {
            "status": "Active",
            "s3_prefix": "dev/",
            "log_level": "DEBUG",
            "description": "Development environment for testing"
        },
        "staging": {
            "status": "Active",
            "s3_prefix": "staging/",
            "log_level": "INFO",
            "description": "Staging environment for pre-production testing"
        },
        "production": {
            "status": "Ready",
            "s3_prefix": "prod/",
            "log_level": "WARNING",
            "description": "Production environment"
        },
        "local": {
            "status": "Active",
            "s3_prefix": "staging/",
            "log_level": "INFO",
            "description": "Local development environment"
        }
    }

    # Display environments
    for env_name, env_config in environments.items():
        with st.expander(f"🌍 {env_name.title()} Environment"):
            col1, col2, col3 = st.columns(3)

            with col1:
                status_color = "🟢" if env_config["status"] == "Active" else "🟡"
                st.write(f"**Status:** {status_color} {env_config['status']}")
                st.write(f"**S3 Prefix:** `{env_config['s3_prefix']}`")

            with col2:
                st.write(f"**Log Level:** {env_config['log_level']}")
                st.write(f"**Description:** {env_config['description']}")

            with col3:
                if st.button(f"🔄 Switch to {env_name}", key=f"switch_{env_name}"):
                    st.success(f"Switched to {env_name} environment")

                if st.button(f"⚙️ Configure {env_name}", key=f"config_{env_name}"):
                    st.info(f"Opening configuration for {env_name}")

def render_system_config_management():
    """Render system configuration management"""
    st.subheader("📊 System Configuration")

    if CONFIG_MANAGER_AVAILABLE:
        try:
            config_manager = ConfigManager()
            current_config = config_manager.config

            # System information
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### 📋 Current Configuration")
                st.write(f"**Environment:** {current_config.environment}")
                st.write(f"**Debug Mode:** {current_config.debug_mode}")
                st.write(f"**Log Level:** {current_config.log_level}")
                st.write(f"**Config Version:** {current_config.config_version}")

                if current_config.last_updated:
                    st.write(f"**Last Updated:** {current_config.last_updated}")

            with col2:
                st.markdown("### 🔧 Configuration Actions")

                if st.button("🔄 Reload Configuration"):
                    config_manager._load_config()
                    st.success("Configuration reloaded")
                    st.rerun()

                if st.button("💾 Save Configuration"):
                    if config_manager.save_config():
                        st.success("Configuration saved successfully")
                    else:
                        st.error("Failed to save configuration")

                if st.button("✅ Validate Configuration"):
                    validation = config_manager.validate_config()
                    if validation['valid']:
                        st.success("✅ Configuration is valid")
                    else:
                        st.error("❌ Configuration validation failed")
                        for issue in validation['issues']:
                            st.error(f"• {issue}")

            # Configuration sections
            st.markdown("### 📂 Configuration Sections")

            config_sections = {
                "Database": current_config.database,
                "Gateway": current_config.gateway,
                "AWS": current_config.aws,
                "Research": current_config.research,
                "Compliance": current_config.compliance
            }

            for section_name, section_config in config_sections.items():
                with st.expander(f"📋 {section_name} Configuration"):
                    st.json(section_config.__dict__)

        except Exception as e:
            st.error(f"Error accessing configuration: {e}")
    else:
        # Fallback system configuration using existing load_credentials function
        st.info("Using simplified system configuration (ConfigManager not available)")

        config = load_credentials()
        if config:
            col1, col2 = st.columns(2)

            with col1:
                st.markdown("### 📋 Current Configuration")

                # System configuration from settings.yaml
                system_config = config.get('system', {})
                st.write(f"**Environment:** {config.get('configuration', {}).get('environment', 'Unknown')}")
                st.write(f"**Organization:** {system_config.get('organization', 'Not configured')}")
                st.write(f"**Deployment Type:** {system_config.get('deployment_type', 'Unknown')}")
                st.write(f"**Corporate Mode:** {system_config.get('corporate_mode', False)}")
                st.write(f"**Config Version:** {config.get('configuration', {}).get('version', 'Unknown')}")

                last_updated = config.get('configuration', {}).get('last_updated')
                if last_updated:
                    st.write(f"**Last Updated:** {last_updated}")

            with col2:
                st.markdown("### 🔧 Configuration Actions")

                if st.button("🔄 Reload Configuration", help="Reload configuration from settings.yaml"):
                    # Force reload by clearing any cached values
                    if 'config_cache' in st.session_state:
                        del st.session_state['config_cache']
                    st.success("✅ Configuration cache cleared - will reload on next access")
                    st.rerun()

                if st.button("📊 View Raw Configuration", help="Show raw configuration as JSON"):
                    with st.expander("📄 Raw Configuration (settings.yaml)", expanded=True):
                        st.json(config)

                if st.button("🔍 Validate Configuration", help="Check configuration completeness"):
                    validation_issues = []

                    # Check required sections
                    required_sections = ['credentials', 'services', 'system']
                    for section in required_sections:
                        if section not in config:
                            validation_issues.append(f"Missing required section: {section}")

                    # Check PostgreSQL credentials
                    pg_creds = config.get('credentials', {}).get('postgresql', {})
                    required_pg_fields = ['host', 'port', 'database', 'username', 'password']
                    for field in required_pg_fields:
                        if not pg_creds.get(field):
                            validation_issues.append(f"Missing PostgreSQL credential: {field}")

                    # Check MLflow configuration
                    mlflow_config = config.get('services', {}).get('mlflow', {})
                    if not mlflow_config.get('enabled'):
                        validation_issues.append("MLflow is not enabled")
                    if not mlflow_config.get('tracking_uri'):
                        validation_issues.append("MLflow tracking_uri not configured")

                    if not validation_issues:
                        st.success("✅ Configuration validation passed!")
                    else:
                        st.error("❌ Configuration validation failed:")
                        for issue in validation_issues:
                            st.error(f"• {issue}")

            # Configuration sections overview
            st.markdown("### 📂 Configuration Sections")

            sections = {
                "🔐 Credentials": config.get('credentials', {}),
                "⚙️ Services": config.get('services', {}),
                "🏗️ Integrations": config.get('integrations', {}),
                "🖥️ System": config.get('system', {}),
                "🗃️ Databases": config.get('databases', {}),
                "🎛️ Features": config.get('features', {}),
                "📊 Operations": config.get('operations', {})
            }

            for section_name, section_data in sections.items():
                if section_data:  # Only show sections that have data
                    with st.expander(f"{section_name} Configuration"):
                        st.json(section_data)

        else:
            st.error("❌ Could not load configuration from settings.yaml")

def render_postgresql_query_interface():
    """Render PostgreSQL direct query interface"""
    st.subheader("🐘 PostgreSQL Direct Query Interface")

    # Load configuration
    config = load_credentials()
    if not config or 'credentials' not in config or 'postgresql' not in config['credentials']:
        st.error("PostgreSQL configuration not found. Please configure credentials first.")
        return

    # Connection info display
    db_config = config['credentials']['postgresql']
    st.info(f"**Connected to:** {db_config['host']}:{db_config['port']}/{db_config['database']}")

    # PostgreSQL Connection Configuration
    with st.expander("⚙️ PostgreSQL Connection Settings"):
        col1, col2 = st.columns([2, 1])

        with col1:
            st.markdown("##### Database Configuration")

            new_host = st.text_input(
                "Host",
                value=db_config.get('host', ''),
                help="PostgreSQL server hostname or IP",
                key="pg_host"
            )

            col_port, col_db = st.columns(2)
            with col_port:
                new_port = st.number_input(
                    "Port",
                    value=int(db_config.get('port', 5432)),
                    min_value=1,
                    max_value=65535
                )
            with col_db:
                new_database = st.text_input(
                    "Database",
                    value=db_config.get('database', ''),
                    help="Database name",
                    key="pg_database"
                )

            new_username = st.text_input(
                "Username",
                value=db_config.get('username', ''),
                help="Database username",
                key="pg_username"
            )

            new_password = st.text_input(
                "Password",
                value=db_config.get('password', ''),
                type="password",
                help="Database password",
                key="pg_password"
            )

        with col2:
            st.markdown("##### Actions")

            # Test connection button
            if st.button("🧪 Test DB Connection", width="stretch"):
                with st.spinner("Testing PostgreSQL connection..."):
                    try:
                        # Test the new connection settings
                        test_conn = psycopg2.connect(
                            host=new_host,
                            port=new_port,
                            database=new_database,
                            user=new_username,
                            password=new_password,
                            connect_timeout=5
                        )

                        # Test a simple query
                        with test_conn.cursor() as cursor:
                            cursor.execute("SELECT version();")
                            version = cursor.fetchone()[0]

                        test_conn.close()

                        st.success("✅ Database connection successful!")
                        st.info(f"Server: {version[:50]}...")

                    except psycopg2.OperationalError as e:
                        st.error(f"❌ Connection failed: {str(e)}")
                    except Exception as e:
                        st.error(f"❌ Connection failed: {str(e)}")

            # Save configuration button
            if st.button("💾 Save DB Config", width="stretch"):
                try:
                    # Update the configuration
                    config['credentials']['postgresql']['host'] = new_host
                    config['credentials']['postgresql']['port'] = new_port
                    config['credentials']['postgresql']['database'] = new_database
                    config['credentials']['postgresql']['username'] = new_username
                    config['credentials']['postgresql']['password'] = new_password

                    # Save to settings file
                    import yaml
                    settings_path = Path(__file__).parent.parent.parent / "admin" / "settings.yaml"

                    if settings_path.exists():
                        with open(settings_path, 'w') as f:
                            yaml.dump(config, f, default_flow_style=False, sort_keys=False)

                        st.success("✅ Database configuration saved!")
                        st.info("ℹ️ Page will refresh to use new settings")
                        time.sleep(1)
                        st.rerun()
                    else:
                        st.error("❌ Settings file not found")

                except Exception as e:
                    st.error(f"❌ Failed to save configuration: {str(e)}")

    # Pre-defined useful queries
    st.markdown("### 📋 Quick Queries")

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("📊 Database Stats"):
            st.session_state.pg_query = """-- Database Statistics
SELECT
    schemaname,
    tablename,
    n_tup_ins as inserts,
    n_tup_upd as updates,
    n_tup_del as deletes,
    n_live_tup as live_rows,
    n_dead_tup as dead_rows
FROM pg_stat_user_tables
ORDER BY n_live_tup DESC
LIMIT 10;"""

    with col2:
        if st.button("🔗 Active Connections"):
            st.session_state.pg_query = """-- Active Connections
SELECT
    datname as database,
    usename as username,
    client_addr,
    state,
    backend_start,
    query_start,
    LEFT(query, 50) as current_query
FROM pg_stat_activity
WHERE state = 'active'
ORDER BY backend_start DESC;"""

    with col3:
        if st.button("💾 Table Sizes"):
            st.session_state.pg_query = """-- Table Sizes
SELECT
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size,
    pg_total_relation_size(schemaname||'.'||tablename) as size_bytes
FROM pg_tables
WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
ORDER BY size_bytes DESC
LIMIT 15;"""

    # Custom query interface
    st.markdown("### ✏️ Custom Query")

    # Initialize session state for query
    if 'pg_query' not in st.session_state:
        st.session_state.pg_query = "SELECT version();"

    query = st.text_area(
        "Enter PostgreSQL Query:",
        value=st.session_state.pg_query,
        height=150,
        help="Enter any PostgreSQL query. Be careful with UPDATE/DELETE operations!"
    )

    # Quick action buttons
    col_execute, col_clear, col_tables = st.columns([1, 1, 1])

    with col_execute:
        if st.button("🚀 Execute Query", type="primary"):
            execute_postgresql_query(query, db_config)

    with col_clear:
        if st.button("🗑️ Clear"):
            st.session_state.pg_query = ""
            st.rerun()

    with col_tables:
        if st.button("📋 List All Tables", help="Discover all tables in the database"):
            discover_database_tables(db_config)

def execute_postgresql_query(query: str, db_config: Dict[str, Any]):
    """Execute PostgreSQL query and display results"""
    if not query.strip():
        st.warning("Please enter a query to execute.")
        return

    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=db_config['host'],
            port=db_config['port'],
            database=db_config['database'],
            user=db_config['username'],
            password=db_config['password'],
            sslmode=db_config.get('ssl_mode', 'prefer'),
            connect_timeout=10
        )

        cursor = conn.cursor()

        # Execute query with timing
        start_time = time.time()
        cursor.execute(query)
        execution_time = time.time() - start_time

        # Handle different query types
        if query.strip().upper().startswith(('SELECT', 'SHOW', 'EXPLAIN')):
            # Fetch results for SELECT queries
            results = cursor.fetchall()
            columns = [desc[0] for desc in cursor.description] if cursor.description else []

            if results:
                # Convert to DataFrame for better display
                import pandas as pd
                df = pd.DataFrame(results, columns=columns)

                st.success(f"✅ Query executed successfully in {execution_time:.2f} seconds")

                # Results header with statistics
                col_stats1, col_stats2, col_stats3 = st.columns(3)
                with col_stats1:
                    st.metric("Rows Returned", len(results))
                with col_stats2:
                    st.metric("Columns", len(columns))
                with col_stats3:
                    st.metric("Execution Time", f"{execution_time:.3f}s")

                # Display the data table
                st.markdown(f"**Query Results:**")
                st.dataframe(df, width="stretch", height=400)

                # Enhanced download options
                col_download1, col_download2 = st.columns(2)

                with col_download1:
                    # CSV download
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="📥 Download as CSV",
                        data=csv,
                        file_name=f"query_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                        mime="text/csv",
                        width="stretch"
                    )

                with col_download2:
                    # JSON download option
                    import json
                    json_data = df.to_json(orient='records', indent=2)
                    st.download_button(
                        label="📄 Download as JSON",
                        data=json_data,
                        file_name=f"query_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json",
                        width="stretch"
                    )

                # Data preview/summary
                if len(results) > 10:
                    st.info(f"💡 Showing all {len(results)} rows. Use the download buttons to get the complete dataset.")

                # Column information
                with st.expander("📋 Column Information"):
                    col_info = []
                    for i, col_name in enumerate(columns):
                        sample_value = df[col_name].iloc[0] if len(df) > 0 else None
                        data_type = type(sample_value).__name__ if sample_value is not None else "unknown"
                        col_info.append({
                            "Column": col_name,
                            "Data Type": data_type,
                            "Sample Value": str(sample_value) if sample_value is not None else "NULL"
                        })

                    import pandas as pd
                    col_df = pd.DataFrame(col_info)
                    st.dataframe(col_df, width="stretch")
            else:
                st.info("Query executed successfully but returned no results.")

        else:
            # For INSERT, UPDATE, DELETE queries
            affected_rows = cursor.rowcount
            conn.commit()
            st.success(f"✅ Query executed successfully in {execution_time:.2f} seconds")
            st.info(f"Affected rows: {affected_rows}")

        cursor.close()
        conn.close()

    except Exception as e:
        st.error(f"❌ Query execution failed: {str(e)}")


def discover_database_tables(db_config: Dict[str, Any]):
    """Discover and display all tables in the PostgreSQL database with MLflow identification"""
    st.markdown("### 📋 Database Table Discovery")

    try:
        # Connect to PostgreSQL
        conn = psycopg2.connect(
            host=db_config['host'],
            port=db_config['port'],
            database=db_config['database'],
            user=db_config['username'],
            password=db_config['password'],
            sslmode=db_config.get('ssl_mode', 'prefer'),
            connect_timeout=10
        )

        cursor = conn.cursor()

        # Query for all tables with schema information
        table_query = """
        SELECT
            schemaname,
            tablename,
            tableowner,
            hasindexes,
            hasrules,
            hastriggers
        FROM pg_tables
        WHERE schemaname NOT IN ('information_schema', 'pg_catalog', 'pg_toast')
        ORDER BY schemaname, tablename;
        """

        cursor.execute(table_query)
        tables = cursor.fetchall()

        if tables:
            import pandas as pd

            # Create DataFrame for better display
            df_tables = pd.DataFrame(tables, columns=[
                'Schema', 'Table Name', 'Owner', 'Has Indexes', 'Has Rules', 'Has Triggers'
            ])

            # Identify MLflow tables
            mlflow_tables = [
                'experiments', 'runs', 'metrics', 'params', 'tags',
                'experiment_tags', 'run_tags', 'latest_metrics',
                'model_versions', 'registered_models'
            ]

            df_tables['Type'] = df_tables['Table Name'].apply(
                lambda x: '🧪 MLflow' if x in mlflow_tables else '📊 Standard'
            )

            # Statistics
            col_stat1, col_stat2, col_stat3, col_stat4 = st.columns(4)

            with col_stat1:
                st.metric("Total Tables", len(tables))
            with col_stat2:
                mlflow_count = len([t for t in tables if t[1] in mlflow_tables])
                st.metric("MLflow Tables", mlflow_count)
            with col_stat3:
                standard_count = len(tables) - mlflow_count
                st.metric("Standard Tables", standard_count)
            with col_stat4:
                schemas = len(set([t[0] for t in tables]))
                st.metric("Schemas", schemas)

            # Display tables with filtering
            st.markdown("**Table Listing:**")

            # Filter options
            col_filter1, col_filter2 = st.columns(2)

            with col_filter1:
                show_mlflow = st.checkbox("Show MLflow Tables", value=True)
            with col_filter2:
                show_standard = st.checkbox("Show Standard Tables", value=True)

            # Apply filters
            filtered_df = df_tables.copy()
            if not show_mlflow:
                filtered_df = filtered_df[~filtered_df['Table Name'].isin(mlflow_tables)]
            if not show_standard:
                filtered_df = filtered_df[filtered_df['Table Name'].isin(mlflow_tables)]

            # Display the filtered table
            st.dataframe(filtered_df, width="stretch", height=400)

            # Quick action buttons for common queries
            st.markdown("**🚀 Quick Query Templates:**")

            col_btn1, col_btn2, col_btn3, col_btn4 = st.columns(4)

            with col_btn1:
                if st.button("📊 MLflow Experiments", help="Query MLflow experiments"):
                    st.session_state.pg_query = "SELECT * FROM experiments ORDER BY creation_time DESC LIMIT 10;"
                    st.rerun()

            with col_btn2:
                if st.button("🏃 Recent MLflow Runs", help="Query recent MLflow runs"):
                    st.session_state.pg_query = "SELECT experiment_id, run_id, status, start_time, end_time FROM runs ORDER BY start_time DESC LIMIT 10;"
                    st.rerun()

            with col_btn3:
                if st.button("📈 MLflow Metrics", help="Query MLflow metrics"):
                    st.session_state.pg_query = "SELECT run_id, key, value, timestamp FROM metrics ORDER BY timestamp DESC LIMIT 10;"
                    st.rerun()

            with col_btn4:
                if st.button("🔍 Table Sizes", help="Check table sizes"):
                    st.session_state.pg_query = """
SELECT
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables
WHERE schemaname NOT IN ('information_schema', 'pg_catalog')
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
"""
                    st.rerun()

            # MLflow-specific insights
            if mlflow_count > 0:
                with st.expander("🧪 MLflow Table Insights"):
                    st.markdown("""
                    **MLflow Tables Found in Database:**

                    - **experiments**: MLflow experiment metadata
                    - **runs**: Individual MLflow runs and their status
                    - **metrics**: Model performance metrics over time
                    - **params**: Hyperparameters used in runs
                    - **tags**: User-defined tags for experiments and runs
                    - **experiment_tags**: Tags associated with experiments
                    - **run_tags**: Tags associated with individual runs
                    - **latest_metrics**: Most recent metric values for each run
                    - **model_versions**: Versioned model registry entries
                    - **registered_models**: Model registry metadata

                    **💡 Tip:** You can query these tables directly to analyze your ML experiments,
                    compare model performance, and track experiment metadata.
                    """)

            # Download table list
            col_download = st.columns(1)[0]
            with col_download:
                csv_tables = df_tables.to_csv(index=False)
                st.download_button(
                    label="📥 Download Table List as CSV",
                    data=csv_tables,
                    file_name=f"database_tables_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    width="stretch"
                )

        else:
            st.warning("No user tables found in the database.")

        cursor.close()
        conn.close()

    except Exception as e:
        st.error(f"❌ Failed to discover tables: {str(e)}")


def render_mlflow_management_interface():
    """Render MLflow management interface"""
    st.subheader("🧪 MLflow Management Interface")

    # Load configuration
    config = load_credentials()
    mlflow_url = config.get('services', {}).get('mlflow', {}).get('tracking_uri', 'http://localhost:5000') if config else 'http://localhost:5000'

    st.info(f"**MLflow Server:** {mlflow_url}")

    # MLflow server status
    try:
        health_response = requests.get(f"{mlflow_url}/health", timeout=3)
        if health_response.status_code == 200:
            st.success("✅ MLflow server is healthy")
        else:
            st.warning("⚠️ MLflow server responding but may have issues")
    except:
        st.error("❌ Cannot connect to MLflow server")
        return

    # Tabs for different MLflow operations
    mlflow_tab1, mlflow_tab2, mlflow_tab3, mlflow_tab4 = st.tabs([
        "📊 Experiments",
        "🏃 Recent Runs",
        "🎛️ Management",
        "⚙️ Configuration"
    ])

    with mlflow_tab1:
        render_mlflow_experiments(mlflow_url)

    with mlflow_tab2:
        render_mlflow_runs(mlflow_url)

    with mlflow_tab3:
        render_mlflow_management(mlflow_url)

    with mlflow_tab4:
        render_mlflow_configuration(config, mlflow_url)

def render_mlflow_experiments(mlflow_url: str):
    """Render MLflow experiments interface"""
    st.markdown("### 📊 MLflow Experiments")

    try:
        # Get experiments
        experiments_response = requests.get(f"{mlflow_url}/api/2.0/mlflow/experiments/search?max_results=20", timeout=5)

        if experiments_response.status_code == 200:
            experiments_data = experiments_response.json()
            experiments = experiments_data.get("experiments", [])

            if experiments:
                # Display experiments in a table
                exp_data = []
                for exp in experiments:
                    exp_data.append({
                        "ID": exp.get("experiment_id"),
                        "Name": exp.get("name"),
                        "Artifact Location": exp.get("artifact_location", "")[:50] + "...",
                        "Lifecycle Stage": exp.get("lifecycle_stage"),
                        "Creation Time": exp.get("creation_time")
                    })

                import pandas as pd
                df = pd.DataFrame(exp_data)
                st.dataframe(df, width="stretch")

                # Experiment selector for detailed view
                selected_exp = st.selectbox(
                    "Select experiment for details:",
                    options=[(exp["name"], exp["experiment_id"]) for exp in experiments],
                    format_func=lambda x: x[0]
                )

                if st.button("🔍 View Experiment Details"):
                    exp_id = selected_exp[1]
                    view_experiment_details(mlflow_url, exp_id)

            else:
                st.info("No experiments found")

        else:
            st.error("Failed to fetch experiments")

    except Exception as e:
        st.error(f"Error fetching experiments: {e}")

def render_mlflow_runs(mlflow_url: str):
    """Render MLflow runs interface"""
    st.markdown("### 🏃 Recent MLflow Runs")

    try:
        # Get recent runs
        runs_response = requests.get(f"{mlflow_url}/api/2.0/mlflow/runs/search",
                                   params={"max_results": 20}, timeout=5)

        if runs_response.status_code == 200:
            runs_data = runs_response.json()
            runs = runs_data.get("runs", [])

            if runs:
                # Display runs in a table
                runs_table_data = []
                for run in runs:
                    info = run.get("info", {})
                    data = run.get("data", {})
                    metrics = data.get("metrics", {})

                    runs_table_data.append({
                        "Run ID": info.get("run_id", "")[:8] + "...",
                        "Experiment ID": info.get("experiment_id"),
                        "Status": info.get("status"),
                        "Start Time": info.get("start_time"),
                        "Metrics": len(metrics),
                        "Artifact URI": info.get("artifact_uri", "")[:30] + "..."
                    })

                import pandas as pd
                df = pd.DataFrame(runs_table_data)
                st.dataframe(df, width="stretch")

            else:
                st.info("No runs found")

        else:
            st.error("Failed to fetch runs")

    except Exception as e:
        st.error(f"Error fetching runs: {e}")

def render_mlflow_management(mlflow_url: str):
    """Render MLflow management tools"""
    st.markdown("### 🎛️ MLflow Management Tools")

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("#### 🔧 Server Operations")

        if st.button("🔄 Refresh Server Status"):
            try:
                health_response = requests.get(f"{mlflow_url}/health", timeout=3)
                version_response = requests.get(f"{mlflow_url}/version", timeout=3)

                if health_response.status_code == 200:
                    st.success("✅ Server is healthy")

                if version_response.status_code == 200:
                    version_data = version_response.json()
                    st.info(f"MLflow Version: {version_data.get('version', 'Unknown')}")

            except Exception as e:
                st.error(f"Health check failed: {e}")

    with col2:
        st.markdown("#### 📈 Quick Stats")

        if st.button("📊 Get Server Statistics"):
            try:
                # Get experiments count
                exp_response = requests.get(f"{mlflow_url}/api/2.0/mlflow/experiments/search?max_results=100", timeout=5)
                exp_count = len(exp_response.json().get("experiments", [])) if exp_response.status_code == 200 else 0

                # Get runs count
                runs_response = requests.get(f"{mlflow_url}/api/2.0/mlflow/runs/search", timeout=5)
                runs_count = len(runs_response.json().get("runs", [])) if runs_response.status_code == 200 else 0

                st.metric("Total Experiments", exp_count)
                st.metric("Recent Runs", runs_count)

            except Exception as e:
                st.error(f"Failed to get statistics: {e}")

    # MLflow Connection Configuration
    st.markdown("---")
    st.markdown("#### ⚙️ MLflow Connection Settings")

    # Load current config
    config = load_credentials()
    current_mlflow_config = config.get('integrations', {}).get('mlflow', {}) if config else {}

    col1, col2 = st.columns([2, 1])

    with col1:
        # Connection settings form
        st.markdown("##### Connection Configuration")

        new_tracking_uri = st.text_input(
            "Tracking URI",
            value=current_mlflow_config.get('tracking_uri', 'http://localhost:5000'),
            help="MLflow tracking server URI",
            key="mlflow_config_tracking_uri"
        )

        new_backend_store = st.text_input(
            "Backend Store URI",
            value=current_mlflow_config.get('backend_store_uri', ''),
            help="Database connection string for MLflow backend",
            key="mlflow_config_backend_store"
        )

        new_artifact_store = st.text_input(
            "Artifact Store",
            value=current_mlflow_config.get('artifact_store', ''),
            help="S3 or local path for artifacts",
            key="mlflow_config_artifact_store"
        )

    with col2:
        st.markdown("##### Actions")

        # Test connection button
        if st.button("🧪 Test Connection", width="stretch"):
            with st.spinner("Testing MLflow connection..."):
                try:
                    # Test the new connection settings
                    test_response = requests.get(f"{new_tracking_uri}/health", timeout=5)

                    if test_response.status_code == 200:
                        st.success("✅ Connection test successful!")

                        # Try to get version info
                        try:
                            version_response = requests.get(f"{new_tracking_uri}/version", timeout=3)
                            if version_response.status_code == 200:
                                version_data = version_response.json()
                                st.info(f"Server Version: {version_data.get('version', 'Unknown')}")
                        except:
                            pass

                        # Try to get experiment count
                        try:
                            exp_response = requests.get(f"{new_tracking_uri}/api/2.0/mlflow/experiments/search?max_results=5", timeout=3)
                            if exp_response.status_code == 200:
                                exp_data = exp_response.json()
                                exp_count = len(exp_data.get('experiments', []))
                                st.info(f"Found {exp_count} experiments")
                        except:
                            pass

                    else:
                        st.error(f"❌ Connection failed: HTTP {test_response.status_code}")

                except requests.exceptions.ConnectionError:
                    st.error("❌ Connection failed: Server not reachable")
                except requests.exceptions.Timeout:
                    st.error("❌ Connection failed: Request timed out")
                except Exception as e:
                    st.error(f"❌ Connection failed: {str(e)}")

        # Save configuration button
        if st.button("💾 Save Configuration", width="stretch"):
            try:
                if config:
                    # Update the configuration
                    if 'integrations' not in config:
                        config['integrations'] = {}
                    if 'mlflow' not in config['integrations']:
                        config['integrations']['mlflow'] = {}

                    config['integrations']['mlflow']['tracking_uri'] = new_tracking_uri
                    config['integrations']['mlflow']['backend_store_uri'] = new_backend_store
                    config['integrations']['mlflow']['artifact_store'] = new_artifact_store

                    # Also update the services section for consistency
                    if 'services' not in config:
                        config['services'] = {}
                    if 'mlflow' not in config['services']:
                        config['services']['mlflow'] = {}

                    config['services']['mlflow']['tracking_uri'] = new_tracking_uri

                    # Save to settings file
                    import yaml
                    settings_path = Path(__file__).parent.parent.parent / "admin" / "settings.yaml"

                    if settings_path.exists():
                        with open(settings_path, 'w') as f:
                            yaml.dump(config, f, default_flow_style=False, sort_keys=False)

                        st.success("✅ Configuration saved successfully!")
                        st.info("ℹ️ Restart services to apply changes")
                    else:
                        st.error("❌ Settings file not found")
                else:
                    st.error("❌ Configuration not loaded")

            except Exception as e:
                st.error(f"❌ Failed to save configuration: {str(e)}")

        # Reset to defaults button
        if st.button("🔄 Reset to Defaults", width="stretch"):
            st.session_state.mlflow_reset = True
            st.rerun()

def render_mlflow_configuration(config: dict, mlflow_url: str):
    """Render comprehensive MLflow configuration interface"""
    st.markdown("### ⚙️ MLflow Configuration Manager")
    st.markdown("Manage all MLflow settings across different configuration sections.")

    if not config:
        st.error("Configuration not loaded")
        return

    # Configuration sections
    config_tab1, config_tab2, config_tab3 = st.tabs([
        "🔗 Service Settings",
        "🏗️ Integration Settings",
        "💾 Server Configuration"
    ])

    with config_tab1:
        st.markdown("#### 🔗 Service Settings (services.mlflow)")
        render_mlflow_service_config(config)

    with config_tab2:
        st.markdown("#### 🏗️ Integration Settings (integrations.mlflow)")
        render_mlflow_integration_config(config)

    with config_tab3:
        st.markdown("#### 💾 Server Configuration")
        render_mlflow_server_config(config)

def render_mlflow_service_config(config: dict):
    """Render services.mlflow configuration section"""
    services_mlflow = config.get('services', {}).get('mlflow', {})

    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("##### Core Service Settings")

        enabled = st.checkbox(
            "MLflow Enabled",
            value=services_mlflow.get('enabled', True),
            help="Enable/disable MLflow service"
        )

        tracking_uri = st.text_input(
            "Tracking URI",
            value=services_mlflow.get('tracking_uri', 'http://localhost:5000'),
            help="MLflow tracking server URI",
            key="mlflow_service_tracking_uri"
        )

        gateway_uri = st.text_input(
            "Gateway URI",
            value=services_mlflow.get('mlflow_gateway_uri', 'http://localhost:5000'),
            help="MLflow gateway URI",
            key="mlflow_service_gateway_uri"
        )

        # Architecture Analysis: Connection String vs Hexagonal Adapter
        st.warning("⚠️ **ARCHITECTURE CONCERN**: Current system uses connection strings instead of proper V2 hexagonal adapters")

        col_current, col_proper = st.columns(2)

        with col_current:
            st.markdown("**🚨 Current: Multiple Connection Strings**")
            st.code("""
❌ CURRENT PROBLEM:
• Main System: PostgreSQL credentials
• MLflow: PostgreSQL connection string
• Both use same DB but separate connections
• Not following V2 hexagonal architecture
            """, language="text")

            # Extract PostgreSQL info from config for display
            pg_creds = config.get('credentials', {}).get('postgresql', {})
            pg_host = pg_creds.get('host', 'Not configured')
            pg_database = pg_creds.get('database', 'Not configured')

            st.markdown(f"**Current PostgreSQL Details:**")
            st.code(f"Host: {pg_host}\nDatabase: {pg_database}", language="text")

        with col_proper:
            st.markdown("**✅ Proper: V2 Hexagonal Architecture**")
            st.code("""
✅ V2 HEXAGONAL SOLUTION:
• Single PostgreSQL Adapter (V2PostgresAdapter)
• Main System → PostgreSQL Adapter
• MLflow → Same PostgreSQL Adapter
• True shared connection pool
• Follows hexagonal architecture pattern
            """, language="text")

            if st.button("🔄 Migrate to V2 Adapters", help="Switch to proper hexagonal architecture"):
                st.info("🚧 **Migration Plan**: Replace connection strings with V2PostgresAdapter")
                st.markdown("""
                **Migration Steps:**
                1. Use existing `V2PostgresAdapter` from `rag_adapters/`
                2. Replace MLflow connection string with adapter reference
                3. Configure both systems to use shared adapter instance
                4. Implement proper dependency injection
                """)

        st.info("🔗 **Current State**: MLflow uses same PostgreSQL instance but via separate connection string (not ideal)")

        # Show adapter architecture comparison
        with st.expander("📊 View Architecture Comparison"):
            st.markdown("""
            ### 🏗️ **Connection String vs Adapter Architecture**

            **Current (Connection String):**
            ```
            Application → Direct Connection String → PostgreSQL
            MLflow → Direct Connection String → PostgreSQL
            (Multiple connection objects to same DB)
            ```

            **V2 Hexagonal (Adapter Pattern):**
            ```
            Application → V2PostgresAdapter → PostgreSQL
            MLflow → V2PostgresAdapter → PostgreSQL
            (Single adapter instance with connection pooling)
            ```

            **Benefits of V2 Adapter Approach:**
            - Single source of truth for DB connections
            - Proper connection pooling and resource management
            - Easier testing with adapter mocking
            - Follows clean architecture principles
            - Better error handling and retry logic
            """)

            st.code("""
# Example V2 Adapter Usage:
from rag_adapters.v2_postgres_adapter import V2PostgresAdapter

# Initialize shared adapter
db_adapter = V2PostgresAdapter()

# Main system uses adapter
main_data = db_adapter.query_unified_rag(query)

# MLflow uses same adapter instance (not connection string)
mlflow_backend = db_adapter  # Shared instance
            """, language="python")

        # Backend store URI with dependency indicator
        current_backend_store = services_mlflow.get('backend_store_uri', '')
        backend_store = st.text_input(
            "Backend Store URI (🔗 Uses PostgreSQL Above)",
            value=current_backend_store,
            help="This connects to the same PostgreSQL instance configured in credentials.postgresql",
            key="mlflow_service_backend_store"
        )

        # Sync MLflow Connection - emphasizes locked dependency
        st.markdown("---")

        # Check if MLflow URI is in sync with PostgreSQL credentials AND enabled
        def check_sync_status():
            if not all([pg_creds.get(k) for k in ['host', 'port', 'database', 'username', 'password']]):
                return "incomplete", "PostgreSQL credentials incomplete"

            expected_uri = f"postgresql://{pg_creds['username']}:{pg_creds['password']}@{pg_creds['host']}:{pg_creds['port']}/{pg_creds['database']}?sslmode={pg_creds.get('ssl_mode', 'require')}"

            # Check if MLflow is enabled in both sections
            services_enabled = config.get('services', {}).get('mlflow', {}).get('enabled', False)
            integrations_enabled = config.get('integrations', {}).get('mlflow', {}).get('enabled', False)

            connection_synced = current_backend_store == expected_uri
            both_enabled = services_enabled and integrations_enabled

            if connection_synced and both_enabled:
                return "synced", "MLflow connection synchronized with PostgreSQL and ENABLED"
            elif connection_synced and not both_enabled:
                return "enabled_issue", "MLflow connection synced but NOT ENABLED in both sections"
            elif not connection_synced and both_enabled:
                return "sync_issue", "MLflow enabled but connection OUT OF SYNC with PostgreSQL"
            else:
                return "out_of_sync", "MLflow connection OUT OF SYNC and NOT ENABLED"

        sync_status, sync_message = check_sync_status()

        col_status, col_sync = st.columns([2, 1])

        with col_status:
            if sync_status == "synced":
                st.success(f"✅ {sync_message}")
            elif sync_status == "enabled_issue":
                st.warning(f"⚠️ {sync_message}")
            elif sync_status == "sync_issue":
                st.warning(f"🔗 {sync_message}")
            elif sync_status == "out_of_sync":
                st.error(f"❌ {sync_message}")
            else:
                st.warning(f"❓ {sync_message}")

        with col_sync:
            if st.button("🔄 Sync MLflow Connection",
                        help="Lock MLflow to current PostgreSQL credentials",
                        width="stretch",
                        type="primary" if sync_status == "out_of_sync" else "secondary"):

                if all([pg_creds.get(k) for k in ['host', 'port', 'database', 'username', 'password']]):
                    # Build the synchronized URI
                    synced_uri = f"postgresql://{pg_creds['username']}:{pg_creds['password']}@{pg_creds['host']}:{pg_creds['port']}/{pg_creds['database']}?sslmode={pg_creds.get('ssl_mode', 'require')}"

                    # Update both services and integrations sections
                    if 'services' not in config:
                        config['services'] = {}
                    if 'mlflow' not in config['services']:
                        config['services']['mlflow'] = {}
                    if 'integrations' not in config:
                        config['integrations'] = {}
                    if 'mlflow' not in config['integrations']:
                        config['integrations']['mlflow'] = {}

                    config['services']['mlflow']['backend_store_uri'] = synced_uri
                    config['integrations']['mlflow']['backend_store_uri'] = synced_uri

                    # ENSURE MLFLOW IS ENABLED in both sections
                    config['services']['mlflow']['enabled'] = True
                    config['integrations']['mlflow']['enabled'] = True

                    # Also ensure other critical MLflow settings are present
                    if 'tracking_uri' not in config['services']['mlflow']:
                        config['services']['mlflow']['tracking_uri'] = 'http://localhost:5000'
                    if 'mlflow_gateway_uri' not in config['services']['mlflow']:
                        config['services']['mlflow']['mlflow_gateway_uri'] = 'http://localhost:5000'

                    # Copy critical settings to integrations section as well
                    config['integrations']['mlflow']['tracking_uri'] = config['services']['mlflow']['tracking_uri']
                    config['integrations']['mlflow']['mlflow_gateway_uri'] = config['services']['mlflow']['mlflow_gateway_uri']

                    # Save configuration
                    try:
                        save_config_to_file(config)
                        st.success("🔗 **MLflow connection synchronized and ENABLED!** Both systems now use identical PostgreSQL connection.")
                        st.info("**✅ MLflow Status:** Enabled in both services and integrations sections")
                        st.info("**🔒 Locked Dependency:** Changing PostgreSQL credentials will require re-syncing MLflow.")
                        st.rerun()
                    except Exception as e:
                        st.error(f"❌ Failed to sync: {str(e)}")
                else:
                    st.error("❌ Cannot sync: PostgreSQL credentials incomplete")

        # Show what the sync will do
        if sync_status == "out_of_sync":
            with st.expander("🔍 See what Sync will change"):
                expected_uri = f"postgresql://{pg_creds['username']}:{pg_creds['password']}@{pg_creds['host']}:{pg_creds['port']}/{pg_creds['database']}?sslmode={pg_creds.get('ssl_mode', 'require')}"

                st.markdown("**Current MLflow URI:**")
                st.code(current_backend_store, language="text")

                st.markdown("**Will become (locked to PostgreSQL):**")
                st.code(expected_uri, language="text")

                st.warning("⚠️ **This creates a locked dependency** - MLflow will only work with these exact PostgreSQL credentials.")

        artifact_store = st.text_input(
            "Artifact Store",
            value=services_mlflow.get('artifact_store', ''),
            help="S3 or local path for artifacts",
            key="mlflow_service_artifact_store"
        )

        # Server settings
        st.markdown("##### Server Settings")
        server_config = services_mlflow.get('server', {})

        col_host, col_port = st.columns(2)
        with col_host:
            server_host = st.text_input(
                "Server Host",
                value=server_config.get('host', '0.0.0.0'),
                help="MLflow server host",
                key="mlflow_service_server_host"
            )
        with col_port:
            server_port = st.number_input(
                "Server Port",
                value=int(server_config.get('port', 5000)),
                min_value=1,
                max_value=65535,
                help="MLflow server port"
            )

    with col2:
        st.markdown("##### Actions")

        # Test service configuration
        if st.button("🧪 Test Service Config", width="stretch"):
            with st.spinner("Testing service configuration..."):
                try:
                    test_response = requests.get(f"{tracking_uri}/health", timeout=5)
                    if test_response.status_code == 200:
                        st.success("✅ Service configuration test successful!")

                        # Get version
                        try:
                            version_response = requests.get(f"{tracking_uri}/version", timeout=3)
                            if version_response.status_code == 200:
                                version_data = version_response.json()
                                st.info(f"MLflow Version: {version_data.get('version', 'Unknown')}")
                        except:
                            pass
                    else:
                        st.error(f"❌ Service test failed: HTTP {test_response.status_code}")
                except Exception as e:
                    st.error(f"❌ Service test failed: {str(e)}")

        # Save service configuration
        if st.button("💾 Save Service Config", width="stretch"):
            try:
                # Update services section
                if 'services' not in config:
                    config['services'] = {}
                if 'mlflow' not in config['services']:
                    config['services']['mlflow'] = {}

                config['services']['mlflow']['enabled'] = enabled
                config['services']['mlflow']['tracking_uri'] = tracking_uri
                config['services']['mlflow']['mlflow_gateway_uri'] = gateway_uri
                config['services']['mlflow']['backend_store_uri'] = backend_store
                config['services']['mlflow']['artifact_store'] = artifact_store
                config['services']['mlflow']['server'] = {
                    'host': server_host,
                    'port': server_port
                }

                # Save to file
                save_config_to_file(config)
                st.success("✅ Service configuration saved!")

            except Exception as e:
                st.error(f"❌ Failed to save service config: {str(e)}")

def render_mlflow_integration_config(config: dict):
    """Render integrations.mlflow configuration section"""
    integrations_mlflow = config.get('integrations', {}).get('mlflow', {})

    col1, col2 = st.columns([2, 1])

    with col1:
        st.markdown("##### Integration Settings")

        int_enabled = st.checkbox(
            "Integration Enabled",
            value=integrations_mlflow.get('enabled', True),
            help="Enable MLflow integration"
        )

        int_tracking_uri = st.text_input(
            "Integration Tracking URI",
            value=integrations_mlflow.get('tracking_uri', 'http://localhost:5000'),
            help="Tracking URI for integration",
            key="mlflow_integration_tracking_uri"
        )

        int_gateway_uri = st.text_input(
            "Integration Gateway URI",
            value=integrations_mlflow.get('mlflow_gateway_uri', 'http://localhost:5000'),
            help="Gateway URI for integration",
            key="mlflow_integration_gateway_uri"
        )

        int_backend_store = st.text_input(
            "Integration Backend Store",
            value=integrations_mlflow.get('backend_store_uri', ''),
            help="Backend store for integration",
            key="mlflow_integration_backend_store"
        )

        int_artifact_store = st.text_input(
            "Integration Artifact Store",
            value=integrations_mlflow.get('artifact_store', ''),
            help="Artifact store for integration",
            key="mlflow_integration_artifact_store"
        )

        # Server settings for integration
        st.markdown("##### Integration Server Settings")
        int_server_config = integrations_mlflow.get('server', {})

        col_int_host, col_int_port = st.columns(2)
        with col_int_host:
            int_server_host = st.text_input(
                "Integration Host",
                value=int_server_config.get('host', '0.0.0.0'),
                help="Integration server host",
                key="mlflow_integration_server_host"
            )
        with col_int_port:
            int_server_port = st.number_input(
                "Integration Port",
                value=int(int_server_config.get('port', 5000)),
                min_value=1,
                max_value=65535,
                help="Integration server port"
            )

    with col2:
        st.markdown("##### Actions")

        # Test integration configuration
        if st.button("🧪 Test Integration Config", width="stretch"):
            with st.spinner("Testing integration configuration..."):
                try:
                    test_response = requests.get(f"{int_tracking_uri}/health", timeout=5)
                    if test_response.status_code == 200:
                        st.success("✅ Integration configuration test successful!")
                    else:
                        st.error(f"❌ Integration test failed: HTTP {test_response.status_code}")
                except Exception as e:
                    st.error(f"❌ Integration test failed: {str(e)}")

        # Save integration configuration
        if st.button("💾 Save Integration Config", width="stretch"):
            try:
                # Update integrations section
                if 'integrations' not in config:
                    config['integrations'] = {}
                if 'mlflow' not in config['integrations']:
                    config['integrations']['mlflow'] = {}

                config['integrations']['mlflow']['enabled'] = int_enabled
                config['integrations']['mlflow']['tracking_uri'] = int_tracking_uri
                config['integrations']['mlflow']['mlflow_gateway_uri'] = int_gateway_uri
                config['integrations']['mlflow']['backend_store_uri'] = int_backend_store
                config['integrations']['mlflow']['artifact_store'] = int_artifact_store
                config['integrations']['mlflow']['server'] = {
                    'host': int_server_host,
                    'port': int_server_port
                }

                # Save to file
                save_config_to_file(config)
                st.success("✅ Integration configuration saved!")

            except Exception as e:
                st.error(f"❌ Failed to save integration config: {str(e)}")

def render_mlflow_server_config(config: dict):
    """Render server-specific MLflow configuration"""
    st.markdown("##### Server Management")

    col1, col2 = st.columns(2)

    with col1:
        if st.button("🔄 Restart MLflow Server", width="stretch"):
            st.warning("⚠️ Server restart functionality not implemented")
            st.info("To restart MLflow server, use your system's service manager")

        if st.button("📊 Server Status", width="stretch"):
            try:
                mlflow_url = config.get('services', {}).get('mlflow', {}).get('tracking_uri', 'http://localhost:5000')

                # Check server status
                health_response = requests.get(f"{mlflow_url}/health", timeout=5)
                version_response = requests.get(f"{mlflow_url}/version", timeout=5)

                if health_response.status_code == 200:
                    st.success("✅ Server is running")

                    if version_response.status_code == 200:
                        version_data = version_response.json()
                        st.info(f"Version: {version_data.get('version', 'Unknown')}")
                else:
                    st.error("❌ Server is not responding")

            except Exception as e:
                st.error(f"❌ Cannot check server status: {str(e)}")

    with col2:
        if st.button("🗂️ View Logs", width="stretch"):
            st.info("Log viewing functionality would be implemented here")

        if st.button("⚙️ Advanced Settings", width="stretch"):
            st.info("Advanced server settings would be shown here")

def save_config_to_file(config: dict):
    """Save configuration to settings.yaml file"""
    import yaml
    settings_path = Path(__file__).parent.parent.parent / "admin" / "settings.yaml"

    if settings_path.exists():
        with open(settings_path, 'w') as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    else:
        raise FileNotFoundError("Settings file not found")

def view_experiment_details(mlflow_url: str, experiment_id: str):
    """View detailed experiment information"""
    try:
        # Get experiment details
        exp_response = requests.get(f"{mlflow_url}/api/2.0/mlflow/experiments/get",
                                  params={"experiment_id": experiment_id}, timeout=5)

        if exp_response.status_code == 200:
            exp_data = exp_response.json()
            experiment = exp_data.get("experiment", {})

            st.write("**Experiment Details:**")
            st.json(experiment)

    except Exception as e:
        st.error(f"Failed to get experiment details: {e}")

def render_system_monitor_page(health_data: Dict[str, Any], aha_dashboard: 'AHAHealthDashboard'):
    """Render the System Monitor page with subnav."""
    # Clear any existing content
    st.empty()
    st.header("🖥️ System Monitor")

    st.markdown("""
    Real-time monitoring of system resources, processing performance, and error tracking.
    Use the tabs below to navigate between different monitoring categories.
    """)

    # Get system monitor data
    monitor_data = aha_dashboard.get_system_monitor_data()

    # Create tabs for subnav
    tab1, tab2, tab3 = st.tabs(["💻 Resource Usage", "⚙️ Processing Metrics", "🚨 Error Tracking"])

    with tab1:
        render_resource_usage(monitor_data)

    with tab2:
        render_processing_metrics(monitor_data)

    with tab3:
        render_error_tracking(monitor_data)

def main():
    """Main AHA dashboard"""

    # Initialize session state
    if 'current_page' not in st.session_state:
        st.session_state.current_page = "System Monitor"

    # Initialize AHA dashboard
    aha_dashboard = AHAHealthDashboard()

    # Get comprehensive health data
    health_data = aha_dashboard.get_comprehensive_health()

    # Render sidebar and get current page
    current_page = render_aha_sidebar(health_data, st.session_state.current_page)

    # Update session state if page changed
    if current_page != st.session_state.current_page:
        st.session_state.current_page = current_page
        st.rerun()

    # Clear main content area and render based on selected page
    main_container = st.container()

    with main_container:
        # Health Overview page removed as requested

        if current_page == "System Monitor":
            render_system_monitor_page(health_data, aha_dashboard)

        elif current_page == "Configuration Management":
            render_config_management_page()

def render_s3_direct_access_interface():
    """Render S3 direct access testing interface"""
    st.markdown("### 📦 S3 Direct Access Testing")

    # Load S3 credentials from settings
    config = load_credentials()
    if not config:
        st.error("Cannot load configuration file for S3 access")
        return

    # Get AWS credentials from config
    aws_creds = config.get('credentials', {}).get('aws', {})
    s3_config = config.get('services', {}).get('s3', {})

    if not aws_creds.get('access_key_id') or not aws_creds.get('secret_access_key'):
        st.error("AWS credentials not found in configuration")
        return

    # Display S3 connection info
    st.markdown("#### 🔗 Connection Information")
    col1, col2, col3 = st.columns(3)

    with col1:
        st.metric("S3 Bucket", s3_config.get('bucket', 'nsc-mvp1'))

    with col2:
        st.metric("Region", s3_config.get('region', 'us-east-1'))

    with col3:
        st.metric("Prefix", s3_config.get('prefix', 'staging/'))

    # S3 testing tabs
    test_tab1, test_tab2, test_tab3 = st.tabs([
        "🔍 Connection Test",
        "📁 Bucket Operations",
        "📊 Permissions Check"
    ])

    with test_tab1:
        st.markdown("##### S3 Connection Test")

        if st.button("🧪 Test S3 Connection"):
            try:
                # Create S3 client
                s3_client = boto3.client(
                    's3',
                    aws_access_key_id=aws_creds.get('access_key_id'),
                    aws_secret_access_key=aws_creds.get('secret_access_key'),
                    region_name=s3_config.get('region', 'us-east-1')
                )

                # Test connection by listing buckets
                start_time = time.time()
                response = s3_client.list_buckets()
                end_time = time.time()

                st.success(f"✅ S3 Connection successful! Response time: {(end_time - start_time)*1000:.2f}ms")

                # Display available buckets
                buckets = response.get('Buckets', [])
                st.markdown(f"**Found {len(buckets)} accessible buckets:**")

                for bucket in buckets:
                    bucket_name = bucket['Name']
                    created = bucket['CreationDate'].strftime('%Y-%m-%d %H:%M:%S')
                    if bucket_name == s3_config.get('bucket', 'nsc-mvp1'):
                        st.success(f"🎯 **{bucket_name}** (Target bucket) - Created: {created}")
                    else:
                        st.info(f"📁 {bucket_name} - Created: {created}")

            except NoCredentialsError:
                st.error("❌ AWS credentials not found or invalid")
            except ClientError as e:
                error_code = e.response['Error']['Code']
                st.error(f"❌ AWS Error ({error_code}): {e.response['Error']['Message']}")
            except Exception as e:
                st.error(f"❌ Connection failed: {str(e)}")

    with test_tab2:
        st.markdown("##### Bucket Operations")

        bucket_name = st.text_input("Bucket Name", value=s3_config.get('bucket', 'nsc-mvp1'), key="s3_bucket")
        prefix = st.text_input("Prefix/Path", value=s3_config.get('prefix', 'staging/'), key="s3_prefix")

        col1, col2 = st.columns(2)

        with col1:
            if st.button("📋 List Objects"):
                try:
                    s3_client = boto3.client(
                        's3',
                        aws_access_key_id=aws_creds.get('access_key_id'),
                        aws_secret_access_key=aws_creds.get('secret_access_key'),
                        region_name=s3_config.get('region', 'us-east-1')
                    )

                    response = s3_client.list_objects_v2(
                        Bucket=bucket_name,
                        Prefix=prefix,
                        MaxKeys=20
                    )

                    objects = response.get('Contents', [])
                    st.success(f"Found {len(objects)} objects")

                    if objects:
                        for obj in objects:
                            key = obj['Key']
                            size = obj['Size']
                            modified = obj['LastModified'].strftime('%Y-%m-%d %H:%M:%S')
                            st.text(f"📄 {key} ({size} bytes) - {modified}")
                    else:
                        st.info("No objects found with this prefix")

                except Exception as e:
                    st.error(f"Error listing objects: {str(e)}")

        with col2:
            if st.button("🔍 Check Bucket Access"):
                try:
                    s3_client = boto3.client(
                        's3',
                        aws_access_key_id=aws_creds.get('access_key_id'),
                        aws_secret_access_key=aws_creds.get('secret_access_key'),
                        region_name=s3_config.get('region', 'us-east-1')
                    )

                    # Try to get bucket location
                    location = s3_client.get_bucket_location(Bucket=bucket_name)
                    region = location.get('LocationConstraint', 'us-east-1')

                    st.success(f"✅ Bucket accessible in region: {region}")

                    # Try to head bucket
                    s3_client.head_bucket(Bucket=bucket_name)
                    st.success("✅ Bucket HEAD operation successful")

                except Exception as e:
                    st.error(f"Bucket access check failed: {str(e)}")

    with test_tab3:
        st.markdown("##### Permissions Check")

        bucket_name = st.text_input("Test Bucket", value=s3_config.get('bucket', 'nsc-mvp1'), key="perm_bucket")
        test_key = st.text_input("Test Object Key", value="test/permissions_test.txt", key="s3_test_key")

        if st.button("🔐 Test Read/Write Permissions"):
            try:
                s3_client = boto3.client(
                    's3',
                    aws_access_key_id=aws_creds.get('access_key_id'),
                    aws_secret_access_key=aws_creds.get('secret_access_key'),
                    region_name=s3_config.get('region', 'us-east-1')
                )

                # Test write permission
                test_content = f"Permission test from AHA Dashboard - {datetime.now().isoformat()}"

                try:
                    s3_client.put_object(
                        Bucket=bucket_name,
                        Key=test_key,
                        Body=test_content.encode('utf-8'),
                        ContentType='text/plain'
                    )
                    st.success("✅ Write permission: SUCCESS")
                except Exception as e:
                    st.error(f"❌ Write permission: FAILED - {str(e)}")
                    return

                # Test read permission
                try:
                    response = s3_client.get_object(Bucket=bucket_name, Key=test_key)
                    content = response['Body'].read().decode('utf-8')
                    st.success("✅ Read permission: SUCCESS")
                    st.text(f"Retrieved content: {content[:100]}...")
                except Exception as e:
                    st.error(f"❌ Read permission: FAILED - {str(e)}")

                # Test delete permission
                try:
                    s3_client.delete_object(Bucket=bucket_name, Key=test_key)
                    st.success("✅ Delete permission: SUCCESS")
                except Exception as e:
                    st.warning(f"⚠️ Delete permission: FAILED - {str(e)}")

            except Exception as e:
                st.error(f"Permission test failed: {str(e)}")

    # Health monitoring
    st.markdown("---")
    st.markdown("#### 📊 S3 Health Monitoring")

    if st.button("🔄 Refresh S3 Health Status"):
        with st.spinner("Checking S3 health..."):
            try:
                s3_client = boto3.client(
                    's3',
                    aws_access_key_id=aws_creds.get('access_key_id'),
                    aws_secret_access_key=aws_creds.get('secret_access_key'),
                    region_name=s3_config.get('region', 'us-east-1')
                )

                # Check multiple S3 operations for health
                start_time = time.time()

                # 1. List buckets
                s3_client.list_buckets()

                # 2. Check target bucket
                bucket_name = s3_config.get('bucket', 'nsc-mvp1')
                s3_client.head_bucket(Bucket=bucket_name)

                # 3. List some objects
                s3_client.list_objects_v2(Bucket=bucket_name, MaxKeys=1)

                end_time = time.time()
                response_time = (end_time - start_time) * 1000

                col1, col2, col3, col4 = st.columns(4)

                with col1:
                    st.metric("S3 Status", "🟢 Healthy", "All operations successful")

                with col2:
                    st.metric("Response Time", f"{response_time:.0f}ms", "Bucket operations")

                with col3:
                    st.metric("Target Bucket", "✅ Accessible", bucket_name)

                with col4:
                    st.metric("Permissions", "✅ Valid", "Read/Write/List")

            except Exception as e:
                st.error(f"S3 Health Check Failed: {str(e)}")

                col1, col2 = st.columns(2)
                with col1:
                    st.metric("S3 Status", "🔴 Unhealthy", "Connection failed")
                with col2:
                    st.metric("Error", "❌ Failed", str(e)[:30] + "...")

if __name__ == "__main__":
    main()
