#!/usr/bin/env python3
"""
Onboarding Portal Launcher
==========================

Launch the Onboarding Streamlit application from the tidyllm package.
"""

import subprocess
import sys
import os
from pathlib import Path


def launch_onboarding_portal(port: int = 8502, host: str = "localhost"):
    """Launch the Onboarding Portal Streamlit application."""

    # Get the directory containing this script
    portal_dir = Path(__file__).parent
    app_file = portal_dir / "app.py"

    if not app_file.exists():
        print(f"[ERROR] Onboarding Portal app not found at: {app_file}")
        return False

    print(f"[LAUNCH] Launching Onboarding Portal...")
    print(f"[LOCATION] {app_file}")
    print(f"[URL] http://{host}:{port}")

    try:
        # Change to the portal directory
        os.chdir(portal_dir)

        # Launch Streamlit
        subprocess.run([
            sys.executable, "-m", "streamlit", "run",
            str(app_file),
            "--server.port", str(port),
            "--server.address", host,
            "--server.headless", "false"
        ])

        return True

    except Exception as e:
        print(f"[ERROR] Failed to launch Onboarding Portal: {e}")
        return False


def main():
    """Main entry point for onboarding-portal command."""
    import argparse

    parser = argparse.ArgumentParser(description="Launch Onboarding Portal")
    parser.add_argument("--port", type=int, default=8502, help="Port to run on")
    parser.add_argument("--host", default="localhost", help="Host to bind to")

    args = parser.parse_args()

    success = launch_onboarding_portal(args.port, args.host)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()