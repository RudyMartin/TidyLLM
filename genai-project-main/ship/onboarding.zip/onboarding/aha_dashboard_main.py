#!/usr/bin/env python3
"""
AHA Dashboard - Main Streamlit Application
Automated Health Awareness Dashboard for TidyLLM System Monitoring
"""

import streamlit as st
import sys
import os
import time
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Add the project root to the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import AHA components
from aha_connection_manager_working import get_aha_connection_manager
from aha_health_collector import get_aha_health_collector

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Streamlit page configuration
st.set_page_config(
    page_title="AHA Dashboard - Automated Health Awareness",
    page_icon="💓",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .health-card {
        background: linear-gradient(145deg, #ffffff 0%, #f1f3f4 100%);
        border: 2px solid #dadce0;
        border-radius: 12px;
        padding: 1.2rem;
        margin: 0.8rem 0;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15), 0 2px 4px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        color: #202124;
    }
    .health-card:hover {
        box-shadow: 0 6px 20px rgba(0,0,0,0.2), 0 4px 8px rgba(0,0,0,0.15);
        transform: translateY(-2px);
        border-color: #1f77b4;
    }
    .status-healthy {
        color: #28a745;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(40,167,69,0.3);
    }
    .status-degraded {
        color: #ffc107;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(255,193,7,0.3);
    }
    .status-unhealthy {
        color: #dc3545;
        font-weight: bold;
        text-shadow: 1px 1px 2px rgba(220,53,69,0.3);
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 16px;
        padding: 1.8rem;
        text-align: center;
        box-shadow: 0 8px 25px rgba(102,126,234,0.3), 0 4px 12px rgba(0,0,0,0.15);
        border: 1px solid rgba(255,255,255,0.1);
        margin: 0.8rem 0;
    }
    .gateway-card {
        background: linear-gradient(145deg, #ffffff 0%, #f1f3f4 100%);
        border: 2px solid #dadce0;
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1rem 0;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15), 0 2px 6px rgba(0,0,0,0.1);
        transition: all 0.3s ease;
        color: #202124;
    }
    .gateway-card:hover {
        box-shadow: 0 8px 25px rgba(0,0,0,0.2), 0 4px 12px rgba(0,0,0,0.15);
        transform: translateY(-3px);
        border-color: #1f77b4;
        background: linear-gradient(145deg, #f8f9fa 0%, #e9ecef 100%);
    }
    .pulse-details-card {
        background: linear-gradient(145deg, #ffffff 0%, #f1f3f4 100%);
        border: 2px solid #dadce0;
        border-radius: 12px;
        padding: 1.5rem;
        margin: 1rem 0;
        box-shadow: 0 4px 15px rgba(0,0,0,0.15), 0 2px 6px rgba(0,0,0,0.1);
        color: #202124;
        font-weight: 500;
    }
    .pulse-details-card strong {
        color: #1f77b4;
        font-weight: 600;
    }
    .debug-info {
        background: linear-gradient(145deg, #fff3cd 0%, #ffeaa7 100%);
        border: 1px solid #ffeaa7;
        border-radius: 8px;
        padding: 0.8rem;
        margin: 0.5rem 0;
        color: #856404;
        font-size: 0.9rem;
    }
</style>
""", unsafe_allow_html=True)

class AHADashboard:
    """AHA Dashboard Main Class"""
    
    def __init__(self):
        """Initialize AHA Dashboard"""
        self.connection_manager = get_aha_connection_manager()
        self.health_collector = get_aha_health_collector()
        
        # Initialize session state
        if 'aha_dashboard_initialized' not in st.session_state:
            st.session_state.aha_dashboard_initialized = True
            st.session_state.auto_refresh = True
            st.session_state.refresh_interval = 30
    
    def render_header(self):
        """Render dashboard header"""
        st.markdown('<div class="main-header">💓 AHA Dashboard - Automated Health Awareness</div>', unsafe_allow_html=True)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Database Status", "Connected" if self.connection_manager.is_connected() else "Disconnected")
        
        with col2:
            collection_status = self.health_collector.get_collection_status()
            st.metric("Collection Status", "Active" if collection_status['collection_active'] else "Inactive")
        
        with col3:
            current_time = datetime.now().strftime("%H:%M:%S")
            st.metric("Last Update", current_time)
        
        with col4:
            if st.button("🔄 Manual Refresh"):
                st.rerun()
    
    def render_sidebar(self):
        """Render dashboard sidebar"""
        st.sidebar.title("AHA Controls")
        
        # Auto-refresh settings
        st.sidebar.subheader("Refresh Settings")
        auto_refresh = st.sidebar.checkbox("Auto Refresh", value=st.session_state.auto_refresh)
        if auto_refresh:
            refresh_interval = st.sidebar.slider("Refresh Interval (seconds)", 10, 300, st.session_state.refresh_interval)
            st.session_state.refresh_interval = refresh_interval
        
        # Collection controls
        st.sidebar.subheader("Collection Controls")
        collection_status = self.health_collector.get_collection_status()
        
        if collection_status['collection_active']:
            if st.sidebar.button("🛑 Stop Collection"):
                self.health_collector.stop_collection()
                st.rerun()
        else:
            if st.sidebar.button("▶️ Start Collection"):
                self.health_collector.start_collection()
                st.rerun()
        
        # Manual pulse collection
        if st.sidebar.button("🔄 Collect Manual Pulse"):
            with st.spinner("Collecting health data..."):
                result = self.health_collector.collect_manual_pulse()
                if result['status'] == 'success':
                    st.sidebar.success("✅ Pulse collected successfully")
                else:
                    st.sidebar.error(f"❌ Pulse collection failed: {result['message']}")
        
        # Time range selector
        st.sidebar.subheader("Time Range")
        time_range = st.sidebar.selectbox(
            "Select time range",
            ["Last Hour", "Last 6 Hours", "Last 24 Hours", "Last 7 Days"],
            index=2
        )
        
        # Map time range to hours
        time_range_map = {
            "Last Hour": 1,
            "Last 6 Hours": 6,
            "Last 24 Hours": 24,
            "Last 7 Days": 168
        }
        
        return time_range_map[time_range]
    
    def render_system_overview(self, hours: int):
        """Render system overview section"""
        st.subheader("📊 System Overview")
        
        try:
            # Get system health summary
            health_summary = self.connection_manager.get_system_health_summary(hours)
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.markdown("### 🚪 Gateways")
                gateway_summary = health_summary.get('gateway_summary', [])
                
                if gateway_summary:
                    for gateway in gateway_summary:
                        gateway_name = gateway['gateway_name']
                        avg_health = gateway['avg_health_score']
                        healthy_count = gateway['healthy_count']
                        total_count = gateway['pulse_count']
                        
                        status_class = "status-healthy" if avg_health >= 80 else "status-degraded" if avg_health >= 50 else "status-unhealthy"
                        
                        st.markdown(f"""
                        <div class="health-card">
                            <strong>{gateway_name}</strong><br>
                            <span class="{status_class}">Health: {avg_health:.1f}%</span><br>
                            <small>Healthy: {healthy_count}/{total_count} pulses</small>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.info("No gateway data available")
            
            with col2:
                st.markdown("### ⚙️ Services")
                service_summary = health_summary.get('service_summary', [])
                
                if service_summary:
                    for service in service_summary:
                        service_name = service['service_name']
                        avg_availability = service['avg_availability']
                        healthy_count = service['healthy_count']
                        total_count = service['pulse_count']
                        
                        status_class = "status-healthy" if avg_availability >= 80 else "status-degraded" if avg_availability >= 50 else "status-unhealthy"
                        
                        st.markdown(f"""
                        <div class="health-card">
                            <strong>{service_name}</strong><br>
                            <span class="{status_class}">Availability: {avg_availability:.1f}%</span><br>
                            <small>Healthy: {healthy_count}/{total_count} pulses</small>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.info("No service data available")
            
            with col3:
                st.markdown("### 🚨 Alerts")
                alert_summary = health_summary.get('alert_summary', [])
                
                if alert_summary:
                    for alert in alert_summary:
                        alert_level = alert['alert_level']
                        alert_count = alert['alert_count']
                        unresolved_count = alert['unresolved_count']
                        
                        status_class = "status-unhealthy" if alert_level == "CRITICAL" else "status-degraded" if alert_level == "WARNING" else "status-healthy"
                        
                        st.markdown(f"""
                        <div class="health-card">
                            <strong>{alert_level}</strong><br>
                            <span class="{status_class}">{alert_count} total</span><br>
                            <small>Unresolved: {unresolved_count}</small>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.info("No alerts in selected time range")
                    
        except Exception as e:
            st.error(f"Failed to load system overview: {e}")
    
    def render_gateway_details(self, hours: int):
        """Render gateway details section"""
        st.subheader("🚪 Gateway Details")
        
        try:
            # Get gateway pulse history
            gateway_pulses = self.connection_manager.get_gateway_pulse_history(hours=hours)
            
            # Show summary info
            if gateway_pulses:
                st.info(f"📊 Found {len(gateway_pulses)} gateway health records")
            
            if gateway_pulses:
                # Create DataFrame for visualization
                df = pd.DataFrame(gateway_pulses)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # Group by gateway
                gateway_groups = df.groupby('gateway_name')
                
                for gateway_name, group in gateway_groups:
                    # Get latest status for the gateway
                    latest_pulse = group.iloc[0]
                    status = latest_pulse['status']
                    health_score = latest_pulse['health_score']
                    
                    # Determine status color and icon
                    if status == 'healthy':
                        status_color = '#28a745'
                        status_icon = '✅'
                    elif status == 'degraded':
                        status_color = '#ffc107'
                        status_icon = '⚠️'
                    elif status == 'unhealthy':
                        status_color = '#dc3545'
                        status_icon = '❌'
                    else:
                        status_color = '#6c757d'
                        status_icon = '❓'
                    
                    # Create expander with status indicator
                    expander_title = f"{status_icon} Gateway: {gateway_name} - {status.upper()} ({health_score:.1f}%)"
                    
                    with st.expander(expander_title, expanded=True):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            # Health score over time with status colors
                            fig_health = px.line(
                                group, 
                                x='timestamp', 
                                y='health_score',
                                title=f'{gateway_name} - Health Score Over Time',
                                labels={'health_score': 'Health Score (%)', 'timestamp': 'Time'},
                                color_discrete_sequence=['#28a745']  # Green for health score
                            )
                            fig_health.update_layout(height=300)
                            st.plotly_chart(fig_health, use_container_width=True)
                        
                        with col2:
                            # Response time over time with status colors
                            fig_response = px.line(
                                group, 
                                x='timestamp', 
                                y='response_time_ms',
                                title=f'{gateway_name} - Response Time Over Time',
                                labels={'response_time_ms': 'Response Time (ms)', 'timestamp': 'Time'},
                                color_discrete_sequence=['#007bff']  # Blue for response time
                            )
                            fig_response.update_layout(height=300)
                            st.plotly_chart(fig_response, use_container_width=True)
                        
                        # Status distribution
                        col3, col4 = st.columns(2)
                        
                        with col3:
                            status_counts = group['status'].value_counts()
                            
                            # Define status colors
                            status_colors = {
                                'healthy': '#28a745',
                                'degraded': '#ffc107', 
                                'unhealthy': '#dc3545',
                                'unknown': '#6c757d'
                            }
                            
                            fig_status = px.pie(
                                values=status_counts.values,
                                names=status_counts.index,
                                title=f'{gateway_name} - Status Distribution',
                                color_discrete_map=status_colors
                            )
                            st.plotly_chart(fig_status, use_container_width=True)
                        
                        with col4:
                            # Latest pulse details with colored status
                            try:
                                latest_pulse = group.iloc[0]
                                
                                # Show latest pulse details
                                st.markdown("### Latest Pulse Details")
                                
                                # Safely extract values with defaults
                                status = latest_pulse.get('status', 'unknown')
                                health_score = latest_pulse.get('health_score', 0.0)
                                response_time = latest_pulse.get('response_time_ms', 0)
                                timestamp = latest_pulse.get('timestamp', 'N/A')
                                environment = latest_pulse.get('environment', 'production')
                                
                                # Handle timestamp formatting
                                if hasattr(timestamp, 'strftime'):
                                    timestamp_str = timestamp.strftime('%Y-%m-%d %H:%M:%S')
                                else:
                                    timestamp_str = str(timestamp)
                                
                                # Determine status color
                                if status == 'healthy':
                                    status_color = '#28a745'
                                    status_icon = '✅'
                                elif status == 'degraded':
                                    status_color = '#ffc107'
                                    status_icon = '⚠️'
                                elif status == 'unhealthy':
                                    status_color = '#dc3545'
                                    status_icon = '❌'
                                else:
                                    status_color = '#6c757d'
                                    status_icon = '❓'
                                
                                st.markdown(f"""
                                <div class="pulse-details-card">
                                    <strong>{status_icon} Status: <span style="color: {status_color}">{status.upper()}</span></strong><br>
                                    <strong>Health Score: <span style="color: {status_color}">{health_score:.1f}%</span></strong><br>
                                    <strong>Response Time: {response_time}ms</strong><br>
                                    <strong>Timestamp: {timestamp_str}</strong><br>
                                    <strong>Environment: {environment}</strong>
                                </div>
                                """, unsafe_allow_html=True)
                                
                            except Exception as e:
                                st.error(f"Error displaying latest pulse details: {e}")
                                st.markdown("### Latest Pulse Details")
                                st.markdown("""
                                <div class="pulse-details-card">
                                    <strong>❓ Status: UNKNOWN</strong><br>
                                    <strong>Health Score: 0.0%</strong><br>
                                    <strong>Response Time: 0ms</strong><br>
                                    <strong>Timestamp: N/A</strong><br>
                                    <strong>Environment: production</strong>
                                </div>
                                """, unsafe_allow_html=True)
            else:
                st.info("No gateway pulse data available for the selected time range")
                
        except Exception as e:
            st.error(f"Failed to load gateway details: {e}")
    
    def render_service_details(self, hours: int):
        """Render service details section"""
        st.subheader("⚙️ Service Details")
        
        try:
            # Get service pulse history
            service_pulses = self.connection_manager.get_service_pulse_history(hours=hours)
            
            if service_pulses:
                # Create DataFrame for visualization
                df = pd.DataFrame(service_pulses)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # Group by service
                service_groups = df.groupby('service_name')
                
                for service_name, group in service_groups:
                    with st.expander(f"Service: {service_name}", expanded=True):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            # Availability score over time
                            fig_availability = px.line(
                                group, 
                                x='timestamp', 
                                y='availability_score',
                                title=f'{service_name} - Availability Score Over Time',
                                labels={'availability_score': 'Availability Score (%)', 'timestamp': 'Time'}
                            )
                            fig_availability.update_layout(height=300)
                            st.plotly_chart(fig_availability, use_container_width=True)
                        
                        with col2:
                            # Response time over time
                            fig_response = px.line(
                                group, 
                                x='timestamp', 
                                y='response_time_ms',
                                title=f'{service_name} - Response Time Over Time',
                                labels={'response_time_ms': 'Response Time (ms)', 'timestamp': 'Time'}
                            )
                            fig_response.update_layout(height=300)
                            st.plotly_chart(fig_response, use_container_width=True)
                        
                        # Latest pulse details
                        latest_pulse = group.iloc[0]
                        st.markdown("### Latest Pulse Details")
                        st.json({
                            'Status': latest_pulse['status'],
                            'Availability Score': f"{latest_pulse['availability_score']:.1f}%",
                            'Response Time': f"{latest_pulse['response_time_ms']}ms",
                            'Timestamp': latest_pulse['timestamp'].strftime('%Y-%m-%d %H:%M:%S'),
                            'Environment': latest_pulse.get('environment', 'production')
                        })
            else:
                st.info("No service pulse data available for the selected time range")
                
        except Exception as e:
            st.error(f"Failed to load service details: {e}")
    
    def render_alerts_section(self, hours: int):
        """Render alerts section"""
        st.subheader("🚨 Health Alerts")
        
        try:
            # Get health alerts
            alerts = self.connection_manager.get_health_alerts(hours=hours)
            
            if alerts:
                # Create DataFrame for alerts
                df = pd.DataFrame(alerts)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # Filter unresolved alerts
                unresolved_alerts = df[df['resolved'] == False]
                
                if not unresolved_alerts.empty:
                    st.warning(f"⚠️ {len(unresolved_alerts)} unresolved alerts")
                    
                    for _, alert in unresolved_alerts.iterrows():
                        alert_level = alert['alert_level']
                        component_name = alert['component_name']
                        alert_message = alert['alert_message']
                        timestamp = alert['timestamp']
                        
                        status_class = "status-unhealthy" if alert_level == "CRITICAL" else "status-degraded" if alert_level == "WARNING" else "status-healthy"
                        
                        st.markdown(f"""
                        <div class="health-card">
                            <strong>{alert_level} - {component_name}</strong><br>
                            <span class="{status_class}">{alert_message}</span><br>
                            <small>Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}</small>
                        </div>
                        """, unsafe_allow_html=True)
                else:
                    st.success("✅ No unresolved alerts")
                
                # Show all alerts in a table
                st.markdown("### All Alerts")
                st.dataframe(df[['timestamp', 'alert_level', 'component_name', 'alert_message', 'resolved']], use_container_width=True)
                
            else:
                st.info("No alerts in the selected time range")
                
        except Exception as e:
            st.error(f"Failed to load alerts: {e}")
    
    def render_control_signals_section(self, hours: int):
        """Render control signals section"""
        st.subheader("🎛️ Control Signals")
        
        try:
            # Get control signals
            control_signals = self.connection_manager.get_control_signal_history(hours=hours)
            
            if control_signals:
                # Create DataFrame for control signals
                df = pd.DataFrame(control_signals)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                
                # Group by signal type
                signal_types = df['signal_type'].unique()
                
                # Create columns for different signal types
                cols = st.columns(len(signal_types))
                
                for i, signal_type in enumerate(signal_types):
                    with cols[i]:
                        type_signals = df[df['signal_type'] == signal_type]
                        
                        # Determine signal type color and icon
                        if signal_type == 'start':
                            signal_color = '#28a745'
                            signal_icon = '▶️'
                        elif signal_type == 'stop':
                            signal_color = '#dc3545'
                            signal_icon = '⏹️'
                        elif signal_type == 'restart':
                            signal_color = '#ffc107'
                            signal_icon = '🔄'
                        elif signal_type == 'configure':
                            signal_color = '#007bff'
                            signal_icon = '⚙️'
                        elif signal_type == 'scale':
                            signal_color = '#6f42c1'
                            signal_icon = '📈'
                        elif signal_type == 'maintenance':
                            signal_color = '#fd7e14'
                            signal_icon = '🔧'
                        else:
                            signal_color = '#6c757d'
                            signal_icon = '❓'
                        
                        st.markdown(f"""
                        <div class="health-card">
                            <strong>{signal_icon} {signal_type.upper()}</strong><br>
                            <span style="color: {signal_color}">{len(type_signals)} signals</span><br>
                            <small>Last: {type_signals.iloc[0]['timestamp'].strftime('%H:%M:%S') if not type_signals.empty else 'N/A'}</small>
                        </div>
                        """, unsafe_allow_html=True)
                
                # Show recent control signals
                st.markdown("### Recent Control Signals")
                
                # Filter for recent signals (last 10)
                recent_signals = df.head(10)
                
                for _, signal in recent_signals.iterrows():
                    signal_type = signal['signal_type']
                    target_component = signal['target_component']
                    result_status = signal.get('result_status', 'pending')
                    timestamp = signal['timestamp']
                    
                    # Determine result status color
                    if result_status == 'success':
                        result_color = '#28a745'
                        result_icon = '✅'
                    elif result_status == 'failure':
                        result_color = '#dc3545'
                        result_icon = '❌'
                    elif result_status == 'timeout':
                        result_color = '#ffc107'
                        result_icon = '⏰'
                    else:
                        result_color = '#6c757d'
                        result_icon = '⏳'
                    
                    # Determine signal type icon
                    if signal_type == 'start':
                        signal_icon = '▶️'
                    elif signal_type == 'stop':
                        signal_icon = '⏹️'
                    elif signal_type == 'restart':
                        signal_icon = '🔄'
                    elif signal_type == 'configure':
                        signal_icon = '⚙️'
                    elif signal_type == 'scale':
                        signal_icon = '📈'
                    elif signal_type == 'maintenance':
                        signal_icon = '🔧'
                    else:
                        signal_icon = '❓'
                    
                    st.markdown(f"""
                    <div class="health-card">
                        <strong>{signal_icon} {signal_type.upper()} → {target_component}</strong><br>
                        <span style="color: {result_color}">{result_icon} {result_status.upper()}</span><br>
                        <small>Time: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}</small>
                    </div>
                    """, unsafe_allow_html=True)
                
                # Show all control signals in a table
                st.markdown("### All Control Signals")
                display_df = df[['timestamp', 'signal_type', 'target_component', 'signal_source', 'result_status', 'acknowledged']].copy()
                st.dataframe(display_df, use_container_width=True)
                
            else:
                st.info("No control signals in the selected time range")
                
        except Exception as e:
            st.error(f"Failed to load control signals: {e}")
    
    def render_connection_status(self):
        """Render connection status section"""
        st.subheader("🔌 Connection Status")
        
        try:
            # Get connection status
            connection_status = self.connection_manager.get_status()
            collection_status = self.health_collector.get_collection_status()
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("### Database Connection")
                st.json(connection_status)
            
            with col2:
                st.markdown("### Collection Status")
                st.json(collection_status)
                
        except Exception as e:
            st.error(f"Failed to load connection status: {e}")
    
    def run(self):
        """Run the AHA Dashboard"""
        try:
            # Render header
            self.render_header()
            
            # Render sidebar and get time range
            hours = self.render_sidebar()
            
            # Create tabs for different sections
            tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
                "📊 Overview", 
                "🚪 Gateways", 
                "⚙️ Services", 
                "🚨 Alerts", 
                "🎛️ Control Signals",
                "🔌 Status"
            ])
            
            with tab1:
                self.render_system_overview(hours)
            
            with tab2:
                self.render_gateway_details(hours)
            
            with tab3:
                self.render_service_details(hours)
            
            with tab4:
                self.render_alerts_section(hours)
            
            with tab5:
                self.render_control_signals_section(hours)
            
            with tab6:
                self.render_connection_status()
            
            # Auto-refresh functionality
            if st.session_state.auto_refresh:
                time.sleep(st.session_state.refresh_interval)
                st.rerun()
                
        except Exception as e:
            st.error(f"Dashboard error: {e}")
            logger.error(f"Dashboard error: {e}")

def main():
    """Main function to run the AHA Dashboard"""
    try:
        dashboard = AHADashboard()
        dashboard.run()
    except Exception as e:
        st.error(f"Failed to initialize AHA Dashboard: {e}")
        logger.error(f"Failed to initialize AHA Dashboard: {e}")

if __name__ == "__main__":
    main()
