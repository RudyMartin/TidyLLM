"""
TidyLLM Onboarding Setup Page
============================

First-time system setup and configuration page.
"""

import streamlit as st
import yaml
import os
from pathlib import Path
from typing import Dict, Any

def render_setup_page():
    """Render the first-time system setup page."""
    
    st.markdown('<div class="section-header">🚀 TidyLLM First-Time Setup</div>', unsafe_allow_html=True)
    
    st.info("""
    **Welcome to TidyLLM! Let's get your system configured.**
    
    This setup wizard will guide you through configuring all required services:
    - AWS credentials and services (S3, Bedrock)
    - Database configuration
    - Workflow settings
    - System initialization
    """)
    
    # Get settings path
    settings_path = Path(__file__).parent.parent.parent.parent / "tidyllm" / "admin" / "settings.yaml"
    
    # Load current settings (may be empty for first-time setup)
    current_settings = {}
    if settings_path.exists():
        try:
            with open(settings_path, 'r') as f:
                current_settings = yaml.safe_load(f) or {}
        except Exception as e:
            st.warning(f"⚠️ Could not load existing settings: {e}")
    
    # No status checking - just show setup options
    
    # Create tabs for different configuration sections
    tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
        "🏢 Deployment Template",
        "🔑 AWS Setup",
        "🗄️ Database Setup",
        "🔗 Integrations Setup",
        "🚪 Gateway Configuration",
        "⚙️ Workflow Setup",
        "🚀 Initialize System"
    ])
    
    with tab1:
        render_deployment_template_tab(current_settings, settings_path)
    
    with tab2:
        render_aws_setup_tab(current_settings, settings_path)
    
    with tab3:
        render_database_setup_tab(current_settings, settings_path)

    with tab4:
        render_integrations_setup_tab(current_settings, settings_path)

    with tab5:
        render_gateway_configuration_tab(current_settings, settings_path)

    with tab6:
        render_workflow_setup_tab(current_settings, settings_path)

    with tab7:
        render_system_initialization_tab()

def render_deployment_template_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render deployment template selection tab."""
    st.markdown("### 🚀 Configuration Setup Options")
    
    st.info("""
    **Choose how you want to configure your TidyLLM system:**
    """)
    
    # Main choice: New vs Existing
    setup_mode = st.radio(
        "Setup Method",
        options=[
            "🆕 Create New Configuration (from blank template)",
            "🔄 Use Existing Environment (promote to active)"
        ],
        index=0,
        help="Choose whether to create a new configuration or use an existing environment template"
    )
    
    st.markdown("---")
    
    # Enhanced Template System using proposed_settings.yaml
    template_choice = "custom"
    
    if "🆕 Create New Configuration" in setup_mode:
        st.markdown("#### 🚀 Enhanced Template System")
        st.info("""
        **New**: Templates are now generated from `proposed_settings.yaml` with proper environment separation:
        - **Development**: Debug logging, dev S3 prefix, relaxed security
        - **Staging**: Production-like setup for testing
        - **Production**: Full security, prod S3 prefix, minimal logging
        - **Custom**: Build your own from minimal template
        """)
        
        # Template selection for new configuration
        template_choice = st.selectbox(
            "Choose Environment Template",
            options=["development", "staging", "production", "custom"],
            index=0,  # Default to development
            help="Select an environment template generated from proposed_settings.yaml"
        )
        
        # Show template status
        try:
            from old_core.settings_template_manager import get_template_manager
            manager = get_template_manager()
            status = manager.get_environment_status()
            
            col1, col2, col3 = st.columns(3)
            with col1:
                if status["proposed_settings_exists"]:
                    st.success("✅ Template Source Available")
                else:
                    st.error("❌ proposed_settings.yaml Missing")
            
            with col2:
                if status["admin_directory_exists"]:
                    st.success("✅ Admin Directory Ready")
                else:
                    st.warning("⚠️ Creating Admin Directory")
            
            with col3:
                st.info(f"📂 {status['backup_count']} Backups Available")
                
        except ImportError:
            st.warning("⚠️ Enhanced template system not available")
        
        render_enhanced_template_workflow(current_settings, settings_path, template_choice)
    else:
        render_existing_environment_workflow(current_settings, settings_path)
    
    # Template descriptions
    if template_choice == "corporate":
        st.markdown("#### 🏢 Corporate Template")
        st.info("""
        **Enterprise-grade configuration for production environments:**
        - AWS SSO enabled with corporate profile
        - SSL-required database connections
        - Full security features (encryption, audit logging, data masking)
        - SOX compliance mode
        - Horizontal scaling with monitoring
        - Backup enabled
        """)
    
    elif template_choice == "development":
        st.markdown("#### 🛠️ Development Template")
        st.info("""
        **Simplified configuration for development environments:**
        - Local database connections
        - Minimal security features
        - Fast model selection (Claude Haiku)
        - Single instance scaling
        - No monitoring or backup
        """)
    
    elif template_choice == "staging":
        st.markdown("#### 🧪 Staging Template")
        st.info("""
        **Production-like configuration for testing:**
        - AWS SSO enabled
        - SSL-required database connections
        - Full security features
        - Horizontal scaling with monitoring
        - Backup enabled
        """)
    
    else:
        st.markdown("#### ⚙️ Custom Template")
        st.info("""
        **Build your own configuration from scratch.**
        You'll configure each section manually in the following tabs.
        """)
    
    # Preview template if requested
    if hasattr(st.session_state, 'preview_template') and st.session_state.preview_template == template_choice:
        try:
            from config.templates import ConfigTemplates
            template_config = ConfigTemplates.get_template_by_name(template_choice)
            
            st.markdown("#### 📋 Template Configuration Preview")
            st.json(template_config)
            
        except Exception as e:
            st.error(f"❌ Error loading template: {e}")
    
    # Apply template
    if template_choice != "custom":
        if st.button("🚀 Apply Template", type="primary"):
            try:
                from config.templates import ConfigTemplates
                template_config = ConfigTemplates.get_template_by_name(template_choice)
                
                # Merge template with current settings
                merged_settings = current_settings.copy()
                
                # Apply template sections
                for section, config in template_config.items():
                    if section not in merged_settings:
                        merged_settings[section] = {}
                    merged_settings[section].update(config)
                
                # Add deployment metadata
                merged_settings["deployment"] = merged_settings.get("deployment", {})
                merged_settings["deployment"]["template_used"] = template_choice
                merged_settings["deployment"]["template_applied_at"] = str(Path().cwd())
                
                # Save merged settings
                with open(settings_path, 'w') as f:
                    yaml.dump(merged_settings, f, default_flow_style=False, sort_keys=False)
                
                st.success(f"✅ {template_choice.title()} template applied successfully!")
                st.info("🔄 Please refresh the page to see the applied configuration.")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error applying template: {e}")
    
    # Advanced template customization
    with st.expander("🔧 Advanced Template Customization"):
        st.markdown("#### Customize Template Settings")
        
        col1, col2 = st.columns(2)
        
        with col1:
            enable_ssl = st.checkbox(
                "Enable SSL for Database",
                value=current_settings.get("database", {}).get("ssl_mode") == "require",
                help="Require SSL connections for database"
            )
            
            enable_audit = st.checkbox(
                "Enable Audit Logging",
                value=current_settings.get("security", {}).get("audit_logging", False),
                help="Enable comprehensive audit logging"
            )
        
        with col2:
            enable_encryption = st.checkbox(
                "Enable Data Encryption",
                value=current_settings.get("security", {}).get("encryption", False),
                help="Enable data encryption at rest"
            )
            
            enable_monitoring = st.checkbox(
                "Enable Monitoring",
                value=current_settings.get("deployment", {}).get("monitoring", False),
                help="Enable system monitoring and alerting"
            )
        
        if st.button("💾 Save Custom Settings"):
            try:
                # Update security settings
                if "security" not in current_settings:
                    current_settings["security"] = {}
                current_settings["security"]["encryption"] = enable_encryption
                current_settings["security"]["audit_logging"] = enable_audit
                
                # Update database settings
                if "database" not in current_settings:
                    current_settings["database"] = {}
                current_settings["database"]["ssl_mode"] = "require" if enable_ssl else "disable"
                
                # Update deployment settings
                if "deployment" not in current_settings:
                    current_settings["deployment"] = {}
                current_settings["deployment"]["monitoring"] = enable_monitoring
                
                # Save settings
                with open(settings_path, 'w') as f:
                    yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
                
                st.success("✅ Custom settings saved successfully!")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error saving custom settings: {e}")

def render_aws_setup_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render AWS configuration tab."""
    st.markdown("### 🔑 AWS Services Configuration")
    
    st.info("""
    **Configure AWS credentials and services.**
    
    Required for: S3 storage, Bedrock AI models, STS authentication
    """)
    
    # Get current AWS config
    aws_config = current_settings.get("aws", {})
    api_keys = current_settings.get("api_keys", {})
    
    # AWS credentials
    col1, col2 = st.columns(2)
    
    with col1:
        aws_access_key = st.text_input(
            "AWS Access Key ID",
            value=aws_config.get("access_key_id", api_keys.get("aws_access_key_id", "AKIASXYZBZ46D4MIAYC2")),
            type="password",
            help="Your AWS access key ID"
        )
        
        aws_region = st.selectbox(
            "AWS Region",
            options=["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"],
            index=["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"].index(aws_config.get("region", "us-east-1")),
            help="AWS region for your services"
        )
    
    with col2:
        aws_secret_key = st.text_input(
            "AWS Secret Access Key",
            value=aws_config.get("secret_access_key", api_keys.get("aws_secret_access_key", "xGMWglS3y6LbOk+uDMrb6rFwRrCpJBgzMrhoWtYk")),
            type="password",
            help="Your AWS secret access key"
        )
        
        # Show current region
        if aws_config.get("region"):
            st.info(f"Current region: `{aws_config.get('region')}`")
    
    # S3 Configuration
    st.markdown("#### 📦 S3 Configuration")
    
    st.info("""
    **Configure S3 storage settings.**

    Required for: Document storage, file uploads, data persistence
    - **Primary S3**: Main document storage bucket
    - **Backup S3**: Backup and disaster recovery storage
    - **Archive S3**: Long-term archival storage
    """)

    # S3 configuration tabs
    s3_tab1, s3_tab2, s3_tab3 = st.tabs([
        "📁 Primary S3",
        "💾 Backup S3", 
        "🗄️ Archive S3"
    ])

    with s3_tab1:
        render_s3_config_form(
            "Primary S3",
            "primary",
            current_settings,
            settings_path,
            is_required=True
        )

    with s3_tab2:
        render_s3_config_form(
            "Backup S3",
            "backup",
            current_settings,
            settings_path,
            is_required=False
        )

    with s3_tab3:
        render_s3_config_form(
            "Archive S3",
            "archive",
            current_settings,
            settings_path,
            is_required=False
        )

    # Each S3 bucket has its own save and test buttons within its tab
    
    
    # Bedrock Configuration
    st.markdown("#### 🤖 Bedrock Configuration")
    col1, col2 = st.columns(2)
    
    with col1:
        bedrock_model = st.selectbox(
            "Default Bedrock Model",
            options=[
                "anthropic.claude-3-sonnet-20240229-v1:0",
                "anthropic.claude-3-haiku-20240307-v1:0",
                "anthropic.claude-3-opus-20240229-v1:0"
            ],
            index=0,
            help="Default model for AI processing"
        )
    
    with col2:
        st.info("""
        **Corporate Environment Notice:**
        Bedrock models are region-specific. Ensure your region supports the selected model.
        
        **Corporate Restrictions:** Some API calls may be limited by your organization's security policies.
        """)
    
    # Bedrock Test Button
    st.markdown("---")
    col1, col2, col3 = st.columns([1, 1, 1])
    
    with col2:
        if st.button("🧪 Test Bedrock Connection", use_container_width=True, type="primary"):
            with st.spinner("Testing Bedrock connectivity..."):
                try:
                    from old_core.validator import OnboardingValidator
                    validator = OnboardingValidator()
                    aws_results = validator.validate_aws_connectivity()
                    bedrock_result = aws_results.get('bedrock', {})
                    if bedrock_result.get('status') == 'success':
                        st.success("✅ **Bedrock Connected Successfully!**")
                        st.info(f"**Response Time**: {bedrock_result.get('latency', 0):.1f}ms")
                        st.balloons()
                    else:
                        st.error(f"❌ **Bedrock Connection Failed**")
                        st.error(f"**Error**: {bedrock_result.get('message', 'Unknown error')}")
                except Exception as e:
                    st.error(f"❌ **Bedrock Test Failed**: {e}")
    
    st.markdown("---")
    
    # Save AWS configuration
    if st.button("💾 Save AWS Configuration", type="primary"):
        if aws_access_key and aws_secret_key:
            try:
                # Update settings
                if "aws" not in current_settings:
                    current_settings["aws"] = {}
                if "api_keys" not in current_settings:
                    current_settings["api_keys"] = {}
                if "s3" not in current_settings:
                    current_settings["s3"] = {}
                if "bedrock" not in current_settings:
                    current_settings["bedrock"] = {}
                
                # AWS credentials
                current_settings["aws"]["access_key_id"] = aws_access_key
                current_settings["aws"]["secret_access_key"] = aws_secret_key
                current_settings["aws"]["region"] = aws_region
                current_settings["aws"]["default_region"] = aws_region
                
                # API keys (for compatibility)
                current_settings["api_keys"]["aws_access_key_id"] = aws_access_key
                current_settings["api_keys"]["aws_secret_access_key"] = aws_secret_key
                
                # S3 configuration
                current_settings["s3"]["default_bucket"] = s3_bucket
                current_settings["s3"]["default_prefix"] = s3_prefix
                
                # Bedrock configuration
                current_settings["bedrock"]["default_model"] = bedrock_model
                current_settings["bedrock"]["region"] = aws_region
                
                # Save to file
                with open(settings_path, 'w') as f:
                    yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
                
                st.success("✅ AWS configuration saved successfully!")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error saving AWS configuration: {e}")
        else:
            st.warning("⚠️ Please enter both AWS Access Key ID and Secret Access Key")

def render_database_setup_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render database configuration tab."""
    st.markdown("### 🗄️ Database Configuration")
    
    st.info("""
    **Configure multiple PostgreSQL database connections.**
    
    Required for: Vector storage, knowledge management, workflow persistence
    - **Primary Database**: Main operational database
    - **Secondary Database**: Read replica or failover database  
    - **Backup Database**: Backup and disaster recovery database
    """)
    
    # Database configuration tabs
    db_tab1, db_tab2, db_tab3 = st.tabs([
        "🏢 Primary Database", 
        "🔄 Secondary Database", 
        "💾 Backup Database"
    ])
    
    with db_tab1:
        render_database_config_form(
            "Primary Database", 
            "primary", 
            current_settings, 
            settings_path,
            is_required=True
        )
    
    with db_tab2:
        render_database_config_form(
            "Secondary Database", 
            "secondary", 
            current_settings, 
            settings_path,
            is_required=False
        )
    
    with db_tab3:
        render_database_config_form(
            "Backup Database", 
            "backup", 
            current_settings, 
            settings_path,
            is_required=False
        )
    
    # Each database has its own save and test buttons within its tab

def render_database_config_form(
    db_name: str, 
    db_key: str, 
    current_settings: Dict[str, Any], 
    settings_path: Path,
    is_required: bool = False
):
    """Render individual database configuration form."""
    
    # Get current database config
    db_config = current_settings.get("databases", {}).get(db_key, {})
    
    st.markdown(f"#### {db_name} Configuration")
    
    if not is_required:
        st.info("ℹ️ This database is optional and can be configured later.")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # Pre-populate with actual data from settings.yaml
        if db_key == "primary":
            default_host = db_config.get("host", "vectorqa-cluster.cluster-cu562e4m02nq.us-east-1.rds.amazonaws.com")
            default_port = db_config.get("port", 5432)
            default_db_name = db_config.get("database", "vectorqa")
            default_username = db_config.get("username", "vectorqa_user")
            default_password = db_config.get("password", "Fujifuji500!")
        elif db_key == "secondary":
            default_host = db_config.get("host", "localhost")
            default_port = db_config.get("port", 5432)
            default_db_name = db_config.get("database", "backup_db")
            default_username = db_config.get("username", "backup_user")
            default_password = db_config.get("password", "")
        else:  # backup
            default_host = db_config.get("host", "./data/backup.db")
            default_port = db_config.get("port", 3306)
            default_db_name = db_config.get("database", "./data/backup.db")
            default_username = db_config.get("username", "backup_user")
            default_password = db_config.get("password", "test")

        db_host = st.text_input(
            f"{db_name} Host",
            value=default_host,
            help=f"PostgreSQL server hostname or IP for {db_name.lower()}"
        )

        db_port = st.number_input(
            f"{db_name} Port",
            value=default_port,
            min_value=1,
            max_value=65535,
            help=f"PostgreSQL server port for {db_name.lower()}"
        )

        db_name_input = st.text_input(
            f"{db_name} Database Name",
            value=default_db_name,
            help=f"Database name for {db_name.lower()}"
        )

    with col2:
        db_username = st.text_input(
            f"{db_name} Username",
            value=default_username,
            help=f"Database username for {db_name.lower()}"
        )

        db_password = st.text_input(
            f"{db_name} Password",
            value=default_password,
            type="password",
            help=f"Database password for {db_name.lower()}"
        )
        
        # Database-specific settings
        if db_key == "primary":
            db_ssl_mode = st.selectbox(
                "SSL Mode",
                options=["disable", "allow", "prefer", "require"],
                index=3,
                help="SSL connection mode for primary database"
            )
        elif db_key == "secondary":
            db_ssl_mode = st.selectbox(
                "SSL Mode",
                options=["disable", "allow", "prefer", "require"],
                index=2,
                help="SSL connection mode for secondary database"
            )
        else:  # backup
            db_ssl_mode = st.selectbox(
                "SSL Mode",
                options=["disable", "allow", "prefer", "require"],
                index=1,
                help="SSL connection mode for backup database"
            )
    
    # Connection test for this specific database
    if st.button(f"🧪 Test {db_name} Connection"):
        if db_host and db_username and db_password:
            with st.spinner(f"Testing {db_name.lower()} connection..."):
                try:
                    import psycopg2
                    conn = psycopg2.connect(
                        host=db_host,
                        port=db_port,
                        database=db_name_input,
                        user=db_username,
                        password=db_password,
                        sslmode=db_ssl_mode
                    )
                    conn.close()
                    st.success(f"✅ {db_name} connection successful!")
                except Exception as e:
                    st.error(f"❌ {db_name} connection failed: {e}")
        else:
            st.warning(f"⚠️ Please enter {db_name.lower()} host, username, and password")
    
    # Save this specific database configuration
    if st.button(f"💾 Save {db_name} Configuration"):
        if db_host and db_username and db_password:
            try:
                # Update settings
                if "databases" not in current_settings:
                    current_settings["databases"] = {}
                if db_key not in current_settings["databases"]:
                    current_settings["databases"][db_key] = {}
                
                current_settings["databases"][db_key]["host"] = db_host
                current_settings["databases"][db_key]["port"] = db_port
                current_settings["databases"][db_key]["database"] = db_name_input
                current_settings["databases"][db_key]["username"] = db_username
                current_settings["databases"][db_key]["password"] = db_password
                current_settings["databases"][db_key]["ssl_mode"] = db_ssl_mode
                current_settings["databases"][db_key]["enabled"] = True
                
                # Also maintain backward compatibility with single postgres config
                if db_key == "primary":
                    current_settings["postgres"] = current_settings["databases"][db_key]
                
                # Save to file
                with open(settings_path, 'w') as f:
                    yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
                
                st.success(f"✅ {db_name} configuration saved successfully!")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error saving {db_name.lower()} configuration: {e}")
        else:
            st.warning(f"⚠️ Please enter {db_name.lower()} host, username, and password")

def test_database_connection(db_key: str, current_settings: Dict[str, Any]):
    """Test database connection for a specific database."""
    db_config = current_settings.get("databases", {}).get(db_key, {})
    
    if not db_config.get("host"):
        st.warning(f"⚠️ {db_key.title()} database not configured")
        return
    
    with st.spinner(f"Testing {db_key} database connection..."):
        try:
            import psycopg2
            conn = psycopg2.connect(
                host=db_config.get("host"),
                port=db_config.get("port", 5432),
                database=db_config.get("database"),
                user=db_config.get("username"),
                password=db_config.get("password"),
                sslmode=db_config.get("ssl_mode", "prefer")
            )
            conn.close()
            st.success(f"✅ {db_key.title()} database connection successful!")
        except Exception as e:
            st.error(f"❌ {db_key.title()} database connection failed: {e}")

def render_s3_config_form(
    s3_name: str,
    s3_key: str,
    current_settings: Dict[str, Any],
    settings_path: Path,
    is_required: bool = False
):
    """Render individual S3 configuration form."""

    # Get current S3 config
    s3_config = current_settings.get("s3_buckets", {}).get(s3_key, {})
    
    # Fallback to main s3 config for primary
    if s3_key == "primary" and not s3_config:
        s3_config = current_settings.get("s3", {})

    st.markdown(f"#### {s3_name} Configuration")

    if not is_required:
        st.info("ℹ️ This S3 bucket is optional and can be configured later.")

    col1, col2 = st.columns(2)

    with col1:
        # Pre-populate with actual data from settings.yaml
        if s3_key == "primary":
            # Use the main s3 config data
            default_bucket = s3_config.get("bucket", "nsc-mvp1")
            default_prefix = s3_config.get("prefix", "onboarding-test/")
            default_region = s3_config.get("region", "us-east-1")
            default_timeout = s3_config.get("connection_timeout", 30)
            default_retries = s3_config.get("max_retries", 3)
            default_marker = s3_config.get("test_marker", "test_marker_1757467241")
        else:
            # Use defaults for backup/archive
            default_bucket = s3_config.get("bucket", f"nsc-mvp1-{s3_key}")
            default_prefix = s3_config.get("prefix", f"onboarding-test/{s3_key}/")
            default_region = s3_config.get("region", "us-east-1")
            default_timeout = s3_config.get("connection_timeout", 30)
            default_retries = s3_config.get("max_retries", 3)
            default_marker = s3_config.get("test_marker", f"test_marker_{s3_key}")

        s3_bucket = st.text_input(
            f"{s3_name} Bucket Name",
            value=default_bucket,
            help=f"S3 bucket name for {s3_name.lower()}"
        )
        
        s3_prefix = st.text_input(
            f"{s3_name} Prefix",
            value=default_prefix,
            help=f"S3 prefix for {s3_name.lower()}"
        )
        
        s3_region = st.selectbox(
            f"{s3_name} Region",
            options=["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"],
            index=["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"].index(default_region),
            help=f"AWS region for {s3_name.lower()}"
        )

    with col2:
        s3_connection_timeout = st.number_input(
            f"{s3_name} Connection Timeout (seconds)",
            value=default_timeout,
            min_value=5,
            max_value=300,
            help=f"S3 connection timeout for {s3_name.lower()}"
        )
        
        s3_max_retries = st.number_input(
            f"{s3_name} Max Retries",
            value=default_retries,
            min_value=0,
            max_value=10,
            help=f"Maximum retry attempts for {s3_name.lower()}"
        )
        
        s3_test_marker = st.text_input(
            f"{s3_name} Test Marker",
            value=default_marker,
            help=f"Test marker for {s3_name.lower()} connectivity testing"
        )

    # S3-specific settings
    if s3_key == "primary":
        s3_encryption = st.checkbox(
            "Enable Encryption",
            value=s3_config.get("encryption", True),
            help="Enable server-side encryption for primary S3",
            key=f"s3_{s3_key}_encryption"
        )
        s3_versioning = st.checkbox(
            "Enable Versioning",
            value=s3_config.get("versioning", False),
            help="Enable versioning for primary S3",
            key=f"s3_{s3_key}_versioning"
        )
    elif s3_key == "backup":
        s3_encryption = st.checkbox(
            "Enable Encryption",
            value=s3_config.get("encryption", True),
            help="Enable server-side encryption for backup S3",
            key=f"s3_{s3_key}_encryption"
        )
        s3_lifecycle = st.checkbox(
            "Enable Lifecycle",
            value=s3_config.get("lifecycle", True),
            help="Enable lifecycle policies for backup S3",
            key=f"s3_{s3_key}_lifecycle"
        )
    else:  # archive
        s3_encryption = st.checkbox(
            "Enable Encryption",
            value=s3_config.get("encryption", True),
            help="Enable server-side encryption for archive S3",
            key=f"s3_{s3_key}_encryption"
        )
        s3_glacier = st.checkbox(
            "Enable Glacier",
            value=s3_config.get("glacier_enabled", False),
            help="Enable Glacier storage class for archive S3",
            key=f"s3_{s3_key}_glacier"
        )

    # Connection test for this specific S3
    if st.button(f"🧪 Test {s3_name} Connection"):
        if s3_bucket:
            with st.spinner(f"Testing {s3_name.lower()} connection..."):
                try:
                    test_s3_connection_direct(s3_bucket, s3_region, s3_prefix)
                    st.success(f"✅ {s3_name} connection successful!")
                except Exception as e:
                    st.error(f"❌ {s3_name} connection failed: {e}")
        else:
            st.warning(f"⚠️ Please enter {s3_name.lower()} bucket name")

    # Save this specific S3 configuration
    if st.button(f"💾 Save {s3_name} Configuration"):
        if s3_bucket:
            try:
                # Update settings
                if "s3_buckets" not in current_settings:
                    current_settings["s3_buckets"] = {}
                if s3_key not in current_settings["s3_buckets"]:
                    current_settings["s3_buckets"][s3_key] = {}

                current_settings["s3_buckets"][s3_key]["bucket"] = s3_bucket
                current_settings["s3_buckets"][s3_key]["prefix"] = s3_prefix
                current_settings["s3_buckets"][s3_key]["region"] = s3_region
                current_settings["s3_buckets"][s3_key]["connection_timeout"] = s3_connection_timeout
                current_settings["s3_buckets"][s3_key]["max_retries"] = s3_max_retries
                current_settings["s3_buckets"][s3_key]["test_marker"] = s3_test_marker
                current_settings["s3_buckets"][s3_key]["enabled"] = True

                # Add S3-specific settings
                if s3_key == "primary":
                    current_settings["s3_buckets"][s3_key]["encryption"] = s3_encryption
                    current_settings["s3_buckets"][s3_key]["versioning"] = s3_versioning
                    # Also maintain backward compatibility with main s3 config
                    current_settings["s3"] = current_settings["s3_buckets"][s3_key]
                elif s3_key == "backup":
                    current_settings["s3_buckets"][s3_key]["encryption"] = s3_encryption
                    current_settings["s3_buckets"][s3_key]["lifecycle"] = s3_lifecycle
                else:  # archive
                    current_settings["s3_buckets"][s3_key]["encryption"] = s3_encryption
                    current_settings["s3_buckets"][s3_key]["glacier_enabled"] = s3_glacier

                # Save to file
                with open(settings_path, 'w') as f:
                    yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

                st.success(f"✅ {s3_name} configuration saved successfully!")
                st.rerun()

            except Exception as e:
                st.error(f"❌ Error saving {s3_name.lower()} configuration: {e}")
        else:
            st.warning(f"⚠️ Please enter {s3_name.lower()} bucket name")

def test_s3_connection(s3_key: str, current_settings: Dict[str, Any]):
    """Test S3 connection for a specific S3 bucket."""
    s3_config = current_settings.get("s3_buckets", {}).get(s3_key, {})
    
    # Fallback to main s3 config for primary
    if s3_key == "primary" and not s3_config:
        s3_config = current_settings.get("s3", {})

    if not s3_config.get("bucket"):
        st.warning(f"⚠️ {s3_key.title()} S3 bucket not configured")
        return

    with st.spinner(f"Testing {s3_key} S3 connection..."):
        try:
            test_s3_connection_direct(
                s3_config.get("bucket"),
                s3_config.get("region", "us-east-1"),
                s3_config.get("prefix", "")
            )
            st.success(f"✅ {s3_key.title()} S3 connection successful!")
        except Exception as e:
            st.error(f"❌ {s3_key.title()} S3 connection failed: {e}")

def test_s3_connection_direct(bucket: str, region: str, prefix: str):
    """Test S3 connection directly."""
    try:
        import boto3
        from botocore.exceptions import ClientError
        
        # Create S3 client
        s3_client = boto3.client('s3', region_name=region)
        
        # Test bucket access
        s3_client.head_bucket(Bucket=bucket)
        
        # Test list objects
        response = s3_client.list_objects_v2(
            Bucket=bucket,
            Prefix=prefix,
            MaxKeys=1
        )
        
        return True
        
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == '404':
            raise Exception(f"Bucket '{bucket}' not found")
        elif error_code == '403':
            raise Exception(f"Access denied to bucket '{bucket}'")
        else:
            raise Exception(f"S3 error: {error_code}")
    except Exception as e:
        raise Exception(f"S3 connection failed: {str(e)}")

def render_integrations_setup_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render integrations configuration tab."""
    st.markdown("### 🔗 Integrations Configuration")

    st.info("""
    **Configure external service integrations.**

    Required for: MLflow tracking, observability, SSO, LDAP
    - **MLflow**: Machine learning experiment tracking
    - **Observability**: Monitoring and alerting services
    - **SSO/LDAP**: Authentication and user management
    """)

    # Get current integrations config
    integrations_config = current_settings.get("integrations", {})

    # Integration configuration tabs
    int_tab1, int_tab2, int_tab3 = st.tabs([
        "🧪 MLflow Integration",
        "📊 Observability",
        "🔐 Authentication"
    ])

    with int_tab1:
        render_mlflow_config_form(current_settings, settings_path)

    with int_tab2:
        render_observability_config_form(current_settings, settings_path)

    with int_tab3:
        render_auth_config_form(current_settings, settings_path)

def render_mlflow_config_form(current_settings: Dict[str, Any], settings_path: Path):
    """Render MLflow configuration form."""
    st.markdown("#### 🧪 MLflow Configuration")

    mlflow_config = current_settings.get("integrations", {}).get("mlflow", {})

    col1, col2 = st.columns(2)

    with col1:
        mlflow_enabled = st.checkbox(
            "Enable MLflow",
            value=mlflow_config.get("enabled", True),
            help="Enable MLflow experiment tracking",
            key="mlflow_enabled"
        )

        mlflow_tracking_uri = st.text_input(
            "MLflow Tracking URI",
            value=mlflow_config.get("tracking_uri", "http://localhost:5000"),
            help="MLflow tracking server URI"
        )

        mlflow_backend_store_uri = st.text_input(
            "Backend Store URI",
            value=mlflow_config.get("backend_store_uri", "postgresql://vectorqa_user:Fujifuji500!@vectorqa-cluster.cluster-cu562e4m02nq.us-east-1.rds.amazonaws.com:5432/vectorqa?sslmode=require"),
            help="Database URI for MLflow backend store"
        )

    with col2:
        mlflow_artifact_store = st.text_input(
            "Artifact Store",
            value=mlflow_config.get("artifact_store", "s3://nsc-mvp1/onboarding-test/mlflow/"),
            help="S3 URI for MLflow artifact storage"
        )

        mlflow_server_host = st.text_input(
            "Server Host",
            value=mlflow_config.get("server", {}).get("host", "0.0.0.0"),
            help="MLflow server host"
        )

        mlflow_server_port = st.number_input(
            "Server Port",
            value=mlflow_config.get("server", {}).get("port", 5000),
            min_value=1000,
            max_value=65535,
            help="MLflow server port"
        )

    # Save MLflow configuration
    if st.button("💾 Save MLflow Configuration", type="primary"):
        try:
            # Update settings
            if "integrations" not in current_settings:
                current_settings["integrations"] = {}
            if "mlflow" not in current_settings["integrations"]:
                current_settings["integrations"]["mlflow"] = {}

            current_settings["integrations"]["mlflow"]["enabled"] = mlflow_enabled
            current_settings["integrations"]["mlflow"]["tracking_uri"] = mlflow_tracking_uri
            current_settings["integrations"]["mlflow"]["backend_store_uri"] = mlflow_backend_store_uri
            current_settings["integrations"]["mlflow"]["artifact_store"] = mlflow_artifact_store
            current_settings["integrations"]["mlflow"]["server"] = {
                "host": mlflow_server_host,
                "port": mlflow_server_port
            }

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ MLflow configuration saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving MLflow configuration: {e}")
    
    # Test MLflow Integration Button
    st.markdown("---")
    st.markdown("#### 🧪 Test MLflow Integration")
    
    col1, col2 = st.columns(2)
    with col1:
        if st.button("🧪 Test MLflow Integration", use_container_width=True):
            with st.spinner("Testing MLflow integration (Server + Database + S3)..."):
                try:
                    from old_core.validator import OnboardingValidator
                    validator = OnboardingValidator()
                    mlflow_results = validator.validate_mlflow_integration()
                    
                    st.session_state.mlflow_test_results = mlflow_results
                    st.success("✅ MLflow integration test completed!")
                    
                except Exception as e:
                    st.error(f"❌ MLflow integration test failed: {e}")
    
    with col2:
        st.info("Tests all MLflow components:\n- 🌐 Tracking Server\n- 🗃️ Backend Database\n- 📦 S3 Artifact Store")
    
    # Display MLflow test results if available
    if hasattr(st.session_state, 'mlflow_test_results'):
        from setup import display_test_results  # Import the display function
        display_test_results("MLflow Integration", st.session_state.mlflow_test_results)

def render_observability_config_form(current_settings: Dict[str, Any], settings_path: Path):
    """Render observability configuration form."""
    st.markdown("#### 📊 Observability Configuration")

    observability_config = current_settings.get("integrations", {}).get("observability", {})

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("##### 📈 Datadog")
        datadog_enabled = st.checkbox(
            "Enable Datadog",
            value=observability_config.get("datadog", {}).get("enabled", False),
            help="Enable Datadog monitoring",
            key="datadog_enabled"
        )

        st.markdown("##### 📊 New Relic")
        newrelic_enabled = st.checkbox(
            "Enable New Relic",
            value=observability_config.get("newrelic", {}).get("enabled", False),
            help="Enable New Relic monitoring",
            key="newrelic_enabled"
        )

    with col2:
        st.markdown("##### 🔍 Monitoring Settings")
        monitoring_enabled = st.checkbox(
            "Enable Monitoring",
            value=current_settings.get("monitoring", {}).get("enabled", True),
            help="Enable system monitoring",
            key="monitoring_enabled"
        )

        health_check_enabled = st.checkbox(
            "Enable Health Checks",
            value=current_settings.get("monitoring", {}).get("health_check", {}).get("enabled", True),
            help="Enable health check endpoints",
            key="monitoring_health_check_enabled"
        )

        metrics_enabled = st.checkbox(
            "Enable Metrics",
            value=current_settings.get("monitoring", {}).get("metrics", {}).get("enabled", True),
            help="Enable metrics collection",
            key="monitoring_metrics_enabled"
        )

    # Save observability configuration
    if st.button("💾 Save Observability Configuration", type="primary"):
        try:
            # Update settings
            if "integrations" not in current_settings:
                current_settings["integrations"] = {}
            if "observability" not in current_settings["integrations"]:
                current_settings["integrations"]["observability"] = {}

            current_settings["integrations"]["observability"]["datadog"] = {"enabled": datadog_enabled}
            current_settings["integrations"]["observability"]["newrelic"] = {"enabled": newrelic_enabled}

            if "monitoring" not in current_settings:
                current_settings["monitoring"] = {}
            current_settings["monitoring"]["enabled"] = monitoring_enabled
            current_settings["monitoring"]["health_check"] = {"enabled": health_check_enabled}
            current_settings["monitoring"]["metrics"] = {"enabled": metrics_enabled}

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ Observability configuration saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving observability configuration: {e}")

def render_auth_config_form(current_settings: Dict[str, Any], settings_path: Path):
    """Render authentication configuration form."""
    st.markdown("#### 🔐 Authentication Configuration")

    auth_config = current_settings.get("integrations", {})

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("##### 🔑 SSO")
        sso_enabled = st.checkbox(
            "Enable SSO",
            value=auth_config.get("sso", {}).get("enabled", False),
            help="Enable Single Sign-On",
            key="sso_enabled"
        )

    with col2:
        st.markdown("##### 🏢 LDAP")
        ldap_enabled = st.checkbox(
            "Enable LDAP",
            value=auth_config.get("ldap", {}).get("enabled", False),
            help="Enable LDAP authentication",
            key="ldap_enabled"
        )

    # Save authentication configuration
    if st.button("💾 Save Authentication Configuration", type="primary"):
        try:
            # Update settings
            if "integrations" not in current_settings:
                current_settings["integrations"] = {}

            current_settings["integrations"]["sso"] = {"enabled": sso_enabled}
            current_settings["integrations"]["ldap"] = {"enabled": ldap_enabled}

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ Authentication configuration saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving authentication configuration: {e}")

def render_gateway_configuration_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render gateway configuration tab."""
    st.markdown("### 🚪 Gateway Configuration")

    st.info("""
    **Configure TidyLLM gateway settings and system paths.**

    Required for: Gateway initialization, path management, system configuration
    - **Core Gateways**: Corporate LLM, AI Processing, Workflow Optimizer, Knowledge MCP
    - **System Paths**: Root folder detection and path management
    - **Onboarding Settings**: Health checks, refresh intervals, retry attempts
    """)

    # Get current gateway and system configs
    gateways_config = current_settings.get("gateways", {})
    system_config = current_settings.get("system", {})
    onboarding_config = current_settings.get("onboarding", {})

    # Gateway configuration tabs
    gw_tab1, gw_tab2, gw_tab3 = st.tabs([
        "🚪 Core Gateways",
        "📁 System Paths",
        "⚙️ Onboarding Settings"
    ])

    with gw_tab1:
        render_core_gateways_config(current_settings, settings_path)

    with gw_tab2:
        render_system_paths_config(current_settings, settings_path)

    with gw_tab3:
        render_onboarding_settings_config(current_settings, settings_path)

def render_core_gateways_config(current_settings: Dict[str, Any], settings_path: Path):
    """Render core gateways configuration."""
    st.markdown("#### 🚪 Core Gateways Configuration")

    gateways_config = current_settings.get("gateways", {})

    # Corporate LLM Gateway
    st.markdown("##### 🤖 Corporate LLM Gateway")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        corp_llm_enabled = st.checkbox(
            "Enable Corporate LLM",
            value=gateways_config.get("corporate_llm", {}).get("enabled", True),
            help="Enable Corporate LLM Gateway",
            key="gateway_corp_llm_enabled"
        )
    
    with col2:
        corp_llm_timeout = st.number_input(
            "Timeout (seconds)",
            value=gateways_config.get("corporate_llm", {}).get("timeout", 30.0),
            min_value=5.0,
            max_value=300.0,
            step=5.0,
            help="Corporate LLM Gateway timeout"
        )
    
    with col3:
        corp_llm_retries = st.number_input(
            "Retry Attempts",
            value=gateways_config.get("corporate_llm", {}).get("retry_attempts", 3),
            min_value=0,
            max_value=10,
            help="Corporate LLM Gateway retry attempts"
        )

    # AI Processing Gateway
    st.markdown("##### 🧠 AI Processing Gateway")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        ai_proc_enabled = st.checkbox(
            "Enable AI Processing",
            value=gateways_config.get("ai_processing", {}).get("enabled", True),
            help="Enable AI Processing Gateway",
            key="gateway_ai_proc_enabled"
        )
    
    with col2:
        ai_proc_timeout = st.number_input(
            "AI Processing Timeout (seconds)",
            value=gateways_config.get("ai_processing", {}).get("timeout", 45.0),
            min_value=5.0,
            max_value=300.0,
            step=5.0,
            help="AI Processing Gateway timeout"
        )
    
    with col3:
        ai_proc_retries = st.number_input(
            "AI Processing Retry Attempts",
            value=gateways_config.get("ai_processing", {}).get("retry_attempts", 2),
            min_value=0,
            max_value=10,
            help="AI Processing Gateway retry attempts"
        )

    # Workflow Optimizer Gateway
    st.markdown("##### ⚙️ Workflow Optimizer Gateway")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        workflow_opt_enabled = st.checkbox(
            "Enable Workflow Optimizer",
            value=gateways_config.get("workflow_optimizer", {}).get("enabled", True),
            help="Enable Workflow Optimizer Gateway",
            key="gateway_workflow_opt_enabled"
        )
    
    with col2:
        workflow_opt_timeout = st.number_input(
            "Workflow Optimizer Timeout (seconds)",
            value=gateways_config.get("workflow_optimizer", {}).get("timeout", 60.0),
            min_value=5.0,
            max_value=300.0,
            step=5.0,
            help="Workflow Optimizer Gateway timeout"
        )
    
    with col3:
        workflow_opt_retries = st.number_input(
            "Workflow Optimizer Retry Attempts",
            value=gateways_config.get("workflow_optimizer", {}).get("retry_attempts", 2),
            min_value=0,
            max_value=10,
            help="Workflow Optimizer Gateway retry attempts"
        )

    # Knowledge MCP Gateway
    st.markdown("##### 📚 Knowledge MCP Gateway")
    col1, col2, col3 = st.columns(3)
    
    with col1:
        knowledge_mcp_enabled = st.checkbox(
            "Enable Knowledge MCP",
            value=gateways_config.get("knowledge_mcp", {}).get("enabled", True),
            help="Enable Knowledge MCP Gateway",
            key="gateway_knowledge_mcp_enabled"
        )
    
    with col2:
        knowledge_mcp_timeout = st.number_input(
            "Knowledge MCP Timeout (seconds)",
            value=gateways_config.get("knowledge_mcp", {}).get("timeout", 30.0),
            min_value=5.0,
            max_value=300.0,
            step=5.0,
            help="Knowledge MCP Gateway timeout"
        )
    
    with col3:
        knowledge_mcp_retries = st.number_input(
            "Knowledge MCP Retry Attempts",
            value=gateways_config.get("knowledge_mcp", {}).get("retry_attempts", 3),
            min_value=0,
            max_value=10,
            help="Knowledge MCP Gateway retry attempts"
        )

    # Save core gateways configuration
    if st.button("💾 Save Core Gateways Configuration", type="primary"):
        try:
            # Update settings
            if "gateways" not in current_settings:
                current_settings["gateways"] = {}

            current_settings["gateways"]["corporate_llm"] = {
                "enabled": corp_llm_enabled,
                "timeout": corp_llm_timeout,
                "retry_attempts": corp_llm_retries
            }

            current_settings["gateways"]["ai_processing"] = {
                "enabled": ai_proc_enabled,
                "timeout": ai_proc_timeout,
                "retry_attempts": ai_proc_retries
            }

            current_settings["gateways"]["workflow_optimizer"] = {
                "enabled": workflow_opt_enabled,
                "timeout": workflow_opt_timeout,
                "retry_attempts": workflow_opt_retries
            }

            current_settings["gateways"]["knowledge_mcp"] = {
                "enabled": knowledge_mcp_enabled,
                "timeout": knowledge_mcp_timeout,
                "retry_attempts": knowledge_mcp_retries
            }

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ Core gateways configuration saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving core gateways configuration: {e}")

def render_system_paths_config(current_settings: Dict[str, Any], settings_path: Path):
    """Render system paths configuration."""
    st.markdown("#### 📁 System Paths Configuration")

    system_config = current_settings.get("system", {})

    st.info("""
    **Configure system paths and root folder detection.**

    These paths determine where TidyLLM stores configuration, data, logs, and other files.
    """)

    col1, col2 = st.columns(2)

    with col1:
        # Root path configuration
        st.markdown("##### 🏠 Root Path Settings")
        
        root_path = st.text_input(
            "Root Path",
            value=system_config.get("root_path", "C:\\Users\\marti\\github"),
            help="Base path for all TidyLLM operations"
        )

        auto_detect_root = st.checkbox(
            "Auto-detect Root Path",
            value=system_config.get("auto_detect_root_path", True),
            help="Automatically detect the root path",
            key="system_auto_detect_root"
        )

        corporate_mode = st.checkbox(
            "Corporate Mode",
            value=system_config.get("corporate_mode", False),
            help="Enable corporate environment settings",
            key="system_corporate_mode"
        )

        deep_folder_support = st.checkbox(
            "Deep Folder Support",
            value=system_config.get("deep_folder_support", True),
            help="Support for deep corporate folder structures",
            key="system_deep_folder_support"
        )

    with col2:
        # Folder configurations
        st.markdown("##### 📂 Folder Configurations")
        
        config_folder = st.text_input(
            "Config Folder",
            value=system_config.get("config_folder", "tidyllm/admin"),
            help="Configuration files folder"
        )

        data_folder = st.text_input(
            "Data Folder",
            value=system_config.get("data_folder", "tidyllm/data"),
            help="Data storage folder"
        )

        logs_folder = st.text_input(
            "Logs Folder",
            value=system_config.get("logs_folder", "tidyllm/logs"),
            help="Log files folder"
        )

        onboarding_folder = st.text_input(
            "Onboarding Folder",
            value=system_config.get("onboarding_folder", "onboarding"),
            help="Onboarding system folder"
        )

        temp_folder = st.text_input(
            "Temp Folder",
            value=system_config.get("temp_folder", "tidyllm/temp"),
            help="Temporary files folder"
        )

        cache_folder = st.text_input(
            "Cache Folder",
            value=system_config.get("cache_folder", "tidyllm/cache"),
            help="Cache files folder"
        )

    # Path testing
    st.markdown("##### 🧪 Path Testing")
    
    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("🧪 Test Root Path"):
            if root_path:
                with st.spinner("Testing root path..."):
                    try:
                        test_root_path(root_path)
                        st.success("✅ Root path is accessible!")
                    except Exception as e:
                        st.error(f"❌ Root path test failed: {e}")
            else:
                st.warning("⚠️ Please enter root path")

    with col2:
        if st.button("📁 Create Folders"):
            with st.spinner("Creating system folders..."):
                try:
                    create_system_folders(root_path, config_folder, data_folder, logs_folder, temp_folder, cache_folder)
                    st.success("✅ System folders created!")
                except Exception as e:
                    st.error(f"❌ Folder creation failed: {e}")

    with col3:
        if st.button("🔍 Auto-detect Paths"):
            with st.spinner("Auto-detecting paths..."):
                try:
                    detected_paths = auto_detect_paths()
                    st.success("✅ Paths auto-detected!")
                    st.json(detected_paths)
                except Exception as e:
                    st.error(f"❌ Auto-detection failed: {e}")

    # Save system paths configuration
    if st.button("💾 Save System Paths Configuration", type="primary"):
        try:
            # Update settings
            if "system" not in current_settings:
                current_settings["system"] = {}

            current_settings["system"]["root_path"] = root_path
            current_settings["system"]["auto_detect_root_path"] = auto_detect_root
            current_settings["system"]["corporate_mode"] = corporate_mode
            current_settings["system"]["deep_folder_support"] = deep_folder_support
            current_settings["system"]["config_folder"] = config_folder
            current_settings["system"]["data_folder"] = data_folder
            current_settings["system"]["logs_folder"] = logs_folder
            current_settings["system"]["onboarding_folder"] = onboarding_folder
            current_settings["system"]["temp_folder"] = temp_folder
            current_settings["system"]["cache_folder"] = cache_folder

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ System paths configuration saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving system paths configuration: {e}")

def render_onboarding_settings_config(current_settings: Dict[str, Any], settings_path: Path):
    """Render onboarding settings configuration."""
    st.markdown("#### ⚙️ Onboarding Settings Configuration")

    onboarding_config = current_settings.get("onboarding", {})

    col1, col2 = st.columns(2)

    with col1:
        auto_detect_root = st.checkbox(
            "Auto-detect Root Path",
            value=onboarding_config.get("auto_detect_root_path", True),
            help="Automatically detect root path during onboarding",
            key="onboarding_auto_detect_root"
        )

        show_debug_info = st.checkbox(
            "Show Debug Info",
            value=onboarding_config.get("show_debug_info", False),
            help="Show debug information in onboarding UI",
            key="onboarding_show_debug_info"
        )

        enable_health_checks = st.checkbox(
            "Enable Health Checks",
            value=onboarding_config.get("enable_health_checks", True),
            help="Enable health check endpoints",
            key="onboarding_enable_health_checks"
        )

    with col2:
        refresh_interval = st.number_input(
            "Refresh Interval (seconds)",
            value=onboarding_config.get("refresh_interval", 5),
            min_value=1,
            max_value=60,
            help="UI refresh interval in seconds"
        )

        max_retry_attempts = st.number_input(
            "Max Retry Attempts",
            value=onboarding_config.get("max_retry_attempts", 3),
            min_value=1,
            max_value=10,
            help="Maximum retry attempts for operations"
        )

    # Save onboarding settings configuration
    if st.button("💾 Save Onboarding Settings", type="primary"):
        try:
            # Update settings
            if "onboarding" not in current_settings:
                current_settings["onboarding"] = {}

            current_settings["onboarding"]["auto_detect_root_path"] = auto_detect_root
            current_settings["onboarding"]["show_debug_info"] = show_debug_info
            current_settings["onboarding"]["enable_health_checks"] = enable_health_checks
            current_settings["onboarding"]["refresh_interval"] = refresh_interval
            current_settings["onboarding"]["max_retry_attempts"] = max_retry_attempts

            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)

            st.success("✅ Onboarding settings saved successfully!")
            st.rerun()

        except Exception as e:
            st.error(f"❌ Error saving onboarding settings: {e}")

def test_root_path(root_path: str):
    """Test if root path is accessible."""
    try:
        import os
        if os.path.exists(root_path) and os.access(root_path, os.R_OK):
            return True
        else:
            raise Exception(f"Path '{root_path}' is not accessible")
    except Exception as e:
        raise Exception(f"Root path test failed: {str(e)}")

def create_system_folders(root_path: str, config_folder: str, data_folder: str, logs_folder: str, temp_folder: str, cache_folder: str):
    """Create system folders."""
    try:
        import os
        folders = [config_folder, data_folder, logs_folder, temp_folder, cache_folder]
        for folder in folders:
            full_path = os.path.join(root_path, folder)
            os.makedirs(full_path, exist_ok=True)
        return True
    except Exception as e:
        raise Exception(f"Folder creation failed: {str(e)}")

def auto_detect_paths():
    """Auto-detect system paths."""
    try:
        import os
        current_dir = os.getcwd()
        return {
            "detected_root": current_dir,
            "config_folder": "tidyllm/admin",
            "data_folder": "tidyllm/data",
            "logs_folder": "tidyllm/logs",
            "onboarding_folder": "onboarding",
            "temp_folder": "tidyllm/temp",
            "cache_folder": "tidyllm/cache"
        }
    except Exception as e:
        raise Exception(f"Auto-detection failed: {str(e)}")

def render_workflow_setup_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow configuration tab."""
    st.markdown("### ⚙️ Workflow Configuration")
    
    st.info("""
    **Configure workflow optimization settings and files.**
    
    Required for: Workflow analysis, optimization, and management
    - **Workflow Files**: Multiple workflow definition files
    - **Dashboard Integration**: Link to workflow dashboard
    - **Optimization Settings**: Performance and analysis configuration
    """)
    
    # Workflow configuration tabs
    wf_tab1, wf_tab2, wf_tab3, wf_tab4 = st.tabs([
        "📁 Workflow Files", 
        "📊 Dashboard Integration", 
        "⚙️ Optimization Settings", 
        "🔧 Advanced Configuration"
    ])
    
    with wf_tab1:
        render_workflow_files_tab(current_settings, settings_path)
    
    with wf_tab2:
        render_workflow_dashboard_tab(current_settings, settings_path)
    
    with wf_tab3:
        render_workflow_optimization_tab(current_settings, settings_path)
    
    with wf_tab4:
        render_workflow_advanced_tab(current_settings, settings_path)

def render_workflow_files_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow files configuration."""
    st.markdown("#### 📁 Workflow Files Configuration")
    
    st.info("""
    **Configure multiple workflow definition files.**
    
    Workflow files define the structure and logic of your business processes.
    """)
    
    # Get current workflow files config
    workflow_files = current_settings.get("workflow_files", {})
    
    # Workflow file types
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("##### 📋 Core Workflow Files")
        
        # Main workflow file
        main_workflow = st.text_input(
            "Main Workflow File",
            value=workflow_files.get("main", "workflows/main_workflow.yaml"),
            help="Primary workflow definition file"
        )
        
        # Business process workflows
        business_workflows = st.text_area(
            "Business Process Workflows",
            value="\n".join(workflow_files.get("business", [])),
            help="List of business process workflow files (one per line)",
            height=100
        )
        
        # AI workflow files
        ai_workflows = st.text_area(
            "AI Workflow Files",
            value="\n".join(workflow_files.get("ai", [])),
            help="List of AI-specific workflow files (one per line)",
            height=100
        )
    
    with col2:
        st.markdown("##### 🔄 Integration Workflow Files")
        
        # Integration workflows
        integration_workflows = st.text_area(
            "Integration Workflows",
            value="\n".join(workflow_files.get("integration", [])),
            help="List of integration workflow files (one per line)",
            height=100
        )
        
        # Custom workflows
        custom_workflows = st.text_area(
            "Custom Workflows",
            value="\n".join(workflow_files.get("custom", [])),
            help="List of custom workflow files (one per line)",
            height=100
        )
        
        # Workflow templates
        workflow_templates = st.text_input(
            "Workflow Templates Directory",
            value=workflow_files.get("templates", "workflows/templates/"),
            help="Directory containing workflow templates"
        )
    
    # Workflow file management
    st.markdown("##### 🛠️ Workflow File Management")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📁 Create Workflow Directory"):
            try:
                import os
                workflow_dir = "workflows"
                os.makedirs(workflow_dir, exist_ok=True)
                os.makedirs(f"{workflow_dir}/templates", exist_ok=True)
                os.makedirs(f"{workflow_dir}/business", exist_ok=True)
                os.makedirs(f"{workflow_dir}/ai", exist_ok=True)
                os.makedirs(f"{workflow_dir}/integration", exist_ok=True)
                st.success("✅ Workflow directories created!")
            except Exception as e:
                st.error(f"❌ Error creating directories: {e}")
    
    with col2:
        if st.button("📋 Generate Sample Workflows"):
            try:
                generate_sample_workflows()
                st.success("✅ Sample workflows generated!")
            except Exception as e:
                st.error(f"❌ Error generating workflows: {e}")
    
    with col3:
        if st.button("🧪 Validate Workflow Files"):
            try:
                result = validate_workflow_files(workflow_files)
                if result.get("valid", False):
                    st.success("✅ Workflow files validated!")
                    st.info(f"Validated {result.get('total_workflows', 0)} workflow files")
                else:
                    st.error("❌ Workflow validation failed!")
                    if "error" in result:
                        st.error(f"Error: {result['error']}")
                    if "results" in result:
                        for workflow_result in result["results"]:
                            if workflow_result["status"] == "error":
                                st.error(f"❌ {workflow_result['workflow']}: {workflow_result['message']}")
                            else:
                                st.success(f"✅ {workflow_result['workflow']}: {workflow_result['message']}")
            except Exception as e:
                st.error(f"❌ Error validating workflows: {e}")
    
    # Save workflow files configuration
    if st.button("💾 Save Workflow Files Configuration", type="primary"):
        try:
            # Update settings
            if "workflow_files" not in current_settings:
                current_settings["workflow_files"] = {}
            
            current_settings["workflow_files"]["main"] = main_workflow
            current_settings["workflow_files"]["business"] = [f.strip() for f in business_workflows.split('\n') if f.strip()]
            current_settings["workflow_files"]["ai"] = [f.strip() for f in ai_workflows.split('\n') if f.strip()]
            current_settings["workflow_files"]["integration"] = [f.strip() for f in integration_workflows.split('\n') if f.strip()]
            current_settings["workflow_files"]["custom"] = [f.strip() for f in custom_workflows.split('\n') if f.strip()]
            current_settings["workflow_files"]["templates"] = workflow_templates
            
            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
            
            st.success("✅ Workflow files configuration saved successfully!")
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ Error saving workflow files configuration: {e}")

def render_workflow_dashboard_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow dashboard integration."""
    st.markdown("#### 📊 Workflow Dashboard Integration")
    
    st.info("""
    **Configure workflow dashboard and monitoring.**
    
    Link to your workflow dashboard for real-time monitoring and management.
    """)
    
    # Get current dashboard config
    dashboard_config = current_settings.get("workflow_dashboard", {})
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("##### 🌐 Dashboard Configuration")
        
        # Dashboard URL
        dashboard_url = st.text_input(
            "Dashboard URL",
            value=dashboard_config.get("url", "http://localhost:8502"),
            help="URL of the workflow dashboard"
        )
        
        # Dashboard port
        dashboard_port = st.number_input(
            "Dashboard Port",
            value=dashboard_config.get("port", 8502),
            min_value=1000,
            max_value=65535,
            help="Port for the workflow dashboard"
        )
        
        # Dashboard authentication
        dashboard_auth = st.checkbox(
            "Enable Dashboard Authentication",
            value=dashboard_config.get("auth_enabled", False),
            help="Enable authentication for dashboard access"
        )
        
        # Dashboard refresh interval
        refresh_interval = st.number_input(
            "Refresh Interval (seconds)",
            value=dashboard_config.get("refresh_interval", 30),
            min_value=5,
            max_value=300,
            help="Dashboard refresh interval in seconds"
        )
    
    with col2:
        st.markdown("##### 📈 Monitoring Configuration")
        
        # Real-time monitoring
        realtime_monitoring = st.checkbox(
            "Enable Real-time Monitoring",
            value=dashboard_config.get("realtime_monitoring", True),
            help="Enable real-time workflow monitoring"
        )
        
        # Performance metrics
        performance_metrics = st.checkbox(
            "Enable Performance Metrics",
            value=dashboard_config.get("performance_metrics", True),
            help="Enable performance metrics collection"
        )
        
        # Alert notifications
        alert_notifications = st.checkbox(
            "Enable Alert Notifications",
            value=dashboard_config.get("alert_notifications", True),
            help="Enable alert notifications for workflow issues"
        )
        
        # Data retention
        data_retention = st.number_input(
            "Data Retention (days)",
            value=dashboard_config.get("data_retention_days", 30),
            min_value=1,
            max_value=365,
            help="Data retention period in days"
        )
    
    # Dashboard actions
    st.markdown("##### 🚀 Dashboard Actions")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 Launch Dashboard"):
            try:
                result = launch_workflow_dashboard(dashboard_config)
                if result.get("status") == "success":
                    st.success("✅ Workflow dashboard launched!")
                    st.info(f"Dashboard URL: {result.get('url')}")
                    st.info(f"Process ID: {result.get('process_id')}")
                else:
                    st.error("❌ Dashboard launch failed!")
                    st.error(f"Error: {result.get('message', 'Unknown error')}")
            except Exception as e:
                st.error(f"❌ Error launching dashboard: {e}")
    
    with col2:
        if st.button("🔗 Open Dashboard"):
            try:
                import webbrowser
                webbrowser.open(dashboard_url)
                st.success("✅ Dashboard opened in browser!")
            except Exception as e:
                st.error(f"❌ Error opening dashboard: {e}")
    
    with col3:
        if st.button("🧪 Test Dashboard Connection"):
            try:
                result = test_dashboard_connection(dashboard_url)
                if result.get("status") == "success":
                    st.success("✅ Dashboard connection successful!")
                    st.info(f"Response code: {result.get('response_code')}")
                elif result.get("status") == "warning":
                    st.warning("⚠️ Dashboard connection warning!")
                    st.warning(f"Warning: {result.get('message')}")
                else:
                    st.error("❌ Dashboard connection failed!")
                    st.error(f"Error: {result.get('message', 'Unknown error')}")
            except Exception as e:
                st.error(f"❌ Dashboard connection failed: {e}")
    
    # Save dashboard configuration
    if st.button("💾 Save Dashboard Configuration", type="primary"):
        try:
            # Update settings
            if "workflow_dashboard" not in current_settings:
                current_settings["workflow_dashboard"] = {}
            
            current_settings["workflow_dashboard"]["url"] = dashboard_url
            current_settings["workflow_dashboard"]["port"] = dashboard_port
            current_settings["workflow_dashboard"]["auth_enabled"] = dashboard_auth
            current_settings["workflow_dashboard"]["refresh_interval"] = refresh_interval
            current_settings["workflow_dashboard"]["realtime_monitoring"] = realtime_monitoring
            current_settings["workflow_dashboard"]["performance_metrics"] = performance_metrics
            current_settings["workflow_dashboard"]["alert_notifications"] = alert_notifications
            current_settings["workflow_dashboard"]["data_retention_days"] = data_retention
            
            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
            
            st.success("✅ Dashboard configuration saved successfully!")
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ Error saving dashboard configuration: {e}")

def render_workflow_optimization_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow optimization settings."""
    st.markdown("#### ⚙️ Workflow Optimization Settings")
    
    st.info("""
    **Configure workflow optimization and performance settings.**
    
    Optimize workflow execution and analysis performance.
    """)
    
    # Get current workflow config
    workflow_config = current_settings.get("workflow_optimizer", {})
    
    col1, col2 = st.columns(2)
    
    with col1:
        workflow_enabled = st.checkbox(
            "Enable Workflow Optimizer",
            value=workflow_config.get("enabled", True),
            help="Enable workflow optimization features"
        )
        
        analysis_mode = st.selectbox(
            "Analysis Mode",
            options=["full", "analysis_only", "monitoring_only"],
            index=1 if workflow_config.get("analysis_mode", "analysis_only") == "analysis_only" else 0,
            help="Workflow analysis mode"
        )
        
        max_workers = st.number_input(
            "Maximum Workers",
            value=workflow_config.get("max_workers", 4),
            min_value=1,
            max_value=16,
            help="Maximum number of workflow workers"
        )
    
    with col2:
        cache_size = st.number_input(
            "Cache Size (MB)",
            value=workflow_config.get("cache_size_mb", 100),
            min_value=10,
            max_value=1000,
            help="Workflow cache size in megabytes"
        )
        
        timeout_seconds = st.number_input(
            "Timeout (seconds)",
            value=workflow_config.get("timeout_seconds", 300),
            min_value=30,
            max_value=3600,
            help="Workflow operation timeout"
        )
        
        retry_attempts = st.number_input(
            "Retry Attempts",
            value=workflow_config.get("retry_attempts", 3),
            min_value=0,
            max_value=10,
            help="Number of retry attempts for failed operations"
        )
    
    # Save workflow optimization configuration
    if st.button("💾 Save Workflow Optimization", type="primary"):
        try:
            # Update settings
            if "workflow_optimizer" not in current_settings:
                current_settings["workflow_optimizer"] = {}
            
            current_settings["workflow_optimizer"]["enabled"] = workflow_enabled
            current_settings["workflow_optimizer"]["analysis_mode"] = analysis_mode
            current_settings["workflow_optimizer"]["max_workers"] = max_workers
            current_settings["workflow_optimizer"]["cache_size_mb"] = cache_size
            current_settings["workflow_optimizer"]["timeout_seconds"] = timeout_seconds
            current_settings["workflow_optimizer"]["retry_attempts"] = retry_attempts
            
            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
            
            st.success("✅ Workflow optimization saved successfully!")
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ Error saving workflow optimization: {e}")

def render_workflow_advanced_tab(current_settings: Dict[str, Any], settings_path: Path):
    """Render advanced workflow configuration."""
    st.markdown("#### 🔧 Advanced Workflow Configuration")
    
    st.info("""
    **Advanced workflow configuration options.**
    
    Configure advanced features and integrations.
    """)
    
    # Get current advanced config
    advanced_config = current_settings.get("workflow_advanced", {})
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("##### 🔄 Integration Settings")
        
        # API integration
        api_integration = st.checkbox(
            "Enable API Integration",
            value=advanced_config.get("api_integration", True),
            help="Enable API integration for workflows"
        )
        
        # Webhook support
        webhook_support = st.checkbox(
            "Enable Webhook Support",
            value=advanced_config.get("webhook_support", False),
            help="Enable webhook support for workflow events"
        )
        
        # External system integration
        external_integration = st.checkbox(
            "Enable External System Integration",
            value=advanced_config.get("external_integration", False),
            help="Enable integration with external systems"
        )
    
    with col2:
        st.markdown("##### 🛡️ Security Settings")
        
        # Workflow encryption
        workflow_encryption = st.checkbox(
            "Enable Workflow Encryption",
            value=advanced_config.get("workflow_encryption", True),
            help="Enable encryption for workflow data"
        )
        
        # Access control
        access_control = st.checkbox(
            "Enable Access Control",
            value=advanced_config.get("access_control", True),
            help="Enable role-based access control"
        )
        
        # Audit logging
        audit_logging = st.checkbox(
            "Enable Audit Logging",
            value=advanced_config.get("audit_logging", True),
            help="Enable comprehensive audit logging"
        )
    
    # Save advanced configuration
    if st.button("💾 Save Advanced Configuration", type="primary"):
        try:
            # Update settings
            if "workflow_advanced" not in current_settings:
                current_settings["workflow_advanced"] = {}
            
            current_settings["workflow_advanced"]["api_integration"] = api_integration
            current_settings["workflow_advanced"]["webhook_support"] = webhook_support
            current_settings["workflow_advanced"]["external_integration"] = external_integration
            current_settings["workflow_advanced"]["workflow_encryption"] = workflow_encryption
            current_settings["workflow_advanced"]["access_control"] = access_control
            current_settings["workflow_advanced"]["audit_logging"] = audit_logging
            
            # Save to file
            with open(settings_path, 'w') as f:
                yaml.dump(current_settings, f, default_flow_style=False, sort_keys=False)
            
            st.success("✅ Advanced configuration saved successfully!")
            st.rerun()
            
        except Exception as e:
            st.error(f"❌ Error saving advanced configuration: {e}")

# Helper functions for workflow management
def generate_sample_workflows():
    """Generate sample workflow files."""
    import os
    import yaml
    
    # Create sample workflows
    sample_workflows = {
        "main_workflow.yaml": {
            "name": "Main Business Workflow",
            "description": "Primary business process workflow",
            "steps": [
                {"name": "data_input", "type": "input", "required": True},
                {"name": "data_processing", "type": "process", "required": True},
                {"name": "data_output", "type": "output", "required": True}
            ]
        },
        "ai_workflow.yaml": {
            "name": "AI Processing Workflow",
            "description": "AI-powered data processing workflow",
            "steps": [
                {"name": "ai_input", "type": "ai_input", "required": True},
                {"name": "ai_processing", "type": "ai_process", "required": True},
                {"name": "ai_output", "type": "ai_output", "required": True}
            ]
        }
    }
    
    # Write sample workflows
    for filename, content in sample_workflows.items():
        with open(f"workflows/{filename}", 'w') as f:
            yaml.dump(content, f, default_flow_style=False)

def validate_workflow_files(workflow_files):
    """Validate workflow files using TidyLLM workflow system."""
    try:
        from tidyllm.workflow_optimizer import HierarchicalDAGManager
        from pathlib import Path
        
        # Get extended session manager with MLflow support
        session_manager = st.session_state.get('tidyllm_session_manager')
        
        # Create DAG manager for validation
        dag_manager = HierarchicalDAGManager(session_manager=session_manager)
        
        validation_results = []
        
        # workflow_files is a dict from current_settings.get("workflow_files", {})
        for workflow_name, workflow_config in workflow_files.items():
            try:
                # Check if workflow file exists and is accessible
                workflow_path = workflow_config.get("path", "")
                if workflow_path and Path(workflow_path).exists():
                    # Basic file validation
                    validation_results.append({
                        "workflow": workflow_name,
                        "status": "valid",
                        "message": f"Workflow file exists and is accessible: {workflow_path}",
                        "path": workflow_path
                    })
                else:
                    validation_results.append({
                        "workflow": workflow_name,
                        "status": "error", 
                        "message": f"Workflow file not found: {workflow_path}",
                        "path": workflow_path
                    })
            except Exception as e:
                validation_results.append({
                    "workflow": workflow_name,
                    "status": "error",
                    "message": f"Validation failed: {str(e)}"
                })
        
        return {
            "valid": all(r["status"] == "valid" for r in validation_results),
            "results": validation_results,
            "total_workflows": len(workflow_files)
        }
        
    except ImportError as e:
        return {
            "valid": False,
            "error": f"TidyLLM workflow system not available: {e}",
            "fallback": "Basic file validation only"
        }

def launch_workflow_dashboard(dashboard_config):
    """Launch workflow dashboard using TidyLLM web dashboard system."""
    try:
        import subprocess
        import sys
        from pathlib import Path
        
        # dashboard_config is a dict from current_settings.get("workflow_dashboard", {})
        dashboard_url = dashboard_config.get("url", "http://localhost:8502")
        dashboard_port = dashboard_config.get("port", 8502)
        
        # Check if TidyLLM dashboard exists
        tidyllm_dashboard_path = Path("tidyllm/web/ai_dropzone_dashboard.py")
        
        if tidyllm_dashboard_path.exists():
            try:
                # Launch TidyLLM dashboard
                dashboard_process = subprocess.Popen([
                    sys.executable, "-m", "streamlit", "run", 
                    str(tidyllm_dashboard_path),
                    "--server.port", str(dashboard_port),
                    "--server.address", "0.0.0.0"
                ])
                
                return {
                    "status": "success",
                    "message": f"TidyLLM Dashboard launched on {dashboard_url}",
                    "process_id": dashboard_process.pid,
                    "url": dashboard_url,
                    "port": dashboard_port
                }
                
            except Exception as launch_error:
                return {
                    "status": "error", 
                    "message": f"Failed to launch TidyLLM dashboard: {launch_error}"
                }
        else:
            return {
                "status": "error",
                "message": "TidyLLM dashboard not found at tidyllm/web/ai_dropzone_dashboard.py",
                "fallback": "Manual dashboard launch required"
            }
            
    except Exception as e:
        return {
            "status": "error",
            "message": f"Dashboard launch failed: {e}"
        }

def test_dashboard_connection(dashboard_url):
    """Test dashboard connection using HTTP requests."""
    try:
        import requests
        
        # dashboard_url is a string from the text input field
        if not dashboard_url:
            return {
                "status": "error",
                "message": "Dashboard URL is required"
            }
        
        # Test basic connectivity
        try:
            # Try to connect to the dashboard
            response = requests.get(f"{dashboard_url}/health", timeout=5)
            
            if response.status_code == 200:
                return {
                    "status": "success",
                    "message": "Dashboard is accessible and responding",
                    "response_code": response.status_code,
                    "url": dashboard_url
                }
            else:
                return {
                    "status": "warning",
                    "message": f"Dashboard responded with status {response.status_code}",
                    "response_code": response.status_code,
                    "url": dashboard_url
                }
                
        except requests.exceptions.ConnectionError:
            return {
                "status": "error",
                "message": f"Could not connect to dashboard at {dashboard_url}",
                "url": dashboard_url
            }
        except requests.exceptions.Timeout:
            return {
                "status": "error", 
                "message": f"Dashboard connection timed out: {dashboard_url}",
                "url": dashboard_url
            }
        except requests.exceptions.RequestException as e:
            return {
                "status": "error",
                "message": f"Dashboard connection failed: {str(e)}",
                "url": dashboard_url
            }
            
    except ImportError:
        return {
            "status": "error",
            "message": "requests library not available for connection testing",
            "fallback": "Manual connection test required"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Connection test failed: {e}"
        }


def render_system_initialization_tab():
    """Render system initialization tab."""
    st.markdown("### 🚀 System Initialization")
    
    st.info("""
    **Initialize and start all TidyLLM services.**
    
    This will start all configured services and make them available for use.
    """)
    
    # Real-time system status
    st.markdown("#### 📊 System Status")
    
    # Check current system status
    try:
        from tidyllm.gateways.gateway_registry import get_global_registry
        
        # Get extended session manager with MLflow support
        session_manager = st.session_state.get('tidyllm_session_manager')
        registry = get_global_registry()
        
        # Display session manager status
        if session_manager:
            st.success("✅ UnifiedSessionManager: Active")
            
            # Test AWS connectivity
            try:
                s3_client = session_manager.get_s3_client()
                st.success("✅ AWS S3: Connected")
            except Exception as e:
                st.error(f"❌ AWS S3: {str(e)[:50]}...")
            
            # Test database connectivity
            try:
                postgres_conn = session_manager.get_postgres_connection()
                st.success("✅ PostgreSQL: Connected")
            except Exception as e:
                st.error(f"❌ PostgreSQL: {str(e)[:50]}...")
        else:
            st.error("❌ UnifiedSessionManager: Not initialized")
        
        # Display gateway registry status
        if registry:
            st.success("✅ GatewayRegistry: Active")
            
            # List available services
            services = registry.list_services()
            if services:
                st.info(f"📋 Available Services: {len(services)}")
                for service in services[:5]:  # Show first 5
                    status = "✅" if service['initialized'] else "❌"
                    st.write(f"{status} {service['service_class']}")
                if len(services) > 5:
                    st.info(f"... and {len(services) - 5} more services")
            else:
                st.warning("⚠️ No services registered")
        else:
            st.error("❌ GatewayRegistry: Not available")
            
    except ImportError as e:
        st.error(f"❌ TidyLLM system not available: {e}")
    except Exception as e:
        st.error(f"❌ System status check failed: {e}")
    
    st.markdown("---")
    
    # System initialization controls
    st.markdown("#### 🚀 Initialize System")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🚀 Initialize TidyLLM System", type="primary", use_container_width=True):
            with st.spinner("Initializing TidyLLM UnifiedSessionManager..."):
                try:
                    # Use REAL TidyLLM UnifiedSessionManager with MLflow extension - NO FAKE STUFF
                    # Get the extended session manager with MLflow support
                    session_manager = st.session_state.get('tidyllm_session_manager')
                    
                    if session_manager:
                        # Test that it actually works by trying to get AWS client
                        try:
                            s3_client = session_manager.get_s3_client()
                            postgres_conn = session_manager.get_postgres_connection()
                            
                            st.success("✅ TidyLLM UnifiedSessionManager initialized successfully!")
                            st.info("🎉 **Real TidyLLM system is now ready for use!**")
                            st.info("📊 AWS and Database clients are operational")
                            
                            # 🎈 Balloon celebration when all services are ready!
                            st.balloons()
                        except Exception as client_error:
                            st.success("✅ TidyLLM UnifiedSessionManager initialized")
                            st.warning(f"⚠️ Some services may not be configured: {client_error}")
                    else:
                        st.error("❌ Failed to initialize UnifiedSessionManager")
                except Exception as e:
                    st.error(f"❌ Error initializing TidyLLM system: {e}")
                    st.error("Make sure tidyllm package is properly installed")
    
    with col2:
        if st.button("🧪 Test All Connections", use_container_width=True):
            with st.spinner("Testing all connections..."):
                try:
                    from old_core.validator import OnboardingValidator
                    validator = OnboardingValidator()
                    
                    # Test AWS
                    aws_results = validator.validate_aws_connectivity()
                    st.session_state.aws_test_results = aws_results
                    
                    # Test database
                    try:
                        db_results = validator.validate_database_connectivity()
                        st.session_state.db_test_results = db_results
                    except Exception:
                        pass  # Database test is optional
                    
                    # Test MLflow
                    try:
                        mlflow_results = validator.validate_mlflow_integration()
                        st.session_state.mlflow_test_results = mlflow_results
                    except Exception:
                        pass  # MLflow test is optional
                    
                    # Test gateways
                    try:
                        gateway_results = validator.validate_gateways()
                        st.session_state.gateway_test_results = gateway_results
                    except Exception:
                        pass  # Gateway test is optional
                    
                    st.success("✅ All connection tests completed!")
                    
                except Exception as e:
                    st.error(f"❌ Connection test failed: {e}")
    
    # Display test results
    if hasattr(st.session_state, 'aws_test_results'):
        display_test_results("AWS Services", st.session_state.aws_test_results)
    
    if hasattr(st.session_state, 'db_test_results'):
        display_test_results("Database", st.session_state.db_test_results)
    
    if hasattr(st.session_state, 'mlflow_test_results'):
        display_test_results("MLflow Integration", st.session_state.mlflow_test_results)
    
    if hasattr(st.session_state, 'gateway_test_results'):
        display_test_results("TidyLLM Gateways", st.session_state.gateway_test_results)

def display_test_results(title: str, results: Dict[str, Any]):
    """Display test results in a formatted way with tiered support."""
    st.markdown(f"#### 📊 {title} Test Results")
    
    if isinstance(results, dict):
        for service, result in results.items():
            if isinstance(result, dict):
                # Handle tiered results (S3, Database, MLflow with primary/secondary/backup)
                if 'primary' in result or 'secondary' in result or 'backup' in result:
                    overall_status = result.get("status", "unknown")
                    overall_message = result.get("message", "No overall message")
                    
                    # Show overall status first
                    if overall_status == "success":
                        st.success(f"✅ **{service}**: {overall_message}")
                    elif overall_status == "not_configured":
                        st.info(f"ℹ️ **{service}**: {overall_message}")
                    else:
                        st.error(f"❌ **{service}**: {overall_message}")
                    
                    # Show tier details in an expander
                    with st.expander(f"📋 {service} Tier Details"):
                        for tier in ['primary', 'secondary', 'backup']:
                            if tier in result:
                                tier_result = result[tier]
                                tier_status = tier_result.get("status", "unknown")
                                tier_message = tier_result.get("message", "No message")
                                
                                if tier_status == "success":
                                    st.success(f"✅ {tier.title()} tier: {tier_message}")
                                elif tier_status == "not_configured":
                                    st.info(f"ℹ️ {tier.title()} tier: {tier_message}")
                                elif tier_status == "corporate_restricted":
                                    st.warning(f"⚠️ {tier.title()} tier: {tier_message}")
                                else:
                                    st.error(f"❌ {tier.title()} tier: {tier_message}")
                else:
                    # Handle non-tiered results (STS, Bedrock, etc.)
                    status = result.get("status", "unknown")
                    message = result.get("message", "No message")
                    
                    if status == "success":
                        st.success(f"✅ **{service}**: {message}")
                    elif status == "corporate_restricted":
                        st.warning(f"⚠️ **{service}**: {message}")
                    elif status == "not_configured":
                        st.info(f"ℹ️ **{service}**: {message}")
                    elif status == "permission_error":
                        st.error(f"❌ **{service}**: {message}")
                    else:
                        st.error(f"❌ **{service}**: {message}")
            else:
                st.info(f"ℹ️ {service}: {result}")
    else:
        st.info(f"ℹ️ {title}: {results}")


def render_enhanced_template_workflow(current_settings: Dict[str, Any], settings_path: Path, template_choice: str):
    """Render enhanced template workflow using proposed_settings.yaml."""
    
    st.markdown("#### 🛠️ Deploy Environment Template")
    
    try:
        from old_core.settings_template_manager import get_template_manager, quick_deploy_environment
        manager = get_template_manager()
        
        # Show current status
        status = manager.get_environment_status()
        
        if status["current_settings_exists"]:
            current_env = status.get("current_environment", "unknown")
            st.info(f"**Current Environment**: {current_env}")
        
        # Preview template
        if st.button("🔍 Preview Template", key="preview_enhanced"):
            with st.spinner(f"Generating {template_choice} template..."):
                try:
                    template = manager.create_environment_template(template_choice)
                    
                    st.markdown("#### 📋 Template Preview")
                    
                    # Show key sections
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown("**Environment Settings:**")
                        env_info = {
                            "Environment": template.get("system", {}).get("environment"),
                            "Deployment Mode": template.get("deployment", {}).get("mode"),
                            "S3 Prefix": template.get("services", {}).get("s3", {}).get("prefix"),
                            "Log Level": template.get("operations", {}).get("logging", {}).get("level")
                        }
                        for key, value in env_info.items():
                            if value:
                                st.write(f"- {key}: `{value}`")
                    
                    with col2:
                        st.markdown("**Configuration Info:**")
                        config_info = template.get("configuration", {})
                        st.write(f"- Version: `{config_info.get('version')}`")
                        st.write(f"- Generated From: `{config_info.get('generated_from')}`")
                        st.write(f"- Environment: `{config_info.get('environment')}`")
                    
                    # Show template validation
                    validation = manager.validate_template(template)
                    if validation["valid"]:
                        st.success("✅ Template validation passed")
                    else:
                        st.error(f"❌ Template validation failed: {', '.join(validation['errors'])}")
                    
                    if validation["warnings"]:
                        for warning in validation["warnings"]:
                            st.warning(f"⚠️ {warning}")
                    
                    # Option to show full template
                    if st.checkbox("Show Full Template", key="show_full_enhanced"):
                        st.json(template)
                        
                except Exception as e:
                    st.error(f"❌ Error generating template: {e}")
        
        # Deploy template
        st.markdown("#### 🚀 Deploy Template")
        
        deployment_options = st.expander("⚙️ Deployment Options")
        with deployment_options:
            backup_before = st.checkbox("Backup current settings before deployment", value=True)
            user_overrides = st.text_area(
                "Custom Overrides (YAML format)",
                placeholder="# Optional: Add custom overrides\n# credentials:\n#   aws:\n#     access_key_id: YOUR_KEY",
                height=100
            )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🚀 Deploy to Admin Directory", type="primary", key="deploy_enhanced"):
                with st.spinner(f"Deploying {template_choice} template..."):
                    try:
                        # Parse user overrides if provided
                        overrides = {}
                        if user_overrides.strip():
                            overrides = yaml.safe_load(user_overrides)
                        
                        # Quick deploy
                        result = quick_deploy_environment(template_choice, overrides)
                        
                        if result["status"] == "success":
                            st.success(f"✅ {result['message']}")
                            st.success(f"📁 Settings saved to: {result['settings_path']}")
                            
                            if result.get("backup_path"):
                                st.info(f"💾 Previous settings backed up to: {result['backup_path']}")
                            
                            if result.get("validation", {}).get("warnings"):
                                for warning in result["validation"]["warnings"]:
                                    st.warning(f"⚠️ {warning}")
                            
                            # Show next steps
                            st.markdown("#### ✨ Next Steps")
                            st.info("""
                            Your environment has been deployed! You can now:
                            1. Test the new configuration in **Gateway Architecture** page
                            2. Update credentials if needed
                            3. Run validation tests
                            """)
                            
                        else:
                            st.error(f"❌ {result['message']}")
                            
                    except Exception as e:
                        st.error(f"❌ Deployment error: {e}")
        
        with col2:
            if st.button("💾 Save as Template File", key="save_template_enhanced"):
                with st.spinner(f"Saving {template_choice} template..."):
                    try:
                        template = manager.create_environment_template(template_choice)
                        template_path = manager.save_template_file(template, template_choice)
                        st.success(f"✅ Template saved to: {template_path}")
                    except Exception as e:
                        st.error(f"❌ Error saving template: {e}")
        
        # Backup management
        if st.checkbox("📂 Manage Backups", key="manage_backups"):
            st.markdown("#### 📂 Backup Management")
            
            backups = manager.list_backups()
            
            if backups:
                st.write(f"Found {len(backups)} backup files:")
                
                for backup in backups[:5]:  # Show last 5
                    col1, col2, col3 = st.columns([3, 2, 1])
                    
                    with col1:
                        st.write(f"📄 {backup['filename']}")
                    
                    with col2:
                        st.write(f"🕒 {backup['modified']}")
                    
                    with col3:
                        if st.button("↩️ Restore", key=f"restore_{backup['filename']}"):
                            result = manager.restore_from_backup(backup['filename'])
                            if result["status"] == "success":
                                st.success(f"✅ {result['message']}")
                                st.rerun()
                            else:
                                st.error(f"❌ {result['message']}")
                
                if len(backups) > 5:
                    st.info(f"... and {len(backups) - 5} more backups available")
            else:
                st.info("No backup files found")
                
    except ImportError:
        st.error("❌ Enhanced template system not available.")
        st.error("**Required:** `proposed_settings.yaml` file must exist in onboarding directory.")
        st.info("**Solution:** Create `proposed_settings.yaml` with your configuration template.")
        st.info("**Alternative:** Use the 'System Configuration' tab to configure manually.")
        
        # Don't fall back to blank template - provide clear guidance instead
        st.markdown("### 📋 Manual Configuration Required")
        st.markdown("""
        Since the enhanced template system is not available, you can:
        
        1. **Create `proposed_settings.yaml`** in the onboarding directory
        2. **Use the System Configuration tabs** to configure manually
        3. **Copy from existing settings** if available
        
        The template system requires `proposed_settings.yaml` to generate environment-specific configurations.
        """)


def render_blank_template_workflow(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow for creating new configuration from blank template."""
    st.markdown("### 🆕 Create New Configuration")
    
    st.info("""
    **Start with a blank template and configure it step by step.**
    
    This will load the blank `proposed_settings.yaml` template and guide you through 
    filling in your specific configuration values.
    """)
    
    # Check if blank template exists
    blank_template_path = settings_path.parent / "proposed_settings.yaml"
    
    if not blank_template_path.exists():
        st.error(f"❌ Blank template not found: {blank_template_path}")
        st.info("Please run `python create_environment_settings.py` first to set up the templates.")
        return
    
    # Load blank template
    try:
        with open(blank_template_path, 'r') as f:
            blank_template = yaml.safe_load(f)
        
        st.success(f"✅ Loaded blank template: {blank_template_path}")
        
        # Show template structure
        with st.expander("📋 View Blank Template Structure"):
            st.json(blank_template)
        
        # Configuration wizard
        st.markdown("#### ⚙️ Configuration Wizard")
        st.info("""
        **Next Steps:**
        1. Use the other tabs (AWS Setup, Database Setup, etc.) to fill in your configuration
        2. Your changes will be saved to the active settings.yaml
        3. The blank template will remain unchanged for future use
        """)
        
        # Apply blank template as starting point
        if st.button("🚀 Start with Blank Template", type="primary"):
            try:
                # Copy blank template to active settings
                with open(settings_path, 'w') as f:
                    yaml.dump(blank_template, f, default_flow_style=False, sort_keys=False)
                
                st.success("✅ Blank template loaded as starting point!")
                st.info("👉 Now use the other tabs to configure your system.")
                st.rerun()
                
            except Exception as e:
                st.error(f"❌ Error loading blank template: {e}")
    
    except Exception as e:
        st.error(f"❌ Error reading blank template: {e}")


def render_existing_environment_workflow(current_settings: Dict[str, Any], settings_path: Path):
    """Render workflow for using existing environment templates."""
    st.markdown("### 🔄 Use Existing Environment")
    
    st.info("""
    **Promote an existing environment template to active settings.**
    
    This will copy one of your pre-configured environment templates to become 
    the active configuration that all TidyLLM systems will use.
    """)
    
    # Check for existing environment templates
    admin_dir = settings_path.parent
    environment_files = {
        'development': admin_dir / "development_settings.yaml",
        'staging': admin_dir / "staging_settings.yaml", 
        'corporate': admin_dir / "corporate_settings.yaml",
        'local': admin_dir / "local_settings.yaml"
    }
    
    # Check which environments exist
    available_environments = []
    for env_name, env_file in environment_files.items():
        if env_file.exists():
            available_environments.append(env_name)
    
    if not available_environments:
        st.warning("⚠️ No environment templates found!")
        st.info("""
        **To create environment templates:**
        1. Run `python create_environment_settings.py` from the project root
        2. This will generate all environment template files
        3. Then return here to select one
        """)
        
        if st.button("🔄 Refresh Page"):
            st.rerun()
        return
    
    # Environment selection
    st.markdown("#### 🎯 Select Environment")
    
    selected_env = st.selectbox(
        "Choose environment to promote:",
        options=available_environments,
        help="Select which environment configuration to make active"
    )
    
    if selected_env:
        env_file = environment_files[selected_env]
        
        # Show environment details
        try:
            with open(env_file, 'r') as f:
                env_config = yaml.safe_load(f)
            
            st.markdown(f"#### 📋 {selected_env.title()} Environment Details")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                s3_prefix = env_config.get('services', {}).get('s3', {}).get('prefix', 'unknown')
                st.metric("S3 Prefix", s3_prefix)
            
            with col2:
                log_level = env_config.get('operations', {}).get('logging', {}).get('level', 'unknown')
                st.metric("Log Level", log_level)
            
            with col3:
                environment = env_config.get('system', {}).get('environment', 'unknown')
                st.metric("Environment", environment)
            
            # Show preview
            with st.expander(f"📄 Preview {selected_env.title()} Configuration"):
                st.json(env_config)
            
            # Promote button
            st.markdown("#### 🚀 Promote to Active")
            
            if st.button(f"🎯 Promote {selected_env.title()} Environment", type="primary"):
                try:
                    import shutil
                    from datetime import datetime
                    
                    # Create backup of current active settings
                    if settings_path.exists():
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                        backup_file = admin_dir / f"settings_backup_{timestamp}.yaml"
                        shutil.copy2(settings_path, backup_file)
                        st.info(f"📋 Created backup: {backup_file.name}")
                    
                    # Promote environment to active settings
                    shutil.copy2(env_file, settings_path)
                    
                    st.success(f"🎉 Successfully promoted {selected_env} environment to active settings!")
                    st.info(f"✅ All TidyLLM systems now use {selected_env} configuration")
                    st.balloons()
                    
                    # Show promotion details
                    st.markdown("#### 📊 Promotion Details")
                    st.info(f"""
                    **Promoted:** `{env_file.name}` → `settings.yaml`  
                    **Active Environment:** {selected_env}  
                    **Timestamp:** {datetime.now().isoformat()}
                    """)
                    
                except Exception as e:
                    st.error(f"❌ Error promoting environment: {e}")
        
        except Exception as e:
            st.error(f"❌ Error reading environment file: {e}")
