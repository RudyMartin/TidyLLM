"""
TidyLLM Native Knowledge Systems Interface
==========================================

Knowledge management using TidyLLM's native knowledge systems and RAG capabilities.
"""

import streamlit as st
from typing import Dict, Any, List, Optional
import json
from datetime import datetime
from pathlib import Path

from tidyllm.knowledge_systems.core.domain_rag import DomainRAG
from tidyllm.knowledge_systems.interfaces.knowledge_interface import KnowledgeInterface
from tidyllm.gateways import get_gateway
from tidyllm.infrastructure.session.unified import UnifiedSessionManager

class TidyLLMKnowledgeInterface:
    """Native TidyLLM knowledge systems interface."""
    
    def __init__(self):
        """Initialize with TidyLLM knowledge components."""
        self.session_manager = st.session_state.get('tidyllm_session_manager')
        self.domain_rag = None
        self.database_gateway = None
        self._init_knowledge_system()
        self._init_session_state()
    
    def _init_knowledge_system(self):
        """Initialize TidyLLM knowledge system."""
        try:
            # Get database gateway for knowledge storage
            self.database_gateway = get_gateway('database')
            
            # Initialize Domain RAG if session manager available
            if self.session_manager:
                self.domain_rag = DomainRAG(
                    session_manager=self.session_manager,
                    domain_name="enterprise_knowledge"
                )
        except Exception as e:
            st.error(f"Failed to initialize knowledge system: {e}")
    
    def _init_session_state(self):
        """Initialize knowledge session state."""
        if 'knowledge_domains' not in st.session_state:
            st.session_state.knowledge_domains = []
        if 'selected_domain' not in st.session_state:
            st.session_state.selected_domain = None
        if 'search_history' not in st.session_state:
            st.session_state.search_history = []
        if 'uploaded_documents' not in st.session_state:
            st.session_state.uploaded_documents = []
    
    def render(self):
        """Render the TidyLLM knowledge interface."""
        st.title("📚 TidyLLM Knowledge Systems")
        st.markdown("**Enterprise Knowledge Management with Domain RAG**")
        
        # Check system status
        if not self.session_manager:
            st.error("❌ Session Manager not initialized")
            st.info("Please initialize the system first (go to Initialize System page)")
            return
        
        # Knowledge system tabs
        tabs = st.tabs([
            "🔍 Search & Query",
            "📤 Document Upload",
            "🏗️ Domain Management",
            "📊 Knowledge Analytics",
            "🔧 RAG Configuration"
        ])
        
        with tabs[0]:
            self._render_search_query()
        
        with tabs[1]:
            self._render_document_upload()
        
        with tabs[2]:
            self._render_domain_management()
        
        with tabs[3]:
            self._render_knowledge_analytics()
        
        with tabs[4]:
            self._render_rag_configuration()
    
    def _render_search_query(self):
        """Render search and query interface."""
        st.markdown("### 🔍 Knowledge Search")
        
        # Search mode selector
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            search_mode = st.selectbox(
                "Search Mode",
                ["Semantic Search", "Keyword Search", "Hybrid Search", "Graph Traversal"],
                key="search_mode"
            )
        
        with col2:
            max_results = st.number_input(
                "Max Results",
                min_value=1,
                max_value=50,
                value=10,
                key="max_results"
            )
        
        with col3:
            confidence_threshold = st.slider(
                "Confidence",
                min_value=0.0,
                max_value=1.0,
                value=0.7,
                key="confidence_threshold"
            )
        
        # Search input
        query = st.text_area(
            "Enter your query",
            placeholder="Ask anything about your knowledge base...",
            height=100,
            key="search_query"
        )
        
        # Advanced filters
        with st.expander("🔧 Advanced Filters"):
            col1, col2 = st.columns(2)
            
            with col1:
                domain_filter = st.multiselect(
                    "Filter by Domain",
                    options=st.session_state.knowledge_domains or ["default"],
                    key="domain_filter"
                )
                
                date_range = st.date_input(
                    "Date Range",
                    value=[],
                    key="date_range"
                )
            
            with col2:
                doc_type_filter = st.multiselect(
                    "Document Types",
                    options=["PDF", "TXT", "MD", "DOCX", "HTML"],
                    key="doc_type_filter"
                )
                
                author_filter = st.text_input(
                    "Author Filter",
                    key="author_filter"
                )
        
        # Search button
        if st.button("🔍 Search Knowledge Base", type="primary", use_container_width=True):
            if query:
                self._perform_search(query, search_mode, max_results, confidence_threshold)
        
        # Display search results
        if 'search_results' in st.session_state and st.session_state.search_results:
            st.markdown("---")
            st.markdown("### 📋 Search Results")
            
            for idx, result in enumerate(st.session_state.search_results):
                with st.expander(f"📄 {result.get('title', 'Document')} - Score: {result.get('score', 0):.2f}"):
                    # Document metadata
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown(f"**Source:** {result.get('source', 'Unknown')}")
                    with col2:
                        st.markdown(f"**Type:** {result.get('type', 'Unknown')}")
                    with col3:
                        st.markdown(f"**Date:** {result.get('date', 'Unknown')}")
                    
                    # Content preview
                    st.markdown("**Content Preview:**")
                    st.markdown(result.get('content', 'No content available'))
                    
                    # Actions
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        if st.button(f"📖 View Full", key=f"view_{idx}"):
                            self._view_document(result.get('id'))
                    
                    with col2:
                        if st.button(f"💬 Ask About This", key=f"ask_{idx}"):
                            self._ask_about_document(result)
                    
                    with col3:
                        if st.button(f"🔗 Related Docs", key=f"related_{idx}"):
                            self._find_related_documents(result.get('id'))
        
        # Search history
        if st.session_state.search_history:
            with st.expander("📜 Recent Searches"):
                for search in st.session_state.search_history[-5:]:
                    st.markdown(f"- {search['query']} ({search['timestamp']})")
    
    def _render_document_upload(self):
        """Render document upload interface."""
        st.markdown("### 📤 Document Upload")
        
        # Upload configuration
        col1, col2 = st.columns(2)
        
        with col1:
            target_domain = st.selectbox(
                "Target Domain",
                options=st.session_state.knowledge_domains or ["default"],
                key="upload_domain"
            )
            
            process_mode = st.selectbox(
                "Processing Mode",
                ["Automatic", "Manual Review", "Batch Processing"],
                key="process_mode"
            )
        
        with col2:
            enable_ocr = st.checkbox("Enable OCR", value=True, key="enable_ocr")
            extract_metadata = st.checkbox("Extract Metadata", value=True, key="extract_metadata")
            create_embeddings = st.checkbox("Create Embeddings", value=True, key="create_embeddings")
        
        # File uploader
        uploaded_files = st.file_uploader(
            "Choose files to upload",
            type=["pdf", "txt", "md", "docx", "html", "csv", "json"],
            accept_multiple_files=True,
            key="file_uploader"
        )
        
        if uploaded_files:
            st.markdown("#### 📎 Files to Process")
            
            # Display file information
            file_info = []
            for file in uploaded_files:
                file_info.append({
                    "Name": file.name,
                    "Size": f"{file.size / 1024:.2f} KB",
                    "Type": file.type
                })
            
            import pandas as pd
            df = pd.DataFrame(file_info)
            st.dataframe(df, use_container_width=True)
            
            # Processing options
            with st.expander("⚙️ Processing Options"):
                chunk_size = st.slider(
                    "Chunk Size",
                    min_value=100,
                    max_value=2000,
                    value=500,
                    step=100,
                    key="chunk_size"
                )
                
                overlap = st.slider(
                    "Chunk Overlap",
                    min_value=0,
                    max_value=200,
                    value=50,
                    step=10,
                    key="chunk_overlap"
                )
                
                embedding_model = st.selectbox(
                    "Embedding Model",
                    ["titan-embed-text-v1", "cohere-embed", "openai-ada-002"],
                    key="embedding_model"
                )
            
            # Upload button
            if st.button("📤 Upload and Process", type="primary", use_container_width=True):
                self._process_uploads(uploaded_files, target_domain)
        
        # Upload history
        if st.session_state.uploaded_documents:
            st.markdown("---")
            st.markdown("### 📚 Recent Uploads")
            
            for doc in st.session_state.uploaded_documents[-5:]:
                with st.expander(f"📄 {doc['name']} - {doc['timestamp']}"):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.markdown(f"**Status:** {doc['status']}")
                    with col2:
                        st.markdown(f"**Chunks:** {doc.get('chunks', 0)}")
                    with col3:
                        st.markdown(f"**Domain:** {doc['domain']}")
                    
                    if doc['status'] == "✅ Processed":
                        if st.button(f"🔍 Search in this doc", key=f"search_doc_{doc['id']}"):
                            self._search_in_document(doc['id'])
    
    def _render_domain_management(self):
        """Render domain management interface."""
        st.markdown("### 🏗️ Knowledge Domain Management")
        
        # Create new domain
        st.markdown("#### Create New Domain")
        
        col1, col2 = st.columns(2)
        
        with col1:
            new_domain_name = st.text_input(
                "Domain Name",
                placeholder="e.g., technical_docs, hr_policies",
                key="new_domain_name"
            )
            
            domain_description = st.text_area(
                "Description",
                placeholder="Describe the purpose of this domain...",
                height=100,
                key="domain_description"
            )
        
        with col2:
            domain_type = st.selectbox(
                "Domain Type",
                ["General", "Technical", "Legal", "Financial", "Medical"],
                key="domain_type"
            )
            
            access_level = st.selectbox(
                "Access Level",
                ["Public", "Internal", "Restricted", "Confidential"],
                key="access_level"
            )
        
        if st.button("➕ Create Domain", type="primary"):
            if new_domain_name:
                self._create_domain(new_domain_name, domain_description, domain_type, access_level)
        
        st.markdown("---")
        
        # Existing domains
        st.markdown("#### Existing Domains")
        
        if self.domain_rag:
            try:
                # Get domains from S3
                domains = self._list_domains()
                
                if domains:
                    for domain in domains:
                        with st.expander(f"📁 {domain['name']}"):
                            col1, col2, col3 = st.columns(3)
                            
                            with col1:
                                st.metric("Documents", domain.get('doc_count', 0))
                            with col2:
                                st.metric("Total Size", f"{domain.get('size_mb', 0):.1f} MB")
                            with col3:
                                st.metric("Last Updated", domain.get('last_updated', 'Unknown'))
                            
                            # Domain actions
                            col1, col2, col3, col4 = st.columns(4)
                            
                            with col1:
                                if st.button(f"📊 Analytics", key=f"analytics_{domain['name']}"):
                                    self._show_domain_analytics(domain['name'])
                            
                            with col2:
                                if st.button(f"🔄 Refresh", key=f"refresh_{domain['name']}"):
                                    self._refresh_domain(domain['name'])
                            
                            with col3:
                                if st.button(f"📥 Export", key=f"export_{domain['name']}"):
                                    self._export_domain(domain['name'])
                            
                            with col4:
                                if st.button(f"🗑️ Delete", key=f"delete_{domain['name']}"):
                                    self._delete_domain(domain['name'])
                else:
                    st.info("No domains found. Create your first domain above.")
            except Exception as e:
                st.error(f"Failed to load domains: {e}")
    
    def _render_knowledge_analytics(self):
        """Render knowledge analytics dashboard."""
        st.markdown("### 📊 Knowledge Analytics")
        
        # Overall metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Documents", "1,234", "+56")
        with col2:
            st.metric("Knowledge Domains", len(st.session_state.knowledge_domains))
        with col3:
            st.metric("Total Queries", "8,901", "+234")
        with col4:
            st.metric("Avg Response Time", "1.2s", "-0.3s")
        
        st.markdown("---")
        
        # Charts
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 📈 Query Volume (Last 7 Days)")
            # Placeholder for chart
            st.line_chart({"Queries": [120, 145, 132, 189, 201, 178, 195]})
        
        with col2:
            st.markdown("#### 🎯 Top Search Topics")
            # Placeholder for chart
            st.bar_chart({"Topics": [45, 38, 32, 28, 22, 18, 15]})
        
        # Document statistics
        st.markdown("#### 📄 Document Statistics")
        
        doc_stats = {
            "Document Type": ["PDF", "TXT", "MD", "DOCX", "HTML"],
            "Count": [456, 234, 189, 145, 98],
            "Avg Size (KB)": [245, 12, 8, 156, 34]
        }
        
        import pandas as pd
        df = pd.DataFrame(doc_stats)
        st.dataframe(df, use_container_width=True)
        
        # Performance metrics
        with st.expander("🚀 Performance Metrics"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Indexing Performance**")
                st.metric("Avg Indexing Time", "2.3s/doc")
                st.metric("Embedding Generation", "0.8s/chunk")
                st.metric("Success Rate", "99.2%")
            
            with col2:
                st.markdown("**Query Performance**")
                st.metric("Avg Query Time", "1.2s")
                st.metric("Cache Hit Rate", "67%")
                st.metric("Relevance Score", "0.84")
    
    def _render_rag_configuration(self):
        """Render RAG configuration interface."""
        st.markdown("### 🔧 RAG Configuration")
        
        # Retrieval settings
        st.markdown("#### Retrieval Settings")
        
        col1, col2 = st.columns(2)
        
        with col1:
            retrieval_method = st.selectbox(
                "Retrieval Method",
                ["Dense", "Sparse", "Hybrid", "Graph-based"],
                key="retrieval_method"
            )
            
            top_k = st.slider(
                "Top K Documents",
                min_value=1,
                max_value=20,
                value=5,
                key="top_k"
            )
            
            similarity_threshold = st.slider(
                "Similarity Threshold",
                min_value=0.0,
                max_value=1.0,
                value=0.7,
                step=0.05,
                key="similarity_threshold"
            )
        
        with col2:
            rerank_enabled = st.checkbox(
                "Enable Reranking",
                value=True,
                key="rerank_enabled"
            )
            
            if rerank_enabled:
                rerank_model = st.selectbox(
                    "Reranking Model",
                    ["cross-encoder", "bm25", "mmr"],
                    key="rerank_model"
                )
            
            context_window = st.number_input(
                "Context Window Size",
                min_value=512,
                max_value=8192,
                value=2048,
                step=512,
                key="context_window"
            )
        
        st.markdown("---")
        
        # Generation settings
        st.markdown("#### Generation Settings")
        
        col1, col2 = st.columns(2)
        
        with col1:
            llm_model = st.selectbox(
                "LLM Model",
                ["claude-3-sonnet", "claude-3-opus", "gpt-4", "llama-3-70b"],
                key="llm_model"
            )
            
            temperature = st.slider(
                "Temperature",
                min_value=0.0,
                max_value=1.0,
                value=0.3,
                step=0.1,
                key="temperature"
            )
            
            max_tokens = st.number_input(
                "Max Tokens",
                min_value=100,
                max_value=4000,
                value=1000,
                step=100,
                key="max_tokens"
            )
        
        with col2:
            prompt_template = st.selectbox(
                "Prompt Template",
                ["Default", "Academic", "Technical", "Conversational", "Custom"],
                key="prompt_template"
            )
            
            if prompt_template == "Custom":
                custom_prompt = st.text_area(
                    "Custom Prompt Template",
                    placeholder="Context: {context}\n\nQuestion: {question}\n\nAnswer:",
                    height=150,
                    key="custom_prompt"
                )
            
            include_sources = st.checkbox(
                "Include Source Citations",
                value=True,
                key="include_sources"
            )
        
        # Save configuration
        if st.button("💾 Save RAG Configuration", type="primary", use_container_width=True):
            self._save_rag_config()
    
    def _perform_search(self, query: str, mode: str, max_results: int, confidence: float):
        """Perform knowledge search."""
        with st.spinner(f"Searching knowledge base..."):
            try:
                if self.domain_rag:
                    # Perform search based on mode
                    if mode == "Semantic Search":
                        results = self.domain_rag.semantic_search(
                            query=query,
                            top_k=max_results,
                            threshold=confidence
                        )
                    elif mode == "Hybrid Search":
                        results = self.domain_rag.hybrid_search(
                            query=query,
                            top_k=max_results
                        )
                    else:
                        # Fallback to basic search
                        results = [{
                            "title": f"Document {i}",
                            "content": f"Sample content for query: {query}",
                            "score": 0.9 - (i * 0.1),
                            "source": "knowledge_base",
                            "type": "PDF",
                            "date": datetime.now().strftime("%Y-%m-%d")
                        } for i in range(min(3, max_results))]
                    
                    st.session_state.search_results = results
                    
                    # Add to search history
                    st.session_state.search_history.append({
                        "query": query,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "results_count": len(results)
                    })
                    
                    st.success(f"Found {len(results)} relevant documents")
                else:
                    st.error("Knowledge system not initialized")
            except Exception as e:
                st.error(f"Search failed: {e}")
    
    def _process_uploads(self, files, domain: str):
        """Process uploaded documents."""
        progress_bar = st.progress(0)
        status_text = st.empty()
        
        for idx, file in enumerate(files):
            progress = (idx + 1) / len(files)
            progress_bar.progress(progress)
            status_text.text(f"Processing {file.name}...")
            
            try:
                # Process with Domain RAG
                if self.domain_rag:
                    # Save file to S3 and process
                    doc_id = self.domain_rag.add_document(
                        content=file.read(),
                        filename=file.name,
                        domain=domain
                    )
                    
                    # Add to upload history
                    st.session_state.uploaded_documents.append({
                        "id": doc_id,
                        "name": file.name,
                        "domain": domain,
                        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "status": "✅ Processed",
                        "chunks": 10  # Placeholder
                    })
                
            except Exception as e:
                st.error(f"Failed to process {file.name}: {e}")
                st.session_state.uploaded_documents.append({
                    "name": file.name,
                    "domain": domain,
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "status": f"❌ Failed: {str(e)}"
                })
        
        progress_bar.progress(1.0)
        status_text.text("Processing complete!")
        st.success(f"Successfully processed {len(files)} documents")
    
    def _create_domain(self, name: str, description: str, domain_type: str, access: str):
        """Create a new knowledge domain."""
        try:
            if self.domain_rag:
                # Create domain in S3
                self.domain_rag.create_domain(
                    name=name,
                    description=description,
                    metadata={
                        "type": domain_type,
                        "access_level": access,
                        "created": datetime.now().isoformat()
                    }
                )
                
                # Add to session state
                st.session_state.knowledge_domains.append(name)
                st.success(f"✅ Domain '{name}' created successfully")
                st.rerun()
        except Exception as e:
            st.error(f"Failed to create domain: {e}")
    
    def _list_domains(self) -> List[Dict[str, Any]]:
        """List all knowledge domains."""
        # Placeholder implementation
        return [
            {
                "name": domain,
                "doc_count": 42,
                "size_mb": 125.3,
                "last_updated": "2024-01-15"
            }
            for domain in st.session_state.knowledge_domains
        ]
    
    def _save_rag_config(self):
        """Save RAG configuration."""
        config = {
            "retrieval": {
                "method": st.session_state.retrieval_method,
                "top_k": st.session_state.top_k,
                "similarity_threshold": st.session_state.similarity_threshold,
                "rerank_enabled": st.session_state.rerank_enabled
            },
            "generation": {
                "model": st.session_state.llm_model,
                "temperature": st.session_state.temperature,
                "max_tokens": st.session_state.max_tokens,
                "include_sources": st.session_state.include_sources
            }
        }
        
        st.success("✅ RAG configuration saved successfully")
        st.json(config)
    
    def _view_document(self, doc_id: str):
        """View full document."""
        st.info(f"Opening document {doc_id}...")
    
    def _ask_about_document(self, doc: Dict[str, Any]):
        """Ask questions about specific document."""
        st.info(f"Opening chat for document: {doc.get('title')}")
    
    def _find_related_documents(self, doc_id: str):
        """Find related documents."""
        st.info(f"Finding documents related to {doc_id}...")
    
    def _search_in_document(self, doc_id: str):
        """Search within a specific document."""
        st.info(f"Searching in document {doc_id}...")
    
    def _show_domain_analytics(self, domain: str):
        """Show analytics for a domain."""
        st.info(f"Loading analytics for domain: {domain}")
    
    def _refresh_domain(self, domain: str):
        """Refresh domain index."""
        st.info(f"Refreshing domain: {domain}")
    
    def _export_domain(self, domain: str):
        """Export domain data."""
        st.info(f"Exporting domain: {domain}")
    
    def _delete_domain(self, domain: str):
        """Delete a domain."""
        if st.confirm(f"Are you sure you want to delete domain '{domain}'?"):
            st.session_state.knowledge_domains.remove(domain)
            st.success(f"Domain '{domain}' deleted")
            st.rerun()


def render_tidyllm_knowledge_page():
    """Convenience function to render TidyLLM knowledge page."""
    knowledge = TidyLLMKnowledgeInterface()
    knowledge.render()