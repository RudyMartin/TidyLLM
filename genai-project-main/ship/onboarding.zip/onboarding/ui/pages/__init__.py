"""
TidyLLM Onboarding Pages Module
===============================

Page components for the onboarding system.
"""

from .connection import render_connection_page
from .setup import render_setup_page
from .chat import render_chat_page
from .knowledge import render_knowledge_page
from .workflows import render_workflows_page
from .testing import render_testing_page
from .dashboard import render_dashboard_page
from .guided_setup import render_guided_setup_page

__all__ = [
    'render_connection_page',
    'render_setup_page',
    'render_chat_page', 
    'render_knowledge_page',
    'render_workflows_page',
    'render_testing_page',
    'render_dashboard_page',
    'render_guided_setup_page'
]
