"""
TidyLLM Onboarding Gateway Testing Page
======================================

Gateway connection testing and validation page.
"""

import streamlit as st
import time
# Using existing TidyLLM validator instead of old_core
from tidyllm.onboarding.session_validator import CorporateSessionManager

def render_connection_page():
    """Render the gateway testing page with corporate-safe validation."""
    
    st.markdown('<div class="section-header">🚪 Gateway Testing & Validation</div>', unsafe_allow_html=True)
    
    # Show corporate environment status
    if 'corporate_environment' in st.session_state:
        env_info = st.session_state.corporate_environment
        if env_info.get('is_corporate'):
            st.warning(f"🏢 **Corporate Environment Detected** (Score: {env_info.get('corporate_score')}/6)")
            st.info("Using corporate-safe validation methods to prevent hanging")
        else:
            st.success(f"🌐 **Standard Environment** (Score: {env_info.get('corporate_score')}/6)")
    
    st.info("""
    **Test and validate all TidyLLM gateway connections.**
    
    This page focuses on testing the core gateways that power the TidyLLM system.
    For full system configuration, use the "System Setup" page.
    """)
    
    st.markdown("---")
    
    st.markdown("### 🚨 AWS Connection Required")
    st.error("""
    **⚠️ NOTHING WORKS WITHOUT AWS CONNECTION**
    
    All TidyLLM gateways and features require AWS connectivity:
    - **S3** - Document storage and retrieval
    - **Bedrock** - AI model access and processing  
    - **STS** - Security token service
    - **PostgreSQL** - Vector database
    
    **Configure connections in "System Setup" page first, then test here.**
    """)
    
    # Connection validator
    validator = CorporateSessionManager()
    
    # AWS Services Test Buttons
    st.markdown("### 🚨 AWS Services Testing")
    st.markdown("**Test individual AWS services:**")
    
    st.info("""
    **🏢 Corporate Environment Notice:**
    Tests are designed to work within corporate security restrictions.
    Some API operations may be limited by your organization's policies.
    """)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        if st.button("🗄️ Test S3", use_container_width=True):
            with st.spinner("Testing S3 connectivity..."):
                aws_results = validator.validate_aws_connectivity()
                st.session_state.aws_results = aws_results
                if aws_results.get('s3', {}).get('status') == 'success':
                    st.success("✅ S3: Connected")
                else:
                    st.error("❌ S3: Failed")
    
    with col2:
        if st.button("🤖 Test Bedrock", use_container_width=True):
            with st.spinner("Testing Bedrock connectivity..."):
                aws_results = validator.validate_aws_connectivity()
                st.session_state.aws_results = aws_results
                bedrock_result = aws_results.get('bedrock', {})
                if bedrock_result.get('status') == 'success':
                    st.success("✅ Bedrock: Connected")
                    st.info(f"Latency: {bedrock_result.get('latency', 0):.1f}ms")
                else:
                    st.error(f"❌ Bedrock: {bedrock_result.get('message', 'Failed')}")
    
    with col3:
        if st.button("🔐 Test STS", use_container_width=True):
            with st.spinner("Testing STS connectivity..."):
                aws_results = validator.validate_aws_connectivity()
                st.session_state.aws_results = aws_results
                sts_result = aws_results.get('sts', {})
                if sts_result.get('status') == 'success':
                    st.success("✅ STS: Connected")
                    st.info(f"Latency: {sts_result.get('latency', 0):.1f}ms")
                else:
                    st.error(f"❌ STS: {sts_result.get('message', 'Failed')}")
    
    with col4:
        if st.button("🗄️ Test Database", use_container_width=True):
            with st.spinner("Testing database connectivity..."):
                db_results = validator.validate_database_connectivity()
                st.session_state.db_results = db_results
                if db_results.get('status') == 'success':
                    st.success("✅ Database: Connected")
                else:
                    st.error("❌ Database: Failed")
    
    # Bedrock Configuration Card
    st.markdown("### 🤖 Bedrock Configuration")
    
    with st.container():
        st.markdown("""
        **Amazon Bedrock AI Service Configuration**
        
        Bedrock provides access to foundation models for AI processing.
        """)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.info("""
            **Current Status**: Bedrock connection is required for:
            - AI model access and processing
            - Document analysis and insights
            - Chat functionality
            - Workflow optimization
            """)
        
        with col2:
            if st.button("🧪 Test Bedrock Connection", use_container_width=True, type="primary"):
                with st.spinner("Testing Bedrock connectivity..."):
                    aws_results = validator.validate_aws_connectivity()
                    st.session_state.aws_results = aws_results
                    bedrock_result = aws_results.get('bedrock', {})
                    if bedrock_result.get('status') == 'success':
                        st.success("✅ **Bedrock Connected Successfully!**")
                        st.info(f"**Response Time**: {bedrock_result.get('latency', 0):.1f}ms")
                        st.balloons()
                    else:
                        st.error(f"❌ **Bedrock Connection Failed**")
                        st.error(f"**Error**: {bedrock_result.get('message', 'Unknown error')}")
    
    st.markdown("---")
    
    # Gateway Testing
    st.markdown("### 🚪 Gateway Testing")
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🚪 Test Gateways", use_container_width=True):
            with st.spinner("Testing gateways..."):
                gateway_results = validator.validate_gateways()
                st.session_state.gateway_results = gateway_results
    
    # Run all tests button
    if st.button("🔄 Run All Tests", use_container_width=True, type="primary"):
        with st.spinner("Running comprehensive tests..."):
            all_results = validator.run_full_validation()
            st.session_state.all_results = all_results
    
    # Display results
    if hasattr(st.session_state, 'aws_results'):
        st.markdown("### AWS Connectivity Results")
        display_aws_results(st.session_state.aws_results)
    
    if hasattr(st.session_state, 'db_results'):
        st.markdown("### Database Connectivity Results")
        display_db_results(st.session_state.db_results)
    
    if hasattr(st.session_state, 'gateway_results'):
        st.markdown("### Gateway Results")
        display_gateway_results(st.session_state.gateway_results)
    
    if hasattr(st.session_state, 'all_results'):
        st.markdown("### Complete Test Results")
        display_all_results(st.session_state.all_results)

def display_aws_results(results):
    """Display AWS connectivity test results."""
    if not results:
        st.error("No AWS test results available")
        return
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("S3", "✅ Connected" if results.get('s3', {}).get('status') == 'success' else "❌ Failed")
    
    with col2:
        st.metric("Bedrock", "✅ Connected" if results.get('bedrock', {}).get('status') == 'success' else "❌ Failed")
    
    with col3:
        st.metric("STS", "✅ Connected" if results.get('sts', {}).get('status') == 'success' else "❌ Failed")
    
    # Show detailed results
    with st.expander("Detailed AWS Results"):
        st.json(results)

def display_db_results(results):
    """Display database connectivity test results."""
    if not results:
        st.error("No database test results available")
        return
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Primary DB", "✅ Connected" if results.get('primary', {}).get('status') == 'success' else "❌ Failed")
    
    with col2:
        st.metric("Secondary DB", "✅ Connected" if results.get('secondary', {}).get('status') == 'success' else "❌ Failed")
    
    with col3:
        st.metric("Backup DB", "✅ Connected" if results.get('backup', {}).get('status') == 'success' else "❌ Failed")
    
    # Show detailed results
    with st.expander("Detailed Database Results"):
        st.json(results)

def display_gateway_results(results):
    """Display gateway test results."""
    if not results:
        st.error("No gateway test results available")
        return
    
    # Core gateways
    st.markdown("#### Core Gateways")
    col1, col2, col3, col4 = st.columns(4)
    
    gateways = [
        ("CorporateLLM", results.get('corporate_llm', {})),
        ("AIProcessing", results.get('ai_processing', {})),
        ("WorkflowOptimizer", results.get('workflow_optimizer', {})),
        ("KnowledgeMCP", results.get('knowledge_mcp', {}))
    ]
    
    for i, (name, result) in enumerate(gateways):
        with [col1, col2, col3, col4][i]:
            status = "✅ Active" if result.get('status') == 'success' else "❌ Failed"
            st.metric(name, status)
    
    # Utility services
    st.markdown("#### Utility Services")
    col1, col2, col3 = st.columns(3)
    
    services = [
        ("DatabaseGateway", results.get('database_gateway', {})),
        ("FileStorage", results.get('file_storage', {})),
        ("MVRAnalysis", results.get('mvr_analysis', {}))
    ]
    
    for i, (name, result) in enumerate(services):
        with [col1, col2, col3][i]:
            status = "✅ Active" if result.get('status') == 'success' else "❌ Failed"
            st.metric(name, status)
    
    # Show detailed results
    with st.expander("Detailed Gateway Results"):
        st.json(results)

def display_all_results(results):
    """Display complete test results."""
    st.json(results)
    
    # Check if all services are working and show balloons! 🎈
    if isinstance(results, dict):
        all_working = True
        
        # Check AWS services
        if 'aws' in results:
            aws_status = results['aws'].get('status', 'unknown')
            if aws_status != 'success':
                all_working = False
        
        # Check database
        if 'database' in results:
            db_status = results['database'].get('status', 'unknown')
            if db_status != 'success':
                all_working = False
        
        # Check gateways
        if 'gateways' in results:
            gateway_status = results['gateways'].get('status', 'unknown')
            if gateway_status != 'success':
                all_working = False
        
        # 🎈 Celebrate if everything is working!
        if all_working:
            st.success("🎉 **ALL SERVICES ARE WORKING PERFECTLY!** 🎉")
            st.balloons()
            st.info("🚀 **System is fully operational and ready for use!**")