"""
TidyLLM Onboarding Workflows Page
=================================

Workflow configuration and YAML registry management page.
"""

import streamlit as st
import yaml
import sys
import os
import json
from pathlib import Path

# Add v2 directory to Python path for imports
v2_path = Path(__file__).parent.parent.parent.parent / 'v2'
if str(v2_path) not in sys.path:
    sys.path.append(str(v2_path))

try:
    from workflow_registry_system import WorkflowRegistrySystem
    from intelligent_document_intake import IntelligentDocumentIntake
except ImportError:
    # Fallback if imports fail
    WorkflowRegistrySystem = None
    IntelligentDocumentIntake = None

def render_workflows_page():
    """Render the workflows page."""
    
    st.markdown('<div class="section-header">⚙️ Workflows - Admin Configuration</div>', unsafe_allow_html=True)
    
    # Initialize workflow registry if available
    registry = None
    if WorkflowRegistrySystem:
        try:
            registry = WorkflowRegistrySystem()
        except Exception as e:
            st.error(f"Failed to initialize workflow registry: {e}")
            return
    
    if not registry:
        st.error("Workflow registry system not available.")
        return
    
    # Global workflow selector at the top
    try:
        workflows = registry.get_all_workflows()
        
        # Include any workflows created in this session
        if 'created_workflows' in st.session_state:
            workflows.update(st.session_state.created_workflows)
        
        workflow_names = {wid: w['name'] for wid, w in workflows.items()}
        
        if not workflows:
            st.info("No workflows found in registry.")
            return
        
        # Global workflow selector with better styling
        st.markdown("### 🎯 Select Workflow to Manage")
        
        # Auto-select workflow if coming from navigation
        default_workflow = (st.session_state.get('edit_criteria_workflow') or 
                          st.session_state.get('edit_template_workflow'))
        default_index = 0
        if default_workflow and default_workflow in workflow_names:
            default_index = list(workflow_names.keys()).index(default_workflow)
        
        # Add "Create New Workflow" option to the list
        workflow_options = list(workflow_names.keys()) + ["__CREATE_NEW__"]
        
        def format_workflow_option(x):
            if x == "__CREATE_NEW__":
                return "➕ Create New Workflow"
            else:
                return f"🔧 {workflow_names[x]} ({x})"
        
        selected_workflow = st.selectbox(
            "Choose a workflow:",
            options=workflow_options,
            format_func=format_workflow_option,
            index=default_index,
            key="global_workflow_selector"
        )
        
        # Clear navigation flags after using
        if st.session_state.get('edit_criteria_workflow'):
            st.session_state.edit_criteria_workflow = None
        if st.session_state.get('edit_template_workflow'):
            st.session_state.edit_template_workflow = None
        
        if selected_workflow == "__CREATE_NEW__":
            # Show workflow creation card
            with st.container():
                st.markdown("""
                <div style="
                    background: linear-gradient(90deg, #e8f5e8 0%, #ffffff 100%);
                    border: 2px solid #28a745;
                    border-radius: 10px;
                    padding: 20px;
                    margin: 10px 0;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                ">
                    <h4 style="color: #28a745; margin: 0 0 15px 0;">➕ Create New Workflow</h4>
                    <p style="margin-bottom: 15px; color: #555;">Fill in the basic details to create a new workflow:</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Workflow creation form
                with st.form("create_workflow_form", clear_on_submit=False):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        new_workflow_name = st.text_input(
                            "Workflow Name *", 
                            placeholder="e.g., Invoice Processing",
                            help="Descriptive name for the workflow"
                        )
                        new_workflow_type = st.selectbox(
                            "Workflow Type *",
                            options=["document_processing", "compliance", "legal", "financial", "quality_assurance", "custom"],
                            help="Category of workflow for organization"
                        )
                    
                    with col2:
                        new_workflow_id = st.text_input(
                            "Workflow ID *",
                            placeholder="e.g., process_invoice",
                            help="Unique identifier (lowercase, underscores only)"
                        )
                        new_workflow_priority = st.selectbox(
                            "Priority Level",
                            options=["normal", "high", "critical"],
                            help="Processing priority for this workflow"
                        )
                    
                    new_workflow_description = st.text_area(
                        "Description",
                        placeholder="Describe what this workflow does and when to use it...",
                        height=80,
                        help="Detailed description of the workflow purpose"
                    )
                    
                    # Form submission
                    col1, col2, col3 = st.columns([1, 1, 2])
                    with col1:
                        create_submitted = st.form_submit_button("✅ Create Workflow", use_container_width=True, type="primary")
                    with col2:
                        cancel_create = st.form_submit_button("❌ Cancel", use_container_width=True)
                    
                    if cancel_create:
                        # Reset to first workflow
                        st.session_state.global_workflow_selector = list(workflow_names.keys())[0] if workflow_names else None
                        st.rerun()
                    
                    if create_submitted:
                        # Validate required fields
                        if not new_workflow_name or not new_workflow_id or not new_workflow_type:
                            st.error("Please fill in all required fields (marked with *)")
                        elif not new_workflow_id.replace('_', '').isalnum() or ' ' in new_workflow_id:
                            st.error("Workflow ID must contain only letters, numbers, and underscores (no spaces)")
                        elif new_workflow_id in workflows:
                            st.error(f"Workflow ID '{new_workflow_id}' already exists. Please choose a different ID.")
                        else:
                            # Create the new workflow
                            try:
                                # Add to registry (this would normally save to file)
                                new_workflow_data = {
                                    'name': new_workflow_name,
                                    'type': new_workflow_type,
                                    'status': 'draft',
                                    'priority_level': new_workflow_priority,
                                    'description': new_workflow_description,
                                    'criteria_file': None,
                                    'template_file': None,
                                    'created_at': 'just now'
                                }
                                
                                # Store in session state for demo (in production, this would go to the registry)
                                if 'created_workflows' not in st.session_state:
                                    st.session_state.created_workflows = {}
                                st.session_state.created_workflows[new_workflow_id] = new_workflow_data
                                
                                st.success(f"✅ Workflow '{new_workflow_name}' created successfully!")
                                st.info("You can now select it from the dropdown and configure its criteria and templates.")
                                
                                # Auto-select the new workflow
                                st.session_state.global_workflow_selector = new_workflow_id
                                st.rerun()
                                
                            except Exception as e:
                                st.error(f"Error creating workflow: {e}")
                
        elif selected_workflow and selected_workflow in workflows:
            # Show selected workflow info card
            workflow = workflows[selected_workflow]
            
            with st.container():
                st.markdown(f"""
                <div style="
                    background: linear-gradient(90deg, #f0f2f6 0%, #ffffff 100%);
                    border: 2px solid #1f77b4;
                    border-radius: 10px;
                    padding: 15px;
                    margin: 10px 0;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                ">
                    <h4 style="color: #1f77b4; margin: 0 0 10px 0;">🎯 {workflow['name']}</h4>
                    <div style="display: flex; gap: 20px; margin-bottom: 10px;">
                        <span><strong>Type:</strong> {workflow.get('type', 'unknown')}</span>
                        <span><strong>Status:</strong> {workflow.get('status', 'unknown')}</span>
                    </div>
                    <div style="display: flex; gap: 20px;">
                        <span><strong>Criteria:</strong> {'✅ Available' if workflow.get('criteria_file') else '❌ Not set'}</span>
                        <span><strong>Template:</strong> {'✅ Available' if workflow.get('template_file') else '❌ Not set'}</span>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
        
        # Only show tabs if we have a real workflow selected (not creating new)
        if selected_workflow != "__CREATE_NEW__":
            st.markdown("---")
            
            # Tab interface with session state navigation
            # Determine active tab based on session state
            active_tab = st.session_state.get('active_workflow_tab', 0)
            
            tab1, tab2, tab3, tab4, tab5 = st.tabs(["📋 Registry", "⚡ Active Workflows", "📊 Criteria", "📝 Templates", "🧪 Testing"])
            
            with tab1:
                render_workflow_registry_v2(registry, selected_workflow)
            
            with tab2:
                render_registered_workflows(registry)
            
            with tab3:
                render_criterion_editor(registry, selected_workflow)
            
            with tab4:
                render_template_editor(registry, selected_workflow)
            
            with tab5:
                render_document_testing(registry, selected_workflow)
    
    except Exception as e:
        st.error(f"Error initializing workflow interface: {e}")
        
        # Fallback to original interface
        tab1, tab2, tab3 = st.tabs(["📋 Workflow Registry", "🤖 AI Managers", "📝 YAML Editor"])
        
        with tab1:
            render_workflow_registry()
        
        with tab2:
            render_ai_managers()
        
        with tab3:
            render_yaml_editor()

def render_workflow_registry():
    """Render workflow registry interface."""
    st.subheader("Workflow Registry")
    
    # Mock workflow data
    workflows = [
        {
            "name": "QA Processing",
            "description": "Quality assurance document processing workflow",
            "type": "document_processing",
            "status": "active",
            "last_run": "2025-01-09 10:30:00"
        },
        {
            "name": "MVR Analysis",
            "description": "Motor vehicle record analysis workflow",
            "type": "compliance",
            "status": "active",
            "last_run": "2025-01-09 09:15:00"
        },
        {
            "name": "Contract Review",
            "description": "Legal contract review and analysis",
            "type": "legal",
            "status": "draft",
            "last_run": None
        }
    ]
    
    # Workflow list
    for workflow in workflows:
        with st.expander(f"⚙️ {workflow['name']} ({workflow['type']})"):
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"**Description:** {workflow['description']}")
                st.write(f"**Status:** {workflow['status']}")
                if workflow['last_run']:
                    st.write(f"**Last Run:** {workflow['last_run']}")
                else:
                    st.write("**Last Run:** Never")
            
            with col2:
                if st.button(f"Edit", key=f"edit_{workflow['name']}"):
                    st.session_state.selected_workflow = workflow['name']
                    st.rerun()
                
                if st.button(f"Run", key=f"run_{workflow['name']}"):
                    st.info(f"Running workflow: {workflow['name']}")
    
    # Add new workflow
    st.subheader("Add New Workflow")
    
    with st.form("add_workflow_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            new_name = st.text_input("Workflow Name", placeholder="e.g., Invoice Processing")
            new_description = st.text_area("Description", placeholder="Describe the workflow purpose")
        
        with col2:
            new_type = st.selectbox("Workflow Type", ["document_processing", "compliance", "legal", "financial", "custom"])
            new_priority = st.selectbox("Priority", ["low", "medium", "high", "critical"])
        
        submitted = st.form_submit_button("Add Workflow")
        
        if submitted:
            if new_name and new_description:
                # Store workflow in session state for demo purposes
                if 'demo_workflows' not in st.session_state:
                    st.session_state.demo_workflows = []
                
                new_workflow = {
                    'id': f"wf_{len(st.session_state.demo_workflows) + 1:03d}",
                    'name': new_name,
                    'description': new_description,
                    'type': new_type,
                    'priority': new_priority,
                    'status': 'active',
                    'created_at': 'just now'
                }
                st.session_state.demo_workflows.append(new_workflow)
                
                st.success(f"Workflow '{new_name}' added successfully!")
                st.info("In production, this would integrate with the TidyLLM workflow optimizer gateway.")
                
                # Show a preview of what was created
                with st.expander("View Created Workflow", expanded=True):
                    st.json(new_workflow)
                    
            else:
                st.error("Please fill in all required fields.")

def render_ai_managers():
    """Render AI managers interface."""
    st.subheader("AI Managers")
    
    # Mock AI manager data
    ai_managers = [
        {
            "name": "Document Processor",
            "description": "Handles document processing workflows",
            "rag_systems": ["domain_knowledge", "work_history"],
            "models": ["claude-3-sonnet", "gpt-4"],
            "status": "active"
        },
        {
            "name": "Compliance Checker",
            "description": "Ensures regulatory compliance",
            "rag_systems": ["policy_database", "regulation_history"],
            "models": ["claude-3-opus"],
            "status": "active"
        }
    ]
    
    # AI manager list
    for manager in ai_managers:
        with st.expander(f"🤖 {manager['name']}"):
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.write(f"**Description:** {manager['description']}")
                st.write(f"**RAG Systems:** {', '.join(manager['rag_systems'])}")
                st.write(f"**Models:** {', '.join(manager['models'])}")
                st.write(f"**Status:** {manager['status']}")
            
            with col2:
                if st.button(f"Configure", key=f"config_{manager['name']}"):
                    st.session_state.selected_manager = manager['name']
                    st.rerun()
                
                if st.button(f"Test", key=f"test_{manager['name']}"):
                    st.info(f"Testing AI manager: {manager['name']}")
    
    # Create new AI manager
    st.subheader("Create New AI Manager")
    
    with st.form("create_manager_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            manager_name = st.text_input("Manager Name", placeholder="e.g., Legal Reviewer")
            manager_description = st.text_area("Description", placeholder="Describe the manager's purpose")
        
        with col2:
            rag_systems = st.multiselect(
                "RAG Systems",
                ["domain_knowledge", "work_history", "policy_database", "regulation_history", "custom"],
                default=["domain_knowledge"]
            )
            models = st.multiselect(
                "AI Models",
                ["claude-3-sonnet", "claude-3-opus", "gpt-4", "gpt-3.5-turbo"],
                default=["claude-3-sonnet"]
            )
        
        submitted = st.form_submit_button("Create AI Manager")
        
        if submitted:
            if manager_name and manager_description and rag_systems and models:
                # Store AI manager in session state for demo purposes
                if 'demo_ai_managers' not in st.session_state:
                    st.session_state.demo_ai_managers = []
                
                new_manager = {
                    'id': f"am_{len(st.session_state.demo_ai_managers) + 1:03d}",
                    'name': manager_name,
                    'description': manager_description,
                    'rag_systems': rag_systems,
                    'models': models,
                    'status': 'active',
                    'created_at': 'just now',
                    'performance': '95%'
                }
                st.session_state.demo_ai_managers.append(new_manager)
                
                st.success(f"AI Manager '{manager_name}' created successfully!")
                st.info("In production, this would integrate with TidyLLM's AI Processing Gateway to configure models and RAG systems.")
                
                # Show a preview of what was created
                with st.expander("View Created AI Manager", expanded=True):
                    st.json(new_manager)
                    
            else:
                st.error("Please fill in all required fields.")

def render_yaml_editor():
    """Render YAML editor interface."""
    st.subheader("YAML Editor")
    
    # Sample YAML content
    sample_yaml = """# TidyLLM Workflow Configuration
workflow:
  name: "Document Processing"
  version: "1.0.0"
  description: "Process and analyze documents"
  
  steps:
    - name: "upload"
      type: "file_upload"
      config:
        allowed_types: ["pdf", "docx", "txt"]
        max_size: "10MB"
    
    - name: "extract"
      type: "text_extraction"
      config:
        engine: "tesseract"
        language: "en"
    
    - name: "analyze"
      type: "ai_analysis"
      config:
        model: "claude-3-sonnet"
        prompt: "Analyze this document and extract key information"
    
    - name: "store"
      type: "knowledge_store"
      config:
        domain: "processed_documents"
        vectorize: true

  ai_managers:
    - name: "document_processor"
      rag_systems:
        - "domain_knowledge"
        - "work_history"
      models:
        - "claude-3-sonnet"
        - "gpt-4"
"""
    
    # YAML editor
    yaml_content = st.text_area(
        "YAML Configuration",
        value=sample_yaml,
        height=400,
        help="Edit the YAML configuration for your workflow"
    )
    
    # Editor controls
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("💾 Save Configuration", use_container_width=True):
            try:
                # Validate YAML
                parsed_yaml = yaml.safe_load(yaml_content)
                
                # Store the configuration in session state for demo purposes
                if 'saved_configurations' not in st.session_state:
                    st.session_state.saved_configurations = []
                
                config_entry = {
                    'id': f"config_{len(st.session_state.saved_configurations) + 1:03d}",
                    'name': parsed_yaml.get('name', 'Unnamed Configuration'),
                    'content': yaml_content,
                    'saved_at': 'just now',
                    'type': 'workflow_configuration'
                }
                st.session_state.saved_configurations.append(config_entry)
                
                st.success("Configuration saved successfully!")
                st.info("In production, this would integrate with TidyLLM's workflow optimizer to deploy the configuration.")
                
                # Show what was saved
                with st.expander("View Saved Configuration", expanded=False):
                    st.code(yaml_content, language='yaml')
                    
            except yaml.YAMLError as e:
                st.error(f"Invalid YAML: {e}")
    
    with col2:
        if st.button("✅ Validate YAML", use_container_width=True):
            try:
                parsed = yaml.safe_load(yaml_content)
                st.success("YAML is valid!")
                st.json(parsed)
            except yaml.YAMLError as e:
                st.error(f"YAML validation failed: {e}")
    
    with col3:
        if st.button("🔄 Reset to Default", use_container_width=True):
            st.rerun()
    
    # YAML preview
    st.subheader("YAML Preview")
    try:
        parsed_yaml = yaml.safe_load(yaml_content)
        st.json(parsed_yaml)
    except yaml.YAMLError as e:
        st.error(f"Invalid YAML: {e}")

def render_registered_workflows(registry):
    """Render the registered workflows list and statistics."""
    st.subheader("🔧 Active Registered Workflows")
    
    try:
        # Get registered workflows data
        workflows = registry.get_registered_workflows()
        stats = registry.get_workflow_stats()
        
        # Display overview statistics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Workflows", stats["total_workflows"])
        with col2:
            st.metric("Active", stats["active_workflows"])
        with col3:
            st.metric("New Structure", stats["new_structure_count"])
        with col4:
            st.metric("Average Success", f"{stats['average_success_rate']:.1%}")
        
        # Display workflow breakdown by category
        st.markdown("### Workflow Categories")
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**By Priority Level:**")
            for priority, count in stats["priority_levels"].items():
                priority_icon = {"critical": "🔴", "high": "🟡", "normal": "🟢", "low": "🔵"}.get(priority, "⚪")
                st.write(f"{priority_icon} {priority.title()}: {count}")
        
        with col2:
            st.markdown("**By Workflow Type:**")
            for wf_type, count in stats["workflow_types"].items():
                st.write(f"• {wf_type.title()}: {count}")
        
        # Display detailed workflow list
        st.markdown("### Detailed Workflow List")
        
        if workflows:
            # Create expandable sections for each workflow
            for workflow in workflows:
                status_icon = "✅" if workflow["status"] == "active" else "⚙️"
                priority_icon = {"critical": "🔴", "high": "🟡", "normal": "🟢", "low": "🔵"}.get(workflow["priority_level"], "⚪")
                
                with st.expander(f"{status_icon} {priority_icon} {workflow['workflow_name']} ({workflow['workflow_id']})"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.markdown(f"**Description:** {workflow['description']}")
                        st.markdown(f"**Type:** {workflow['workflow_type']}")
                        st.markdown(f"**Priority:** {workflow['priority_level']}")
                        st.markdown(f"**Processing Strategy:** {workflow['processing_strategy']}")
                        st.markdown(f"**Template Count:** {workflow['template_count']}")
                    
                    with col2:
                        st.markdown(f"**Status:** {workflow['status']}")
                        st.markdown(f"**Success Rate:** {workflow['success_rate']:.1%}")
                        st.markdown(f"**Executions:** {workflow['total_executions']}")
                        st.markdown(f"**New Structure:** {'Yes' if workflow['has_new_structure'] else 'No'}")
                        st.markdown(f"**Resources:** {'Available' if workflow['resources_available'] else 'None'}")
                    
                    # Show template files
                    if workflow['template_files']:
                        st.markdown("**Template Files:**")
                        for template in workflow['template_files']:
                            st.write(f"  • {template}.md")
                    
                    # Show criteria file
                    if workflow['criteria_file']:
                        st.markdown(f"**Criteria File:** {workflow['criteria_file']}")
                    
                    # Flow encoding
                    if workflow['flow_encoding']:
                        st.code(workflow['flow_encoding'], language="text")
        else:
            st.info("No workflows are currently registered.")
            
    except Exception as e:
        st.error(f"Error loading registered workflows: {e}")

def render_workflow_registry_v2(registry, selected_workflow=None):
    """Render enhanced workflow registry with real data."""
    st.subheader("Workflow Registry")
    
    try:
        workflows = registry.get_all_workflows()
        
        # Summary stats
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Workflows", len(workflows))
        with col2:
            active_count = sum(1 for w in workflows.values() if w.get('status') == 'active')
            st.metric("Active", active_count)
        with col3:
            with_criteria = sum(1 for w in workflows.values() if w.get('criteria_file'))
            st.metric("With Criteria", with_criteria)
        with col4:
            with_templates = sum(1 for w in workflows.values() if w.get('template_file'))
            st.metric("With Templates", with_templates)
        
        # Workflow list
        st.subheader("Registered Workflows")
        for workflow_id, workflow in workflows.items():
            with st.expander(f"⚙️ {workflow['name']} ({workflow_id})"):
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.write(f"**Type:** {workflow.get('type', 'unknown')}")
                    st.write(f"**Status:** {workflow.get('status', 'unknown')}")
                    st.write(f"**Criteria File:** {workflow.get('criteria_file', 'Not set')}")
                    st.write(f"**Template File:** {workflow.get('template_file', 'Not set')}")
                    
                    # Show metrics if available
                    if 'metrics' in workflow:
                        metrics = workflow['metrics']
                        st.write(f"**Executions:** {metrics.get('total_executions', 0)}")
                        st.write(f"**Success Rate:** {metrics.get('success_rate', 0):.1%}")
                
                with col2:
                    if st.button(f"Edit Criteria", key=f"criteria_{workflow_id}"):
                        st.session_state.edit_criteria_workflow = workflow_id
                        st.rerun()
                    
                    if st.button(f"Edit Template", key=f"template_{workflow_id}"):
                        st.session_state.edit_template_workflow = workflow_id
                        st.rerun()
                    
                    # Toggle status
                    current_status = workflow.get('status', 'inactive')
                    new_status = 'inactive' if current_status == 'active' else 'active'
                    if st.button(f"Set {new_status.title()}", key=f"toggle_{workflow_id}"):
                        registry.update_workflow_status(workflow_id, new_status)
                        st.rerun()
        
    except Exception as e:
        st.error(f"Error loading workflow registry: {e}")

def render_criterion_editor(registry, selected_workflow=None):
    """Render criterion editor interface."""
    st.subheader("Criterion Editor")
    
    if not selected_workflow:
        st.info("Please select a workflow from the dropdown above.")
        return
    
    # Workflow selection
    try:
        workflows = registry.get_all_workflows()
        workflow_names = {wid: w['name'] for wid, w in workflows.items()}
        
        if not workflows:
            st.info("No workflows found in registry.")
            return
        
        if selected_workflow:
            workflow = workflows[selected_workflow]
            st.write(f"**Editing criteria for:** {workflow['name']}")
            
            # Load existing criteria if available
            criteria_file = workflow.get('criteria_file')
            current_criteria = {}
            
            if criteria_file:
                try:
                    current_criteria = registry.load_criteria(selected_workflow)
                except Exception as e:
                    st.warning(f"Could not load existing criteria: {e}")
            
            # Criteria editor form
            st.subheader("JSON Criteria Configuration")
            
            # Show current criteria if exists
            if current_criteria:
                st.write("**Current Criteria:**")
                st.json(current_criteria)
            
            # Simple criteria editor
            with st.form(f"criteria_form_{selected_workflow}"):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Scoring Weights**")
                    document_type_weight = st.slider("Document Type Match", 0.0, 1.0, 
                                                    current_criteria.get('document_type_weight', 0.3))
                    content_relevance_weight = st.slider("Content Relevance", 0.0, 1.0, 
                                                        current_criteria.get('content_relevance_weight', 0.4))
                    format_compliance_weight = st.slider("Format Compliance", 0.0, 1.0, 
                                                        current_criteria.get('format_compliance_weight', 0.3))
                
                with col2:
                    st.write("**Threshold Values**")
                    min_confidence = st.slider("Minimum Confidence", 0.0, 1.0, 
                                             current_criteria.get('min_confidence', 0.5))
                    auto_accept_threshold = st.slider("Auto Accept Threshold", 0.0, 1.0, 
                                                     current_criteria.get('auto_accept_threshold', 0.8))
                
                # Required fields
                st.write("**Required Fields (one per line)**")
                required_fields_text = st.text_area(
                    "Required Fields",
                    value='\n'.join(current_criteria.get('required_fields', [])),
                    height=100
                )
                
                # Keywords
                st.write("**Keywords for Matching (one per line)**")
                keywords_text = st.text_area(
                    "Keywords",
                    value='\n'.join(current_criteria.get('keywords', [])),
                    height=100
                )
                
                # Advanced JSON editor
                st.write("**Advanced JSON Editor**")
                advanced_json = st.text_area(
                    "Full JSON Configuration",
                    value=json.dumps(current_criteria, indent=2) if current_criteria else "{}",
                    height=200
                )
                
                submitted = st.form_submit_button("Save Criteria")
                
                if submitted:
                    try:
                        # Build criteria from form
                        new_criteria = {
                            "document_type_weight": document_type_weight,
                            "content_relevance_weight": content_relevance_weight,
                            "format_compliance_weight": format_compliance_weight,
                            "min_confidence": min_confidence,
                            "auto_accept_threshold": auto_accept_threshold,
                            "required_fields": [field.strip() for field in required_fields_text.split('\n') if field.strip()],
                            "keywords": [keyword.strip() for keyword in keywords_text.split('\n') if keyword.strip()]
                        }
                        
                        # Try to parse advanced JSON and merge
                        try:
                            advanced_data = json.loads(advanced_json)
                            new_criteria.update(advanced_data)
                        except json.JSONDecodeError as e:
                            st.error(f"Invalid JSON in advanced editor: {e}")
                            return
                        
                        # Save criteria
                        registry.save_criteria(selected_workflow, new_criteria)
                        st.success(f"Criteria saved for {workflow['name']}")
                        st.rerun()
                        
                    except Exception as e:
                        st.error(f"Error saving criteria: {e}")
        
    except Exception as e:
        st.error(f"Error in criterion editor: {e}")

def render_template_editor(registry, selected_workflow=None):
    """Render template editor interface."""
    st.subheader("Template Editor")
    
    if not selected_workflow:
        st.info("Please select a workflow from the dropdown above.")
        return
    
    try:
        workflows = registry.get_all_workflows()
        workflow_names = {wid: w['name'] for wid, w in workflows.items()}
        
        if not workflows:
            st.info("No workflows found in registry.")
            return
        
        if selected_workflow:
            workflow = workflows[selected_workflow]
            st.write(f"**Editing template for:** {workflow['name']}")
            
            # Load existing template
            template_file = workflow.get('template_file')
            current_template = ""
            
            if template_file:
                try:
                    current_template = registry.load_template(selected_workflow)
                except Exception as e:
                    st.warning(f"Could not load existing template: {e}")
            
            # Template editor
            st.subheader("Markdown Template")
            
            # Show template path
            if template_file:
                st.info(f"Template file: {template_file}")
            
            # Template editor
            template_content = st.text_area(
                "Template Content (Markdown)",
                value=current_template,
                height=400,
                help="Use {variable_name} for dynamic content placeholders"
            )
            
            # Template controls
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button("💾 Save Template", use_container_width=True):
                    try:
                        registry.save_template(selected_workflow, template_content)
                        st.success("Template saved successfully!")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Error saving template: {e}")
            
            with col2:
                if st.button("👁️ Preview", use_container_width=True):
                    st.session_state.preview_template = template_content
            
            with col3:
                if st.button("🔄 Reset", use_container_width=True):
                    st.rerun()
            
            # Template preview
            if st.session_state.get('preview_template'):
                st.subheader("Template Preview")
                st.markdown(st.session_state.preview_template)
            
    except Exception as e:
        st.error(f"Error in template editor: {e}")

def render_document_testing(registry, selected_workflow=None):
    """Render document testing interface."""
    st.subheader("Document Testing")
    
    if selected_workflow:
        st.info(f"Testing documents against workflow: **{selected_workflow}**")
    
    st.markdown("""
    Test how PDF documents match against workflow criteria:
    """)
    
    # Initialize document intake if available
    intake_system = None
    if IntelligentDocumentIntake:
        try:
            intake_system = IntelligentDocumentIntake()
        except Exception as e:
            st.error(f"Failed to initialize document intake: {e}")
    
    if not intake_system:
        st.warning("Document intake system not available.")
        return
    
    # File upload
    uploaded_file = st.file_uploader("Upload PDF for testing", type=['pdf'])
    
    if uploaded_file:
        # Save uploaded file temporarily
        temp_path = f"temp_{uploaded_file.name}"
        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        
        try:
            st.subheader("Analysis Results")
            
            # Process document
            with st.spinner("Analyzing document..."):
                results = intake_system.process_document(temp_path, auto_route=False)
            
            # Show document profile
            st.write("**Document Profile:**")
            profile = results.get('document_profile', {})
            st.json(profile)
            
            # Show workflow matches
            st.write("**Workflow Matches:**")
            matches = results.get('workflow_matches', [])
            
            if matches:
                for match in matches[:5]:  # Show top 5 matches
                    with st.expander(f"🎯 {match['workflow_name']} - {match['confidence']:.1%} confidence"):
                        st.write(f"**Workflow ID:** {match['workflow_id']}")
                        st.write(f"**Confidence:** {match['confidence']:.1%}")
                        st.write(f"**Match Score:** {match['score']:.2f}")
                        
                        if 'criteria_match' in match:
                            st.write("**Criteria Breakdown:**")
                            st.json(match['criteria_match'])
                        
                        # Test routing
                        if st.button(f"Route to {match['workflow_name']}", 
                                   key=f"route_{match['workflow_id']}"):
                            st.info(f"Would route document to workflow: {match['workflow_name']}")
            else:
                st.warning("No workflow matches found for this document.")
            
            # Manual workflow assignment
            st.subheader("Manual Assignment")
            workflows = registry.get_all_workflows()
            workflow_options = {wid: w['name'] for wid, w in workflows.items()}
            
            manual_workflow = st.selectbox(
                "Manually assign to workflow:",
                options=[''] + list(workflow_options.keys()),
                format_func=lambda x: workflow_options.get(x, 'Select a workflow...')
            )
            
            if manual_workflow and st.button("Assign Document"):
                st.success(f"Document assigned to: {workflow_options[manual_workflow]}")
                st.info("In production, this would trigger the workflow processing.")
        
        except Exception as e:
            st.error(f"Error processing document: {e}")
        
        finally:
            # Clean up temp file
            if os.path.exists(temp_path):
                os.remove(temp_path)
