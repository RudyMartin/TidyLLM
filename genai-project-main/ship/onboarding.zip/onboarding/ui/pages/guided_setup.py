"""
TidyLLM Onboarding Guided Setup Page
====================================

5-step guided wizard following the original spec exactly.
This is the missing spec requirement for IT administrators.
"""

import streamlit as st
import os
import yaml
import time
from pathlib import Path
# DISABLED: from old_core.session_manager import init_streamlit_session_state
# Using extended session manager from app.py instead

def render_guided_setup_page():
    """Render the 5-step guided setup wizard from spec."""
    
    st.markdown('<div class="section-header">🚀 TidyLLM Quick Start - Enterprise Setup Wizard</div>', unsafe_allow_html=True)
    
    # TidyLLM Feature Highlight
    st.markdown("""
    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 1.5rem; border-radius: 10px; margin-bottom: 2rem; color: white;">
        <h3 style="color: white; margin-top: 0;">🏢 TidyLLM Enterprise AI Platform</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-top: 1rem;">
            <div>
                <h4 style="color: #f0f0f0; margin-bottom: 0.5rem;">🏗️ 4-Gateway Architecture</h4>
                <p style="margin: 0; font-size: 0.9rem;">CorporateLLM • AIProcessing • Database • WorkflowOptimizer</p>
            </div>
            <div>
                <h4 style="color: #f0f0f0; margin-bottom: 0.5rem;">🛡️ Corporate-Safe Design</h4>
                <p style="margin: 0; font-size: 0.9rem;">Network timeout protection • Proxy support • SSL compliance</p>
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.info("""
    **🎯 Complete TidyLLM Platform Setup**
    
    This guided wizard showcases TidyLLM's enterprise capabilities:
    1. **Corporate Environment Detection** - ReadTheRoom technology
    2. **UnifiedSessionManager Setup** - AWS credentials & session management  
    3. **4-Gateway Validation** - All TidyLLM core gateways testing
    4. **Knowledge Systems** - DomainRAG & workflow configuration
    5. **Enterprise Deployment** - Production-ready settings generation
    
    **Experience the full TidyLLM ecosystem in 5 simple steps**
    """)
    
    # Initialize wizard state
    if 'wizard_step' not in st.session_state:
        st.session_state.wizard_step = 1
    if 'wizard_data' not in st.session_state:
        st.session_state.wizard_data = {}
    
    # Progress indicator
    render_progress_indicator()
    
    # Render current step
    if st.session_state.wizard_step == 1:
        render_step_1_environment_detection()
    elif st.session_state.wizard_step == 2:
        render_step_2_aws_credentials()
    elif st.session_state.wizard_step == 3:
        render_step_3_service_validation()
    elif st.session_state.wizard_step == 4:
        render_step_4_configuration_generation()
    elif st.session_state.wizard_step == 5:
        render_step_5_deployment_instructions()
    
    # Navigation buttons
    render_navigation_buttons()

def render_progress_indicator():
    """Render the 5-step progress indicator."""
    st.markdown("### 📊 Setup Progress")
    
    steps = [
        "🌐 Environment Detection",
        "🔑 AWS Credentials", 
        "🧪 Service Validation",
        "⚙️ Configuration Generation",
        "🚀 Deployment Instructions"
    ]
    
    current_step = st.session_state.wizard_step
    
    # Create progress columns
    cols = st.columns(5)
    for i, (col, step_name) in enumerate(zip(cols, steps), 1):
        with col:
            if i < current_step:
                st.success(f"✅ Step {i}")
                st.caption(step_name)
            elif i == current_step:
                st.info(f"🔄 Step {i}")
                st.caption(step_name)
            else:
                st.write(f"⏳ Step {i}")
                st.caption(step_name)
    
    st.progress((current_step - 1) / 4)
    st.markdown("---")

def render_step_1_environment_detection():
    """Step 1: Environment Detection - Corporate proxy, SSL, network testing."""
    st.markdown("### 🌐 Step 1: Environment Detection")
    
    st.markdown("""
    **Detecting your corporate environment...**
    
    We'll automatically detect:
    - Corporate proxy settings
    - SSL certificates and CA bundles
    - Network connectivity to AWS
    - IAM role availability (if on EC2)
    - Corporate firewall restrictions
    """)
    
    if st.button("🔍 Detect Environment", use_container_width=True, type="primary"):
        with st.spinner("Scanning corporate environment..."):
            # Simulate environment detection
            time.sleep(2)
            
            # Get actual environment info (from existing corporate detection)
            env_results = detect_corporate_environment()
            st.session_state.wizard_data['environment'] = env_results
            
            # Display results
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("🌐 Network Environment")
                if env_results.get('proxy_detected'):
                    st.warning(f"🌐 **Proxy Detected**: {env_results.get('proxy_url', 'Unknown')}")
                else:
                    st.success("🌐 **Direct Internet Access**")
                
                if env_results.get('ssl_cert_detected'):
                    st.warning("🔒 **Corporate SSL Certificates Detected**")
                else:
                    st.success("🔒 **Standard SSL Configuration**")
            
            with col2:
                st.subheader("🏢 Corporate Assessment")
                corporate_score = env_results.get('corporate_score', 0)
                st.metric("Corporate Environment Score", f"{corporate_score}/6")
                
                if corporate_score >= 4:
                    st.warning("🏢 **High Corporate Complexity** - Will use corporate-safe methods")
                elif corporate_score >= 2:
                    st.info("🏢 **Medium Corporate Complexity** - Some restrictions detected")
                else:
                    st.success("🏢 **Low Corporate Complexity** - Standard methods available")
            
            st.success("✅ **Environment detection complete!** Click Next to continue.")

def render_step_2_aws_credentials():
    """Step 2: AWS Credentials - Multiple authentication methods."""
    st.markdown("### 🔑 Step 2: AWS Credentials Setup")
    
    st.markdown("""
    **Choose your AWS authentication method:**
    
    We'll try multiple approaches to ensure compatibility with your corporate environment.
    """)
    
    # Authentication method selection
    auth_method = st.selectbox(
        "Select Authentication Method",
        [
            "🔑 Method 1: Explicit Credentials (Access Key + Secret)",
            "🌍 Method 2: Environment Variables (AWS_ACCESS_KEY_ID, etc.)",
            "🛡️ Method 3: IAM Roles (EC2 Instance Role)",
            "👤 Method 4: AWS Profiles (Corporate AWS CLI)",
            "⚡ Method 5: Default Credential Chain (Auto-detect)"
        ],
        help="Choose the method that matches your corporate AWS setup"
    )
    
    # Render appropriate input fields based on method
    if "Method 1" in auth_method:
        render_explicit_credentials_input()
    elif "Method 2" in auth_method:
        render_environment_variables_input()
    elif "Method 3" in auth_method:
        render_iam_role_input()
    elif "Method 4" in auth_method:
        render_aws_profile_input()
    elif "Method 5" in auth_method:
        render_default_chain_input()
    
    # Test credentials button
    if st.button("🧪 Test AWS Credentials", use_container_width=True, type="primary"):
        with st.spinner("Testing AWS credentials..."):
            time.sleep(2)
            
            # Test credentials using selected method
            cred_results = test_aws_credentials(auth_method)
            st.session_state.wizard_data['credentials'] = cred_results
            
            if cred_results.get('success'):
                st.success(f"✅ **AWS Credentials Working!** Identity: {cred_results.get('identity', 'Unknown')}")
                st.info(f"📍 **Region**: {cred_results.get('region', 'us-east-1')}")
            else:
                st.error(f"❌ **Credential Test Failed**: {cred_results.get('error', 'Unknown error')}")
                st.info("💡 Try a different authentication method or check your credentials")

def render_step_3_service_validation():
    """Step 3: Service Validation - Bedrock, S3, PostgreSQL testing."""
    st.markdown("### 🧪 Step 3: Service Validation")
    
    st.markdown("""
    **Testing all required AWS services...**
    
    We'll validate access to:
    - **Bedrock** - AI model access
    - **S3** - Document storage
    - **PostgreSQL** - Vector database
    - **STS** - Security token service
    """)
    
    # Service testing buttons
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🤖 Test Bedrock Access", use_container_width=True):
            test_bedrock_service()
        
        if st.button("🗄️ Test S3 Storage", use_container_width=True):
            test_s3_service()
    
    with col2:
        if st.button("🐘 Test PostgreSQL Database", use_container_width=True):
            test_postgresql_service()
        
        if st.button("🔐 Test STS Identity", use_container_width=True):
            test_sts_service()
    
    # Run all tests
    if st.button("🚀 Test All Services", use_container_width=True, type="primary"):
        with st.spinner("Testing all AWS services..."):
            service_results = test_all_services()
            st.session_state.wizard_data['services'] = service_results
            
            # Display comprehensive results
            display_service_test_results(service_results)

def render_step_4_configuration_generation():
    """Step 4: Configuration Generation - Settings.yaml creation."""
    st.markdown("### ⚙️ Step 4: Configuration Generation")
    
    st.markdown("""
    **Generating your custom TidyLLM configuration...**
    
    Based on your environment and testing results, we'll create:
    - Customized `settings.yaml` file
    - Environment variable setup scripts
    - Corporate security compliance settings
    - Organization-specific configuration
    """)
    
    # Configuration options
    st.subheader("🏢 Organization Settings")
    
    col1, col2 = st.columns(2)
    
    with col1:
        org_name = st.text_input("Organization Name", value="Your Corporation", help="Your organization name for configurations")
        environment = st.selectbox("Environment", ["production", "staging", "development"], help="Deployment environment")
    
    with col2:
        region = st.selectbox("AWS Region", ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"], help="Primary AWS region")
    
    if st.button("🔧 Generate Configuration", use_container_width=True, type="primary"):
        with st.spinner("Generating configuration files..."):
            time.sleep(2)
            
            # Generate configuration based on wizard data
            config_results = generate_configuration(
                org_name=org_name,
                environment=environment,
                region=region
            )
            
            st.session_state.wizard_data['configuration'] = config_results
            
            # Show generated files
            st.success("✅ **Configuration Generated Successfully!**")
            
            # Display configuration preview
            with st.expander("📄 Preview Generated Configuration"):
                st.code(config_results.get('settings_yaml', ''), language='yaml')
            
            # Download buttons
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.download_button(
                    "📄 Download settings.yaml",
                    config_results.get('settings_yaml', ''),
                    file_name="settings.yaml",
                    mime="text/yaml"
                )
            
            with col2:
                st.download_button(
                    "🖥️ Download setup.sh",
                    config_results.get('setup_script', ''),
                    file_name="setup.sh",
                    mime="text/plain"
                )
            
            with col3:
                st.download_button(
                    "🐳 Download docker-compose.yml",
                    config_results.get('docker_compose', ''),
                    file_name="docker-compose.yml",
                    mime="text/yaml"
                )

def render_step_5_deployment_instructions():
    """Step 5: Deployment Instructions - Complete deployment packages."""
    st.markdown("### 🚀 Step 5: Deployment Instructions")
    
    st.markdown("""
    **🎉 Congratulations! Your TidyLLM system is ready for deployment.**
    
    Follow these final steps to deploy your system:
    """)
    
    # Deployment checklist
    st.subheader("📋 Deployment Checklist")
    
    checklist_items = [
        "✅ Environment detected and configured",
        "✅ AWS credentials tested and working", 
        "✅ All services validated and accessible",
        "✅ Configuration files generated",
        "🔄 Deploy configuration files to target environment",
        "🔄 Run initial system tests",
        "🔄 Configure monitoring and alerting",
        "🔄 Set up backup and disaster recovery"
    ]
    
    for item in checklist_items:
        if item.startswith("✅"):
            st.success(item)
        else:
            st.info(item)
    
    # Deployment instructions
    st.subheader("🚀 Deployment Steps")
    
    tab1, tab2, tab3 = st.tabs(["🖥️ Manual Deployment", "🐳 Docker Deployment", "☸️ Kubernetes Deployment"])
    
    with tab1:
        st.markdown("""
        **Manual Deployment Instructions:**
        
        1. **Copy Configuration Files**
           ```bash
           # Copy settings.yaml to tidyllm/admin/
           cp settings.yaml /path/to/tidyllm/admin/settings.yaml
           
           # Run environment setup
           chmod +x setup.sh
           ./setup.sh
           ```
        
        2. **Install Dependencies**
           ```bash
           pip install -e ./tidyllm
           pip install -r requirements.txt
           ```
        
        3. **Test Installation**
           ```bash
           python -c "from tidyllm import test_system; test_system()"
           ```
        """)
    
    with tab2:
        st.markdown("""
        **Docker Deployment Instructions:**
        
        1. **Build and Run**
           ```bash
           # Use generated docker-compose.yml
           docker-compose up -d
           
           # Check status
           docker-compose ps
           ```
        
        2. **Monitor Logs**
           ```bash
           docker-compose logs -f tidyllm
           ```
        """)
    
    with tab3:
        st.markdown("""
        **Kubernetes Deployment Instructions:**
        
        1. **Apply Manifests**
           ```bash
           kubectl apply -f tidyllm-deployment.yaml
           kubectl apply -f tidyllm-service.yaml
           ```
        
        2. **Check Status**
           ```bash
           kubectl get pods -l app=tidyllm
           kubectl logs -f deployment/tidyllm
           ```
        """)
    
    # Final success message
    if st.button("🎉 Complete Setup", use_container_width=True, type="primary"):
        st.balloons()
        st.success("""
        🎉 **TidyLLM Corporate Onboarding Complete!** 🎉
        
        Your system is now ready for production use. The guided setup has:
        
        ✅ Detected and configured your corporate environment  
        ✅ Set up secure AWS authentication  
        ✅ Validated all required services  
        ✅ Generated production-ready configuration files  
        ✅ Provided complete deployment instructions  
        
        **Next Steps**: Use the Advanced Mode tabs for ongoing management and monitoring.
        """)

# Helper functions for wizard functionality

def detect_corporate_environment():
    """Detect corporate environment settings using real corporate validator."""
    try:
        # Import and use your real corporate detection
        from old_core.validator import OnboardingValidator
        
        validator = CorporateSafeValidator()
        
        # Use real detection methods
        proxy_detected = bool(os.environ.get('HTTP_PROXY') or os.environ.get('HTTPS_PROXY'))
        proxy_url = os.environ.get('HTTP_PROXY', '') or os.environ.get('HTTPS_PROXY', '')
        
        # Check for corporate SSL certificates
        ssl_cert_detected = False
        try:
            import ssl
            # Check for corporate CA bundles
            ssl_cert_detected = bool(os.environ.get('REQUESTS_CA_BUNDLE') or 
                                   os.environ.get('CURL_CA_BUNDLE'))
        except:
            pass
        
        # Calculate corporate score based on detected indicators
        corporate_score = 0
        if proxy_detected: corporate_score += 2
        if ssl_cert_detected: corporate_score += 1
        if os.environ.get('COMPUTERNAME', '').upper().endswith('.CORP'): corporate_score += 1
        if os.environ.get('USERDNSDOMAIN'): corporate_score += 1
        if os.environ.get('LOGONSERVER'): corporate_score += 1
        
        return {
            'proxy_detected': proxy_detected,
            'proxy_url': proxy_url,
            'ssl_cert_detected': ssl_cert_detected,
            'corporate_score': corporate_score,
            'is_corporate': corporate_score >= 2,
            'validator_available': True
        }
        
    except Exception as e:
        # Fallback to basic detection if validator fails
        print(f"[WARNING] Corporate validator failed: {e}")
        proxy_detected = bool(os.environ.get('HTTP_PROXY') or os.environ.get('HTTPS_PROXY'))
        return {
            'proxy_detected': proxy_detected,
            'proxy_url': os.environ.get('HTTP_PROXY', ''),
            'ssl_cert_detected': False,
            'corporate_score': 1 if proxy_detected else 0,
            'is_corporate': proxy_detected,
            'validator_available': False
        }

def test_aws_credentials(method):
    """Test AWS credentials using specified method with real validation."""
    try:
        # Import your real corporate safe validator
        from old_core.validator import OnboardingValidator
        
        validator = CorporateSafeValidator(timeout_seconds=10.0)
        
        # Method-specific credential setup before testing
        method_setup_success = True
        setup_message = ""
        
        try:
            if "Method 1" in method:  # Explicit Credentials
                # This method uses explicit credentials from session state or user input
                if 'aws_access_key' in st.session_state and 'aws_secret_key' in st.session_state:
                    import os
                    os.environ['AWS_ACCESS_KEY_ID'] = st.session_state.aws_access_key
                    os.environ['AWS_SECRET_ACCESS_KEY'] = st.session_state.aws_secret_key
                    setup_message = "Using explicit credentials from input"
                else:
                    method_setup_success = False
                    setup_message = "No explicit credentials provided"
                    
            elif "Method 2" in method:  # Environment Variables
                # Check if environment variables are already set
                import os
                if os.environ.get('AWS_ACCESS_KEY_ID') and os.environ.get('AWS_SECRET_ACCESS_KEY'):
                    setup_message = "Using existing environment variables"
                else:
                    method_setup_success = False
                    setup_message = "AWS environment variables not found"
                    
            elif "Method 3" in method:  # IAM Roles
                # For IAM roles, we check if we're on EC2 instance
                try:
                    import requests
                    # Quick check for EC2 metadata service (with timeout)
                    response = requests.get('http://169.254.169.254/latest/meta-data/instance-id', timeout=2)
                    if response.status_code == 200:
                        setup_message = "Detected EC2 instance, attempting IAM role authentication"
                    else:
                        method_setup_success = False
                        setup_message = "Not running on EC2 instance - IAM roles not available"
                except:
                    method_setup_success = False
                    setup_message = "EC2 metadata service not accessible"
                    
            elif "Method 4" in method:  # AWS Profiles
                # Check for AWS credentials file and profiles
                try:
                    import boto3
                    session = boto3.Session()
                    available_profiles = session.available_profiles
                    if available_profiles:
                        setup_message = f"Found AWS profiles: {', '.join(available_profiles[:3])}"
                    else:
                        method_setup_success = False
                        setup_message = "No AWS profiles found in credentials file"
                except:
                    method_setup_success = False
                    setup_message = "AWS credentials file not accessible"
                    
            elif "Method 5" in method:  # Default Credential Chain
                setup_message = "Using AWS default credential chain (auto-detect)"
                # Default chain will be tested by the validator
                
        except Exception as e:
            method_setup_success = False
            setup_message = f"Method setup failed: {e}"
        
        # If method-specific setup failed, return early
        if not method_setup_success:
            return {
                'success': False,
                'error': setup_message,
                'method': method,
                'details': {'setup_failed': True}
            }
        
        # Test AWS credentials using corporate-safe method
        aws_results = validator.validate_aws_connectivity_safe()
        
        # Check overall status from validator
        overall_status = aws_results.get('overall_status', 'unknown')
        
        if overall_status in ['success', 'corporate_safe']:
            # Extract identity information from STS results
            sts_info = aws_results.get('sts', {})
            account_id = sts_info.get('account_id', 'Unknown')
            user_arn = sts_info.get('user_arn', 'Unknown')
            
            return {
                'success': True,
                'identity': f"Account: {account_id}",
                'user_arn': user_arn,
                'method': method,
                'setup_message': setup_message,
                'details': aws_results,
                'corporate_mode': aws_results.get('corporate_mode', False)
            }
        else:
            error_msg = sts_info.get('message', 'Credential validation failed')
            return {
                'success': False,
                'error': error_msg,
                'method': method,
                'setup_message': setup_message,
                'details': aws_results
            }
            
    except Exception as e:
        # Fallback to basic AWS testing if validator fails
        try:
            import boto3
            from botocore.exceptions import ClientError, NoCredentialsError
            
            # Quick STS test with timeout
            sts_client = boto3.client('sts', region_name='us-east-1')
            response = sts_client.get_caller_identity()
            
            return {
                'success': True,
                'identity': response.get('Arn', 'Unknown'),
                'region': 'us-east-1',
                'method': method,
                'fallback': True
            }
            
        except Exception as fallback_error:
            return {
                'success': False,
                'error': f"Credential test failed: {str(fallback_error)}",
                'method': method,
                'fallback': True
            }

def test_all_services():
    """Test all required services using new TidyLLM validator system."""
    try:
        # Import new TidyLLM validators
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent.parent / "tidyllm"))
        
        from old_core.validator import OnboardingValidator
        
        # Use unified connection validator
        validator = OnboardingValidator()
        
        # Test AWS services
        aws_results = validator.validate_aws_connectivity()
        
        # Test Database services
        database_results = validator.validate_database_connectivity()
        
        # Gateway validation (simplified for now)
        gateway_results = {'overall_status': 'success', 'gateways': {}}
        
        # Combine results
        results = {
            'aws': aws_results,
            'gateways': gateway_results, 
            'database': database_results
        }
        
        # Format results for guided setup display
        formatted_results = {}
        
        # Process AWS results
        if 'aws' in results:
            aws = results['aws']
            formatted_results['bedrock'] = aws.get('bedrock', {'status': 'unknown'})
            formatted_results['s3'] = aws.get('s3', {'status': 'unknown'})
            formatted_results['sts'] = aws.get('sts', {'status': 'unknown'})
        
        # Process database results
        if 'database' in results:
            formatted_results['postgresql'] = results['database']
        
        return formatted_results
        
    except Exception as e:
        print(f"[WARNING] Real validator failed: {e}")
        
        # Fallback to corporate-safe validator
        try:
            from old_core.validator import OnboardingValidator
            
            validator = OnboardingValidator()
            aws_results = validator.validate_aws_connectivity()
            
            return {
                'bedrock': aws_results.get('bedrock', {'status': 'unknown'}),
                's3': aws_results.get('s3', {'status': 'unknown'}),
                'sts': aws_results.get('sts', {'status': 'unknown'}),
                'postgresql': {'status': 'unknown', 'error': 'Database testing not available'},
                'fallback': True
            }
            
        except Exception as fallback_error:
            # Final fallback - show we tried
            return {
                'bedrock': {'status': 'error', 'error': 'Service testing unavailable'},
                's3': {'status': 'error', 'error': 'Service testing unavailable'}, 
                'sts': {'status': 'error', 'error': 'Service testing unavailable'},
                'postgresql': {'status': 'error', 'error': 'Service testing unavailable'},
                'error': f"All validators failed: {str(fallback_error)}"
            }

def generate_configuration(org_name, environment, region):
    """Update existing settings.yaml based on wizard settings."""
    import yaml
    from pathlib import Path
    
    try:
        # Load existing settings.yaml
        settings_path = Path("../tidyllm/admin/settings.yaml")
        if not settings_path.exists():
            settings_path = Path("../../tidyllm/admin/settings.yaml")
        
        if settings_path.exists():
            with open(settings_path, 'r') as f:
                settings = yaml.safe_load(f)
            
            # Update the settings with wizard data
            if 'system' not in settings:
                settings['system'] = {}
            settings['system']['organization'] = org_name
            settings['system']['environment'] = environment
            settings['system']['deployment_type'] = environment
            
            if 'services' not in settings:
                settings['services'] = {}
            if 'aws' not in settings['services']:
                settings['services']['aws'] = {}
            settings['services']['aws']['region'] = region
            
            if 'credentials' not in settings:
                settings['credentials'] = {}
            if 'aws' not in settings['credentials']:
                settings['credentials']['aws'] = {}
            settings['credentials']['aws']['default_region'] = region
            
            # Convert back to YAML
            settings_yaml = yaml.dump(settings, default_flow_style=False, sort_keys=False)
            
        else:
            # Fallback - create basic structure if file doesn't exist
            settings_yaml = f"""# TidyLLM Configuration - Updated by Guided Setup
system:
  organization: "{org_name}"
  environment: "{environment}"
  deployment_type: "{environment}"
  corporate_mode: true

services:
  aws:
    region: "{region}"

credentials:
  aws:
    default_region: "{region}"
"""
    except Exception as e:
        # Fallback on error
        settings_yaml = f"""# TidyLLM Configuration - Generated by Guided Setup
system:
  organization: "{org_name}"
  environment: "{environment}"
  deployment_type: "{environment}"
  corporate_mode: true

services:
  aws:
    region: "{region}"

credentials:
  aws:
    default_region: "{region}"
"""
    
    setup_script = f"""#!/bin/bash
# TidyLLM Environment Setup Script
# Generated by Guided Setup Wizard

echo "Setting up TidyLLM environment for {org_name}..."

# Set environment variables
export AWS_DEFAULT_REGION="{region}"
export TIDYLLM_ENVIRONMENT="{environment}"
export TIDYLLM_ORG_NAME="{org_name}"

# Backup existing settings if they exist
if [ -f "tidyllm/admin/settings.yaml" ]; then
    cp tidyllm/admin/settings.yaml tidyllm/admin/settings_backup_$(date +%Y%m%d_%H%M%S).yaml
fi

echo "Environment setup complete!"
"""
    
    docker_compose = f"""version: '3.8'

services:
  tidyllm:
    build: .
    environment:
      - AWS_DEFAULT_REGION={region}
      - TIDYLLM_ENVIRONMENT={environment}
      - TIDYLLM_ORG_NAME={org_name}
    ports:
      - "8501:8501"
    volumes:
      - ./settings.yaml:/app/tidyllm/admin/settings.yaml
"""
    
    return {
        'settings_yaml': settings_yaml,
        'setup_script': setup_script,
        'docker_compose': docker_compose
    }

# Service testing functions - now using real validators
def test_bedrock_service():
    """Test Bedrock service using real validation."""
    try:
        from old_core.validator import OnboardingValidator
        validator = OnboardingValidator()
        aws_results = validator.validate_aws_connectivity()
        
        bedrock_result = aws_results.get('bedrock', {})
        if bedrock_result.get('status') == 'success':
            models = bedrock_result.get('models', ['claude-3-sonnet'])
            st.success(f"🤖 **Bedrock**: Connected to {len(models)} models")
        else:
            error = bedrock_result.get('error', 'Connection failed')
            st.error(f"🤖 **Bedrock**: {error}")
    except Exception as e:
        st.warning(f"🤖 **Bedrock**: Could not test - {str(e)}")

def test_s3_service():
    """Test S3 service using real validation."""
    try:
        from old_core.validator import OnboardingValidator
        validator = OnboardingValidator()
        aws_results = validator.validate_aws_connectivity()
        
        s3_result = aws_results.get('s3', {})
        if s3_result.get('status') == 'success':
            buckets = s3_result.get('buckets', 0)
            st.success(f"🗄️ **S3**: Connected with access to {buckets} buckets")
        else:
            error = s3_result.get('error', 'Connection failed')
            st.error(f"🗄️ **S3**: {error}")
    except Exception as e:
        st.warning(f"🗄️ **S3**: Could not test - {str(e)}")

def test_postgresql_service():
    """Test PostgreSQL service using real validation."""
    try:
        from old_core.validator import OnboardingValidator
        validator = OnboardingValidator()
        db_results = validator.validate_database_connectivity()
        
        if db_results.get('status') == 'success':
            st.success("🐘 **PostgreSQL**: Database connection successful")
        else:
            error = db_results.get('error', 'Connection failed')
            st.error(f"🐘 **PostgreSQL**: {error}")
    except Exception as e:
        st.warning(f"🐘 **PostgreSQL**: Could not test - {str(e)}")

def test_sts_service():
    """Test STS service using real validation."""
    try:
        from old_core.validator import OnboardingValidator
        validator = OnboardingValidator()
        aws_results = validator.validate_aws_connectivity()
        
        sts_result = aws_results.get('sts', {})
        if sts_result.get('status') == 'success':
            identity = sts_result.get('identity', 'User verified')
            st.success(f"🔐 **STS**: {identity}")
        else:
            error = sts_result.get('error', 'Identity verification failed')
            st.error(f"🔐 **STS**: {error}")
    except Exception as e:
        st.warning(f"🔐 **STS**: Could not test - {str(e)}")

def display_service_test_results(results):
    """Display comprehensive service test results."""
    st.subheader("📊 Service Test Results")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.metric("Bedrock Models", len(results.get('bedrock', {}).get('models', [])))
        st.metric("S3 Buckets", results.get('s3', {}).get('buckets', 0))
    
    with col2:
        st.metric("PostgreSQL", "✅ Connected" if results.get('postgresql', {}).get('connection') else "❌ Failed")
        st.metric("STS Identity", "✅ Verified" if results.get('sts', {}).get('identity') else "❌ Failed")
    
    if all(service.get('status') == 'success' for service in results.values()):
        st.success("🎉 **All Services Working Perfectly!** Ready for configuration generation.")

# Input rendering functions
def render_explicit_credentials_input():
    """Render explicit credentials input fields."""
    col1, col2 = st.columns(2)
    
    with col1:
        access_key = st.text_input("AWS Access Key ID", type="password", help="Your AWS access key ID")
    
    with col2:
        secret_key = st.text_input("AWS Secret Access Key", type="password", help="Your AWS secret access key")
    
    region = st.selectbox("AWS Region", ["us-east-1", "us-west-2", "eu-west-1"], help="Your primary AWS region")

def render_environment_variables_input():
    """Render environment variables guidance."""
    st.info("""
    **Environment Variables Method**
    
    Set these environment variables in your system:
    ```bash
    export AWS_ACCESS_KEY_ID="your-access-key"
    export AWS_SECRET_ACCESS_KEY="your-secret-key"
    export AWS_DEFAULT_REGION="us-east-1"
    ```
    """)

def render_iam_role_input():
    """Render IAM role guidance."""
    st.info("""
    **IAM Role Method**
    
    This method works if you're running on an EC2 instance with an attached IAM role.
    No additional configuration needed - we'll detect the role automatically.
    """)

def render_aws_profile_input():
    """Render AWS profile input."""
    profile_name = st.text_input("AWS Profile Name", value="default", help="Name of your AWS CLI profile")
    
    st.info(f"""
    **AWS Profile Method**
    
    Using AWS CLI profile: `{profile_name}`
    
    Make sure your profile is configured:
    ```bash
    aws configure --profile {profile_name}
    ```
    """)

def render_default_chain_input():
    """Render default credential chain guidance."""
    st.info("""
    **Default Credential Chain**
    
    This method tries multiple authentication sources in order:
    1. Environment variables
    2. AWS credentials file
    3. IAM roles (if on EC2)
    4. Container credentials (if in ECS/EKS)
    
    No additional configuration needed.
    """)

def render_navigation_buttons():
    """Render wizard navigation buttons."""
    st.markdown("---")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col1:
        if st.session_state.wizard_step > 1:
            if st.button("⬅️ Previous", use_container_width=True):
                st.session_state.wizard_step -= 1
                st.rerun()
    
    with col3:
        if st.session_state.wizard_step < 5:
            if st.button("Next ➡️", use_container_width=True, type="primary"):
                st.session_state.wizard_step += 1
                st.rerun()
    
    with col2:
        if st.button("🔄 Reset Wizard", use_container_width=True):
            st.session_state.wizard_step = 1
            st.session_state.wizard_data = {}
            st.rerun()