"""
TidyLLM Native Configuration Interface
======================================

Configuration and setup using TidyLLM's native components and gateway architecture.
"""

import streamlit as st
import yaml
import os
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

from tidyllm.gateways.gateway_registry import get_global_registry
# DISABLED: from tidyllm.infrastructure.session.unified import UnifiedSessionManager
# Using extended session manager from app.py instead
from tidyllm.infrastructure.config import ConfigManager

class TidyLLMConfigInterface:
    """Native TidyLLM configuration interface."""
    
    def __init__(self):
        """Initialize with TidyLLM components."""
        self.registry = get_global_registry()
        self.session_manager = st.session_state.get('tidyllm_session_manager')
        self.config_manager = ConfigManager() if hasattr(tidyllm, 'ConfigManager') else None
        self.settings_path = Path(__file__).parent.parent.parent.parent / "tidyllm" / "admin" / "settings.yaml"
        self._init_session_state()
    
    def _init_session_state(self):
        """Initialize configuration session state."""
        if 'tidyllm_config' not in st.session_state:
            st.session_state.tidyllm_config = self._load_current_config()
        if 'config_modified' not in st.session_state:
            st.session_state.config_modified = False
    
    def _load_current_config(self) -> Dict[str, Any]:
        """Load current TidyLLM configuration."""
        if self.settings_path.exists():
            try:
                with open(self.settings_path, 'r') as f:
                    return yaml.safe_load(f) or {}
            except Exception as e:
                st.error(f"Failed to load configuration: {e}")
                return {}
        return {}
    
    def render(self):
        """Render the TidyLLM configuration interface."""
        st.title("🔧 TidyLLM System Configuration")
        st.markdown("**Native Gateway Configuration & Setup**")
        
        # Show current system status
        self._render_system_status()
        
        # Configuration tabs
        tabs = st.tabs([
            "🚀 Quick Setup",
            "🔌 Gateway Config",
            "🔑 AWS Settings",
            "💾 Database Config",
            "⚙️ Workflow Settings",
            "🔒 Security",
            "📊 Advanced"
        ])
        
        with tabs[0]:
            self._render_quick_setup()
        
        with tabs[1]:
            self._render_gateway_config()
        
        with tabs[2]:
            self._render_aws_settings()
        
        with tabs[3]:
            self._render_database_config()
        
        with tabs[4]:
            self._render_workflow_settings()
        
        with tabs[5]:
            self._render_security_settings()
        
        with tabs[6]:
            self._render_advanced_settings()
    
    def _render_system_status(self):
        """Render current system status."""
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            services = self.registry.list_services()
            active = sum(1 for s in services if s.get('initialized'))
            if active == len(services) and services:
                st.success(f"✅ {active} Gateways Active")
            else:
                st.warning(f"⚠️ {active}/{len(services)} Active")
        
        with col2:
            if self.session_manager:
                try:
                    self.session_manager.get_s3_client()
                    st.success("✅ AWS Connected")
                except:
                    st.error("❌ AWS Disconnected")
            else:
                st.warning("⚠️ No Session")
        
        with col3:
            config_exists = self.settings_path.exists()
            if config_exists:
                st.success("✅ Config Loaded")
            else:
                st.warning("⚠️ No Config")
        
        with col4:
            if st.session_state.config_modified:
                st.warning("⚠️ Unsaved Changes")
            else:
                st.info("💾 Config Saved")
    
    def _render_quick_setup(self):
        """Render quick setup wizard."""
        st.markdown("### 🚀 Quick Setup Wizard")
        
        st.info("""
        **Get TidyLLM running in 3 steps:**
        1. Choose deployment environment
        2. Configure AWS credentials
        3. Initialize gateways
        """)
        
        # Step 1: Environment selection
        st.markdown("#### Step 1: Select Environment")
        environment = st.selectbox(
            "Deployment Environment",
            ["Development", "Staging", "Production", "Air-Gapped"],
            help="Choose your deployment environment type"
        )
        
        # Apply environment template
        if st.button("Apply Environment Template", type="primary"):
            self._apply_environment_template(environment.lower())
        
        st.markdown("---")
        
        # Step 2: AWS Configuration
        st.markdown("#### Step 2: AWS Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            aws_key = st.text_input(
                "AWS Access Key ID",
                value=st.session_state.tidyllm_config.get('aws', {}).get('access_key_id', ''),
                type="password"
            )
        
        with col2:
            aws_secret = st.text_input(
                "AWS Secret Access Key",
                value=st.session_state.tidyllm_config.get('aws', {}).get('secret_access_key', ''),
                type="password"
            )
        
        aws_region = st.selectbox(
            "AWS Region",
            ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"],
            index=0
        )
        
        if st.button("Test AWS Connection"):
            self._test_aws_connection(aws_key, aws_secret, aws_region)
        
        st.markdown("---")
        
        # Step 3: Initialize System
        st.markdown("#### Step 3: Initialize System")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔌 Auto-Configure Gateways", type="primary", use_container_width=True):
                self._auto_configure_gateways()
        
        with col2:
            if st.button("💾 Save Configuration", use_container_width=True):
                self._save_configuration()
        
        with col3:
            if st.button("🚀 Launch System", type="secondary", use_container_width=True):
                self._launch_system()
    
    def _render_gateway_config(self):
        """Render gateway configuration."""
        st.markdown("### 🔌 Gateway Configuration")
        
        st.info("""
        **TidyLLM 4-Gateway Architecture:**
        Configure each gateway for your enterprise needs.
        """)
        
        # Gateway status grid
        gateways = [
            ("corporate_llm", "🤖 Corporate LLM Gateway", "LLM access and management"),
            ("ai_processing", "🧠 AI Processing Gateway", "Advanced AI operations"),
            ("workflow_optimizer", "⚙️ Workflow Optimizer", "Process automation"),
            ("database", "💾 Database Gateway", "Knowledge management")
        ]
        
        for gateway_id, name, description in gateways:
            with st.expander(name):
                st.markdown(f"**{description}**")
                
                # Check if gateway is registered
                service = next((s for s in self.registry.list_services() 
                              if s.get('service_type') == gateway_id), None)
                
                if service and service.get('initialized'):
                    st.success("✅ Gateway Active")
                    
                    # Show gateway configuration
                    config = st.session_state.tidyllm_config.get('gateways', {}).get(gateway_id, {})
                    
                    if gateway_id == "corporate_llm":
                        model = st.selectbox(
                            "Model",
                            ["claude-3", "gpt-4", "llama-3"],
                            key=f"{gateway_id}_model"
                        )
                        max_tokens = st.number_input(
                            "Max Tokens",
                            value=config.get('max_tokens', 2000),
                            key=f"{gateway_id}_tokens"
                        )
                    
                    elif gateway_id == "ai_processing":
                        rag_enabled = st.checkbox(
                            "Enable RAG",
                            value=config.get('rag_enabled', True),
                            key=f"{gateway_id}_rag"
                        )
                        embedding_model = st.selectbox(
                            "Embedding Model",
                            ["titan-embed", "cohere-embed", "openai-embed"],
                            key=f"{gateway_id}_embed"
                        )
                    
                    elif gateway_id == "workflow_optimizer":
                        max_parallel = st.number_input(
                            "Max Parallel Workflows",
                            value=config.get('max_parallel', 5),
                            key=f"{gateway_id}_parallel"
                        )
                        timeout = st.number_input(
                            "Timeout (seconds)",
                            value=config.get('timeout', 300),
                            key=f"{gateway_id}_timeout"
                        )
                    
                    elif gateway_id == "database":
                        db_type = st.selectbox(
                            "Database Type",
                            ["postgresql", "mysql", "sqlite"],
                            key=f"{gateway_id}_type"
                        )
                        connection_pool = st.number_input(
                            "Connection Pool Size",
                            value=config.get('pool_size', 10),
                            key=f"{gateway_id}_pool"
                        )
                else:
                    st.warning("⚠️ Gateway Not Initialized")
                    if st.button(f"Initialize {name}", key=f"init_{gateway_id}"):
                        self._initialize_gateway(gateway_id)
    
    def _render_aws_settings(self):
        """Render AWS settings configuration."""
        st.markdown("### 🔑 AWS Settings")
        
        # AWS Credentials
        st.markdown("#### Credentials")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.text_input(
                "Access Key ID",
                value=st.session_state.tidyllm_config.get('aws', {}).get('access_key_id', ''),
                type="password",
                key="aws_key_detailed"
            )
            
            st.text_input(
                "Session Token (optional)",
                value=st.session_state.tidyllm_config.get('aws', {}).get('session_token', ''),
                type="password",
                key="aws_session_token"
            )
        
        with col2:
            st.text_input(
                "Secret Access Key",
                value=st.session_state.tidyllm_config.get('aws', {}).get('secret_access_key', ''),
                type="password",
                key="aws_secret_detailed"
            )
            
            st.selectbox(
                "Region",
                ["us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"],
                key="aws_region_detailed"
            )
        
        st.markdown("---")
        
        # S3 Configuration
        st.markdown("#### S3 Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.text_input(
                "Default Bucket",
                value=st.session_state.tidyllm_config.get('s3', {}).get('default_bucket', ''),
                key="s3_bucket"
            )
            
            st.text_input(
                "Document Prefix",
                value=st.session_state.tidyllm_config.get('s3', {}).get('document_prefix', 'documents/'),
                key="s3_prefix"
            )
        
        with col2:
            st.text_input(
                "Knowledge Base Bucket",
                value=st.session_state.tidyllm_config.get('s3', {}).get('knowledge_bucket', ''),
                key="s3_knowledge"
            )
            
            st.checkbox(
                "Enable Versioning",
                value=st.session_state.tidyllm_config.get('s3', {}).get('versioning', True),
                key="s3_versioning"
            )
        
        st.markdown("---")
        
        # Bedrock Configuration
        st.markdown("#### Bedrock Configuration")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.text_input(
                "Bedrock Endpoint (optional)",
                value=st.session_state.tidyllm_config.get('bedrock', {}).get('endpoint', ''),
                key="bedrock_endpoint",
                help="Leave empty for default regional endpoint"
            )
            
            st.selectbox(
                "Default Model",
                ["anthropic.claude-3-sonnet", "anthropic.claude-3-opus", "meta.llama3-70b"],
                key="bedrock_model"
            )
        
        with col2:
            st.number_input(
                "Max Retries",
                value=st.session_state.tidyllm_config.get('bedrock', {}).get('max_retries', 3),
                min_value=0,
                max_value=10,
                key="bedrock_retries"
            )
            
            st.number_input(
                "Timeout (seconds)",
                value=st.session_state.tidyllm_config.get('bedrock', {}).get('timeout', 60),
                min_value=10,
                max_value=300,
                key="bedrock_timeout"
            )
    
    def _render_database_config(self):
        """Render database configuration."""
        st.markdown("### 💾 Database Configuration")
        
        db_type = st.selectbox(
            "Database Type",
            ["PostgreSQL", "MySQL", "SQLite", "MongoDB"],
            key="db_type_main"
        )
        
        if db_type in ["PostgreSQL", "MySQL"]:
            col1, col2 = st.columns(2)
            
            with col1:
                st.text_input("Host", key="db_host")
                st.text_input("Database Name", key="db_name")
                st.text_input("Username", key="db_user")
            
            with col2:
                st.number_input("Port", value=5432 if db_type == "PostgreSQL" else 3306, key="db_port")
                st.text_input("Schema", value="tidyllm", key="db_schema")
                st.text_input("Password", type="password", key="db_password")
        
        elif db_type == "SQLite":
            st.text_input(
                "Database File Path",
                value="data/tidyllm.db",
                key="sqlite_path"
            )
        
        # Connection pooling
        st.markdown("#### Connection Pooling")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.number_input("Min Connections", value=2, min_value=1, key="pool_min")
        
        with col2:
            st.number_input("Max Connections", value=10, min_value=1, key="pool_max")
        
        with col3:
            st.number_input("Connection Timeout (s)", value=30, key="pool_timeout")
        
        # Vector database settings
        st.markdown("#### Vector Database")
        
        st.checkbox("Enable Vector Storage", value=True, key="vector_enabled")
        
        if st.session_state.vector_enabled:
            vector_type = st.selectbox(
                "Vector Database Type",
                ["pgvector", "Pinecone", "Weaviate", "Qdrant"],
                key="vector_type"
            )
            
            st.number_input(
                "Embedding Dimension",
                value=1536,
                min_value=128,
                max_value=4096,
                key="embedding_dim"
            )
    
    def _render_workflow_settings(self):
        """Render workflow settings."""
        st.markdown("### ⚙️ Workflow Settings")
        
        # Workflow engine configuration
        st.markdown("#### Workflow Engine")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.number_input(
                "Max Parallel Workflows",
                value=5,
                min_value=1,
                max_value=20,
                key="workflow_parallel"
            )
            
            st.number_input(
                "Default Timeout (minutes)",
                value=30,
                min_value=1,
                max_value=240,
                key="workflow_timeout"
            )
        
        with col2:
            st.selectbox(
                "Execution Mode",
                ["Sequential", "Parallel", "Adaptive"],
                key="workflow_mode"
            )
            
            st.checkbox(
                "Enable Workflow Caching",
                value=True,
                key="workflow_cache"
            )
        
        # Workflow templates
        st.markdown("#### Workflow Templates")
        
        st.text_input(
            "Templates Directory",
            value="workflows/templates",
            key="workflow_templates_dir"
        )
        
        st.multiselect(
            "Enabled Templates",
            ["data_processing", "document_analysis", "report_generation", "quality_check"],
            default=["data_processing", "document_analysis"],
            key="workflow_templates"
        )
        
        # MLflow integration
        st.markdown("#### MLflow Integration")
        
        mlflow_enabled = st.checkbox("Enable MLflow Tracking", value=False, key="mlflow_enabled")
        
        if mlflow_enabled:
            st.text_input(
                "MLflow Tracking URI",
                value="http://localhost:5000",
                key="mlflow_uri"
            )
            
            st.text_input(
                "Default Experiment Name",
                value="tidyllm_workflows",
                key="mlflow_experiment"
            )
    
    def _render_security_settings(self):
        """Render security settings."""
        st.markdown("### 🔒 Security Settings")
        
        # Authentication
        st.markdown("#### Authentication")
        
        auth_method = st.selectbox(
            "Authentication Method",
            ["None", "Basic", "OAuth2", "SAML", "LDAP"],
            key="auth_method"
        )
        
        if auth_method != "None":
            st.text_area(
                "Authentication Configuration",
                value="",
                height=100,
                key="auth_config",
                help="JSON configuration for authentication provider"
            )
        
        # Encryption
        st.markdown("#### Encryption")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.checkbox("Encrypt Data at Rest", value=True, key="encrypt_rest")
            st.checkbox("Encrypt Data in Transit", value=True, key="encrypt_transit")
        
        with col2:
            st.selectbox(
                "Encryption Algorithm",
                ["AES-256", "AES-128", "RSA-2048"],
                key="encryption_algo"
            )
        
        # API Security
        st.markdown("#### API Security")
        
        st.checkbox("Require API Keys", value=True, key="require_api_keys")
        st.checkbox("Enable Rate Limiting", value=True, key="rate_limiting")
        
        if st.session_state.rate_limiting:
            col1, col2 = st.columns(2)
            
            with col1:
                st.number_input(
                    "Requests per Minute",
                    value=60,
                    min_value=1,
                    key="rate_limit_rpm"
                )
            
            with col2:
                st.number_input(
                    "Burst Size",
                    value=10,
                    min_value=1,
                    key="rate_limit_burst"
                )
    
    def _render_advanced_settings(self):
        """Render advanced settings."""
        st.markdown("### 📊 Advanced Settings")
        
        # Logging
        st.markdown("#### Logging")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.selectbox(
                "Log Level",
                ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
                index=1,
                key="log_level"
            )
            
            st.text_input(
                "Log Directory",
                value="logs/",
                key="log_dir"
            )
        
        with col2:
            st.number_input(
                "Max Log Size (MB)",
                value=100,
                min_value=1,
                key="log_size"
            )
            
            st.number_input(
                "Log Retention (days)",
                value=30,
                min_value=1,
                key="log_retention"
            )
        
        # Performance
        st.markdown("#### Performance")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.number_input(
                "Cache Size (MB)",
                value=512,
                min_value=64,
                key="cache_size"
            )
            
            st.number_input(
                "Worker Threads",
                value=4,
                min_value=1,
                max_value=16,
                key="worker_threads"
            )
        
        with col2:
            st.number_input(
                "Request Timeout (s)",
                value=30,
                min_value=5,
                key="request_timeout"
            )
            
            st.checkbox(
                "Enable Profiling",
                value=False,
                key="enable_profiling"
            )
        
        # Export/Import Configuration
        st.markdown("#### Configuration Management")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("📥 Export Config", use_container_width=True):
                self._export_config()
        
        with col2:
            if st.button("📤 Import Config", use_container_width=True):
                self._import_config()
        
        with col3:
            if st.button("🔄 Reset to Defaults", use_container_width=True):
                self._reset_to_defaults()
    
    def _apply_environment_template(self, environment: str):
        """Apply environment-specific template."""
        templates = {
            "development": {
                "log_level": "DEBUG",
                "cache_enabled": True,
                "s3_prefix": "dev/",
                "max_parallel_workflows": 10
            },
            "staging": {
                "log_level": "INFO",
                "cache_enabled": True,
                "s3_prefix": "staging/",
                "max_parallel_workflows": 5
            },
            "production": {
                "log_level": "WARNING",
                "cache_enabled": True,
                "s3_prefix": "prod/",
                "max_parallel_workflows": 20
            },
            "air-gapped": {
                "log_level": "INFO",
                "cache_enabled": True,
                "s3_prefix": "local/",
                "max_parallel_workflows": 5,
                "offline_mode": True
            }
        }
        
        if environment in templates:
            st.session_state.tidyllm_config.update(templates[environment])
            st.session_state.config_modified = True
            st.success(f"✅ Applied {environment} template")
            st.rerun()
    
    def _test_aws_connection(self, key: str, secret: str, region: str):
        """Test AWS connection."""
        with st.spinner("Testing AWS connection..."):
            try:
                # Update session manager with new credentials
                os.environ['AWS_ACCESS_KEY_ID'] = key
                os.environ['AWS_SECRET_ACCESS_KEY'] = secret
                os.environ['AWS_DEFAULT_REGION'] = region
                
                # Test S3 connection
                # Use extended session manager from app.py instead
                session_manager = st.session_state.get('tidyllm_session_manager')
                s3_client = session_manager.get_s3_client()
                s3_client.list_buckets()
                
                st.success("✅ AWS connection successful!")
            except Exception as e:
                st.error(f"❌ AWS connection failed: {e}")
    
    def _auto_configure_gateways(self):
        """Auto-configure all gateways."""
        with st.spinner("Auto-configuring gateways..."):
            try:
                self.registry.auto_configure()
                st.success("✅ All gateways configured successfully!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Gateway configuration failed: {e}")
    
    def _save_configuration(self):
        """Save configuration to file."""
        try:
            # Create backup
            if self.settings_path.exists():
                backup_path = self.settings_path.with_suffix(f'.backup.{datetime.now():%Y%m%d_%H%M%S}.yaml')
                self.settings_path.rename(backup_path)
            
            # Save new configuration
            self.settings_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.settings_path, 'w') as f:
                yaml.dump(st.session_state.tidyllm_config, f, default_flow_style=False)
            
            st.session_state.config_modified = False
            st.success("✅ Configuration saved successfully!")
        except Exception as e:
            st.error(f"❌ Failed to save configuration: {e}")
    
    def _launch_system(self):
        """Launch the TidyLLM system."""
        if not self.registry.list_services():
            st.warning("⚠️ Please configure gateways first")
        else:
            st.success("🚀 System ready! Navigate to other pages to use TidyLLM features.")
    
    def _initialize_gateway(self, gateway_id: str):
        """Initialize a specific gateway."""
        with st.spinner(f"Initializing {gateway_id}..."):
            try:
                # Gateway-specific initialization
                if gateway_id == "corporate_llm":
                    from tidyllm.gateways.corporate_llm_gateway import CorporateLLMGateway
                    gateway = CorporateLLMGateway()
                elif gateway_id == "ai_processing":
                    from tidyllm.gateways.ai_processing_gateway import AIProcessingGateway
                    gateway = AIProcessingGateway()
                elif gateway_id == "workflow_optimizer":
                    from tidyllm.gateways.workflow_optimizer_gateway import WorkflowOptimizerGateway
                    gateway = WorkflowOptimizerGateway()
                elif gateway_id == "database":
                    from tidyllm.gateways.database_gateway import DatabaseGateway
                    gateway = DatabaseGateway()
                
                self.registry.register_gateway(gateway_id, gateway)
                st.success(f"✅ {gateway_id} initialized successfully!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Failed to initialize {gateway_id}: {e}")
    
    def _export_config(self):
        """Export configuration."""
        config_str = yaml.dump(st.session_state.tidyllm_config, default_flow_style=False)
        st.download_button(
            label="Download Configuration",
            data=config_str,
            file_name=f"tidyllm_config_{datetime.now():%Y%m%d_%H%M%S}.yaml",
            mime="text/yaml"
        )
    
    def _import_config(self):
        """Import configuration."""
        uploaded_file = st.file_uploader("Choose configuration file", type=['yaml', 'yml'])
        if uploaded_file:
            try:
                config = yaml.safe_load(uploaded_file)
                st.session_state.tidyllm_config = config
                st.session_state.config_modified = True
                st.success("✅ Configuration imported successfully!")
                st.rerun()
            except Exception as e:
                st.error(f"❌ Failed to import configuration: {e}")
    
    def _reset_to_defaults(self):
        """Reset to default configuration."""
        if st.confirm("Are you sure you want to reset to defaults?"):
            st.session_state.tidyllm_config = {}
            st.session_state.config_modified = True
            st.info("Configuration reset to defaults")
            st.rerun()


def render_tidyllm_config_page():
    """Convenience function to render TidyLLM configuration page."""
    config = TidyLLMConfigInterface()
    config.render()