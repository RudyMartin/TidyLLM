"""
TidyLLM Initialize Page
======================

Dedicated page for system initialization and status overview.
First tab - gives immediate visibility into what's working.
"""

import streamlit as st
import time
import polars as pl
from old_core.validator import OnboardingValidator
from old_core.system_store import SystemStatusStore, render_refresh_controls, render_status_summary

def render_initialize_page():
    """Render the TidyLLM initialization and status page."""
    
    st.markdown("## 🚀 TidyLLM System Initialize")
    st.markdown("**Welcome to TidyLLM Enterprise AI Platform!** Use this page to initialize and monitor all foundational services.")
    
    # Show system status summary cards only on this tab
    system_df = SystemStatusStore.get_system_data()
    if system_df.height > 0:
        summary = SystemStatusStore.get_status_summary()
        if summary['success'] > 0:
            st.success(f"✅ System Status: {summary['success']} services operational")
        if summary['warning'] > 0:
            st.warning(f"⚠️ System Status: {summary['warning']} services with warnings") 
        if summary['error'] > 0:
            st.error(f"❌ System Status: {summary['error']} services offline")
    else:
        st.info("🔄 Initializing system status...")
    
    st.markdown("---")
    
    # Foundational Status Overview
    render_foundational_status()
    
    st.markdown("---")
    
    # System Initialization Controls
    render_initialization_controls()
    
    st.markdown("---")
    
    # Detailed Status
    render_detailed_status()

def render_foundational_status():
    """Render the foundational services status overview using Polars data."""
    
    st.markdown("### 🏗️ Foundational Services Status")
    st.markdown("**Critical infrastructure that must be LIVE before using TidyLLM:**")
    
    # Get current system data from Polars store
    system_df = SystemStatusStore.get_system_data()
    
    if system_df.height > 0:
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            # MLflow Status
            mlflow_data = SystemStatusStore.get_component_status('mlflow')
            if mlflow_data and mlflow_data['status'] == 'success':
                st.success("🎯 **MLflow LIVE**")
                st.caption(f"✅ {mlflow_data['message']} ({mlflow_data['latency_ms']:.1f}ms)")
            else:
                st.error("❌ **MLflow Offline**")
                st.caption(f"⚠️ {mlflow_data['message'] if mlflow_data else 'Not available'}")
        
        with col2:
            # Database Status  
            db_data = SystemStatusStore.get_component_status('database')
            if db_data and db_data['status'] == 'success':
                st.success("🗄️ **Database LIVE**")
                st.caption(f"✅ {db_data['message']} ({db_data['latency_ms']:.1f}ms)")
            else:
                st.error("❌ **Database Offline**")
                st.caption(f"⚠️ {db_data['message'] if db_data else 'Not available'}")
        
        with col3:
            # Gateway Status
            gateway_df = SystemStatusStore.get_category_status('gateway')
            if gateway_df.height > 0:
                successful_gateways = gateway_df.filter(pl.col('status') == 'success').height
                total_gateways = gateway_df.height
                
                if successful_gateways == total_gateways:
                    st.success(f"🏢 **All Gateways Ready**")
                    st.caption(f"✅ {successful_gateways}/{total_gateways} operational")
                elif successful_gateways > 0:
                    st.warning(f"⚠️ **Gateways Partial**")
                    st.caption(f"⚠️ {successful_gateways}/{total_gateways} operational")
                else:
                    st.error("❌ **Gateways Offline**")
                    st.caption("❌ None operational")
            else:
                st.error("❌ **Gateways Offline**")
                st.caption("❌ No gateways found")
        
        with col4:
            # Overall System Status using Polars summary
            summary = SystemStatusStore.get_status_summary()
            foundational_ok = (mlflow_data and mlflow_data['status'] == 'success' and
                             db_data and db_data['status'] == 'success')
            
            if foundational_ok and summary['success'] > 2:  # MLflow + DB + at least 1 gateway
                st.success("🎉 **System Ready**")
                st.caption("✅ Ready for AI workloads")
            else:
                st.error("🔧 **Needs Setup**")
                st.caption("⚠️ Initialize required")
                
        # Add refresh controls
        st.markdown("---")
        render_refresh_controls()
        
    else:
        st.info("🔄 **Checking system status...** Click Initialize to start.")
        
        # Add refresh button for empty state
        col_a, col_b = st.columns(2)
        with col_a:
            if st.button("🔄 Initialize System Data", type="primary"):
                SystemStatusStore.force_refresh()
                st.rerun()
        with col_b:
            if st.button("🚀 Auto-Start MLflow"):
                with st.spinner("Starting MLflow server..."):
                    mlflow_started = SystemStatusStore.auto_start_mlflow()
                    if mlflow_started:
                        st.success("✅ MLflow server started!")
                        st.info("💡 Please wait 10-15 seconds for full initialization")
                    else:
                        st.error("❌ Failed to start MLflow server")
                st.rerun()

def render_initialization_controls():
    """Render the system initialization controls."""
    
    st.markdown("### 🔧 System Initialization")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("🚀 Initialize Foundation", type="primary", use_container_width=True):
            with st.spinner("Initializing foundational services (MLflow + Database)..."):
                try:
                    st.info("🎯 Step 1: Auto-starting MLflow server...")
                    
                    # Auto-start MLflow
                    mlflow_started = SystemStatusStore.auto_start_mlflow()
                    if mlflow_started:
                        st.success("✅ MLflow server auto-start initiated")
                        
                        # Wait a moment for MLflow to start
                        import time
                        time.sleep(3)
                    
                    st.info("🎯 Step 2: Refreshing system data...")
                    SystemStatusStore.force_refresh()
                    
                    # Check foundational services
                    mlflow_data = SystemStatusStore.get_component_status('mlflow')
                    db_data = SystemStatusStore.get_component_status('database')
                    
                    if mlflow_data and mlflow_data['status'] == 'success' and db_data and db_data['status'] == 'success':
                        st.success("✅ Foundation initialized successfully!")
                        st.info("🎯 MLflow and Database are LIVE - ready for gateway initialization")
                        st.balloons()
                    else:
                        st.warning("⚠️ Foundation partially initialized - check status above")
                        if mlflow_data:
                            st.info(f"MLflow: {mlflow_data['status']} - {mlflow_data['message']}")
                        if db_data:
                            st.info(f"Database: {db_data['status']} - {db_data['message']}")
                        
                        # If MLflow still not ready, show help
                        if mlflow_data and mlflow_data['status'] != 'success':
                            st.info("💡 MLflow may take 10-15 seconds to fully start. Try refreshing in a moment.")
                        
                    st.rerun()
                    
                except Exception as e:
                    st.error(f"❌ Foundation initialization failed: {e}")
    
    with col2:
        if st.button("🏢 Initialize Gateways", use_container_width=True):
            with st.spinner("Initializing TidyLLM gateways..."):
                try:
                    st.info("🏗️ Refreshing TidyLLM 4-Gateway Architecture...")
                    SystemStatusStore.force_refresh()
                    
                    # Check gateway status
                    gateway_df = SystemStatusStore.get_category_status('gateway')
                    
                    if gateway_df.height > 0:
                        successful = gateway_df.filter(pl.col('status') == 'success').height
                        total = gateway_df.height
                        
                        if successful == total:
                            st.success(f"✅ All {total} gateways initialized successfully!")
                            st.balloons()
                        else:
                            st.warning(f"⚠️ {successful}/{total} gateways initialized")
                            
                        # Show gateway details
                        for row in gateway_df.iter_rows(named=True):
                            status_icon = "✅" if row['status'] == 'success' else "❌"
                            st.info(f"{status_icon} {row['component']}: {row['message']}")
                    else:
                        st.warning("⚠️ No gateways found")
                        
                    st.rerun()
                    
                except Exception as e:
                    st.error(f"❌ Gateway initialization failed: {e}")
    
    with col3:
        if st.button("🔄 Full System Check", use_container_width=True):
            with st.spinner("Running complete system validation..."):
                try:
                    st.info("🔍 Running comprehensive system check...")
                    SystemStatusStore.force_refresh()
                    
                    # Get summary of all components
                    summary = SystemStatusStore.get_status_summary()
                    system_df = SystemStatusStore.get_system_data()
                    
                    st.success(f"✅ System check completed!")
                    st.info(f"📊 Status: {summary['success']} success, {summary['warning']} warnings, {summary['error']} errors")
                    
                    # Show collection time
                    collection_time = st.session_state.get('last_collection_time', 0)
                    if collection_time:
                        st.caption(f"Data collection time: {collection_time:.2f}s")
                    
                    st.rerun()
                    
                except Exception as e:
                    st.error(f"❌ System check failed: {e}")

def render_detailed_status():
    """Render detailed status information."""
    
    if not hasattr(st.session_state, 'validator_results') or not st.session_state.validator_results:
        st.info("💡 **Tip:** Click 'Full System Check' above to see detailed status information.")
        return
    
    results = st.session_state.validator_results
    
    st.markdown("### 📊 Detailed Status Information")
    
    # MLflow Details
    if 'mlflow' in results:
        with st.expander("🎯 MLflow Integration Details", expanded=False):
            mlflow_result = results['mlflow']
            
            if mlflow_result.get('status') == 'success':
                st.success(f"**Status:** {mlflow_result.get('message', 'Connected')}")
            else:
                st.error(f"**Status:** {mlflow_result.get('message', 'Failed')}")
            
            # Show tier details if available
            for tier in ['primary', 'secondary', 'backup']:
                if tier in mlflow_result:
                    tier_result = mlflow_result[tier]
                    status_icon = "✅" if tier_result.get('status') == 'success' else "❌"
                    st.markdown(f"- **{tier.title()}:** {status_icon} {tier_result.get('message', 'Unknown')}")
    
    # Database Details
    if 'database' in results:
        with st.expander("🗄️ Database Connection Details", expanded=False):
            db_result = results['database']
            
            if db_result.get('status') == 'success':
                st.success(f"**Status:** {db_result.get('message', 'Connected')}")
            else:
                st.error(f"**Status:** {db_result.get('message', 'Failed')}")
            
            # Show tier details if available
            for tier in ['primary', 'secondary', 'backup']:
                if tier in db_result:
                    tier_result = db_result[tier]
                    status_icon = "✅" if tier_result.get('status') == 'success' else "❌"
                    st.markdown(f"- **{tier.title()}:** {status_icon} {tier_result.get('message', 'Unknown')}")
    
    # Gateway Details
    if 'gateways' in results:
        with st.expander("🏢 Gateway Status Details", expanded=False):
            gateway_results = results['gateways']
            
            for name, result in gateway_results.items():
                if isinstance(result, dict):
                    status_icon = "✅" if result.get('status') == 'success' else "❌"
                    latency = result.get('latency', 0)
                    message = result.get('message', 'Unknown')
                    st.markdown(f"**{name.replace('_', ' ').title()}:** {status_icon} {message} ({latency:.1f}ms)")
                else:
                    st.markdown(f"**{name.replace('_', ' ').title()}:** ❓ Status unknown")
    
    # Timestamp
    if 'timestamp' in results:
        timestamp = results['timestamp']
        formatted_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp))
        st.caption(f"Last updated: {formatted_time}")