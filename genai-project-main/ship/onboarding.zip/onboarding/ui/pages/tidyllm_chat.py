"""
TidyLLM Native Chat Interface
=============================

Chat interface using TidyLLM's gateway architecture.
"""

import streamlit as st
from typing import Optional, Dict, Any, List
import json
from datetime import datetime

from tidyllm.gateways import get_gateway
from tidyllm.gateways.corporate_llm_gateway import CorporateLLMGateway
from tidyllm.gateways.ai_processing_gateway import AIProcessingGateway

class TidyLLMChatInterface:
    """Native TidyLLM chat interface."""
    
    def __init__(self):
        """Initialize with TidyLLM gateways."""
        self.llm_gateway = None
        self.ai_gateway = None
        self._init_gateways()
        self._init_chat_session()
    
    def _init_gateways(self):
        """Initialize TidyLLM gateways."""
        try:
            # Get Corporate LLM Gateway
            self.llm_gateway = get_gateway('corporate_llm')
            if not self.llm_gateway:
                # Try to initialize it
                from tidyllm.gateways.gateway_registry import get_global_registry
                registry = get_global_registry()
                registry.auto_configure()
                self.llm_gateway = get_gateway('corporate_llm')
            
            # Get AI Processing Gateway
            self.ai_gateway = get_gateway('ai_processing')
            
        except Exception as e:
            st.error(f"Failed to initialize gateways: {e}")
    
    def _init_chat_session(self):
        """Initialize chat session state."""
        if 'tidyllm_messages' not in st.session_state:
            st.session_state.tidyllm_messages = []
        if 'tidyllm_chat_mode' not in st.session_state:
            st.session_state.tidyllm_chat_mode = 'standard'
    
    def render(self):
        """Render the TidyLLM chat interface."""
        st.title("🧠 TidyLLM AI Chat")
        st.markdown("**Powered by TidyLLM Gateway Architecture**")
        
        # Check gateway status
        if not self.llm_gateway:
            st.error("❌ Corporate LLM Gateway not initialized")
            st.info("Please initialize the system first (go to Initialize System page)")
            return
        
        # Chat mode selector
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            mode = st.selectbox(
                "Chat Mode",
                ["Standard", "RAG-Enhanced", "Workflow-Guided"],
                key="chat_mode_selector"
            )
            st.session_state.tidyllm_chat_mode = mode.lower().replace('-', '_')
        
        with col2:
            model = st.selectbox(
                "Model",
                ["Claude 3", "GPT-4", "Llama 3"],
                key="model_selector"
            )
        
        with col3:
            if st.button("🗑️ Clear Chat", type="secondary"):
                st.session_state.tidyllm_messages = []
                st.rerun()
        
        st.markdown("---")
        
        # Display chat messages
        self._render_messages()
        
        # Chat input
        self._render_chat_input()
        
        # Show gateway info in expander
        with st.expander("🔧 Gateway Information"):
            self._render_gateway_info()
    
    def _render_messages(self):
        """Render chat messages."""
        for message in st.session_state.tidyllm_messages:
            role = message["role"]
            content = message["content"]
            
            if role == "user":
                with st.chat_message("user", avatar="👤"):
                    st.markdown(content)
            else:
                with st.chat_message("assistant", avatar="🤖"):
                    st.markdown(content)
                    
                    # Show metadata if available
                    if "metadata" in message:
                        with st.expander("📊 Response Metadata"):
                            st.json(message["metadata"])
    
    def _render_chat_input(self):
        """Render chat input and handle responses."""
        prompt = st.chat_input("Ask TidyLLM anything...")
        
        if prompt:
            # Add user message
            st.session_state.tidyllm_messages.append({
                "role": "user",
                "content": prompt
            })
            
            # Display user message immediately
            with st.chat_message("user", avatar="👤"):
                st.markdown(prompt)
            
            # Get response from TidyLLM gateway
            with st.chat_message("assistant", avatar="🤖"):
                with st.spinner("TidyLLM is thinking..."):
                    response = self._get_tidyllm_response(prompt)
                    st.markdown(response["content"])
                    
                    if response.get("metadata"):
                        with st.expander("📊 Response Metadata"):
                            st.json(response["metadata"])
            
            # Add assistant message to history
            st.session_state.tidyllm_messages.append(response)
    
    def _get_tidyllm_response(self, prompt: str) -> Dict[str, Any]:
        """Get response from TidyLLM gateway."""
        try:
            # Prepare request based on mode
            if st.session_state.tidyllm_chat_mode == 'rag_enhanced':
                # Use AI Processing Gateway for RAG
                if self.ai_gateway:
                    response = self.ai_gateway.process({
                        "operation": "rag_query",
                        "query": prompt,
                        "context_limit": 5
                    })
                    
                    return {
                        "role": "assistant",
                        "content": response.get("answer", "No response generated"),
                        "metadata": {
                            "mode": "RAG-Enhanced",
                            "sources": response.get("sources", []),
                            "confidence": response.get("confidence", 0)
                        }
                    }
            
            elif st.session_state.tidyllm_chat_mode == 'workflow_guided':
                # Use Workflow Optimizer Gateway
                workflow_gateway = get_gateway('workflow_optimizer')
                if workflow_gateway:
                    response = workflow_gateway.process({
                        "operation": "guided_chat",
                        "prompt": prompt
                    })
                    
                    return {
                        "role": "assistant",
                        "content": response.get("response", "No response generated"),
                        "metadata": {
                            "mode": "Workflow-Guided",
                            "workflow": response.get("workflow", ""),
                            "steps": response.get("steps", [])
                        }
                    }
            
            # Default: Standard chat via Corporate LLM Gateway
            if self.llm_gateway:
                response = self.llm_gateway.process({
                    "prompt": prompt,
                    "max_tokens": 2000,
                    "temperature": 0.7
                })
                
                return {
                    "role": "assistant",
                    "content": response.get("response", "No response generated"),
                    "metadata": {
                        "mode": "Standard",
                        "model": response.get("model", "unknown"),
                        "tokens": response.get("token_count", 0)
                    }
                }
            
            # Fallback if no gateway available
            return {
                "role": "assistant",
                "content": "Gateway not available. Please check system configuration.",
                "metadata": {"error": "No gateway available"}
            }
            
        except Exception as e:
            return {
                "role": "assistant",
                "content": f"Error: {str(e)}",
                "metadata": {"error": str(e)}
            }
    
    def _render_gateway_info(self):
        """Render gateway information."""
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Corporate LLM Gateway:**")
            if self.llm_gateway:
                st.success("✅ Connected")
                if hasattr(self.llm_gateway, 'get_status'):
                    status = self.llm_gateway.get_status()
                    st.json(status)
            else:
                st.error("❌ Not Connected")
        
        with col2:
            st.markdown("**AI Processing Gateway:**")
            if self.ai_gateway:
                st.success("✅ Connected")
                if hasattr(self.ai_gateway, 'get_status'):
                    status = self.ai_gateway.get_status()
                    st.json(status)
            else:
                st.warning("⚠️ Not Connected")


def render_tidyllm_chat_page():
    """Convenience function to render TidyLLM chat page."""
    chat = TidyLLMChatInterface()
    chat.render()