"""
TidyLLM Native Workflow Automation Interface
============================================

Workflow automation using TidyLLM's Workflow Optimizer Gateway and flow system.
"""

import streamlit as st
from typing import Dict, Any, List, Optional, Tuple
import json
import yaml
from datetime import datetime, timedelta
from pathlib import Path
import uuid

from tidyllm.gateways import get_gateway
from tidyllm.gateways.workflow_optimizer_gateway import WorkflowOptimizerGateway
from tidyllm.flow import FlowAgreementManager, execute_flow_command
# DISABLED: from tidyllm.infrastructure.session.unified import UnifiedSessionManager
# Using extended session manager from app.py instead

class TidyLLMWorkflowInterface:
    """Native TidyLLM workflow automation interface."""
    
    def __init__(self):
        """Initialize with TidyLLM workflow components."""
        self.session_manager = st.session_state.get('tidyllm_session_manager')
        self.workflow_gateway = None
        self.flow_manager = None
        self._init_workflow_system()
        self._init_session_state()
    
    def _init_workflow_system(self):
        """Initialize TidyLLM workflow system."""
        try:
            # Get Workflow Optimizer Gateway
            self.workflow_gateway = get_gateway('workflow_optimizer')
            if not self.workflow_gateway:
                # Try to initialize it
                self.workflow_gateway = WorkflowOptimizerGateway()
            
            # Initialize Flow Manager if available
            if self.session_manager:
                self.flow_manager = FlowAgreementManager()
        except Exception as e:
            st.error(f"Failed to initialize workflow system: {e}")
    
    def _init_session_state(self):
        """Initialize workflow session state."""
        if 'workflow_templates' not in st.session_state:
            st.session_state.workflow_templates = self._load_workflow_templates()
        if 'active_workflows' not in st.session_state:
            st.session_state.active_workflows = []
        if 'workflow_history' not in st.session_state:
            st.session_state.workflow_history = []
        if 'current_workflow' not in st.session_state:
            st.session_state.current_workflow = None
    
    def _load_workflow_templates(self) -> List[Dict[str, Any]]:
        """Load available workflow templates."""
        # Default templates
        templates = [
            {
                "id": "data_processing",
                "name": "📊 Data Processing Pipeline",
                "description": "Extract, transform, and load data from various sources",
                "category": "Data",
                "steps": 5,
                "estimated_time": "5-10 mins"
            },
            {
                "id": "document_analysis",
                "name": "📄 Document Analysis",
                "description": "Analyze documents for insights and key information",
                "category": "Analysis",
                "steps": 4,
                "estimated_time": "3-5 mins"
            },
            {
                "id": "report_generation",
                "name": "📑 Report Generation",
                "description": "Generate comprehensive reports from data sources",
                "category": "Reporting",
                "steps": 6,
                "estimated_time": "10-15 mins"
            },
            {
                "id": "quality_check",
                "name": "✅ Quality Check",
                "description": "Automated quality assurance workflow",
                "category": "QA",
                "steps": 4,
                "estimated_time": "2-3 mins"
            },
            {
                "id": "ml_pipeline",
                "name": "🤖 ML Pipeline",
                "description": "End-to-end machine learning workflow",
                "category": "ML",
                "steps": 7,
                "estimated_time": "15-30 mins"
            }
        ]
        
        # Try to load from workflow configs
        try:
            workflow_dir = Path("tidyllm/workflow_configs")
            if workflow_dir.exists():
                for yaml_file in workflow_dir.glob("*.yaml"):
                    with open(yaml_file, 'r') as f:
                        config = yaml.safe_load(f)
                        if config:
                            templates.append({
                                "id": yaml_file.stem,
                                "name": config.get('name', yaml_file.stem),
                                "description": config.get('description', ''),
                                "category": config.get('category', 'Custom'),
                                "steps": len(config.get('steps', [])),
                                "estimated_time": config.get('estimated_time', 'Variable')
                            })
        except Exception as e:
            st.warning(f"Could not load custom templates: {e}")
        
        return templates
    
    def render(self):
        """Render the TidyLLM workflow interface."""
        st.title("⚙️ TidyLLM Workflow Automation")
        st.markdown("**Enterprise Process Automation with Workflow Optimizer Gateway**")
        
        # Check system status
        if not self.workflow_gateway:
            st.error("❌ Workflow Optimizer Gateway not initialized")
            st.info("Please initialize the system first (go to Initialize System page)")
            return
        
        # Workflow tabs
        tabs = st.tabs([
            "🚀 Execute Workflow",
            "📋 Workflow Templates",
            "🔨 Workflow Builder",
            "📊 Active Workflows",
            "📈 Analytics & History",
            "⚙️ Configuration"
        ])
        
        with tabs[0]:
            self._render_execute_workflow()
        
        with tabs[1]:
            self._render_workflow_templates()
        
        with tabs[2]:
            self._render_workflow_builder()
        
        with tabs[3]:
            self._render_active_workflows()
        
        with tabs[4]:
            self._render_analytics_history()
        
        with tabs[5]:
            self._render_configuration()
    
    def _render_execute_workflow(self):
        """Render workflow execution interface."""
        st.markdown("### 🚀 Execute Workflow")
        
        # Workflow selection
        col1, col2 = st.columns([2, 1])
        
        with col1:
            template_names = [t['name'] for t in st.session_state.workflow_templates]
            selected_template = st.selectbox(
                "Select Workflow Template",
                template_names,
                key="selected_workflow_template"
            )
            
            # Get selected template details
            template = next((t for t in st.session_state.workflow_templates 
                           if t['name'] == selected_template), None)
            
            if template:
                st.info(f"**Description:** {template['description']}")
                st.markdown(f"**Category:** {template['category']} | **Steps:** {template['steps']} | **Est. Time:** {template['estimated_time']}")
        
        with col2:
            execution_mode = st.selectbox(
                "Execution Mode",
                ["Sequential", "Parallel", "Adaptive"],
                key="execution_mode"
            )
            
            priority = st.selectbox(
                "Priority",
                ["Low", "Normal", "High", "Critical"],
                index=1,
                key="execution_priority"
            )
        
        st.markdown("---")
        
        # Workflow parameters
        st.markdown("#### Workflow Parameters")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            param1 = st.text_input(
                "Input Source",
                placeholder="s3://bucket/path or local path",
                key="workflow_input"
            )
        
        with col2:
            param2 = st.text_input(
                "Output Destination",
                placeholder="s3://bucket/output",
                key="workflow_output"
            )
        
        with col3:
            param3 = st.number_input(
                "Timeout (minutes)",
                min_value=1,
                max_value=240,
                value=30,
                key="workflow_timeout"
            )
        
        # Advanced options
        with st.expander("🔧 Advanced Options"):
            col1, col2 = st.columns(2)
            
            with col1:
                retry_on_failure = st.checkbox(
                    "Retry on Failure",
                    value=True,
                    key="retry_on_failure"
                )
                
                if retry_on_failure:
                    max_retries = st.number_input(
                        "Max Retries",
                        min_value=1,
                        max_value=5,
                        value=3,
                        key="max_retries"
                    )
                
                notify_on_completion = st.checkbox(
                    "Notify on Completion",
                    value=False,
                    key="notify_completion"
                )
            
            with col2:
                enable_caching = st.checkbox(
                    "Enable Caching",
                    value=True,
                    key="enable_caching"
                )
                
                save_intermediate = st.checkbox(
                    "Save Intermediate Results",
                    value=False,
                    key="save_intermediate"
                )
                
                debug_mode = st.checkbox(
                    "Debug Mode",
                    value=False,
                    key="debug_mode"
                )
        
        # Execute button
        col1, col2, col3 = st.columns([1, 1, 1])
        
        with col2:
            if st.button("▶️ Execute Workflow", type="primary", use_container_width=True):
                if template and param1:
                    self._execute_workflow(template, param1, param2)
                else:
                    st.warning("Please select a template and provide input source")
        
        # Execution preview
        if template:
            with st.expander("📋 Workflow Steps Preview"):
                self._render_workflow_steps_preview(template)
    
    def _render_workflow_templates(self):
        """Render workflow templates management."""
        st.markdown("### 📋 Workflow Templates")
        
        # Template filters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            category_filter = st.multiselect(
                "Filter by Category",
                ["All", "Data", "Analysis", "Reporting", "QA", "ML", "Custom"],
                default=["All"],
                key="category_filter"
            )
        
        with col2:
            sort_by = st.selectbox(
                "Sort By",
                ["Name", "Category", "Steps", "Last Modified"],
                key="sort_templates"
            )
        
        with col3:
            search_term = st.text_input(
                "Search Templates",
                placeholder="Search...",
                key="search_templates"
            )
        
        # Display templates
        filtered_templates = self._filter_templates(category_filter, search_term)
        
        if filtered_templates:
            for template in filtered_templates:
                with st.expander(f"{template['name']} - {template['category']}"):
                    col1, col2 = st.columns([3, 1])
                    
                    with col1:
                        st.markdown(f"**Description:** {template['description']}")
                        st.markdown(f"**Steps:** {template['steps']} | **Estimated Time:** {template['estimated_time']}")
                        
                        # Template metadata
                        if 'created_by' in template:
                            st.caption(f"Created by: {template['created_by']} | Last modified: {template.get('last_modified', 'Unknown')}")
                    
                    with col2:
                        col_a, col_b, col_c = st.columns(3)
                        
                        with col_a:
                            if st.button("▶️", key=f"run_{template['id']}", help="Execute"):
                                st.session_state.selected_workflow_template = template['name']
                                st.rerun()
                        
                        with col_b:
                            if st.button("✏️", key=f"edit_{template['id']}", help="Edit"):
                                self._edit_template(template)
                        
                        with col_c:
                            if st.button("📋", key=f"copy_{template['id']}", help="Duplicate"):
                                self._duplicate_template(template)
        else:
            st.info("No templates found matching your criteria")
        
        # Import/Export templates
        st.markdown("---")
        st.markdown("#### Template Management")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("➕ Create New Template", use_container_width=True):
                st.session_state.creating_template = True
                st.rerun()
        
        with col2:
            if st.button("📥 Import Template", use_container_width=True):
                self._import_template()
        
        with col3:
            if st.button("📤 Export Templates", use_container_width=True):
                self._export_templates()
    
    def _render_workflow_builder(self):
        """Render workflow builder interface."""
        st.markdown("### 🔨 Workflow Builder")
        
        # Builder mode
        builder_mode = st.radio(
            "Builder Mode",
            ["Visual Builder", "YAML Editor", "Code Editor"],
            horizontal=True,
            key="builder_mode"
        )
        
        if builder_mode == "Visual Builder":
            self._render_visual_builder()
        elif builder_mode == "YAML Editor":
            self._render_yaml_editor()
        else:
            self._render_code_editor()
    
    def _render_visual_builder(self):
        """Render visual workflow builder."""
        st.info("🎨 Drag and drop workflow nodes to build your automation")
        
        # Node palette
        col1, col2 = st.columns([1, 3])
        
        with col1:
            st.markdown("#### 🎯 Available Nodes")
            
            node_types = {
                "Input": ["📥 S3 Input", "📁 File Input", "🔌 API Input"],
                "Processing": ["🔄 Transform", "🔍 Filter", "🔗 Join"],
                "AI/ML": ["🤖 LLM Process", "🧠 Embedding", "📊 Classification"],
                "Output": ["📤 S3 Output", "📧 Email", "📊 Dashboard"]
            }
            
            for category, nodes in node_types.items():
                with st.expander(category):
                    for node in nodes:
                        st.button(node, key=f"node_{node}", use_container_width=True)
        
        with col2:
            st.markdown("#### 🔀 Workflow Canvas")
            
            # Placeholder for visual builder
            canvas_container = st.container()
            with canvas_container:
                st.markdown("""
                <div style="border: 2px dashed #ccc; border-radius: 10px; padding: 50px; text-align: center; min-height: 400px;">
                    <h3>Workflow Canvas</h3>
                    <p>Drag nodes here to build your workflow</p>
                    <br>
                    <div style="display: flex; justify-content: center; gap: 20px; margin-top: 20px;">
                        <div style="background: #e3f2fd; padding: 20px; border-radius: 8px;">
                            📥 Input Node
                        </div>
                        <div style="background: #fff3e0; padding: 20px; border-radius: 8px;">
                            → 🔄 Process Node →
                        </div>
                        <div style="background: #e8f5e9; padding: 20px; border-radius: 8px;">
                            📤 Output Node
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)
            
            # Workflow properties
            with st.expander("⚙️ Workflow Properties"):
                workflow_name = st.text_input("Workflow Name", key="builder_workflow_name")
                workflow_desc = st.text_area("Description", key="builder_workflow_desc")
                
                col_a, col_b = st.columns(2)
                with col_a:
                    if st.button("💾 Save Workflow", type="primary", use_container_width=True):
                        self._save_built_workflow()
                with col_b:
                    if st.button("▶️ Test Workflow", use_container_width=True):
                        self._test_built_workflow()
    
    def _render_yaml_editor(self):
        """Render YAML workflow editor."""
        st.markdown("#### 📝 YAML Workflow Editor")
        
        # Template selector
        template_option = st.selectbox(
            "Start from template",
            ["Blank"] + [t['name'] for t in st.session_state.workflow_templates],
            key="yaml_template"
        )
        
        # Load template YAML
        if template_option != "Blank":
            template = next((t for t in st.session_state.workflow_templates 
                           if t['name'] == template_option), None)
            if template:
                initial_yaml = self._generate_template_yaml(template)
            else:
                initial_yaml = self._get_blank_yaml()
        else:
            initial_yaml = self._get_blank_yaml()
        
        # YAML editor
        yaml_content = st.text_area(
            "Workflow YAML",
            value=initial_yaml,
            height=400,
            key="yaml_editor_content"
        )
        
        # Validation and actions
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("✅ Validate YAML", use_container_width=True):
                self._validate_yaml(yaml_content)
        
        with col2:
            if st.button("💾 Save Workflow", type="primary", use_container_width=True):
                self._save_yaml_workflow(yaml_content)
        
        with col3:
            if st.button("▶️ Execute", use_container_width=True):
                self._execute_yaml_workflow(yaml_content)
        
        # YAML reference
        with st.expander("📚 YAML Reference"):
            st.markdown("""
            ```yaml
            name: My Workflow
            description: Workflow description
            version: 1.0
            
            parameters:
              input_path: s3://bucket/input
              output_path: s3://bucket/output
            
            steps:
              - id: step1
                type: input
                source: ${input_path}
                
              - id: step2
                type: process
                operation: transform
                input: step1
                
              - id: step3
                type: output
                destination: ${output_path}
                input: step2
            ```
            """)
    
    def _render_code_editor(self):
        """Render code-based workflow editor."""
        st.markdown("#### 💻 Code Workflow Editor")
        
        # Language selector
        language = st.selectbox(
            "Language",
            ["Python", "JavaScript", "YAML"],
            key="code_language"
        )
        
        # Code editor
        code_content = st.text_area(
            f"{language} Code",
            value=self._get_code_template(language),
            height=400,
            key="code_editor_content"
        )
        
        # Actions
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if st.button("🔍 Syntax Check", use_container_width=True):
                self._check_syntax(code_content, language)
        
        with col2:
            if st.button("💾 Save Code", type="primary", use_container_width=True):
                self._save_code_workflow(code_content, language)
        
        with col3:
            if st.button("▶️ Run", use_container_width=True):
                self._run_code_workflow(code_content, language)
    
    def _render_active_workflows(self):
        """Render active workflows monitoring."""
        st.markdown("### 📊 Active Workflows")
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Running", len([w for w in st.session_state.active_workflows 
                                    if w.get('status') == 'running']), "↑2")
        with col2:
            st.metric("Queued", len([w for w in st.session_state.active_workflows 
                                   if w.get('status') == 'queued']), "↓1")
        with col3:
            st.metric("Completed Today", 15, "+3")
        with col4:
            st.metric("Failed", 2, "0")
        
        st.markdown("---")
        
        # Active workflows list
        if st.session_state.active_workflows:
            for workflow in st.session_state.active_workflows:
                with st.container():
                    col1, col2, col3, col4, col5 = st.columns([3, 2, 2, 1, 1])
                    
                    with col1:
                        st.markdown(f"**{workflow['name']}**")
                        st.caption(f"ID: {workflow['id']}")
                    
                    with col2:
                        status_color = {
                            "running": "🟢",
                            "queued": "🟡",
                            "completed": "✅",
                            "failed": "❌"
                        }.get(workflow['status'], "⚪")
                        st.markdown(f"{status_color} {workflow['status'].title()}")
                    
                    with col3:
                        progress = workflow.get('progress', 0)
                        st.progress(progress / 100)
                        st.caption(f"{progress}%")
                    
                    with col4:
                        if st.button("👁️", key=f"view_{workflow['id']}", help="View Details"):
                            self._view_workflow_details(workflow['id'])
                    
                    with col5:
                        if workflow['status'] == 'running':
                            if st.button("⏹️", key=f"stop_{workflow['id']}", help="Stop"):
                                self._stop_workflow(workflow['id'])
                    
                    st.markdown("---")
        else:
            st.info("No active workflows. Start a new workflow from the Execute tab.")
        
        # Auto-refresh
        col1, col2 = st.columns([3, 1])
        with col2:
            auto_refresh = st.checkbox("Auto-refresh (5s)", key="auto_refresh_workflows")
            if auto_refresh:
                st.rerun()
    
    def _render_analytics_history(self):
        """Render workflow analytics and history."""
        st.markdown("### 📈 Workflow Analytics & History")
        
        # Time range selector
        col1, col2 = st.columns([3, 1])
        
        with col1:
            time_range = st.selectbox(
                "Time Range",
                ["Last 24 Hours", "Last 7 Days", "Last 30 Days", "Custom"],
                key="analytics_time_range"
            )
        
        with col2:
            if st.button("🔄 Refresh", use_container_width=True):
                st.rerun()
        
        # Analytics metrics
        st.markdown("#### 📊 Performance Metrics")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Executions", "234", "+12%")
        with col2:
            st.metric("Success Rate", "94.2%", "+2.1%")
        with col3:
            st.metric("Avg Duration", "4.5 min", "-30s")
        with col4:
            st.metric("Resource Usage", "67%", "-5%")
        
        # Charts
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("##### Workflow Executions")
            st.line_chart({"Executions": [20, 25, 22, 30, 28, 35, 32]})
        
        with col2:
            st.markdown("##### Success/Failure Rate")
            st.bar_chart({"Success": [18, 23, 20, 28, 26, 33, 30],
                          "Failed": [2, 2, 2, 2, 2, 2, 2]})
        
        st.markdown("---")
        
        # Workflow history
        st.markdown("#### 📜 Execution History")
        
        # Filters
        col1, col2, col3 = st.columns(3)
        
        with col1:
            status_filter = st.multiselect(
                "Status",
                ["All", "Completed", "Failed", "Cancelled"],
                default=["All"],
                key="history_status_filter"
            )
        
        with col2:
            workflow_filter = st.selectbox(
                "Workflow",
                ["All"] + [t['name'] for t in st.session_state.workflow_templates],
                key="history_workflow_filter"
            )
        
        with col3:
            search_history = st.text_input(
                "Search",
                placeholder="Search history...",
                key="search_history"
            )
        
        # History table
        history_data = self._get_workflow_history()
        
        if history_data:
            import pandas as pd
            df = pd.DataFrame(history_data)
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No workflow history available")
    
    def _render_configuration(self):
        """Render workflow configuration settings."""
        st.markdown("### ⚙️ Workflow Configuration")
        
        # Gateway configuration
        st.markdown("#### 🔌 Workflow Optimizer Gateway")
        
        col1, col2 = st.columns(2)
        
        with col1:
            max_parallel = st.number_input(
                "Max Parallel Workflows",
                min_value=1,
                max_value=20,
                value=5,
                key="config_max_parallel"
            )
            
            default_timeout = st.number_input(
                "Default Timeout (minutes)",
                min_value=1,
                max_value=240,
                value=30,
                key="config_timeout"
            )
        
        with col2:
            retry_policy = st.selectbox(
                "Retry Policy",
                ["Exponential Backoff", "Linear", "Fixed Delay"],
                key="config_retry_policy"
            )
            
            max_retries = st.number_input(
                "Max Retries",
                min_value=0,
                max_value=10,
                value=3,
                key="config_max_retries"
            )
        
        st.markdown("---")
        
        # Resource limits
        st.markdown("#### 🎯 Resource Limits")
        
        col1, col2 = st.columns(2)
        
        with col1:
            cpu_limit = st.slider(
                "CPU Limit (%)",
                min_value=10,
                max_value=100,
                value=80,
                key="config_cpu_limit"
            )
            
            memory_limit = st.slider(
                "Memory Limit (GB)",
                min_value=1,
                max_value=32,
                value=8,
                key="config_memory_limit"
            )
        
        with col2:
            io_limit = st.slider(
                "I/O Limit (MB/s)",
                min_value=10,
                max_value=1000,
                value=100,
                key="config_io_limit"
            )
            
            network_limit = st.slider(
                "Network Limit (Mbps)",
                min_value=10,
                max_value=1000,
                value=100,
                key="config_network_limit"
            )
        
        st.markdown("---")
        
        # Notification settings
        st.markdown("#### 📬 Notifications")
        
        col1, col2 = st.columns(2)
        
        with col1:
            enable_notifications = st.checkbox(
                "Enable Notifications",
                value=True,
                key="config_enable_notifications"
            )
            
            if enable_notifications:
                notification_channels = st.multiselect(
                    "Notification Channels",
                    ["Email", "Slack", "Teams", "Webhook"],
                    default=["Email"],
                    key="config_notification_channels"
                )
        
        with col2:
            notify_on = st.multiselect(
                "Notify On",
                ["Start", "Complete", "Failure", "Warning"],
                default=["Complete", "Failure"],
                key="config_notify_on"
            )
            
            notification_email = st.text_input(
                "Notification Email",
                placeholder="admin@company.com",
                key="config_notification_email"
            )
        
        # Save configuration
        if st.button("💾 Save Configuration", type="primary", use_container_width=True):
            self._save_workflow_configuration()
    
    def _execute_workflow(self, template: Dict[str, Any], input_path: str, output_path: str):
        """Execute a workflow."""
        with st.spinner(f"Executing {template['name']}..."):
            try:
                # Create workflow instance
                workflow_id = str(uuid.uuid4())[:8]
                
                # Add to active workflows
                st.session_state.active_workflows.append({
                    "id": workflow_id,
                    "name": template['name'],
                    "status": "running",
                    "progress": 0,
                    "started": datetime.now().isoformat()
                })
                
                # Execute via gateway
                if self.workflow_gateway:
                    result = self.workflow_gateway.execute({
                        "template_id": template['id'],
                        "input": input_path,
                        "output": output_path,
                        "parameters": {
                            "timeout": st.session_state.workflow_timeout,
                            "mode": st.session_state.execution_mode,
                            "priority": st.session_state.execution_priority
                        }
                    })
                    
                    st.success(f"✅ Workflow {workflow_id} started successfully!")
                    st.json(result)
                else:
                    st.error("Workflow gateway not available")
                    
            except Exception as e:
                st.error(f"Failed to execute workflow: {e}")
    
    def _render_workflow_steps_preview(self, template: Dict[str, Any]):
        """Render workflow steps preview."""
        steps = [
            {"name": "Input", "description": "Load data from source"},
            {"name": "Validate", "description": "Validate input data"},
            {"name": "Process", "description": "Apply transformations"},
            {"name": "Analyze", "description": "Run analysis algorithms"},
            {"name": "Output", "description": "Save results to destination"}
        ]
        
        for i, step in enumerate(steps[:template['steps']], 1):
            st.markdown(f"**Step {i}: {step['name']}**")
            st.caption(step['description'])
            if i < len(steps):
                st.markdown("↓")
    
    def _filter_templates(self, categories: List[str], search: str) -> List[Dict[str, Any]]:
        """Filter workflow templates."""
        templates = st.session_state.workflow_templates
        
        # Filter by category
        if "All" not in categories:
            templates = [t for t in templates if t['category'] in categories]
        
        # Filter by search term
        if search:
            templates = [t for t in templates 
                        if search.lower() in t['name'].lower() 
                        or search.lower() in t['description'].lower()]
        
        return templates
    
    def _get_blank_yaml(self) -> str:
        """Get blank YAML template."""
        return """name: New Workflow
description: Workflow description here
version: 1.0

parameters:
  input_path: ""
  output_path: ""

steps:
  - id: step1
    type: input
    source: ${input_path}
    
  - id: step2
    type: process
    operation: transform
    input: step1
    
  - id: step3
    type: output
    destination: ${output_path}
    input: step2
"""
    
    def _generate_template_yaml(self, template: Dict[str, Any]) -> str:
        """Generate YAML from template."""
        return f"""name: {template['name']}
description: {template['description']}
category: {template['category']}
version: 1.0

parameters:
  input_path: ""
  output_path: ""
  
steps:
  # Add your workflow steps here
  - id: step1
    type: input
    source: ${{input_path}}
"""
    
    def _get_code_template(self, language: str) -> str:
        """Get code template for language."""
        if language == "Python":
            return """# TidyLLM Workflow Script
from tidyllm.flow import Workflow

# Define workflow
workflow = Workflow("My Workflow")

# Add steps
workflow.add_step("input", source="s3://bucket/input")
workflow.add_step("process", operation="transform")
workflow.add_step("output", destination="s3://bucket/output")

# Execute
workflow.run()
"""
        elif language == "JavaScript":
            return """// TidyLLM Workflow Script
const { Workflow } = require('tidyllm');

// Define workflow
const workflow = new Workflow('My Workflow');

// Add steps
workflow.addStep('input', { source: 's3://bucket/input' });
workflow.addStep('process', { operation: 'transform' });
workflow.addStep('output', { destination: 's3://bucket/output' });

// Execute
workflow.run();
"""
        else:
            return self._get_blank_yaml()
    
    def _get_workflow_history(self) -> List[Dict[str, Any]]:
        """Get workflow execution history."""
        # Placeholder data
        return [
            {
                "Workflow": "Data Processing Pipeline",
                "Status": "✅ Completed",
                "Duration": "4.2 min",
                "Started": "2024-01-20 14:30",
                "User": "admin"
            },
            {
                "Workflow": "Document Analysis",
                "Status": "✅ Completed",
                "Duration": "3.8 min",
                "Started": "2024-01-20 14:00",
                "User": "user1"
            },
            {
                "Workflow": "Report Generation",
                "Status": "❌ Failed",
                "Duration": "2.1 min",
                "Started": "2024-01-20 13:45",
                "User": "admin"
            }
        ]
    
    def _save_workflow_configuration(self):
        """Save workflow configuration."""
        config = {
            "max_parallel": st.session_state.config_max_parallel,
            "default_timeout": st.session_state.config_timeout,
            "retry_policy": st.session_state.config_retry_policy,
            "max_retries": st.session_state.config_max_retries,
            "resource_limits": {
                "cpu": st.session_state.config_cpu_limit,
                "memory": st.session_state.config_memory_limit,
                "io": st.session_state.config_io_limit,
                "network": st.session_state.config_network_limit
            },
            "notifications": {
                "enabled": st.session_state.config_enable_notifications,
                "channels": st.session_state.get('config_notification_channels', []),
                "events": st.session_state.config_notify_on,
                "email": st.session_state.config_notification_email
            }
        }
        
        st.success("✅ Configuration saved successfully!")
        st.json(config)
    
    # Placeholder methods for actions
    def _edit_template(self, template): st.info(f"Editing {template['name']}")
    def _duplicate_template(self, template): st.info(f"Duplicating {template['name']}")
    def _import_template(self): st.info("Import template functionality")
    def _export_templates(self): st.info("Export templates functionality")
    def _validate_yaml(self, content): st.success("✅ YAML is valid")
    def _save_yaml_workflow(self, content): st.success("✅ Workflow saved")
    def _execute_yaml_workflow(self, content): st.info("Executing YAML workflow")
    def _check_syntax(self, content, lang): st.success(f"✅ {lang} syntax is valid")
    def _save_code_workflow(self, content, lang): st.success(f"✅ {lang} workflow saved")
    def _run_code_workflow(self, content, lang): st.info(f"Running {lang} workflow")
    def _save_built_workflow(self): st.success("✅ Visual workflow saved")
    def _test_built_workflow(self): st.info("Testing built workflow")
    def _view_workflow_details(self, wf_id): st.info(f"Viewing details for {wf_id}")
    def _stop_workflow(self, wf_id): st.warning(f"Stopping workflow {wf_id}")


def render_tidyllm_workflows_page():
    """Convenience function to render TidyLLM workflows page."""
    workflows = TidyLLMWorkflowInterface()
    workflows.render()