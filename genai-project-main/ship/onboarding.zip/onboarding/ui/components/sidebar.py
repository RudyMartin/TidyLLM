"""
TidyLLM Onboarding Sidebar Component
====================================

Navigation sidebar for the onboarding system.
"""

import streamlit as st
from tidyllm_system_status import TidyLLMSystemStatus

def check_tidyllm_installation():
    """Check if TidyLLM is properly installed as a package."""
    try:
        import tidyllm
        # Check if it's installed as a package (not just in path)
        import importlib.util
        spec = importlib.util.find_spec('tidyllm')
        if spec and spec.origin:
            # Check if it's from site-packages (properly installed)
            if 'site-packages' in spec.origin or 'dist-packages' in spec.origin:
                return 'installed', spec.origin
            else:
                return 'development', spec.origin
        return 'development', 'Local path'
    except ImportError:
        return 'missing', None

def render_sidebar():
    """Render the navigation sidebar."""
    
    st.sidebar.title("TidyLLM Enterprise")
    st.sidebar.markdown("**Corporate AI Platform Showcase**")
    st.sidebar.markdown("---")
    
    # Navigation menu - TidyLLM Feature Showcase (Reorganized)
    pages = [
        "Initialize System",
        "System Configuration", 
        "Quick Start (Guided Setup)",
        "Gateway Architecture",
        "AI Chat & Processing",
        "Knowledge Systems",
        "Workflow Automation",
        "Analytics Dashboard",
        "Testing Suite"
    ]
    
    selected_page = st.sidebar.selectbox(
        "Select Section",
        pages,
        index=0
    )
    
    st.sidebar.markdown("---")
    
    # TidyLLM Architecture Status using native integration
    st.sidebar.subheader("🏗️ System Status")
    
    # Get system health from TidyLLM
    system_health = TidyLLMSystemStatus.get_system_health()
    
    if system_health['status'] != 'error':
        # Show overall system health using TidyLLM data
        healthy_count = system_health.get('healthy_count', 0)
        total_count = system_health.get('total_count', 0)
        
        if healthy_count >= 3:  # Good coverage
            st.sidebar.success(f"🎉 System Operational")
            st.sidebar.caption(f"✅ {healthy_count}/{total_count} components ready")
        elif healthy_count > 0:
            st.sidebar.warning(f"⚠️ System Partial")
            st.sidebar.caption(f"⚠️ {healthy_count}/{total_count} components online")
        else:
            st.sidebar.error("❌ System Offline")
            st.sidebar.caption("❌ All components offline")
        
        # Show TidyLLM components
        components = system_health.get('components', {})
        
        # Show services first
        service_components = {k: v for k, v in components.items() if v.get('type') == 'service'}
        if service_components:
            st.sidebar.markdown("**Services:**")
            for name, comp in service_components.items():
                status_icon = "✅" if comp.get('healthy', False) else "❌"
                display_name = name.replace('_', ' ').title()
                st.sidebar.markdown(f"{status_icon} ⚙️ {display_name}")
        
        # Show TidyLLM gateways
        gateway_components = {k: v for k, v in components.items() if v.get('type') == 'gateway'}
        if gateway_components:
            st.sidebar.markdown("**Gateways:**")
            
            # Gateway icons and display names
            gateway_config = {
                'corporate_llm': {'icon': '🤖', 'display': 'Corporate LLM'},
                'ai_processing': {'icon': '🧠', 'display': 'AI Processing'}, 
                'workflow_optimizer': {'icon': '⚙️', 'display': 'Workflow Optimizer'},
                'context_gateway': {'icon': '📚', 'display': 'Context'},
                'database': {'icon': '📚', 'display': 'Context'}
            }
            
            # Display gateways
            for gateway_name, comp in gateway_components.items():
                config = gateway_config.get(gateway_name, {'icon': '🔧', 'display': gateway_name.replace('_', ' ').title()})
                status_icon = "✅" if comp.get('healthy', False) else "❌"
                st.sidebar.markdown(f"{status_icon} {config['icon']} {config['display']}")
        
        # Add quick refresh
        st.sidebar.markdown("---")
        if st.sidebar.button("🔄 Refresh Status"):
            # Safe refresh - just rerun to update status display
            st.rerun()
            
    else:
        st.sidebar.error("🚨 System Status Unknown")
        st.sidebar.markdown(f"**Error: {system_health.get('message', 'Unknown error')}**")
        if st.sidebar.button("🚀 Initialize System"):
            # Safe initialization - just rerun to trigger app initialization
            st.rerun()
    
    # Check services separately
    if hasattr(st.session_state, 'services') and st.session_state.services:
        st.sidebar.markdown("**Utility Services:**")
        
        # Service display icons
        service_icons = {
            'context_support': '📚',  # Context Support Service
            'file_storage': '📁',
            'mvr_document': '📝',
            'mlflow_integration': '🔗'
        }
        
        for name, service in st.session_state.services.items():
            icon = service_icons.get(name, '🔧')
            display_name = name.replace('_', ' ').title()
            
            if service is None:
                st.sidebar.error(f"❌ {icon} {display_name}")
            else:
                # Special handling for MLflow to show connection status
                if name == 'mlflow_integration' and hasattr(service, 'is_available'):
                    if service.is_available():
                        st.sidebar.success(f"✅ {icon} {display_name} (Connected)")
                    else:
                        st.sidebar.warning(f"⚠️ {icon} {display_name} (Offline)")
                else:
                    st.sidebar.success(f"✅ {icon} {display_name}")
    
    st.sidebar.markdown("---")
    
    # Quick actions
    st.sidebar.subheader("Quick Actions")
    
    if st.sidebar.button("🔄 Refresh System"):
        # Safe refresh - just rerun to update system status
        st.rerun()
    
    # Remove unsafe buttons that could cause errors
    # if st.sidebar.button("🚀 Force USM Init"):
    #     # REMOVED: Could cause initialization conflicts
    
    # if st.sidebar.button("🧪 Run Tests"):
    #     # REMOVED: Could trigger unexpected test runs
    
    st.sidebar.markdown("---")
    
    # Help section
    st.sidebar.subheader("Help")
    # TidyLLM Installation Status (Bottom of sidebar)
    st.sidebar.markdown("---")
    
    installation_status, install_path = check_tidyllm_installation()
    
    if installation_status == 'missing':
        if st.sidebar.button("🔴 TidyLLM Not Installed", key="tidyllm_missing", 
                            help="Click to configure system integration"):
            st.session_state.show_system_config = True
            st.sidebar.error("⚠️ TidyLLM package not found!")
            st.sidebar.info("🔧 Opening System Integration Config...")
            st.rerun()
    elif installation_status == 'development':
        st.sidebar.warning("🟠 TidyLLM (Dev Mode)")
        st.sidebar.caption(f"Path: {install_path[:30]}..." if install_path and len(install_path) > 30 else f"Path: {install_path}")
    else:
        st.sidebar.success("🟢 TidyLLM Installed")
        st.sidebar.caption(f"v{getattr(tidyllm, '__version__', 'unknown')}" if 'tidyllm' in locals() else "Version unknown")
    
    st.sidebar.markdown("""
    **Getting Started:**
    1. Configure connections in Connection Config
    2. Test AI models in Chat Test
    3. Set up knowledge domains
    4. Configure workflows
    5. Test end-to-end processing
    6. Monitor system in Dashboard
    """)
    
    # Check if we need to show system config dialog
    if hasattr(st.session_state, 'show_system_config') and st.session_state.show_system_config:
        show_system_integration_config()
        st.session_state.show_system_config = False
    
    return selected_page

def show_system_integration_config():
    """Show system integration configuration dialog."""
    with st.sidebar.expander("🔧 System Integration Config", expanded=True):
        st.markdown("### TidyLLM Installation Required")
        
        st.markdown("""
        **Installation Options:**
        
        1. **Production Install** (Recommended):
        ```bash
        pip install tidyllm
        ```
        
        2. **Development Install** (Editable):
        ```bash
        cd /path/to/tidyllm
        pip install -e .
        ```
        
        3. **From GitHub**:
        ```bash
        pip install git+https://github.com/yourusername/tidyllm.git
        ```
        """)
        
        st.markdown("### Missing Components:")
        missing_items = check_missing_components()
        for item in missing_items:
            st.error(f"❌ {item}")
        
        st.markdown("### System Status:")
        show_system_status()
        
        if st.button("Retry Detection", key="retry_tidyllm"):
            st.rerun()

def check_missing_components():
    """Check for missing TidyLLM components."""
    missing = []
    
    components = [
        ('tidyllm', 'Core TidyLLM Package'),
        ('tidyllm.gateways', 'Gateway Components'),
        ('tidyllm.infrastructure', 'Infrastructure Layer'),
        ('tidyllm.services', 'Service Components'),
        ('tlm', 'TLM (NumPy replacement)'),
        ('tidyllm_sentence', 'Sentence Transformers')
    ]
    
    for module, description in components:
        try:
            __import__(module)
        except ImportError:
            missing.append(description)
    
    return missing if missing else ["All components available!"]

def show_system_status():
    """Show detailed system status."""
    status_items = []
    
    # Check Python version
    import sys
    py_version = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    status_items.append(("🐍 Python", py_version, "success"))
    
    # Check critical packages
    packages = [
        ('streamlit', '🌐 Streamlit'),
        ('boto3', '☁️ AWS SDK'),
        ('psycopg2', '🐘 PostgreSQL'),
        ('numpy', '🔢 NumPy'),
        ('pandas', '🐼 Pandas')
    ]
    
    for pkg_name, display_name in packages:
        try:
            pkg = __import__(pkg_name)
            version = getattr(pkg, '__version__', 'installed')
            status_items.append((display_name, version, "success"))
        except ImportError:
            status_items.append((display_name, "missing", "error"))
    
    for name, version, status in status_items:
        if status == "success":
            st.success(f"✅ {name}: {version}")
        else:
            st.error(f"❌ {name}: {version}")
