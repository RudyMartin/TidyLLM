"""
TidyLLM Native Sidebar Component
================================

Navigation sidebar using TidyLLM's native interface components.
"""

from tidyllm.interfaces.web import TidyLLMWebInterface
from tidyllm.gateways.gateway_registry import get_global_registry
from tidyllm.infrastructure.session.unified import UnifiedSessionManager
import streamlit as st
from typing import Optional, Dict, Any

class TidyLLMSidebar:
    """TidyLLM-native sidebar component."""
    
    def __init__(self, session_manager: Optional[UnifiedSessionManager] = None):
        """Initialize with TidyLLM components."""
        self.registry = get_global_registry()
        self.session_manager = session_manager or st.session_state.get('tidyllm_session_manager')
        
    def render(self) -> str:
        """Render the navigation sidebar using TidyLLM components."""
        
        # Title using TidyLLM branding
        st.sidebar.title("🚀 TidyLLM Enterprise")
        st.sidebar.markdown("**Unified AI Platform**")
        st.sidebar.markdown("---")
        
        # Navigation menu - TidyLLM native pages
        pages = [
            "🚀 Initialize System",
            "🔧 System Configuration", 
            "🎯 Quick Start",
            "🔌 Gateway Management",
            "🧠 AI Processing",
            "📚 Knowledge Systems",
            "⚙️ Workflow Automation",
            "📊 Analytics Dashboard",
            "🧪 Testing Suite"
        ]
        
        selected_page = st.sidebar.selectbox(
            "Navigate",
            pages,
            index=0,
            key="tidyllm_nav"
        )
        
        st.sidebar.markdown("---")
        
        # System Status using TidyLLM registry
        self._render_system_status()
        
        st.sidebar.markdown("---")
        
        # TidyLLM Info
        self._render_tidyllm_info()
        
        return selected_page
    
    def _render_system_status(self):
        """Render system status using TidyLLM registry."""
        st.sidebar.subheader("🏗️ System Status")
        
        # Get service status from registry
        services = self.registry.list_services()
        
        # Count active services
        active_count = sum(1 for s in services if s.get('initialized', False))
        total_count = len(services)
        
        # Overall status
        if active_count == total_count and total_count > 0:
            st.sidebar.success(f"✅ All Systems Operational")
        elif active_count > 0:
            st.sidebar.warning(f"⚠️ Partial ({active_count}/{total_count})")
        else:
            st.sidebar.error("❌ System Offline")
        
        # Show gateway details
        if services:
            st.sidebar.markdown("**Gateways:**")
            
            gateway_icons = {
                'corporate_llm': '🤖',
                'ai_processing': '🧠',
                'workflow_optimizer': '⚙️',
                'database': '💾'
            }
            
            for service in services:
                service_type = service.get('service_type', 'unknown')
                icon = gateway_icons.get(service_type, '📦')
                status = "✅" if service.get('initialized', False) else "❌"
                name = service_type.replace('_', ' ').title()
                
                st.sidebar.markdown(f"{status} {icon} {name}")
        
        # Session Manager status
        if self.session_manager:
            st.sidebar.markdown("**Session Manager:**")
            
            # Check AWS connection
            try:
                s3_client = self.session_manager.get_s3_client()
                if s3_client:
                    st.sidebar.markdown("✅ 🔐 AWS Connected")
                else:
                    st.sidebar.markdown("❌ 🔐 AWS Disconnected")
            except:
                st.sidebar.markdown("❌ 🔐 AWS Error")
            
            # Check Bedrock
            try:
                bedrock_client = self.session_manager.get_bedrock_client()
                if bedrock_client:
                    st.sidebar.markdown("✅ 🤖 Bedrock Ready")
                else:
                    st.sidebar.markdown("❌ 🤖 Bedrock Offline")
            except:
                st.sidebar.markdown("❌ 🤖 Bedrock Error")
    
    def _render_tidyllm_info(self):
        """Render TidyLLM information."""
        st.sidebar.subheader("ℹ️ About TidyLLM")
        
        # Check TidyLLM installation
        try:
            import tidyllm
            import importlib.util
            spec = importlib.util.find_spec('tidyllm')
            
            if spec and spec.origin:
                if 'site-packages' in spec.origin:
                    st.sidebar.info("📦 Package: Installed")
                else:
                    st.sidebar.info("🔧 Package: Development")
            
            # Show version if available
            if hasattr(tidyllm, '__version__'):
                st.sidebar.caption(f"Version: {tidyllm.__version__}")
            
        except ImportError:
            st.sidebar.warning("⚠️ TidyLLM not found")
        
        # Architecture info
        with st.sidebar.expander("Architecture"):
            st.markdown("""
            **4-Gateway Design:**
            - Corporate LLM Gateway
            - AI Processing Gateway
            - Workflow Optimizer
            - Database Gateway
            
            **Pure Python:**
            - Air-gapped compatible
            - Zero external deps
            - Corporate-safe
            """)


def render_tidyllm_sidebar() -> str:
    """Convenience function to render TidyLLM sidebar."""
    sidebar = TidyLLMSidebar()
    return sidebar.render()