# DBA Configuration Portal v3

## Quick Start for Tired DBAs

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the Portal
```bash
streamlit run dba_config_portal.py
```

### 3. Open in Browser
Navigate to: http://localhost:8501

## Features

1. **Upload Settings** - Drag & drop your settings.yaml
2. **View Configuration** - See all sections clearly
3. **Edit Credentials** - Fix what's broken
4. **Test Connections** - Verify everything works
   - S3 bucket access
   - Bedrock AI model
   - PostgreSQL/Aurora database
   - MLflow tracking server
5. **Save Configuration** - Save your changes

## Environment Variables

### Windows (Command Prompt)
```cmd
set TIDYLLM_CONFIG_PATH=C:\MyApp\settings.yaml
set AWS_ACCESS_KEY_ID=your_key_here
set AWS_SECRET_ACCESS_KEY=your_secret_here
```

### Windows (PowerShell)
```powershell
$env:TIDYLLM_CONFIG_PATH="C:\MyApp\settings.yaml"
$env:AWS_ACCESS_KEY_ID="your_key_here"
$env:AWS_SECRET_ACCESS_KEY="your_secret_here"
```

### Linux/Mac
```bash
export TIDYLLM_CONFIG_PATH=/opt/myapp/settings.yaml
export AWS_ACCESS_KEY_ID=your_key_here
export AWS_SECRET_ACCESS_KEY=your_secret_here
```

## Common Config Locations

- Development: `tidyllm/admin/settings.yaml`
- Linux System: `/etc/tidyllm/settings.yaml`
- Windows System: `C:/ProgramData/TidyLLM/settings.yaml`
- User Home: `~/.tidyllm/settings.yaml`

## Troubleshooting

### Portal won't start?
- Check Python version: `python --version` (needs 3.8+)
- Reinstall requirements: `pip install -r requirements.txt --upgrade`

### Can't connect to services?
- Check your AWS credentials in settings.yaml
- Verify network connectivity
- Ensure services are running (MLflow, database, etc.)

### Settings won't save?
- Check file permissions
- Ensure you have write access to the directory
- Try downloading the YAML instead

---
Generated: 2025-09-16 14:20:27
Version: DBA Config Portal v3
