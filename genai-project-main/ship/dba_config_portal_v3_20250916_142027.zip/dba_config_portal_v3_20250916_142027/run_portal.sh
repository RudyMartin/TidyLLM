#!/bin/bash
echo "Starting DBA Configuration Portal..."
echo ""
echo "Portal will open at http://localhost:8501"
echo "Press Ctrl+C to stop the server"
echo ""
streamlit run dba_config_portal.py
