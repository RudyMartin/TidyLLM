#!/usr/bin/env python3
"""
DBA-Friendly Configuration Portal v3
===================================

For overworked, sleepy DBAs who just want to:
1. Upload a settings file
2. See what's in it clearly
3. Fix what's broken
4. Test the connections
5. Save and go home

Now with full connection testing and base path detection!
"""

import streamlit as st
import yaml
import os
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional

def detect_base_path() -> Optional[Path]:
    """Detect the project base path by looking for key indicators"""
    current = Path(__file__).resolve()

    # Walk up the directory tree looking for project indicators
    indicators = [
        'tidyllm/admin/settings.yaml',  # Our main settings file
        '.git',  # Git repository root
        'requirements.txt',  # Python project root
        'specs.json',  # Project specific file
    ]

    # Start from current file and go up
    for parent in current.parents:
        for indicator in indicators:
            if (parent / indicator).exists():
                return parent

    # Fallback to current working directory
    return Path.cwd()

# Get base path once at module load
BASE_PATH = detect_base_path()
if 'base_path' not in st.session_state:
    st.session_state.base_path = BASE_PATH

# Page config
st.set_page_config(
    page_title="DBA Config Portal v3",
    page_icon="🔧",
    layout="wide"
)

st.title("🔧 DBA Configuration Portal v3")
st.markdown("*For overworked DBAs who just want to get stuff done*")

def load_settings_from_upload(uploaded_file):
    """Load settings from uploaded file"""
    try:
        content = uploaded_file.getvalue().decode('utf-8')
        return yaml.safe_load(content)
    except Exception as e:
        st.error(f"Error loading file: {e}")
        return None

def save_settings(settings, path=None):
    """Save settings to file using search_paths from YAML"""
    if not path:
        # Use search_paths from the settings itself if available
        search_paths = settings.get('search_paths', [])

        # Fallback to default paths if no search_paths in YAML
        if not search_paths:
            search_paths = [
                {'path': 'tidyllm/admin/settings.yaml', 'description': 'Default location'},
                {'path': './settings.yaml', 'description': 'Current directory'}
            ]

        # Try paths from search_paths configuration
        for path_config in search_paths:
            try:
                # Use base path for relative paths
                path = BASE_PATH / path_config['path']
                if path.exists() or path.parent.exists():
                    with open(path, 'w', encoding='utf-8') as f:
                        yaml.dump(settings, f, default_flow_style=False, indent=2)
                    return str(path)
            except Exception:
                continue

        # If nothing worked, try to create in first location
        try:
            path = BASE_PATH / search_paths[0]['path']
            path.parent.mkdir(parents=True, exist_ok=True)
            with open(path, 'w', encoding='utf-8') as f:
                yaml.dump(settings, f, default_flow_style=False, indent=2)
            return str(path)
        except Exception as e:
            st.error(f"Could not save file: {e}")
            return None
    else:
        # Save to specific path
        try:
            with open(path, 'w', encoding='utf-8') as f:
                yaml.dump(settings, f, default_flow_style=False, indent=2)
            return str(path)
        except Exception as e:
            st.error(f"Error saving to {path}: {e}")
            return None

def extract_key_sections(settings):
    """Extract key configuration sections"""
    sections = {}

    if 'credentials' in settings:
        sections['Credentials'] = settings['credentials']

    if 'system' in settings:
        sections['System'] = settings['system']

    if 'services' in settings:
        sections['Services'] = settings['services']

    if 'search_paths' in settings:
        sections['Search Paths'] = settings['search_paths']

    # Add any other top-level configs
    for key, value in settings.items():
        if key not in ['credentials', 'system', 'services', 'search_paths'] and isinstance(value, dict):
            sections[key.replace('_', ' ').title()] = value

    return sections

# Sidebar - Path Examples & Environment Variables for Tired DBAs
with st.sidebar:
    st.header("🎯 Detected Base Path")
    st.code(str(BASE_PATH))
    st.success(f"✅ Auto-detected project root")
    st.markdown("---")

    st.header("📚 Quick Examples for DBAs")

    st.subheader("🔧 Environment Variables")
    st.markdown("""
    **Windows (Command Prompt):**
    ```cmd
    set TIDYLLM_CONFIG_PATH=C:\\MyApp\\settings.yaml
    set CONFIG_DIR=C:\\MyApp\\config
    ```

    **Windows (PowerShell):**
    ```powershell
    $env:TIDYLLM_CONFIG_PATH="C:\\MyApp\\settings.yaml"
    ```

    **Linux/Mac:**
    ```bash
    export TIDYLLM_CONFIG_PATH=/opt/myapp/settings.yaml
    export CONFIG_DIR=/opt/myapp/config
    ```
    """)

    # Show current environment variables
    current_env_vars = {
        'TIDYLLM_CONFIG_PATH': os.getenv('TIDYLLM_CONFIG_PATH', 'Not set'),
        'CONFIG_DIR': os.getenv('CONFIG_DIR', 'Not set'),
        'SECURE_CONFIG_PATH': os.getenv('SECURE_CONFIG_PATH', 'Not set')
    }

    st.subheader("📊 Your Current Environment")
    for var, value in current_env_vars.items():
        if value != 'Not set':
            st.success(f"✅ {var}: `{value}`")
        else:
            st.info(f"ℹ️ {var}: {value}")

    st.subheader("📁 Common Config Locations")
    st.markdown("""
    **Development:**
    - `tidyllm/admin/settings.yaml`
    - `admin/settings.yaml`
    - `./settings.yaml`

    **Production:**
    - `/etc/tidyllm/settings.yaml` (Linux)
    - `/opt/tidyllm/config/settings.yaml`
    - `C:/Program Files/TidyLLM/config/settings.yaml` (Windows)
    - `~/.tidyllm/settings.yaml` (User home)
    """)

# Initialize session state
if 'temp_yaml' not in st.session_state:
    st.session_state.temp_yaml = None

# Main Content
col1, col2 = st.columns([2, 1])

with col1:
    # Step 1: Upload Settings
    with st.expander("📁 Step 1: Upload Your settings.yaml", expanded=True):
        uploaded_file = st.file_uploader(
            "Drop your settings.yaml here",
            type=['yaml', 'yml'],
            help="Drag and drop your settings.yaml file here"
        )

        if uploaded_file:
            settings = load_settings_from_upload(uploaded_file)
            if settings:
                st.session_state.temp_yaml = settings
                st.success(f"✅ Loaded {uploaded_file.name} successfully!")
                st.info(f"Found {len(settings)} top-level configuration sections")

    # Step 2: Show Configuration Sections
    if 'temp_yaml' in st.session_state and st.session_state.temp_yaml:
        with st.expander("📋 Step 2: Configuration Overview", expanded=True):
            sections = extract_key_sections(st.session_state.temp_yaml)

            st.markdown(f"**Found {len(sections)} configuration sections:**")

            for section_name, section_data in sections.items():
                with st.expander(f"🔍 {section_name}", expanded=False):
                    if isinstance(section_data, dict):
                        st.json(section_data)
                    else:
                        st.write(section_data)

        # Step 3: Edit Core Settings
        with st.expander("⚙️ Step 3: Edit Core Settings", expanded=True):
            if st.session_state.temp_yaml:
                # Credentials section
                st.subheader("🔐 Credentials")
                credentials = st.session_state.temp_yaml.get('credentials', {})

                # AWS Credentials
                if 'aws' in credentials:
                    aws_creds = credentials['aws']

                    col_a, col_b = st.columns(2)
                    with col_a:
                        new_aws_key = st.text_input("AWS Access Key",
                                                   value=aws_creds.get('access_key_id', ''),
                                                   type="password")
                        new_aws_region = st.selectbox("AWS Region",
                                                     ['us-east-1', 'us-west-2', 'eu-west-1'],
                                                     index=0 if aws_creds.get('default_region', 'us-east-1') == 'us-east-1' else 1)
                    with col_b:
                        new_aws_secret = st.text_input("AWS Secret Key",
                                                      value=aws_creds.get('secret_access_key', ''),
                                                      type="password")

                    # Update AWS credentials
                    if 'credentials' not in st.session_state.temp_yaml:
                        st.session_state.temp_yaml['credentials'] = {}
                    if 'aws' not in st.session_state.temp_yaml['credentials']:
                        st.session_state.temp_yaml['credentials']['aws'] = {}

                    st.session_state.temp_yaml['credentials']['aws']['access_key_id'] = new_aws_key
                    st.session_state.temp_yaml['credentials']['aws']['secret_access_key'] = new_aws_secret
                    st.session_state.temp_yaml['credentials']['aws']['default_region'] = new_aws_region

                # PostgreSQL Credentials
                if 'postgresql' in credentials:
                    pg_creds = credentials['postgresql']

                    st.subheader("🐘 PostgreSQL / Aurora")
                    col_a, col_b = st.columns(2)
                    with col_a:
                        new_pg_host = st.text_input("PostgreSQL Host", value=pg_creds.get('host', ''))
                        new_pg_port = st.number_input("Port", value=pg_creds.get('port', 5432), min_value=1, max_value=65535)
                        new_pg_db = st.text_input("Database", value=pg_creds.get('database', ''))
                    with col_b:
                        new_pg_user = st.text_input("Username", value=pg_creds.get('username', ''))
                        new_pg_pass = st.text_input("Password", value=pg_creds.get('password', ''), type="password")

                    # Update PostgreSQL credentials
                    if 'postgresql' not in st.session_state.temp_yaml['credentials']:
                        st.session_state.temp_yaml['credentials']['postgresql'] = {}

                    st.session_state.temp_yaml['credentials']['postgresql']['host'] = new_pg_host
                    st.session_state.temp_yaml['credentials']['postgresql']['port'] = new_pg_port
                    st.session_state.temp_yaml['credentials']['postgresql']['database'] = new_pg_db
                    st.session_state.temp_yaml['credentials']['postgresql']['username'] = new_pg_user
                    st.session_state.temp_yaml['credentials']['postgresql']['password'] = new_pg_pass

        # Step 4: Edit Search Paths
        with st.expander("🔍 Step 4: Edit Search Paths Configuration", expanded=False):
            if st.session_state.temp_yaml:
                search_paths = st.session_state.temp_yaml.get('search_paths', [])

                if not search_paths:
                    st.warning("No search_paths found. Creating default configuration...")
                    search_paths = [
                        {
                            'description': 'V2 Official admin config with credentials',
                            'path': 'tidyllm/admin/settings.yaml',
                            'permissions': '0600',
                            'v2_compliant': True
                        }
                    ]
                    st.session_state.temp_yaml['search_paths'] = search_paths

                st.subheader(f"📁 Current Search Paths ({len(search_paths)} configured)")

                # Add new path button
                col1, col2 = st.columns([3, 1])
                with col2:
                    if st.button("➕ Add Path", key="add_search_path"):
                        new_path = {
                            'description': 'New search path',
                            'path': './new_settings.yaml',
                            'permissions': '0600'
                        }
                        search_paths.append(new_path)
                        st.session_state.temp_yaml['search_paths'] = search_paths
                        st.rerun()

                # Edit each search path
                paths_to_remove = []
                for i, path_config in enumerate(search_paths):
                    with st.container():
                        st.markdown(f"**Path {i+1}:** `{path_config.get('path', 'Unknown')}`")

                        col1, col2, col3, col4 = st.columns([3, 2, 2, 1])

                        with col1:
                            new_desc = st.text_input(
                                "Description:",
                                value=path_config.get('description', ''),
                                key=f"desc_{i}"
                            )
                            new_path = st.text_input(
                                "Path:",
                                value=path_config.get('path', ''),
                                key=f"path_{i}"
                            )

                        with col2:
                            new_perms = st.text_input(
                                "Permissions:",
                                value=path_config.get('permissions', '0600'),
                                key=f"perms_{i}"
                            )

                        with col3:
                            v2_compliant = st.checkbox(
                                "V2 Compliant",
                                value=path_config.get('v2_compliant', False),
                                key=f"v2comp_{i}"
                            )
                            v2_fallback = st.checkbox(
                                "V2 Fallback",
                                value=path_config.get('v2_fallback', False),
                                key=f"v2fall_{i}"
                            )
                            v2_template = st.checkbox(
                                "V2 Template",
                                value=path_config.get('v2_template', False),
                                key=f"v2temp_{i}"
                            )

                        with col4:
                            st.write("")
                            st.write("")
                            if st.button("🗑️", key=f"remove_{i}", help="Remove this path"):
                                paths_to_remove.append(i)

                        # Update the path config
                        search_paths[i] = {
                            'description': new_desc,
                            'path': new_path,
                            'permissions': new_perms
                        }
                        if v2_compliant:
                            search_paths[i]['v2_compliant'] = True
                        if v2_fallback:
                            search_paths[i]['v2_fallback'] = True
                        if v2_template:
                            search_paths[i]['v2_template'] = True

                        st.markdown("---")

                # Remove paths marked for deletion
                for i in reversed(paths_to_remove):
                    search_paths.pop(i)
                    st.rerun()

                # Update the temp_yaml with modified search_paths
                st.session_state.temp_yaml['search_paths'] = search_paths

                # Test search paths
                if st.button("🧪 Test All Search Paths", key="test_all_search_paths"):
                    st.write("**Testing search paths...**")
                    for i, path_config in enumerate(search_paths):
                        path = path_config.get('path', '')
                        try:
                            # Try with base path first
                            full_path = BASE_PATH / path
                            if full_path.exists():
                                st.success(f"✅ Path {i+1}: {path} - Found at {full_path}")
                            else:
                                # Try other resolutions
                                alt_path = Path(path).expanduser()
                                if alt_path.exists():
                                    st.success(f"✅ Path {i+1}: {path} - Found at {alt_path}")
                                else:
                                    st.warning(f"⚠️ Path {i+1}: {path} - Not found")
                        except Exception as e:
                            st.error(f"❌ Path {i+1}: {path} - Invalid ({str(e)})")

        # Step 5: Test Connections
        with st.expander("🧪 Step 5: Test Connections", expanded=True):
            if 'temp_yaml' in st.session_state and st.session_state.temp_yaml:
                st.markdown("**Test your configuration against real services**")

                credentials = st.session_state.temp_yaml.get('credentials', {})
                services = st.session_state.temp_yaml.get('services', {})

                col1, col2 = st.columns(2)

                with col1:
                    st.subheader("☁️ AWS Services")

                    # Test S3
                    if st.button("🪣 Test S3", key="test_s3", use_container_width=True):
                        aws_creds = credentials.get('aws', {})
                        s3_config = services.get('s3', {})
                        if aws_creds.get('access_key_id'):
                            try:
                                import boto3
                                s3 = boto3.client(
                                    's3',
                                    aws_access_key_id=aws_creds['access_key_id'],
                                    aws_secret_access_key=aws_creds['secret_access_key'],
                                    region_name=aws_creds.get('default_region', 'us-east-1')
                                )
                                # Try to list buckets
                                buckets = s3.list_buckets()
                                st.success(f"✅ S3 Connected! Found {len(buckets['Buckets'])} buckets")
                                if s3_config.get('bucket'):
                                    st.info(f"Default bucket: {s3_config['bucket']}")
                            except Exception as e:
                                st.error(f"❌ S3 Error: {str(e)[:100]}")
                        else:
                            st.error("❌ AWS credentials missing")

                    # Test Bedrock with actual model invocation
                    if st.button("🤖 Test Bedrock", key="test_bedrock", use_container_width=True):
                        aws_creds = credentials.get('aws', {})
                        bedrock_config = services.get('aws', {}).get('bedrock', {})
                        if aws_creds.get('access_key_id'):
                            try:
                                import boto3
                                import json

                                # Connect to both bedrock and bedrock-runtime
                                bedrock = boto3.client(
                                    'bedrock',
                                    aws_access_key_id=aws_creds['access_key_id'],
                                    aws_secret_access_key=aws_creds['secret_access_key'],
                                    region_name=bedrock_config.get('region', 'us-east-1')
                                )

                                bedrock_runtime = boto3.client(
                                    'bedrock-runtime',
                                    aws_access_key_id=aws_creds['access_key_id'],
                                    aws_secret_access_key=aws_creds['secret_access_key'],
                                    region_name=bedrock_config.get('region', 'us-east-1')
                                )

                                st.success(f"✅ Bedrock Connected!")

                                # Use the model from config if available
                                model_id = bedrock_config.get('default_model', 'anthropic.claude-3-sonnet-20240229-v1:0')
                                st.info(f"Testing model: {model_id}")

                                # Try a simple test invocation
                                try:
                                    test_prompt = "Say 'Hello from Bedrock!' in 5 words or less."

                                    # Claude model request format
                                    if 'claude' in model_id.lower():
                                        body = json.dumps({
                                            "anthropic_version": "bedrock-2023-05-31",
                                            "messages": [
                                                {"role": "user", "content": test_prompt}
                                            ],
                                            "max_tokens": 50,
                                            "temperature": 0.5
                                        })
                                    else:
                                        # Generic format for other models
                                        body = json.dumps({
                                            "prompt": test_prompt,
                                            "max_tokens": 50,
                                            "temperature": 0.5
                                        })

                                    response = bedrock_runtime.invoke_model(
                                        modelId=model_id,
                                        body=body,
                                        contentType='application/json',
                                        accept='application/json'
                                    )

                                    response_body = json.loads(response.get('body').read())

                                    # Extract response based on model type
                                    if 'claude' in model_id.lower():
                                        content = response_body.get('content', [{}])[0].get('text', 'No response')
                                    else:
                                        content = response_body.get('completion', response_body.get('text', 'No response'))

                                    st.success(f"✅ Model Response: {content}")

                                except Exception as model_error:
                                    st.warning(f"⚠️ Model test failed: {str(model_error)[:100]}")
                                    st.info("Connection successful but model invocation failed")

                            except Exception as e:
                                st.error(f"❌ Bedrock Error: {str(e)[:100]}")
                        else:
                            st.error("❌ AWS credentials missing")

                    st.subheader("💾 Database")

                    # Test PostgreSQL/Aurora
                    if st.button("🐘 Test Database", key="test_db", use_container_width=True):
                        pg_creds = credentials.get('postgresql', {})
                        if pg_creds.get('host') and pg_creds.get('password'):
                            try:
                                import psycopg2
                                conn = psycopg2.connect(
                                    host=pg_creds['host'],
                                    port=pg_creds.get('port', 5432),
                                    database=pg_creds.get('database', 'postgres'),
                                    user=pg_creds.get('username', 'postgres'),
                                    password=pg_creds['password']
                                )
                                cursor = conn.cursor()
                                cursor.execute('SELECT version()')
                                version = cursor.fetchone()[0]
                                conn.close()

                                # Check if it's Aurora
                                if 'aurora' in version.lower():
                                    st.success(f"✅ Aurora Connected!")
                                else:
                                    st.success(f"✅ PostgreSQL Connected!")
                                st.info(f"Version: {version[:50]}...")
                            except Exception as e:
                                st.error(f"❌ Database Error: {str(e)[:100]}")
                        else:
                            st.error("❌ Database credentials missing")

                with col2:
                    st.subheader("🔧 Services")

                    # Test MLflow
                    if st.button("📊 Test MLflow", key="test_mlflow", use_container_width=True):
                        mlflow_config = services.get('mlflow', {})
                        if mlflow_config.get('tracking_uri'):
                            try:
                                import requests
                                response = requests.get(
                                    f"{mlflow_config['tracking_uri']}/health",
                                    timeout=5
                                )
                                if response.status_code == 200:
                                    st.success(f"✅ MLflow Connected!")
                                    st.info(f"URI: {mlflow_config['tracking_uri']}")
                                else:
                                    st.warning(f"⚠️ MLflow status {response.status_code}")
                            except requests.ConnectionError:
                                st.error("❌ MLflow not running")
                                st.info("Start with: mlflow ui --host 0.0.0.0")
                            except Exception as e:
                                st.error(f"❌ MLflow Error: {str(e)[:100]}")
                        else:
                            st.error("❌ MLflow tracking URI not configured")

                    # Test Chat (requirements check)
                    if st.button("💬 Test Chat Requirements", key="test_chat", use_container_width=True):
                        # Check if basic chat requirements are met
                        has_llm = bool(services.get('aws', {}).get('bedrock', {}).get('default_model'))
                        has_db = bool(credentials.get('postgresql', {}).get('host'))
                        has_mlflow = bool(services.get('mlflow', {}).get('tracking_uri'))

                        if has_llm and has_db:
                            st.success("✅ Chat prerequisites met!")
                            st.success("• LLM: Configured")
                            st.success("• Database: Configured")
                            if has_mlflow:
                                st.success("• MLflow: Configured")
                            else:
                                st.warning("• MLflow: Optional, not configured")
                        else:
                            st.error("❌ Missing chat requirements:")
                            if not has_llm:
                                st.error("• LLM configuration missing")
                            if not has_db:
                                st.error("• Database missing")

                    st.subheader("🎯 Quick Tests")

                    # Overall Test Status
                    if st.button("🔍 Test All Connections", key="test_all", use_container_width=True):
                        with st.spinner("Running all tests..."):
                            test_results = {}

                            # Test AWS
                            aws_creds = credentials.get('aws', {})
                            test_results['AWS'] = bool(aws_creds.get('access_key_id'))

                            # Test DB
                            pg_creds = credentials.get('postgresql', {})
                            test_results['Database'] = bool(pg_creds.get('host') and pg_creds.get('password'))

                            # Test Services
                            test_results['S3'] = bool(services.get('s3', {}).get('bucket'))
                            test_results['Bedrock'] = bool(services.get('aws', {}).get('bedrock', {}).get('default_model'))
                            test_results['MLflow'] = bool(services.get('mlflow', {}).get('tracking_uri'))

                            # Show results
                            for service, configured in test_results.items():
                                if configured:
                                    st.success(f"✅ {service}")
                                else:
                                    st.error(f"❌ {service}")
            else:
                st.error("❌ No configuration loaded. Upload settings.yaml first.")

        # Step 6: Save Configuration
        with st.expander("💾 Step 6: Save Your Configuration", expanded=True):
            if 'temp_yaml' in st.session_state and st.session_state.temp_yaml:
                col1, col2, col3 = st.columns(3)

                with col1:
                    if st.button("💾 Save Configuration", key="save_config", type="primary"):
                        saved_path = save_settings(st.session_state.temp_yaml)
                        if saved_path:
                            st.success(f"✅ Configuration saved to: {saved_path}")
                        else:
                            st.error("❌ Failed to save configuration")

                with col2:
                    if st.button("📥 Download YAML", key="download_yaml"):
                        yaml_content = yaml.dump(st.session_state.temp_yaml, default_flow_style=False, indent=2)
                        st.download_button(
                            label="⬇️ Download settings.yaml",
                            data=yaml_content,
                            file_name="settings.yaml",
                            mime="application/x-yaml"
                        )

                with col3:
                    if st.button("🔄 Reset", key="reset_config"):
                        st.session_state.temp_yaml = None
                        st.rerun()

with col2:
    st.subheader("🎯 Status")

    if 'temp_yaml' in st.session_state and st.session_state.temp_yaml:
        settings = st.session_state.temp_yaml

        # Quick validation
        credentials = settings.get('credentials', {})
        aws_creds = credentials.get('aws', {})
        pg_creds = credentials.get('postgresql', {})
        services = settings.get('services', {})
        search_paths = settings.get('search_paths', [])

        has_aws = bool(aws_creds.get('access_key_id') and aws_creds.get('secret_access_key'))
        has_db = bool(pg_creds.get('host') and pg_creds.get('password'))
        has_search_paths = len(search_paths) > 0
        has_s3 = bool(services.get('s3', {}).get('bucket'))
        has_bedrock = bool(services.get('aws', {}).get('bedrock', {}).get('default_model'))
        has_mlflow = bool(services.get('mlflow', {}).get('tracking_uri'))

        st.markdown("### Core Requirements")
        if has_aws:
            st.success("✅ AWS Configured")
        else:
            st.error("❌ AWS Missing")

        if has_db:
            st.success("✅ Database Configured")
        else:
            st.error("❌ Database Missing")

        if has_search_paths:
            st.success(f"✅ {len(search_paths)} Search Paths")
        else:
            st.warning("⚠️ No Search Paths")

        st.markdown("### Services")
        if has_s3:
            st.success("✅ S3 Configured")
        else:
            st.warning("⚠️ S3 Not Configured")

        if has_bedrock:
            st.success("✅ Bedrock Configured")
        else:
            st.warning("⚠️ Bedrock Not Configured")

        if has_mlflow:
            st.success("✅ MLflow Configured")
        else:
            st.warning("⚠️ MLflow Not Configured")

        # Overall status
        st.markdown("### Overall Status")
        if has_aws and has_db:
            st.success("🚀 Ready to Deploy!")
        else:
            st.warning("⚠️ Configuration Incomplete")

    else:
        st.info("📁 Upload settings.yaml to begin")

if __name__ == "__main__":
    st.write("DBA Configuration Portal v3 - Complete config management with connection testing!")