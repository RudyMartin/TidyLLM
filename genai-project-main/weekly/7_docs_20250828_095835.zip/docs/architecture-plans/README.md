# Architecture

Architecture plans (existing folder)

## Contents

This folder contains documentation related to architecture.
