# 📈 VectorQA Sage - Library Upgrade Plan

## 🎯 **Current Status**
- **Python Version**: 3.12.7 ✅ (Excellent - Latest stable)
- **All Tests**: 31/31 passing ✅
- **Environment**: Ready for upgrades

## 📦 **Available Updates**

Based on `pip list --outdated`, here are the packages with available updates:

### **Critical Updates** 🚨
| Package | Current | Latest | Impact | Priority |
|---------|---------|--------|---------|----------|
| **dspy** | 2.5.26 | **3.0.1** | 🔥 Major version - New features | **HIGH** |
| **litellm** | 1.46.4 | **1.75.9** | 🔄 Many improvements | **HIGH** |
| **pydantic_core** | 2.33.2 | **2.39.0** | 🛡️ Performance & security | **MEDIUM** |

### **AWS Updates** ☁️
| Package | Current | Latest | Impact | Priority |
|---------|---------|--------|---------|----------|
| **boto3** | 1.40.13 | **1.40.14** | 🔧 Bug fixes | **LOW** |
| **botocore** | 1.40.13 | **1.40.14** | 🔧 Bug fixes | **LOW** |

### **Utility Updates** 🔧
| Package | Current | Latest | Impact | Priority |
|---------|---------|--------|---------|----------|
| **dill** | 0.3.8 | **0.4.0** | 📦 Serialization improvements | **LOW** |
| **fsspec** | 2025.3.0 | **2025.7.0** | 📁 File system improvements | **LOW** |
| **multiprocess** | 0.70.16 | **0.70.18** | ⚡ Performance | **LOW** |
| **pip** | 24.2 | **25.2** | 🛠️ Package manager | **MEDIUM** |

## 🚀 **Recommended Upgrade Strategy**

### **Phase 1: Safe Updates** ✅
Start with low-risk updates:
```bash
# Update pip first
python3 -m pip install --upgrade pip

# Update AWS libraries
python3 -m pip install --upgrade boto3 botocore

# Update utility packages
python3 -m pip install --upgrade dill fsspec multiprocess
```

### **Phase 2: Test Critical Updates** ⚠️
Test major updates in isolation:
```bash
# Test DSPy 3.0.1 (Major version change!)
python3 -m pip install --upgrade dspy==3.0.1

# Run tests to ensure compatibility
python3 run_tests.py

# If tests pass, update LiteLLM
python3 -m pip install --upgrade litellm==1.75.9

# Run tests again
python3 run_tests.py
```

### **Phase 3: Update Requirements** 📝
Update requirements.txt with tested versions:
```bash
# Use the updated requirements file
python3 -m pip install -r requirements_updated.txt
```

## ⚠️ **Breaking Changes to Watch**

### **DSPy 3.0.1** 🔥
- **Major version upgrade** - potential API changes
- **Action**: Check DSPy changelog for breaking changes
- **Test**: Especially `app/core/validator.py` and `app/tabs/*dspy*.py`

### **LiteLLM 1.75.9** 📡
- **Many minor versions jumped** (1.46.4 → 1.75.9)
- **Action**: Check LiteLLM docs for API changes
- **Test**: All LLM integration points

## 🧪 **Testing Strategy**

### **Before Upgrading**
```bash
# Backup current working state
python3 run_tests.py --coverage
# Save coverage report
```

### **After Each Phase**
```bash
# Run full test suite
python3 run_tests.py --fast

# Test specific functionality
python3 -m pytest tests/test_validator.py -v
python3 -m pytest tests/test_integration.py -v
```

### **Integration Testing**
```bash
# Test the actual Streamlit app
streamlit run app/main.py --server.headless true --server.port 8502 &
# Test file uploads and processing
```

## 📋 **Upgrade Commands**

### **Conservative Approach** (Recommended)
```bash
# Phase 1: Safe updates
python3 -m pip install --upgrade pip boto3 botocore dill fsspec multiprocess pydantic-core

# Test
python3 run_tests.py

# Phase 2: Critical updates (one at a time)
python3 -m pip install --upgrade dspy==3.0.1
python3 run_tests.py

python3 -m pip install --upgrade litellm==1.75.9  
python3 run_tests.py
```

### **Aggressive Approach** (If you're feeling lucky)
```bash
# Update everything at once
python3 -m pip install --upgrade dspy litellm boto3 botocore dill fsspec multiprocess pydantic-core pip

# Cross fingers and test
python3 run_tests.py
```

## 🔒 **Security Considerations**

### **Install Security Scanner**
```bash
python3 -m pip install safety
python3 -m safety check
```

### **Vulnerability Monitoring**
- **DSPy 3.0.1**: Check for security fixes
- **LiteLLM 1.75.9**: Review security changelog
- **boto3/botocore**: AWS security updates

## 📊 **Success Metrics**

✅ **All tests passing**: 31/31  
✅ **No import errors**  
✅ **Streamlit app starts**  
✅ **File uploads work**  
✅ **DSPy pipelines function**  
✅ **AWS integration works**  

## 🎯 **Final Recommendation**

**Start with Phase 1** - it's low risk and gives you immediate benefits. Then carefully test DSPy 3.0.1 since it's a major version change. The current setup is working perfectly, so there's no rush!

**Priority Order**:
1. 🥇 **pip** (always keep updated)
2. 🥈 **pydantic-core** (security & performance)
3. 🥉 **boto3/botocore** (AWS compatibility)
4. ⚠️ **dspy** (major version - test carefully)
5. ⚠️ **litellm** (many versions - test carefully)
