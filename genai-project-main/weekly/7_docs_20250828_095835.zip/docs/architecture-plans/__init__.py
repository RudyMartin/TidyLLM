"""Documentation for architecture"""
