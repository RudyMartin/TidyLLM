# FileClassificationWorker How-To Guide

## Overview

The `FileClassificationWorker` is a **unified, configurable worker** that provides progressive complexity for file classification across three modes:
- **Simple**: Basic extension and content analysis
- **Enhanced**: Multi-dimensional classification with 5 analysis dimensions
- **Advanced**: Enhanced + AI/ML capabilities

## Architecture

### Progressive Complexity Design
```
Simple Mode → Enhanced Mode → Advanced Mode
     ↓              ↓              ↓
Basic Analysis → Multi-Dimensional → AI/ML Features
```

### Classification Dimensions (Enhanced/Advanced)
1. **File Properties**: Extension, size, encoding, structure
2. **Content Analysis**: Topics, sensitivity, content type, MVR document type
3. **Purpose/Context**: Business function, workflow stage, audience
4. **Ownership/Source**: Creator type, source system, temporal properties
5. **Policy Framework**: Confidentiality, document taxonomy, regulatory compliance

## Usage

### Basic Usage

```python
from backend.mcp.workers.file_classification_worker import FileClassificationWorker, ClassificationMode

# Simple mode (default)
simple_worker = FileClassificationWorker(ClassificationMode.SIMPLE)
result = simple_worker.classify_file("document.pdf", content)

# Enhanced mode
enhanced_worker = FileClassificationWorker(ClassificationMode.ENHANCED)
result = enhanced_worker.classify_file_enhanced({
    'filename': 'document.pdf',
    'content': content,
    'file_size': 1024 * 1024,
    'metadata': {'author': 'John Doe'},
    'context': {'project': 'Risk Model'}
})

# Advanced mode
advanced_worker = FileClassificationWorker(ClassificationMode.ADVANCED)
result = advanced_worker.classify_file_enhanced(file_data)
# Advanced features automatically added
```

### MCP Task Processing

```python
# The worker automatically handles different task types based on mode
message = MCPMessage(
    task_type=TaskType.FILE_CLASSIFICATION,
    task_data={'filename': 'doc.pdf', 'content': '...'}
)

# Simple mode: Basic classification
simple_result = simple_worker.process_task(message)

# Enhanced mode: Multi-dimensional analysis
enhanced_result = enhanced_worker.process_task(message)

# Advanced mode: Enhanced + AI/ML
advanced_result = advanced_worker.process_task(message)
```

## Configuration

### MVR Document Types
The worker supports 15 MVR document types defined in `dev_configs/file_classification.yaml`:

- **Unclassified (U)**: Documents needing classification
- **Whitepaper (W)**: Research papers and academic documents
- **Validation Scoping Template (VST)**: Validation planning documents
- **Annual Model Review (AMR)**: Annual review documents
- **Model Documentation Assessment (MDA)**: Documentation quality assessments
- **Model Development Document (MDD)**: Development methodology documents
- **Model Development Plan (MDP)**: Strategic development plans
- **SDC Validation Report (SVR)**: Software development cycle reports
- **QA Template (QAT)**: Quality assurance templates
- **Implementation Testing Document (ITD)**: Testing documentation
- **Model Implementation Plan (MIP)**: Implementation roadmaps
- **Standards/Procedures (SP)**: Governance frameworks
- **Model Performance Monitoring (MPM) Plan**: Monitoring frameworks
- **Post-Development Recalibrated Model (PDRM) Plan**: Recalibration plans
- **Modeling Area Prioritization Plan (MAPP)**: Strategic prioritization

### Classification Keywords
The worker uses comprehensive keyword sets for:
- **Topics**: Finance, Legal, Technical, Research, Operations
- **Sensitivity**: Public, Internal, Confidential, Restricted, Regulated
- **Content Types**: Textual, Numerical, Multimedia, Code, Mixed
- **Business Functions**: HR, Finance, Engineering, Compliance, Operations
- **Workflow Stages**: Draft, Review, Final, Archive, Raw
- **Audiences**: Internal, External, Regulators, Public

## Output Formats

### Simple Mode Output
```json
{
    "type": "model_development_document",
    "category": "Model Development Document (MDD)",
    "priority": "High",
    "description": "Documents outlining model development methodology",
    "confidence": 0.85,
    "review_id": "REV00001"
}
```

### Enhanced Mode Output
```json
{
    "classification_method": "enhanced_multi_dimensional",
    "primary_classification": "model_development_document",
    "overall_confidence": 0.75,
    "dimensions": {
        "file_properties": {
            "file_extension": ".pdf",
            "format_category": "document_formats",
            "size_category": "small",
            "encoding_type": "text",
            "confidence_score": 0.9
        },
        "content_analysis": {
            "topics": [{"topic": "technical", "score": 3, "confidence": 0.8}],
            "sensitivity_level": {"level": "confidential", "score": 2, "confidence": 0.7},
            "content_type": {"type": "textual", "score": 1, "confidence": 0.5},
            "mvr_document_type": {
                "type": "model_development_document",
                "category": "Model Development Document (MDD)",
                "priority": "High",
                "confidence": 0.8
            },
            "keywords": ["model", "development", "methodology", "architecture"],
            "confidence_score": 0.73
        },
        "purpose_context": {
            "business_function": {"function": "ENGINEERING", "confidence": 0.7},
            "workflow_stage": {"stage": "final", "confidence": 0.5},
            "audience": {"audience": "internal", "confidence": 0.5},
            "confidence_score": 0.7
        },
        "ownership_source": {
            "creator_type": "individual",
            "source_system": "manual",
            "temporal_properties": {"version": "1.0"},
            "confidence_score": 0.6
        },
        "policy_framework": {
            "confidentiality_level": {"level": "confidential", "confidence": 0.7},
            "document_taxonomy": {"taxonomy": "reports", "confidence": 0.5},
            "regulatory_tags": ["SOX"],
            "confidence_score": 0.8
        }
    },
    "recommendations": [
        "Apply appropriate access controls for sensitive content",
        "Ensure compliance with: SOX"
    ]
}
```

### Advanced Mode Output
Enhanced output plus:
```json
{
    "advanced_features": {
        "ai_analysis": {
            "sentiment_score": 0.75,
            "complexity_level": "medium",
            "key_topics": ["model development", "risk assessment"],
            "writing_style": "technical",
            "suggested_improvements": [
                "Add more quantitative metrics",
                "Include risk mitigation strategies"
            ]
        },
        "ml_predictions": {
            "quality_score": 0.82,
            "completion_probability": 0.95,
            "risk_level": "medium",
            "recommended_reviewers": ["compliance_team", "risk_management"]
        },
        "advanced_metrics": {
            "readability_score": 0.68,
            "technical_depth": "high",
            "audience_appropriateness": "expert",
            "regulatory_alignment": 0.85
        }
    }
}
```

## Validation

### Simple Validation
```python
validation = worker.validate_file({
    'filename': 'document.pdf',
    'content': content,
    'file_size': 1024 * 1024,
    'classification': result
})
```

### Enhanced Validation
```python
validation = worker.validate_file_enhanced({
    'filename': 'document.pdf',
    'content': content,
    'file_size': 1024 * 1024,
    'classification': enhanced_result
})
```

Enhanced validation includes:
- File size checks
- Classification confidence validation
- Sensitivity level analysis
- Regulatory compliance verification
- Enhanced security recommendations

## Integration with Orchestrators

### SimpleQAOrchestrator
```python
# Uses simple mode for basic classification
worker = FileClassificationWorker(ClassificationMode.SIMPLE)
```

### EnhancedQAOrchestrator
```python
# Uses enhanced mode for multi-dimensional analysis
worker = FileClassificationWorker(ClassificationMode.ENHANCED)
```

### AdvancedQAOrchestrator
```python
# Uses advanced mode for AI/ML capabilities
worker = FileClassificationWorker(ClassificationMode.ADVANCED)
```

## Performance Considerations

### Mode Performance
- **Simple**: Fastest, minimal resource usage
- **Enhanced**: Moderate performance impact, comprehensive analysis
- **Advanced**: Highest resource usage, AI/ML features

### Caching
The worker supports caching of classification results to improve performance for repeated analysis.

### Batch Processing
```python
# Process multiple files efficiently
batch_result = worker._batch_classify_task({
    'files': [
        {'filename': 'doc1.pdf', 'content': '...'},
        {'filename': 'doc2.pdf', 'content': '...'}
    ]
})
```

## Error Handling

### Graceful Degradation
- Falls back to simpler classification if enhanced features fail
- Provides confidence scores to indicate reliability
- Includes recommendations for manual review when needed

### Common Error Scenarios
1. **Missing Configuration**: Falls back to default classification
2. **Invalid File Format**: Returns unclassified with warnings
3. **Content Analysis Failure**: Uses extension-based classification
4. **AI/ML Service Unavailable**: Falls back to enhanced mode

## Testing

### Unit Tests
```python
# Test each mode independently
simple_worker = FileClassificationWorker(ClassificationMode.SIMPLE)
enhanced_worker = FileClassificationWorker(ClassificationMode.ENHANCED)
advanced_worker = FileClassificationWorker(ClassificationMode.ADVANCED)

# Test classification accuracy
# Test validation logic
# Test error handling
```

### Integration Tests
```python
# Test with orchestrators
# Test with real documents
# Test performance under load
```

## Best Practices

### Mode Selection
- **Use Simple mode** for basic file categorization
- **Use Enhanced mode** for compliance and regulatory analysis
- **Use Advanced mode** for research and advanced analytics

### Configuration Management
- Keep `file_classification.yaml` updated with new document types
- Regularly review and update classification keywords
- Monitor classification accuracy and adjust thresholds

### Performance Optimization
- Cache frequently accessed classification results
- Use batch processing for multiple files
- Consider worker pooling for high-volume scenarios

## Troubleshooting

### Common Issues
1. **Low Classification Confidence**: Check content quality and keyword coverage
2. **Missing Review IDs**: Verify regex patterns and document format
3. **Validation Failures**: Review file size limits and extension restrictions
4. **Performance Issues**: Consider mode downgrade or caching

### Debug Mode
```python
# Enable detailed logging
import logging
logging.getLogger('FileClassificationWorker').setLevel(logging.DEBUG)
```

## Future Enhancements

### Planned Features
- **Machine Learning Models**: Improved classification accuracy
- **Natural Language Processing**: Better content understanding
- **Real-time Learning**: Adaptive classification based on feedback
- **Integration APIs**: Connect with external classification services

### Extensibility
The worker is designed for easy extension:
- Add new document types in configuration
- Extend classification dimensions
- Integrate new AI/ML capabilities
- Customize validation rules

