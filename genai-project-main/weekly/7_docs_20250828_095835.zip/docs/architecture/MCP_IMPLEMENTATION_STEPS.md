# 🏗️ MCP Implementation Steps - Real Multi-LLM Process

## Overview
This document outlines the **REAL IMPLEMENTATION** of MCP (Model Context Protocol) logic for a multi-LLM process, step by step, based on the actual backend code.

## 🎯 **MCP Architecture Components**

| Component | Location | Purpose |
|-----------|----------|---------|
| **Orchestrator** | `src/backend/mcp/orchestrators/qa_orchestrator.py` | Main workflow controller |
| **Coordinator** | `src/backend/mcp/coordinators/dspy_coordinator.py` | Task coordination and DSPy integration |
| **Protocol** | `src/backend/mcp/protocol/` | Message schemas and communication |
| **Context** | `src/backend/mcp/context/` | Context management and state |
| **Workers** | `src/backend/mcp/workers/` | Specialized task execution |
| **Communication** | `src/backend/mcp/communication/` | Message routing and handling |

---

## 📋 **Step-by-Step MCP Implementation**

### **Step 1: User Upload (Frontend)**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| User uploads files via Streamlit | `QAOrchestrator.process_qa_documents()` called | None |
| Files stored temporarily | Workflow context created with UUID | None |
| Form data collected (team, process, reviewer, etc.) | Context stored in `MCPContextManager` | None |

**Backend Code:**
```python
# QAOrchestrator._create_workflow_context()
context_data = {
    "workflow_type": "qa_document_processing",
    "files": files,
    "team_num": team_num,
    "process_name": process_name,
    "reviewer_name": reviewer_name,
    "review_id": review_id,
    "model_type": model_type,
    "risk_tier": risk_tier,
    "s3_path": f"usecase-qa/teams/{team_num}/{process_name}/{reviewer_name}/{review_id}",
    "created_at": datetime.now().isoformat()
}
```

### **Step 2: S3 Upload (Orchestrator)**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| None | `QAOrchestrator._upload_files_to_s3()` | None |
| None | Files uploaded to S3 with structured path | None |
| None | S3 paths returned for processing | None |

**Backend Code:**
```python
# QAOrchestrator._upload_files_to_s3()
upload_result = {
    "s3_paths": [f"s3://example-bucket-name/{s3_path}/{filename}"],
    "upload_status": "success",
    "files_uploaded": len(files)
}
```

### **Step 3: DSPy Field Extraction (Coordinator)**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| None | `DSPyCoordinator.extract_key_fields()` called | **Claude Sonnet** for field extraction |
| None | Documents processed with DSPy | **Titan Embed** for embeddings |
| None | Key fields extracted and validated | **Claude Haiku** for quick validation |

**Backend Code:**
```python
# DSPyCoordinator._process_documents_with_dspy()
processed_docs = []
for s3_path in s3_paths:
    doc_content = self._extract_text_from_s3(s3_path)
    # DSPy processes with Claude Sonnet
    processed_doc = {
        "s3_path": s3_path,
        "content": doc_content,
        "metadata": {...}
    }
```

**LLM Models Used:**
- **Claude Sonnet**: Document analysis and field extraction
- **Titan Embed**: Generate embeddings for similarity search
- **Claude Haiku**: Quick validation and compliance checks

### **Step 4: MCP Message Protocol**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| None | `MCPMessageSchema` created | None |
| None | Task requests sent via `MCPProtocol` | None |
| None | Context updates propagated | None |

**Backend Code:**
```python
# MCPMessageSchema
message = MCPMessageSchema(
    message_id=str(uuid.uuid4()),
    sender_id="qa_orchestrator",
    receiver_id="dspy_coordinator",
    message_type=MessageType.TASK_REQUEST,
    payload={
        "task_id": task_id,
        "task_type": "field_extraction",
        "task_data": {"s3_paths": s3_paths},
        "context": context_data
    }
)
```

### **Step 5: Context Management**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| None | `MCPContextManager` maintains state | None |
| None | Context shared across all layers | None |
| None | Workflow state persisted | None |

**Backend Code:**
```python
# MCPContextManager
context = self.context_manager.create_context(
    context_data=context_data,
    source_layer="qa_orchestrator",
    expiry_hours=24
)
```

### **Step 6: QA Report Generation (Orchestrator)**
| Frontend Action | Backend MCP Process | LLM Involvement |
|-----------------|-------------------|-----------------|
| None | `QAOrchestrator._generate_qa_report()` | **Claude Opus** for report generation |
| None | Report structured with extracted fields | **Claude Sonnet** for content analysis |
| None | PDF report generated and stored | None |

**Backend Code:**
```python
# QAOrchestrator._generate_qa_report()
report_result = {
    "report_s3_path": f"s3://example-bucket-name/reports/{review_id}_report.pdf",
    "report_status": "generated",
    "extracted_fields_used": extracted_fields
}
```

**LLM Models Used:**
- **Claude Opus**: High-quality report generation
- **Claude Sonnet**: Content analysis and structuring

---

## 🔄 **MCP Message Flow**

### **Message Types:**
1. **TASK_REQUEST**: Orchestrator → Coordinator
2. **TASK_RESPONSE**: Coordinator → Orchestrator
3. **STATUS_UPDATE**: All layers → All layers
4. **CONTEXT_UPDATE**: Context changes propagated
5. **RESULT_AGGREGATION**: Final results collected

### **Priority Levels:**
- **LOW**: Background tasks
- **NORMAL**: Standard processing
- **HIGH**: Time-sensitive operations
- **CRITICAL**: Error handling and recovery

---

## 🧠 **Multi-LLM Process Flow**

### **LLM Model Selection Logic:**
```python
# Model selection based on task type
if task_type == "embedding":
    model = "amazon.titan-embed-text-v2:0"  # Titan Embed
elif task_type == "analysis":
    model = "anthropic.claude-3-sonnet-20240229-v1:0"  # Claude Sonnet
elif task_type == "report":
    model = "anthropic.claude-3-opus-20240229-v1:0"  # Claude Opus
elif task_type == "validation":
    model = "anthropic.claude-3-haiku-20240307-v1:0"  # Claude Haiku
```

### **LLM Task Distribution:**
| Task | Primary LLM | Fallback LLM | Purpose |
|------|-------------|--------------|---------|
| **Document Analysis** | Claude Sonnet | Titan Text Express | Extract key fields |
| **Embedding Generation** | Titan Embed v2 | Titan Embed v1 | Vector representations |
| **Report Generation** | Claude Opus | Claude Sonnet | High-quality reports |
| **Quick Validation** | Claude Haiku | Titan Text Lite | Fast compliance checks |

---

## 📊 **Backend Implementation Status**

| Component | Status | Implementation | Testing |
|-----------|--------|----------------|---------|
| **QA Orchestrator** | ✅ Complete | `qa_orchestrator.py` | Ready |
| **DSPy Coordinator** | ✅ Complete | `dspy_coordinator.py` | Ready |
| **MCP Protocol** | ✅ Complete | `message_schemas.py` | Ready |
| **Context Manager** | ✅ Complete | `context_manager.py` | Ready |
| **Communication** | ✅ Complete | `communication.py` | Ready |
| **Workers** | 🔄 In Progress | `workers/` directory | Pending |

---

## 🎯 **Key MCP Benefits**

1. **Structured Communication**: Standardized message schemas
2. **Context Persistence**: State maintained across workflow
3. **Multi-LLM Coordination**: Different models for different tasks
4. **Error Handling**: Robust error propagation and recovery
5. **Scalability**: Easy to add new coordinators and workers
6. **Audit Trail**: Complete workflow tracking and logging

---

## 🚀 **Next Steps**

1. **Complete Workers**: Implement specialized workers for specific tasks
2. **Add Middleware**: Implement middleware for logging and monitoring
3. **Test Integration**: Test end-to-end MCP workflow
4. **Performance Optimization**: Optimize LLM model selection and caching
5. **Error Recovery**: Implement robust error handling and retry logic

---

*This MCP implementation provides a robust, scalable foundation for multi-LLM document processing with proper separation of concerns, standardized communication, and context management.*
