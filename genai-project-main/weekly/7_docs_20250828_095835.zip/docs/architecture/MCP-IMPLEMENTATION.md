# MCP Hierarchical LLM Implementation

## Overview

This document describes the complete implementation of the **Model Context Protocol (MCP)** hierarchical LLM system in VectorQA Sage. The MCP framework provides a structured approach to organizing AI reasoning, knowledge, and communication across multiple levels of abstraction.

## 🏗️ Architecture

### Hierarchical Structure

The MCP system implements a three-tier hierarchical architecture:

```
┌─────────────────────────────────────────────────────────────┐
│                    PLANNER (Strategic)                      │
│  • Creates execution plans                                  │
│  • Orchestrates workflow                                    │
│  • Aggregates results                                       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                COORDINATORS (Tactical)                      │
│  • Retrieval Coordinator: Document search & retrieval       │
│  • Analysis Coordinator: Content analysis & reasoning       │
│  • Writer Coordinator: Report generation & writing          │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                  WORKERS (Operational)                      │
│  • Retrieval Worker: Vector search, document retrieval      │
│  • Analysis Worker: Sentiment, key points, compliance       │
│  • Writer Worker: Reports, summaries, content creation      │
└─────────────────────────────────────────────────────────────┘
```

### MCP Framework Components

#### 1. **Model Layer**
- **Planner**: Strategic reasoning engine (GPT-4o)
- **Coordinators**: Tactical coordination agents (GPT-4o-mini)
- **Workers**: Specialized execution engines (GPT-3.5-turbo)

#### 2. **Context Layer**
- **Global Context**: User request, constraints, session data
- **Scoped Context**: Domain-specific information for coordinators
- **Micro Context**: Task-specific data for workers

#### 3. **Protocol Layer**
- **Message Format**: JSON-based communication
- **Validation Schema**: Structured data validation
- **Error Handling**: Retry policies and fallback strategies

## 📁 File Structure

```
backend/
├── core/
│   └── mcp/
│       ├── __init__.py                 # MCP package initialization
│       ├── base.py                     # Core MCP classes (MCPNode, MCPContext, MCPProtocol)
│       ├── protocol.py                 # Message protocol and communication
│       ├── planner.py                  # Strategic planner implementation
│       ├── coordinator.py              # Tactical coordinator implementation
│       ├── worker.py                   # Base worker implementation
│       ├── orchestrator.py             # Complete system orchestrator
│       └── workers/
│           ├── __init__.py             # Workers package
│           ├── retrieval_worker.py     # Document retrieval specialist
│           ├── analysis_worker.py      # Content analysis specialist
│           └── writer_worker.py        # Report writing specialist
├── services/
│   └── mcp_service.py                  # VectorQA Sage integration service
└── config/
    └── credential_manager.py           # Credential management

frontend/
└── streamlit/
    └── mcp_dashboard.py                # Comprehensive MCP dashboard

tests/
└── test_mcp_hierarchy.py               # Complete test suite

docs/
└── MCP-IMPLEMENTATION.md               # This documentation
```

## 🚀 Quick Start

### 1. Installation

Ensure all dependencies are installed:

```bash
pip install -r backend/requirements.txt
```

### 2. Configuration

Set up your API credentials in `backend/config/credentials.env`:

```env
OPENAI_API_KEY=your_openai_key_here
ANTHROPIC_API_KEY=your_anthropic_key_here
COHERE_API_KEY=your_cohere_key_here
GOOGLE_API_KEY=your_google_key_here
```

### 3. Basic Usage

```python
from backend.services.mcp_service import MCPService

# Initialize the MCP service
mcp_service = MCPService()

# Process a QA request
result = mcp_service.process_qa_request(
    question="What is artificial intelligence?",
    context_documents=["AI is a field of computer science..."],
    use_vector_search=True
)

print(result["final_response"])
```

### 4. Run the Dashboard

```bash
cd frontend/streamlit
streamlit run mcp_dashboard.py
```

## 🔧 Core Components

### MCPNode (Base Class)

All MCP components inherit from `MCPNode`:

```python
class MCPNode(ABC):
    def __init__(self, role: MCPRole, model_config: Dict[str, Any]):
        self.role = role
        self.model_config = model_config
        self.protocol = self._define_protocol()
        self.llm_manager = LLMManager()
    
    @abstractmethod
    def _define_protocol(self) -> MCPProtocol:
        """Define the protocol for this node type"""
        pass
    
    @abstractmethod
    def process(self, context: MCPContext, input_data: Any) -> Any:
        """Process input according to MCP protocol"""
        pass
```

### MCPContext

Manages context flow through the hierarchy:

```python
@dataclass
class MCPContext:
    user_request: str
    constraints: Dict[str, Any] = field(default_factory=dict)
    session_data: Dict[str, Any] = field(default_factory=dict)
    parent_context: Optional['MCPContext'] = None
    context_id: str = field(default_factory=lambda: f"ctx_{datetime.now().timestamp()}")
    
    def enrich(self, additional_data: Dict[str, Any]) -> 'MCPContext':
        """Create enriched context with additional data"""
        new_data = {**self.session_data, **additional_data}
        return MCPContext(
            user_request=self.user_request,
            constraints=self.constraints,
            session_data=new_data,
            parent_context=self,
            context_id=f"{self.context_id}_enriched"
        )
```

### MCPProtocol

Defines communication standards:

```python
@dataclass
class MCPProtocol:
    message_format: str  # "json", "function_call", "dspy_signature"
    validation_schema: Dict[str, Any]
    error_handling: Dict[str, Any]
    retry_policy: Dict[str, Any]
    
    def validate_message(self, message: Dict[str, Any]) -> bool:
        """Validate message against protocol schema"""
        # Implementation for validation
        pass
```

## 🎯 Specialized Workers

### RetrievalWorker

Handles document retrieval and search operations:

```python
class RetrievalWorker(Worker):
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__("retriever", "document retrieval and search", model_config)
        self.vector_store = None
    
    def perform_vector_search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """Perform vector search using the vector store"""
        # Implementation for vector search
        pass
```

**Capabilities:**
- Document search and retrieval
- Vector similarity search
- Semantic search
- Information gathering
- Content indexing

### AnalysisWorker

Handles content analysis and reasoning:

```python
class AnalysisWorker(Worker):
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__("analyzer", "content analysis and reasoning", model_config)
    
    def analyze_sentiment(self, content: str) -> Dict[str, Any]:
        """Perform sentiment analysis on content"""
        # Implementation for sentiment analysis
        pass
    
    def extract_key_points(self, content: str) -> List[str]:
        """Extract key points from content"""
        # Implementation for key point extraction
        pass
```

**Capabilities:**
- Content analysis and reasoning
- Sentiment analysis
- Key point extraction
- Compliance checking
- Data processing and pattern recognition

### WriterWorker

Handles report generation and writing:

```python
class WriterWorker(Worker):
    def __init__(self, model_config: Dict[str, Any]):
        super().__init__("writer", "report generation and writing", model_config)
    
    def generate_report(self, content_data: Dict[str, Any], style_guide: Dict[str, Any]) -> str:
        """Generate comprehensive report"""
        # Implementation for report generation
        pass
    
    def generate_summary(self, content_data: Dict[str, Any]) -> str:
        """Generate concise summary"""
        # Implementation for summary generation
        pass
```

**Capabilities:**
- Report generation and writing
- Content creation and composition
- Document writing and formatting
- Executive summaries and briefs
- Technical documentation

## 🔄 Workflow Process

### 1. Request Processing

```python
# User submits request
user_request = "What is artificial intelligence?"

# MCP Service processes request
result = mcp_service.process_qa_request(user_request)
```

### 2. Planning Phase

The Planner creates an execution plan:

```json
{
    "goal": "Answer the question about artificial intelligence",
    "subtasks": [
        {
            "id": "task_1",
            "coordinator": "retrieval",
            "task": "Find relevant information about AI",
            "priority": "high",
            "dependencies": [],
            "estimated_duration": 30
        },
        {
            "id": "task_2",
            "coordinator": "analysis",
            "task": "Analyze the retrieved information",
            "priority": "high",
            "dependencies": ["task_1"],
            "estimated_duration": 45
        },
        {
            "id": "task_3",
            "coordinator": "writer",
            "task": "Generate comprehensive answer",
            "priority": "high",
            "dependencies": ["task_2"],
            "estimated_duration": 30
        }
    ]
}
```

### 3. Coordination Phase

Coordinators decompose tasks and delegate to workers:

```python
# Retrieval Coordinator
worker_tasks = {
    "retriever": {
        "task": "Search for AI-related documents",
        "priority": "high",
        "input_data": {"query": "artificial intelligence"},
        "constraints": {}
    }
}

# Analysis Coordinator
worker_tasks = {
    "analyzer": {
        "task": "Analyze AI concepts and definitions",
        "priority": "high",
        "input_data": {"content": retrieved_documents},
        "constraints": {}
    }
}
```

### 4. Execution Phase

Workers execute specialized tasks:

```python
# Retrieval Worker
search_results = retriever.perform_vector_search("artificial intelligence")

# Analysis Worker
analysis_results = analyzer.analyze_sentiment(ai_content)

# Writer Worker
final_response = writer.generate_summary(analysis_results)
```

### 5. Aggregation Phase

The Planner aggregates results into a final response:

```python
final_result = {
    "success": True,
    "final_response": "Artificial intelligence is a field of computer science...",
    "execution_plan": execution_plan,
    "intermediate_results": {
        "task_1": retrieval_results,
        "task_2": analysis_results,
        "task_3": writing_results
    }
}
```

## 📊 Monitoring & Analytics

### System Status

```python
status = mcp_service.get_system_status()

# Returns comprehensive status including:
# - Overall system health
# - Component status (planner, coordinators, workers)
# - Performance metrics
# - Configuration details
```

### Analytics Dashboard

```python
analytics = mcp_service.get_analytics()

# Returns detailed analytics including:
# - Request types and distribution
# - Success rates and performance trends
# - Worker-specific metrics
# - VectorQA integration usage
```

## 🧪 Testing

### Run Test Suite

```bash
# Run all MCP tests
pytest tests/test_mcp_hierarchy.py -v

# Run specific test categories
pytest tests/test_mcp_hierarchy.py::TestMCPBaseClasses -v
pytest tests/test_mcp_hierarchy.py::TestMCPOrchestrator -v
pytest tests/test_mcp_hierarchy.py::TestMCPService -v
```

### Test Coverage

The test suite covers:

- **Base Classes**: MCPContext, MCPProtocol, MCPNode
- **Workers**: RetrievalWorker, AnalysisWorker, WriterWorker
- **Coordinators**: Task decomposition and synthesis
- **Planner**: Execution plan creation and aggregation
- **Orchestrator**: Complete workflow management
- **Service Layer**: VectorQA Sage integration
- **Integration**: End-to-end workflow testing
- **Error Handling**: Robust error management

## 🎛️ Dashboard Features

### System Status
- Real-time system health monitoring
- Component status indicators
- Performance metrics display

### Analytics Dashboard
- Request type distribution charts
- Performance trend analysis
- Worker performance metrics
- VectorQA integration analytics

### Interactive Interfaces
- **QA Processing**: Question-answering with context
- **Report Generation**: Comprehensive report creation
- **Document Analysis**: Multi-type document analysis
- **System Management**: Configuration and control

### Execution History
- Detailed execution logs
- Success rate tracking
- Performance trend visualization

## 🔧 Configuration

### Default Configuration

```python
default_config = {
    "planner_config": {
        "model": "gpt-4o",
        "max_tokens": 2000,
        "temperature": 0.1,
        "provider": "openai"
    },
    "coordinator_config": {
        "model": "gpt-4o-mini",
        "max_tokens": 1500,
        "temperature": 0.2,
        "provider": "openai"
    },
    "worker_config": {
        "model": "gpt-3.5-turbo",
        "max_tokens": 1000,
        "temperature": 0.3,
        "provider": "openai"
    },
    "system_config": {
        "enable_logging": True,
        "enable_analytics": True,
        "max_execution_time": 300,
        "retry_attempts": 2
    }
}
```

### Custom Configuration

```python
custom_config = {
    "planner_config": {
        "model": "gpt-4",
        "max_tokens": 3000,
        "temperature": 0.05
    },
    "vectorqa_integration": {
        "use_vector_store": True,
        "use_dspy_integration": True,
        "enable_real_time_monitoring": True
    }
}

mcp_service = MCPService(custom_config)
```

## 🚀 Advanced Usage

### Custom Worker Implementation

```python
class CustomWorker(Worker):
    def __init__(self, name: str, specialization: str, model_config: Dict[str, Any]):
        super().__init__(name, specialization, model_config)
    
    def _define_protocol(self) -> MCPProtocol:
        return MCPProtocol(
            message_format="json",
            validation_schema={"required": ["task"]},
            error_handling={"retry_count": 1},
            retry_policy={"max_retries": 0}
        )
    
    def process(self, context: MCPContext, task: Dict[str, Any]) -> Dict[str, Any]:
        # Custom processing logic
        return {"result": "custom_processing_result"}
```

### Custom Coordinator

```python
class CustomCoordinator(Coordinator):
    def __init__(self, name: str, domain: str, model_config: Dict[str, Any]):
        super().__init__(name, domain, model_config)
    
    def _decompose_task(self, task: Dict[str, Any], context: MCPContext) -> Dict[str, Any]:
        # Custom task decomposition logic
        return {"custom_worker": {"task": "custom_task"}}
```

### Integration with External Systems

```python
class ExternalIntegrationService:
    def __init__(self, mcp_service: MCPService):
        self.mcp_service = mcp_service
    
    def process_external_request(self, external_data: Dict[str, Any]) -> Dict[str, Any]:
        # Transform external data to MCP format
        user_request = self._transform_to_mcp_request(external_data)
        
        # Process through MCP hierarchy
        result = self.mcp_service.process_request(user_request)
        
        # Transform result back to external format
        return self._transform_from_mcp_result(result)
```

## 🔒 Security & Best Practices

### Credential Management
- All API keys stored securely in environment variables
- Credential manager provides centralized access
- No hardcoded credentials in source code

### Error Handling
- Comprehensive error handling at all levels
- Graceful degradation and fallback strategies
- Detailed error logging and reporting

### Performance Optimization
- Asynchronous processing where possible
- Caching mechanisms for repeated requests
- Resource pooling and connection management

### Monitoring & Observability
- Real-time system monitoring
- Performance metrics collection
- Execution history tracking
- Analytics and reporting

## 🛠️ Troubleshooting

### Common Issues

1. **Import Errors**
   ```bash
   # Ensure backend is in Python path
   export PYTHONPATH="${PYTHONPATH}:/path/to/backend"
   ```

2. **API Key Issues**
   ```bash
   # Check credential file
   cat backend/config/credentials.env
   ```

3. **Vector Store Issues**
   ```python
   # Check vector store initialization
   from backend.core.vector_store import VectorStore
   vector_store = VectorStore()
   ```

### Debug Mode

Enable debug logging:

```python
import logging
logging.basicConfig(level=logging.DEBUG)

# Initialize service with debug
mcp_service = MCPService()
```

### Performance Tuning

```python
# Optimize for speed
fast_config = {
    "planner_config": {"max_tokens": 1000},
    "coordinator_config": {"max_tokens": 800},
    "worker_config": {"max_tokens": 500},
    "system_config": {"max_execution_time": 120}
}

# Optimize for quality
quality_config = {
    "planner_config": {"temperature": 0.05},
    "coordinator_config": {"temperature": 0.1},
    "worker_config": {"temperature": 0.15}
}
```

## 📈 Future Enhancements

### Planned Features

1. **Advanced Orchestration**
   - Dynamic task routing
   - Load balancing across workers
   - Parallel execution optimization

2. **Enhanced Analytics**
   - Real-time performance monitoring
   - Predictive analytics
   - Cost optimization insights

3. **Extended Worker Types**
   - Image analysis workers
   - Audio processing workers
   - Multi-modal workers

4. **Advanced Protocols**
   - Streaming responses
   - Real-time collaboration
   - Distributed processing

### Integration Roadmap

1. **DSPy Integration**
   - Native DSPy module support
   - Optimized prompt chains
   - Advanced reasoning capabilities

2. **Vector Store Enhancements**
   - Multi-modal vector storage
   - Advanced similarity algorithms
   - Real-time indexing

3. **API Extensions**
   - RESTful API endpoints
   - GraphQL interface
   - WebSocket support

## 🤝 Contributing

### Development Setup

1. Fork the repository
2. Create a feature branch
3. Implement your changes
4. Add comprehensive tests
5. Submit a pull request

### Code Standards

- Follow PEP 8 style guidelines
- Add type hints to all functions
- Include comprehensive docstrings
- Write unit tests for new features

### Testing Guidelines

- Maintain >90% test coverage
- Include integration tests
- Test error scenarios
- Performance testing for new features

## 📄 License

This MCP implementation is part of the VectorQA Sage project and follows the same licensing terms.

## 🆘 Support

For issues and questions:

1. Check the troubleshooting section
2. Review the test suite for examples
3. Examine the dashboard for system status
4. Create an issue in the repository

---

**MCP Hierarchical LLM System** - Transforming VectorQA Sage with structured AI reasoning and coordination.
