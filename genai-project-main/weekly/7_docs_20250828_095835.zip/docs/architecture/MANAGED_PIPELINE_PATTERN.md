# Managed Pipeline Pattern - Enterprise Document Processing

## 🎯 **Overview**

The **Managed Pipeline Pattern** is a cloud-native, low-friction redesign that offloads complexity to managed services and simplifies orchestration for enterprise document processing systems.

## 🏗️ **Architecture Summary**

```
┌─────────────────────────────────────────────────────────────┐
│                    Managed Pipeline Pattern                 │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Webhook       │  │   Event-Driven  │  │   Serverless │ │
│  │   Triggers      │  │   Processing    │  │   Jobs       │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Cached        │  │   Versioned     │  │   Decoupled  │ │
│  │   Embeddings    │  │   Storage       │  │   UI/Logic   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## ✅ **Goals of This Redesign**

| Target | Strategy |
|--------|----------|
| 🔐 **Reduce auth friction** | Remove token juggling (Box, S3, IAM complexity) |
| 🧠 **Simplify DSPy/LLM workflow** | Consolidate LLM and vector search logic |
| 🗂 **Reduce indexing overhead** | Avoid re-embedding by storing canonical hashes |
| 🧾 **Improve logging + versioning** | Store previews in versioned DB with rollback |
| 🖥 **Reduce UX friction** | Decouple viewer from processor; allow polling + retries |
| 📉 **Lower costs + idle compute** | Use event-driven, serverless infra |

## 🚨 **25 Pain Points: How They're Reduced**

| Pain Area | Previous Pain | Managed Pattern Fix |
|-----------|---------------|-------------------|
| 🔐 **Box Auth** | Token juggling, link expiry | App Token + folder-scoped webhook triggers → no direct file links |
| 🗂 **Box fetch** | File not ready at trigger time | Use event delay queue or precheck in Lambda |
| 📦 **Embedding** | Re-runs without change detection | Hash files before embedding; cache by doc_id+hash+version |
| 💰 **Cost** | Re-embedding unchanged docs | Embedding cache layer avoids duplicate Bedrock calls |
| ⚠️ **Vector store complexity** | Manual index mgmt | S3 Vector + Metadata DB auto-managed by Lambda |
| 🧠 **DSPy Signature drift** | No version tracking | Signature ID + version stored in metadata DB |
| 🔁 **Retry logic** | Silent failures | Lambda retries, or retry flags stored in DB with TTL watchdog |
| 📝 **Logging** | Manual, unversioned | Preview + edits stored in Postgres or DynamoDB, versioned by run # |
| 🧵 **UI tied to logic** | Fragile coupling | Processing and UI are fully decoupled |
| 📤 **Preview display** | Blocking / slow UX | Poll or subscribe to preview status in web UI |
| 📎 **Reviewer edits** | Not tracked clearly | All edits stored as diffs in DB, versioned per doc |
| 🧠 **Prompt coverage** | No confidence levels | DSPy output includes section match confidence, visible in UI |
| 🔍 **Flag drift** | Flags vary by doc type | Ruleset stored as JSON in DB and attached to each preview run |
| 📦 **Box webhook spam** | Race condition | Use idempotent dedup key in queue or DB lock |
| 🚫 **No rollback** | Reviewers overwrite output | DB stores all previews as immutable versions, with rollback option |
| 🌐 **Hosting** | Monolithic | Stateless Lambda + separate Streamlit frontend |
| 🕒 **Latency complaints** | No spinner | Frontend fetches from queue or API with progress bar |
| 🔄 **File updates** | Requires re-embedding | Hash-based check detects true changes |
| ⚙️ **Deployment** | Manual components | Fully deployable via CDK / Terraform as serverless stack |
| 🔧 **DSPy tuning** | Black box | Expose Signature version + sample prompt per run in log |
| 🔒 **Vector ACL** | Lacked control | Embed metadata includes project/user, used in filtering |
| 📥 **Invalid files** | OCR not applied | Precheck for OCR/parse errors → route to fallback queue |
| 📈 **Observability** | No job status | All runs tagged with job ID, status, retry state, timestamps |
| 🧾 **Compliance tracking** | Manual | Each preview stamped with reviewer ID, doc version, model version |
| 🚨 **Error visibility** | Buried logs | Errors shown in web UI status feed or email alert (SNS/SES) |

## 🏗️ **Implementation Architecture**

### **1. Event-Driven Processing Pipeline**

```python
# Webhook-triggered pipeline
class ManagedDocumentPipeline:
    def __init__(self):
        self.event_queue = EventBridge()
        self.processing_lambda = LambdaFunction()
        self.cache_layer = ElastiCache()
        self.version_db = PostgreSQL()
    
    def handle_webhook(self, event):
        """Handle webhook from Box/SharePoint"""
        # Extract file metadata
        file_info = self.extract_file_info(event)
        
        # Check if already processed (hash-based)
        if self.is_already_processed(file_info['hash']):
            return {"status": "already_processed"}
        
        # Queue for processing
        self.event_queue.send_message({
            'file_id': file_info['id'],
            'hash': file_info['hash'],
            'version': file_info['version'],
            'timestamp': datetime.now()
        })
        
        return {"status": "queued", "job_id": file_info['id']}
```

### **2. Cached Embedding System**

```python
class CachedEmbeddingManager:
    def __init__(self):
        self.cache = ElastiCache()
        self.vector_store = S3VectorStore()
        self.metadata_db = PostgreSQL()
    
    def get_or_create_embedding(self, doc_id: str, content_hash: str, version: str):
        """Get cached embedding or create new one"""
        cache_key = f"{doc_id}:{content_hash}:{version}"
        
        # Check cache first
        cached = self.cache.get(cache_key)
        if cached:
            return cached
        
        # Create new embedding
        embedding = self.create_embedding(doc_id, content_hash, version)
        
        # Store in cache and vector store
        self.cache.set(cache_key, embedding, ttl=86400)  # 24 hours
        self.vector_store.store(doc_id, embedding, metadata={
            'hash': content_hash,
            'version': version,
            'created_at': datetime.now()
        })
        
        return embedding
```

### **3. Versioned Storage System**

```python
class VersionedDocumentStorage:
    def __init__(self):
        self.db = PostgreSQL()
        self.s3 = S3Bucket()
    
    def store_preview(self, doc_id: str, version: str, preview_data: dict):
        """Store immutable preview version"""
        preview_id = f"{doc_id}:{version}:{datetime.now().isoformat()}"
        
        # Store in database
        self.db.insert('document_previews', {
            'preview_id': preview_id,
            'doc_id': doc_id,
            'version': version,
            'preview_data': json.dumps(preview_data),
            'created_at': datetime.now(),
            'reviewer_id': preview_data.get('reviewer_id'),
            'model_version': preview_data.get('model_version')
        })
        
        # Store artifacts in S3
        self.s3.upload(f"previews/{preview_id}.json", preview_data)
        
        return preview_id
    
    def get_preview_history(self, doc_id: str):
        """Get all preview versions for a document"""
        return self.db.query("""
            SELECT * FROM document_previews 
            WHERE doc_id = %s 
            ORDER BY created_at DESC
        """, [doc_id])
    
    def rollback_to_version(self, doc_id: str, version: str):
        """Rollback to specific version"""
        # Implementation for rollback logic
        pass
```

### **4. Decoupled UI Architecture**

```python
# Frontend (Streamlit)
class DocumentViewer:
    def __init__(self):
        self.api_client = APIClient()
        self.polling_interval = 5000  # 5 seconds
    
    def display_document_status(self, doc_id: str):
        """Display document processing status with polling"""
        while True:
            status = self.api_client.get_document_status(doc_id)
            
            if status['state'] == 'completed':
                self.display_preview(status['preview_data'])
                break
            elif status['state'] == 'failed':
                self.display_error(status['error'])
                break
            else:
                self.display_progress(status['progress'])
                time.sleep(self.polling_interval)
    
    def display_preview(self, preview_data: dict):
        """Display document preview with confidence scores"""
        # Render preview with confidence indicators
        pass
```

## 🔧 **Implementation Components**

### **1. AWS Lambda Functions**

```python
# Document Processing Lambda
def lambda_handler(event, context):
    """Main document processing function"""
    try:
        # Extract file info from event
        file_info = event['detail']
        
        # Process document
        processor = DocumentProcessor()
        result = processor.process(file_info)
        
        # Store results
        storage = VersionedDocumentStorage()
        preview_id = storage.store_preview(
            file_info['doc_id'],
            file_info['version'],
            result
        )
        
        # Update status
        update_processing_status(file_info['doc_id'], 'completed', preview_id)
        
    except Exception as e:
        # Handle errors and retries
        handle_processing_error(file_info['doc_id'], str(e))
        raise
```

### **2. Database Schema**

```sql
-- Document processing status
CREATE TABLE document_processing_status (
    doc_id VARCHAR(255) PRIMARY KEY,
    status VARCHAR(50) NOT NULL,
    preview_id VARCHAR(255),
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Document previews (versioned)
CREATE TABLE document_previews (
    preview_id VARCHAR(255) PRIMARY KEY,
    doc_id VARCHAR(255) NOT NULL,
    version VARCHAR(100) NOT NULL,
    preview_data JSONB NOT NULL,
    reviewer_id VARCHAR(255),
    model_version VARCHAR(100),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Processing cache
CREATE TABLE embedding_cache (
    cache_key VARCHAR(500) PRIMARY KEY,
    embedding_data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT NOW(),
    expires_at TIMESTAMP NOT NULL
);
```

### **3. Event Bridge Rules**

```yaml
# CDK/CloudFormation configuration
Resources:
  DocumentProcessingRule:
    Type: AWS::Events::Rule
    Properties:
      EventPattern:
        source:
          - "aws.s3"
        detail-type:
          - "Object Created"
        detail:
          bucket:
            name: ["document-upload-bucket"]
      Targets:
        - Arn: !GetAtt DocumentProcessingFunction.Arn
          Id: "DocumentProcessingTarget"
```

## 🎯 **Benefits Summary**

| Feature | Benefit |
|---------|---------|
| **Webhook-triggered pipeline** | Reduces auth, avoids polling |
| **Serverless jobs** | Scales cleanly, cost-effective |
| **DB-backed versioning** | Enables rollback, audit traceability |
| **Cached embedding & preview logic** | Avoids duplication, saves money |
| **Separate viewer** | Reduces coupling, improves UX |
| **Event-driven architecture** | Handles spikes, reduces idle compute |
| **Hash-based change detection** | Prevents unnecessary reprocessing |
| **Immutable versioning** | Enables audit trails and rollbacks |

## 🚀 **Deployment Strategy**

### **Phase 1: Core Infrastructure**
1. **Set up AWS Lambda functions** for document processing
2. **Create PostgreSQL database** for versioning and metadata
3. **Implement webhook handlers** for Box/SharePoint integration
4. **Build caching layer** for embeddings and previews

### **Phase 2: Processing Pipeline**
1. **Implement hash-based change detection**
2. **Add retry logic and error handling**
3. **Create versioned storage system**
4. **Build status tracking and monitoring**

### **Phase 3: UI and Integration**
1. **Decouple frontend from processing logic**
2. **Implement polling and progress indicators**
3. **Add rollback and audit capabilities**
4. **Create compliance tracking features**

### **Phase 4: Enterprise Features**
1. **Add multi-tenant support**
2. **Implement advanced security controls**
3. **Create disaster recovery procedures**
4. **Add performance monitoring and alerting**

## 🔒 **Security Considerations**

### **Authentication & Authorization**
- **App-level tokens** for Box/SharePoint integration
- **IAM roles** for AWS service access
- **Database-level access controls**
- **API key management** for external access

### **Data Protection**
- **Encryption at rest** for all stored data
- **Encryption in transit** for all communications
- **PII detection and redaction**
- **Audit logging** for compliance

### **Compliance Features**
- **Data retention policies**
- **Version control** for regulatory requirements
- **Audit trails** for all document processing
- **Access logging** for security monitoring

---

**This Managed Pipeline Pattern transforms our document processing system into an enterprise-ready, scalable, and cost-effective solution that addresses the core pain points of enterprise deployment.** 🚀
