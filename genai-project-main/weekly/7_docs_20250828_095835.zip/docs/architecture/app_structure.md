
# 📁 Application Structure – VectorQA Sage

This document lists all files and their purposes in the VectorQA Sage project (Refactored Layout).

---

## 🧠 App Entry & Controllers

| File | Purpose |
|------|---------|
| `app/main.py` | Main Streamlit application entry point |
| `app/example_manager.py` | Utility to load/edit/save examples |
| `app/model_eval_dashboard.py` | Generates charts for evaluation dashboard |

---

## 🧩 App Modules – Tabs

| File | Purpose |
|------|---------|
| `app/tabs/fewshot_qa_app_tab1_upload_normalize.py` | Tab 1: Upload & normalize labeled examples |
| `app/tabs/fewshot_qa_app_tab2_split.py` | Tab 2: Split labeled data into train/test |
| `app/tabs/fewshot_qa_app_tab3_edit_examples.py` | Tab 3: Interactive label editing |
| `app/tabs/fewshot_qa_app_tab4_dspy_prompt_config.py` | Tab 4: Configure prompts (LLM vs DSPy) |
| `app/tabs/fewshot_qa_app_tab5_evaluate.py` | Tab 5: Evaluation dashboard (accuracy, confusion matrix) |
| `app/tabs/fewshot_qa_app_tab6_faiss_status.py` | Tab 6: View status of FAISS + model mapping |
| `app/tabs/fewshot_qa_app_tab7_compile_dspy.py` | Tab 7: Compile DSPy modules and save |

---

## 🔧 Core Logic – DSPy & Config

| File | Purpose |
|------|---------|
| `app/core/config.py` | Central CONFIG dictionary for model, S3, FAISS |
| `app/core/dsp_pipeline_loader.py` | Loads compiled DSPy modules |
| `app/core/normalize_labels.py` | Cleans validation labels for scoring |
| `app/core/qa_log_utils.py` | Log tracking and timestamping |
| `app/core/validator.py` | DSPy Signature + Module for QA scoring |
| `app/core/dspy_prompt_config.py` | Formats DSPy-compatible prompt variants |

---

## 🧰 Scripts

| File | Purpose |
|------|---------|
| `scripts/admin_setup.py` | Preps folders and mappings |
| `scripts/test_dspy_simulation.py` | Dry run DSPy strategies (optional) |

---

## 📊 Data & Evaluation Files

| File | Purpose |
|------|---------|
| `data/examples_topic.json` | Ground truth QA pairs |
| `data/test_examples.json` | Subset for testing |
| `data/validated_titan_v1.json` | Predictions from Titan |
| `data/validated_cohere.json` | Predictions from Cohere |
| `data/faiss_model_map.json` | FAISS-to-model mapping config |

---

## 📦 Compiled Modules

| File | Purpose |
|------|---------|
| `compiled_modules/.gitkeep` | Keeps folder in version control |
| `compiled_modules/*.dspy` | Saved DSPy modules by model key |

---

## 📘 Documentation

| File | Purpose |
|------|---------|
| `docs/APP_STRUCTURE.md` | This file – directory reference |
| `docs/DEPLOY.md` | Deployment options (local, Streamlit Cloud, SageMaker) |
| `docs/vectorqa_sage_quick_start_guide.json` | JSON for app-loaded help |
| `docs/vectorqa_sage_quick_start_guide.pdf` | Printable guide |
| `docs/vectorqa_sage_quick_start_guide.docx` | Word-editable guide |

---

## 📁 Logs

| File | Purpose |
|------|---------|
| `logs/qa_log.txt` | Captures prediction results and system activity |

---

## ⚙️ Project Metadata

| File | Purpose |
|------|---------|
| `README.md` | Main usage instructions |
| `requirements.txt` | Python dependencies |
| `setup.py` | Installer (optional use) |
| `.gitignore` | Rules to ignore logs/cache/data |
