# 🏗️ Architecture Documentation - VectorQA Sage

## 🎯 Overview

Complete architecture documentation for VectorQA Sage, covering system design, component interactions, and architectural decisions.

## 🏛️ System Architecture

### **High-Level Architecture**
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend       │    │   Database      │
│   (Streamlit)   │◄──►│   (Python)      │◄──►│   (PostgreSQL)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   ZLLM Gateway  │    │   MCP System    │    │   Vector Store  │
│   (Local LLM)   │    │   (Hierarchical)│    │   (pgvector)    │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### **Component Architecture**

#### **1. Frontend Layer**
- **Technology**: Streamlit
- **Purpose**: User interface and interaction
- **Components**:
  - Document upload interface
  - Chat interface
  - Status display
  - Results visualization

#### **2. Backend Layer**
- **Technology**: Python
- **Purpose**: Business logic and processing
- **Components**:
  - PDF processing pipeline
  - AI integration
  - Data processing
  - Error handling

#### **3. Database Layer**
- **Technology**: PostgreSQL + pgvector
- **Purpose**: Data persistence and vector storage
- **Components**:
  - Document metadata
  - Vector embeddings
  - Structured data (TOC, bibliography)
  - Error tracking

#### **4. AI Integration Layer**
- **Technology**: ZLLM Gateway
- **Purpose**: Local LLM processing
- **Components**:
  - Model management
  - Response generation
  - Fallback handling

## 🔧 MCP (Model Context Protocol) Architecture

### **Hierarchical Structure**
```
┌─────────────────────────────────────────────────────────────┐
│                    EnhancedPlanner                          │
│              (Strategic Planning & Routing)                 │
└─────────────────────────────────────────────────────────────┘
                                │
                ┌───────────────┼───────────────┐
                │               │               │
                ▼               ▼               ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│ DocumentCoord   │ │ SMEContextCoord │ │ DSPyCoordinator │
│ (Document Proc) │ │ (Domain Context)│ │ (LLM Pipeline)  │
└─────────────────┘ └─────────────────┘ └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐
│ PDFProcessor    │ │ LiveContext     │ │ EmbeddingGen    │
│ TextCleaner     │ │ Worker          │ │ TableExtractor  │
│ ImageProcessor  │ │                 │ │                 │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

### **Orchestrator Pattern**
- **QAOrchestrator**: Basic QA processing
- **QAReviewerOrchestrator**: Expert QA with compliance
- **LLMEnhancedQAOrchestrator**: LLM-enhanced processing
- **RAGQAOrchestrator**: RAG-based document querying

## 📄 PDF Processing Architecture

### **Multi-Library Fallback System**
```
┌─────────────────┐
│   Input PDF     │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ ModernPDFProc   │
│ (Primary)       │
└─────────────────┘
         │
         ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ pdfplumber      │    │ pypdfium2       │    │ pypdf           │
│ (Text/Tables)   │    │ (Images)        │    │ (Fallback)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│ TOC Extractor   │    │ Image Processor │    │ Basic Text      │
│ Bibliography    │    │ (Multi-strategy)│    │ Extraction      │
│ Builder         │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### **Specialized Workers**
- **TOCExtractorWorker**: Hierarchical table of contents extraction
- **BibliographyBuilderWorker**: Academic citation parsing
- **ImageProcessingWorker**: Multi-strategy image extraction
- **ModernPDFProcessor**: Advanced PDF processing with fallbacks

## 🗄️ Database Architecture

### **Core Tables**
```sql
-- Document Management
documents (id, title, file_path, created_at, metadata)
document_chunks (id, document_id, content, chunk_index, embeddings)

-- Vector Storage
chunk_embeddings (id, chunk_id, embedding_vector, model_version)

-- Structured Data
toc_structures (id, document_id, structure_data, confidence_score)
toc_entries (id, toc_id, title, level, page_number, parent_id)
bibliography_structures (id, document_id, citations_data)
citations (id, bib_id, authors, title, year, doi, citation_type)

-- Error Tracking
prompt_history (id, prompt_text, response_text, success, error_message)
error_tracking (id, error_type, severity, context_data, resolution_status)
alert_history (id, alert_type, recipient, message, status)

-- Real-time Context
real_time_context (id, prompt_id, context_type, context_data, relevance_score)
batch_processing_status (id, batch_id, status, progress, metadata)
```

### **Vector Storage with pgvector**
- **Embedding Generation**: sentence-transformers
- **Similarity Search**: Cosine similarity with pgvector
- **Indexing**: HNSW (Hierarchical Navigable Small World)
- **Dimensionality**: 768-dimensional embeddings

## 🔐 Security Architecture

### **Current State**
```
┌─────────────────┐
│   User Input    │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│   Processing    │
│   (No Security) │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│   AI Response   │
└─────────────────┘
```

### **Recommended Security Layer**
```
┌─────────────────┐
│   User Input    │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ Authentication  │
│ (API Key)       │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ Content Filter  │
│ (XSS/SQL Inj)   │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ PII Detection   │
│ (ScrubScan)     │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ Rate Limiting   │
│ (Abuse Prev)    │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│   Processing    │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│ Audit Logging   │
│ (Compliance)    │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│   AI Response   │
└─────────────────┘
```

## 📊 Performance Architecture

### **Caching Strategy**
- **In-Memory Cache**: TOC, bibliography, image processing results
- **Database Cache**: Vector embeddings, processed documents
- **Session Cache**: User session data, chat history

### **Scalability Considerations**
- **Horizontal Scaling**: Multiple Streamlit instances
- **Database Scaling**: Read replicas, connection pooling
- **AI Scaling**: Multiple ZLLM instances, load balancing
- **Storage Scaling**: S3 integration, CDN for static assets

## 🔄 Data Flow Architecture

### **Document Processing Flow**
```
1. Upload → 2. Validation → 3. PDF Processing → 4. Text Extraction
     ↓              ↓              ↓              ↓
5. TOC Extraction → 6. Bibliography → 7. Chunking → 8. Embedding
     ↓              ↓              ↓              ↓
9. Vector Storage → 10. Metadata → 11. Indexing → 12. Ready
```

### **Query Processing Flow**
```
1. User Query → 2. Authentication → 3. Rate Limiting → 4. PII Check
     ↓              ↓              ↓              ↓
5. Vector Search → 6. Context Retrieval → 7. AI Processing → 8. Response
     ↓              ↓              ↓              ↓
9. Content Filter → 10. Audit Log → 11. Response → 12. User
```

## 🚀 Deployment Architecture

### **Development Environment**
- **Local**: Single machine, all components
- **Docker**: Containerized development
- **Database**: Local PostgreSQL

### **Production Environment**
- **Web Server**: Nginx reverse proxy
- **Application**: Multiple Streamlit instances
- **Database**: PostgreSQL cluster with pgvector
- **AI Gateway**: ZLLM cluster with load balancing
- **Monitoring**: MLflow, Prometheus, Grafana

## 📈 Monitoring Architecture

### **Metrics Collection**
- **Application Metrics**: Response time, throughput, error rates
- **System Metrics**: CPU, memory, disk usage
- **Business Metrics**: Document processing, user engagement
- **Security Metrics**: Authentication, authorization, audit events

### **Alerting System**
- **Critical Alerts**: System failures, security breaches
- **Warning Alerts**: Performance degradation, resource usage
- **Info Alerts**: System events, user activities

---

**For detailed implementation guides, see the technical documentation.**
