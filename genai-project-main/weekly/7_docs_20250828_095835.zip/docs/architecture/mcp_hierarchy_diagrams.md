# MCP Hierarchy Diagrams

This document contains Mermaid diagrams for the new MCP (Model Context Protocol) hierarchy structure, showing the Planner → Coordinator → Worker flow for each orchestrator.

## Overview

The new MCP hierarchy follows a clean three-layer architecture:
- **Planner Layer**: Analyzes requests and selects coordination strategies
- **Coordinator Layer**: Manages specific domains and orchestrates workers
- **Worker Layer**: Executes specialized micro-tasks

## 1. Enhanced Planner (Smart Router)

The Enhanced Planner acts as the top-level orchestrator, analyzing user requests and selecting appropriate coordination strategies.

```mermaid
flowchart TD
    U[User Request] --> EP[Enhanced Planner]
    
    subgraph "Planner Analysis"
        AR[Analyze Request]
        DS[Decision Strategy]
        CM[Create Message]
    end
    
    subgraph "Coordination Strategies"
        DC[Document Coordinator]
        AC[Analysis Coordinator]
        VC[Validation Coordinator]
    end
    
    subgraph "Performance Tracking"
        PM[Performance Metrics]
        DL[Decision Log]
        AT[Audit Trail]
    end
    
    EP --> AR
    AR --> DS
    DS --> CM
    CM --> DC
    CM --> AC
    CM --> VC
    
    DC --> PM
    AC --> PM
    VC --> PM
    PM --> DL
    DL --> AT
    
    %% Styling
    style EP fill:#085280,color:#fff,stroke:#121212,stroke-width:2px
    style AR fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style DS fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style CM fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style DC fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style AC fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style VC fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style PM fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    style DL fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    style AT fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    style U fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 2. Document Coordinator

The Document Coordinator manages document processing tasks, including PDF extraction, text cleaning, chunking, and embedding generation.

```mermaid
flowchart TD
    PC[Planner Command] --> DC[Document Coordinator]
    
    subgraph "Document Processing Pipeline"
        PDF[PDF Processor Worker]
        TC[Text Cleaner Worker]
        CG[Chunk Generator]
        EG[Embedding Generator Worker]
        TE[Table Extractor Worker]
    end
    
    subgraph "Processing Steps"
        S1[Step 1: Extract PDF]
        S2[Step 2: Clean Text]
        S3[Step 3: Generate Chunks]
        S4[Step 4: Create Embeddings]
        S5[Step 5: Process Tables]
    end
    
    subgraph "Output Components"
        TI[Text Information]
        CI[Chunk Information]
        EI[Embedding Information]
        TAI[Table Analysis]
        AI[Audit Information]
    end
    
    DC --> S1
    S1 --> PDF
    PDF --> S2
    S2 --> TC
    TC --> S3
    S3 --> CG
    CG --> S4
    S4 --> EG
    EG --> S5
    S5 --> TE
    
    PDF --> TI
    TC --> TI
    CG --> CI
    EG --> EI
    TE --> TAI
    
    TI --> AI
    CI --> AI
    EI --> AI
    TAI --> AI
    
    AI --> DC
    
    %% Styling
    style DC fill:#085280,color:#fff,stroke:#121212,stroke-width:2px
    style PDF fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style TC fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style CG fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style EG fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style TE fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style S1 fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style S2 fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style S3 fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style S4 fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style S5 fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style PC fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 3. PDF Processor Worker

The PDF Processor Worker handles PDF document extraction, including text, images, and tables.

```mermaid
flowchart TD
    CM[Coordinator Message] --> PPW[PDF Processor Worker]
    
    subgraph "PDF Processing Tasks"
        OPDF[Open PDF]
        ET[Extract Text]
        EI[Extract Images]
        ETB[Extract Tables]
        C[Close Document]
    end
    
    subgraph "Image Processing"
        ICL[Image Classification]
        ICS[Image Colorspace Check]
        ISZ[Image Size Analysis]
    end
    
    subgraph "Table Processing"
        TCL[Table Classification]
        TRC[Table Row/Column Count]
        TCT[Table Content Type]
    end
    
    subgraph "Output Data"
        TC[Text Content]
        IC[Image Data]
        TD[Table Data]
        PC[Page Count]
        FS[File Size]
    end
    
    PPW --> OPDF
    OPDF --> ET
    ET --> EI
    EI --> ETB
    ETB --> C
    
    EI --> ICL
    EI --> ICS
    EI --> ISZ
    
    ETB --> TCL
    ETB --> TRC
    ETB --> TCT
    
    ET --> TC
    EI --> IC
    ETB --> TD
    OPDF --> PC
    OPDF --> FS
    
    TC --> PPW
    IC --> PPW
    TD --> PPW
    PC --> PPW
    FS --> PPW
    
    %% Styling
    style PPW fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style OPDF fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style ET fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style EI fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style ETB fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style C fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style CM fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 4. Text Cleaner Worker

The Text Cleaner Worker processes and cleans extracted text, extracts references, claims, and evidence.

```mermaid
flowchart TD
    CM[Coordinator Message] --> TCW[Text Cleaner Worker]
    
    subgraph "Text Processing Tasks"
        CT[Clean Text]
        ER[Extract References]
        EC[Extract Claims]
        EE[Extract Evidence]
    end
    
    subgraph "Text Cleaning"
        RWS[Remove Whitespace]
        RSC[Remove Special Characters]
        FOCR[Fix OCR Issues]
    end
    
    subgraph "Reference Extraction"
        ARP[Academic Reference Patterns]
        URLP[URL Patterns]
        RP[Reference Positions]
    end
    
    subgraph "Claim Extraction"
        CP[Claim Patterns]
        CPOS[Claim Positions]
    end
    
    subgraph "Evidence Extraction"
        EP[Evidence Patterns]
        EPOS[Evidence Positions]
    end
    
    subgraph "Output Data"
        CTX[Cleaned Text]
        REF[References]
        CLM[Claims]
        EV[Evidence]
        OL[Original Length]
        CL[Cleaned Length]
    end
    
    TCW --> CT
    CT --> ER
    ER --> EC
    EC --> EE
    
    CT --> RWS
    CT --> RSC
    CT --> FOCR
    
    ER --> ARP
    ER --> URLP
    ER --> RP
    
    EC --> CP
    EC --> CPOS
    
    EE --> EP
    EE --> EPOS
    
    CT --> CTX
    ER --> REF
    EC --> CLM
    EE --> EV
    CT --> OL
    CT --> CL
    
    CTX --> TCW
    REF --> TCW
    CLM --> TCW
    EV --> TCW
    OL --> TCW
    CL --> TCW
    
    %% Styling
    style TCW fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style CT fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style ER fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style EC fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style EE fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style CM fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 5. Embedding Generator Worker

The Embedding Generator Worker creates vector embeddings for text chunks using sentence transformers.

```mermaid
flowchart TD
    CM[Coordinator Message] --> EGW[Embedding Generator Worker]
    
    subgraph "Embedding Processing"
        LM[Load Model]
        EC[Encode Chunks]
        VE[Validate Embeddings]
    end
    
    subgraph "Model Management"
        SM[Sentence Transformer Model]
        MF[Model Fallback]
    end
    
    subgraph "Chunk Processing"
        CI[Chunk Input]
        CE[Chunk Encoding]
        CO[Chunk Output]
    end
    
    subgraph "Embedding Data"
        EV[Embedding Vectors]
        ED[Embedding Dimensions]
        TL[Text Lengths]
        CID[Chunk IDs]
    end
    
    subgraph "Output Metrics"
        TC[Total Chunks]
        EDIM[Embedding Dimension]
        SC[Success Count]
    end
    
    EGW --> LM
    LM --> EC
    EC --> VE
    
    LM --> SM
    LM --> MF
    
    EC --> CI
    CI --> CE
    CE --> CO
    
    CE --> EV
    CE --> ED
    CE --> TL
    CE --> CID
    
    VE --> TC
    VE --> EDIM
    VE --> SC
    
    TC --> EGW
    EDIM --> EGW
    SC --> EGW
    
    %% Styling
    style EGW fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style LM fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style EC fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style VE fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style CM fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 6. Table Extractor Worker

The Table Extractor Worker processes and analyzes table data from documents.

```mermaid
flowchart TD
    CM[Coordinator Message] --> TEW[Table Extractor Worker]
    
    subgraph "Table Processing"
        PT[Process Table]
        ED[Extract Data]
        AD[Analyze Data]
    end
    
    subgraph "Data Extraction"
        HC[Header Content]
        RC[Row Content]
        SC[Structured Data]
    end
    
    subgraph "Column Analysis"
        NC[Numeric Columns]
        TC[Text Columns]
        DC[Date Columns]
        DT[Data Types]
    end
    
    subgraph "Table Metadata"
        TR[Table Rows]
        TC2[Table Columns]
        TH[Table Header]
        TP[Table Page]
    end
    
    subgraph "Output Data"
        SD[Structured Data]
        TA[Table Analysis]
        TM[Table Metadata]
    end
    
    TEW --> PT
    PT --> ED
    ED --> AD
    
    ED --> HC
    ED --> RC
    ED --> SC
    
    AD --> NC
    AD --> TC
    AD --> DC
    AD --> DT
    
    PT --> TR
    PT --> TC2
    PT --> TH
    PT --> TP
    
    SC --> SD
    AD --> TA
    PT --> TM
    
    SD --> TEW
    TA --> TEW
    TM --> TEW
    
    %% Styling
    style TEW fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style PT fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style ED fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style AD fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style CM fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## 7. Complete MCP Hierarchy Flow

This diagram shows the complete flow from user request to final result through the entire MCP hierarchy.

```mermaid
flowchart TD
    U[User Request] --> EP[Enhanced Planner]
    
    subgraph "Planner Layer"
        AR[Analyze Request]
        DS[Decision Strategy]
        CM[Create Message]
    end
    
    subgraph "Coordinator Layer"
        DC[Document Coordinator]
        AC[Analysis Coordinator]
        VC[Validation Coordinator]
    end
    
    subgraph "Worker Layer"
        PDF[PDF Processor]
        TC[Text Cleaner]
        EG[Embedding Generator]
        TE[Table Extractor]
        LLM[LLM Worker]
        VAL[Validator Worker]
    end
    
    subgraph "Message Protocol"
        MP[MCP Message]
        AT[Audit Trail]
        PM[Performance Metrics]
    end
    
    subgraph "Output"
        R[Result]
        AL[Audit Log]
        ML[Metrics Log]
    end
    
    EP --> AR
    AR --> DS
    DS --> CM
    CM --> MP
    
    MP --> DC
    MP --> AC
    MP --> VC
    
    DC --> PDF
    DC --> TC
    DC --> EG
    DC --> TE
    
    AC --> LLM
    VC --> VAL
    
    PDF --> AT
    TC --> AT
    EG --> AT
    TE --> AT
    LLM --> AT
    VAL --> AT
    
    AT --> PM
    PM --> R
    AT --> AL
    PM --> ML
    
    %% Styling
    style EP fill:#085280,color:#fff,stroke:#121212,stroke-width:2px
    style DC fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style AC fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style VC fill:#238196,color:#fff,stroke:#121212,stroke-width:2px
    style PDF fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style TC fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style EG fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style TE fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style LLM fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style VAL fill:#C55422,color:#fff,stroke:#121212,stroke-width:2px
    style U fill:#e1f5fe,stroke:#01579b,stroke-width:2px
```

## Key Benefits of the New MCP Hierarchy

1. **Clear Separation of Concerns**: Each layer has a specific responsibility
2. **Auditability**: Every decision and action is tracked through the audit trail
3. **Modularity**: Components can be swapped or upgraded independently
4. **Scalability**: Workers can be distributed across multiple systems
5. **Performance Monitoring**: Granular metrics at each level
6. **Error Tracing**: Failures can be traced to specific components
7. **Standardized Protocol**: Consistent message format across all layers

## Color Coding

- **Blue (Planner)**: High-level orchestration and decision making
- **Teal (Coordinators)**: Domain-specific coordination and management
- **Orange (Workers)**: Specialized task execution
- **Light Blue**: Input/Output and data flow
