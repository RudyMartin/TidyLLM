# Database Setup Guide

## 🔗 Database Configuration

The database connection strings have been updated to use environment variables for security.

### 1. Environment Configuration

Copy the template and configure your database:

```bash
# Copy template
cp environ_settings/.env.template environ_settings/.env.local

# Edit with your credentials
nano environ_settings/.env.local
```

### 2. Database Options

#### Option A: Local PostgreSQL
```bash
# Install PostgreSQL locally
brew install postgresql  # macOS
sudo apt-get install postgresql postgresql-contrib  # Ubuntu

# Start PostgreSQL
brew services start postgresql  # macOS
sudo systemctl start postgresql  # Ubuntu

# Create database
createdb vectorqa
```

#### Option B: Docker PostgreSQL
```bash
# Run PostgreSQL in Docker
docker run --name vectorqa-postgres \
  -e POSTGRES_DB=vectorqa \
  -e POSTGRES_USER=vectorqa \
  -e POSTGRES_PASSWORD=your_password \
  -p 5432:5432 \
  -d postgres:15
```

#### Option C: AWS RDS
```bash
# Use AWS RDS PostgreSQL instance
# Update .env.local with your RDS endpoint
DB_HOST=your-rds-endpoint.amazonaws.com
```

### 3. Test Connection

```bash
# Test database connectivity
python3 scripts/check_database_connectivity.py

# Run database exploration
python3 notebooks/01_database_exploration.py
```

### 4. Environment Variables

The following environment variables are used:

- `DB_HOST`: Database host (default: localhost)
- `DB_PORT`: Database port (default: 5432)
- `DB_NAME`: Database name (default: vectorqa)
- `DB_USER`: Database username
- `DB_PASSWORD`: Database password
- `DATABASE_URL`: Full connection string (auto-generated)

### 5. Security Notes

- Never commit `.env.local` to version control
- Use strong passwords for database users
- Consider using AWS Secrets Manager for production
- Enable SSL for remote database connections

## 🚀 Quick Start

1. **Setup Database:**
   ```bash
   # Local PostgreSQL
   createdb vectorqa
   ```

2. **Configure Environment:**
   ```bash
   cp environ_settings/.env.template environ_settings/.env.local
   # Edit .env.local with your credentials
   ```

3. **Test Connection:**
   ```bash
   python3 scripts/check_database_connectivity.py
   ```

4. **Run Application:**
   ```bash
   python3 run_qa_demo.py
   ```
