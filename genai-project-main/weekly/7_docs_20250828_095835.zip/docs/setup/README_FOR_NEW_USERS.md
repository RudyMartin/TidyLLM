# 🚀 Welcome to VectorQA Sage

## 🎯 For New Engineers & Data Scientists

**Start here: [docs/getting-started/NEW_ENGINEER_GUIDE.md](docs/getting-started/NEW_ENGINEER_GUIDE.md)**

This is your complete guide to getting started with the VectorQA Sage project.

## 📚 What You'll Find

- **Complete beginner's guide** with step-by-step instructions
- **Security best practices** to keep you safe
- **Common problems and solutions**
- **Clear guidance** on when to ask for help

## 🛡️ Important Security Note

- ✅ **Safe**: Use the `deploy/` folder for examples and instructions
- ❌ **Dangerous**: Avoid the `environ_settings/` folder (contains real secrets)

## 🚀 Quick Start

1. **Read the guide**: [docs/getting-started/README_FOR_NEW_ENGINEERS.md](docs/getting-started/README_FOR_NEW_ENGINEERS.md)
2. **Follow the instructions** step by step
3. **Ask for help** when you need it

## 📞 Need Help?

- **Your team leader** - For most questions
- **DevOps team** - For server and deployment issues
- **Security team** - For password and access issues

**Remember**: It's better to ask for help than to make a mistake!

---

**Good luck!** 🎉
