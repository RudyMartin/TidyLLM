# Database Connection Manager

## Overview

The Database Connection Manager (`src/backend/core/database_connection_manager.py`) is a centralized system for managing all database connections and operations in the application. It provides connection pooling, automatic connection management, error handling, and environment-specific configuration.

## Key Features

### 1. **Connection Pooling**
- Efficient reuse of database connections
- Configurable pool size (default: 5 connections)
- Automatic connection lifecycle management
- Prevents connection leaks and improves performance

### 2. **Environment-Aware Configuration**
- Automatically detects environment from `DATABASE_URL`
- Supports multiple environments (local, staging, production)
- Environment-specific connection parameters
- Secure credential management

### 3. **Automatic Connection Management**
- Context managers for safe connection handling
- Automatic commit/rollback on success/failure
- Connection cleanup and return to pool
- Exception handling with proper cleanup

### 4. **Extension Management**
- Automatic pgvector extension setup
- Support for other PostgreSQL extensions
- Extension availability checking
- Graceful handling of missing extensions

### 5. **Error Handling and Retry Logic**
- Automatic retry for transient failures
- Circuit breaker pattern for persistent failures
- Detailed error logging and reporting
- Graceful degradation when database is unavailable

## Architecture

### Core Components

#### 1. **DatabaseConnectionManager Class**
```python
class DatabaseConnectionManager:
    def __init__(self, database_url: Optional[str] = None, pool_size: int = 5):
        self.database_url = database_url or os.getenv('DATABASE_URL')
        self.pool_size = pool_size
        self.connection_pool = None
        self._initialize_pool()
```

**Responsibilities**:
- Initialize connection pool
- Manage pool lifecycle
- Provide connection access methods
- Handle configuration and environment setup

#### 2. **Global Instance Management**
```python
# Global instance for easy access
_db_manager = None

def get_database_manager() -> DatabaseConnectionManager:
    """Get the global database connection manager instance"""
    global _db_manager
    if _db_manager is None:
        _db_manager = DatabaseConnectionManager()
    return _db_manager
```

**Benefits**:
- Singleton pattern ensures single pool instance
- Lazy initialization
- Thread-safe access
- Memory efficient

#### 3. **Context Manager Support**
```python
@contextmanager
def get_cursor(self, cursor_factory=None):
    """Get a cursor with automatic connection management"""
    conn = None
    try:
        conn = self.get_connection()
        cursor = conn.cursor(cursor_factory=cursor_factory or RealDictCursor)
        yield cursor
        conn.commit()
    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if conn:
            self.return_connection(conn)
```

**Features**:
- Automatic transaction management
- Exception handling with rollback
- Connection cleanup in finally block
- Support for custom cursor factories

## Usage Patterns

### 1. **Basic Query Execution**
```python
from backend.core.database_connection_manager import get_database_manager

# Get manager instance
db_manager = get_database_manager()

# Execute a simple query
results = db_manager.execute_query("SELECT * FROM documents WHERE status = %s", ('active',))
```

### 2. **Using Context Manager**
```python
# Use context manager for complex operations
with db_manager.get_cursor() as cursor:
    cursor.execute("""
        INSERT INTO documents (title, content, created_at)
        VALUES (%s, %s, %s)
    """, ('Document Title', 'Content here', datetime.now()))
    
    # Automatic commit on success, rollback on exception
```

### 3. **Custom Cursor Factory**
```python
# Use RealDictCursor for dictionary results
with db_manager.get_cursor(cursor_factory=RealDictCursor) as cursor:
    cursor.execute("SELECT * FROM documents")
    results = cursor.fetchall()
    # results is a list of dictionaries
    for row in results:
        print(f"Title: {row['title']}, Content: {row['content']}")
```

### 4. **Extension Management**
```python
# Ensure pgvector extension is available
success = db_manager.ensure_extension("vector")
if success:
    print("pgvector extension is ready")
else:
    print("Failed to setup pgvector extension")
```

### 5. **Connection Testing**
```python
# Test if database is accessible
if db_manager.test_connection():
    print("Database connection is working")
else:
    print("Database connection failed")
```

## Configuration

### Environment Variables

#### Required
- `DATABASE_URL`: PostgreSQL connection string
  ```
  postgresql://username:password@host:port/database
  ```

#### Optional
- `DB_POOL_SIZE`: Connection pool size (default: 5)
- `DB_CONNECT_TIMEOUT`: Connection timeout in seconds
- `DB_READ_TIMEOUT`: Read timeout in seconds
- `DB_WRITE_TIMEOUT`: Write timeout in seconds

### Environment-Specific Configuration

#### Local Development
```bash
export DATABASE_URL="postgresql://localhost:5432/myapp_dev"
export DB_POOL_SIZE=3
```

#### Staging Environment
```bash
export DATABASE_URL="postgresql://staging-db.example.com:5432/myapp_staging"
export DB_POOL_SIZE=10
export DB_CONNECT_TIMEOUT=30
```

#### Production Environment
```bash
export DATABASE_URL="postgresql://prod-db.example.com:5432/myapp_prod"
export DB_POOL_SIZE=20
export DB_CONNECT_TIMEOUT=60
export DB_READ_TIMEOUT=30
export DB_WRITE_TIMEOUT=30
```

## Error Handling

### 1. **Connection Failures**
```python
try:
    with db_manager.get_cursor() as cursor:
        cursor.execute("SELECT * FROM documents")
except RuntimeError as e:
    # Database connection pool not initialized
    logger.error(f"Database not available: {e}")
except psycopg2.OperationalError as e:
    # Connection failed
    logger.error(f"Database connection failed: {e}")
except Exception as e:
    # Other database errors
    logger.error(f"Database error: {e}")
```

### 2. **Graceful Degradation**
```python
def get_documents():
    try:
        db_manager = get_database_manager()
        if db_manager.test_connection():
            return db_manager.execute_query("SELECT * FROM documents")
        else:
            logger.warning("Database unavailable, using fallback")
            return get_documents_from_cache()
    except Exception as e:
        logger.error(f"Database error: {e}")
        return get_documents_from_cache()
```

## Performance Considerations

### 1. **Connection Pool Sizing**
- **Small applications**: 3-5 connections
- **Medium applications**: 10-20 connections
- **Large applications**: 20-50 connections
- **High-traffic applications**: 50+ connections

### 2. **Query Optimization**
```python
# Good: Use parameterized queries
results = db_manager.execute_query(
    "SELECT * FROM documents WHERE category = %s AND status = %s",
    ('research', 'active')
)

# Bad: String concatenation (SQL injection risk)
results = db_manager.execute_query(
    f"SELECT * FROM documents WHERE category = '{category}'"
)
```

### 3. **Batch Operations**
```python
# Efficient batch insert
with db_manager.get_cursor() as cursor:
    cursor.executemany(
        "INSERT INTO documents (title, content) VALUES (%s, %s)",
        [('Doc 1', 'Content 1'), ('Doc 2', 'Content 2')]
    )
```

## Security Features

### 1. **Credential Management**
- Environment variable-based configuration
- No hardcoded credentials in code
- Secure credential rotation support

### 2. **SQL Injection Prevention**
- Parameterized queries only
- No string concatenation for SQL
- Input validation and sanitization

### 3. **Connection Security**
- SSL/TLS encryption support
- Connection string validation
- Access control and authentication

## Monitoring and Observability

### 1. **Connection Metrics**
```python
# Get connection pool status
pool_status = db_manager.get_pool_status()
print(f"Active connections: {pool_status['active']}")
print(f"Available connections: {pool_status['available']}")
print(f"Total connections: {pool_status['total']}")
```

### 2. **Performance Monitoring**
- Connection acquisition time
- Query execution time
- Pool utilization metrics
- Error rates and types

### 3. **Logging**
```python
import logging

# Database operations are automatically logged
logger = logging.getLogger(__name__)
logger.info("Database connection established")
logger.warning("Database connection pool exhausted")
logger.error("Database query failed")
```

## Integration with Other Systems

### 1. **MCP (Model Context Protocol) Integration**
The database connection manager is used throughout the MCP system for:
- Document storage and retrieval
- Embedding storage with pgvector
- Metadata management
- Experiment tracking

### 2. **RAG System Integration**
```python
# In RAG QA Orchestrator
class RAGQAOrchestrator:
    def __init__(self):
        self.db_manager = get_database_manager()
    
    def store_documents(self, documents):
        with self.db_manager.get_cursor() as cursor:
            # Store document metadata and chunks
            pass
```

### 3. **MLflow Integration**
```python
# Database backend for MLflow
mlflow_config = {
    'tracking_uri': 'postgresql://localhost:5432/mlflow',
    'registry_uri': 'postgresql://localhost:5432/mlflow'
}
```

## Best Practices

### 1. **Always Use the Manager**
```python
# Good
from backend.core.database_connection_manager import get_database_manager
db_manager = get_database_manager()

# Bad
import psycopg2
conn = psycopg2.connect("postgresql://...")
```

### 2. **Use Context Managers**
```python
# Good: Automatic cleanup
with db_manager.get_cursor() as cursor:
    cursor.execute("SELECT * FROM documents")

# Bad: Manual cleanup required
cursor = db_manager.get_connection().cursor()
try:
    cursor.execute("SELECT * FROM documents")
finally:
    cursor.close()
    db_manager.return_connection(conn)
```

### 3. **Handle Errors Gracefully**
```python
try:
    results = db_manager.execute_query("SELECT * FROM documents")
except Exception as e:
    logger.error(f"Database query failed: {e}")
    # Provide fallback or default behavior
    results = []
```

### 4. **Monitor Pool Usage**
```python
# Check pool health periodically
if db_manager.get_pool_status()['available'] == 0:
    logger.warning("Database connection pool exhausted")
```

## Troubleshooting

### Common Issues

#### 1. **Connection Pool Exhausted**
**Symptoms**: `RuntimeError: Database connection pool not initialized`
**Solutions**:
- Increase pool size
- Check for connection leaks
- Monitor connection usage

#### 2. **Connection Timeouts**
**Symptoms**: `psycopg2.OperationalError: connection timeout`
**Solutions**:
- Increase connection timeout
- Check network connectivity
- Verify database server status

#### 3. **Authentication Failures**
**Symptoms**: `psycopg2.OperationalError: authentication failed`
**Solutions**:
- Verify credentials in DATABASE_URL
- Check user permissions
- Ensure SSL configuration

### Debug Mode
```python
# Enable debug logging
import logging
logging.getLogger('backend.core.database_connection_manager').setLevel(logging.DEBUG)
```

## Future Enhancements

### 1. **Advanced Pooling**
- Dynamic pool sizing based on load
- Connection health checking
- Automatic pool rebalancing

### 2. **Read Replicas**
- Automatic read/write splitting
- Load balancing across replicas
- Failover support

### 3. **Query Optimization**
- Query plan analysis
- Automatic query optimization
- Performance recommendations

### 4. **Advanced Monitoring**
- Real-time performance metrics
- Predictive scaling
- Automated alerting

## Conclusion

The Database Connection Manager provides a robust, secure, and efficient way to manage database connections in the application. By centralizing all database operations, it ensures:

- **Consistency** across the application
- **Security** through proper credential management
- **Performance** through connection pooling
- **Reliability** through error handling and retry logic
- **Observability** through comprehensive logging and monitoring

This centralized approach is essential for building scalable, maintainable applications that can handle production workloads reliably.
