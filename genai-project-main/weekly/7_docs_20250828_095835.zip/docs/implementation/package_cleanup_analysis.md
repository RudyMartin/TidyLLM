# 🧹 Package Cleanup Analysis for VectorQA Sage

## 🚨 **CRITICAL: Packages to Uninstall**

### **1. Duplicate PDF Libraries** ✅ SAFE
You have both `PyPDF2` and `pypdf` installed:

```bash
# Remove the older PyPDF2 (keep pypdf which is the newer version)
pip uninstall PyPDF2 -y
```

**Why**: `pypdf` is the newer, maintained version of PyPDF2. Having both can cause confusion and potential conflicts.

### **2. Database/ORM Packages (Not Used)** ✅ SAFE
```bash
# Remove SQLAlchemy and related packages
pip uninstall SQLAlchemy psycopg2-binary alembic greenlet -y
```

**Why**: Your application doesn't use databases. These are likely installed as dependencies of other packages but not directly used.

### **3. Web Framework Packages (Not Used)** ✅ SAFE
```bash
# Remove FastAPI and related packages
pip uninstall fastapi uvicorn starlette h11 -y
```

**Why**: Your app uses Streamlit, not FastAPI. These are unnecessary.

### **4. Git/Version Control Packages (Not Used)** ✅ SAFE
```bash
# Remove Git-related packages
pip uninstall GitPython gitdb smmap -y
```

**Why**: Not used in your application logic.

### **5. Optimization/ML Packages (Not Used)** ✅ SAFE
```bash
# Remove optimization packages
pip uninstall optuna narwhals -y
```

**Why**: Not used in your VectorQA Sage application.

### **6. Additional Unused Packages** ✅ SAFE
```bash
# Remove other unused packages
pip uninstall aiohappyeyeballs aiohttp aiosignal frozenlist multidict yarl -y
pip uninstall magicattr propcache -y
pip uninstall jiter -y
```

## ⚠️ **PACKAGES TO KEEP (Required Dependencies)**

### **❌ DO NOT REMOVE: datasets**
**Why**: DSPy actually depends on the `datasets` package. Removing it breaks the application.

**Evidence**: When we tried to remove `datasets`, we got:
```
dspy 2.5.26 requires datasets, which is not installed.
ModuleNotFoundError: No module named 'datasets'
```

**Solution**: Keep `datasets` but accept the version conflicts. The application works despite the conflicts.

## 📊 **PACKAGE USAGE ANALYSIS**

### **✅ ACTUALLY USED PACKAGES**
Based on your codebase analysis:

**Core Application:**
- `streamlit` - Web framework
- `dspy` - LLM framework (requires datasets)
- `litellm` - LLM interface
- `boto3` - AWS services
- `pandas` - Data processing
- `numpy` - Numerical computing
- `matplotlib` - Plotting
- `seaborn` - Statistical plotting
- `scikit-learn` - ML metrics
- `sentence-transformers` - Embeddings
- `torch` - PyTorch (dependency)
- `transformers` - Hugging Face (dependency)
- `datasets` - Required by DSPy

**File Processing:**
- `openpyxl` - Excel files
- `pypdf` - PDF processing
- `python-docx` - Word documents
- `fpdf` - PDF generation
- `PyPDF2` - (duplicate, should remove)

**Testing:**
- `pytest` - Testing framework
- `pytest-cov` - Coverage
- `pytest-mock` - Mocking

**Utilities:**
- `requests` - HTTP requests
- `pydantic` - Data validation
- `python-dotenv` - Environment variables
- `tqdm` - Progress bars
- `nltk` - Natural language processing

### **❌ SAFE TO REMOVE PACKAGES**
- `PyPDF2` - Duplicate of pypdf
- `SQLAlchemy` - Database ORM
- `fastapi` - Web framework
- `GitPython` - Git integration
- `optuna` - Hyperparameter optimization
- `narwhals` - ML optimization
- Various async/HTTP libraries

## 🚀 **UPDATED CLEANUP COMMANDS**

### **Phase 1: Remove Duplicates** ✅ SAFE
```bash
pip uninstall PyPDF2 -y
```

### **Phase 2: Remove Unused Major Packages** ✅ SAFE
```bash
pip uninstall SQLAlchemy psycopg2-binary alembic greenlet -y
pip uninstall fastapi uvicorn starlette h11 -y
pip uninstall GitPython gitdb smmap -y
pip uninstall optuna narwhals -y
```

### **Phase 3: Remove Unused Utilities** ✅ SAFE
```bash
pip uninstall aiohappyeyeballs aiohttp aiosignal frozenlist multidict yarl -y
pip uninstall magicattr propcache jiter -y
```

### **Phase 4: Verify Cleanup**
```bash
python3 -m pip check
python3 run_tests.py --fast
```

## 📈 **EXPECTED BENEFITS**

### **After Cleanup:**
- ✅ **Smaller environment size**
- ✅ **Faster package installation**
- ✅ **Cleaner dependency tree**
- ✅ **Reduced security surface**
- ✅ **Better maintainability**
- ⚠️ **Some dependency conflicts may remain** (datasets vs dill/fsspec/multiprocess)

### **Estimated Space Savings:**
- **Before**: ~150 packages
- **After**: ~120 packages
- **Savings**: ~20% reduction

## 🛡️ **SAFETY MEASURES**

### **Before Running Cleanup:**
1. **Backup current environment:**
   ```bash
   pip freeze > requirements_before_cleanup.txt
   ```

2. **Test current state:**
   ```bash
   python3 run_tests.py --fast
   ```

### **After Each Phase:**
1. **Check for conflicts:**
   ```bash
   python3 -m pip check
   ```

2. **Run tests:**
   ```bash
   python3 run_tests.py --fast
   ```

3. **If tests fail, restore:**
   ```bash
   pip install -r requirements_before_cleanup.txt
   ```

## 🎯 **FINAL RECOMMENDATION**

**Start with Phase 1** (remove `PyPDF2` duplicate) as it's completely safe. Then proceed with the other phases one at a time, testing after each phase.

**Important**: Keep `datasets` package as it's required by DSPy. The version conflicts with `dill`, `fsspec`, and `multiprocess` are acceptable since the application works correctly.

The cleanup will make your environment cleaner while preserving all required functionality!
