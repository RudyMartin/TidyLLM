"""Documentation for implementation"""
