# 🔍 QA Categories Integration - Where Risk Categories Are Plugged In

## 🎯 Overview

The QA (Quality Assurance) categories in this system are the **four main risk categories** used throughout the risk management framework. These categories are integrated at multiple levels across the codebase to provide comprehensive risk analysis and management capabilities.

## 📋 The Four Core QA Categories

1. **Model Risk** - Machine learning model performance, validation, and governance
2. **Credit Risk** - Lending, default rates, portfolio concentration, and credit scoring
3. **Market Risk** - VaR models, volatility, liquidity, and market exposure
4. **Operational Risk** - System failures, processes, human error, and business continuity

## 🔧 Where Categories Are Defined and Integrated

### 1. **Core System Definitions**

#### A. SME Context Coordinator (`src/backend/mcp/coordinators/sme_context_coordinator.py`)
```python
# Lines 571-574: Base risk scores by category
category_risk_base = {
    "Model Risk": 6,
    "Credit Risk": 7,
    "Market Risk": 8,
    "Operational Risk": 5
}

# Lines 605-615: Category-specific logic
if ctx.expertise_area == "Model Risk":
    # Model risk specific processing
elif ctx.expertise_area == "Credit Risk":
    # Credit risk specific processing
elif ctx.expertise_area == "Market Risk":
    # Market risk specific processing
elif ctx.expertise_area == "Operational Risk":
    # Operational risk specific processing
```

#### B. Database Schema (`database/sme_context_test_queries.sql`)
```sql
-- Lines 9-84: MVR prompts for each category
INSERT INTO mvr_prompts (title, sequence_order, requirements) VALUES
('Model Risk', 1, 'INPUT CONSIDERATIONS: Model performance metrics...'),
('Credit Risk', 2, 'INPUT CONSIDERATIONS: Credit scoring model performance...'),
('Market Risk', 3, 'INPUT CONSIDERATIONS: VaR model accuracy...'),
('Operational Risk', 4, 'INPUT CONSIDERATIONS: System reliability metrics...');

-- Lines 116-123: SME expertise mapping
('SME_001', 'Dr. Sarah Johnson', 'Model Risk', 'initial', 'high'),
('SME_002', 'Michael Chen', 'Credit Risk', 'event-driven', 'critical'),
('SME_003', 'Dr. Emily Rodriguez', 'Market Risk', 'periodic', 'critical'),
('SME_004', 'James Wilson', 'Operational Risk', 'initial', 'medium');
```

### 2. **Test Scenarios and Demo Data**

#### A. Manual Test Scenarios (`manual_test_scenarios.py`)
```python
# Lines 66-94: Test scenario definitions
self.scenarios = {
    "1": {"name": "Model Performance Degradation", "risk_category": "Model Risk"},
    "2": {"name": "VaR Model Breach", "risk_category": "Market Risk"},
    "3": {"name": "Data Quality Issues", "risk_category": "Operational Risk"},
    "4": {"name": "Credit Portfolio Concentration", "risk_category": "Credit Risk"},
    "5": {"name": "Real-time Fraud Detection Failure", "risk_category": "Operational Risk"}
}
```

#### B. DSPy MCP Demo (`notebooks/10_dspy_mcp_demo.py`)
```python
# Lines 106-115: Risk events by category
self.risk_events = [
    {"id": 1, "category": "Model Risk", "event": "Model Performance Degradation"},
    {"id": 2, "category": "Model Risk", "event": "Data Drift Detection"},
    {"id": 3, "category": "Model Risk", "event": "Model Bias Identification"},
    {"id": 4, "category": "Credit Risk", "event": "Default Rate Increase"},
    {"id": 5, "category": "Credit Risk", "event": "Credit Score Model Failure"},
    {"id": 6, "category": "Market Risk", "event": "VaR Model Breach"},
    {"id": 7, "category": "Market Risk", "event": "Market Volatility Spike"},
    {"id": 8, "category": "Operational Risk", "event": "System Failure"},
    {"id": 9, "category": "Operational Risk", "event": "Data Breach"},
    {"id": 10, "category": "Operational Risk", "event": "Process Failure"}
]

# Lines 695-698: Category-specific accuracy scores
"Model Risk": 0.94,
"Credit Risk": 0.89,
"Market Risk": 0.91,
"Operational Risk": 0.93
```

#### C. Real AWS Demo (`notebooks/09_real_aws_dspy_demo.py`)
```python
# Lines 116-181: Comprehensive risk events by category
# Model Risk Events (1-15)
{"id": 1, "category": "Model Risk", "event": "Model Performance Degradation"},
{"id": 2, "category": "Model Risk", "event": "Data Drift Detection"},
# ... 13 more Model Risk events

# Credit Risk Events (16-30)
{"id": 16, "category": "Credit Risk", "event": "Default Rate Increase"},
{"id": 17, "category": "Credit Risk", "event": "Credit Score Model Failure"},
# ... 13 more Credit Risk events

# Market Risk Events (31-45)
{"id": 31, "category": "Market Risk", "event": "VaR Model Breach"},
{"id": 32, "category": "Market Risk", "event": "Market Volatility Spike"},
# ... 13 more Market Risk events

# Operational Risk Events (46-59)
{"id": 46, "category": "Operational Risk", "event": "System Failure"},
{"id": 47, "category": "Operational Risk", "event": "Data Breach"},
# ... 12 more Operational Risk events
```

### 3. **Performance Testing Integration**

#### A. Performance Tests (`notebooks/13_performance_test.py`, `notebooks/15_production_performance_test.py`)
```python
# Lines 56-68: Test scenarios by category
self.test_scenarios = [
    {"name": "Simple Risk Analysis", "event": "Model Performance Degradation", "category": "Model Risk"},
    {"name": "Complex Multi-Category Analysis", "event": "VaR Model Breach", "category": "Market Risk"},
    {"name": "High-Frequency Operation", "event": "Credit Portfolio Concentration", "category": "Credit Risk"}
]
```

### 4. **Cross-Category Analysis**

#### A. Category Relationships (`notebooks/09_real_aws_dspy_demo.py`)
```python
# Lines 463-466: Cross-category relationships
"Model Risk": ["Credit Risk", "Market Risk"],
"Credit Risk": ["Model Risk", "Operational Risk"],
"Market Risk": ["Model Risk", "Credit Risk"],
"Operational Risk": ["Model Risk", "Credit Risk"]
```

#### B. Category Keywords (`notebooks/09_real_aws_dspy_demo.py`)
```python
# Lines 567-570: Category-specific keywords for analysis
"Model Risk": ["model", "validation", "testing", "performance", "drift"],
"Credit Risk": ["credit", "default", "lending", "borrower", "collateral"],
"Market Risk": ["market", "volatility", "var", "liquidity", "correlation"],
"Operational Risk": ["operational", "system", "process", "human", "technology"]
```

### 5. **SME Context Integration**

#### A. SME Expertise Areas (`src/backend/mcp/coordinators/sme_context_coordinator.py`)
```python
# Lines 328-341: SME context definitions
SMEContext(
    sme_id="SME_001",
    sme_name="Dr. Sarah Johnson",
    expertise_area="Model Risk",
    focus_area="Model Risk",
    requirements="INPUT CONSIDERATIONS:\n- Model performance metrics\n- Data quality assessment..."
),
SMEContext(
    sme_id="SME_002", 
    sme_name="Michael Chen",
    expertise_area="Credit Risk",
    focus_area="Credit Risk",
    requirements="INPUT CONSIDERATIONS:\n- Credit scoring model performance\n- Default rate analysis..."
)
```

### 6. **Report Generation Integration**

#### A. PDF Report Generator (`generate_pdf_report.py`)
```python
# Lines 189-190: Category coverage in reports
"The analysis covers multiple risk scenarios including Model Risk, Market Risk, Credit Risk, and Operational Risk events."
```

#### B. Testing Guide (`TESTING_GUIDE.md`)
```markdown
# Lines 24-28: Test scenario table
| 1 | Model Performance Degradation | Model Risk | High |
| 2 | VaR Model Breach | Market Risk | Critical |
| 3 | Data Quality Issues | Operational Risk | Medium |
| 4 | Credit Portfolio Concentration | Credit Risk | High |
| 5 | Real-time Fraud Detection Failure | Operational Risk | Critical |
```

## 🔄 How Categories Flow Through the System

### 1. **Input Layer**
- **Test scenarios** define risk events by category
- **SME context** provides expertise by category
- **Database schema** stores category-specific prompts and requirements

### 2. **Processing Layer**
- **DSPy signatures** analyze events within category context
- **SME coordinator** applies category-specific logic
- **Cross-category analysis** identifies relationships between categories

### 3. **Output Layer**
- **Risk scores** are calculated with category-specific baselines
- **Recommendations** are generated based on category expertise
- **Reports** organize results by category for stakeholders

## 🎯 Category-Specific Features

### **Model Risk**
- **Focus:** ML model performance, validation, governance
- **Key Metrics:** Accuracy, precision, recall, F1-score
- **Common Events:** Performance degradation, data drift, bias detection
- **SME Expertise:** Dr. Sarah Johnson

### **Credit Risk**
- **Focus:** Lending, default rates, portfolio concentration
- **Key Metrics:** Default rates, credit scores, concentration ratios
- **Common Events:** Default rate increases, credit score failures
- **SME Expertise:** Michael Chen

### **Market Risk**
- **Focus:** VaR models, volatility, liquidity, market exposure
- **Key Metrics:** VaR breaches, volatility spikes, correlation changes
- **Common Events:** VaR model breaches, market volatility spikes
- **SME Expertise:** Dr. Emily Rodriguez

### **Operational Risk**
- **Focus:** System failures, processes, human error, business continuity
- **Key Metrics:** System reliability, process efficiency, error rates
- **Common Events:** System failures, data breaches, process failures
- **SME Expertise:** James Wilson

## 🔧 How to Add New Categories

### 1. **Update Core Definitions**
```python
# Add to category_risk_base in sme_context_coordinator.py
category_risk_base = {
    "Model Risk": 6,
    "Credit Risk": 7,
    "Market Risk": 8,
    "Operational Risk": 5,
    "New Category": 6  # Add new category
}
```

### 2. **Add Database Entries**
```sql
-- Add to mvr_prompts table
INSERT INTO mvr_prompts (title, sequence_order, requirements) VALUES
('New Category', 5, 'INPUT CONSIDERATIONS: ...');

-- Add SME expertise
INSERT INTO sme_context_mapping VALUES
('SME_005', 'New Expert', 'New Category', 'initial', 'medium');
```

### 3. **Update Test Scenarios**
```python
# Add to test scenarios in manual_test_scenarios.py
"6": {
    "name": "New Category Event",
    "risk_category": "New Category",
    "severity": "Medium"
}
```

### 4. **Add Category-Specific Logic**
```python
# Add to SME coordinator processing
elif ctx.expertise_area == "New Category":
    # New category specific processing
    recommendations.append("New category specific recommendation")
```

## 📊 Category Performance Metrics

### **Current Category Coverage**
- **Model Risk:** 15 specific events defined
- **Credit Risk:** 15 specific events defined  
- **Market Risk:** 15 specific events defined
- **Operational Risk:** 14 specific events defined

### **Category Accuracy Scores**
- **Model Risk:** 94% accuracy
- **Credit Risk:** 89% accuracy
- **Market Risk:** 91% accuracy
- **Operational Risk:** 93% accuracy

### **Category Risk Baselines**
- **Model Risk:** Base score 6/10
- **Credit Risk:** Base score 7/10
- **Market Risk:** Base score 8/10
- **Operational Risk:** Base score 5/10

---

*The QA categories are deeply integrated throughout the system, providing a comprehensive framework for risk analysis and management across all major risk types.*
