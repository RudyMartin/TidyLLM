# Project Folder Structure Guide

## 🎯 **Overview**

This document explains the purpose and contents of each folder in the S3-Native QA system project. Understanding this structure is crucial for development, deployment, and maintenance.

## 📁 **Root Directory Structure**

```
qaz_20250321/
├── 📄 Core Application Files
│   ├── simple_demo.py              # Main Streamlit demo application
│   ├── start_simple_demo.py        # Launcher for simple demo
│   ├── start_demo.py               # Launcher for advanced demo
│   ├── start_advanced.py           # Launcher for advanced features
│   ├── requirements*.txt           # Python dependencies
│   └── README*.md                  # Documentation files
│
├── 📁 Source Code
│   ├── src/                        # Main application source code
│   ├── scripts/                    # Utility and deployment scripts
│   └── tests/                      # Test suite
│
├── 📁 Data & Runtime
│   ├── data/                       # Runtime data, cache, experiments
│   ├── input/                      # Input documents and assets
│   ├── output/                     # Generated outputs
│   ├── logs/                       # Application logs
│   └── test_outputs/               # Test execution results
│
├── 📁 Configuration & Settings
│   ├── environ_settings/           # Environment configurations
│   ├── dev_configs/                # Development configurations
│   └── deploy/                     # Deployment configurations
│
├── 📁 Database & Infrastructure
│   ├── database/                   # Database schemas and scripts
│   └── migration_bundles/          # Deployment bundles
│
├── 📁 Documentation
│   ├── docs/                       # Comprehensive documentation
│   └── notebooks/                  # Jupyter notebooks
│
└── 📁 System & Maintenance
    ├── _archive/                   # Archived files
    ├── optional/                   # Optional components
    └── .venv/                      # Python virtual environment
```

---

## 📄 **Core Application Files**

### **`simple_demo.py`**
- **Purpose**: Main Streamlit demo application
- **Contents**: Complete QA system with document upload, processing, and chat interface
- **Usage**: Primary application for demonstrating system capabilities

### **`start_*.py` Files**
- **Purpose**: Application launchers for different environments
- **Contents**: 
  - `start_simple_demo.py` - Simple demo launcher
  - `start_demo.py` - Advanced demo launcher  
  - `start_advanced.py` - Full feature launcher
- **Usage**: Entry points for different deployment scenarios

### **`requirements*.txt` Files**
- **Purpose**: Python dependency specifications
- **Contents**:
  - `requirements.txt` - Core dependencies
  - `requirements_demo.txt` - Demo-specific dependencies
  - `requirements_rag.txt` - RAG system dependencies
- **Usage**: `pip install -r requirements.txt`

---

## 📁 **Source Code (`src/`)**

### **Main Application Code**
```
src/
├── main.py                         # Streamlit app entry point
├── backend/                        # Backend services and core logic
│   ├── core/                       # Core system components
│   ├── llm/                        # LLM gateway and integration
│   ├── mcp/                        # Model Context Protocol
│   └── processing/                 # Document processing workers
├── static/                         # Web application static assets
└── assets/                         # Report generation assets
    ├── prompts/                    # QA prompt templates
    └── *.tex                       # LaTeX report templates
```

### **Key Components**:
- **`backend/core/`**: Core system components, MLflow configuration
- **`backend/llm/`**: Unified LLM Gateway, enhanced agents
- **`backend/mcp/`**: Orchestrators and processing pipelines
- **`backend/processing/`**: Document processing workers (TOC, Bibliography, etc.)
- **`assets/`**: Templates for report generation and QA prompts

---

## 📁 **Data & Runtime Folders**

### **`data/` - Runtime Data**
```
data/
├── cache/                          # Temporary cache files
│   ├── llm/                        # LLM response caches
│   └── mlflow/                     # MLflow export data
├── input/                          # Input documents for processing
├── output/                         # Generated outputs
│   ├── reports/                    # QA reports and analysis
│   ├── artifacts/                  # Report artifacts
│   └── test_results/               # Test execution results
├── experiments/                    # Experiment tracking
│   ├── mlruns/                     # MLflow experiment data
│   └── document_outputs/           # Document processing outputs
├── logs/                           # Application logs
├── cycles/                         # Processing cycles data
└── tests/                          # Test data
```

**Characteristics**:
- **Safe to clean up** - Entire directory is in `.gitignore`
- **No secrets** - Contains no credentials or sensitive data
- **Runtime data** - Generated during application execution
- **Large size** - Can contain GB of cache and experiment data

### **`input/` - Input Assets**
```
input/
├── *.pdf                           # Demo documents
└── omnibus/                        # Large collection of demo files
    ├── all/                        # All demo documents
    ├── reviews/                    # Review documents
    ├── wfc/                        # WFC-specific documents
    └── *.pdf                       # Individual demo files
```

**Purpose**: Documents for testing and demonstration
**Size**: Can be very large (100MB+ for omnibus collection)
**Deployment**: Filtered for deployment packages

### **`output/` - Generated Outputs**
```
output/
├── reports/                        # Generated QA reports
├── artifacts/                      # Report artifacts
└── test_results/                   # Test execution results
```

**Purpose**: Application outputs and generated content
**Deployment**: Excluded from deployment packages

---

## 📁 **Configuration & Settings**

### **`environ_settings/` - Environment Configuration**
```
environ_settings/
├── config.local.yaml               # Local environment config
├── config.staging.yaml             # Staging environment config
├── config.production.yaml          # Production environment config
├── place_settings_here.txt         # Settings template
├── unpack_environ.py               # Environment setup script
└── create_gitignore.py             # Git ignore generator
```

**Purpose**: Environment-specific configurations
**Contents**: Database connections, MLflow settings, API keys
**Deployment**: Included in credentials package

### **`dev_configs/` - Development Configurations**
```
dev_configs/
├── qa_criteria_simplified.yaml     # Simplified QA criteria
└── qa_criteria_full.yaml           # Full QA criteria
```

**Purpose**: Development and testing configurations
**Contents**: QA criteria, testing parameters
**Deployment**: Included in credentials package

### **`deploy/` - Deployment Configurations**
```
deploy/
├── deployment_guides/              # Deployment documentation
├── scripts/                        # Deployment scripts
└── configs/                        # Deployment configurations
```

**Purpose**: Deployment-specific configurations and guides
**Contents**: AWS configs, Docker files, deployment scripts

---

## 📁 **Database & Infrastructure**

### **`database/` - Database Schemas and Scripts**
```
database/
├── infra/                          # Infrastructure scripts
│   ├── 01_extensions.sql           # PostgreSQL extensions
│   ├── 02_review_system.sql        # Review system tables
│   ├── 03_embeddings_system.sql    # Embeddings and vectors
│   ├── 04_event_tracking.sql       # Event tracking tables
│   └── 05_mlflow_integration.sql   # MLflow integration tables
└── prod_scripts/                   # Production scripts
    └── 00_complete_setup.sql       # Complete setup wrapper
```

**Purpose**: Database schema and migration scripts
**Contents**: SQL scripts for PostgreSQL with pgvector
**Deployment**: Separate package for database setup

---

## 📦 **Migration Bundles (`migration_bundles/`)**

### **What Are Migration Bundles?**

Migration bundles are **self-contained deployment packages** that contain everything needed to deploy the system to a specific environment. They are created for air-gapped or restricted environments where git access is not available.

### **Bundle Structure**
```
migration_bundles/
├── production_ready_bundle/        # Production deployment bundle
│   ├── src/                        # Application source code
│   ├── database/                   # Database scripts
│   ├── config/                     # Configuration files
│   ├── scripts/                    # Deployment scripts
│   ├── launchers/                  # Application launchers
│   ├── validation/                 # Validation scripts
│   ├── docs/                       # Documentation
│   └── requirements*.txt           # Dependencies
└── test_bundle_fixed/              # Test deployment bundle
    ├── bundle_manifest.json        # Bundle contents manifest
    ├── deployment_config.json      # Deployment configuration
    ├── health_config.json          # Health check configuration
    ├── DEPLOYMENT_GUIDE.md         # Deployment instructions
    └── [same structure as above]
```

### **Bundle Contents**

#### **Application Files**
- **`src/`**: Complete application source code
- **`requirements*.txt`**: Python dependencies
- **`README.md`**: Application documentation

#### **Configuration**
- **`deployment_config.json`**: Deployment-specific settings
- **`health_config.json`**: Health check configuration
- **`config/`**: Environment configurations

#### **Scripts**
- **`scripts/deploy.py`**: Deployment automation
- **`scripts/setup_environment.py`**: Environment setup
- **`scripts/health_check.py`**: Health monitoring
- **`scripts/validate_config.py`**: Configuration validation

#### **Launchers**
- **`launchers/launch.py`**: Main launcher
- **`launchers/launch_*.py`**: Environment-specific launchers

#### **Documentation**
- **`DEPLOYMENT_GUIDE.md`**: Step-by-step deployment instructions
- **`bundle_manifest.json`**: Complete inventory of bundle contents

### **Bundle Manifest Example**
```json
{
  "bundle_name": "test_bundle_fixed",
  "target_environment": "staging",
  "version": "1.0.0",
  "contents": {
    "application_files": ["src/", "requirements*.txt"],
    "configuration": ["deployment_config.json", "health_config.json"],
    "scripts": ["scripts/deploy.py", "scripts/setup_environment.py"],
    "launchers": ["launchers/launch.py", "launchers/launch_staging.py"]
  }
}
```

### **When to Use Migration Bundles**

1. **Air-gapped environments** - No internet access
2. **Restricted networks** - No git access
3. **Production deployments** - Controlled, versioned releases
4. **Client deployments** - Self-contained packages
5. **Testing environments** - Isolated testing

### **Bundle vs Manual Packer**

| Feature | Migration Bundles | Manual Packer |
|---------|------------------|---------------|
| **Purpose** | Pre-built deployment packages | On-demand packaging |
| **Contents** | Complete, tested system | Current development state |
| **Versioning** | Versioned releases | Timestamp-based |
| **Testing** | Pre-tested and validated | Current state |
| **Use Case** | Production deployments | Development/testing |

---

## 📁 **Documentation (`docs/`)**

### **Organized Documentation Structure**
```
docs/
├── README.md                       # Main documentation index
├── WHAT_IS_THIS_SYSTEM.md         # System overview
├── NEW_GUY_S3_QA_GUIDE.md         # New team member guide
├── planning/                       # Strategic planning documents
├── architecture/                   # System architecture
├── technical/                      # Technical implementation
├── demo/                           # Demo applications & tests
├── deploy/                         # Deployment guides
├── maintenance/                    # Maintenance documentation
├── mlflow/                         # MLflow integration
├── processing-content/             # Document processing
├── llm-gateway/                    # LLM Gateway system
└── database/                       # Database documentation
```

---

## 📁 **System & Maintenance**

### **`_archive/` - Archived Files**
- **Purpose**: Old versions and deprecated files
- **Contents**: Previous implementations, old documentation
- **Deployment**: Excluded from deployment packages

### **`optional/` - Optional Components**
- **Purpose**: Non-essential components
- **Contents**: Additional features, experimental code
- **Deployment**: Excluded unless specifically requested

### **`.venv/` - Python Virtual Environment**
- **Purpose**: Python dependencies and environment
- **Contents**: Installed packages, Python interpreter
- **Deployment**: Excluded (recreated on target)

---

## 🎯 **Deployment Package Organization**

### **Manual Packer Creates 4 Packages for Air-Gapped Installation**:

#### **1. `database_schemas_YYYYMMDD_HHMMSS.zip`**
```
📦 Database Schemas Package
├── database/
│   ├── infra/
│   │   ├── 01_extensions.sql           # PostgreSQL extensions
│   │   ├── 02_review_system.sql        # Review system tables
│   │   ├── 03_embeddings_system.sql    # Embeddings and vectors
│   │   ├── 04_event_tracking.sql       # Event tracking tables
│   │   └── 05_mlflow_integration.sql   # MLflow integration tables
│   └── prod_scripts/
│       └── 00_complete_setup.sql       # Complete setup wrapper
```
**Purpose**: Database setup and migration
**Deployment**: Run SQL scripts to set up PostgreSQL with pgvector

#### **2. `credentials_config_YYYYMMDD_HHMMSS.zip`**
```
📦 Credentials & Config Package
├── environ_settings/
│   ├── config.local.yaml               # Local environment config
│   ├── config.staging.yaml             # Staging environment config
│   ├── config.production.yaml          # Production environment config
│   ├── place_settings_here.txt         # Settings template
│   ├── unpack_environ.py               # Environment setup script
│   └── create_gitignore.py             # Git ignore generator
└── dev_configs/
    ├── qa_criteria_simplified.yaml     # Simplified QA criteria
    └── qa_criteria_full.yaml           # Full QA criteria
```
**Purpose**: Environment setup and configuration
**Deployment**: Configure database connections, MLflow settings, API keys

#### **3. `input_assets_YYYYMMDD_HHMMSS.zip`**
```
📦 Input Assets Package
├── input/
│   ├── *.pdf                           # Demo documents (filtered)
│   └── omnibus/                        # Selected demo files only
│       ├── Readme Rag Demo.pdf         # Essential demo files
│       ├── Robot Presentation.pdf      # (when --include-demos)
│       ├── Smart Fruit Ripeness System.pdf
│       └── helper_functions.txt
```
**Purpose**: Demo and testing assets
**Deployment**: Documents for testing and demonstration
**Filtering**: Excludes large omnibus collections unless `--include-demos`

#### **4. `core_application_YYYYMMDD_HHMMSS.zip`**
```
📦 Core Application Package
├── src/
│   ├── main.py                         # Streamlit app entry point
│   ├── backend/                        # Backend services and core logic
│   │   ├── core/                       # Core system components
│   │   ├── llm/                        # LLM gateway and integration
│   │   ├── mcp/                        # Model Context Protocol
│   │   └── processing/                 # Document processing workers
│   ├── static/                         # Web application static assets
│   └── assets/                         # Report generation assets
│       ├── prompts/                    # QA prompt templates
│       └── *.tex                       # LaTeX report templates
├── scripts/
│   ├── pack_files.py                   # Manual packer script
│   ├── unpack_and_deploy.py            # Deployment script
│   └── [other utility scripts]
├── docs/
│   ├── README.md                       # Main documentation index
│   ├── WHAT_IS_THIS_SYSTEM.md         # System overview
│   ├── NEW_GUY_S3_QA_GUIDE.md         # New team member guide
│   ├── planning/                       # Strategic planning documents
│   ├── architecture/                   # System architecture
│   ├── technical/                      # Technical implementation
│   ├── demo/                           # Demo applications & tests
│   ├── deploy/                         # Deployment guides
│   ├── maintenance/                    # Maintenance documentation
│   ├── mlflow/                         # MLflow integration
│   ├── processing-content/             # Document processing
│   ├── llm-gateway/                    # LLM Gateway system
│   └── database/                       # Database documentation
├── simple_demo.py                      # Main Streamlit demo
├── start_simple_demo.py                # Simple demo launcher
├── start_demo.py                       # Advanced demo launcher
├── start_advanced.py                   # Full feature launcher
├── requirements.txt                    # Core dependencies
├── requirements_demo.txt               # Demo-specific dependencies
├── requirements_rag.txt                # RAG system dependencies
├── README.md                           # Project README
├── README_SIMPLE_DEMO.md               # Demo README
└── IMPORTANT_START_HERE.md             # Getting started guide
```
**Purpose**: Core application functionality
**Deployment**: Complete application with source code and documentation

### **Excluded from Deployment**:
- `data/` - Runtime data (regenerated)
- `output/` - Generated outputs (regenerated)
- `logs/` - Application logs (regenerated)
- `_archive/` - Archived files (not needed)
- `optional/` - Optional components (not essential)
- `.venv/` - Virtual environment (recreated)

---

## 🔧 **Folder Management Best Practices**

### **For Development**:
- Keep `data/` clean by running cleanup scripts
- Use `input/` for testing documents
- Store experiments in `data/experiments/`
- Use `logs/` for debugging

### **For Deployment**:
- Use migration bundles for production
- Use manual packer for development/testing
- Always exclude runtime data folders
- Include essential configuration files

### **For Maintenance**:
- Regular cleanup of `data/cache/`
- Archive old experiments in `data/experiments/`
- Rotate log files in `logs/`
- Update migration bundles for releases

---

**This folder structure supports both development flexibility and production deployment reliability!** 🚀
