
  All MCP workers inherit from BaseWorker and follow the same pattern:

  1. Input Format: All workers expect an MCPMessage object with:
  MCPMessage(
      task_type=TaskType.CLASSIFICATION,  # or other types
      priority=Priority.NORMAL,
      task_data={...},  # Worker-specific data
      # ... other standard fields
  )
  2. Standard Methods:
    - process_task(message: MCPMessage) -> Dict[str, Any] - Core processing
    - execute(message: MCPMessage) -> MCPMessage - Full execution with audit trail
  3. Common Features:
    - Audit Trail: All workers automatically track performance metrics
    - Error Handling: Standardized exception management
    - Logging: Consistent logging across all workers

  🔧 Worker-Specific Variations

  While the interface is standardized, workers differ in:

  1. Task Data Requirements:
    - FileClassificationWorker: Expects file_path, file_name, file_content
    - TOCExtractorWorker: Expects document path and extraction parameters
    - BibliographyBuilderWorker: Expects document content for citation extraction
    - ImageProcessingWorker: Expects image data and processing mode
  2. Processing Modes:
    - All workers support 3 complexity modes: SIMPLE, ENHANCED, ADVANCED
    - Each mode provides different levels of processing sophistication
  3. Return Data Structure:
    - All return Dict[str, Any] but with different keys/content
    - Classification: {'classification': '...', 'confidence_score': ...}
    - TOC: {'toc_structure': {...}, 'entries': [...]}
    - Bibliography: {'citations': [...], 'bibliography_structure': {...}}

  🔄 Unified Task Types

  The system supports these standardized task types:
  class TaskType(Enum):
      RETRIEVAL = "retrieval"
      ANALYSIS = "analysis"
      VALIDATION = "validation"
      CLASSIFICATION = "classification"  # Added for file classification
      DOCUMENT_PROCESSING = "document_processing"
      TEXT_PROCESSING = "text_processing"
      # ... more types

  📋 Summary

  Standard: Input message format, error handling, audit trail, performance metricsVariable:
  Task-specific data requirements, processing complexity modes, output structure

  For your Streamlit demo: You can use the same MCPMessage pattern for all workers, just change the
  task_type and task_data contents based on what each worker needs.