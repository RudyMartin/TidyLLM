# 📚 Complete User Guide - Simple RAG Demo

## 🎯 Overview

A comprehensive guide for using the Simple RAG Demo application. This guide covers everything from basic setup to advanced features and troubleshooting.

## 🚀 Quick Start

### One-Command Setup and Launch

```bash
python start_simple_demo.py
```

That's it! The launcher will:
1. ✅ Create a virtual environment automatically
2. ✅ Install all required dependencies
3. ✅ Launch the demo on port 8555
4. ✅ Open your browser to the application

## 📋 Features

- ✅ **Simple Interface**: Clean, easy-to-use design
- ✅ **Document Upload**: Support for PDF and TXT files (up to 5)
- ✅ **AI Chat**: Ask questions about your documents
- ✅ **ZLLM Gateway**: Powered by local AI models
- ✅ **No Technical Setup**: Everything is automated
- ✅ **Cross-Platform**: Works on Windows, Mac, and Linux
- ✅ **Advanced PDF Processing**: TOC extraction, bibliography parsing
- ✅ **Smart Chunking**: Intelligent document segmentation
- ✅ **Real-time Processing**: Live status updates

## 🎯 How to Use

### Step 1: Launch the Demo
```bash
python start_simple_demo.py
```

### Step 2: Upload Documents
- Click "Browse files" or drag and drop documents
- Select up to 5 PDF or TXT files
- Click "🔄 Process Documents"

### Step 3: Start Chatting
- Type your question in the chatbox
- Click "🚀 Send"
- Get AI-powered answers based on your documents

## 🔧 Advanced Options

### Custom Port
```bash
python start_simple_demo.py --port 8560
```

### Headless Mode (No Browser)
```bash
python start_simple_demo.py --headless
```

### Reinstall Dependencies
```bash
python start_simple_demo.py --reinstall
```

## 📁 File Structure

```
├── start_simple_demo.py          # Launcher (run this!)
├── simple_demo.py               # The demo application
├── simple_demo_env/             # Virtual environment (created automatically)
└── README_SIMPLE_DEMO.md        # Basic guide
```

## 🛠️ Technical Details

### Requirements (Installed Automatically)
- streamlit>=1.48.1
- PyPDF2>=3.0.0
- pdfplumber>=0.11.0 (advanced PDF processing)
- pypdfium2>=4.30.0 (image extraction)
- pypdf>=6.0.0 (modern PDF library)
- requests>=2.31.0
- pandas>=2.0.0
- numpy>=1.24.0

### Virtual Environment
- Created automatically at `simple_demo_env/`
- Isolated from your system Python
- All dependencies installed here

### ZLLM Gateway Integration
- Connects to local ZLLM gateway (default: http://localhost:11434)
- Falls back to simple responses if gateway unavailable
- Uses llama2 model by default

## 🚨 Troubleshooting

### "Python not found"
- Make sure Python 3.7+ is installed
- Download from: https://python.org

### "Permission denied"
- On Mac/Linux: `chmod +x start_simple_demo.py`
- On Windows: Right-click → "Run as administrator"

### "Port already in use"
- Use a different port: `python start_simple_demo.py --port 8560`
- Or close other applications using port 8555

### "Virtual environment creation failed"
- Make sure you have write permissions in the directory
- Try running with administrator privileges

### "ZLLM gateway not available"
- The demo will still work with simple responses
- To use ZLLM: Install and run ZLLM gateway on localhost:11434

## 🎉 Success Tips

1. **Start Simple**: Try with 1-2 documents first
2. **Use Clear Questions**: "What are the main topics?" works better than "Tell me everything"
3. **Check File Types**: Only PDF and TXT files are supported
4. **Be Patient**: Large documents take longer to process
5. **Clear Cache**: Use the "🗑️ Clear All Documents" button to start fresh

## 🔗 Related Files

- `start_demo.py` - More advanced demo launcher
- `start_advanced.py` - Full VectorQA Sage interface
- `docs/` - Detailed documentation

## 📞 Support

If you encounter issues:
1. Check the troubleshooting section above
2. Try the `--reinstall` flag
3. Check that Python 3.7+ is installed
4. Ensure you have internet connection for dependency installation

---

**Happy Document Chatting! 🤖📚**
