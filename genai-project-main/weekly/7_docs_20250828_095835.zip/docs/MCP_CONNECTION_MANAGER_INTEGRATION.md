# MCP Connection Manager Integration

## Overview

The Model Context Protocol (MCP) system in this project extensively uses the centralized Database Connection Manager for all database operations. This integration ensures consistent, secure, and efficient database access across all MCP components.

## MCP Architecture and Database Integration

### Directory Structure
```
src/backend/mcp/
├── orchestrators/           # High-level orchestration components
│   ├── rag_qa_orchestrator.py
│   ├── document_processing_orchestrator.py
│   └── ...
├── workers/                 # Specialized worker components
│   ├── document_workers.py
│   ├── live_context_worker.py
│   └── ...
├── protocol/               # MCP protocol definitions
│   ├── message_protocol.py
│   └── ...
└── ...
```

## Integration Patterns

### 1. **Orchestrator Level Integration**

#### RAG QA Orchestrator
**File**: `src/backend/mcp/orchestrators/rag_qa_orchestrator.py`

**Database Integration**:
```python
from ...core.database_connection_manager import get_database_manager

class RAGQAOrchestrator:
    def __init__(self, config_path: str = "config/qa_criteria_full.yaml"):
        # Initialize centralized database manager
        self.db_manager = get_database_manager()
        
        # Other initializations...
        self.embedding_helper = EmbeddingHelper(target_dimensions=1024)
        self.dspy_config = DSPyConfig(provider="openai")
    
    def _setup_database_connection(self):
        """Setup database connection using centralized manager"""
        try:
            # Use centralized database connection manager
            self.db_manager = get_database_manager()
            
            if self.db_manager.test_connection():
                logger.info("✅ Database connection established via centralized manager")
                # Ensure pgvector extension is available
                self.db_manager.ensure_extension("vector")
                self.db_connection = True  # Flag to indicate connection is available
            else:
                logger.warning("Database connection not available. Using local file storage only.")
                self.db_connection = None
                
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            self.db_connection = None
```

**Key Features**:
- **Centralized Connection Management**: Uses the global database manager instance
- **Extension Management**: Automatically ensures pgvector extension is available
- **Graceful Degradation**: Falls back to local storage if database is unavailable
- **Connection Testing**: Validates database connectivity before operations

#### Document Processing Orchestrator
**File**: `src/backend/mcp/orchestrators/document_processing_orchestrator.py`

**Database Integration**:
```python
def _store_document_metadata(self, document_data):
    """Store document metadata using centralized database manager"""
    try:
        with self.db_manager.get_cursor() as cursor:
            cursor.execute("""
                INSERT INTO document_metadata 
                (doc_id, title, doc_type, status, total_chunks, file_size_bytes, ingested_at)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                ON CONFLICT (doc_id) DO UPDATE SET
                last_processed = now()
            """, (
                document_data['doc_id'],
                document_data['title'],
                document_data['doc_type'],
                'processed',
                document_data['total_chunks'],
                document_data['file_size'],
                datetime.now()
            ))
            
        logger.info(f"Stored document metadata for {document_data['doc_id']}")
        
    except Exception as e:
        logger.error(f"Failed to store document metadata: {e}")
        raise
```

### 2. **Worker Level Integration**

#### Document Workers
**File**: `src/backend/mcp/workers/document_workers.py`

**Database Integration**:
```python
class EmbeddingGeneratorWorker(BaseWorker):
    """Worker for generating embeddings with database storage"""
    
    def __init__(self):
        super().__init__("embedding_generator", "embedding_processing")
        # Initialize centralized components
        self.embedding_helper = EmbeddingHelper(target_dimensions=1024)
        self.db_manager = get_database_manager()
    
    def process_task(self, message: MCPMessage) -> Dict[str, Any]:
        """Generate embeddings for text chunks with database storage"""
        payload = message.payload
        text_chunks = payload.get('text_chunks', [])
        
        if not text_chunks:
            return {
                'success': False,
                'confidence_score': 0.0,
                'error': 'No text chunks provided'
            }
        
        try:
            embeddings = []
            
            for i, chunk in enumerate(text_chunks):
                # Generate embedding using centralized helper
                embedding, metadata = self.embedding_helper.generate_embedding(
                    chunk['text'], 
                    f"chunk_{chunk.get('chunk_id', i)}"
                )
                embedding_dim = len(embedding)
                
                # Store in database if available
                if self.db_manager and self.db_manager.test_connection():
                    with self.db_manager.get_cursor() as cursor:
                        cursor.execute("""
                            UPDATE document_chunks 
                            SET embedding = %s, 
                                embedding_model = %s,
                                content_hash = %s
                            WHERE chunk_id = %s
                        """, (
                            embedding.tolist(),
                            metadata.model_name,
                            metadata.content_hash,
                            chunk.get('chunk_id', f'chunk_{i}')
                        ))
                
                embeddings.append({
                    'chunk_id': chunk.get('chunk_id', f'chunk_{i}'),
                    'embedding': embedding.tolist(),
                    'embedding_dim': embedding_dim,
                    'text_length': len(chunk['text'])
                })
            
            return {
                'success': True,
                'confidence_score': 0.95,
                'processing': {
                    'embeddings': embeddings,
                    'total_chunks': len(embeddings),
                    'embedding_dim': len(embeddings[0]['embedding']) if embeddings else 0
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'confidence_score': 0.0,
                'error': str(e)
            }
```

#### Live Context Worker
**File**: `src/backend/mcp/workers/live_context_worker.py`

**Database Integration**:
```python
class LiveContextWorker(BaseWorker):
    """Worker for managing live context with database persistence"""
    
    def __init__(self):
        super().__init__("live_context", "context_management")
        self.db_manager = get_database_manager()
    
    def store_context(self, context_data: Dict[str, Any]) -> bool:
        """Store context data using centralized database manager"""
        try:
            with self.db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO live_context 
                    (session_id, context_type, context_data, created_at, expires_at)
                    VALUES (%s, %s, %s, %s, %s)
                    ON CONFLICT (session_id, context_type) DO UPDATE SET
                    context_data = EXCLUDED.context_data,
                    updated_at = now(),
                    expires_at = EXCLUDED.expires_at
                """, (
                    context_data['session_id'],
                    context_data['context_type'],
                    json.dumps(context_data['context_data']),
                    datetime.now(),
                    context_data.get('expires_at', datetime.now() + timedelta(hours=1))
                ))
            
            logger.info(f"Stored context for session {context_data['session_id']}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to store context: {e}")
            return False
    
    def retrieve_context(self, session_id: str, context_type: str) -> Optional[Dict[str, Any]]:
        """Retrieve context data using centralized database manager"""
        try:
            with self.db_manager.get_cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute("""
                    SELECT context_data, created_at, expires_at
                    FROM live_context
                    WHERE session_id = %s AND context_type = %s AND expires_at > now()
                """, (session_id, context_type))
                
                result = cursor.fetchone()
                if result:
                    return {
                        'context_data': json.loads(result['context_data']),
                        'created_at': result['created_at'],
                        'expires_at': result['expires_at']
                    }
                return None
                
        except Exception as e:
            logger.error(f"Failed to retrieve context: {e}")
            return None
```

### 3. **Protocol Level Integration**

#### Message Protocol
**File**: `src/backend/mcp/protocol/message_protocol.py`

**Database Integration**:
```python
class MCPMessage:
    """MCP message with database persistence support"""
    
    def __init__(self, message_type: str, payload: Dict[str, Any], session_id: str = None):
        self.message_type = message_type
        self.payload = payload
        self.session_id = session_id or str(uuid.uuid4())
        self.timestamp = datetime.now()
        self.message_id = str(uuid.uuid4())
    
    def store_message(self, db_manager) -> bool:
        """Store message in database for audit trail"""
        try:
            with db_manager.get_cursor() as cursor:
                cursor.execute("""
                    INSERT INTO mcp_messages 
                    (message_id, session_id, message_type, payload, timestamp)
                    VALUES (%s, %s, %s, %s, %s)
                """, (
                    self.message_id,
                    self.session_id,
                    self.message_type,
                    json.dumps(self.payload),
                    self.timestamp
                ))
            
            logger.debug(f"Stored MCP message {self.message_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to store MCP message: {e}")
            return False
    
    @classmethod
    def retrieve_messages(cls, db_manager, session_id: str, limit: int = 100) -> List['MCPMessage']:
        """Retrieve messages for a session"""
        try:
            with db_manager.get_cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute("""
                    SELECT message_id, message_type, payload, timestamp
                    FROM mcp_messages
                    WHERE session_id = %s
                    ORDER BY timestamp DESC
                    LIMIT %s
                """, (session_id, limit))
                
                messages = []
                for row in cursor.fetchall():
                    message = cls(
                        message_type=row['message_type'],
                        payload=json.loads(row['payload']),
                        session_id=session_id
                    )
                    message.message_id = row['message_id']
                    message.timestamp = row['timestamp']
                    messages.append(message)
                
                return messages
                
        except Exception as e:
            logger.error(f"Failed to retrieve messages: {e}")
            return []
```

## Database Schema Integration

### Core Tables Used by MCP

#### 1. **Document Management**
```sql
-- Document metadata
CREATE TABLE document_metadata (
    doc_id VARCHAR(255) PRIMARY KEY,
    title TEXT NOT NULL,
    doc_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    total_chunks INTEGER NOT NULL,
    file_size_bytes BIGINT NOT NULL,
    ingested_at TIMESTAMP NOT NULL,
    last_processed TIMESTAMP,
    created_at TIMESTAMP DEFAULT now()
);

-- Document chunks with embeddings
CREATE TABLE document_chunks (
    doc_id VARCHAR(255) NOT NULL,
    chunk_id VARCHAR(255) NOT NULL,
    chunk_text TEXT NOT NULL,
    char_count INTEGER NOT NULL,
    embedding_model VARCHAR(100),
    embedding vector(1024),  -- pgvector extension
    content_hash VARCHAR(64),
    created_at TIMESTAMP DEFAULT now(),
    PRIMARY KEY (doc_id, chunk_id),
    FOREIGN KEY (doc_id) REFERENCES document_metadata(doc_id)
);
```

#### 2. **Live Context Management**
```sql
-- Live context storage
CREATE TABLE live_context (
    session_id VARCHAR(255) NOT NULL,
    context_type VARCHAR(100) NOT NULL,
    context_data JSONB NOT NULL,
    created_at TIMESTAMP DEFAULT now(),
    updated_at TIMESTAMP DEFAULT now(),
    expires_at TIMESTAMP NOT NULL,
    PRIMARY KEY (session_id, context_type)
);

-- MCP message audit trail
CREATE TABLE mcp_messages (
    message_id VARCHAR(255) PRIMARY KEY,
    session_id VARCHAR(255) NOT NULL,
    message_type VARCHAR(100) NOT NULL,
    payload JSONB NOT NULL,
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT now()
);
```

#### 3. **Experiment Tracking**
```sql
-- MLflow integration tables
CREATE TABLE mlflow_experiments (
    experiment_id VARCHAR(255) PRIMARY KEY,
    experiment_name VARCHAR(255) NOT NULL,
    tracking_uri TEXT,
    artifact_location TEXT,
    lifecycle_stage VARCHAR(50),
    created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE mlflow_runs (
    run_id VARCHAR(255) PRIMARY KEY,
    experiment_id VARCHAR(255) NOT NULL,
    run_name VARCHAR(255),
    status VARCHAR(50),
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    created_at TIMESTAMP DEFAULT now(),
    FOREIGN KEY (experiment_id) REFERENCES mlflow_experiments(experiment_id)
);
```

## Integration Benefits

### 1. **Consistent Database Access**
- All MCP components use the same connection manager
- Consistent error handling and retry logic
- Standardized logging and monitoring

### 2. **Performance Optimization**
- Connection pooling reduces overhead
- Efficient query patterns across components
- Optimized for pgvector operations

### 3. **Reliability and Fault Tolerance**
- Graceful degradation when database is unavailable
- Automatic retry mechanisms
- Circuit breaker patterns for persistent failures

### 4. **Security and Compliance**
- Centralized credential management
- Audit trails for all operations
- SQL injection prevention

### 5. **Monitoring and Observability**
- Centralized metrics collection
- Consistent logging patterns
- Performance monitoring across all components

## Best Practices for MCP Database Integration

### 1. **Always Use the Centralized Manager**
```python
# Good: Use centralized manager
from backend.core.database_connection_manager import get_database_manager
db_manager = get_database_manager()

# Bad: Direct database connection
import psycopg2
conn = psycopg2.connect("postgresql://...")
```

### 2. **Use Context Managers for Transactions**
```python
# Good: Automatic transaction management
with db_manager.get_cursor() as cursor:
    cursor.execute("INSERT INTO documents VALUES (%s, %s)", (title, content))
    # Automatic commit on success, rollback on exception

# Bad: Manual transaction management
cursor = db_manager.get_connection().cursor()
try:
    cursor.execute("INSERT INTO documents VALUES (%s, %s)", (title, content))
    cursor.connection.commit()
except:
    cursor.connection.rollback()
finally:
    cursor.close()
```

### 3. **Handle Database Unavailability Gracefully**
```python
def process_documents(documents):
    try:
        db_manager = get_database_manager()
        if db_manager.test_connection():
            # Use database storage
            store_in_database(documents)
        else:
            # Fallback to local storage
            store_locally(documents)
    except Exception as e:
        logger.error(f"Database operation failed: {e}")
        # Provide fallback behavior
        store_locally(documents)
```

### 4. **Use Parameterized Queries**
```python
# Good: Parameterized query
cursor.execute(
    "SELECT * FROM documents WHERE category = %s AND status = %s",
    (category, status)
)

# Bad: String concatenation (SQL injection risk)
cursor.execute(f"SELECT * FROM documents WHERE category = '{category}'")
```

### 5. **Monitor and Log Database Operations**
```python
import logging
logger = logging.getLogger(__name__)

def store_embedding(chunk_id, embedding):
    try:
        with db_manager.get_cursor() as cursor:
            cursor.execute(
                "UPDATE document_chunks SET embedding = %s WHERE chunk_id = %s",
                (embedding.tolist(), chunk_id)
            )
        logger.info(f"Stored embedding for chunk {chunk_id}")
    except Exception as e:
        logger.error(f"Failed to store embedding for chunk {chunk_id}: {e}")
        raise
```

## Troubleshooting MCP Database Issues

### Common Issues and Solutions

#### 1. **Connection Pool Exhaustion**
**Symptoms**: `RuntimeError: Database connection pool not initialized`
**Solutions**:
- Increase pool size in configuration
- Check for connection leaks in MCP workers
- Monitor connection usage patterns

#### 2. **pgvector Extension Issues**
**Symptoms**: `psycopg2.ProgrammingError: extension "vector" is not available`
**Solutions**:
- Ensure pgvector extension is installed in PostgreSQL
- Use `db_manager.ensure_extension("vector")` during initialization
- Check PostgreSQL version compatibility

#### 3. **Performance Issues with Large Documents**
**Symptoms**: Slow embedding storage or retrieval
**Solutions**:
- Use batch operations for multiple embeddings
- Optimize chunk sizes for better performance
- Consider indexing strategies for vector similarity search

#### 4. **Session Context Expiration**
**Symptoms**: Missing context data for active sessions
**Solutions**:
- Adjust expiration times based on usage patterns
- Implement context refresh mechanisms
- Monitor context storage and retrieval patterns

## Future Enhancements

### 1. **Advanced Vector Operations**
- Implement vector similarity search optimization
- Add support for multiple embedding models
- Implement vector clustering and classification

### 2. **Distributed Database Support**
- Support for read replicas
- Sharding strategies for large datasets
- Multi-region database deployment

### 3. **Advanced Caching**
- Redis integration for session context
- Embedding cache for frequently accessed vectors
- Query result caching for performance

### 4. **Enhanced Monitoring**
- Real-time performance metrics
- Predictive scaling based on usage patterns
- Automated alerting for database issues

## Conclusion

The MCP system's integration with the centralized Database Connection Manager provides a robust, scalable, and maintainable foundation for document processing, context management, and experiment tracking. This integration ensures:

- **Consistency** across all MCP components
- **Performance** through connection pooling and optimization
- **Reliability** through proper error handling and fallbacks
- **Security** through centralized credential management
- **Observability** through comprehensive logging and monitoring

This architectural approach is essential for building production-ready MCP systems that can handle complex document processing workflows reliably and efficiently.
