# BibliographyBuilderWorker How-To Guide

## Overview

The `BibliographyBuilderWorker` is a **unified, configurable worker** that provides progressive complexity for bibliography and citation extraction across three modes:
- **Simple**: Basic regex-based citation extraction
- **Enhanced**: Multi-format citation parsing (APA, MLA, IEEE, Chicago, Harvard, Vancouver)
- **Advanced**: AI-powered analysis, citation network analysis, bibliometric analysis

## Architecture

### Progressive Complexity Design
```
Simple Mode → Enhanced Mode → Advanced Mode
     ↓              ↓              ↓
Basic Regex → Multi-Format → AI/ML Analysis
```

### Extraction Methods
1. **Simple**: Basic regex patterns for citation detection
2. **Enhanced**: Multi-format citation parsing with enhanced metadata
3. **Advanced**: Enhanced + AI-powered semantic analysis and network analysis

## Usage

### Basic Usage

```python
from backend.mcp.workers.bibliography_builder_worker import BibliographyBuilderWorker, BibliographyMode

# Simple mode (default)
simple_worker = BibliographyBuilderWorker(BibliographyMode.SIMPLE)
result = simple_worker._extract_bibliography_simple({
    'content': document_content,
    'filename': 'document.txt'
})

# Enhanced mode
enhanced_worker = BibliographyBuilderWorker(BibliographyMode.ENHANCED)
result = enhanced_worker._extract_bibliography_enhanced({
    'content': document_content,
    'filename': 'document.txt'
})

# Advanced mode
advanced_worker = BibliographyBuilderWorker(BibliographyMode.ADVANCED)
result = advanced_worker._extract_bibliography_advanced({
    'content': document_content,
    'filename': 'document.txt'
})
```

### MCP Task Processing

```python
# The worker automatically handles different task types based on mode
message = MCPMessage(
    task_type=TaskType.BIBLIOGRAPHY_EXTRACTION,
    task_data={'content': '...', 'filename': 'doc.txt'}
)

# Simple mode: Basic extraction
simple_result = simple_worker.process_task(message)

# Enhanced mode: Multi-format parsing
enhanced_result = enhanced_worker.process_task(message)

# Advanced mode: AI-powered analysis
advanced_result = advanced_worker.process_task(message)
```

## Pattern Recognition

### Simple Patterns
- `^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+\((\d{4})\)\.\s+(.+?)\.\s+(.+?)(?:,\s+(\d+))?\.?$` - Author (Year). Title. Journal, Pages.
- `^(\d+)\.\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+\((\d{4})\)\.\s+(.+?)\.\s+(.+?)(?:,\s+(\d+))?\.?$` - 1. Author (Year). Title. Journal, Pages.
- `^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\.\s+(.+?)\.\s+(.+?)(?:,\s+(\d{4}))?\.?$` - Author. Title. Journal, Year.

### Enhanced Patterns
- **APA Style**: Author (Year). Title. Journal, Pages.
- **MLA Style**: Author. "Title" Journal, Year.
- **IEEE Style**: 1. Author (Year). Title. Journal, Pages.
- **Chicago Style**: Author (Year). Title. Journal, Pages.
- **Harvard Style**: Author (Year). Title. Journal, Pages.
- **Vancouver Style**: 1. Author (Year). Title. Journal, Pages.

### Advanced Patterns
- All enhanced patterns plus semantic patterns:
- DOI pattern: `^(.+?)\.\s+DOI:\s+(10\.\d{4,}/[^\s]+)\.?$`
- URL pattern: `^(.+?)\.\s+Retrieved from:\s+(https?://[^\s]+)\.?$`
- arXiv pattern: `^(.+?)\.\s+arXiv:(\d{4}\.\d{4,})\.?$`
- ISBN pattern: `^(.+?)\.\s+ISBN:\s+(\d{1,5}-\d{1,7}-\d{1,7}-\d{1,7})\.?$`

## Output Formats

### Simple Mode Output
```json
{
    "success": true,
    "bibliography_structure": {
        "document_id": "a1b2c3d4",
        "document_title": "Research Paper",
        "total_citations": 5,
        "citations": [
            {
                "citation_id": "smith_2020",
                "raw_text": "Smith, J. (2020). Machine Learning Applications. Journal of AI, 15(3), 245-260.",
                "authors": ["Smith, J."],
                "title": "Machine Learning Applications",
                "journal": "Journal of AI",
                "year": 2020,
                "doi": null,
                "url": null,
                "arxiv_id": null,
                "venue": null,
                "pages": "245-260",
                "volume": "15",
                "issue": "3",
                "publisher": null,
                "citation_type": "journal",
                "confidence_score": 0.6,
                "metadata": {
                    "pattern_used": "^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+\((\d{4})\)\.\s+(.+?)\.\s+(.+?)(?:,\s+(\d+))?\.?$"
                }
            }
        ],
        "extraction_method": "simple_regex",
        "confidence_score": 0.6,
        "reference_section_text": "References\n\n1. Smith, J. (2020)...",
        "metadata": {
            "mode": "simple",
            "patterns_used": 3
        },
        "created_at": "2024-01-15T10:30:00"
    },
    "extraction_method": "simple_regex",
    "confidence_score": 0.6,
    "total_citations": 5,
    "mode": "simple",
    "processed_at": "2024-01-15T10:30:00",
    "worker_name": "BibliographyBuilderWorker"
}
```

### Enhanced Mode Output
Enhanced output includes:
- **Semantic categorization** of citations
- **Quality assessment** for each citation
- **Completeness scoring** for citation data
- **Additional metadata** extraction (DOI, URL, arXiv ID)

```json
{
    "success": true,
    "bibliography_structure": {
        "document_id": "a1b2c3d4",
        "document_title": "Research Paper",
        "total_citations": 5,
        "citations": [
            {
                "citation_id": "smith_2020",
                "raw_text": "Smith, J. (2020). Machine Learning Applications. Journal of AI, 15(3), 245-260. DOI: 10.1234/ai.2020.001",
                "authors": ["Smith, J."],
                "title": "Machine Learning Applications",
                "journal": "Journal of AI",
                "year": 2020,
                "doi": "10.1234/ai.2020.001",
                "url": null,
                "arxiv_id": null,
                "venue": null,
                "pages": "245-260",
                "volume": "15",
                "issue": "3",
                "publisher": null,
                "citation_type": "journal",
                "confidence_score": 0.8,
                "metadata": {
                    "pattern_used": "^([A-Z][a-z]+(?:\s+[A-Z][a-z]+)*)\s+\((\d{4})\)\.\s+(.+?)\.\s+(.+?)(?:,\s+(\d+))?\.?$",
                    "enhanced": true,
                    "extraction_quality": 0.85,
                    "completeness_score": 0.9
                }
            }
        ],
        "extraction_method": "enhanced_regex",
        "confidence_score": 0.75,
        "reference_section_text": "References\n\n1. Smith, J. (2020)...",
        "metadata": {
            "mode": "enhanced",
            "patterns_used": 6,
            "enhancement_applied": true
        },
        "created_at": "2024-01-15T10:30:00"
    },
    "extraction_method": "enhanced_regex",
    "confidence_score": 0.75,
    "total_citations": 5,
    "mode": "enhanced",
    "processed_at": "2024-01-15T10:30:00",
    "worker_name": "BibliographyBuilderWorker"
}
```

### Advanced Mode Output
Advanced output includes enhanced features plus:
```json
{
    "advanced_features": {
        "ai_analysis": {
            "citation_network_analysis": {
                "network_density": 0.45,
                "central_authors": ["Smith, J.", "Johnson, A.", "Brown, M."],
                "citation_clusters": [
                    {
                        "name": "Core Theory",
                        "citations": 15
                    },
                    {
                        "name": "Applications",
                        "citations": 12
                    },
                    {
                        "name": "Methodology",
                        "citations": 8
                    }
                ],
                "network_metrics": {
                    "average_degree": 3.2,
                    "clustering_coefficient": 0.35,
                    "network_diameter": 4
                }
            },
            "topic_modeling": {
                "topics": [
                    {
                        "topic": "machine learning",
                        "weight": 0.3,
                        "citations": 8
                    },
                    {
                        "topic": "data analysis",
                        "weight": 0.25,
                        "citations": 6
                    },
                    {
                        "topic": "statistical methods",
                        "weight": 0.2,
                        "citations": 5
                    },
                    {
                        "topic": "optimization",
                        "weight": 0.15,
                        "citations": 4
                    }
                ],
                "topic_coherence": 0.72,
                "dominant_topics": ["machine learning", "data analysis"]
            },
            "impact_analysis": {
                "high_impact_citations": 12,
                "medium_impact_citations": 8,
                "low_impact_citations": 5,
                "impact_distribution": [0.48, 0.32, 0.20],
                "citation_impact_score": 0.75,
                "recommended_high_impact_sources": [
                    "Nature",
                    "Science",
                    "PNAS",
                    "Cell"
                ]
            },
            "bibliometric_analysis": {
                "total_citations": 25,
                "unique_authors": 18,
                "unique_journals": 12,
                "publication_years": {
                    "range": "2010-2024",
                    "most_recent": 2024,
                    "oldest": 2010,
                    "average_year": 2018.5
                },
                "citation_types": {
                    "journal_articles": 15,
                    "conference_papers": 6,
                    "books": 2,
                    "reports": 2
                },
                "geographic_distribution": {
                    "USA": 12,
                    "UK": 5,
                    "Germany": 3,
                    "China": 3,
                    "Others": 2
                }
            }
        },
        "ml_predictions": {
            "citation_quality_score": 0.85,
            "impact_factor_estimate": 0.78,
            "relevance_score": 0.82,
            "recommended_citations": [
                "Add more recent citations (last 5 years)",
                "Include more high-impact journal articles",
                "Consider adding review papers for context"
            ]
        },
        "advanced_metrics": {
            "citation_diversity": 0.75,
            "temporal_distribution": 0.68,
            "geographic_distribution": 0.72,
            "institutional_diversity": 0.65
        }
    }
}
```

## Citation Types

### Supported Citation Types
- **journal**: Academic journal articles
- **conference**: Conference proceedings and papers
- **arxiv**: arXiv preprints
- **book**: Books and book chapters
- **website**: Web resources and online content
- **other**: Other types of references

### Citation Quality Assessment
- **Extraction Quality**: Based on completeness of extracted fields
- **Completeness Score**: Percentage of available citation fields
- **Confidence Score**: Overall confidence in citation extraction

## Integration with Orchestrators

### SimpleQAOrchestrator
```python
# Uses simple mode for basic citation extraction
worker = BibliographyBuilderWorker(BibliographyMode.SIMPLE)
```

### EnhancedQAOrchestrator
```python
# Uses enhanced mode for multi-format citation parsing
worker = BibliographyBuilderWorker(BibliographyMode.ENHANCED)
```

### AdvancedQAOrchestrator
```python
# Uses advanced mode for AI-powered analysis
worker = BibliographyBuilderWorker(BibliographyMode.ADVANCED)
```

## Performance Considerations

### Mode Performance
- **Simple**: Fastest, minimal resource usage
- **Enhanced**: Moderate performance impact, multi-format parsing
- **Advanced**: Highest resource usage, AI/ML features

### Caching
The worker supports caching of bibliography structures to improve performance for repeated analysis.

### Library Dependencies
- **spacy**: Optional for advanced NLP features
- **scholarly**: Optional for Google Scholar integration
- **requests**: Required for Crossref API integration

## Error Handling

### Graceful Degradation
- Falls back to simpler extraction if advanced features fail
- Provides confidence scores to indicate reliability
- Includes recommendations for manual review when needed

### Common Error Scenarios
1. **Missing Libraries**: Falls back to regex extraction
2. **Invalid Citation Format**: Returns basic extraction with warnings
3. **No Citations Found**: Returns empty structure with low confidence
4. **AI/ML Service Unavailable**: Falls back to enhanced mode

## Testing

### Unit Tests
```python
# Test each mode independently
simple_worker = BibliographyBuilderWorker(BibliographyMode.SIMPLE)
enhanced_worker = BibliographyBuilderWorker(BibliographyMode.ENHANCED)
advanced_worker = BibliographyBuilderWorker(BibliographyMode.ADVANCED)

# Test extraction accuracy
# Test citation parsing
# Test error handling
```

### Integration Tests
```python
# Test with orchestrators
# Test with real academic papers
# Test performance under load
```

## Best Practices

### Mode Selection
- **Use Simple mode** for basic citation extraction
- **Use Enhanced mode** for academic papers with multiple citation formats
- **Use Advanced mode** for research analysis and bibliometric studies

### Pattern Configuration
- Keep regex patterns updated for new citation formats
- Test patterns with diverse academic papers
- Monitor extraction accuracy and adjust patterns

### Performance Optimization
- Cache frequently accessed bibliography structures
- Use appropriate mode for the task complexity
- Consider worker pooling for high-volume scenarios

## Troubleshooting

### Common Issues
1. **Low Extraction Accuracy**: Check pattern coverage and citation format
2. **Missing Citations**: Verify reference section format and markers
3. **Incorrect Parsing**: Review regex patterns for specific citation styles
4. **Performance Issues**: Consider mode downgrade or caching

### Debug Mode
```python
# Enable detailed logging
import logging
logging.getLogger('BibliographyBuilderWorker').setLevel(logging.DEBUG)
```

## Future Enhancements

### Planned Features
- **Machine Learning Models**: Improved citation pattern recognition
- **Natural Language Processing**: Better semantic understanding
- **Real-time Learning**: Adaptive extraction based on feedback
- **Integration APIs**: Connect with external citation databases

### Extensibility
The worker is designed for easy extension:
- Add new citation formats and patterns
- Integrate new citation databases
- Extend semantic analysis capabilities
- Customize bibliometric analysis

## Citation Analysis Features

### Citation Network Analysis
- **Network Density**: Measure of citation connectivity
- **Central Authors**: Most frequently cited authors
- **Citation Clusters**: Grouped citations by topic
- **Network Metrics**: Graph theory analysis

### Topic Modeling
- **Topic Identification**: Automatic topic discovery
- **Topic Weights**: Importance of each topic
- **Citation Distribution**: Citations per topic
- **Topic Coherence**: Quality of topic modeling

### Impact Analysis
- **Impact Categories**: High, medium, low impact citations
- **Impact Distribution**: Distribution across impact levels
- **Impact Score**: Overall citation impact
- **Recommended Sources**: High-impact journal suggestions

### Bibliometric Analysis
- **Citation Statistics**: Total citations, unique authors/journals
- **Temporal Analysis**: Publication year distribution
- **Citation Types**: Distribution across citation types
- **Geographic Distribution**: Author/institution locations


