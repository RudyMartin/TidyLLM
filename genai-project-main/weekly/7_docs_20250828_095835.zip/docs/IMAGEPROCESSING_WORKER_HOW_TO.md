# ImageProcessingWorker How-To Guide

## Overview

The `ImageProcessingWorker` is a configurable worker for handling image extraction and analysis from documents with progressive complexity. It supports three modes of operation: Simple, Enhanced, and Advanced, providing increasingly sophisticated image processing capabilities.

## Architecture

### Progressive Complexity Model

The worker follows a progressive complexity pattern:

- **Simple Mode**: Basic image extraction and metadata
- **Enhanced Mode**: OCR, image classification, quality assessment
- **Advanced Mode**: AI-powered analysis, object detection, semantic understanding

### Key Components

```python
class ImageProcessingMode(Enum):
    SIMPLE = "simple"
    ENHANCED = "enhanced"
    ADVANCED = "advanced"

class ImageProcessingWorker(BaseWorker):
    def __init__(self, mode: ImageProcessingMode = ImageProcessingMode.SIMPLE)
```

## Usage

### Basic Initialization

```python
from backend.mcp.workers.image_processing_worker import ImageProcessingWorker, ImageProcessingMode

# Simple mode
simple_worker = ImageProcessingWorker(ImageProcessingMode.SIMPLE)

# Enhanced mode
enhanced_worker = ImageProcessingWorker(ImageProcessingMode.ENHANCED)

# Advanced mode
advanced_worker = ImageProcessingWorker(ImageProcessingMode.ADVANCED)
```

### Processing Images

```python
# Extract images from PDF
result = worker._extract_images_simple({
    'file_path': 'document.pdf',
    'page_numbers': [0, 1, 2]
})

# Or use enhanced extraction
result = worker._extract_images_enhanced({
    'file_path': 'document.pdf',
    'page_numbers': [0, 1, 2]
})

# Or use advanced extraction
result = worker._extract_images_advanced({
    'file_path': 'document.pdf',
    'page_numbers': [0, 1, 2]
})
```

## Mode-Specific Features

### Simple Mode

**Purpose**: Basic image extraction and metadata collection

**Features**:
- Multiple extraction methods (pypdfium2, fitz, pymupdf)
- Basic image metadata (width, height, format, page number)
- Image caching for performance
- Fallback strategies

**Output Format**:
```python
{
    'success': True,
    'images': [
        {
            'image_id': 'img_0_abc12345',
            'data': 'base64_encoded_image_data',
            'format': 'PNG',
            'width': 800,
            'height': 600,
            'page_number': 1,
            'extraction_method': 'pypdfium2',
            'metadata': {
                'mode': 'simple',
                'basic_processing': True
            }
        }
    ],
    'total_images': 1,
    'methods_tried': ['pypdfium2'],
    'extraction_method': 'simple_basic',
    'confidence_score': 0.6,
    'mode': 'simple',
    'processed_at': '2024-01-27T14:30:00',
    'worker_name': 'ImageProcessingWorker'
}
```

### Enhanced Mode

**Purpose**: OCR, image classification, and quality assessment

**Features**:
- All Simple mode features
- OCR text extraction (if tesseract available)
- Image classification (type, size, aspect ratio)
- Quality assessment and recommendations
- Enhanced metadata

**Additional Output Fields**:
```python
{
    # ... Simple mode fields ...
    'ocr_text': 'Extracted text from image',
    'ocr_confidence': 0.85,
    'classification': {
        'image_type': 'landscape',
        'size_category': 'medium',
        'aspect_ratio': 1.33,
        'total_pixels': 480000,
        'confidence': 0.7
    },
    'quality_metrics': {
        'overall_quality': 0.75,
        'resolution_score': 0.48,
        'aspect_ratio_score': 1.0,
        'format_score': 0.3,
        'recommendations': [
            'Image quality is acceptable but could be improved'
        ]
    }
}
```

### Advanced Mode

**Purpose**: AI-powered analysis and semantic understanding

**Features**:
- All Enhanced mode features
- Object detection and classification
- Image segmentation
- Content analysis
- Semantic understanding
- ML predictions and recommendations

**Additional Output Fields**:
```python
{
    # ... Enhanced mode fields ...
    'advanced_features': {
        'ai_analysis': {
            'object_detection': {
                'objects_detected': 5,
                'primary_objects': ['text', 'chart', 'diagram'],
                'object_confidence': 0.75,
                'detection_method': 'rule_based',
                'object_locations': [...]
            },
            'image_segmentation': {
                'segments_detected': 8,
                'segment_types': ['text_region', 'image_region'],
                'segmentation_confidence': 0.68,
                'segment_areas': [...]
            },
            'content_analysis': {
                'content_type': 'mixed',
                'text_content': True,
                'visual_content': True,
                'tables_charts': True,
                'content_complexity': 'medium',
                'readability_score': 0.72,
                'content_organization': 'structured'
            },
            'semantic_understanding': {
                'semantic_topics': ['financial_data', 'performance_metrics'],
                'document_context': 'business_report',
                'semantic_confidence': 0.65,
                'key_concepts': ['revenue', 'growth', 'analysis'],
                'semantic_relationships': [...]
            }
        },
        'ml_predictions': {
            'image_quality_score': 0.85,
            'content_relevance': 0.78,
            'processing_complexity': 0.65,
            'recommended_actions': [
                'Apply image compression for web display',
                'Enhance contrast for better readability'
            ]
        },
        'advanced_metrics': {
            'feature_extraction_score': 0.82,
            'semantic_accuracy': 0.75,
            'processing_efficiency': 0.68,
            'content_coverage': 0.85
        }
    }
}
```

## Extraction Methods

### Supported Libraries

The worker supports multiple image extraction methods:

1. **pypdfium2** (Primary)
   - Fast and reliable
   - Good for most PDF types
   - Returns PIL images

2. **fitz/PyMuPDF** (Fallback)
   - Comprehensive PDF support
   - Handles complex layouts
   - Good for older PDFs

3. **pymupdf** (Modern PyMuPDF)
   - Latest PyMuPDF features
   - Enhanced performance
   - Better memory management

4. **pdf2image** (Alternative)
   - Converts pages to images
   - Good for simple documents
   - Requires poppler

### Method Selection

The worker tries methods in order of preference:
1. pypdfium2
2. fitz
3. pymupdf
4. pdf2image

If a method fails, it automatically tries the next available method.

## OCR Capabilities

### Tesseract Integration

When Tesseract is available, the worker can perform OCR:

```python
# OCR result structure
{
    'text': 'Extracted text content',
    'confidence': 0.85,  # 0-1 scale
    'word_count': 150,
    'lines': 25
}
```

### Installation

```bash
# Install pytesseract
pip install pytesseract

# Install system Tesseract
# macOS
brew install tesseract

# Ubuntu/Debian
sudo apt-get install tesseract-ocr

# Windows
# Download from https://github.com/UB-Mannheim/tesseract/wiki
```

## Image Classification

### Classification Types

1. **Image Type**:
   - `landscape`: Width > 1.5 × height
   - `portrait`: Height > 1.5 × width
   - `square`: Balanced dimensions

2. **Size Category**:
   - `large`: > 1MP (1,000,000 pixels)
   - `medium`: 100KP - 1MP
   - `small`: < 100KP

3. **Quality Metrics**:
   - Resolution score
   - Aspect ratio score
   - Format score
   - Overall quality assessment

## Quality Assessment

### Quality Scoring

The worker assesses image quality based on:

1. **Resolution**: Higher resolution = better score
2. **Aspect Ratio**: Standard ratios (0.8-1.2) preferred
3. **Format**: JPEG/PNG preferred over other formats

### Recommendations

Based on quality scores, the worker provides recommendations:

- **Low Quality (< 0.5)**: Suggest higher resolution, check format
- **Medium Quality (0.5-0.7)**: Acceptable but could improve
- **High Quality (> 0.7)**: Good quality

## Advanced AI Features

### Object Detection

Simulates object detection capabilities:

```python
{
    'objects_detected': 5,
    'primary_objects': ['text', 'chart', 'diagram', 'logo', 'signature'],
    'object_confidence': 0.75,
    'detection_method': 'rule_based',
    'object_locations': [
        {'object': 'text', 'confidence': 0.9, 'area': 'top_left'},
        {'object': 'chart', 'confidence': 0.8, 'area': 'center'}
    ]
}
```

### Image Segmentation

Analyzes image structure:

```python
{
    'segments_detected': 8,
    'segment_types': ['text_region', 'image_region', 'background'],
    'segmentation_confidence': 0.68,
    'segment_areas': [
        {'type': 'text_region', 'percentage': 45},
        {'type': 'image_region', 'percentage': 35},
        {'type': 'background', 'percentage': 20}
    ]
}
```

### Content Analysis

Evaluates document content:

```python
{
    'content_type': 'mixed',
    'text_content': True,
    'visual_content': True,
    'tables_charts': True,
    'content_complexity': 'medium',
    'readability_score': 0.72,
    'content_organization': 'structured'
}
```

### Semantic Understanding

Extracts semantic information:

```python
{
    'semantic_topics': ['financial_data', 'performance_metrics', 'analysis_results'],
    'document_context': 'business_report',
    'semantic_confidence': 0.65,
    'key_concepts': ['revenue', 'growth', 'analysis', 'metrics'],
    'semantic_relationships': [
        {'concept1': 'revenue', 'concept2': 'growth', 'relationship': 'correlation'},
        {'concept1': 'metrics', 'concept2': 'analysis', 'relationship': 'evaluation'}
    ]
}
```

## Performance Optimization

### Caching

The worker implements intelligent caching:

```python
# Cache key generation
cache_key = f"{file_path}_{page_numbers}_{mode.value}"

# Cache lookup
if cache_key in self.image_cache:
    return self.image_cache[cache_key]
```

### Method Availability Checking

The worker checks for available libraries at initialization:

```python
def _check_available_methods(self) -> Dict[str, bool]:
    methods = {}
    
    # Check each library
    for library in ['pypdfium2', 'fitz', 'pymupdf', 'pdf2image', 
                   'opencv', 'tesseract', 'tensorflow', 'pytorch']:
        try:
            __import__(library)
            methods[library] = True
        except ImportError:
            methods[library] = False
    
    return methods
```

## Integration

### MCP Protocol Integration

The worker integrates with the MCP protocol:

```python
def process_task(self, message: MCPMessage) -> Dict[str, Any]:
    task_data = message.get_task_data()
    task_type = message.get_task_type()
    
    if task_type == TaskType.IMAGE_EXTRACTION:
        return self._extract_images_task(task_data)
    elif task_type == TaskType.IMAGE_ANALYSIS:
        return self._analyze_images_task(task_data)
    else:
        raise ValueError(f"Unsupported task type: {task_type}")
```

### Coordinator Integration

```python
# In a coordinator
image_worker = ImageProcessingWorker(ImageProcessingMode.ENHANCED)
result = image_worker.process_task(message)
```

## Error Handling

### Graceful Degradation

The worker handles failures gracefully:

1. **Method Failure**: Tries next available method
2. **Library Missing**: Skips unavailable features
3. **Processing Error**: Returns partial results with error info

### Error Response Format

```python
{
    'success': False,
    'error': 'Error description',
    'images': [],
    'mode': 'simple',
    'worker_name': 'ImageProcessingWorker'
}
```

## Testing

### Test Script

Run the comprehensive test script:

```bash
cd notebooks
python3 test_image_processing_worker.py
```

### Test Coverage

The test script covers:

1. **Mode Testing**: All three modes (Simple, Enhanced, Advanced)
2. **Method Availability**: Checks for required libraries
3. **Feature Testing**: OCR, classification, quality assessment
4. **Performance Metrics**: Cache size, method availability
5. **Error Handling**: Graceful degradation scenarios

### Expected Output

```
🚀 Testing ImageProcessingWorker
============================================================

📋 Test 1: Simple Mode
----------------------------------------
Worker Mode: simple
Success: False
Extraction Method: simple_basic
Confidence Score: 0.60
Total Images: 0
Methods Tried: []

📋 Test 2: Enhanced Mode
----------------------------------------
Worker Mode: enhanced
Success: False
Extraction Method: enhanced_ocr_classification
Confidence Score: 0.75
Total Images: 0

📋 Test 3: Advanced Mode
----------------------------------------
Worker Mode: advanced
Success: False
Extraction Method: advanced_ai
Confidence Score: 0.90
Total Images: 0
```

## Best Practices

### Mode Selection

1. **Simple Mode**: Use for basic image extraction
2. **Enhanced Mode**: Use when OCR and classification needed
3. **Advanced Mode**: Use for comprehensive analysis

### Performance Considerations

1. **Caching**: Leverage built-in caching for repeated operations
2. **Method Selection**: Use fastest available method
3. **Memory Management**: Close PDF objects after processing

### Error Handling

1. **Check Success**: Always verify `success` field
2. **Handle Partial Results**: Process available images even if some fail
3. **Log Errors**: Use worker's logging for debugging

## Troubleshooting

### Common Issues

1. **No Images Extracted**:
   - Check PDF format and content
   - Verify extraction methods are available
   - Try different page numbers

2. **OCR Not Working**:
   - Install pytesseract and system Tesseract
   - Check image quality and format
   - Verify text is present in images

3. **Performance Issues**:
   - Enable caching
   - Use appropriate mode for requirements
   - Check available system resources

### Debug Information

```python
# Get supported methods
methods = worker.get_supported_methods()
print(f"Available methods: {methods}")

# Get performance metrics
metrics = worker.get_performance_metrics()
print(f"Performance: {metrics}")
```

## Future Enhancements

### Planned Features

1. **Real AI Integration**: Connect to actual AI models
2. **Batch Processing**: Process multiple documents
3. **Custom Classifiers**: User-defined image classification
4. **Advanced OCR**: Multi-language support
5. **Image Enhancement**: Automatic image improvement

### Extension Points

1. **Custom Extraction Methods**: Add new PDF libraries
2. **Custom Classifiers**: Implement domain-specific classification
3. **Custom Quality Metrics**: Define organization-specific quality criteria
4. **Integration APIs**: Connect to external image analysis services

## Dependencies

### Required Libraries

```python
# Core dependencies
pypdfium2>=0.20.0
fitz>=0.0.1
pymupdf>=1.23.0
Pillow>=9.0.0

# Enhanced mode dependencies
pytesseract>=0.3.10
opencv-python>=4.8.0

# Advanced mode dependencies
tensorflow>=2.13.0
torch>=2.0.0
```

### System Requirements

- **Tesseract**: For OCR functionality
- **Poppler**: For pdf2image support
- **Memory**: 2GB+ for large documents
- **Storage**: Sufficient space for image cache

## Conclusion

The `ImageProcessingWorker` provides a comprehensive solution for image extraction and analysis with progressive complexity. Its modular design allows for easy integration and extension while maintaining consistent interfaces across all modes.

The worker's ability to gracefully handle missing dependencies and provide fallback strategies makes it robust for production use, while its advanced features enable sophisticated image analysis when needed.


