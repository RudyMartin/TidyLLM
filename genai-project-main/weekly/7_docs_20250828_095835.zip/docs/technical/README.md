# 🔧 Technical Documentation - VectorQA Sage

## 🎯 Overview

Complete technical documentation for developers working with VectorQA Sage. This guide covers architecture, development setup, and technical implementation details.

## 🏗️ Architecture Overview

### **System Components**
- **Frontend**: Streamlit-based web interface
- **Backend**: Python-based processing pipeline
- **Database**: PostgreSQL with vector storage
- **AI Integration**: ZLLM gateway for local LLM processing
- **PDF Processing**: Multi-library fallback system

### **Key Technologies**
- **Streamlit**: Web application framework
- **PostgreSQL**: Primary database with pgvector extension
- **ZLLM**: Local LLM gateway
- **DSPy**: Prompt optimization framework
- **MCP**: Model Context Protocol for hierarchical processing

## 🚀 Development Setup

### **Prerequisites**
```bash
# Python 3.7+
python3 --version

# Git
git --version

# PostgreSQL (for advanced features)
psql --version
```

### **Installation**
```bash
# Clone repository
git clone <repository-url>
cd qaz_20250321

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # Mac/Linux
# or
venv\Scripts\activate     # Windows

# Install dependencies
pip install -r requirements.txt
pip install -r requirements_rag.txt
```

### **Database Setup**
```bash
# Create database
createdb vectorqa

# Run schema files
psql -d vectorqa -f database/simple_error_tracking_schema.sql
psql -d vectorqa -f database/schema_toc_tables.sql
psql -d vectorqa -f database/schema_bibliography_tables.sql
```

## 📁 Project Structure

```
qaz_20250321/
├── src/                    # Main application source
│   ├── main.py            # Streamlit app entry point
│   ├── backend/           # Backend services and core logic
│   │   ├── mcp/          # Model Context Protocol
│   │   ├── core/         # Core processing logic
│   │   └── workers/      # Specialized workers
│   ├── static/            # Static assets
│   └── *.py               # Streamlit tab modules
├── docs/                  # Documentation
├── tests/                 # Test suite
├── database/              # Database schemas and scripts
├── scripts/               # Utility scripts
├── deploy/                # Deployment configurations
└── requirements.txt       # Dependencies
```

## 🔧 Core Components

### **1. PDF Processing Pipeline**
- **ModernPDFProcessor**: Multi-library PDF processing
- **TOCExtractorWorker**: Table of contents extraction
- **BibliographyBuilderWorker**: Citation parsing
- **ImageProcessingWorker**: Image extraction with fallbacks

### **2. MCP (Model Context Protocol)**
- **Planners**: High-level strategic planning
- **Coordinators**: Mid-level coordination
- **Workers**: Task-specific execution
- **Orchestrators**: System orchestration

### **3. Database Layer**
- **Error Tracking**: Comprehensive error logging
- **Vector Storage**: pgvector for embeddings
- **Structured Data**: TOC and bibliography storage
- **Real-time Context**: Live data integration

### **4. AI Integration**
- **ZLLM Gateway**: Local LLM processing
- **DSPy Framework**: Prompt optimization
- **Embedding Generation**: Vector representations
- **RAG Pipeline**: Retrieval-augmented generation

## 🧪 Testing

### **Run All Tests**
```bash
# Run complete test suite
python -m pytest tests/ -v

# Run specific test categories
python -m pytest tests/test_modern_pdf_embeddings.py -v
python -m pytest tests/test_custom_extraction_routines.py -v
```

### **Test Individual Components**
```bash
# Test PDF processing
python scripts/test_modern_pdf_stack.py

# Test custom extraction
python scripts/test_custom_extraction_routines.py

# Test TOC extraction
python scripts/test_toc_extractor_worker.py

# Test bibliography extraction
python scripts/test_bibliography_builder_worker.py
```

## 🔍 Debugging

### **Enable Debug Logging**
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### **Common Debug Commands**
```bash
# Check system health
python -c "import sys; print(sys.version)"

# Test imports
python -c "from src.backend.mcp.workers import ModernPDFProcessor; print('OK')"

# Check database connection
python scripts/debug_credentials.py
```

## 🚀 Deployment

### **Local Development**
```bash
# Run development server
streamlit run src/main.py --server.port 8501

# Run simple demo
python start_simple_demo.py
```

### **Production Deployment**
```bash
# See deployment guide
docs/deploy/README.md
```

## 📊 Performance Monitoring

### **Key Metrics**
- **Response Time**: < 5 seconds for chat responses
- **Document Processing**: < 30 seconds per document
- **Memory Usage**: < 2GB for typical usage
- **CPU Usage**: < 50% during normal operation

### **Monitoring Tools**
- **MLflow**: Experiment tracking and metrics
- **PostgreSQL**: Performance monitoring
- **Streamlit**: Application metrics
- **Custom Logging**: Error tracking and analysis

## 🔐 Security Considerations

### **Current Gaps**
- ❌ No PII detection/redaction
- ❌ No authentication system
- ❌ No content filtering
- ❌ No rate limiting

### **Recommended Implementations**
- ✅ ScrubScan for PII detection
- ✅ Simple API key authentication
- ✅ Content filtering
- ✅ Rate limiting
- ✅ Audit logging

## 📚 Additional Resources

- **[Architecture Details](docs/architecture/README.md)**: Detailed system architecture
- **[API Documentation](docs/api/README.md)**: API reference
- **[Deployment Guide](docs/deploy/README.md)**: Production deployment
- **[Testing Guide](docs/testing/README.md)**: Comprehensive testing
- **[Security Guide](docs/security/README.md)**: Security best practices

---

**For questions or issues, see the troubleshooting section or contact the development team.**
