# Integrated Workers Usage Guide

## 🎯 Overview

This guide demonstrates how to use the **TOC Extractor Worker**, **Bibliography Builder Worker**, and **Table Extractor Worker** together for comprehensive document analysis. These three workers complement each other perfectly and are designed to work seamlessly through the `DocumentProcessingOrchestrator`.

## 🚀 Quick Start

### **1. Basic Integrated Processing**

```python
from backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator

# Initialize orchestrator
orchestrator = DocumentProcessingOrchestrator()

# Process document with all workers
result = orchestrator.process_document(
    document_path="research_paper.pdf",
    task_types=['toc', 'bibliography', 'tables', 'images']
)

# Check results
print(f"✅ Success: {result.success}")
print(f"📑 TOC sections: {result.toc_sections}")
print(f"📚 Citations: {result.citations_count}")
print(f"📋 Tables: {len(result.metadata.get('tables', {}).get('processed_tables', []))}")
print(f"🖼️ Images: {result.images_count}")
```

### **2. Batch Processing**

```python
# Process multiple documents
document_paths = [
    "paper1.pdf",
    "paper2.pdf", 
    "paper3.pdf"
]

results = orchestrator.process_documents_batch(
    document_paths,
    task_types=['toc', 'bibliography', 'tables']
)

# Analyze results
for result in results:
    print(f"📄 {Path(result.document_path).name}:")
    print(f"   TOC: {result.toc_sections} sections")
    print(f"   Citations: {result.citations_count}")
    print(f"   Tables: {len(result.metadata.get('tables', {}).get('processed_tables', []))}")
```

## 🔧 Individual Worker Usage

### **TOC Extractor Worker**

```python
from backend.mcp.workers.toc_extractor_worker import TOCExtractorWorker

# Initialize worker
toc_worker = TOCExtractorWorker()

# Extract TOC
toc_structure = toc_worker.extract_toc(
    file_path="document.pdf",
    document_id="doc_001",
    document_title="Research Paper"
)

# Access TOC data
print(f"📑 Found {len(toc_structure.entries)} sections")
print(f"🎯 Confidence: {toc_structure.confidence_score}")

# Navigate sections
for entry in toc_structure.entries:
    print(f"   {entry.title} (Page {entry.page_number})")
    
    # Get section content
    content = toc_worker.get_section_content(
        file_path="document.pdf",
        section_title=entry.title
    )
    print(f"      Content length: {len(content)} characters")
```

### **Bibliography Builder Worker**

```python
from backend.mcp.workers.bibliography_builder_worker import BibliographyBuilderWorker

# Initialize worker
bib_worker = BibliographyBuilderWorker()

# Extract bibliography
bibliography = bib_worker.extract_bibliography(
    file_path="research_paper.pdf",
    document_id="paper_001",
    document_title="Machine Learning Advances"
)

# Access citation data
print(f"📚 Found {len(bibliography.citations)} citations")
print(f"🎯 Confidence: {bibliography.confidence_score}")

# Analyze citations
for citation in bibliography.citations:
    print(f"   {citation.title} ({citation.year})")
    print(f"      Authors: {', '.join(citation.authors)}")
    print(f"      Type: {citation.citation_type}")
    print(f"      DOI: {citation.doi}")

# Get statistics
stats = bib_worker.get_citation_statistics(bibliography)
print(f"📊 Citation types: {stats['citation_type_distribution']}")
print(f"📈 Year distribution: {stats['year_distribution']}")
```

### **Table Extractor Worker**

```python
from backend.mcp.workers.document_workers import TableExtractorWorker
from backend.mcp.workers.modern_pdf_processor import ModernPDFProcessor

# Initialize workers
pdf_processor = ModernPDFProcessor()
table_worker = TableExtractorWorker()

# Extract tables from PDF
pdf_result = pdf_processor.process_pdf("document.pdf")
tables = pdf_result.get('tables', [])

# Process tables
if tables:
    result = table_worker.process_task({
        'payload': {'tables': tables}
    })
    
    processed_tables = result.get('processing', {}).get('processed_tables', [])
    
    for table in processed_tables:
        print(f"📋 Table: {table['table_id']}")
        print(f"   Rows: {table['rows']}, Columns: {table['columns']}")
        print(f"   Headers: {table['header']}")
        
        # Access structured data
        for row_data in table['structured_data'][:3]:  # First 3 rows
            print(f"      {row_data}")
```

## 🎯 Use Case Examples

### **1. Academic Literature Review**

```python
def analyze_research_papers(papers: List[str]):
    """Analyze multiple research papers for literature review"""
    
    orchestrator = DocumentProcessingOrchestrator()
    all_citations = []
    all_sections = []
    all_tables = []
    
    for paper in papers:
        result = orchestrator.process_document(
            document_path=paper,
            task_types=['toc', 'bibliography', 'tables']
        )
        
        if result.success:
            # Collect citations
            if result.bibliography_extracted:
                citations = result.metadata['bibliography']['bibliography_data']['citations']
                all_citations.extend(citations)
            
            # Collect sections
            if result.toc_extracted:
                sections = result.metadata['toc']['toc_data']['entries']
                all_sections.extend(sections)
            
            # Collect tables
            if 'tables' in result.metadata:
                tables = result.metadata['tables']['processed_tables']
                all_tables.extend(tables)
    
    # Generate insights
    insights = {
        'total_citations': len(all_citations),
        'unique_authors': len(set([author for citation in all_citations for author in citation.authors])),
        'citation_network': build_citation_network(all_citations),
        'common_sections': analyze_sections(all_sections),
        'data_tables': analyze_tables(all_tables)
    }
    
    return insights
```

### **2. Document Quality Assessment**

```python
def assess_document_quality(pdf_path: str):
    """Assess document quality using all extractors"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    result = orchestrator.process_document(
        document_path=pdf_path,
        task_types=['toc', 'bibliography', 'tables', 'images']
    )
    
    quality_score = 0
    quality_issues = []
    
    # TOC quality
    if result.toc_extracted:
        toc_quality = assess_toc_quality(result.metadata['toc']['toc_data'])
        quality_score += toc_quality['score']
        quality_issues.extend(toc_quality['issues'])
    
    # Bibliography quality
    if result.bibliography_extracted:
        bib_quality = assess_bibliography_quality(result.metadata['bibliography']['bibliography_data'])
        quality_score += bib_quality['score']
        quality_issues.extend(bib_quality['issues'])
    
    # Table quality
    if 'tables' in result.metadata:
        table_quality = assess_table_quality(result.metadata['tables']['processed_tables'])
        quality_score += table_quality['score']
        quality_issues.extend(table_quality['issues'])
    
    return {
        'overall_score': quality_score,
        'issues': quality_issues,
        'recommendations': generate_recommendations(quality_issues)
    }
```

### **3. Enhanced RAG System**

```python
class EnhancedRAGSystem:
    def __init__(self):
        self.orchestrator = DocumentProcessingOrchestrator()
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    def create_comprehensive_embeddings(self, pdf_path: str):
        """Create embeddings using all extracted data"""
        
        result = self.orchestrator.process_document(
            document_path=pdf_path,
            task_types=['toc', 'bibliography', 'tables', 'pdf']
        )
        
        embeddings = {}
        
        # Text embeddings (from PDF)
        if 'pdf' in result.metadata:
            text_content = result.metadata['pdf']['text_content']
            text_embeddings = self._create_text_embeddings(text_content)
            embeddings['text'] = text_embeddings
        
        # TOC embeddings
        if result.toc_extracted:
            toc_data = result.metadata['toc']['toc_data']
            toc_embeddings = self._create_toc_embeddings(toc_data)
            embeddings['toc'] = toc_embeddings
        
        # Citation embeddings
        if result.bibliography_extracted:
            citations = result.metadata['bibliography']['bibliography_data']['citations']
            citation_embeddings = self._create_citation_embeddings(citations)
            embeddings['citations'] = citation_embeddings
        
        # Table embeddings
        if 'tables' in result.metadata:
            tables = result.metadata['tables']['processed_tables']
            table_embeddings = self._create_table_embeddings(tables)
            embeddings['tables'] = table_embeddings
        
        return embeddings
    
    def _create_text_embeddings(self, text_content: str):
        """Create embeddings for text content"""
        # Implementation for text chunking and embedding
        pass
    
    def _create_toc_embeddings(self, toc_data: Dict):
        """Create embeddings for TOC structure"""
        # Implementation for TOC embedding
        pass
    
    def _create_citation_embeddings(self, citations: List):
        """Create embeddings for citations"""
        # Implementation for citation embedding
        pass
    
    def _create_table_embeddings(self, tables: List):
        """Create embeddings for table data"""
        # Implementation for table embedding
        pass
```

## 🔗 Cross-Referencing Analysis

### **1. Citation-Section Mapping**

```python
def map_citations_to_sections(pdf_path: str):
    """Map citations to the sections where they appear"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    result = orchestrator.process_document(
        document_path=pdf_path,
        task_types=['toc', 'bibliography', 'pdf']
    )
    
    if not (result.toc_extracted and result.bibliography_extracted):
        return {}
    
    toc_data = result.metadata['toc']['toc_data']
    citations = result.metadata['bibliography']['bibliography_data']['citations']
    text_content = result.metadata['pdf']['text_content']
    
    citation_sections = {}
    
    for citation in citations:
        # Find which section contains this citation
        for entry in toc_data['entries']:
            section_content = get_section_content(text_content, entry)
            
            # Check if citation appears in this section
            if citation.raw_text in section_content:
                citation_sections[citation.citation_id] = {
                    'section_title': entry.title,
                    'section_page': entry.page_number,
                    'citation': citation
                }
                break
    
    return citation_sections
```

### **2. Table-Section Mapping**

```python
def map_tables_to_sections(pdf_path: str):
    """Map tables to the sections where they appear"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    result = orchestrator.process_document(
        document_path=pdf_path,
        task_types=['toc', 'tables', 'pdf']
    )
    
    if not (result.toc_extracted and 'tables' in result.metadata):
        return {}
    
    toc_data = result.metadata['toc']['toc_data']
    tables = result.metadata['tables']['processed_tables']
    text_content = result.metadata['pdf']['text_content']
    
    table_sections = {}
    
    for table in tables:
        # Find which section contains this table
        for entry in toc_data['entries']:
            section_content = get_section_content(text_content, entry)
            
            # Check if table headers appear in this section
            table_headers = ' '.join(table.get('header', []))
            if table_headers in section_content:
                table_sections[table['table_id']] = {
                    'section_title': entry.title,
                    'section_page': entry.page_number,
                    'table': table
                }
                break
    
    return table_sections
```

## 📊 Performance Optimization

### **1. Parallel Processing**

```python
def process_documents_parallel(document_paths: List[str]):
    """Process documents in parallel for better performance"""
    
    orchestrator = DocumentProcessingOrchestrator(max_workers=4)
    
    # Process in parallel
    results = orchestrator.process_documents_batch(
        document_paths,
        task_types=['toc', 'bibliography', 'tables']
    )
    
    # Analyze performance
    total_time = sum(r.processing_time for r in results)
    total_extractions = sum([
        r.toc_sections + r.citations_count + 
        len(r.metadata.get('tables', {}).get('processed_tables', []))
        for r in results
    ])
    
    print(f"⚡ Processed {len(results)} documents in {total_time:.2f}s")
    print(f"📊 Extracted {total_extractions} total elements")
    print(f"🚀 Average: {total_time/len(results):.2f}s per document")
    
    return results
```

### **2. Caching Strategy**

```python
def optimize_with_caching():
    """Demonstrate caching benefits"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    # First run - all workers process
    print("🔧 First run (no cache):")
    start_time = time.time()
    result1 = orchestrator.process_document("document.pdf")
    first_run_time = time.time() - start_time
    print(f"   Time: {first_run_time:.2f}s")
    
    # Second run - cached results
    print("💾 Second run (with cache):")
    start_time = time.time()
    result2 = orchestrator.process_document("document.pdf")
    second_run_time = time.time() - start_time
    print(f"   Time: {second_run_time:.2f}s")
    
    # Performance improvement
    improvement = ((first_run_time - second_run_time) / first_run_time) * 100
    print(f"🚀 Performance improvement: {improvement:.1f}%")
    
    # Check cache statistics
    cache_stats = orchestrator.get_worker_status()
    for worker_name, stats in cache_stats.items():
        if stats['cache_stats']:
            print(f"   {worker_name}: {stats['cache_stats']['hits']} cache hits")
```

## 🧪 Testing and Validation

### **1. Run Integrated Test Suite**

```bash
# Run comprehensive test suite
python scripts/test_integrated_workers.py
```

### **2. Individual Component Testing**

```python
# Test individual workers
from scripts.test_integrated_workers import (
    test_toc_worker,
    test_bibliography_worker,
    test_table_extraction
)

# Test TOC extraction
test_toc_worker()

# Test bibliography extraction
test_bibliography_worker()

# Test table extraction
test_table_extraction()
```

### **3. Performance Testing**

```python
# Test performance comparison
from scripts.test_integrated_workers import test_performance_comparison

test_performance_comparison()
```

## 🎯 Best Practices

### **1. Task Type Selection**

```python
# For academic papers
task_types = ['toc', 'bibliography', 'tables', 'images']

# For technical documents
task_types = ['toc', 'tables', 'images']

# For business reports
task_types = ['toc', 'tables', 'bibliography']

# For quick analysis
task_types = ['toc', 'bibliography']  # Skip tables for speed
```

### **2. Error Handling**

```python
def robust_document_processing(pdf_path: str):
    """Robust document processing with error handling"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    try:
        result = orchestrator.process_document(
            document_path=pdf_path,
            task_types=['toc', 'bibliography', 'tables']
        )
        
        if result.success:
            return {
                'success': True,
                'data': result,
                'summary': {
                    'toc_sections': result.toc_sections,
                    'citations': result.citations_count,
                    'tables': len(result.metadata.get('tables', {}).get('processed_tables', []))
                }
            }
        else:
            return {
                'success': False,
                'error': result.error_message,
                'partial_data': result.metadata
            }
            
    except Exception as e:
        return {
            'success': False,
            'error': str(e),
            'partial_data': {}
        }
```

### **3. Database Integration**

```python
def process_and_store(pdf_path: str):
    """Process document and store results in database"""
    
    # Configure database connection
    db_config = {
        'host': 'localhost',
        'port': 5432,
        'database': 'document_processing',
        'user': 'postgres',
        'password': 'password'
    }
    
    orchestrator = DocumentProcessingOrchestrator(db_config=db_config)
    
    # Process and automatically store in database
    result = orchestrator.process_document(
        document_path=pdf_path,
        task_types=['toc', 'bibliography', 'tables']
    )
    
    if result.database_stored:
        print("✅ Results stored in database")
        return result
    else:
        print("❌ Failed to store in database")
        return result
```

## 🔮 Future Enhancements

### **1. Cross-Document Analysis**

```python
def cross_document_analysis(papers: List[str]):
    """Analyze relationships between multiple documents"""
    
    # Process all papers
    results = []
    for paper in papers:
        result = process_document(paper)
        results.append(result)
    
    # Find citation overlaps
    citation_overlaps = find_citation_overlaps(results)
    
    # Find similar sections
    section_similarities = find_section_similarities(results)
    
    # Find related tables
    table_relationships = find_table_relationships(results)
    
    return {
        'citation_network': citation_overlaps,
        'section_relationships': section_similarities,
        'table_relationships': table_relationships
    }
```

### **2. Real-Time Processing**

```python
def real_time_document_analysis():
    """Real-time document analysis with streaming results"""
    
    orchestrator = DocumentProcessingOrchestrator()
    
    # Monitor directory for new documents
    for pdf_path in watch_directory("input/"):
        print(f"📄 Processing new document: {pdf_path}")
        
        # Process with real-time updates
        result = orchestrator.process_document(
            document_path=pdf_path,
            task_types=['toc', 'bibliography', 'tables']
        )
        
        # Send real-time updates
        send_notification(f"Document processed: {result.toc_sections} sections, {result.citations_count} citations")
```

---

**Last Updated**: December 2024  
**Version**: 1.0  
**Maintainer**: AI Assistant  
**Status**: ✅ **Production Ready**
