Python “Tidyverse Stack” – Cheat Sheet (No‑Pandas Edition)

> Goal: Tidyverse‑style workflow **using only `datatable`** (no pandas bridge). Focus on fast, chainable transforms, joins, grouping, reshaping patterns built with `datatable` primitives.

---

## 1) Core Stack

* **Wrangle:** `datatable`
* **Plot:** (optional) export to CSV and plot elsewhere; or use Python plotting on converted arrays (but keep tables in `datatable`).
* **I/O:** `datatable.fread`, `datatable.fwrite`
* **Strings:** Python `re` + `Frame.replace()`
* **Dates:** `python-dateutil` parsed into Python `datetime` objects stored in columns

**Install**

```bash
pip install datatable python-dateutil
```

---

## 2) Verb Map (tidyverse → datatable)

| Tidyverse      | `datatable` (Python)                                     | Notes                             |
| -------------- | -------------------------------------------------------- | --------------------------------- |
| `select()`     | `DT[:, [cols]]` or dict                                  | Keep/reorder columns              |
| `filter()`     | `DT[expr, :]`                                            | Boolean row filter                |
| `mutate()`     | `DT[:, {newcol: expr, ...}]` or `DT[:, dt.f.col] = expr` | Add/transform columns             |
| `summarise()`  | `DT[:, {agg_dict}]`                                      | Aggregations                      |
| `group_by()`   | `DT[:, {...}, dt.by(keys)]`                              | Grouped ops                       |
| `arrange()`    | `DT[:, :, dt.sort(+/-DT.col)]`                           | Sort                              |
| `distinct()`   | `DT[:, :, dt.by(keys)]`                                  | Unique records over keys          |
| `rename()`     | `DT.names = {...}` or dict select                        | Rename columns                    |
| `left_join()`  | `DT1[:, :, dt.join(DT2, on="key")]`                      | Left join by default              |
| `inner_join()` | `join_type="inner"`                                      | `dt.join(..., join_type="inner")` |
| `anti_join()`  | `dt.anti_join(DT1, DT2, on="key")`                       |                                   |
| `semi_join()`  | `dt.semi_join(DT1, DT2, on="key")`                       |                                   |

---

## 3) Minimal Patterns

### A) Filter → Select → Sort

```python
import datatable as dt
DT = dt.Frame(name=["A","B","C"], age=[25,35,40], grp=["x","x","y"])
OUT = (
  DT[DT.age > 30, :]             # filter
    [:, ["name","age","grp"]]  # select
    [:, :, dt.sort(-DT.age)]     # arrange desc
)
```

### B) Grouped Summaries

```python
SUM = DT[:, {"mean_age": dt.mean(DT.age), "n": dt.count()}, dt.by("grp")]
```

### C) Mutate / Conditional Mutate

```python
DT[:, dt.f.age2] = DT.age * 2
DT[:, dt.f.bucket] = dt.ifelse(DT.age >= 35, "senior", "regular")
```

### D) Joins

```python
DT1 = dt.Frame(id=[1,2,3], a=[10,20,30])
DT2 = dt.Frame(id=[2,3,4], b=[200,300,400])
LEFT  = DT1[:, :, dt.join(DT2, on="id")]                       # left
INNER = DT1[:, :, dt.join(DT2, on="id", join_type="inner")]   # inner
```

### E) Distinct / Deduplicate

```python
UNIQ = DT[:, :, dt.by("grp","name")]  # unique (grp,name) pairs
```

---

## 4) Reshaping **without pandas**

`datatable` doesn’t expose a single "melt/pivot" verb like tidyverse, but you can reshape efficiently using native building blocks: `dt.rbind`, `dt.cbind`, group aggregations, and conditional projections.

### Pattern 1 — **pivot\_longer (manual melt)**

Stack multiple value columns into two columns: `variable` and `value`.

```python
# Example table with wide measures
W = dt.Frame(id=[1,1,2,2], grp=["A","A","B","B"], m1=[5,7,1,3], m2=[50,70,10,30])

# Build long frames per measure then rbind
long_m1 = W[:, {"id": W.id, "grp": W.grp, "variable": "m1", "value": W.m1}]
long_m2 = W[:, {"id": W.id, "grp": W.grp, "variable": "m2", "value": W.m2}]
LONG = dt.rbind(long_m1, long_m2)
```

> Scale this with a loop over measure columns to avoid code repetition.

### Pattern 2 — **pivot\_wider (manual pivot)**

Turn rows into columns by category using conditional aggregates.

```python
# Start from LONG(id, grp, variable, value) and compute wide means per grp
WIDE = LONG[:, {
  "m1": dt.mean(dt.ifelse(LONG.variable == "m1", LONG.value, None)),
  "m2": dt.mean(dt.ifelse(LONG.variable == "m2", LONG.value, None)),
}, dt.by("grp")]
```

> Replace `dt.mean` with `dt.sum`, `dt.max`, etc., as needed. For **counts**, use `dt.count()` on an indicator.

### Pattern 3 — **Top‑N per group**

```python
TOP2 = (DT[:, :, dt.sort(-DT.age)]
          [:, {"rank": dt.rowid()}, dt.by("grp")]
          [dt.f.rank <= 2, :])
```

### Pattern 4 — **One‑hot style widening**

Create a column per category and aggregate.

```python
Cats = dt.unique(DT[:, ["grp"]])["grp"].to_list()[0]
agg = {f"is_{g}": dt.sum(dt.ifelse(DT.grp == g, 1, 0)) for g in Cats}
ONEHOT = DT[:, agg]
```

### Pattern 5 — **Row/column binding**

```python
# Row bind (stack tables)
DT_all = dt.rbind(DT_part1, DT_part2)

# Column bind (add columns side-by-side; must have same nrows)
DT_side = dt.cbind(DT_left, DT_right)
```

---

## 5) Strings & Dates (No‑Pandas)

```python
import re
from dateutil import parser

DT = dt.Frame(txt=["A-001","B-002"], when=["2025-08-01","Aug 2, 2025"]) 

# split into prefix/code using regex with replace()
DT[:, dt.f.prefix] = DT.txt.replace(re.compile(r"-.*$"), "")
DT[:, dt.f.code]   = DT.txt.replace(re.compile(r"^.*-"), "")

# parse dates into Python datetime objects
DT[:, dt.f.when_dt] = [parser.parse(x) for x in DT["when"].to_list()[0]]
```

---

## 6) I/O (Fast, No‑Pandas)

```python
DT = dt.fread("data.csv")
dt.fwrite(DT, "out.csv")  # or DT.to_csv("out.csv")
```

---

## 7) Performance Guidelines

* Keep everything in `datatable` frames; avoid converting to pandas.
* Express logic with **columnar expressions** (avoid Python loops inside hot paths).
* Use **dict in the second slot** (`DT[:, {...}]`) to add multiple computed columns at once.
* Minimize repeated sorts; sort once, then slice.
* For reshaping, prefer **conditional aggregates** + `rbind/cbind` patterns shown above.

---

## 8) Useful Aggregates & Helpers

* Aggregates: `dt.count()`, `dt.sum(col)`, `dt.mean(col)`, `dt.min(col)`, `dt.max(col)`, `dt.sd(col)`
* Logic: `dt.ifelse(cond, a, b)`
* Sorting: `dt.sort(DT.col)` or `dt.sort(-DT.col)`
* Row id: `dt.rowid()`
* Column refs: `DT.col` or `dt.f.col`

---

## 9) Troubleshooting Gotchas

* Joins are **left** by default; specify `join_type` for inner/right/full as supported.
* Sorting happens in the **third** slot of `DT[:, :, ...]`.
* `Frame.replace(pattern, repl)` expects a compiled regex for complex patterns.
* When building LONG via loops, precompute the list of measure columns to avoid hard‑coding.

---

## 10) Quick Reshaping Template (Parametric long → wide)

```python
# Given LONG with keys K, category C, value V, produce wide sums per K
K = ["id", "grp"]; C = "variable"; V = "value"
Cats = dt.unique(LONG[:, [C]])[C].to_list()[0]
agg = {c: dt.sum(dt.ifelse(LONG[C] == c, LONG[V], 0)) for c in Cats}
WIDE = LONG[:, agg, dt.by(*K)]
```


