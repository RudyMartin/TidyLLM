# File Upload Security Documentation

## Overview

The QA Document Processing system implements comprehensive security measures to protect against malicious file uploads, including executable files, script injection, and other security threats commonly associated with file upload functionality.

## Security Threats Addressed

### 1. Executable File Uploads
- **Threat**: Attackers upload executable files (.exe, .bat, .sh, .py, etc.) disguised as documents
- **Risk**: Code execution on the server or client systems
- **Protection**: File extension validation and content signature checking

### 2. File Extension Spoofing
- **Threat**: Renaming malicious files with safe extensions (e.g., `malicious.exe` → `document.jpg`)
- **Risk**: Bypassing basic extension filters
- **Protection**: Magic byte signature validation and content analysis

### 3. Path Traversal Attacks
- **Threat**: Files with paths like `../../../etc/passwd` or `C:\Windows\System32\malicious.dll`
- **Risk**: Accessing sensitive system files
- **Protection**: Path sanitization and traversal detection

### 4. ZIP Bomb Attacks
- **Threat**: Compressed files that expand to enormous sizes
- **Risk**: Denial of service through disk space exhaustion
- **Protection**: File count limits and size restrictions

### 5. Malicious Script Injection
- **Threat**: Files containing executable code disguised as data
- **Risk**: Server-side code execution
- **Protection**: Content pattern analysis and signature validation

## Security Implementation

### File Type Restrictions

#### Allowed File Extensions
```python
ALLOWED_EXTENSIONS = {
    # Documents
    '.pdf', '.docx', '.txt', '.csv', '.xlsx', '.md', '.doc', '.rtf',
    # Data formats
    '.log',
    # Images
    '.gif', '.jpg', '.jpeg', '.png', '.svg', '.bmp', '.tiff', '.webp',
    # Code and Analysis
    '.py', '.ipynb', '.r', '.sql', '.sas', '.mat', '.m',
    # Statistical and Data
    '.sav', '.dta', '.rds', '.rdata', '.parquet', '.feather', '.h5', '.hdf5',
    # Configuration and Metadata
    '.toml', '.ini', '.cfg', '.conf',
    # Reports and Outputs
    '.tex', '.bib', '.ris', '.enw'
}
```

**Note**: XML, HTML, JSON, YAML, and JavaScript files are explicitly blocked due to security risks (XXE attacks, XSS, code execution, etc.).

#### Blocked File Extensions
```python
DANGEROUS_EXTENSIONS = {
    # Executables
    '.exe', '.bat', '.cmd', '.com', '.scr', '.pif', '.vbs', '.js', '.jar',
    # Scripts
    '.py', '.sh', '.bash', '.zsh', '.csh', '.ksh', '.pl', '.rb', '.php',
    # System files
    '.dll', '.so', '.dylib', '.sys', '.drv', '.ocx', '.cpl',
    # Archives that could contain more dangerous content
    '.tar', '.gz', '.bz2', '.7z', '.rar', '.cab',
    # Other potentially dangerous
    '.reg', '.inf', '.msi', '.msp', '.mst', '.chm', '.hta', '.wsf',
    # Network/communication files
    '.url', '.lnk', '.desktop', '.app', '.command'
}
```

### Content Validation

#### Comprehensive File Type Validation
The system implements **extensive content type checking** that goes far beyond simple file extensions. This prevents file extension spoofing attacks where malicious files are renamed with safe extensions.

#### File Signature (Magic Byte) Validation
The system checks file signatures to ensure content matches the declared file type:

```python
file_signatures = {
    b'MZ': 'Windows executable',
    b'\x7fELF': 'ELF executable',
    b'#!/': 'Shell script',
    b'<?php': 'PHP script',
    b'<%': 'ASP script',
    b'PK\x03\x04': 'ZIP archive',
    b'Rar!': 'RAR archive',
    b'\x1f\x8b\x08': 'GZIP archive',
    b'\x37\x7A\x68': '7-Zip archive',
}
```

#### Expected Content Signatures
For allowed file types, the system validates expected content patterns:

```python
expected_signatures = {
    '.jpg': [b'\xff\xd8\xff'],
    '.png': [b'\x89PNG\r\n\x1a\n'],
    '.gif': [b'GIF87a', b'GIF89a'],
    '.pdf': [b'%PDF'],
    '.zip': [b'PK\x03\x04'],
    '.py': [b'#!/usr/bin/python', b'import ', b'def ', b'class '],
    '.sql': [b'SELECT', b'INSERT', b'UPDATE', b'DELETE'],
    # ... more signatures
}
```

#### Suspicious Content Pattern Detection
The system scans file content for malicious patterns:

```python
suspicious_patterns = [
    '#!/bin/bash', '#!/bin/sh', '#!/usr/bin/python',
    'exec(', 'eval(', 'system(', 'subprocess.',
    'os.system', 'shell_exec', 'passthru',
    'cmd.exe', 'powershell', 'wscript',
    'regsvr32', 'rundll32', 'certutil',
    'mz',  # DOS/Windows executable header
    'pe\x00\x00',  # PE executable header
    'elf',  # ELF executable header
    'javascript:',  # JavaScript execution
    'vbscript:',  # VBScript execution
    'data:text/html',  # Data URLs
]
```

### Size and Quantity Limits

#### File Size Restrictions
- **Individual file limit**: 10MB per file
- **ZIP file limit**: 50MB total
- **Content size limit**: 10MB after extraction

#### Quantity Restrictions
- **Files per ZIP**: Maximum 100 files
- **Total files per upload**: Limited by Streamlit's file uploader

### Path Security

#### Path Traversal Protection
The system blocks files with dangerous paths:
- `../../../malicious.txt` (Unix path traversal)
- `C:\Windows\system32\malicious.dll` (Windows path traversal)
- `\etc\passwd` (Absolute paths)

#### Path Sanitization
- All paths are normalized and validated
- Only relative paths within the extraction directory are allowed
- Backslashes and forward slashes are detected and blocked

## ZIP File Security

### ZIP Extraction Security
When processing ZIP files, the system:

1. **Validates ZIP integrity** before extraction
2. **Checks file count** to prevent ZIP bombs
3. **Validates each extracted file** individually
4. **Uses temporary directories** for safe extraction
5. **Cleans up** temporary files automatically

### ZIP Bomb Protection
- **File count limit**: 100 files per ZIP
- **Size limit**: 50MB total ZIP size
- **Individual file size**: 10MB per extracted file
- **Recursive extraction**: Not allowed (no nested archives)

## Error Handling and Reporting

### Security Alert System
When malicious files are detected, the system:

1. **Blocks the file** from processing
2. **Logs the security event** with details
3. **Reports to user** with specific reason for blocking
4. **Continues processing** other valid files
5. **Provides summary** of blocked files

### User Feedback
```python
# Example security alert
st.warning(f"⚠️ **Security Alert**: {len(blocked_files)} files were blocked:")
for blocked in blocked_files[:5]:
    st.warning(f"  - {blocked}")
```

## Security Best Practices

### For Users
1. **Verify file sources** before upload
2. **Scan files** with antivirus software
3. **Use trusted file formats** only
4. **Report suspicious files** to administrators

### For Administrators
1. **Monitor security logs** regularly
2. **Update security patterns** as threats evolve
3. **Review blocked files** for false positives
4. **Maintain file type signatures** database

## Configuration

### Security Settings
```python
# Configurable security parameters
max_size_mb = 50          # Maximum ZIP file size
max_files = 100           # Maximum files per ZIP
max_file_size = 10        # Maximum individual file size (MB)
max_content_size = 10     # Maximum content size after extraction (MB)
```

### Customization
Security parameters can be adjusted in `src/qa_demo.py`:
- `extract_zip_safely()` function parameters
- `DANGEROUS_EXTENSIONS` list
- `ALLOWED_EXTENSIONS` list
- `suspicious_patterns` list

## Testing

### Security Test Suite
The system includes comprehensive security tests in `tests/test_zip_handling.py`:

1. **Dangerous file extension tests**
2. **Suspicious content pattern tests**
3. **Path traversal attack tests**
4. **File signature validation tests**
5. **ZIP bomb protection tests**

### Running Security Tests
```bash
python3 tests/test_zip_handling.py
```

## Incident Response

### Security Event Handling
1. **Immediate blocking** of detected threats
2. **Logging** of security events
3. **User notification** of blocked files
4. **Administrator alerting** for repeated attempts
5. **Forensic analysis** of blocked content

### Escalation Procedures
1. **Multiple blocked files**: Review for coordinated attack
2. **Repeated uploads**: Consider IP blocking
3. **Successful bypass**: Immediate security review
4. **Data breach**: Follow incident response plan

## Compliance

### Regulatory Requirements
The security measures support compliance with:
- **SR 11-7**: Model risk management
- **Basel III**: Risk management standards
- **CCAR**: Comprehensive Capital Analysis and Review
- **SOX**: Sarbanes-Oxley Act requirements

### Audit Trail
All security events are logged for:
- **Compliance audits**
- **Security reviews**
- **Incident investigations**
- **Risk assessments**

## Future Enhancements

### Planned Security Improvements
1. **Machine learning** for threat detection
2. **Real-time threat intelligence** integration
3. **Advanced file analysis** capabilities
4. **Behavioral analysis** of upload patterns
5. **Enhanced logging** and monitoring

### Security Roadmap
- **Q1**: Enhanced signature database
- **Q2**: ML-based threat detection
- **Q3**: Real-time threat feeds
- **Q4**: Advanced behavioral analysis

---

**Last Updated**: August 2025  
**Version**: 1.0  
**Security Level**: High  
**Review Frequency**: Quarterly
