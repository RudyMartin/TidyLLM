# TOCExtractorWorker How-To Guide

## Overview

The `TOCExtractorWorker` is a **unified, configurable worker** that provides progressive complexity for table of contents extraction across three modes:
- **Simple**: Basic regex-based TOC extraction
- **Enhanced**: PDF-aware extraction with page numbers, hierarchy detection
- **Advanced**: AI-powered structure analysis, semantic section grouping

## Architecture

### Progressive Complexity Design
```
Simple Mode → Enhanced Mode → Advanced Mode
     ↓              ↓              ↓
Basic Regex → PDF-Aware → AI/ML Analysis
```

### Extraction Methods
1. **Simple**: Basic regex patterns for TOC detection
2. **Enhanced**: PDF-aware extraction using pdfplumber/fitz libraries
3. **Advanced**: Enhanced + AI-powered semantic analysis

## Usage

### Basic Usage

```python
from backend.mcp.workers.toc_extractor_worker import TOCExtractorWorker, TOCMode

# Simple mode (default)
simple_worker = TOCExtractorWorker(TOCMode.SIMPLE)
result = simple_worker._extract_toc_simple({
    'content': document_content,
    'filename': 'document.txt'
})

# Enhanced mode
enhanced_worker = TOCExtractorWorker(TOCMode.ENHANCED)
result = enhanced_worker._extract_toc_enhanced({
    'content': document_content,
    'filename': 'document.pdf',
    'file_path': '/path/to/document.pdf'
})

# Advanced mode
advanced_worker = TOCExtractorWorker(TOCMode.ADVANCED)
result = advanced_worker._extract_toc_advanced({
    'content': document_content,
    'filename': 'document.pdf'
})
```

### MCP Task Processing

```python
# The worker automatically handles different task types based on mode
message = MCPMessage(
    task_type=TaskType.TOC_EXTRACTION,
    task_data={'content': '...', 'filename': 'doc.pdf'}
)

# Simple mode: Basic extraction
simple_result = simple_worker.process_task(message)

# Enhanced mode: PDF-aware extraction
enhanced_result = enhanced_worker.process_task(message)

# Advanced mode: AI-powered analysis
advanced_result = advanced_worker.process_task(message)
```

## Pattern Recognition

### Simple Patterns
- `^(\d+\.?\d*)\s+(.+?)(?:\s+(\d+))?$` - 1. Title 5
- `^([IVX]+\.?)\s+(.+?)(?:\s+(\d+))?$` - I. Title 5
- `^([A-Z]\.?)\s+(.+?)(?:\s+(\d+))?$` - A. Title 5
- `^(.+?)(?:\s+(\d+))?$` - Title 5

### Enhanced Patterns
- All simple patterns plus:
- `^(\d+\.?\d*\.?\d*)\s+(.+?)(?:\s+(\d+))?$` - 1.1.1 Title 5
- `^([A-Z]\.?\d+\.?\d*)\s+(.+?)(?:\s+(\d+))?$` - A.1.1 Title 5

### Advanced Patterns
- All enhanced patterns plus semantic patterns:
- `^(Chapter|Section|Part|Appendix)\s+(\d+|[IVX]+|[A-Z]+)\s*[:\.]?\s*(.+?)(?:\s+(\d+))?$`
- `^(Abstract|Introduction|Conclusion|References|Bibliography)(?:\s+(\d+))?$`

## Output Formats

### Simple Mode Output
```json
{
    "success": true,
    "toc_structure": {
        "document_id": "a1b2c3d4",
        "document_title": "Research Paper",
        "total_pages": 25,
        "entries": [
            {
                "title": "Introduction",
                "page_number": 1,
                "level": 1,
                "section_id": "intro_123",
                "parent_id": null,
                "children": [],
                "metadata": {
                    "pattern_used": "^(\d+\.?\d*)\s+(.+?)(?:\s+(\d+))?$",
                    "number": "1"
                }
            }
        ],
        "extraction_method": "simple_regex",
        "confidence_score": 0.6,
        "metadata": {
            "mode": "simple",
            "patterns_used": 4
        },
        "created_at": "2024-01-15T10:30:00"
    },
    "extraction_method": "simple_regex",
    "confidence_score": 0.6,
    "total_entries": 8,
    "mode": "simple",
    "processed_at": "2024-01-15T10:30:00",
    "worker_name": "TOCExtractorWorker"
}
```

### Enhanced Mode Output
Enhanced output includes:
- **Semantic categorization** of sections
- **Importance scoring** for each section
- **Enhanced metadata** with context
- **PDF-aware extraction** when available

```json
{
    "success": true,
    "toc_structure": {
        "document_id": "a1b2c3d4",
        "document_title": "Research Paper",
        "total_pages": 25,
        "entries": [
            {
                "title": "Introduction",
                "page_number": 1,
                "level": 1,
                "section_id": "intro_123",
                "parent_id": null,
                "children": [],
                "metadata": {
                    "pattern_used": "^(\d+\.?\d*)\s+(.+?)(?:\s+(\d+))?$",
                    "number": "1",
                    "semantic_category": "introduction",
                    "importance_score": 0.8
                }
            }
        ],
        "extraction_method": "enhanced_regex",
        "confidence_score": 0.75,
        "metadata": {
            "mode": "enhanced",
            "patterns_used": 6,
            "enhancement_applied": true
        },
        "created_at": "2024-01-15T10:30:00"
    },
    "extraction_method": "enhanced_regex",
    "confidence_score": 0.75,
    "total_entries": 8,
    "mode": "enhanced",
    "processed_at": "2024-01-15T10:30:00",
    "worker_name": "TOCExtractorWorker"
}
```

### Advanced Mode Output
Advanced output includes enhanced features plus:
```json
{
    "advanced_features": {
        "ai_analysis": {
            "semantic_clustering": {
                "clusters": [
                    {
                        "name": "Overview",
                        "sections": ["Abstract", "Introduction"]
                    },
                    {
                        "name": "Methodology",
                        "sections": ["Methods", "Approach"]
                    },
                    {
                        "name": "Results",
                        "sections": ["Results", "Findings"]
                    },
                    {
                        "name": "Conclusion",
                        "sections": ["Discussion", "Conclusion"]
                    }
                ],
                "cluster_confidence": 0.75
            },
            "topic_modeling": {
                "topics": [
                    {"topic": "research methodology", "weight": 0.3},
                    {"topic": "data analysis", "weight": 0.25},
                    {"topic": "results interpretation", "weight": 0.2},
                    {"topic": "conclusions", "weight": 0.15}
                ],
                "topic_coherence": 0.68
            },
            "section_importance": {
                "critical_sections": ["Abstract", "Introduction", "Conclusion"],
                "important_sections": ["Methods", "Results", "Discussion"],
                "supporting_sections": ["References", "Appendices"],
                "importance_distribution": [0.3, 0.4, 0.2, 0.1]
            },
            "document_structure_analysis": {
                "structure_type": "academic_paper",
                "completeness_score": 0.85,
                "balance_score": 0.72,
                "recommended_improvements": [
                    "Add executive summary",
                    "Include methodology section",
                    "Improve section numbering"
                ]
            }
        },
        "ml_predictions": {
            "completeness_score": 0.85,
            "structure_quality": 0.78,
            "missing_sections": ["Executive Summary", "Methodology"],
            "recommended_improvements": [
                "Add executive summary section",
                "Include methodology section",
                "Improve section numbering consistency"
            ]
        },
        "advanced_metrics": {
            "hierarchy_depth": 3,
            "section_balance": 0.85,
            "navigational_complexity": 0.65,
            "content_coverage": 0.82
        }
    }
}
```

## PDF Processing

### Supported Libraries
- **pdfplumber**: Primary PDF processing library
- **fitz (PyMuPDF)**: Alternative PDF library
- **pymupdf**: Modern PyMuPDF interface

### PDF Extraction Methods
1. **pdfplumber**: Text-based extraction with page analysis
2. **fitz**: Bookmark-based TOC extraction
3. **Fallback**: Regex-based extraction when PDF libraries unavailable

## Semantic Analysis

### Section Categorization
- **overview**: Abstract, Summary, Overview
- **introduction**: Introduction, Background
- **methodology**: Method, Methodology, Approach
- **results**: Result, Finding, Analysis
- **conclusion**: Conclusion, Discussion
- **references**: Reference, Bibliography
- **content**: Other sections

### Importance Scoring
- Based on section level and title keywords
- Critical sections get higher scores
- Used for document structure analysis

## Integration with Orchestrators

### SimpleQAOrchestrator
```python
# Uses simple mode for basic TOC extraction
worker = TOCExtractorWorker(TOCMode.SIMPLE)
```

### EnhancedQAOrchestrator
```python
# Uses enhanced mode for PDF-aware extraction
worker = TOCExtractorWorker(TOCMode.ENHANCED)
```

### AdvancedQAOrchestrator
```python
# Uses advanced mode for AI-powered analysis
worker = TOCExtractorWorker(TOCMode.ADVANCED)
```

## Performance Considerations

### Mode Performance
- **Simple**: Fastest, minimal resource usage
- **Enhanced**: Moderate performance impact, PDF processing
- **Advanced**: Highest resource usage, AI/ML features

### Caching
The worker supports caching of TOC structures to improve performance for repeated analysis.

### Library Dependencies
- **pdfplumber**: Required for enhanced PDF processing
- **fitz**: Alternative PDF library
- **spacy**: Optional for advanced NLP features

## Error Handling

### Graceful Degradation
- Falls back to simpler extraction if PDF libraries unavailable
- Provides confidence scores to indicate reliability
- Includes recommendations for manual review when needed

### Common Error Scenarios
1. **Missing PDF Libraries**: Falls back to regex extraction
2. **Invalid PDF Format**: Returns basic extraction with warnings
3. **No TOC Found**: Returns empty structure with low confidence
4. **AI/ML Service Unavailable**: Falls back to enhanced mode

## Testing

### Unit Tests
```python
# Test each mode independently
simple_worker = TOCExtractorWorker(TOCMode.SIMPLE)
enhanced_worker = TOCExtractorWorker(TOCMode.ENHANCED)
advanced_worker = TOCExtractorWorker(TOCMode.ADVANCED)

# Test extraction accuracy
# Test hierarchy building
# Test error handling
```

### Integration Tests
```python
# Test with orchestrators
# Test with real PDF documents
# Test performance under load
```

## Best Practices

### Mode Selection
- **Use Simple mode** for basic TOC extraction
- **Use Enhanced mode** for PDF documents with bookmarks
- **Use Advanced mode** for research and academic papers

### Pattern Configuration
- Keep regex patterns updated for new document formats
- Test patterns with diverse document types
- Monitor extraction accuracy and adjust patterns

### Performance Optimization
- Cache frequently accessed TOC structures
- Use appropriate mode for the task complexity
- Consider worker pooling for high-volume scenarios

## Troubleshooting

### Common Issues
1. **Low Extraction Accuracy**: Check pattern coverage and document format
2. **Missing Page Numbers**: Verify PDF bookmark structure
3. **Hierarchy Issues**: Review section numbering consistency
4. **Performance Issues**: Consider mode downgrade or caching

### Debug Mode
```python
# Enable detailed logging
import logging
logging.getLogger('TOCExtractorWorker').setLevel(logging.DEBUG)
```

## Future Enhancements

### Planned Features
- **Machine Learning Models**: Improved pattern recognition
- **Natural Language Processing**: Better semantic understanding
- **Real-time Learning**: Adaptive extraction based on feedback
- **Integration APIs**: Connect with external TOC services

### Extensibility
The worker is designed for easy extension:
- Add new regex patterns
- Integrate new PDF libraries
- Extend semantic analysis capabilities
- Customize hierarchy building logic


