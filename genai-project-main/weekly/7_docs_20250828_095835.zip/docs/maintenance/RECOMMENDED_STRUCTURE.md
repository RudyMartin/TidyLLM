# Recommended File Structure for Deployment Resilience

## 🎯 Goals
- Eliminate relative import issues
- Consistent import patterns across environments
- Reduced nesting complexity
- Clear module boundaries

## 📁 Proposed Structure

```
src/
├── __init__.py                    # Main package init
├── main.py                        # Application entry point
├── config/                        # Configuration (top-level)
│   ├── __init__.py
│   ├── settings.py               # All configuration logic
│   ├── environments.py           # Environment-specific settings
│   └── credentials.py            # Credential management
├── core/                         # Core business logic
│   ├── __init__.py
│   ├── document_processor.py
│   ├── qa_engine.py
│   ├── llm_manager.py
│   └── report_generator.py
├── mcp/                          # MCP framework (flattened)
│   ├── __init__.py
│   ├── orchestrator.py           # Main orchestrator
│   ├── coordinator.py            # Coordination logic
│   ├── protocol.py               # Protocol definitions
│   ├── context.py                # Context management
│   └── workers.py                # Worker implementations
├── llm/                          # LLM integrations
│   ├── __init__.py
│   ├── gateway.py
│   ├── agents.py
│   └── mlflow_integration.py
├── api/                          # API layer
│   ├── __init__.py
│   ├── routes.py
│   ├── middleware.py
│   └── dashboard.py
├── personas/                     # Domain-specific personas
│   ├── __init__.py
│   ├── control_risks.py
│   └── sme_reviewer.py
├── utils/                        # Utilities
│   ├── __init__.py
│   ├── helpers.py
│   └── validators.py
└── ui/                          # UI components
    ├── __init__.py
    ├── dashboard.py
    ├── upload.py
    └── evaluation.py
```

## 🔧 Key Changes

### 1. Flattened Structure
- **Before**: `src/backend/mcp/orchestrators/qa_orchestrator.py`
- **After**: `src/mcp/orchestrator.py`

### 2. Consolidated Modules
- Combine related functionality into single files
- Reduce the number of small modules
- Clear separation of concerns

### 3. Top-Level Config
- Move all configuration to `src/config/`
- Single source of truth for settings
- Environment-agnostic configuration

## 📋 Migration Steps

1. **Phase 1**: Flatten MCP structure
2. **Phase 2**: Consolidate configuration
3. **Phase 3**: Update all imports to absolute
4. **Phase 4**: Add import validation tests
5. **Phase 5**: Update deployment scripts
