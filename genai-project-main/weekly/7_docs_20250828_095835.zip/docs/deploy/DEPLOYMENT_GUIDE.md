# Deployment Guide - Bibliography Builder Worker & Document Processing System

## 🚀 Quick Start Deployment

### **Prerequisites**
- Python 3.11+
- PostgreSQL 12+
- Conda or virtual environment
- Git

### **1. Environment Setup**
```bash
# Clone the repository
git clone <repository-url>
cd qaz_20250321

# Create and activate conda environment
conda create -n document_processing python=3.11
conda activate document_processing

# Install dependencies
pip install -r requirements_rag.txt
```

### **2. Database Setup**
```bash
# Install PostgreSQL (if not already installed)
# macOS: brew install postgresql
# Ubuntu: sudo apt-get install postgresql postgresql-contrib

# Create database
createdb document_processing

# Run schema scripts
psql -d document_processing -f database/schema_toc_tables.sql
psql -d document_processing -f database/schema_bibliography_tables.sql

# Load initial data
psql -d document_processing -f database/initial_bibliography_data.sql
```

### **3. Configuration**
```bash
# Create configuration file
cp config.example.yaml config.yaml

# Edit configuration
nano config.yaml
```

**Example Configuration:**
```yaml
database:
  host: localhost
  port: 5432
  database: document_processing
  user: postgres
  password: your_password

processing:
  max_workers: 4
  cache_size: 1000
  timeout: 300

workers:
  bibliography:
    enabled: true
    confidence_threshold: 0.7
  toc:
    enabled: true
    confidence_threshold: 0.6
  images:
    enabled: true
    max_image_size: 10485760
```

### **4. Test Installation**
```bash
# Run comprehensive tests
python scripts/test_bibliography_builder_worker.py
python scripts/test_toc_extractor_worker.py
python scripts/test_image_processing_worker.py

# Test database connection
python scripts/test_database_connection.py
```

## 🏗️ Production Deployment

### **Docker Deployment**

#### **Dockerfile**
```dockerfile
FROM python:3.11-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    postgresql-client \
    libpq-dev \
    gcc \
    && rm -rf /var/lib/apt/lists/*

# Set working directory
WORKDIR /app

# Copy requirements
COPY requirements_rag.txt .

# Install Python dependencies
RUN pip install --no-cache-dir -r requirements_rag.txt

# Copy application code
COPY src/ ./src/
COPY scripts/ ./scripts/
COPY database/ ./database/
COPY docs/ ./docs/

# Create non-root user
RUN useradd -m -u 1000 appuser && chown -R appuser:appuser /app
USER appuser

# Expose port
EXPOSE 8000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD python -c "import sys; sys.exit(0)"

# Default command
CMD ["python", "-m", "src.backend.mcp.orchestrators.document_processing_orchestrator"]
```

#### **Docker Compose**
```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: document_processing
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: secure_password
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database:/docker-entrypoint-initdb.d
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres"]
      interval: 10s
      timeout: 5s
      retries: 5

  document_processor:
    build: .
    environment:
      DATABASE_URL: postgresql://postgres:secure_password@postgres:5432/document_processing
      MAX_WORKERS: 4
      LOG_LEVEL: INFO
    volumes:
      - ./input:/app/input
      - ./output:/app/output
    depends_on:
      postgres:
        condition: service_healthy
    ports:
      - "8000:8000"
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

### **Kubernetes Deployment**

#### **Namespace**
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: document-processing
```

#### **ConfigMap**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: document-processor-config
  namespace: document-processing
data:
  config.yaml: |
    database:
      host: postgres-service
      port: 5432
      database: document_processing
      user: postgres
      password: ${POSTGRES_PASSWORD}
    
    processing:
      max_workers: 4
      cache_size: 1000
      timeout: 300
```

#### **Secret**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: postgres-secret
  namespace: document-processing
type: Opaque
data:
  password: <base64-encoded-password>
```

#### **PostgreSQL StatefulSet**
```yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: postgres
  namespace: document-processing
spec:
  serviceName: postgres-service
  replicas: 1
  selector:
    matchLabels:
      app: postgres
  template:
    metadata:
      labels:
        app: postgres
    spec:
      containers:
      - name: postgres
        image: postgres:15
        env:
        - name: POSTGRES_DB
          value: document_processing
        - name: POSTGRES_USER
          value: postgres
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-secret
              key: password
        ports:
        - containerPort: 5432
        volumeMounts:
        - name: postgres-storage
          mountPath: /var/lib/postgresql/data
  volumeClaimTemplates:
  - metadata:
      name: postgres-storage
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 10Gi
```

#### **Document Processor Deployment**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: document-processor
  namespace: document-processing
spec:
  replicas: 3
  selector:
    matchLabels:
      app: document-processor
  template:
    metadata:
      labels:
        app: document-processor
    spec:
      containers:
      - name: document-processor
        image: document-processor:latest
        env:
        - name: DATABASE_URL
          value: postgresql://postgres:$(POSTGRES_PASSWORD)@postgres-service:5432/document_processing
        - name: POSTGRES_PASSWORD
          valueFrom:
            secretKeyRef:
              name: postgres-secret
              key: password
        ports:
        - containerPort: 8000
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

#### **Services**
```yaml
apiVersion: v1
kind: Service
metadata:
  name: postgres-service
  namespace: document-processing
spec:
  selector:
    app: postgres
  ports:
  - port: 5432
    targetPort: 5432
---
apiVersion: v1
kind: Service
metadata:
  name: document-processor-service
  namespace: document-processing
spec:
  selector:
    app: document-processor
  ports:
  - port: 8000
    targetPort: 8000
  type: LoadBalancer
```

## 🔧 Configuration Management

### **Environment Variables**
```bash
# Database
DATABASE_URL=postgresql://user:pass@host:port/db
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=document_processing
POSTGRES_USER=postgres
POSTGRES_PASSWORD=secure_password

# Processing
MAX_WORKERS=4
CACHE_SIZE=1000
TIMEOUT=300
LOG_LEVEL=INFO

# Workers
BIBLIOGRAPHY_ENABLED=true
BIBLIOGRAPHY_CONFIDENCE_THRESHOLD=0.7
TOC_ENABLED=true
TOC_CONFIDENCE_THRESHOLD=0.6
IMAGES_ENABLED=true
MAX_IMAGE_SIZE=10485760
```

### **Configuration File Structure**
```yaml
# config.yaml
database:
  host: ${POSTGRES_HOST:-localhost}
  port: ${POSTGRES_PORT:-5432}
  database: ${POSTGRES_DB:-document_processing}
  user: ${POSTGRES_USER:-postgres}
  password: ${POSTGRES_PASSWORD}

processing:
  max_workers: ${MAX_WORKERS:-4}
  cache_size: ${CACHE_SIZE:-1000}
  timeout: ${TIMEOUT:-300}
  log_level: ${LOG_LEVEL:-INFO}

workers:
  bibliography:
    enabled: ${BIBLIOGRAPHY_ENABLED:-true}
    confidence_threshold: ${BIBLIOGRAPHY_CONFIDENCE_THRESHOLD:-0.7}
    patterns:
      reference_headers:
        - "^references?$"
        - "^bibliography$"
        - "^works\\s+cited$"
  
  toc:
    enabled: ${TOC_ENABLED:-true}
    confidence_threshold: ${TOC_CONFIDENCE_THRESHOLD:-0.6}
    max_depth: 10
  
  images:
    enabled: ${IMAGES_ENABLED:-true}
    max_image_size: ${MAX_IMAGE_SIZE:-10485760}
    supported_formats:
      - "jpeg"
      - "png"
      - "tiff"

cache:
  redis:
    enabled: false
    host: localhost
    port: 6379
    db: 0
  
  memory:
    enabled: true
    max_size: 1000
    ttl: 3600

monitoring:
  prometheus:
    enabled: true
    port: 9090
  
  health_check:
    enabled: true
    port: 8000
    path: /health
```

## 📊 Monitoring & Observability

### **Health Checks**
```python
# health_check.py
from flask import Flask, jsonify
import psycopg2
import redis

app = Flask(__name__)

@app.route('/health')
def health_check():
    status = {
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'services': {}
    }
    
    # Check database
    try:
        conn = psycopg2.connect(os.getenv('DATABASE_URL'))
        conn.close()
        status['services']['database'] = 'healthy'
    except Exception as e:
        status['services']['database'] = f'unhealthy: {e}'
        status['status'] = 'unhealthy'
    
    # Check Redis
    try:
        r = redis.Redis.from_url(os.getenv('REDIS_URL', 'redis://localhost:6379'))
        r.ping()
        status['services']['redis'] = 'healthy'
    except Exception as e:
        status['services']['redis'] = f'unhealthy: {e}'
    
    return jsonify(status), 200 if status['status'] == 'healthy' else 503

@app.route('/ready')
def readiness_check():
    # Similar to health check but for readiness
    return health_check()
```

### **Prometheus Metrics**
```python
# metrics.py
from prometheus_client import Counter, Histogram, Gauge
import time

# Metrics
PROCESSING_TIME = Histogram('document_processing_duration_seconds', 'Time spent processing documents')
DOCUMENTS_PROCESSED = Counter('documents_processed_total', 'Total documents processed')
CITATIONS_EXTRACTED = Counter('citations_extracted_total', 'Total citations extracted')
TOC_SECTIONS_EXTRACTED = Counter('toc_sections_extracted_total', 'Total TOC sections extracted')
IMAGES_EXTRACTED = Counter('images_extracted_total', 'Total images extracted')
PROCESSING_ERRORS = Counter('processing_errors_total', 'Total processing errors')
CACHE_HITS = Counter('cache_hits_total', 'Total cache hits')
CACHE_MISSES = Counter('cache_misses_total', 'Total cache misses')

# Gauges
ACTIVE_WORKERS = Gauge('active_workers', 'Number of active workers')
QUEUE_SIZE = Gauge('processing_queue_size', 'Number of documents in processing queue')
CACHE_SIZE = Gauge('cache_size', 'Number of items in cache')
```

### **Logging Configuration**
```python
# logging_config.py
import logging
import logging.handlers
import os

def setup_logging():
    log_level = os.getenv('LOG_LEVEL', 'INFO').upper()
    
    # Create formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create handlers
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    file_handler = logging.handlers.RotatingFileHandler(
        'logs/document_processor.log',
        maxBytes=10485760,  # 10MB
        backupCount=5
    )
    file_handler.setFormatter(formatter)
    
    # Setup root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, log_level))
    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)
    
    # Setup specific loggers
    loggers = [
        'backend.mcp.workers.bibliography_builder_worker',
        'backend.mcp.workers.toc_extractor_worker',
        'backend.mcp.workers.image_processing_worker',
        'backend.mcp.orchestrators.document_processing_orchestrator'
    ]
    
    for logger_name in loggers:
        logger = logging.getLogger(logger_name)
        logger.setLevel(getattr(logging, log_level))
```

## 🔒 Security Considerations

### **Database Security**
```sql
-- Create dedicated user with limited privileges
CREATE USER document_processor WITH PASSWORD 'secure_password';

-- Grant necessary permissions
GRANT CONNECT ON DATABASE document_processing TO document_processor;
GRANT USAGE ON SCHEMA public TO document_processor;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO document_processor;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO document_processor;

-- Enable SSL
ALTER SYSTEM SET ssl = on;
ALTER SYSTEM SET ssl_cert_file = '/path/to/server.crt';
ALTER SYSTEM SET ssl_key_file = '/path/to/server.key';
```

### **Network Security**
```bash
# Firewall rules
sudo ufw allow 5432/tcp  # PostgreSQL
sudo ufw allow 8000/tcp  # Application
sudo ufw allow 9090/tcp  # Prometheus
sudo ufw enable

# SSL/TLS configuration
# Use Let's Encrypt for production certificates
```

### **Application Security**
```python
# security.py
import secrets
import hashlib
from cryptography.fernet import Fernet

class SecurityManager:
    def __init__(self):
        self.secret_key = Fernet.generate_key()
        self.cipher_suite = Fernet(self.secret_key)
    
    def encrypt_sensitive_data(self, data: str) -> bytes:
        return self.cipher_suite.encrypt(data.encode())
    
    def decrypt_sensitive_data(self, encrypted_data: bytes) -> str:
        return self.cipher_suite.decrypt(encrypted_data).decode()
    
    def hash_password(self, password: str) -> str:
        salt = secrets.token_hex(16)
        hash_obj = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return salt + hash_obj.hex()
```

## 📈 Performance Tuning

### **Database Optimization**
```sql
-- Performance tuning
ALTER SYSTEM SET shared_buffers = '256MB';
ALTER SYSTEM SET effective_cache_size = '1GB';
ALTER SYSTEM SET maintenance_work_mem = '64MB';
ALTER SYSTEM SET checkpoint_completion_target = 0.9;
ALTER SYSTEM SET wal_buffers = '16MB';
ALTER SYSTEM SET default_statistics_target = 100;

-- Restart PostgreSQL to apply changes
SELECT pg_reload_conf();
```

### **Application Optimization**
```python
# performance.py
import asyncio
import aiofiles
from concurrent.futures import ThreadPoolExecutor
import multiprocessing

class PerformanceOptimizer:
    def __init__(self):
        self.max_workers = multiprocessing.cpu_count()
        self.thread_pool = ThreadPoolExecutor(max_workers=self.max_workers)
    
    async def process_documents_async(self, document_paths: List[str]):
        tasks = []
        for path in document_paths:
            task = asyncio.create_task(self.process_single_document(path))
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        return results
    
    def optimize_memory_usage(self):
        import gc
        gc.collect()
        
        # Clear caches
        for worker in self.workers.values():
            if hasattr(worker, 'clear_cache'):
                worker.clear_cache()
```

## 🚨 Troubleshooting

### **Common Issues**

#### **Database Connection Issues**
```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check connection
psql -h localhost -U postgres -d document_processing

# Check logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

#### **Memory Issues**
```bash
# Monitor memory usage
htop
free -h

# Check for memory leaks
python -m memory_profiler scripts/test_bibliography_builder_worker.py
```

#### **Performance Issues**
```bash
# Profile application
python -m cProfile -o profile.stats scripts/test_bibliography_builder_worker.py

# Analyze profile
python -c "import pstats; p = pstats.Stats('profile.stats'); p.sort_stats('cumulative').print_stats(20)"
```

### **Debug Mode**
```bash
# Enable debug logging
export LOG_LEVEL=DEBUG

# Run with debug flags
python -u scripts/test_bibliography_builder_worker.py --debug --verbose

# Check worker status
python -c "
from backend.mcp.workers.bibliography_builder_worker import BibliographyBuilderWorker
worker = BibliographyBuilderWorker()
print(worker.get_worker_status())
"
```

## 📋 Deployment Checklist

### **Pre-Deployment**
- [ ] Environment setup completed
- [ ] Dependencies installed
- [ ] Database schema created
- [ ] Configuration files updated
- [ ] Security settings configured
- [ ] Monitoring setup completed

### **Deployment**
- [ ] Database migrations run
- [ ] Application deployed
- [ ] Health checks passing
- [ ] Load testing completed
- [ ] Performance benchmarks met
- [ ] Security scan passed

### **Post-Deployment**
- [ ] Monitoring alerts configured
- [ ] Backup strategy implemented
- [ ] Documentation updated
- [ ] Team training completed
- [ ] Support procedures established

---

**Last Updated**: December 2024  
**Version**: 1.0  
**Maintainer**: AI Assistant  
**Status**: ✅ **Production Ready**
