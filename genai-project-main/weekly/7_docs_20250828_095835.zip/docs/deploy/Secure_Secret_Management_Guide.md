# Secure Secret Management Guide

## 🛡️ How to Handle Secrets Safely

This guide shows you how to work with passwords and API keys without putting them in files that could be accidentally shared.

## ❌ What NOT to Do

- ❌ Never put real passwords in files that get committed to git
- ❌ Never share API keys in chat messages or emails
- ❌ Never use the same passwords for test and live servers
- ❌ Never store secrets in local files for production

## ✅ What TO Do

### For Development (Your Computer)

#### Option 1: Environment Variables (Recommended)
```bash
# Set your passwords as environment variables
export GOOGLE_API_KEY="your-actual-key-here"
export COHERE_API_KEY="your-actual-key-here"
export AWS_ACCESS_KEY_ID="your-actual-key-here"
export AWS_SECRET_ACCESS_KEY="your-actual-secret-here"

# Then run your application
python your_app.py
```

#### Option 2: Local .env File (Safe for Development)
```bash
# Create a .env file in your project root (NOT in environ_settings/)
echo "GOOGLE_API_KEY=your-actual-key-here" > .env
echo "COHERE_API_KEY=your-actual-key-here" >> .env

# Make sure .env is in your .gitignore
echo ".env" >> .gitignore
```

### For Test Server (Staging)

#### Option 1: Kubernetes Secrets
```bash
# Create secrets for the test server
kubectl create secret generic vectorqa-staging-secrets \
  --from-literal=GOOGLE_API_KEY="your-staging-key" \
  --from-literal=COHERE_API_KEY="your-staging-key" \
  --from-literal=AWS_ACCESS_KEY_ID="your-staging-key" \
  --from-literal=AWS_SECRET_ACCESS_KEY="your-staging-secret"

# Apply the secrets to your test server
kubectl -n staging apply -f deploy/kubernetes/secret.yaml
```

#### Option 2: AWS Secrets Manager
```bash
# Store secrets in AWS Secrets Manager
aws secretsmanager create-secret \
  --name "vectorqa/staging" \
  --secret-string '{"GOOGLE_API_KEY":"your-staging-key","COHERE_API_KEY":"your-staging-key"}'
```

### For Live Server (Production)

#### Option 1: Kubernetes Secrets (Recommended)
```bash
# Create secrets for the live server
kubectl create secret generic vectorqa-production-secrets \
  --from-literal=GOOGLE_API_KEY="your-production-key" \
  --from-literal=COHERE_API_KEY="your-production-key" \
  --from-literal=AWS_ACCESS_KEY_ID="your-production-key" \
  --from-literal=AWS_SECRET_ACCESS_KEY="your-production-secret"

# Apply the secrets to your live server
kubectl -n prod apply -f deploy/kubernetes/secret.yaml
```

#### Option 2: AWS Secrets Manager
```bash
# Store secrets in AWS Secrets Manager
aws secretsmanager create-secret \
  --name "vectorqa/production" \
  --secret-string '{"GOOGLE_API_KEY":"your-production-key","COHERE_API_KEY":"your-production-key"}'
```

## 🔐 How to Get New API Keys

### Google API Key
1. Go to https://console.cloud.google.com/apis/credentials
2. Click "Create Credentials" → "API Key"
3. Copy the new key
4. Set restrictions (limit to your domain/IP)

### Cohere API Key
1. Go to https://dashboard.cohere.ai/api-keys
2. Click "Create API Key"
3. Copy the new key
4. Set usage limits

### HuggingFace Token
1. Go to https://huggingface.co/settings/tokens
2. Click "New token"
3. Copy the new token
4. Set appropriate permissions

## 📋 Security Checklist

Before starting work:
- [ ] Check that `.gitignore` includes `environ_settings/` and `.env`
- [ ] Use environment variables or secure secret management
- [ ] Never commit files with real passwords
- [ ] Use different keys for test and live servers
- [ ] Ask team leader for production keys

## 🚨 Emergency Procedures

If you accidentally expose secrets:

1. **Immediately** revoke/regenerate the exposed keys
2. **Remove** the files from git tracking
3. **Clean up** any local files with secrets
4. **Notify** your team leader
5. **Review** what was exposed and assess impact

## 📞 Getting Help

- **Ask your team leader** for production API keys
- **Contact DevOps team** for help with Kubernetes secrets
- **Contact security team** if you suspect a breach
- **Use the example files** in `deploy/config/` for reference

## 🔄 Regular Security Tasks

- **Weekly**: Check that no secrets are in git
- **Monthly**: Rotate API keys
- **Quarterly**: Review access permissions
- **Annually**: Security audit

---

**Remember: Security is everyone's responsibility. When in doubt, ask for help!**
