# Quick Reference Guide - Keep This on Your Desk

## Your Computer (Local) - Test Here First

```bash
# Start the application
cd deploy/docker
docker compose up --build

# Open in browser
http://localhost:8080

# Stop the application
CTRL+C
docker compose down
```

## Test Server (Staging) - Ask Team Leader for Help

```bash
# Check if it's working
kubectl -n staging get pods

# See error messages
kubectl -n staging logs deploy/vectorqa --tail=100

# Go back to old version if broken
kubectl -n staging rollout undo deployment/vectorqa
```

## Live Server (Production) - Be Very Careful!

```bash
# Check if it's working
kubectl -n prod get pods

# See error messages
kubectl -n prod logs deploy/vectorqa --tail=100

# Go back to old version if broken
kubectl -n prod rollout undo deployment/vectorqa
```

## Common Problems

| Problem | What to do |
|---------|-----------|
| Application won't start | Check logs: `kubectl -n <ns> logs deploy/vectorqa` |
| Website doesn't work | Check if port 8080 is correct |
| Wrong passwords | Ask team leader for correct passwords |
| Can't download app | Check image name and permissions |

## Important Safety Rules

1. **Test on your computer first**
2. **Use different passwords for test and live servers**
3. **Ask for help if you're not sure**
4. **Never put real passwords in example files**

## Need Help?

- Ask your team leader
- Check the logs for error messages
- Make sure all password files are correct
- Read "Secure_Secret_Management_Guide.md" for security best practices
