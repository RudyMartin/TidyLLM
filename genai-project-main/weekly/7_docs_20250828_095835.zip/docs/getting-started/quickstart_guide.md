# 🚀 Quick Start Guide - VectorQA Sage

## What is this?
A simple app that helps you upload documents and get AI-powered reports. Think of it like having a smart assistant that reads your files and tells you what's important.

## 🎯 What you'll see:
- **Upload files** (PDF, Word, Excel, etc.)
- **AI reads your documents** 
- **Get a report** with key information

## 📋 Before you start:
Make sure you have Python installed on your computer.

## 🚀 How to start the app:

### Option 1: Easy Way (Recommended)
```bash
python3 run_qa_demo.py
```

### Option 2: If Option 1 doesn't work
```bash
cd src
streamlit run qa_demo.py
```

## 🌐 What happens next:
1. Your web browser will open automatically
2. You'll see the app at: `http://localhost:8501`
3. The app will look like a simple webpage

## 📁 How to use it:

### Step 1: Upload Files
- Click "Browse files" 
- Select any documents you want to analyze
- You can upload multiple files at once

### Step 2: Fill in Review ID
- **Review ID**: Enter a review number in format "REVXXXXX" (example: "REV00001")
- This gives your review a unique identifier

### Step 3: Process Documents
- Click the big "🚀 Process Documents" button
- Wait a few seconds while AI reads your files
- The app will automatically fill in other details for you

### Step 4: Check Results
- Look at the information the AI found
- If something looks wrong, you can edit it
- Click "📄 Generate QA HealthCheck Report" to get your final report

## ✅ Success!
You'll get a PDF report with all the important information from your documents.

## 🆘 If something goes wrong:
- Make sure Python is installed
- Try closing and reopening the app
- Check that your files aren't too large

## 📞 Need help?
The app is designed to be simple - just follow the steps above and you should be fine!

**📚 Want to learn more?** Check out our [📖 Documentation Walkthrough](docs/walkthrough/README.md) for detailed guides and technical information.

---

**That's it!** No complicated settings, no confusing options. Just upload, process, and get your report. 🎉
