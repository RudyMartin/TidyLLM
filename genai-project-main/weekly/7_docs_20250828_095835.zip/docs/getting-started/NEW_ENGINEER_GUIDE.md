# 🚀 Complete Guide for New Engineers & Data Scientists

## 👋 Welcome! This Guide is For You

If you're new to engineering, data science, or this project, this guide will help you get started safely and easily. We've organized everything you need to know in one place.

---

## 📋 What You Need to Know (Quick Overview)

### 🎯 Your Goal
Put the VectorQA Sage application on different computers:
- **Your computer** (for testing and development)
- **Test server** (for testing with your team)
- **Live server** (for real users)

### 🛡️ Security First
- **Never put real passwords in files that get shared**
- **Always ask your team leader for help with production**
- **Use different passwords for test and live servers**

---

## 🚨 IMPORTANT: Security Warning

**⚠️ CRITICAL**: The `environ_settings/` folder contains real passwords and is dangerous. 

**✅ SAFE**: The `deploy/` folder contains examples and instructions and is safe to use.

| Folder | Contains | Safe? | What to do |
|--------|----------|-------|------------|
| `environ_settings/` | Real passwords | ❌ NO | Avoid this folder |
| `deploy/` | Examples & instructions | ✅ YES | Use this folder |

---

## 📁 What's in Each Folder?

### ✅ SAFE FOLDERS (Use These)
| Folder | What it contains | When to use |
|--------|------------------|-------------|
| `deploy/` | Deployment scripts and Docker files | ✅ Safe to use |
| `docs/` | Documentation and guides | ✅ Safe to read |
| `src/` | Application code | ✅ Safe to work with |

### 🚨 DANGEROUS FOLDERS (Avoid These)
| Folder | What it contains | Why it's dangerous |
|--------|------------------|-------------------|
| `environ_settings/` | Real passwords and secrets | ❌ Contains actual API keys |

---

## 🎯 Step-by-Step Instructions

### Step 1: Set Up Your Computer (Local Development)

#### 1.1 Create Your Settings Files
```bash
# Go to the backend config folder
cd src/backend/config

# Create your local settings file from the template
cp credentials_template.env credentials.local.env
```

#### 1.2 Edit Your Files
Open the `credentials.local.env` file you just created and replace the example text with your real information:

```env
# Replace these with your real information
OPENAI_API_KEY=your-real-api-key-here
AWS_ACCESS_KEY_ID=your-real-access-key
AWS_SECRET_ACCESS_KEY=your-real-secret-key
```

#### 1.3 Run the Application
```bash
# Start the application
cd deploy
docker compose up --build

# Open in your web browser
# Go to: http://localhost:8080

# To stop the application
# Press CTRL+C, then type: docker compose down
```

### Step 2: Test Server (Staging) - Ask Team Leader for Help

**⚠️ WARNING**: You need help from your team leader for this step.

```bash
# Check if it's working
kubectl -n staging get pods

# See error messages if something is wrong
kubectl -n staging logs deploy/vectorqa --tail=100

# Go back to old version if broken
kubectl -n staging rollout undo deployment/vectorqa
```

### Step 3: Live Server (Production) - Be Very Careful!

**🚨 DANGER**: This affects real users. Only do this with your team leader's permission.

```bash
# Check if it's working
kubectl -n prod get pods

# See error messages if something is wrong
kubectl -n prod logs deploy/vectorqa --tail=100

# Go back to old version if broken
kubectl -n prod rollout undo deployment/vectorqa
```

---

## 🔧 Common Problems and Solutions

| Problem | What it means | How to fix |
|---------|---------------|------------|
| Application won't start | The program can't run | Check logs: `kubectl -n <ns> logs deploy/vectorqa` |
| Website doesn't work | Can't access the app | Check if port 8080 is correct |
| Wrong passwords | API keys don't work | Ask team leader for correct passwords |
| Can't download app | Image not found | Check image name and permissions |

---

## 🔐 How to Handle Passwords Safely

### ❌ What NOT to Do
- Never put real passwords in files that get committed to git
- Never share API keys in chat messages or emails
- Never use the same passwords for test and live servers

### ✅ What TO Do

#### For Your Computer (Development)
```bash
# Option 1: Environment variables (recommended)
export OPENAI_API_KEY="your-real-key-here"
export AWS_ACCESS_KEY_ID="your-real-key-here"

# Option 2: Local .env file (make sure it's in .gitignore)
echo "OPENAI_API_KEY=your-real-key-here" > .env
echo ".env" >> .gitignore
```

#### For Test/Live Servers
Ask your team leader to help you set up:
- Kubernetes secrets
- AWS Secrets Manager
- Environment variables

---

## 📞 Getting Help

### When to Ask for Help
- **Before touching production** (live server)
- **If passwords don't work**
- **If the application won't start**
- **If you're not sure about security**

### Who to Ask
1. **Your team leader** - For most questions
2. **DevOps team** - For server and deployment issues
3. **Security team** - For password and access issues

### How to Ask for Help
1. **Describe what you're trying to do**
2. **Show the error message** (copy and paste it)
3. **Tell them what you've already tried**
4. **Ask specific questions**

---

## 📚 Additional Resources

### Quick Reference (Keep This Handy)
- **Your computer**: `docker compose up --build` then http://localhost:8080
- **Check if working**: `kubectl -n <ns> get pods`
- **See errors**: `kubectl -n <ns> logs deploy/vectorqa --tail=100`
- **Go back**: `kubectl -n <ns> rollout undo deployment/vectorqa`

### Important Files to Know
- **[Quick Reference Guide](../deploy/Quick Reference Guide.md)** - One-page desk reference
- **[Secure_Secret_Management_Guide.md](../deploy/Secure_Secret_Management_Guide.md)** - Security best practices

### Safety Checklist
- [ ] I'm using the `deploy/` folder (safe) not `environ_settings/` (dangerous)
- [ ] I'm not putting real passwords in files that get shared
- [ ] I'm asking for help before touching production
- [ ] I'm using different passwords for test and live servers
- [ ] I know who to ask for help

---

## 🎉 You're Ready!

You now have everything you need to:
1. **Set up the application on your computer**
2. **Work safely with passwords**
3. **Know when to ask for help**
4. **Avoid common mistakes**

**Remember**: It's better to ask for help than to make a mistake. Your team wants you to succeed!

---

## 🚨 Emergency Contacts

If something goes wrong:
1. **Stop what you're doing**
2. **Don't panic**
3. **Contact your team leader immediately**
4. **Describe what happened**
5. **Follow their instructions**

**You've got this!** 🚀
