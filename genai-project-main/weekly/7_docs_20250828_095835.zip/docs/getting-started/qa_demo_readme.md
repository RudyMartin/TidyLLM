# QA Document Processing Demo

## Overview

This demo showcases a QA document processing workflow using the MCP (Model Context Protocol) framework, DSPy for document analysis, and AWS Bedrock for AI processing. The demo allows users to upload documents, extract key fields, and generate QA HealthCheck reports.

## 🎯 Demo Features

### **User Interface**
- **File Upload**: Support for multiple file types (PDF, DOCX, TXT, CSV, XLSX)
- **Pre-filled Configuration**: Team, Process, and Reviewer dropdowns
- **User Input Fields**: Review ID, Model Type, Risk Tier
- **Real-time Processing**: Live status updates and progress tracking

### **Backend Processing**
- **MCP Framework**: Uses the complete MCP architecture we built
- **DSPy Integration**: Document processing and field extraction
- **AWS Bedrock**: AI-powered document analysis
- **S3 Storage**: Organized file storage with proper folder structure

### **Key Fields Extracted**
- Review ID
- Model Type
- Risk Tier
- Model ID
- Model Name
- Version
- Authors
- Date (mm-dd-yyyy format)
- Validation Type

## 🚀 Quick Start

### **1. Install Dependencies**
```bash
pip install -r requirements_demo.txt
```

### **2. Run the Demo**
```bash
python3 run_qa_demo.py
```

### **3. Access the Demo**
Open your browser and go to: `http://localhost:8501`

## 📋 Demo Workflow

### **Step 1: Upload Documents**
1. Click "Browse files" to select one or more documents
2. Supported formats: PDF, DOCX, TXT, CSV, XLSX
3. No file size limits

### **Step 2: Configure Settings**
1. **Team**: Pre-selected "QA Team 1"
2. **Process**: Pre-selected "QA Validation Review"
3. **Reviewer**: Pre-selected "Alex"
4. **Review ID**: Enter a unique review identifier
5. **Model Type**: Enter the type of model being reviewed
6. **Risk Tier**: Select from Low/Medium/High/Critical

### **Step 3: Process Documents**
1. Click "🚀 Process Documents" button
2. Watch real-time processing status
3. View extracted fields from documents

### **Step 4: Review and Generate Report**
1. Review extracted fields for accuracy
2. Edit any incorrect information
3. Click "📄 Generate QA HealthCheck Report"
4. Download the generated PDF report

## 🏗️ Architecture

### **MCP Framework Integration**
```
QA Orchestrator
├── S3 Upload Coordinator
├── DSPy Extraction Coordinator
└── Report Generation Coordinator
    ├── Document Processing Workers
    ├── Field Extraction Workers
    └── Report Generation Workers
```

### **S3 Storage Structure**
```
{s3_root}/usecase-qa/teams/{team_num}/{process_name}/{qa_reviewer_name}/{review_id}/{filename}
```

Example:
```
s3://example-bucket-name/usecase-qa/teams/QA Team 1/QA Validation Review/Alex/REV-001/document.pdf
```

## 🔧 Configuration

### **Environment Variables**
```bash
# AWS Configuration
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key
AWS_DEFAULT_REGION=us-east-1

# Bedrock Configuration
BEDROCK_MODEL_ID=anthropic.claude-3-sonnet-20240229-v1:0

# S3 Configuration
S3_BUCKET_NAME=your-qa-documents-bucket
S3_ROOT_PATH=usecase-qa
```

### **Demo Configuration**
- **Default Team**: QA Team 1
- **Default Process**: QA Validation Review
- **Default Reviewer**: Alex
- **Supported File Types**: PDF, DOCX, TXT, CSV, XLSX
- **Processing Timeout**: 300 seconds

## 📊 QA HealthCheck Report

### **Report Sections**
1. **Executive Summary**
   - Document overview
   - Key findings
   - Risk assessment

2. **Checklist Items**
   - Based on `checklist_categories-config.json`
   - Compliance verification
   - Quality metrics

### **Report Format**
- **Output**: PDF format
- **Storage**: S3 bucket
- **Naming**: `qa_healthcheck_{timestamp}.pdf`

## 🧪 Testing

### **Test Files**
Create test documents with the following content:
```
Model Validation Report

Model ID: ML-2024-001
Model Name: Document Classifier v2.1
Version: 2.1.0
Authors: Dr. Smith, Dr. Johnson
Date: 08-21-2024
Validation Type: Comprehensive Review
Risk Tier: Medium
Model Type: Machine Learning
```

### **Test Scenarios**
1. **Single Document**: Upload one PDF file
2. **Multiple Documents**: Upload multiple files of different types
3. **Field Extraction**: Verify all required fields are extracted
4. **Report Generation**: Test PDF report creation
5. **Error Handling**: Test with invalid files

## 🚀 AWS SageMaker Deployment

### **Deployment Steps**
1. **Create SageMaker Space**
   - Choose Python 3.10 environment
   - Select appropriate instance type

2. **Upload Code**
   - Upload `src/` directory
   - Upload `requirements_demo.txt`

3. **Install Dependencies**
   ```bash
   pip install -r requirements_demo.txt
   ```

4. **Configure AWS Credentials**
   - Set up IAM roles for S3 and Bedrock access
   - Configure environment variables

5. **Launch Application**
   ```bash
   streamlit run src/qa_demo.py --server.port 8501
   ```

### **SageMaker Configuration**
- **Instance Type**: ml.t3.medium (for demo)
- **Storage**: 5GB minimum
- **Networking**: VPC with S3 and Bedrock access

## 🔍 Troubleshooting

### **Common Issues**
1. **Import Errors**: Ensure all dependencies are installed
2. **AWS Permissions**: Verify S3 and Bedrock access
3. **File Upload**: Check file size and format
4. **Processing Timeout**: Increase timeout for large files

### **Debug Mode**
Enable debug logging:
```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

## 📈 Future Enhancements

### **Planned Features**
1. **Real DSPy Integration**: Replace mock processing with actual DSPy signatures
2. **Advanced Document Processing**: Support for more file types
3. **Custom Checklists**: Dynamic checklist configuration
4. **Batch Processing**: Process multiple documents simultaneously
5. **Report Templates**: Customizable report formats

### **Integration Points**
1. **PostgreSQL Database**: Store processing results
2. **Admin Interface**: Folder management and user administration
3. **Notification System**: Email/SMS alerts for completed reports
4. **Analytics Dashboard**: Processing metrics and insights

## 📞 Support

For questions or issues with the demo:
1. Check the troubleshooting section
2. Review the MCP framework documentation
3. Check AWS service status
4. Contact the development team

**📚 Additional Resources:**
- **[📖 Documentation Walkthrough](docs/walkthrough/README.md)** - Complete documentation guide
- **[🚀 Quick Start Guide](QUICKSTART_GUIDE.md)** - Simple user guide
- **[📋 System Design](DESIGN.md)** - Technical architecture details

---

**Demo Version**: 1.0
**Last Updated**: August 21, 2024
**Status**: Ready for Monday Demo
