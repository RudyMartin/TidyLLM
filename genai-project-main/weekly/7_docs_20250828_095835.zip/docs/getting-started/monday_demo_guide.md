# 🎯 Monday Demo Guide - QA Document Processing with Prompts

## 📋 **Demo Overview**

**What**: QA Document Processing Demo with Custom Prompts  
**When**: Monday  
**Duration**: 10-15 minutes  
**Goal**: Showcase the new prompt functionality and QA processing capabilities

## 🚀 **Demo Setup**

### **Prerequisites**
```bash
# 1. Install dependencies
pip install -r requirements_demo.txt

# 2. Run the demo
streamlit run src/qa_demo.py
```

### **Demo Files Ready**
- ✅ `test_prompt.md` - Sample prompt file
- ✅ `demo_document.txt` - Sample document for processing
- ✅ All imports working
- ✅ Core functionality tested

## 🎬 **Demo Script**

### **Opening (2 minutes)**
```
"Today I'm demonstrating our enhanced QA Document Processing system with custom prompt functionality. This system allows users to provide specific instructions for how documents should be analyzed and processed."
```

### **Step 1: Show the Interface (2 minutes)**
1. **Open the Streamlit app**
2. **Point out key features:**
   - Custom prompt text area
   - File upload with .md support
   - Review ID validation
   - Sidebar configuration

### **Step 2: Upload Files (3 minutes)**
1. **Upload test_prompt.md**
   - Show how it's detected as a prompt file
   - Display the extracted prompt content
   - Explain the automatic detection logic

2. **Upload demo_document.txt**
   - Show it's treated as a regular document
   - Point out the file type separation

3. **Enter a custom prompt**
   - Type: "Focus on risk assessment and compliance validation"
   - Show how it combines with the .md prompt

### **Step 3: Process Documents (3 minutes)**
1. **Enter Review ID**: `REV00001`
2. **Click "Process Documents"**
3. **Show the combined prompt display**
4. **Demonstrate the processing workflow**

### **Step 4: Show Results (3 minutes)**
1. **Display extracted fields**
2. **Show QA assessment results**
3. **Generate QA HealthCheck Report**
4. **Highlight the prompt influence on processing**

### **Closing (2 minutes)**
```
"This demonstrates how our system can handle both custom prompts and structured prompt files, providing flexible and powerful QA processing capabilities. The regular QA orchestrator automatically processes documents according to the provided instructions."
```

## 🎯 **Key Features to Highlight**

### **1. Dual Prompt Sources**
- ✅ Custom prompt text area
- ✅ .md file prompt extraction
- ✅ Automatic prompt combination

### **2. Smart File Detection**
- ✅ Automatically detects prompt files
- ✅ Separates prompts from documents
- ✅ Clear visual distinction

### **3. Regular Orchestrator Integration**
- ✅ Uses the standard QA orchestrator
- ✅ Passes combined prompts through
- ✅ Maintains existing workflow

### **4. User-Friendly Interface**
- ✅ Intuitive file upload
- ✅ Real-time validation
- ✅ Clear status indicators

## 🔧 **Technical Details (If Asked)**

### **Architecture**
```
Streamlit UI → File Upload → Prompt Extraction → QA Orchestrator → Processing → Results
```

### **Key Components**
- `src/qa_demo.py` - Main Streamlit interface
- `src/backend/mcp/orchestrators/qa_orchestrator.py` - Processing engine
- `test_prompt.md` - Sample prompt file
- `demo_document.txt` - Sample document

### **Prompt Processing Flow**
1. **File Upload**: Detects .md files with "prompt" in title
2. **Content Extraction**: Reads and displays prompt content
3. **Combination**: Merges custom prompt with extracted prompts
4. **Processing**: Passes combined prompt to QA orchestrator
5. **Results**: Shows how prompts influenced processing

## 🚨 **Troubleshooting**

### **If Streamlit Won't Start**
```bash
# Check Python path
python3 -c "import sys; print(sys.path)"

# Reinstall dependencies
pip install -r requirements_demo.txt --force-reinstall
```

### **If Files Won't Upload**
- Check file permissions
- Ensure files are in the correct directory
- Verify file extensions are supported

### **If Processing Fails**
- Check console for error messages
- Verify all backend components are available
- Ensure input directory exists

## 📊 **Demo Success Metrics**

### **Must Show**
- ✅ File upload with .md support
- ✅ Prompt extraction and display
- ✅ Custom prompt entry
- ✅ Combined prompt processing
- ✅ QA document processing
- ✅ Results generation

### **Nice to Show**
- ✅ Multiple file types
- ✅ Error handling
- ✅ Real-time validation
- ✅ Performance metrics

## 🎉 **Demo Completion Checklist**

- [ ] Streamlit app starts successfully
- [ ] Files upload without errors
- [ ] Prompts are extracted and displayed
- [ ] Processing completes successfully
- [ ] Results are generated
- [ ] All features work as expected

## 📞 **Backup Plan**

If the demo fails:
1. **Show the code structure** - Highlight the implementation
2. **Run the test script** - `python3 demo_test_script.py`
3. **Explain the architecture** - Walk through the components
4. **Show the files** - Display the prompt and document files

## 🎯 **Key Messages**

1. **"Flexible Prompt System"** - Users can provide prompts in multiple ways
2. **"Smart File Detection"** - System automatically identifies prompt files
3. **"Regular Orchestrator Integration"** - Uses existing QA infrastructure
4. **"User-Friendly Interface"** - Intuitive and easy to use
5. **"Production Ready"** - Robust error handling and validation

---

**Good luck with the demo! 🚀**
