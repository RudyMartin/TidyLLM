# 🎛️ QA Demo Manager Usage Guide

## 📋 **Overview**

The `manage_demo.py` script provides easy management of the QA demo Streamlit process with start, stop, restart, and status checking functionality.

## 🚀 **Quick Start**

### **Install Dependencies**
```bash
pip install -r requirements_demo.txt
```

### **Basic Commands**
```bash
# Start the demo
python3 manage_demo.py start

# Stop the demo
python3 manage_demo.py stop

# Restart the demo
python3 manage_demo.py restart

# Check status
python3 manage_demo.py status

# Test imports
python3 manage_demo.py test
```

## 📖 **Detailed Usage**

### **Starting the Demo**
```bash
# Start on default port (8501)
python3 manage_demo.py start

# Start on custom port
python3 manage_demo.py start --port 8502

# Start in interactive mode (not headless)
python3 manage_demo.py start --headless false
```

### **Stopping the Demo**
```bash
# Stop the demo
python3 manage_demo.py stop
```

### **Restarting the Demo**
```bash
# Restart on same port
python3 manage_demo.py restart

# Restart on different port
python3 manage_demo.py restart --port 8503
```

### **Checking Status**
```bash
# Check if demo is running
python3 manage_demo.py status
```

### **Testing Imports**
```bash
# Test if all imports work
python3 manage_demo.py test
```

## 🎯 **Demo Workflow**

### **1. Test Everything First**
```bash
python3 manage_demo.py test
```

### **2. Start the Demo**
```bash
python3 manage_demo.py start
```

### **3. Access the Demo**
- Open browser to: http://localhost:8501
- Upload `test_prompt.md` and `demo_document.txt`
- Enter custom prompt
- Click "Process Documents"

### **4. Stop When Done**
```bash
python3 manage_demo.py stop
```

## 🔧 **Troubleshooting**

### **If Demo Won't Start**
```bash
# Check imports
python3 manage_demo.py test

# Check status
python3 manage_demo.py status

# Force restart
python3 manage_demo.py restart
```

### **If Port is Busy**
```bash
# Try different port
python3 manage_demo.py start --port 8502
```

### **If Process Won't Stop**
```bash
# Force stop
python3 manage_demo.py stop

# Or manually kill
pkill -f "streamlit run"
```

## 📊 **Status Output Examples**

### **Demo Running**
```
📊 QA Demo Status:
   Port: 8501
   App: src/qa_demo.py
   ✅ App file exists
   ✅ Port 8501 is in use
   ✅ Streamlit process running (PID: 40193)
```

### **Demo Not Running**
```
📊 QA Demo Status:
   Port: 8501
   App: src/qa_demo.py
   ✅ App file exists
   ❌ Port 8501 is free
   ❌ No Streamlit process found
```

## 🎉 **Monday Demo Commands**

### **Pre-Demo Setup**
```bash
# 1. Test everything
python3 manage_demo.py test

# 2. Start demo
python3 manage_demo.py start

# 3. Verify it's running
python3 manage_demo.py status
```

### **During Demo**
- Open: http://localhost:8501
- Upload files and test functionality

### **Post-Demo Cleanup**
```bash
# Stop demo
python3 manage_demo.py stop
```

## 🔍 **Advanced Features**

### **Process Management**
- Automatically kills existing processes
- Saves PID for clean shutdown
- Port conflict detection
- Import validation

### **Error Handling**
- Graceful process termination
- Port availability checking
- File existence validation
- Import error detection

## 📝 **Tips**

1. **Always test imports first** before starting the demo
2. **Use different ports** if 8501 is busy
3. **Check status** to verify the demo is running
4. **Stop cleanly** when done to free up resources
5. **Restart** if you encounter any issues

---

**The demo manager makes it easy to start, stop, and manage your QA demo! 🚀**
