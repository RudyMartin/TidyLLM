# Enhanced Embedding System with Model Tracking

## Overview

The Enhanced Embedding System provides comprehensive vector embedding generation and management with detailed tracking of which model generated which embeddings and their original dimensions. This system solves the embedding dimension mismatch issue by using intelligent padding/truncation while maintaining full traceability.

## Key Features

### 1. **Model Tracking**
- Tracks which embedding model was used for each embedding
- Records original dimensions vs target dimensions
- Stores content hashes for deduplication
- Timestamps for generation tracking

### 2. **Dimension Management**
- Automatically handles dimension mismatches
- Zero-padding for smaller embeddings
- Truncation for larger embeddings
- Validates final dimensions match database schema

### 3. **Multi-Model Support**
- Fallback model selection if primary model fails
- Support for different SentenceTransformer models
- Easy integration with Amazon Bedrock (placeholder)

## Architecture

### Core Components

#### `EmbeddingHelper` Class
```python
class EmbeddingHelper:
    def __init__(self, target_dimensions: int = 1024)
    def generate_embedding(self, text: str, content_id: str = None)
    def generate_batch_embeddings(self, texts: List[str], content_ids: List[str] = None)
    def get_model_info(self) -> Dict[str, Any]
    def validate_embedding_dimensions(self, embedding: np.ndarray) -> bool
```

#### `EmbeddingMetadata` Dataclass
```python
@dataclass
class EmbeddingMetadata:
    model_name: str
    original_dimensions: int
    target_dimensions: int
    padding_method: str  # 'zero_pad', 'truncate', 'none'
    content_hash: str
    generation_timestamp: str
```

## Database Integration

### Schema Fields
The database schema includes tracking fields:

```sql
-- In document_chunks table
embedding_model TEXT NOT NULL,       -- Which model generated this embedding
embedding vector(1024),              -- The actual embedding vector
content_hash TEXT,                   -- SHA-1 hash of content for deduplication
```

### Storage Process
1. **Generate embedding** with original model
2. **Adjust dimensions** using padding/truncation
3. **Store metadata** including model name and content hash
4. **Validate** final dimensions match schema

## Model Options

### Current Models Tested
| Model | Original Dimensions | Padding Needed | Status |
|-------|-------------------|----------------|---------|
| `all-mpnet-base-v2` | 768 | 256 zeros | ✅ Recommended |
| `all-MiniLM-L6-v2` | 384 | 640 zeros | ✅ Fallback |
| `all-MiniLM-L12-v2` | 384 | 640 zeros | ✅ Fallback |
| `paraphrase-multilingual-mpnet-base-v2` | 768 | 256 zeros | ✅ Multilingual |
| `distiluse-base-multilingual-cased-v2` | 512 | 512 zeros | ✅ Multilingual |

### Model Selection Strategy
1. **Primary**: `all-mpnet-base-v2` (768d → 1024d with 256 padding)
2. **Fallback**: `all-MiniLM-L6-v2` (384d → 1024d with 640 padding)
3. **Multilingual**: `paraphrase-multilingual-mpnet-base-v2`

## Usage Examples

### Basic Usage
```python
from backend.core.embedding_helper import EmbeddingHelper

# Initialize with target dimensions
helper = EmbeddingHelper(target_dimensions=1024)

# Generate single embedding
embedding, metadata = helper.generate_embedding("Sample text", "chunk_1")
print(f"Model: {metadata.model_name}")
print(f"Dimensions: {metadata.original_dimensions} -> {len(embedding)}")
print(f"Padding: {metadata.padding_method}")
```

### Batch Processing
```python
texts = ["Text 1", "Text 2", "Text 3"]
content_ids = ["chunk_1", "chunk_2", "chunk_3"]

embeddings, metadata_list = helper.generate_batch_embeddings(texts, content_ids)

for embedding, metadata in zip(embeddings, metadata_list):
    print(f"{metadata.model_name}: {len(embedding)} dimensions")
```

### Database Integration
```python
# In RAGQAOrchestrator
embedding, metadata = self.embedding_helper.generate_embedding(
    chunk_doc['content'], 
    chunk_doc['chunk_id']
)

cursor.execute("""
    UPDATE document_chunks 
    SET embedding = %s, 
        embedding_model = %s,
        content_hash = %s
    WHERE doc_id = %s AND chunk_id = %s
""", (
    embedding.tolist(),
    metadata.model_name,
    metadata.content_hash,
    doc_id,
    chunk_id
))
```

## Installation

### Requirements
```bash
# Install in py311 environment
conda activate py311
pip install -r py311_requirements.txt
```

### Key Dependencies
- `sentence-transformers>=5.1.0` (upgraded from 2.6.1)
- `torch>=2.2.2`
- `numpy>=2.3.2`
- `psycopg2-binary>=2.9.9`

## Testing

### Run Enhanced Embedding Tests
```bash
python test_enhanced_embeddings.py
```

### Test PDF RAG with Enhanced System
```bash
python simple_pdf_rag_test.py
```

## Benefits

### 1. **Elegant Padding Solution**
- Zero-padding is mathematically sound for embeddings
- Preserves original semantic information
- No information loss from truncation

### 2. **Complete Traceability**
- Know exactly which model generated each embedding
- Track original vs target dimensions
- Content hashing for deduplication

### 3. **Database Schema Compliance**
- All embeddings guaranteed to be 1024 dimensions
- Consistent storage format
- No more dimension mismatch errors

### 4. **Multi-Model Architecture**
- Easy to switch between embedding models
- Fallback options for reliability
- Future-proof for new models

## Future Enhancements

### 1. **Amazon Bedrock Integration**
- Replace placeholder with actual Bedrock API calls
- Use Titan v1 (1024 dimensions) for perfect match
- Multi-provider support

### 2. **Advanced Padding Strategies**
- Learned padding instead of zero padding
- Model-specific padding approaches
- Quality metrics for padding impact

### 3. **Embedding Quality Validation**
- Semantic similarity preservation tests
- Cross-model consistency checks
- Performance benchmarking

## Troubleshooting

### Common Issues

#### 1. **Dimension Mismatch Still Occurring**
- Check that `sentence-transformers` is upgraded to 5.1.0+
- Verify `EmbeddingHelper` is being used instead of direct model calls
- Check database schema has `embedding vector(1024)` column

#### 2. **Model Loading Failures**
- Ensure all dependencies are installed in py311 environment
- Check internet connection for model downloads
- Verify torch version compatibility

#### 3. **Database Connection Issues**
- Verify `DATABASE_URL` environment variable
- Check PostgreSQL and pgvector installation
- Ensure database schema is properly initialized

### Debug Commands
```bash
# Check current sentence-transformers version
pip show sentence-transformers

# Test embedding system
python test_enhanced_embeddings.py

# Check database schema
python check_db_schema.py

# Verify model dimensions
python test_embedding_models.py
```

## Summary

The Enhanced Embedding System provides a robust, traceable solution for embedding generation that:

1. **Solves the dimension mismatch** with elegant padding
2. **Tracks model usage** for complete auditability  
3. **Ensures database compliance** with 1024-dimensional vectors
4. **Supports multiple models** with fallback options
5. **Maintains semantic quality** while adjusting dimensions

This system is production-ready and provides the foundation for reliable document analysis and RAG workflows.
