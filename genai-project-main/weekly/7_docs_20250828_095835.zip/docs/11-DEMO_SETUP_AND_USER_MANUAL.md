# Demo Setup and User Manual

## 🎯 Overview

This document provides complete setup instructions and user manual for the MVR (Model Validation & Risk Assessment) demo.

---

## 🚀 Quick Start

### **Prerequisites**
- Python 3.11+
- Virtual environment (py311)
- Git repository access

### **Setup Steps**
1. **Clone and navigate to project**
   ```bash
   cd /Users/rudy/GitHub/qaz_20250321
   ```

2. **Activate virtual environment**
   ```bash
   source py311/bin/activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements_streamlit.txt
   ```

4. **Start the demo**
   ```bash
   python start_mvr_demo.py
   ```

5. **Access the demo**
   - Open browser to: `http://localhost:8501`
   - Demo will load automatically

---

## 📋 Demo Features

### **Core Functionality**
- **Document Upload**: Support for multiple file types
- **Intelligent Processing**: Automatic document classification and analysis
- **MVR Analysis**: Model Validation & Risk Assessment capabilities
- **SPARSE Code Interface**: Advanced command interface
- **Real-time Results**: Live processing and feedback

### **Supported File Types**
- **Documents**: PDF, DOCX, TXT, MD
- **Data**: CSV, JSON, Excel
- **Configuration**: YAML, XML
- **Images**: JPG, PNG, GIF, SVG, BMP, TIFF, WebP

### **Processing Modes**
- **Simple**: Basic document processing
- **Enhanced**: Advanced analysis features
- **Advanced**: Full AI/ML capabilities

---

## 🎮 User Interface Guide

### **Main Dashboard**
1. **File Upload Section**
   - Drag & drop or click to upload files
   - Supported formats listed
   - File size limits enforced

2. **Processing Status**
   - Real-time progress indicators
   - Processing time display
   - Success/error feedback

3. **Results Display**
   - Structured data presentation
   - Downloadable results
   - Export capabilities

### **SPARSE Code Interface**
1. **Quick Commands**
   - `[VST Compare]`: Compare Validation Scope Template
   - `[MVR Review]`: Perform Model Validation Report review
   - `[Gap Analysis]`: Identify compliance gaps
   - `[Embedding Similarity]`: Calculate semantic similarity

2. **Custom Commands**
   - Enter custom SPARSE code
   - Natural language instructions
   - Advanced analysis requests

### **Navigation**
- **Step-by-step flow**: Follow numbered steps
- **Visual indicators**: Progress bars and status lights
- **Unlock system**: Complete steps to unlock advanced features

---

## 🔧 Advanced Features

### **Document Processing Chain**
1. **Upload** → File validation and size check
2. **Classification** → Automatic document type detection
3. **Processing** → Worker-based content analysis
4. **Analysis** → MVR-specific analysis
5. **Results** → Structured output and insights

### **Error Handling**
- **Graceful degradation**: System continues with available features
- **User feedback**: Clear error messages and suggestions
- **Recovery options**: Retry mechanisms and fallbacks

### **Performance Optimization**
- **Caching**: Results cached for repeated access
- **Parallel processing**: Multiple files processed simultaneously
- **Memory management**: Efficient resource usage

---

## 🛠️ Troubleshooting

### **Common Issues**

#### **Demo Won't Start**
```bash
# Check Python version
python --version  # Should be 3.11+

# Check virtual environment
which python  # Should point to py311

# Reinstall dependencies
pip install -r requirements_streamlit.txt
```

#### **Import Errors**
```bash
# Check PYTHONPATH
echo $PYTHONPATH

# Add src/backend to path
export PYTHONPATH="${PYTHONPATH}:/Users/rudy/GitHub/qaz_20250321/src/backend"
```

#### **File Upload Issues**
- **File too large**: Check file size limits
- **Unsupported format**: Verify file extension
- **Upload fails**: Check network connection

#### **Processing Errors**
- **Worker unavailable**: Check worker status
- **Memory issues**: Close other applications
- **Timeout**: Try smaller files or simpler processing

### **Debug Mode**
```bash
# Enable debug logging
export LOG_LEVEL=DEBUG
python start_mvr_demo.py
```

### **Emergency Controls**
- **Demo Reset**: Use reset button in interface
- **Emergency Mode**: Available in advanced settings
- **Fallback Processing**: Automatic when advanced features fail

---

## 📊 Performance Monitoring

### **System Health**
- **Worker Status**: All workers should show ✅
- **Processing Times**: Monitor for performance issues
- **Memory Usage**: Check for memory leaks
- **Error Rates**: Track processing failures

### **Metrics Dashboard**
- **Files Processed**: Total count and success rate
- **Processing Speed**: Average time per file
- **Worker Utilization**: Which workers are most used
- **Error Analysis**: Common failure patterns

---

## 🔒 Security Features

### **Demo Protection**
- **File Size Limits**: Prevent system overload
- **Suspicious Name Detection**: Block malicious files
- **Content Validation**: Verify file integrity
- **Access Controls**: Demo-specific restrictions

### **Data Handling**
- **Temporary Storage**: Files processed in memory
- **No Persistent Storage**: Demo data not saved
- **Secure Processing**: Isolated processing environment

---

## 🎯 Best Practices

### **For Users**
1. **Start Simple**: Begin with basic documents
2. **Check File Types**: Ensure supported formats
3. **Monitor Progress**: Watch processing indicators
4. **Use SPARSE Code**: Leverage advanced features
5. **Report Issues**: Provide detailed error information

### **For Administrators**
1. **Monitor Resources**: Check system performance
2. **Update Dependencies**: Keep packages current
3. **Backup Configuration**: Save custom settings
4. **Test Regularly**: Verify demo functionality
5. **Document Changes**: Track modifications

---

## 📚 Reference Materials

### **Documentation Links**
- [Backend API Documentation](5-BACKEND_API_DOCUMENTATION.md)
- [Principles of This App](1-PRINCIPLES_OF_THIS_APP.md)
- [Under the Hood Architecture](2-UNDER_THE_HOOD_ARCHITECTURE.md)
- [DataMart Next Steps](3-DATAMART_NEXT_STEPS.md)
- [Known Issues](3-KNOWN_ISSUES_NON_BLOCKING.md)

### **Technical Resources**
- **SPARSE Code Reference**: See sparse agreements
- **Worker Documentation**: Individual worker guides
- **API Endpoints**: Backend service documentation
- **Configuration Files**: Setup and customization

---

## 🚀 Production Deployment

### **Environment Setup**
```bash
# Production environment
python -m venv production_env
source production_env/bin/activate
pip install -r requirements_streamlit.txt
```

### **Configuration**
- **Environment Variables**: Set production values
- **Logging**: Configure production logging
- **Monitoring**: Set up performance monitoring
- **Security**: Implement access controls

### **Scaling**
- **Load Balancing**: Multiple demo instances
- **Caching**: Redis or similar for performance
- **Database**: PostgreSQL for persistent data
- **Monitoring**: Comprehensive system monitoring

---

## 📞 Support

### **Getting Help**
1. **Check Documentation**: Review this manual
2. **Troubleshooting**: Follow troubleshooting guide
3. **Error Logs**: Check system logs for details
4. **Community**: Reach out to development team

### **Reporting Issues**
- **Bug Reports**: Include error messages and steps
- **Feature Requests**: Describe desired functionality
- **Performance Issues**: Provide system specifications
- **Security Concerns**: Report immediately

---

*Last Updated: March 2025*
*Version: 1.0*
*Status: Production Ready ✅*
