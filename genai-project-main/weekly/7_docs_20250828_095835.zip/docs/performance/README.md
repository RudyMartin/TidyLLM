# Performance

Performance analysis and optimization

## Contents

This folder contains documentation related to performance.
