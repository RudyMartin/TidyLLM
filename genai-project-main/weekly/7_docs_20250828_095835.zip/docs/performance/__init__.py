"""Documentation for performance"""
