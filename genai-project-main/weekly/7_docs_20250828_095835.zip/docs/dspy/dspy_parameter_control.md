# DSPy Parameter Control Guide

## Overview

DSPy has **native parameter control methods** that allow you to configure LLM parameters directly through DSPy's interface. This is much more elegant than manually passing parameters to individual API calls.

## 🎯 Key Points

✅ **DSPy has native parameter control** via `dspy.configure()`  
✅ **GPT-5 reasoning and verbosity** can be controlled  
✅ **Temperature and max_tokens** work across providers  
✅ **Advanced features** like CoT and RAG are built-in  
✅ **Provider-agnostic** interface  

## 🔧 Basic Parameter Control

### Standard Parameters

```python
import dspy

# Configure DSPy with parameters
dspy.configure(lm=dspy.OpenAI(
    model="gpt-3.5-turbo",
    max_tokens=1000,
    temperature=0.1
))

# Use DSPy signatures
class SimpleQA(dspy.Signature):
    question = dspy.InputField()
    answer = dspy.OutputField()

predictor = dspy.Predict(SimpleQA)
result = predictor(question="What is 2+2?")
```

### GPT-5 Specific Parameters

```python
# GPT-5 with reasoning and verbosity control
dspy.configure(lm=dspy.OpenAI(
    model="gpt-5",
    reasoning={"effort": "high"},      # "low", "medium", "high"
    text={"verbosity": "medium"},      # "low", "medium", "high"
    max_tokens=1500,
    temperature=0.1
))
```

## 🎛️ Parameter Tuning

### Temperature Control (Creativity)

```python
# Deterministic, focused responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    temperature=0.0,
    max_tokens=200
))

# Balanced responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    temperature=0.3,
    max_tokens=500
))

# Creative responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    temperature=0.7,
    max_tokens=1000
))
```

### Max Tokens Control

```python
# Very short responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-3.5-turbo",
    max_tokens=50
))

# Medium responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-3.5-turbo",
    max_tokens=500
))

# Long responses
dspy.configure(lm=dspy.OpenAI(
    model="gpt-3.5-turbo",
    max_tokens=2000
))
```

## 🚀 Advanced Features

### Chain of Thought (CoT)

```python
class CoTQA(dspy.Signature):
    problem = dspy.InputField()
    reasoning = dspy.OutputField(desc="Step-by-step reasoning")
    answer = dspy.OutputField(desc="Final answer")

cot_predictor = dspy.ChainOfThought(CoTQA)
result = cot_predictor(problem="If I have 5 apples and eat 2, how many do I have left?")
```

### Retrieval-Augmented Generation (RAG)

```python
class RAGQA(dspy.Signature):
    question = dspy.InputField()
    context = dspy.InputField()
    answer = dspy.OutputField()

rag_predictor = dspy.Predict(RAGQA)
result = rag_predictor(
    question="What is the capital of France?",
    context="Paris is the capital city of France..."
)
```

## 🔄 Multi-Provider Support

### OpenAI

```python
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    max_tokens=1000,
    temperature=0.1
))
```

### Anthropic

```python
dspy.configure(lm=dspy.Anthropic(
    model="claude-3-sonnet-20240229",
    max_tokens=2000,
    temperature=0.1
))
```

### AWS Anthropic

```python
dspy.configure(lm=dspy.AWSAnthropic(
    model="anthropic.claude-3-sonnet-20240229-v1:0",
    max_tokens=2000,
    temperature=0.1
))
```

### Azure OpenAI

```python
dspy.configure(lm=dspy.AzureOpenAI(
    model="gpt-35-turbo",
    max_tokens=1000,
    temperature=0.1
))
```

## 📊 Configuration Examples

### For Precise QA

```python
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    temperature=0.0,    # Deterministic
    max_tokens=500      # Concise
))
```

### For Creative Writing

```python
dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    temperature=0.8,    # Creative
    max_tokens=1000     # Detailed
))
```

### For Complex Reasoning (GPT-5)

```python
dspy.configure(lm=dspy.OpenAI(
    model="gpt-5",
    reasoning={"effort": "high"},      # Deep reasoning
    text={"verbosity": "medium"},      # Detailed responses
    temperature=0.1,                   # Precise
    max_tokens=1500                    # Longer responses
))
```

### For Cost-Effective Processing

```python
dspy.configure(lm=dspy.OpenAI(
    model="gpt-3.5-turbo",
    temperature=0.1,
    max_tokens=200
))
```

## 🔗 Integration with VectorQA Sage

### Using Our Configuration Module

```python
from app.core.dspy_config import configure_dspy_for_provider

# Configure for validation
configure_dspy_for_provider(
    provider="openai",
    temperature=0.1,        # Precise validation
    max_tokens=500          # Concise responses
)

# Configure for creative tasks
configure_dspy_for_provider(
    provider="openai", 
    reasoning_effort="high", # Deep reasoning
    text_verbosity="medium", # Detailed responses
    temperature=0.3,         # Some creativity
    max_tokens=1000         # Longer responses
)
```

### DSPy Signatures for QA Validation

```python
class ValidateQA(dspy.Signature):
    topic = dspy.InputField()
    report_chunk = dspy.InputField()
    retrieved_context = dspy.InputField()
    answer = dspy.OutputField(desc="One of: Correct, Missing Info, Inconsistent")

predictor = dspy.Predict(ValidateQA)
result = predictor(
    topic="sustainability",
    report_chunk="CO2 emissions reduced by 15%",
    retrieved_context="Company targets 20% reduction by 2025"
)
```

## 🎯 Provider-Specific Parameters

### OpenAI Parameters

- **model**: `"gpt-3.5-turbo"`, `"gpt-4"`, `"gpt-5"`
- **max_tokens**: 1-4000
- **temperature**: 0.0-2.0
- **reasoning**: `{"effort": "low/medium/high"}` (GPT-5 only)
- **text**: `{"verbosity": "low/medium/high"}` (GPT-5 only)

### Anthropic Parameters

- **model**: `"claude-3-sonnet"`, `"claude-3-opus"`
- **max_tokens**: 1-4096
- **temperature**: 0.0-1.0

### AWS Anthropic Parameters

- **model**: `"anthropic.claude-3-sonnet-20240229-v1:0"`
- **max_tokens**: 1-4096
- **temperature**: 0.0-1.0

### Azure OpenAI Parameters

- **model**: `"gpt-35-turbo"`, `"gpt-4"`
- **max_tokens**: 1-4000
- **temperature**: 0.0-2.0

## 💡 Best Practices

1. **Use appropriate temperature** for your task:
   - 0.0-0.2: Factual, precise tasks
   - 0.3-0.5: Balanced responses
   - 0.6-0.8: Creative tasks
   - 0.9-1.0: Very creative tasks

2. **Set reasonable max_tokens**:
   - 50-200: Very short responses
   - 200-500: Short responses
   - 500-1000: Medium responses
   - 1000+: Long responses

3. **Use GPT-5 features** when available:
   - `reasoning={"effort": "high"}` for complex problems
   - `text={"verbosity": "medium"}` for detailed responses

4. **Choose the right provider**:
   - OpenAI: Best for general tasks
   - Anthropic: Good for reasoning
   - AWS Anthropic: Cost-effective for enterprise
   - Azure OpenAI: Good for Microsoft ecosystem

## 🚀 Migration from Manual API Calls

### Before (Manual API calls)

```python
import openai

response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "What is 2+2?"}],
    max_tokens=100,
    temperature=0.1
)
```

### After (DSPy native control)

```python
import dspy

dspy.configure(lm=dspy.OpenAI(
    model="gpt-4",
    max_tokens=100,
    temperature=0.1
))

class SimpleQA(dspy.Signature):
    question = dspy.InputField()
    answer = dspy.OutputField()

predictor = dspy.Predict(SimpleQA)
result = predictor(question="What is 2+2?")
```

## 🎉 Summary

DSPy provides **native parameter control** that is:

✅ **Cleaner** than manual API calls  
✅ **Provider-agnostic** across different LLM providers  
✅ **Feature-rich** with GPT-5 reasoning and verbosity  
✅ **Advanced** with CoT and RAG capabilities  
✅ **Easy to use** with simple configuration  

This makes DSPy the ideal choice for LLM applications that need fine-grained parameter control!
