# 🗄️ Database Documentation - VectorQA Sage

## 🎯 Overview

Complete database documentation for VectorQA Sage, including setup, schemas, and essential instructions for new developers.

## 🚀 Quick Start for New Developers

### **1. Database Setup (Essential First Steps)**

#### **Option A: Complete Setup (Recommended for new installations)**
```bash
# Install PostgreSQL
# Create database
createdb vectorqa

# Run complete setup
psql -d vectorqa -f database/infra_scripts/00_complete_setup.sql
```

#### **Option B: Modular Setup (For specific modifications)**
```bash
# Install PostgreSQL
# Create database
createdb vectorqa

# Run individual scripts in order
psql -d vectorqa -f database/infra_scripts/01_extensions.sql
psql -d vectorqa -f database/infra_scripts/02_review_system.sql
psql -d vectorqa -f database/infra_scripts/03_embeddings_system.sql
psql -d vectorqa -f database/infra_scripts/04_event_tracking.sql
```

### **2. Connection Setup**
- **File**: `database/IMPORTANT_DB_CONNECTION.md`
- **Purpose**: Database connection patterns and troubleshooting
- **Essential**: Read this before connecting to database

## 📁 Database Structure

### **Core Tables**
- **Error Tracking**: `simple_error_tracking_schema.sql`
- **TOC Processing**: `schema_toc_tables.sql`
- **Bibliography**: `schema_bibliography_tables.sql`
- **SME Context**: `sme_context_schema.sql`

### **Sample Data**
- **Error Tracking**: `mock_data_error_tracking.sql`
- **Bibliography**: `initial_bibliography_data.sql`
- **Test Queries**: `sme_context_test_queries.sql`

## 🔧 Essential Database Files

### **📋 Setup & Configuration**
- **[Database Connection Guide](IMPORTANT_DB_CONNECTION.md)** - **CRITICAL** - Read first!
- **[Aurora PostgreSQL Setup](Aurora_PostgreSQL_Setup_Walkthrough.md)** - AWS deployment
- **[Database README](database/README.md)** - Database overview

### **🗄️ Schema Files**

#### **Complete Setup Scripts**
- **[Complete Setup](database/infra_scripts/00_complete_setup.sql)** - Master script for full installation
- **[Extensions](database/infra_scripts/01_extensions.sql)** - PostgreSQL extensions setup
- **[Review System](database/infra_scripts/02_review_system.sql)** - QA validation tables
- **[Embeddings System](database/infra_scripts/03_embeddings_system.sql)** - Vector storage and search
- **[Event Tracking](database/infra_scripts/04_event_tracking.sql)** - Analytics and monitoring

#### **Legacy Schema Files (for reference)**
- **[Error Tracking Schema](database/simple_error_tracking_schema.sql)** - Core error logging
- **[TOC Tables Schema](database/schema_toc_tables.sql)** - Table of contents processing
- **[Bibliography Schema](database/schema_bibliography_tables.sql)** - Citation management
- **[SME Context Schema](database/sme_context_schema.sql)** - Subject matter expert context

### **📊 Sample Data & Queries**
- **[Error Tracking Mock Data](database/mock_data_error_tracking.sql)** - Sample error data
- **[Bibliography Sample Data](database/initial_bibliography_data.sql)** - Sample citations
- **[Error Tracking Queries](database/error_tracking_queries.sql)** - Useful queries
- **[SME Context Test Queries](database/sme_context_test_queries.sql)** - Test queries

### **🛠️ Setup Scripts**
- **[Error Tracking Setup](database/setup_error_tracking.sh)** - Automated setup
- **[Infrastructure Schemas](database/infra/)** - Complete database infrastructure

## 🎯 **NEW DEVELOPER CHECKLIST**

### **✅ Essential Reading (Do This First)**
1. **[Database Connection Guide](IMPORTANT_DB_CONNECTION.md)** - **CRITICAL**
2. **[Aurora PostgreSQL Setup](Aurora_PostgreSQL_Setup_Walkthrough.md)** - If using AWS
3. **[Database README](database/README.md)** - Database overview

### **✅ Setup Steps**
1. **Install PostgreSQL** (if not already installed)
2. **Create database**: `createdb vectorqa`
3. **Run core schemas** (see Quick Start above)
4. **Test connection** using connection guide
5. **Verify setup** with test queries

### **✅ Integration Points**
- **TOC Extractor Worker**: Uses `toc_structures` and `toc_entries` tables
- **Bibliography Builder Worker**: Uses `bibliography_structures` and `citations` tables
- **Error Tracking**: Uses `error_tracking` and `alert_history` tables
- **Real-time Context**: Uses `real_time_context` table

## 🔍 **Troubleshooting**

### **Common Issues**
- **Connection refused**: Check if PostgreSQL is running
- **Permission denied**: Check database user permissions
- **Schema not found**: Run schema files in correct order
- **Data not appearing**: Check if mock data was loaded

### **Useful Commands**
```bash
# Check database status
psql -d vectorqa -c "SELECT version();"

# List all tables
psql -d vectorqa -c "\dt"

# Check table structure
psql -d vectorqa -c "\d table_name"

# Test queries
psql -d vectorqa -f database/sme_context_test_queries.sql
```

## 📚 **Related Documentation**

### **System Architecture**
- **[Technical Documentation](../technical/README.md)** - Development setup
- **[Architecture Documentation](../architecture/README.md)** - System design
- **[MCP Details](../../src/backend/mcp/IMPORTANT_MCP_DETAILS.md)** - MCP architecture

### **Workers & Integration**
- **[TOC Extractor Worker](../TOC_EXTRACTOR_WORKER_DETAILED.md)** - TOC processing
- **[Bibliography Builder Worker](../BIBLIOGRAPHY_BUILDER_WORKER.md)** - Citation processing
- **[Integrated Workers Summary](../INTEGRATED_WORKERS_SUMMARY.md)** - Worker overview

### **Deployment & Production**
- **[Deployment Guide](../DEPLOYMENT_GUIDE.md)** - Production deployment
- **[Architect Planning](../ARCHITECT_APPROVER_PLANNING.md)** - Production readiness
- **[Innovative Features](../INNOVATIVE_FEATURES.md)** - Special features

---

**For questions or issues, see the troubleshooting section or contact the development team.**
