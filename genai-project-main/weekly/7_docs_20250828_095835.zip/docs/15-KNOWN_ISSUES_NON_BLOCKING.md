# Known Issues (Non-Blocking)

This document tracks known issues that don't prevent the application from functioning but should be monitored and addressed in future updates.

## 🔧 Current Issues

### 1. NumPy Version Conflict Warning

**Issue**: PyTorch compiled with NumPy 1.x vs installed NumPy 2.x
```
A module that was compiled using NumPy 1.x cannot be run in
NumPy 2.3.2 as it may crash. To support both 1.x and 2.x
versions of NumPy, modules must be compiled with NumPy 2.0.
```

**Impact**: 
- ⚠️ Warning message appears during startup
- ✅ Functionality works correctly
- ✅ No crashes or data corruption

**Status**: 
- **Priority**: Low
- **Resolution**: Expected behavior, documented in architecture
- **Action**: Monitor for PyTorch updates with NumPy 2.x support

**Affected Components**:
- `sentence_transformers` library
- `transformers` library  
- PyTorch modules

---

### 2. ruamel-yaml Not Available

**Issue**: Multiple YAML libraries in environment, ruamel-yaml not available
```
⚠️ ruamel-yaml not available
⚠️ ruamel_yaml (alt) not available
```

**Impact**:
- ✅ Graceful fallback to PyYAML
- ✅ All YAML processing works correctly
- ✅ No functionality loss

**Status**:
- **Priority**: Very Low
- **Resolution**: Graceful fallback working
- **Action**: None required - PyYAML is sufficient

**Affected Components**:
- `YAMLProcessingWorker`
- `DocumentProcessingOrchestrator`
- Sparse agreements loading

---

### 3. Virtual Environment Detection

**Issue**: Multiple Python environments may cause confusion
- System Python
- Conda base environment  
- Virtual environment (py311)

**Impact**:
- ⚠️ Potential dependency conflicts
- ✅ Resolved through virtual environment isolation
- ✅ Python 3.11 requirement enforced

**Status**:
- **Priority**: Low
- **Resolution**: Virtual environment architecture implemented
- **Action**: Use `py311` virtual environment for development/demo

**Affected Components**:
- All Python modules
- Dependency management
- Demo execution

---

## 📋 Resolution Tracking

| Issue | Status | Priority | Next Review |
|-------|--------|----------|-------------|
| NumPy Version Conflict | Monitoring | Low | Q2 2025 |
| ruamel-yaml Missing | Resolved | Very Low | None |
| Environment Detection | Resolved | Low | None |

## 🚀 Mitigation Strategies

### For NumPy Conflict:
1. **Current**: Accept warning, functionality works
2. **Future**: Monitor PyTorch updates
3. **Alternative**: Consider downgrading NumPy if needed

### For YAML Libraries:
1. **Current**: PyYAML fallback working
2. **Future**: Standardize on PyYAML
3. **Alternative**: Install ruamel-yaml if needed

### For Environment Issues:
1. **Current**: Virtual environment isolation
2. **Future**: Containerization (Docker)
3. **Alternative**: Environment validation scripts

## 📝 Notes

- All issues are **non-blocking** - the application functions correctly
- Issues are **documented** for transparency and future reference
- **Graceful degradation** is implemented where possible
- **Monitoring** is in place for critical issues

---

*Last Updated: March 2025*
*Status: All Issues Non-Blocking ✅*
