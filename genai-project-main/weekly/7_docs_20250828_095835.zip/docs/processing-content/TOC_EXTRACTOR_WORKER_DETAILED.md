# TOC Extractor Worker - Detailed Technical Documentation

## Table of Contents
1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Implementation Details](#implementation-details)
4. [API Reference](#api-reference)
5. [Database Schema](#database-schema)
6. [Usage Patterns](#usage-patterns)
7. [Configuration](#configuration)
8. [Troubleshooting](#troubleshooting)
9. [Performance Optimization](#performance-optimization)
10. [Integration Guide](#integration-guide)

## Overview

The TOC (Table of Contents) Extractor Worker is a specialized component designed to extract, parse, and structure table of contents from PDF documents. It enables systematic document navigation and section-by-section processing by creating hierarchical representations of document structure.

### Key Capabilities
- **Multi-method extraction** with automatic fallback strategies
- **Pattern-based recognition** for various TOC formats
- **Hierarchical structure building** with parent-child relationships
- **PostgreSQL integration** with comprehensive schema
- **Section navigation** and content retrieval capabilities
- **Caching system** for performance optimization

## Architecture

### Component Architecture
```
TOC Extractor Worker
├── Method Detection Layer
│   ├── pdfplumber (text-based extraction)
│   ├── fitz (PDF bookmarks)
│   ├── pymupdf (modern PDF bookmarks)
│   └── pypdfium2 (fallback)
├── Pattern Recognition Engine
│   ├── TOC header detection
│   ├── Entry pattern matching
│   ├── Level determination
│   └── Page number extraction
├── Hierarchy Builder
│   ├── Parent-child relationship mapping
│   ├── Level-based structuring
│   └── Section ID generation
└── Data Export Layer
    ├── JSON serialization
    ├── Database integration
    └── Cache management
```

### Data Flow
```
Document Input
    ↓
Method Selection (pdfplumber → fitz → pymupdf → pypdfium2)
    ↓
Pattern Recognition
    ↓
Entry Parsing
    ↓
Hierarchy Building
    ↓
Structure Validation
    ↓
Output (TOCStructure object)
    ↓
Database Storage (optional)
```

## Implementation Details

### Core Classes

#### TOCEntry
```python
@dataclass
class TOCEntry:
    title: str                    # Section title
    page_number: Optional[int]    # Page number where section starts
    level: int                    # Hierarchical level (1=chapter, 2=section, etc.)
    section_id: Optional[str]     # Unique identifier for the section
    parent_id: Optional[str]      # Parent section ID (for hierarchy)
    children: List['TOCEntry']    # Child sections
    metadata: Dict[str, Any]      # Additional metadata
```

#### TOCStructure
```python
@dataclass
class TOCStructure:
    document_id: str              # Unique document identifier
    document_title: str           # Document title
    total_pages: int              # Total number of pages
    entries: List[TOCEntry]       # Root-level TOC entries
    extraction_method: str        # Method used for extraction
    confidence_score: float       # Confidence in extraction quality
    metadata: Dict[str, Any]      # Additional metadata
    created_at: str               # ISO timestamp
```

### Pattern Recognition Engine

#### TOC Header Patterns
```python
toc_headers = [
    re.compile(r'^table\s+of\s+contents?', re.IGNORECASE),
    re.compile(r'^contents?', re.IGNORECASE),
    re.compile(r'^index', re.IGNORECASE),
    re.compile(r'^outline', re.IGNORECASE),
]
```

#### TOC Entry Patterns
```python
toc_entries = [
    # "Chapter 1. Introduction ................ 5"
    re.compile(r'^([^.]*?)\s*\.*\s*(\d+)$'),
    
    # "1.1 Background ........................ 12"
    re.compile(r'^(\d+\.\d+[^.]*?)\s*\.*\s*(\d+)$'),
    
    # "Section 1: Overview ................... 3"
    re.compile(r'^([^:]*?)\s*:?\s*\.*\s*(\d+)$'),
    
    # "Appendix A. Data Tables .............. 45"
    re.compile(r'^(appendix\s+[a-z][^.]*?)\s*\.*\s*(\d+)$', re.IGNORECASE),
]
```

#### Level Detection Logic
```python
def _determine_level(self, title: str) -> int:
    # Chapter indicators
    if re.match(r'^chapter\s+\d+', title, re.IGNORECASE):
        return 1
    
    # Section indicators (1.1, 1.2, etc.)
    if re.match(r'^\d+\.\d+', title):
        return 2
    
    # Subsection indicators (1.1.1, 1.1.2, etc.)
    if re.match(r'^\d+\.\d+\.\d+', title):
        return 3
    
    # Appendix
    if re.match(r'^appendix\s+[a-z]', title, re.IGNORECASE):
        return 1
    
    return 1  # Default level
```

### Hierarchy Building Algorithm

```python
def _structure_toc_entries(self, entries: List[TOCEntry]) -> List[TOCEntry]:
    # Sort by level and page number
    entries.sort(key=lambda x: (x.level, x.page_number or 0))
    
    # Build hierarchy using level stack
    root_entries = []
    level_stack = [None] * 10  # Support up to 10 levels
    
    for entry in entries:
        level = entry.level - 1  # Convert to 0-based index
        
        # Find parent
        if level > 0 and level_stack[level - 1]:
            entry.parent_id = level_stack[level - 1].section_id
            level_stack[level - 1].children.append(entry)
        else:
            root_entries.append(entry)
        
        # Update level stack
        level_stack[level] = entry
    
    return root_entries
```

## API Reference

### TOCExtractorWorker Class

#### Constructor
```python
TOCExtractorWorker()
```
Initializes the worker and checks for available extraction methods.

#### Methods

##### extract_toc()
```python
def extract_toc(
    self, 
    file_path: str = None, 
    file_content: bytes = None,
    document_id: str = None, 
    document_title: str = None
) -> TOCStructure
```

**Parameters:**
- `file_path`: Path to the PDF file
- `file_content`: PDF content as bytes
- `document_id`: Unique identifier for the document
- `document_title`: Title of the document

**Returns:** TOCStructure object containing the extracted TOC

**Example:**
```python
worker = TOCExtractorWorker()
toc = worker.extract_toc(
    file_path="document.pdf",
    document_id="doc_001",
    document_title="Research Paper"
)
```

##### get_section_content()
```python
def get_section_content(
    self, 
    toc_structure: TOCStructure, 
    section_id: str
) -> Optional[Dict[str, Any]]
```

**Parameters:**
- `toc_structure`: The TOC structure to search in
- `section_id`: ID of the section to retrieve

**Returns:** Dictionary with section information or None if not found

##### get_section_range()
```python
def get_section_range(
    self, 
    toc_structure: TOCStructure, 
    section_id: str
) -> Optional[Tuple[int, int]]
```

**Parameters:**
- `toc_structure`: The TOC structure to search in
- `section_id`: ID of the section to get range for

**Returns:** Tuple of (start_page, end_page) or None if not found

##### export_to_json()
```python
def export_to_json(self, toc_structure: TOCStructure) -> str
```

**Parameters:**
- `toc_structure`: The TOC structure to export

**Returns:** JSON string representation of the TOC structure

##### clear_cache()
```python
def clear_cache(self)
```
Clears the internal cache of processed TOCs.

##### get_cache_stats()
```python
def get_cache_stats(self) -> Dict[str, Any]
```

**Returns:** Dictionary with cache statistics

## Database Schema

### Core Tables

#### documents
```sql
CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id VARCHAR(255) UNIQUE NOT NULL,
    title VARCHAR(500) NOT NULL,
    file_path TEXT,
    file_size BIGINT,
    total_pages INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB DEFAULT '{}'::jsonb
);
```

#### toc_structures
```sql
CREATE TABLE toc_structures (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    extraction_method VARCHAR(100) NOT NULL,
    confidence_score DECIMAL(3,2) NOT NULL DEFAULT 0.0,
    total_entries INTEGER NOT NULL DEFAULT 0,
    toc_data JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(document_id)
);
```

#### toc_entries
```sql
CREATE TABLE toc_entries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    toc_structure_id UUID NOT NULL REFERENCES toc_structures(id) ON DELETE CASCADE,
    section_id VARCHAR(255) NOT NULL,
    title TEXT NOT NULL,
    page_number INTEGER,
    level INTEGER NOT NULL DEFAULT 1,
    parent_id VARCHAR(255),
    sort_order INTEGER NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(toc_structure_id, section_id)
);
```

### Key Functions

#### insert_toc_structure()
```sql
CREATE OR REPLACE FUNCTION insert_toc_structure(
    p_document_id VARCHAR(255),
    p_title VARCHAR(500),
    p_extraction_method VARCHAR(100),
    p_confidence_score DECIMAL(3,2),
    p_toc_data JSONB
) RETURNS UUID
```

Inserts a complete TOC structure with all entries into the database.

#### get_section_content_range()
```sql
CREATE OR REPLACE FUNCTION get_section_content_range(
    p_document_id VARCHAR(255),
    p_section_id VARCHAR(255)
) RETURNS TABLE(
    start_page INTEGER,
    end_page INTEGER,
    title TEXT,
    level INTEGER
)
```

Returns the page range for a specific section.

## Usage Patterns

### Basic TOC Extraction
```python
from backend.mcp.workers.toc_extractor_worker import TOCExtractorWorker

# Initialize worker
worker = TOCExtractorWorker()

# Extract TOC
toc = worker.extract_toc(
    file_path="document.pdf",
    document_id="doc_001",
    document_title="Research Paper"
)

# Check results
print(f"Extracted {len(toc.entries)} entries")
print(f"Method: {toc.extraction_method}")
print(f"Confidence: {toc.confidence_score}")
```

### Section-by-Section Processing
```python
# Process each section individually
for entry in toc.entries:
    print(f"Processing: {entry.title}")
    
    # Get section range
    section_range = worker.get_section_range(toc, entry.section_id)
    if section_range:
        start_page, end_page = section_range
        print(f"Pages {start_page} to {end_page}")
        
        # Extract content for this section
        # Create embeddings
        # Store in database
```

### Database Integration
```python
import psycopg2
import json

# Export to JSON
json_data = worker.export_to_json(toc)

# Store in database
conn = psycopg2.connect("postgresql://user:pass@localhost/db")
cursor = conn.cursor()

cursor.execute("""
    SELECT insert_toc_structure(%s, %s, %s, %s, %s)
""", (
    toc.document_id,
    toc.document_title,
    toc.extraction_method,
    toc.confidence_score,
    json.dumps(toc.to_dict())
))

conn.commit()
```

### Batch Processing
```python
import os
from pathlib import Path

def process_documents_batch(directory: str):
    worker = TOCExtractorWorker()
    results = []
    
    for pdf_file in Path(directory).glob("*.pdf"):
        try:
            toc = worker.extract_toc(
                file_path=str(pdf_file),
                document_id=pdf_file.stem,
                document_title=pdf_file.stem
            )
            results.append({
                'file': pdf_file.name,
                'success': toc.confidence_score > 0,
                'entries': len(toc.entries),
                'method': toc.extraction_method
            })
        except Exception as e:
            results.append({
                'file': pdf_file.name,
                'success': False,
                'error': str(e)
            })
    
    return results
```

## Configuration

### Method Priority Configuration
```python
# Default method priority (can be customized)
extraction_methods = [
    ('pdfplumber', self._extract_with_pdfplumber),
    ('fitz', self._extract_with_fitz),
    ('pymupdf', self._extract_with_pymupdf),
    ('pypdfium2', self._extract_with_pypdfium2)
]
```

### Pattern Configuration
```python
# Customize patterns for specific document types
custom_patterns = {
    'toc_headers': [
        re.compile(r'^table\s+of\s+contents?', re.IGNORECASE),
        re.compile(r'^contents?', re.IGNORECASE),
        # Add custom patterns here
    ],
    'toc_entries': [
        # Add custom entry patterns here
    ]
}
```

### Cache Configuration
```python
# Cache settings
cache_settings = {
    'max_size': 1000,        # Maximum cached entries
    'ttl': 3600,            # Time to live (seconds)
    'auto_clear': True      # Automatic cache clearing
}
```

## Troubleshooting

### Common Issues

#### No TOC Found
**Symptoms:** Empty TOC structure or low confidence score
**Solutions:**
1. Check if document has a TOC
2. Verify extraction method availability
3. Review pattern recognition settings
4. Try different extraction methods

#### Pattern Recognition Issues
**Symptoms:** Incorrect level detection or missing entries
**Solutions:**
1. Review TOC format in document
2. Add custom patterns for specific format
3. Adjust level detection logic
4. Check for special characters or formatting

#### Performance Issues
**Symptoms:** Slow extraction or memory problems
**Solutions:**
1. Clear cache regularly
2. Process documents in smaller batches
3. Optimize pattern matching
4. Use appropriate extraction method

### Debug Mode
```python
import logging

# Enable debug logging
logging.basicConfig(level=logging.DEBUG)

# Test with debug output
worker = TOCExtractorWorker()
toc = worker.extract_toc("document.pdf")
```

## Performance Optimization

### Caching Strategy
```python
# Cache key generation
cache_key = f"{document_id}_{document_title or 'unknown'}"

# Cache hit optimization
if cache_key in self.toc_cache:
    return self.toc_cache[cache_key]
```

### Method Selection Optimization
```python
# Try methods in order of preference
for method_name, method_func in extraction_methods:
    if not self.available_methods.get(method_name):
        continue
    
    try:
        result = method_func(file_path, file_content, document_id, document_title)
        if result and result.confidence_score > best_confidence:
            best_result = result
            break
    except Exception:
        continue
```

### Database Optimization
```sql
-- Create indexes for common queries
CREATE INDEX idx_toc_entries_section_id ON toc_entries(section_id);
CREATE INDEX idx_toc_entries_level ON toc_entries(level);
CREATE INDEX idx_toc_entries_page_number ON toc_entries(page_number);

-- GIN indexes for JSONB columns
CREATE INDEX idx_toc_structures_toc_data ON toc_structures USING gin(toc_data);
```

## Integration Guide

### Integration with Document Processing Pipeline
```python
class DocumentProcessor:
    def __init__(self):
        self.toc_worker = TOCExtractorWorker()
        self.pdf_processor = ModernPDFProcessor()
    
    def process_document(self, file_path: str):
        # Extract TOC first
        toc = self.toc_worker.extract_toc(file_path)
        
        # Process document by sections
        for entry in toc.entries:
            section_range = self.toc_worker.get_section_range(toc, entry.section_id)
            if section_range:
                start_page, end_page = section_range
                # Extract content for this section
                content = self.pdf_processor.extract_pages(file_path, start_page, end_page)
                # Process content...
```

### Integration with RAG System
```python
class RAGSystem:
    def __init__(self):
        self.toc_worker = TOCExtractorWorker()
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    def create_section_embeddings(self, document_path: str):
        toc = self.toc_worker.extract_toc(document_path)
        
        embeddings = {}
        for entry in toc.entries:
            # Get section content
            section_content = self.get_section_content(entry)
            if section_content:
                # Create embeddings for section
                embedding = self.embedding_model.encode(section_content)
                embeddings[entry.section_id] = embedding
        
        return embeddings
```

### Integration with Search System
```python
class SearchSystem:
    def __init__(self):
        self.toc_worker = TOCExtractorWorker()
    
    def search_by_section(self, query: str, document_id: str):
        # Get TOC structure
        toc = self.get_toc_from_database(document_id)
        
        # Search within specific sections
        results = []
        for entry in toc.entries:
            if self.section_matches_query(entry, query):
                results.append({
                    'section': entry.title,
                    'page': entry.page_number,
                    'level': entry.level
                })
        
        return results
```

---

**Last Updated**: December 2024  
**Version**: 1.0  
**Maintainer**: AI Assistant  
**Status**: ✅ **Production Ready**
