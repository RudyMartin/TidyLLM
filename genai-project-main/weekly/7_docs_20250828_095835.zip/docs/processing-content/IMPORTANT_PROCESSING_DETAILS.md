# IMPORTANT Document Processing Details - New Guy Guide

## 🎯 **What Makes This System Unique**

### **🏗️ Multi-Worker Architecture**
Unlike traditional single-purpose PDF processors, this system uses **specialized workers** that work together:

```
┌─────────────────────────────────────────────────────────────┐
│              Document Processing Orchestrator               │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   TOC Worker    │  │ Bibliography    │  │   Image      │ │
│  │   (Structure)   │  │   Worker        │  │   Worker     │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   PDF Worker    │  │   Table         │  │   LLM        │ │
│  │   (Core Text)   │  │   Extractor     │  │   Enhanced   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### **🧠 LLM-Enhanced Processing**
- **Not just OCR**: Uses LLMs to understand document structure
- **Intelligent classification**: Automatically categorizes content
- **Context-aware extraction**: Understands relationships between sections
- **Quality validation**: LLMs verify extraction accuracy

### **⚡ Parallel Processing**
- **Multiple workers run simultaneously**: Not sequential
- **Caching system**: Avoids reprocessing same documents
- **Scalable architecture**: Can add new workers easily

## 🔧 **Key Components**

### **1. Document Processing Orchestrator**
**File**: `src/backend/mcp/orchestrators/document_processing_orchestrator.py`
- **Purpose**: Coordinates all workers
- **Features**: Parallel processing, result aggregation, error handling
- **Unique**: Manages multiple specialized workers as a unified system

### **2. TOC Extractor Worker**
**File**: `src/backend/mcp/workers/toc_extractor_worker.py`
- **Purpose**: Extracts table of contents structure
- **Unique**: Uses LLM to understand document hierarchy
- **Output**: Hierarchical structure with page numbers

### **3. Bibliography Builder Worker**
**File**: `src/backend/mcp/workers/bibliography_builder_worker.py`
- **Purpose**: Extracts and validates references
- **Unique**: Cross-references with external databases
- **Output**: Structured bibliography with metadata

### **4. Image Processing Worker**
**File**: `src/backend/mcp/workers/image_processing_worker.py`
- **Purpose**: Extracts and analyzes images
- **Unique**: OCR + image classification + caption generation
- **Output**: Images with metadata and descriptions

### **5. Modern PDF Processor**
**File**: `src/backend/mcp/workers/modern_pdf_processor.py`
- **Purpose**: Core text and table extraction
- **Unique**: Multiple PDF libraries for best results
- **Output**: Clean text with table data

## 🚨 **Critical Issues & Gotchas**

### **1. PDF Dependencies Nightmare**
**Issue**: PDF processing requires multiple system dependencies
```bash
# ❌ Common failure points:
- poppler-utils not installed
- tesseract-ocr missing
- system fonts not available
- memory issues with large PDFs
```

**Solution**: Use the setup script
```bash
# ✅ Always run this first
./scripts/setup_pdf_dependencies.sh
```

### **2. Memory Management**
**Issue**: Large PDFs can crash the system
```python
# ❌ Bad: Loading entire PDF into memory
pdf_content = pdf.read()  # Can crash with 100MB+ PDFs

# ✅ Good: Stream processing
for page in pdf.pages:
    process_page(page)
```

### **3. LLM Rate Limits**
**Issue**: LLM-enhanced workers can hit API limits
```python
# ❌ Bad: No rate limiting
for page in pages:
    llm_response = call_llm(page)  # Can hit rate limits

# ✅ Good: Rate limiting and caching
gateway = UnifiedLLMGateway(rate_limit=10)  # 10 calls per minute
```

### **4. Cache Invalidation**
**Issue**: Cached results can become stale
```python
# ❌ Bad: Never invalidate cache
cached_result = cache.get(document_id)

# ✅ Good: Smart cache invalidation
if document_modified > cache_timestamp:
    reprocess_document()
```

### **5. Error Handling**
**Issue**: One worker failure can break entire pipeline
```python
# ❌ Bad: No error handling
toc = toc_worker.extract_toc(pdf)  # Can crash entire process

# ✅ Good: Graceful degradation
try:
    toc = toc_worker.extract_toc(pdf)
except Exception as e:
    logger.warning(f"TOC extraction failed: {e}")
    toc = {"error": "extraction_failed"}
```

## 🎯 **What's Unique vs. Standard PDF Processing**

### **Standard PDF Processing**
```python
# Typical approach
import PyPDF2
pdf = PyPDF2.PdfReader("document.pdf")
text = ""
for page in pdf.pages:
    text += page.extract_text()
# Result: Raw text, no structure, no understanding
```

### **Our Approach**
```python
# Our approach
orchestrator = DocumentProcessingOrchestrator()
result = orchestrator.process_document("document.pdf")

# Result includes:
- Structured TOC with hierarchy
- Validated bibliography with metadata
- Extracted tables with relationships
- Processed images with descriptions
- LLM-enhanced classifications
- Quality scores and confidence levels
```

## 🚀 **How to Use (The Right Way)**

### **1. Basic Usage**
```python
from src.backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator

# Initialize orchestrator
orchestrator = DocumentProcessingOrchestrator()

# Process document
result = orchestrator.process_document("path/to/document.pdf")

# Access results
print(f"TOC: {result.toc_structure}")
print(f"Bibliography: {result.bibliography_analysis}")
print(f"Tables: {result.table_data_extraction}")
print(f"Images: {result.image_analysis}")
```

### **2. Advanced Usage with LLM Enhancement**
```python
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway
from src.backend.mcp.orchestrators.llm_enhanced_qa_orchestrator import LLMEnhancedQAOrchestrator

# Initialize LLM-enhanced orchestrator
llm_gateway = UnifiedLLMGateway(env_name="production")
orchestrator = LLMEnhancedQAOrchestrator(config_path="config.yaml")

# Process with LLM enhancement
result = orchestrator.process_document_with_llm("document.pdf")
```

### **3. Batch Processing**
```python
# Process multiple documents efficiently
documents = ["doc1.pdf", "doc2.pdf", "doc3.pdf"]
results = []

for doc in documents:
    try:
        result = orchestrator.process_document(doc)
        results.append(result)
    except Exception as e:
        logger.error(f"Failed to process {doc}: {e}")
        continue
```

## 🔍 **Monitoring and Debugging**

### **1. Worker Status**
```python
# Check worker health
status = orchestrator.get_worker_status()
for worker_name, stats in status.items():
    print(f"{worker_name}: {stats['status']}")
    print(f"  Cache hits: {stats['cache_stats']['hits']}")
    print(f"  Errors: {stats['error_count']}")
```

### **2. Performance Monitoring**
```python
# Monitor processing time
import time

start_time = time.time()
result = orchestrator.process_document("document.pdf")
processing_time = time.time() - start_time

print(f"Processing time: {processing_time:.2f}s")
print(f"Worker breakdown: {result.processing_times}")
```

### **3. Quality Assessment**
```python
# Check extraction quality
quality_scores = result.quality_assessment
print(f"Overall quality: {quality_scores['overall']}")
print(f"TOC quality: {quality_scores['toc']}")
print(f"Bibliography quality: {quality_scores['bibliography']}")
```

## 🛠️ **Setup and Configuration**

### **1. Dependencies Setup**
```bash
# Install PDF dependencies
./scripts/setup_pdf_dependencies.sh

# Install Python packages
pip install -r requirements.txt

# Verify installation
python scripts/test_pdf_processing.py
```

### **2. Configuration**
```yaml
# config.yaml
processing:
  max_workers: 4
  cache_enabled: true
  cache_ttl: 3600
  
workers:
  toc:
    enabled: true
    llm_enhanced: true
  bibliography:
    enabled: true
    external_validation: true
  images:
    enabled: true
    ocr_enabled: true
  tables:
    enabled: true
    structure_detection: true
```

### **3. Environment Variables**
```bash
# Required for LLM enhancement
export VECTORQA_ENV=production
export MLFLOW_TRACKING_URI="postgresql://user:pass@host:5432/mlflow"

# Optional for performance
export MAX_WORKERS=4
export CACHE_TTL=3600
```

## 🚨 **Common Problems and Solutions**

### **Problem: "PDF processing failed"**
```bash
# Check dependencies
./scripts/setup_pdf_dependencies.sh

# Check file permissions
ls -la document.pdf

# Check file integrity
file document.pdf
```

### **Problem: "LLM rate limit exceeded"**
```python
# Reduce concurrent requests
orchestrator = DocumentProcessingOrchestrator(max_workers=2)

# Enable caching
orchestrator.enable_caching(ttl=3600)
```

### **Problem: "Memory error"**
```python
# Process in chunks
orchestrator = DocumentProcessingOrchestrator(
    chunk_size=10,  # Process 10 pages at a time
    max_memory_mb=512
)
```

### **Problem: "Cache corruption"**
```python
# Clear cache
orchestrator.clear_cache()

# Or disable cache temporarily
orchestrator.disable_caching()
```

## 📊 **Performance Optimization**

### **1. Parallel Processing**
```python
# Use multiple workers
orchestrator = DocumentProcessingOrchestrator(max_workers=4)

# Process multiple documents
with ThreadPoolExecutor(max_workers=4) as executor:
    futures = [executor.submit(orchestrator.process_document, doc) 
               for doc in documents]
    results = [future.result() for future in futures]
```

### **2. Caching Strategy**
```python
# Enable intelligent caching
orchestrator.enable_caching(
    ttl=3600,  # 1 hour
    max_size=1000,  # Max 1000 cached documents
    compression=True  # Compress cached data
)
```

### **3. Resource Management**
```python
# Monitor resource usage
import psutil

def monitor_resources():
    cpu_percent = psutil.cpu_percent()
    memory_percent = psutil.virtual_memory().percent
    
    if cpu_percent > 80 or memory_percent > 80:
        logger.warning("High resource usage detected")
        # Reduce worker count or pause processing
```

## 🎯 **Best Practices**

### **1. Always Use Error Handling**
```python
try:
    result = orchestrator.process_document(pdf_path)
except PDFProcessingError as e:
    logger.error(f"PDF processing failed: {e}")
    # Handle gracefully
except LLMRateLimitError as e:
    logger.warning(f"Rate limit hit: {e}")
    # Retry with backoff
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    # Log and continue
```

### **2. Monitor Quality**
```python
# Always check quality scores
if result.quality_assessment['overall'] < 0.7:
    logger.warning("Low quality extraction detected")
    # Consider reprocessing or manual review
```

### **3. Use Appropriate Workers**
```python
# Enable only needed workers
orchestrator = DocumentProcessingOrchestrator(
    workers_config={
        'toc': True,
        'bibliography': False,  # Disable if not needed
        'images': True,
        'tables': True
    }
)
```

### **4. Regular Maintenance**
```python
# Clear old cache entries
orchestrator.clear_expired_cache()

# Update worker configurations
orchestrator.update_worker_configs()

# Check for updates
orchestrator.check_for_updates()
```

## 📚 **Additional Resources**

### **Documentation Files**
- `TOC_EXTRACTOR_WORKER.md` - TOC extraction details
- `BIBLIOGRAPHY_BUILDER_WORKER.md` - Bibliography processing
- `IMAGE_PROCESSING_WORKER.md` - Image analysis
- `PDF_DEPENDENCIES_GUIDE.md` - Setup and troubleshooting
- `INTEGRATION_ANALYSIS.md` - How workers work together
- `CUSTOM_EXTRACTION_ROUTINES.md` - Advanced extraction techniques

### **Code Examples**
- `src/backend/mcp/orchestrators/document_processing_orchestrator.py` - Main orchestrator
- `src/backend/mcp/workers/` - All worker implementations
- `scripts/test_*.py` - Test scripts for each worker

### **Testing**
```bash
# Test individual workers
python scripts/test_toc_extractor_worker.py
python scripts/test_bibliography_builder_worker.py
python scripts/test_image_processing_worker.py

# Test full pipeline
python scripts/test_document_processing_pipeline.py
```

## 🎉 **Quick Start Checklist**

1. **✅ Setup Dependencies**: Run `./scripts/setup_pdf_dependencies.sh`
2. **✅ Test Installation**: Run test scripts
3. **✅ Configure Environment**: Set environment variables
4. **✅ Test Basic Processing**: Process a simple PDF
5. **✅ Enable LLM Enhancement**: Configure MLflow integration
6. **✅ Monitor Performance**: Check worker status and quality scores
7. **✅ Deploy**: Use in production with proper error handling

---

**Remember**: This system is unique because it combines multiple specialized workers with LLM enhancement. The key is understanding that each worker has a specific purpose, and they work together to provide comprehensive document analysis that goes far beyond simple text extraction! 🚀
