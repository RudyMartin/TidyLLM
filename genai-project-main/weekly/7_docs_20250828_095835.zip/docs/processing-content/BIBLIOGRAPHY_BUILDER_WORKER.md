# Bibliography Builder Worker - Complete Documentation

## Overview

The **Bibliography Builder Worker** is a specialized component designed to extract, parse, and structure bibliography/reference sections from academic papers and white papers. It enables systematic citation analysis, reference tracking, and bibliometric analysis for research document processing.

## 🎯 Key Features

### **Multi-Format Citation Support**
- **Numbered citations**: `[1] Author, Title, Journal, Year`
- **Author-year citations**: `Author, Title, Journal, Year`
- **ArXiv citations**: `Author. Title. arXiv preprint arXiv:1234.5678, Year`
- **Conference papers**: `Author. Title. In Proceedings of Conference, Year`
- **Journal articles**: `Author. Title. Journal Name, Volume:Pages, Year`

### **Intelligent Parsing**
- **Author extraction** with support for "et al." patterns
- **Title identification** from quoted text or context
- **Year detection** with validation
- **DOI extraction** from various formats
- **ArXiv ID recognition** with validation
- **Journal/venue identification**

### **Robust Extraction Methods**
- **pdfplumber**: Primary text-based extraction
- **fitz (PyMuPDF)**: PDF bookmark and text extraction
- **pymupdf**: Modern PDF processing
- **pypdfium2**: Advanced PDF features with fallback

### **Comprehensive Analysis**
- **Citation type classification** (journal, conference, arxiv, book, website, other)
- **Confidence scoring** for extraction quality
- **Statistical analysis** of citation patterns
- **Author network analysis**
- **Year distribution analysis**

## 📁 File Structure

```
src/backend/mcp/workers/
├── bibliography_builder_worker.py     # Main worker implementation
├── toc_extractor_worker.py           # TOC extraction (complementary)
├── image_processing_worker.py        # Image extraction (complementary)
└── modern_pdf_processor.py           # PDF processing foundation

scripts/
├── test_bibliography_builder_worker.py  # Comprehensive test suite
└── explore_references.py               # Reference exploration tool

database/
├── schema_bibliography_tables.sql     # PostgreSQL schema
└── initial_bibliography_data.sql      # Sample data

docs/
├── BIBLIOGRAPHY_BUILDER_WORKER.md     # This documentation
└── SYSTEM_INTEGRATION_GUIDE.md        # Integration guide
```

## 🏗️ Architecture

### **Core Components**

#### **BibliographyBuilderWorker Class**
```python
class BibliographyBuilderWorker:
    def __init__(self):
        self.available_methods = self._check_available_methods()
        self.bibliography_cache = {}
        self.patterns = self._initialize_patterns()
```

#### **Data Structures**

**Citation Class**
```python
@dataclass
class Citation:
    citation_id: str
    raw_text: str
    authors: List[str]
    title: str
    journal: Optional[str]
    year: Optional[int]
    doi: Optional[str]
    url: Optional[str]
    arxiv_id: Optional[str]
    venue: Optional[str]
    pages: Optional[str]
    volume: Optional[str]
    issue: Optional[str]
    publisher: Optional[str]
    citation_type: str
    confidence_score: float
    metadata: Dict[str, Any]
```

**BibliographyStructure Class**
```python
@dataclass
class BibliographyStructure:
    document_id: str
    document_title: str
    total_citations: int
    citations: List[Citation]
    extraction_method: str
    confidence_score: float
    reference_section_text: str
    metadata: Dict[str, Any]
    created_at: str
```

### **Processing Pipeline**

```
Document Input
    ↓
Method Selection (pdfplumber → fitz → pymupdf → pypdfium2)
    ↓
Text Extraction
    ↓
Reference Section Detection
    ↓
Citation Parsing
    ↓
Component Extraction (authors, titles, years, etc.)
    ↓
Citation Classification
    ↓
Confidence Scoring
    ↓
Structure Building
    ↓
Output (BibliographyStructure object)
    ↓
Database Storage (optional)
```

## 🔧 API Reference

### **Core Methods**

#### **extract_bibliography()**
```python
def extract_bibliography(
    self, 
    file_path: str = None, 
    file_content: bytes = None,
    document_id: str = None, 
    document_title: str = None
) -> BibliographyStructure
```

**Parameters:**
- `file_path`: Path to the PDF file
- `file_content`: PDF content as bytes
- `document_id`: Unique identifier for the document
- `document_title`: Title of the document

**Returns:** BibliographyStructure object containing extracted citations

**Example:**
```python
worker = BibliographyBuilderWorker()
bibliography = worker.extract_bibliography(
    file_path="research_paper.pdf",
    document_id="paper_001",
    document_title="Machine Learning Advances"
)
```

#### **get_citation_statistics()**
```python
def get_citation_statistics(self, bibliography: BibliographyStructure) -> Dict[str, Any]
```

**Returns:** Dictionary with citation statistics including:
- Total citations count
- Citation type distribution
- Year distribution
- Top authors
- Average confidence scores

#### **export_to_json()**
```python
def export_to_json(self, bibliography: BibliographyStructure) -> str
```

**Returns:** JSON string representation of the bibliography structure

### **Utility Methods**

#### **clear_cache()**
```python
def clear_cache(self)
```
Clears the internal cache of processed bibliographies.

#### **get_cache_stats()**
```python
def get_cache_stats(self) -> Dict[str, Any]
```

**Returns:** Dictionary with cache statistics

## 🗄️ Database Schema

### **Core Tables**

#### **bibliography_structures**
```sql
CREATE TABLE bibliography_structures (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    extraction_method VARCHAR(100) NOT NULL,
    confidence_score DECIMAL(3,2) NOT NULL DEFAULT 0.0,
    total_citations INTEGER NOT NULL DEFAULT 0,
    reference_section_text TEXT,
    bibliography_data JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(document_id)
);
```

#### **citations**
```sql
CREATE TABLE citations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bibliography_id UUID NOT NULL REFERENCES bibliography_structures(id) ON DELETE CASCADE,
    citation_id VARCHAR(255) NOT NULL,
    raw_text TEXT NOT NULL,
    authors JSONB NOT NULL DEFAULT '[]'::jsonb,
    title TEXT,
    journal VARCHAR(500),
    year INTEGER,
    doi VARCHAR(255),
    url TEXT,
    arxiv_id VARCHAR(100),
    venue VARCHAR(500),
    pages VARCHAR(100),
    volume VARCHAR(50),
    issue VARCHAR(50),
    publisher VARCHAR(500),
    citation_type VARCHAR(50) NOT NULL,
    confidence_score DECIMAL(3,2) NOT NULL DEFAULT 0.0,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(bibliography_id, citation_id)
);
```

#### **citation_statistics**
```sql
CREATE TABLE citation_statistics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bibliography_id UUID NOT NULL REFERENCES bibliography_structures(id) ON DELETE CASCADE,
    total_citations INTEGER NOT NULL DEFAULT 0,
    unique_authors INTEGER NOT NULL DEFAULT 0,
    avg_confidence DECIMAL(3,2) NOT NULL DEFAULT 0.0,
    arxiv_citations INTEGER NOT NULL DEFAULT 0,
    journal_citations INTEGER NOT NULL DEFAULT 0,
    conference_citations INTEGER NOT NULL DEFAULT 0,
    citation_type_distribution JSONB NOT NULL DEFAULT '{}'::jsonb,
    year_distribution JSONB NOT NULL DEFAULT '{}'::jsonb,
    top_authors JSONB NOT NULL DEFAULT '[]'::jsonb,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(bibliography_id)
);
```

### **Key Functions**

#### **insert_bibliography_structure()**
```sql
CREATE OR REPLACE FUNCTION insert_bibliography_structure(
    p_document_id VARCHAR(255),
    p_title VARCHAR(500),
    p_extraction_method VARCHAR(100),
    p_confidence_score DECIMAL(3,2),
    p_total_citations INTEGER,
    p_reference_section_text TEXT,
    p_bibliography_data JSONB
) RETURNS UUID
```

#### **insert_citations_recursive()**
```sql
CREATE OR REPLACE FUNCTION insert_citations_recursive(
    p_bibliography_id UUID,
    p_citations JSONB
) RETURNS INTEGER
```

#### **get_citation_statistics()**
```sql
CREATE OR REPLACE FUNCTION get_citation_statistics(
    p_document_id VARCHAR(255)
) RETURNS TABLE(
    total_citations INTEGER,
    unique_authors INTEGER,
    avg_confidence DECIMAL(3,2),
    arxiv_citations INTEGER,
    journal_citations INTEGER,
    conference_citations INTEGER,
    citation_type_distribution JSONB,
    year_distribution JSONB,
    top_authors JSONB
)
```

## 📊 Usage Examples

### **Basic Bibliography Extraction**
```python
from backend.mcp.workers.bibliography_builder_worker import BibliographyBuilderWorker

# Initialize worker
worker = BibliographyBuilderWorker()

# Extract bibliography
bibliography = worker.extract_bibliography(
    file_path="research_paper.pdf",
    document_id="paper_001",
    document_title="Machine Learning Advances"
)

# Check results
print(f"Extracted {len(bibliography.citations)} citations")
print(f"Method: {bibliography.extraction_method}")
print(f"Confidence: {bibliography.confidence_score}")
```

### **Citation Analysis**
```python
# Get citation statistics
stats = worker.get_citation_statistics(bibliography)

print(f"Total citations: {stats['total_citations']}")
print(f"Unique authors: {stats['unique_authors']}")
print(f"ArXiv citations: {stats['arxiv_citations']}")
print(f"Journal citations: {stats['journal_citations']}")

# Citation type distribution
for citation_type, count in stats['citation_type_distribution'].items():
    print(f"{citation_type}: {count}")

# Top authors
for author, count in stats['top_authors'][:5]:
    print(f"{author}: {count} citations")
```

### **Database Integration**
```python
import psycopg2
import json

# Export to JSON
json_data = worker.export_to_json(bibliography)

# Store in database
conn = psycopg2.connect("postgresql://user:pass@localhost/db")
cursor = conn.cursor()

cursor.execute("""
    SELECT insert_bibliography_structure(%s, %s, %s, %s, %s, %s, %s)
""", (
    bibliography.document_id,
    bibliography.document_title,
    bibliography.extraction_method,
    bibliography.confidence_score,
    bibliography.total_citations,
    bibliography.reference_section_text,
    json.dumps(bibliography.to_dict())
))

conn.commit()
```

### **Batch Processing**
```python
import os
from pathlib import Path

def process_documents_batch(directory: str):
    worker = BibliographyBuilderWorker()
    results = []
    
    for pdf_file in Path(directory).glob("*.pdf"):
        try:
            bibliography = worker.extract_bibliography(
                file_path=str(pdf_file),
                document_id=pdf_file.stem,
                document_title=pdf_file.stem
            )
            results.append({
                'file': pdf_file.name,
                'success': bibliography.confidence_score > 0,
                'citations': len(bibliography.citations),
                'method': bibliography.extraction_method
            })
        except Exception as e:
            results.append({
                'file': pdf_file.name,
                'success': False,
                'error': str(e)
            })
    
    return results
```

## 🧪 Testing

### **Running Tests**
```bash
# Run comprehensive test suite
python scripts/test_bibliography_builder_worker.py

# Test specific functionality
python -c "
from scripts.test_bibliography_builder_worker import test_citation_parsing
test_citation_parsing()
"
```

### **Test Coverage**
- ✅ **Basic functionality** - Core extraction capabilities
- ✅ **Worker capabilities** - Method availability and patterns
- ✅ **Citation parsing** - Individual citation parsing
- ✅ **Multiple papers** - Batch processing
- ✅ **Statistics and export** - Data analysis and serialization
- ✅ **Cache functionality** - Performance optimization
- ✅ **Error handling** - Robust error management

## 🔧 Configuration

### **Pattern Configuration**
```python
# Customize citation patterns
custom_patterns = {
    'reference_headers': [
        re.compile(r'^references?$', re.IGNORECASE),
        re.compile(r'^bibliography$', re.IGNORECASE),
        # Add custom patterns
    ],
    'numbered_citations': [
        re.compile(r'^\[(\d+)\]\s*(.+)$'),
        # Add custom patterns
    ]
}
```

### **Cache Configuration**
```python
# Cache settings
cache_settings = {
    'max_size': 1000,        # Maximum cached entries
    'ttl': 3600,            # Time to live (seconds)
    'auto_clear': True      # Automatic cache clearing
}
```

## 🚀 Performance Optimization

### **Caching Strategy**
- **In-memory caching** for processed bibliographies
- **Cache key generation** based on document content hash
- **Automatic cache invalidation** for updated documents

### **Parallel Processing**
- **Multi-threaded extraction** for batch processing
- **Method fallback** with automatic retry
- **Resource management** with proper cleanup

### **Database Optimization**
- **GIN indexes** for JSONB columns
- **Composite indexes** for common queries
- **Batch inserts** for citation data

## 🔍 Troubleshooting

### **Common Issues**

#### **No Citations Found**
**Symptoms:** Empty bibliography or low confidence score
**Solutions:**
1. Check if document has a reference section
2. Verify extraction method availability
3. Review pattern recognition settings
4. Try different extraction methods

#### **Poor Citation Parsing**
**Symptoms:** Incorrect author/title extraction or missing metadata
**Solutions:**
1. Review citation format in document
2. Add custom patterns for specific format
3. Adjust parsing logic
4. Check for special characters or formatting

#### **Performance Issues**
**Symptoms:** Slow extraction or memory problems
**Solutions:**
1. Clear cache regularly
2. Process documents in smaller batches
3. Optimize pattern matching
4. Use appropriate extraction method

### **Debug Mode**
```python
import logging

# Enable debug logging
logging.basicConfig(level=logging.DEBUG)

# Test with debug output
worker = BibliographyBuilderWorker()
bibliography = worker.extract_bibliography("document.pdf")
```

## 📈 Integration with Document Processing System

### **Orchestrator Integration**
```python
from backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator

# Initialize orchestrator
orchestrator = DocumentProcessingOrchestrator()

# Process document with bibliography extraction
result = orchestrator.process_document(
    document_path="research_paper.pdf",
    task_types=['bibliography', 'toc', 'images']
)

# Check bibliography results
if result.bibliography_extracted:
    print(f"Extracted {result.citations_count} citations")
    print(f"Confidence: {result.bibliography_confidence}")
```

### **RAG System Integration**
```python
class BibliographyEnhancedRAG:
    def __init__(self):
        self.bibliography_worker = BibliographyBuilderWorker()
        self.embedding_model = SentenceTransformer('all-MiniLM-L6-v2')
    
    def create_citation_embeddings(self, document_path: str):
        bibliography = self.bibliography_worker.extract_bibliography(document_path)
        
        embeddings = {}
        for citation in bibliography.citations:
            # Create embeddings for citation text
            citation_text = f"{citation.title} {' '.join(citation.authors)} {citation.year or ''}"
            embedding = self.embedding_model.encode(citation_text)
            embeddings[citation.citation_id] = embedding
        
        return embeddings
```

## 🎯 Use Cases

### **Academic Research**
- **Literature review automation** - Extract and analyze citations
- **Citation network analysis** - Map research relationships
- **Author collaboration analysis** - Identify research communities
- **Impact factor analysis** - Track citation patterns

### **Research Management**
- **Reference database building** - Create structured citation databases
- **Duplicate detection** - Identify similar papers
- **Trend analysis** - Track research evolution over time
- **Collaboration discovery** - Find potential research partners

### **Publishing**
- **Citation validation** - Verify reference accuracy
- **Format standardization** - Normalize citation formats
- **Impact assessment** - Measure paper influence
- **Metadata extraction** - Extract publication information

## 🔮 Future Enhancements

### **Planned Features**
- **AI-powered citation matching** - Use ML for better citation linking
- **Cross-document citation analysis** - Build citation networks across papers
- **Real-time citation updates** - Track citation changes over time
- **Advanced author disambiguation** - Better author name matching
- **Citation quality scoring** - Assess citation relevance and accuracy

### **Integration Roadmap**
- **CrossRef API integration** - Real-time citation validation
- **ArXiv API integration** - Automatic metadata enrichment
- **Google Scholar integration** - Citation count tracking
- **ORCID integration** - Author identity management

---

**Last Updated**: December 2024  
**Version**: 1.0  
**Maintainer**: AI Assistant  
**Status**: ✅ **Production Ready**
