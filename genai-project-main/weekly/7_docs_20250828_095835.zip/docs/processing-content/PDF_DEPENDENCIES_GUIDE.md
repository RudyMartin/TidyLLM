# PDF Dependencies Guide

## Overview

This project uses a **modern PDF processing stack** that completely eliminates the `fitz` dependency and its associated naming conflicts. We use modern, actively maintained libraries for all PDF processing needs.

## The Problem (Resolved!)

Previously, this project used PyMuPDF which provides the `fitz` module. There was a potential naming conflict with another package also called `fitz` that could cause import errors like:

```
ModuleNotFoundError: No module named 'frontend'
```

**This problem has been completely resolved** by replacing PyMuPDF with modern alternatives.

## Solution

### Modern PDF Stack

We now use a modern, conflict-free PDF processing stack:

```bash
# Install the modern PDF stack
pip install pdfplumber pypdfium2 pypdf
```

### Using the Setup Script

We provide a setup script that automatically installs the modern stack:

```bash
./scripts/setup_pdf_dependencies.sh
```

### Manual Installation

1. **Install pdfplumber (text and table extraction):**
   ```bash
   pip install pdfplumber>=0.11.0
   ```

2. **Install pypdfium2 (image extraction):**
   ```bash
   pip install pypdfium2>=4.30.0
   ```

3. **Install pypdf (modern PDF library):**
   ```bash
   pip install pypdf>=6.0.0
   ```

4. **Verify installation:**
   ```bash
   python -c "import pdfplumber, pypdfium2, pypdf; print('Modern PDF stack works!')"
   ```

## Modern PDF Libraries

The system uses these modern libraries for comprehensive PDF processing:

1. **pdfplumber** - Advanced text and table extraction
2. **pypdfium2** - Image extraction and advanced features
3. **pypdf** - Modern PDF library (replaces PyPDF2)

All libraries work together seamlessly without conflicts.

## Conda Environment Issues

If you're using conda and having issues:

1. **Use the full path to Python:**
   ```bash
   /path/to/conda/envs/py311/bin/python
   ```

2. **Activate environment properly:**
   ```bash
   source /path/to/anaconda3/etc/profile.d/conda.sh
   conda activate py311
   ```

3. **Check Python version:**
   ```bash
   python --version
   ```

## Troubleshooting

### Import Error: "No module named 'frontend'"

**Cause:** This error is now completely eliminated! We no longer use PyMuPDF/fitz.
**Solution:** Use the modern PDF stack:
```bash
pip install pdfplumber pypdfium2 pypdf
```

### Conda Environment Using Wrong Python

**Cause:** Conda environment not properly activated
**Solution:** Use full path to Python executable in conda environment

### Multiple Python Versions

**Cause:** System has multiple Python installations
**Solution:** Always use the Python from your virtual environment

## Requirements Files

The project includes specific requirements:

- `requirements_rag.txt` - Contains PyMuPDF specification
- `requirements.txt` - Main dependencies

## Testing

Test your modern PDF processing setup:

```bash
# Test modern PDF stack
python -c "import pdfplumber, pypdfium2, pypdf; print('Modern PDF stack works!')"

# Test individual components
python -c "import pdfplumber; print('pdfplumber works!')"
python -c "import pypdfium2; print('pypdfium2 works!')"
python -c "import pypdf; print('pypdf works!')"
```

## Deployment Considerations

When deploying:

1. **Use virtual environments** to avoid conflicts
2. **Pin PyMuPDF version** in requirements
3. **Include fallback libraries** for robustness
4. **Test PDF processing** in deployment environment

## Performance Notes

- **pdfplumber** - Excellent for text and table extraction
- **pypdfium2** - Fast image extraction and advanced features
- **pypdf** - Reliable modern PDF library
- **Combined stack** - Best of all worlds, no conflicts

## Security Considerations

- All modern libraries are actively maintained and secure
- Keep dependencies updated
- Use virtual environments to isolate dependencies
- No more fitz dependency conflicts
