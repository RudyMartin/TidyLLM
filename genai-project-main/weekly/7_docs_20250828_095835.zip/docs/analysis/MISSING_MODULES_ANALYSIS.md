# 🔍 MISSING MODULES ANALYSIS & RESOLUTION PLAN

## 📊 Current Test Status

### **Test Results Summary**
- **Total Tests Collected**: 174 items
- **Import Errors**: 4 errors during collection
- **Warnings**: 8 warnings
- **Success Rate**: 97.7% (170/174 tests collected successfully)

### **State-of-the-Code Validation Results**
- **Total Test Files**: 42
- **Total Imports**: 311
- **Missing Modules**: 49
- **Valid Modules**: 89
- **Import Errors**: 0
- **Consistent Paths**: 38
- **Inconsistent Paths**: 6
- **Status**: needs_attention

---

## 🔍 COMPREHENSIVE MODULE ANALYSIS

### **✅ FOUND: Modules That Actually Exist**

#### **1. `noise_agent` Module**
**Location**: `tests/noise_agent.py`
**Status**: ✅ **EXISTS** - Full implementation with NoiseAgent class
**Import Statement**: `from noise_agent import NoiseAgent`
**Root Cause**: Module exists in `tests/` directory, not in `src/`

#### **2. DSPy Integration**
**Location**: `src/backend/mcp/orchestrators/rag_qa_orchestrator.py`
**Status**: ✅ **EXISTS** - DSPy integrated directly in RAG orchestrator
**Import Statement**: `import dspy`
**Root Cause**: DSPyCoordinator was removed, DSPy integrated directly

#### **3. `sentence_transformers` Usage**
**Location**: Multiple files in `src/backend/`
**Status**: ✅ **EXISTS** - Used in document workers and RAG orchestrator
**Import Statement**: `from sentence_transformers import SentenceTransformer`
**Root Cause**: External dependency that needs installation

---

## ❌ MISSING MODULES (Actual Issues)

### **1. `personas` Module**
**Error Location**: 
- `test_control_risks_yaml.py:10`
- `test_latex_generation.py:10`

**Import Statement**: 
```python
from personas.control_risks_yaml_config import ControlRisksYAMLConfig
```

**Current Status**: 
- ❌ **MISSING**: Top-level `personas` module
- ✅ **EXISTS**: `src/backend/personas/control_risks_yaml_config.py`

**Root Cause**: 
- Tests expect `personas` at top level
- Module exists in `src/backend/personas/`

---

### **2. `core` Module**
**Error Location**: 
- `test_qa_report_generation.py:18`

**Import Statement**: 
```python
from core.qa_report_generator import QAReportGenerator
```

**Current Status**: 
- ❌ **MISSING**: Top-level `core` module
- ✅ **EXISTS**: `src/backend/core/qa_report_generator.py`

**Root Cause**: 
- Tests expect `core` at top level
- Module exists in `src/backend/core/`

---

### **3. `backend.mcp.coordinators.dspy_coordinator` Module**
**Error Location**: 
- `test_mcp_workflow.py:40`

**Import Statement**: 
```python
from backend.mcp.coordinators.dspy_coordinator import DSPyCoordinator
```

**Current Status**: 
- ❌ **MISSING**: `dspy_coordinator.py` in `src/backend/mcp/coordinators/`
- ✅ **EXISTS**: DSPy integration in `src/backend/mcp/orchestrators/rag_qa_orchestrator.py`

**Root Cause**: 
- DSPyCoordinator was removed during MCP restructuring
- DSPy functionality integrated directly into orchestrators
- Test needs to be updated to use new architecture

---

## 🔍 COMPLETE MISSING MODULES LIST (49 Total)

### **Standard Library Modules (Expected - Not Actually Missing)**
These are standard Python modules that should be available:
- `datetime`, `typing`, `pathlib`, `unittest`, `io`, `json`, `os`, `sys`

### **Third-Party Dependencies (Need Installation)**
- `pypdf` - PDF processing library (used as PyPDF2 in current code)
- `sentence_transformers` - HuggingFace sentence transformers (used in RAG orchestrator)
- `huggingface_hub` - HuggingFace Hub client

### **Internal Module Path Issues (Need Import Fixes)**
- `personas` → should be `backend.personas`
- `core` → should be `backend.core`
- `src` → should be `backend` (in some contexts)

### **Architecture Changes (Need Test Updates)**
- `dspy_coordinator` → DSPy integrated directly in orchestrators
- `noise_agent` → exists in `tests/` directory

---

## 🔧 RESOLUTION PLAN

### **Phase 1: Import Path Fixes (Immediate)**

#### **1.1 Fix `personas` Import Issues**
**Files to Update**:
- `tests/test_control_risks_yaml.py`
- `tests/test_latex_generation.py`

**Solution**:
```python
# Change from:
from personas.control_risks_yaml_config import ControlRisksYAMLConfig

# To:
from backend.personas.control_risks_yaml_config import ControlRisksYAMLConfig
```

**Priority**: 🔴 **HIGH** - Simple import path fix

---

#### **1.2 Fix `core` Import Issues**
**Files to Update**:
- `tests/test_qa_report_generation.py`

**Solution**:
```python
# Change from:
from core.qa_report_generator import QAReportGenerator

# To:
from backend.core.qa_report_generator import QAReportGenerator
```

**Priority**: 🔴 **HIGH** - Simple import path fix

---

### **Phase 2: Architecture Updates (Medium Priority)**

#### **2.1 Update DSPy Coordinator Test**
**File to Update**: `tests/test_mcp_workflow.py`

**Current Issue**: 
```python
from backend.mcp.coordinators.dspy_coordinator import DSPyCoordinator
```

**Solution Options**:
1. **Remove DSPy Coordinator**: Update test to not use DSPyCoordinator
2. **Use RAG Orchestrator**: Replace with RAGQAOrchestrator that has DSPy integration
3. **Create Mock**: Create a simple mock for testing purposes

**Recommended Solution**:
```python
# Replace DSPyCoordinator with RAGQAOrchestrator
from backend.mcp.orchestrators.rag_qa_orchestrator import RAGQAOrchestrator

# Update test to use RAG orchestrator instead
self.rag_orchestrator = RAGQAOrchestrator()
```

**Priority**: 🟡 **MEDIUM** - Requires test logic updates

---

#### **2.2 Fix `noise_agent` Import**
**File to Update**: `tests/test_pdf_analysis_smart.py`

**Current Issue**: 
```python
from noise_agent import NoiseAgent
```

**Solution**:
```python
# Change from:
from noise_agent import NoiseAgent

# To:
from tests.noise_agent import NoiseAgent
# OR move noise_agent.py to src/backend/utils/ and update import
```

**Priority**: 🟡 **MEDIUM** - Module location fix

---

### **Phase 3: Dependency Installation (Medium Priority)**

#### **3.1 Install Missing Dependencies**
```bash
# Install required packages
pip install pypdf sentence-transformers huggingface-hub

# Or add to requirements.txt
echo "pypdf" >> requirements.txt
echo "sentence-transformers" >> requirements.txt
echo "huggingface-hub" >> requirements.txt
```

**Priority**: 🟡 **MEDIUM** - External dependencies

---

### **Phase 4: Import Structure Standardization (Long-term)**

#### **4.1 Create Import Aliases**
**Create**: `src/__init__.py` with import aliases

**Solution**:
```python
# src/__init__.py
from backend.personas import *
from backend.core import *
from backend.mcp.coordinators import *

# This allows both import styles to work:
# from personas.xxx import yyy  # Legacy
# from backend.personas.xxx import yyy  # New
```

**Priority**: 🟢 **LOW** - Backward compatibility enhancement

---

#### **4.2 Update All Test Files**
**Systematic Review**: Check all test files for import inconsistencies

**Files to Review**:
- All files in `tests/` directory
- Look for imports that don't match current structure

**Priority**: 🟡 **MEDIUM** - Consistency improvement

---

## 📋 IMPLEMENTATION STEPS

### **Step 1: Quick Fixes (Immediate)**
```bash
# 1. Fix personas imports
sed -i '' 's/from personas\./from backend.personas./g' tests/test_control_risks_yaml.py
sed -i '' 's/from personas\./from backend.personas./g' tests/test_latex_generation.py

# 2. Fix core imports
sed -i '' 's/from core\./from backend.core./g' tests/test_qa_report_generation.py

# 3. Test the fixes
python3 tests/run_tests.py --validate-modules --fast --no-credential-check
```

### **Step 2: Architecture Updates**
```bash
# 1. Update DSPy coordinator test
# Edit tests/test_mcp_workflow.py to use RAGQAOrchestrator instead

# 2. Fix noise_agent import
# Move tests/noise_agent.py to src/backend/utils/noise_agent.py
# OR update import in tests/test_pdf_analysis_smart.py
```

### **Step 3: Install Dependencies**
```bash
# Install missing packages
pip install pypdf sentence-transformers huggingface-hub

# Verify installation
python3 -c "import pypdf, sentence_transformers, huggingface_hub; print('✅ Dependencies installed')"
```

### **Step 4: Import Structure Review**
```bash
# Find all import statements in tests
grep -r "from " tests/ | grep -E "(personas|core|backend)" | sort | uniq

# Check for other potential import issues
find tests/ -name "*.py" -exec grep -l "from [a-z]" {} \;
```

---

## 🎯 Expected Results

### **After Phase 1 (Import Fixes)**
- ✅ **Test Collection**: 172/174 tests (98.9% success rate)
- ✅ **Import Errors**: Reduced from 4 to 1
- ✅ **Quick Wins**: Immediate improvement in test coverage

### **After Phase 2 (Architecture Updates)**
- ✅ **Test Collection**: 173/174 tests (99.4% success rate)
- ✅ **Import Errors**: Reduced from 4 to 0
- ✅ **Full Coverage**: All tests collectible

### **After Phase 3 (Dependencies)**
- ✅ **All Dependencies**: Available for RAG and document processing
- ✅ **Full Functionality**: All features working

### **After Phase 4 (Standardization)**
- ✅ **Consistency**: All imports follow same pattern
- ✅ **Maintainability**: Easier to manage import structure
- ✅ **Backward Compatibility**: Legacy imports still work

---

## 🚨 Risk Assessment

### **Low Risk**
- **Import Path Fixes**: Simple text replacements, no functional changes
- **Backward Compatibility**: Adding import aliases doesn't break existing code
- **Dependency Installation**: Standard package installation

### **Medium Risk**
- **DSPy Coordinator Removal**: May require test logic updates
- **Test Updates**: Need to ensure no functional regressions
- **External Dependencies**: May have version conflicts

### **Mitigation Strategies**
- **Incremental Testing**: Test after each change
- **Backup**: Keep original files before modifications
- **Documentation**: Update import guidelines
- **Version Pinning**: Pin dependency versions in requirements.txt

---

## 📊 Impact Analysis

### **Immediate Impact**
- **Test Coverage**: +2.3% improvement (170 → 174 tests)
- **Error Reduction**: 75% reduction in import errors
- **Development Velocity**: Faster test execution

### **Long-term Impact**
- **Code Quality**: Consistent import structure
- **Maintainability**: Easier to manage dependencies
- **Onboarding**: Clearer import patterns for new developers

---

## ✅ Success Criteria

### **Phase 1 Success**
- [ ] All import path fixes applied
- [ ] Test collection success rate >98%
- [ ] No new import errors introduced

### **Phase 2 Success**
- [ ] DSPy coordinator test updated
- [ ] noise_agent import fixed
- [ ] Test collection success rate >99%

### **Phase 3 Success**
- [ ] All dependencies installed
- [ ] All tests collectible
- [ ] Full functionality working

### **Phase 4 Success**
- [ ] Import structure standardized
- [ ] Backward compatibility maintained
- [ ] Documentation updated

---

## 🔄 Next Steps

### **Immediate Actions**
1. **Apply import fixes** (Phase 1)
2. **Update architecture tests** (Phase 2)
3. **Install dependencies** (Phase 3)
4. **Test changes** with enhanced test runner
5. **Document changes** in TEST_DETAILS.md

### **Short-term Actions**
1. **Review all test imports** (Phase 4)
2. **Update documentation** with new import patterns
3. **Create import guidelines** for developers

### **Long-term Actions**
1. **Standardize import structure** across codebase
2. **Automate import validation** in CI/CD
3. **Create module migration tools**

---

## 📚 Related Documentation

- `TEST_DETAILS.md` - Test execution guide with state-of-the-code validation
- `src/backend/mcp/IMPORTANT_MCP_DETAILS.md` - MCP architecture (shows DSPyCoordinator removal)
- `database/IMPORTANT_DB_CONNECTION.md` - Database architecture
- `RECOMMENDED_STRUCTURE.md` - File structure recommendations

---

## 🎉 State-of-the-Code Validation Integration

### **✅ What's Been Added**
- **Module Validation**: Automatic detection of missing/renamed modules
- **Import Path Tracking**: Consistent import structure validation
- **State Reporting**: Current codebase state documentation
- **Automated Fixes**: Tools for resolving import issues

### **🔧 New Test Runner Features**
- `--validate-modules`: Run module validation as part of test suite
- `--generate-report`: Generate detailed module validation report
- **Integrated Reporting**: Module validation results included in test results

### **📊 Validation Results**
- **42 test files** analyzed
- **311 import statements** checked
- **49 missing modules** identified
- **6 inconsistent paths** detected
- **Status**: needs_attention

### **🚀 Ready for Dynamic Codebase**
The test infrastructure now supports:
- **Automatic module validation** on every test run
- **State-of-the-code reporting** for current codebase state
- **Import path consistency checking** across all platforms
- **Automated issue detection** and reporting

**This ensures our test plan always reflects the current state of the codebase, even as modules are frequently added, renamed, or removed.**

---

## 🔍 ARCHITECTURE CHANGES SUMMARY

### **DSPy Coordinator Removal**
- **Removed**: `src/backend/mcp/coordinators/dspy_coordinator.py`
- **Reason**: DSPy integrated directly into orchestrators
- **New Location**: `src/backend/mcp/orchestrators/rag_qa_orchestrator.py`
- **Impact**: Tests need to be updated to use new architecture

### **Module Location Changes**
- **noise_agent**: Exists in `tests/` directory, not in `src/`
- **personas**: Exists in `src/backend/personas/`, not at top level
- **core**: Exists in `src/backend/core/`, not at top level

### **Dependency Requirements**
- **pypdf**: Used for PDF processing (currently using PyPDF2)
- **sentence_transformers**: Used in RAG orchestrator
- **huggingface_hub**: Used for HuggingFace integration
