# 🧪 Testing Protocols Reference Guide

## 📋 **Overview**

This document provides a comprehensive reference for the testing protocols, frameworks, and best practices used in the VectorQA Sage project. The testing infrastructure is production-grade with extensive coverage, security checks, and automated reporting.

**🔄 This guide consolidates all testing documentation into one comprehensive reference.**

---

## 🏗️ **Core Testing Framework**

### **Primary Framework: Pytest**
- **Version**: Latest stable
- **Configuration**: `tests/pytest.ini`
- **Coverage Requirement**: 70% minimum
- **Reports**: HTML and terminal coverage reports

### **Test Discovery Pattern**
```python
# File naming convention
test_*.py          # Test files
Test*              # Test classes  
test_*             # Test functions
```

### **Test Categories**
1. **Unit Tests**: Individual component testing
2. **Integration Tests**: End-to-end workflow testing
3. **Performance Tests**: Load and stress testing
4. **Security Tests**: Credential leak detection
5. **Comprehensive Tests**: Full system validation
6. **MCP Tests**: Model Context Protocol testing
7. **DSPy Tests**: DSPy framework testing
8. **Environment Tests**: Cross-environment compatibility

---

## 🚀 **Test Runner System**

### **Main Runner: `tests/run_tests.py`**

#### **Command Options**
```bash
# Quick tests (no coverage)
python3 run_tests.py --fast

# With coverage reporting
python3 run_tests.py --coverage

# Verbose output
python3 run_tests.py --verbose

# Specific test file
python3 run_tests.py --test tests/test_integration.py

# Module validation
python3 run_tests.py --validate-modules

# Generate detailed report
python3 run_tests.py --generate-report

# Skip credential checking
python3 run_tests.py --no-credential-check

# Skip cleanup
python3 run_tests.py --no-cleanup
```

#### **Key Features**
- **Platform Detection**: Auto-detects Windows/macOS/Linux
- **Credential Security**: Checks for hardcoded credentials
- **Results Management**: Timestamped test results with symlinks
- **Cleanup**: Automatic temporary file cleanup
- **Environment Setup**: Automatic Python path configuration

---

## 🔧 **Test Configuration**

### **Pytest Configuration (`tests/pytest.ini`)**
```ini
[tool:pytest]
testpaths = tests
python_files = test_*.py
python_classes = Test*
python_functions = test_*
addopts = 
    -v
    --cov=app
    --cov-report=html
    --cov-report=term-missing
    --cov-fail-under=70
filterwarnings =
    ignore::DeprecationWarning
    ignore::PendingDeprecationWarning
```

### **Coverage Standards**
- **Minimum Coverage**: 70%
- **HTML Reports**: Generated in `data/tests/latest/coverage_html/`
- **Terminal Reports**: Missing line coverage displayed
- **Failure Threshold**: Build fails if coverage < 70%

---

## 🎭 **Test Fixtures (`tests/conftest.py`)**

### **Standard Fixtures Available**

#### **Sample Data Fixtures**
```python
@pytest.fixture
def sample_qa_data():
    """Sample QA data for testing."""
    return [
        {
            "topic": "finance",
            "report_chunk": "The company reported quarterly earnings of $1.2 billion.",
            "retrieved_context": "Financial performance metrics and quarterly reports.",
            "validation_result": "positive"
        },
        # ... more sample data
    ]

@pytest.fixture
def sample_json_file(sample_qa_data):
    """Create a temporary JSON file with sample data."""
    # Creates temporary file, yields path, cleans up after
```

#### **Mock Fixtures**
```python
@pytest.fixture
def mock_streamlit():
    """Mock Streamlit components for testing."""
    with patch('streamlit.file_uploader') as mock_uploader, \
         patch('streamlit.write') as mock_write, \
         patch('streamlit.success') as mock_success, \
         patch('streamlit.error') as mock_error, \
         patch('streamlit.download_button') as mock_download:
        
        yield {
            'uploader': mock_uploader,
            'write': mock_write,
            'success': mock_success,
            'error': mock_error,
            'download': mock_download
        }

@pytest.fixture
def mock_aws_clients():
    """Mock AWS clients for testing."""
    with patch('boto3.client') as mock_client:
        mock_s3 = Mock()
        mock_bedrock = Mock()
        mock_client.side_effect = lambda service: mock_s3 if service == 's3' else mock_bedrock
        
        yield {
            's3': mock_s3,
            'bedrock': mock_bedrock,
            'client': mock_client
        }

@pytest.fixture
def test_config():
    """Test configuration without AWS dependencies."""
    return {
        "bucket_name": "test-bucket",
        "prefix": "test",
        "num_training_samples": 10,
        "region_name": "us-east-1",
        # ... more config
    }
```

---

## 📝 **Test Patterns & Best Practices**

### **Integration Test Pattern**
```python
class TestIntegration:
    def test_full_data_workflow(self, sample_qa_data):
        """Test the complete data workflow from loading to processing."""
        # Setup
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_file = f.name
            json.dump(sample_qa_data, f)
        
        try:
            # Execute
            loaded_data = load_examples(temp_file)
            
            # Assert
            assert len(loaded_data) == 3
            assert loaded_data == sample_qa_data
            
        finally:
            # Cleanup
            if os.path.exists(temp_file):
                os.unlink(temp_file)
```

### **Mocking Pattern**
```python
@patch('streamlit.file_uploader')
@patch('streamlit.write') 
@patch('streamlit.success')
def test_upload_tab_integration(self, mock_success, mock_write, mock_uploader, sample_json_file):
    """Test with mocked external dependencies."""
    # Mock the file uploader to return our sample file
    mock_uploader.return_value = sample_json_file
    
    # Test the function
    result = some_function()
    
    # Assert the mocks were called correctly
    mock_uploader.assert_called_once()
    mock_success.assert_called_once()
```

### **Unit Test Pattern**
```python
class TestValidator:
    def test_validation_module_initialization(self):
        """Test ValidationModule initialization."""
        # Arrange
        mock_predictor = lambda x: "Correct"
        
        # Act
        module = ValidationModule(mock_predictor)
        
        # Assert
        assert module.predictor == mock_predictor
        assert hasattr(module, 'forward')
        assert callable(module.forward)
```

---

## 🔍 **Test Categories & Files**

### **Core System Tests**
- `test_integration.py` - End-to-end workflows
- `test_config.py` - Configuration validation
- `test_validator.py` - Data validation
- `test_example_manager.py` - Data management
- `test_normalize_labels.py` - Label processing

### **MCP Architecture Tests**
- `test_mcp_workflow.py` - Message Control Protocol
- `test_mcp_integration_comprehensive.py` - Full MCP testing
- `test_mcp_security_validation.py` - Security validation
- `test_mcp_hierarchy.py` - Hierarchy validation
- `test_mcp_coverage_summary.py` - Coverage analysis

### **QA System Tests**
- `test_simple_qa_orchestrator.py` - Simple QA testing
- `test_enhanced_qa_orchestrator.py` - Enhanced QA testing
- `test_advanced_qa_orchestrator.py` - Advanced QA testing
- `test_database_enhanced_qa_orchestrator.py` - Database QA testing

### **Performance & Load Tests**
- `test_realtime_infrastructure.py` - Real-time performance
- `test_environment_compatibility.py` - Environment testing
- `test_progressive_complexity_integration.py` - Complexity testing

### **Error Tracking Tests**
- `test_error_tracking_comprehensive.py` - Comprehensive error tracking
- `test_error_tracking_scenarios.py` - Error scenarios
- `run_error_tracking_test_suite.py` - Error tracking suite

### **Security & Validation Tests**
- `test_credential_loading.py` - Credential management
- `test_import_structure.py` - Import validation
- `test_control_risks_yaml.py` - Risk control validation

### **Worker & Service Tests**
- `test_specialized_workers_quick.py` - Worker testing
- `test_orchestrators_quick.py` - Orchestrator testing
- `test_communication_quick.py` - Communication testing
- `test_context_management_quick.py` - Context management

---

## 🛡️ **Security & Quality Checks**

### **Credential Leak Detection**
```python
def check_credentials():
    """Check that credentials are properly configured and no hardcoded values exist."""
    sensitive_patterns = [
        "Fujifuji500!",
        "vectorqa_user", 
        "vectorqa-cluster.cluster-cu562e4m02nq.us-east-1.rds.amazonaws.com",
        "postgresql://vectorqa_user:"
    ]
    
    # Scans for hardcoded credentials in test output
```

### **Module Validation**
- Validates all modules are properly structured
- Checks for missing dependencies
- Ensures consistent import paths
- Reports structural issues

### **Environment Compatibility**
- Cross-platform testing (Windows/macOS/Linux)
- Python version compatibility
- Dependency validation
- Platform-specific configurations

---

## 📊 **Results Management**

### **Test Results Structure**
```
data/tests/
├── 2024-01-15_14-30-25/          # Timestamped results
│   ├── test_output.txt           # Test output
│   ├── error_output.txt          # Error details
│   ├── coverage_html/            # HTML coverage report
│   └── module_validation.json    # Module validation results
└── latest/                       # Symlink to latest results
```

### **Coverage Reports**
- **HTML Reports**: `data/tests/latest/coverage_html/index.html`
- **Terminal Reports**: Missing line coverage displayed
- **Coverage Threshold**: 70% minimum required

### **Error Handling**
- Detailed error capture and logging
- Credential leak detection in output
- Module validation error reporting
- Cleanup of temporary files

---

## 🔄 **Continuous Integration**

### **GitHub Actions Integration**
```yaml
# Example GitHub Actions workflow
- name: Run Tests
  run: |
    cd tests
    python3 run_tests.py --coverage --validate-modules
```

### **Pre-commit Hooks**
- Automatic test execution on commit
- Coverage threshold enforcement
- Credential leak prevention
- Module validation checks

---

## 📚 **Writing New Tests**

### **Test File Template**
```python
#!/usr/bin/env python3
"""
Test module for [Component Name]
"""

import pytest
import sys
import os
from unittest.mock import patch, Mock

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

class TestComponentName:
    """Test suite for ComponentName."""
    
    def test_basic_functionality(self):
        """Test basic functionality."""
        # Arrange
        # Act
        # Assert
        pass
    
    def test_error_handling(self):
        """Test error handling."""
        with pytest.raises(ValueError):
            # Code that should raise ValueError
            pass
    
    @patch('external.dependency')
    def test_with_mocks(self, mock_dependency):
        """Test with mocked dependencies."""
        mock_dependency.return_value = "mocked_value"
        # Test code here
        pass
```

### **Best Practices**
1. **Descriptive Names**: Use clear, descriptive test names
2. **Arrange-Act-Assert**: Follow AAA pattern
3. **Single Responsibility**: Each test should test one thing
4. **Clean Setup/Teardown**: Use fixtures and try/finally blocks
5. **Mock External Dependencies**: Don't rely on external services
6. **Test Both Success and Failure**: Cover error cases
7. **Use Fixtures**: Leverage existing fixtures for common setup
8. **Documentation**: Add docstrings to test functions

---

## 🚨 **Troubleshooting**

### **Common Issues**

#### **Import Errors**
```bash
# Solution: Ensure src is in Python path
export PYTHONPATH="${PYTHONPATH}:/path/to/src"
```

#### **Coverage Failures**
```bash
# Check coverage locally
python3 -m pytest --cov=app --cov-report=term-missing
```

#### **Credential Issues**
```bash
# Skip credential checking for development
python3 run_tests.py --no-credential-check
```

#### **Platform-Specific Issues**
```bash
# Check platform detection
python3 run_tests.py --verbose
```

### **Debug Mode**
```bash
# Run with debug output
python3 -m pytest -v -s --tb=long
```

---

## 📈 **Performance Testing**

### **Load Testing**
- `test_realtime_infrastructure.py` - Real-time performance validation
- Stress testing with large datasets
- Memory usage monitoring
- Response time validation

### **Scalability Testing**
- Progressive complexity testing
- Worker pool performance
- Orchestrator efficiency
- Database connection pooling

---

## 🔗 **Integration with AHA System**

The testing protocols integrate seamlessly with the Automated Health Awareness (AHA) system:

### **Health Checks in Tests**
```python
def test_architectural_health(self):
    """Test that architectural health is maintained."""
    from backend.health import ReorgDepartment
    
    reorg_dept = ReorgDepartment(".")
    health_report = reorg_dept.run_health_check()
    
    assert health_report.overall_status.value == "healthy"
    assert health_report.metrics['health_score'] >= 0.7
```

### **Pre-commit Health Validation**
```bash
# Run health checks before tests
python3 src/backend/health/aha_system.py --pre-commit
python3 run_tests.py --coverage
```

---

## 🧪 **Specialized Testing Frameworks**

### **DSPy Testing**
```python
# DSPy integration testing
def test_dspy_integration():
    """Test DSPy framework integration."""
    import dspy
    
    # Test DSPy import
    assert dspy.__version__ >= "3.0.0"
    
    # Test our DSPy components
    from src.backend.mcp.coordinators.dspy_coordinator import DSPyCoordinator
    coordinator = DSPyCoordinator()
    assert coordinator is not None
```

### **MCP Testing**
```python
# MCP protocol testing
def test_mcp_protocol():
    """Test Model Context Protocol implementation."""
    from src.backend.mcp.protocol import MCPProtocol
    
    protocol = MCPProtocol()
    assert protocol.validate_message_format({"type": "request"})
```

### **AWS Integration Testing**
```python
# AWS service testing (with mocks)
@patch('boto3.client')
def test_aws_integration(self, mock_boto3):
    """Test AWS service integration."""
    mock_s3 = Mock()
    mock_boto3.return_value = mock_s3
    
    # Test S3 operations
    from src.backend.services.s3_service import S3Service
    s3_service = S3Service()
    result = s3_service.upload_file("test.txt", "test-bucket")
    assert result is True
```

---

## 📊 **Historical Test Results**

### **DSPy Testing Results**
```
🧪 BASIC DSPY TESTS
========================================
✅ DSPy Import (version: 3.0.1)
✅ Basic Configuration
✅ Signature Creation
✅ Predictor Creation
✅ Chain of Thought
✅ Our Config Import
✅ Our Coordinator Import
✅ Parameter Variations
✅ Error Handling

Total tests: 9
Passed: 9
Failed: 0
🎉 All basic DSPy tests passed!
```

### **MCP Testing Results**
```
🧪 MCP PROTOCOL TESTS
========================================
✅ Message Format Validation
✅ Protocol Handlers
✅ Coordinator Integration
✅ Worker Communication
✅ Error Handling
✅ Security Validation

Total tests: 6
Passed: 6
Failed: 0
🎉 All MCP tests passed!
```

### **Integration Testing Results**
```
🧪 INTEGRATION TESTS
========================================
✅ End-to-End Workflows
✅ Cross-Module Communication
✅ Database Integration
✅ AWS Service Integration
✅ Error Recovery
✅ Performance Benchmarks

Total tests: 12
Passed: 11
Failed: 1 (known issue with external API)
🎉 91.7% success rate
```

---

## 🎯 **Test Execution Strategies**

### **Manual Testing Scenarios**
```python
# Manual test scenarios for risk management
test_scenarios = [
    {
        "id": "1",
        "name": "Model Performance Degradation",
        "risk_category": "Model Risk",
        "severity": "High",
        "description": "Credit scoring model accuracy dropped from 95% to 78%"
    },
    {
        "id": "2", 
        "name": "VaR Model Breach",
        "risk_category": "Market Risk",
        "severity": "Critical",
        "description": "Value at Risk exceeded limits during market volatility"
    },
    {
        "id": "3",
        "name": "Data Quality Issues", 
        "risk_category": "Operational Risk",
        "severity": "Medium",
        "description": "Training data completeness dropped below 90% threshold"
    }
]
```

### **Automated Test Suites**
```bash
# Run comprehensive test suite
python3 tests/run_tests.py --coverage --validate-modules

# Run specific test categories
python3 -m pytest tests/test_mcp_workflow.py -v
python3 -m pytest tests/test_dspy_basic.py -v
python3 -m pytest tests/test_integration.py -v
```

---

## 📞 **Support & Maintenance**

### **Test Maintenance**
- Regular fixture updates
- Mock dependency updates
- Coverage threshold adjustments
- New test category additions

### **Documentation Updates**
- Test pattern documentation
- Fixture usage examples
- Troubleshooting guides
- Best practice updates

### **Performance Monitoring**
- Test execution time tracking
- Memory usage monitoring
- Coverage trend analysis
- Failure pattern analysis

---

## 🎉 **Status Summary**

### **✅ Overall Assessment**
- **Test Coverage**: ✅ **COMPREHENSIVE** (70%+ coverage)
- **Framework**: ✅ **PRODUCTION-GRADE** (Pytest with full CI/CD)
- **Documentation**: ✅ **CONSOLIDATED** (Single comprehensive guide)
- **Quality Assurance**: ✅ **ROBUST** (Security, performance, integration)
- **Integration**: ✅ **AHA-COMPATIBLE** (Health monitoring integration)

### **🚀 Ready for Production**
The testing suite is **comprehensive and reliable**. All core functionality is validated, and the system integrates seamlessly with the AHA health monitoring system.

---

## 📚 **Related Documentation**

- [AHA System Guide](AHA_SYSTEM_GUIDE.md) - Automated Health Awareness
- [Additional Safeguards](ADDITIONAL_SAFEGUARDS.md) - Cascade & Loop Prevention
- [Architecture Documentation](architecture/) - System Architecture
- [Implementation Guide](implementation/) - Implementation Details

---

**Last Updated**: January 2024  
**Maintained By**: Testing Team  
**Version**: 2.0.0 (Consolidated)  
**Status**: ✅ **PRODUCTION READY**
