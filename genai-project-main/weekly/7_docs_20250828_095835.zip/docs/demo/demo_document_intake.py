#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Document Intake Demonstration - MCP Workflow

This script demonstrates the exact MCP steps that happen when a document
"walks into the doctor's office" (lands in input folder) before processing.
"""

import logging
import sys
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('document_intake_demo.log')
    ]
)

logger = logging.getLogger(__name__)

# Add src to path for imports
sys.path.append(str(Path(__file__).parent / "src"))

# Import MCP components
from backend.mcp.orchestrators.qa_orchestrator import QAOrchestrator
from backend.mcp.coordinators.dspy_coordinator import DSPyCoordinator
from backend.core.document_processor import DocumentProcessor


class DocumentIntakeDemo:
    """Demonstrates document intake workflow like a doctor's office"""
    
    def __init__(self):
        self.input_dir = Path("input")
        self.output_dir = Path("data/output")
        self.output_dir.mkdir(exist_ok=True)
        
        # Initialize MCP components
        self.qa_orchestrator = None
        self.dspy_coordinator = None
        self.document_processor = None
        
        print("🏥 DOCUMENT INTAKE DEMO - MCP WORKFLOW")
        print("=" * 60)
        print("Simulating a document walking into the 'doctor's office'")
        print("=" * 60)

    def initialize_mcp_components(self):
        """Initialize MCP components (like setting up the doctor's office)"""
        print("\n🔧 STEP 0: SETTING UP THE 'DOCTOR'S OFFICE' (MCP Components)")
        print("-" * 50)
        
        try:
            # Initialize QA Orchestrator (like the main doctor)
            print("👨‍⚕️  Initializing QA Orchestrator (Main Doctor)...")
            self.qa_orchestrator = QAOrchestrator()
            print("✅ QA Orchestrator ready")
            
            # Initialize DSPy Coordinator (like the nurse)
            print("👩‍⚕️  Initializing DSPy Coordinator (Nurse)...")
            self.dspy_coordinator = DSPyCoordinator()
            print("✅ DSPy Coordinator ready")
            
            # Initialize Document Processor (like the receptionist)
            print("👩‍💼 Initializing Document Processor (Receptionist)...")
            self.document_processor = DocumentProcessor()
            print("✅ Document Processor ready")
            
            print("🏥 All MCP components initialized - 'Doctor's office' is ready!")
            return True
            
        except Exception as e:
            print(f"❌ Failed to set up 'doctor's office': {e}")
            return False

    def step_1_reception_check_in(self):
        """Step 1: Document arrives at reception (input folder)"""
        print("\n📋 STEP 1: DOCUMENT ARRIVES AT RECEPTION (Input Folder)")
        print("-" * 50)
        
        # Check what documents are in the input folder
        documents = list(self.input_dir.glob("*"))
        
        if not documents:
            print("⚠️  No documents found in input folder")
            print("   (Like an empty waiting room)")
            return []
        
        print(f"📄 Found {len(documents)} document(s) in input folder:")
        for i, doc in enumerate(documents, 1):
            print(f"   {i}. {doc.name} ({doc.stat().st_size} bytes)")
        
        # Simulate receptionist checking in each document
        checked_in_docs = []
        for doc in documents:
            print(f"\n👩‍💼 Receptionist checking in: {doc.name}")
            print(f"   📝 Document type: {doc.suffix.upper()}")
            print(f"   📏 Document size: {doc.stat().st_size} bytes")
            print(f"   📅 Arrival time: {datetime.now().strftime('%H:%M:%S')}")
            
            checked_in_docs.append({
                "filename": doc.name,
                "filepath": str(doc),
                "file_size": doc.stat().st_size,
                "file_type": doc.suffix,
                "arrival_time": datetime.now().isoformat(),
                "status": "checked_in"
            })
        
        print(f"\n✅ All {len(checked_in_docs)} documents checked in at reception")
        return checked_in_docs

    def step_2_vital_signs_check(self):
        """Step 2: Document vital signs check (file validation)"""
        print("\n🩺 STEP 2: VITAL SIGNS CHECK (File Validation)")
        print("-" * 50)
        
        checked_in_docs = self.step_1_reception_check_in()
        if not checked_in_docs:
            return []
        
        validated_docs = []
        for doc in checked_in_docs:
            print(f"\n🩺 Checking vital signs for: {doc['filename']}")
            
            # Check file health (like vital signs)
            file_path = Path(doc['filepath'])
            
            # Vital sign 1: File exists
            if file_path.exists():
                print("   ✅ Heartbeat: File exists")
            else:
                print("   ❌ Heartbeat: File missing!")
                continue
            
            # Vital sign 2: File size
            if doc['file_size'] > 0:
                print(f"   ✅ Weight: {doc['file_size']} bytes (healthy)")
            else:
                print("   ❌ Weight: 0 bytes (underweight)")
                continue
            
            # Vital sign 3: File type
            supported_types = ['.pdf', '.docx', '.txt']
            if doc['file_type'].lower() in supported_types:
                print(f"   ✅ Blood type: {doc['file_type'].upper()} (supported)")
            else:
                print(f"   ⚠️  Blood type: {doc['file_type'].upper()} (may need special handling)")
            
            # Vital sign 4: Readable
            try:
                with open(file_path, 'rb') as f:
                    f.read(1024)  # Read first 1KB
                print("   ✅ Breathing: File is readable")
            except Exception as e:
                print(f"   ❌ Breathing: File not readable - {e}")
                continue
            
            doc['status'] = 'vital_signs_ok'
            validated_docs.append(doc)
            print(f"   🏥 Document cleared for processing!")
        
        print(f"\n✅ {len(validated_docs)} documents passed vital signs check")
        return validated_docs

    def step_3_medical_history(self):
        """Step 3: Document medical history (metadata extraction)"""
        print("\n📋 STEP 3: MEDICAL HISTORY (Metadata Extraction)")
        print("-" * 50)
        
        validated_docs = self.step_2_vital_signs_check()
        if not validated_docs:
            return []
        
        print("🔍 Extracting document 'medical history' (metadata)...")
        
        try:
            # Use document processor to extract metadata
            processed_documents = self.document_processor.process_all_documents()
            
            if not processed_documents:
                print("⚠️  No documents could be processed")
                return []
            
            print(f"✅ Successfully processed {len(processed_documents)} documents")
            
            # Extract metadata fields
            metadata = self.document_processor.extract_metadata_fields(processed_documents)
            
            print("\n📋 Document Medical History:")
            for field, value in metadata.items():
                if value and value != "Unknown":
                    print(f"   📝 {field}: {value}")
                else:
                    print(f"   ❓ {field}: Not found")
            
            return processed_documents
            
        except Exception as e:
            print(f"❌ Failed to extract medical history: {e}")
            return []

    def step_4_triage_assessment(self):
        """Step 4: Document triage assessment (priority and routing)"""
        print("\n🚨 STEP 4: TRIAGE ASSESSMENT (Priority & Routing)")
        print("-" * 50)
        
        processed_docs = self.step_3_medical_history()
        if not processed_docs:
            return []
        
        triaged_docs = []
        for doc in processed_docs:
            print(f"\n🚨 Triage assessment for: {doc.get('filename', 'Unknown')}")
            
            # Assess document priority based on content
            content = doc.get('content', '')
            priority_score = 0
            priority_reasons = []
            
            # Priority indicators
            if 'review' in content.lower():
                priority_score += 3
                priority_reasons.append("Contains 'review' - high priority")
            
            if 'validation' in content.lower():
                priority_score += 3
                priority_reasons.append("Contains 'validation' - high priority")
            
            if 'model' in content.lower():
                priority_score += 2
                priority_reasons.append("Contains 'model' - medium priority")
            
            if 'research' in content.lower():
                priority_score += 1
                priority_reasons.append("Contains 'research' - standard priority")
            
            # Determine priority level
            if priority_score >= 5:
                priority = "URGENT"
                wait_time = "Immediate"
            elif priority_score >= 3:
                priority = "HIGH"
                wait_time = "15 minutes"
            elif priority_score >= 1:
                priority = "STANDARD"
                wait_time = "30 minutes"
            else:
                priority = "LOW"
                wait_time = "1 hour"
            
            print(f"   🏥 Priority Level: {priority}")
            print(f"   ⏰ Estimated Wait: {wait_time}")
            print(f"   📊 Priority Score: {priority_score}")
            print(f"   📝 Reasons: {', '.join(priority_reasons)}")
            
            doc['triage'] = {
                'priority': priority,
                'priority_score': priority_score,
                'wait_time': wait_time,
                'reasons': priority_reasons
            }
            
            triaged_docs.append(doc)
        
        print(f"\n✅ {len(triaged_docs)} documents triaged and ready for doctor")
        return triaged_docs

    def step_5_doctor_consultation(self):
        """Step 5: Doctor consultation (QA analysis)"""
        print("\n👨‍⚕️  STEP 5: DOCTOR CONSULTATION (QA Analysis)")
        print("-" * 50)
        
        triaged_docs = self.step_4_triage_assessment()
        if not triaged_docs:
            return None
        
        print("👨‍⚕️  Doctor (QA Orchestrator) beginning consultation...")
        
        try:
            # Use QA Orchestrator to process documents
            workflow_result = self.qa_orchestrator.process_qa_documents()
            
            if workflow_result["status"] == "completed":
                print("✅ Doctor consultation completed successfully!")
                
                # Show consultation results
                doc_result = workflow_result.get("document_result", {})
                extraction_result = workflow_result.get("extraction_result", {})
                report_result = workflow_result.get("report_result", {})
                
                print(f"\n📊 Consultation Summary:")
                print(f"   📋 Documents examined: {doc_result.get('document_count', 0)}")
                print(f"   🔍 Fields extracted: {extraction_result.get('field_count', 0)}")
                print(f"   📄 Reports generated: {len(report_result)}")
                
                return workflow_result
            else:
                print(f"❌ Doctor consultation failed: {workflow_result.get('error', 'Unknown error')}")
                return None
                
        except Exception as e:
            print(f"❌ Doctor consultation error: {e}")
            return None

    def run_complete_intake_workflow(self):
        """Run the complete document intake workflow"""
        print("\n🏥 STARTING COMPLETE DOCUMENT INTAKE WORKFLOW")
        print("=" * 60)
        
        # Step 0: Set up the office
        if not self.initialize_mcp_components():
            return None
        
        # Step 1-5: Complete intake process
        consultation_result = self.step_5_doctor_consultation()
        
        if consultation_result:
            print("\n🎉 DOCUMENT INTAKE WORKFLOW COMPLETED SUCCESSFULLY!")
            print("=" * 60)
            print("📁 Check the 'data/output' directory for generated reports")
            print("📄 Document has been fully processed through MCP workflow")
        else:
            print("\n❌ DOCUMENT INTAKE WORKFLOW FAILED")
            print("=" * 60)
        
        return consultation_result


def main():
    """Main function to run the document intake demonstration"""
    
    # Create demo instance
    demo = DocumentIntakeDemo()
    
    # Run complete workflow
    result = demo.run_complete_intake_workflow()
    
    if result:
        print(f"\n📊 Final Workflow ID: {result.get('workflow_id', 'Unknown')}")
        print(f"⏱️  Total processing time: {datetime.now().strftime('%H:%M:%S')}")


if __name__ == "__main__":
    main()
