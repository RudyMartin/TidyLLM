# Demo & Testing

This folder contains demo applications, test scripts, and demonstration materials for the S3-Native QA system.

## 📋 Contents

### **Demo Applications**
- **[demo_document_intake.py](demo_document_intake.py)** - **📄 DOCUMENT INTAKE** - Demo application for document processing and analysis
- **[demo_test_script.py](demo_test_script.py)** - **🧪 TEST SCRIPT** - Test script for demo functionality
- **[run_3_scenarios.py](run_3_scenarios.py)** - **🎬 SCENARIOS** - Script to run three different demo scenarios
- **[manual_test_scenarios.py](manual_test_scenarios.py)** - **🔍 MANUAL TESTS** - Manual testing scenarios and validation

### **Demo Documentation**
- **[SIMPLE_DEMO_SUMMARY.md](SIMPLE_DEMO_SUMMARY.md)** - **📝 SUMMARY** - Summary of the simple demo application
- **[LAUNCHER_COMPARISON.md](LAUNCHER_COMPARISON.md)** - **⚖️ COMPARISON** - Comparison of different launcher approaches
- **[LAUNCHER_STATUS.md](LAUNCHER_STATUS.md)** - **📊 STATUS** - Current status of launcher implementations
- **[DEMO_RESTRUCTURING_SUMMARY.md](DEMO_RESTRUCTURING_SUMMARY.md)** - **🔄 RESTRUCTURE** - Summary of demo restructuring efforts

## 🎯 Purpose

These files provide:
- **Working demonstrations** of system capabilities
- **Test scenarios** for validation and verification
- **Documentation** of demo functionality
- **Comparison analysis** of different approaches
- **Status tracking** of demo implementations

## 🚀 Getting Started

1. **Review** `SIMPLE_DEMO_SUMMARY.md` - Understand the demo approach
2. **Run** `demo_document_intake.py` - See the system in action
3. **Test** `run_3_scenarios.py` - Execute different scenarios
4. **Validate** `manual_test_scenarios.py` - Manual testing procedures

## 🧪 Testing

- **Automated tests** in the demo scripts
- **Manual validation** procedures
- **Scenario testing** for different use cases
- **Performance testing** and benchmarking
