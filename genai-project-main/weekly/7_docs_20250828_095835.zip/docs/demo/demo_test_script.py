#!/usr/bin/env python3
"""
Demo Test Script for QA Document Processing

This script tests the core functionality of the QA demo:
1. File upload handling
2. Prompt extraction from .md files
3. Custom prompt processing
4. QA orchestrator integration
"""

import sys
import os
from pathlib import Path

def test_qa_demo_imports():
    """Test that all QA demo components can be imported"""
    print("🧪 Testing QA Demo Imports")
    print("=" * 40)
    
    try:
        # Test main QA demo import
        sys.path.append('src')
        from qa_demo import main, validate_review_id
        print("✅ QA Demo main module imported")
        
        # Test QA orchestrator import
        from backend.mcp.orchestrators.qa_orchestrator import QAOrchestrator
        print("✅ QA Orchestrator imported")
        
        # Test DSPy coordinator import
        from backend.mcp.orchestrators.dspy_coordinator import DSPyCoordinator
        print("✅ DSPy Coordinator imported")
        
        return True
        
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False

def test_review_id_validation():
    """Test the review ID validation function"""
    print("\n🔍 Testing Review ID Validation")
    print("=" * 40)
    
    sys.path.append('src')
    from qa_demo import validate_review_id
    
    test_cases = [
        ("REV00001", True),
        ("REV12345", True),
        ("rev00001", False),  # lowercase
        ("REV0001", False),   # too short
        ("REV000001", False), # too long
        ("", False),          # empty
        ("ABC12345", False),  # wrong prefix
    ]
    
    all_passed = True
    for review_id, expected in test_cases:
        is_valid, message = validate_review_id(review_id)
        result = "✅" if is_valid == expected else "❌"
        print(f"{result} {review_id}: {message}")
        if is_valid != expected:
            all_passed = False
    
    return all_passed

def test_file_creation():
    """Test that demo files exist"""
    print("\n📁 Testing Demo Files")
    print("=" * 40)
    
    required_files = [
        "test_prompt.md",
        "demo_document.txt"
    ]
    
    all_exist = True
    for file_path in required_files:
        if Path(file_path).exists():
            print(f"✅ {file_path} exists")
        else:
            print(f"❌ {file_path} missing")
            all_exist = False
    
    return all_exist

def test_prompt_extraction():
    """Test prompt extraction from .md files"""
    print("\n📝 Testing Prompt Extraction")
    print("=" * 40)
    
    try:
        # Read the test prompt file
        with open("test_prompt.md", "r") as f:
            content = f.read()
        
        # Check if it contains expected content
        if "QA Review Prompt" in content:
            print("✅ Prompt file contains expected title")
        else:
            print("❌ Prompt file missing expected title")
            return False
        
        if "Instructions" in content:
            print("✅ Prompt file contains instructions section")
        else:
            print("❌ Prompt file missing instructions section")
            return False
        
        return True
        
    except FileNotFoundError:
        print("❌ test_prompt.md not found")
        return False

def main():
    """Run all tests"""
    print("🚀 QA Demo Functionality Test")
    print("=" * 50)
    
    tests = [
        ("Import Test", test_qa_demo_imports),
        ("Review ID Validation", test_review_id_validation),
        ("Demo Files", test_file_creation),
        ("Prompt Extraction", test_prompt_extraction),
    ]
    
    results = []
    for test_name, test_func in tests:
        print(f"\n🧪 Running {test_name}...")
        result = test_func()
        results.append((test_name, result))
    
    # Summary
    print("\n" + "=" * 50)
    print("📊 TEST RESULTS SUMMARY")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status}: {test_name}")
        if result:
            passed += 1
    
    print(f"\n🎯 Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED! Ready for demo.")
        print("\n📋 Next Steps:")
        print("1. Run: streamlit run src/qa_demo.py")
        print("2. Upload test_prompt.md and demo_document.txt")
        print("3. Enter a custom prompt")
        print("4. Click 'Process Documents'")
    else:
        print("\n⚠️ Some tests failed. Please fix issues before demo.")
        return False
    
    return True

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
