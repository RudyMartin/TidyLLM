# 🎬 VectorQA Sage Demo Scenarios & Walkthroughs

## 🚀 **Quick Start**

### **Launch All Demo Apps**
```bash
# Option 1: Simple launcher
./launch_demo.sh

# Option 2: Python launcher with monitoring
python3 scripts/launch_demo_apps.py
```

### **Available Apps**
1. **MCP Dashboard**: http://localhost:8504 (System overview)
2. **Enhanced QA**: http://localhost:8502 (Document processing)
3. **RAG Query**: http://localhost:8503 (Intelligent search)
4. **Main App**: http://localhost:8501 (Complete pipeline)

---

## 📋 **Demo Scenarios**

### **Scenario 1: System Overview & Architecture**
**App**: MCP Dashboard (Port 8504)
**Duration**: 5-7 minutes
**Audience**: Technical stakeholders, architects

#### **Walkthrough Steps:**
1. **System Architecture Overview**
   - Show MCP hierarchy (Planner → Coordinator → Worker)
   - Explain real-time context integration
   - Demonstrate error tracking system

2. **Performance Metrics**
   - Display current system performance
   - Show error rates and resolution times
   - Demonstrate live monitoring capabilities

3. **Component Status**
   - Check orchestrator health
   - Verify database connectivity
   - Show active workflows

#### **Key Talking Points:**
- **Scalable Architecture**: MCP pattern for complex workflows
- **Real-time Processing**: Live context integration
- **Error Resilience**: Intelligent error tracking and recovery
- **Performance Monitoring**: Comprehensive metrics and alerting

---

### **Scenario 2: Document Processing Pipeline**
**App**: Enhanced QA Demo (Port 8502)
**Duration**: 8-10 minutes
**Audience**: Business users, QA teams

#### **Walkthrough Steps:**
1. **Document Upload**
   - Upload a sample PDF document
   - Show intelligent file validation
   - Demonstrate security checks

2. **Smart Orchestrator Selection**
   - Explain how the system chooses the right orchestrator
   - Show user preference management
   - Demonstrate workflow optimization

3. **Processing Results**
   - Display extracted metadata
   - Show quality assessment
   - Demonstrate error handling

#### **Sample Documents:**
- `input/2506.21734v2_hierarchy.pdf` (Research paper)
- `input/investment-model-validation.pdf` (Financial document)
- Any PDF document for testing

#### **Key Talking Points:**
- **Intelligent Routing**: Automatic orchestrator selection
- **Quality Assurance**: Multi-stage validation
- **User Preferences**: Personalized processing
- **Error Recovery**: Graceful failure handling

---

### **Scenario 3: Intelligent Document Search**
**App**: RAG Query Demo (Port 8503)
**Duration**: 6-8 minutes
**Audience**: Researchers, analysts

#### **Walkthrough Steps:**
1. **Document Database Overview**
   - Show available documents
   - Display processing statistics
   - Demonstrate search capabilities

2. **Natural Language Queries**
   - Ask complex questions about documents
   - Show intelligent answer generation
   - Demonstrate source citations

3. **Advanced Search Features**
   - Semantic search capabilities
   - Multi-document analysis
   - Context-aware responses

#### **Sample Queries:**
- "What are the main findings in the research paper?"
- "How does the investment model handle risk?"
- "What methodology was used for validation?"
- "What are the limitations mentioned?"

#### **Key Talking Points:**
- **Semantic Search**: Understanding context, not just keywords
- **Source Citations**: Transparent answer sources
- **Multi-Document Analysis**: Cross-referencing capabilities
- **Intelligent Reasoning**: Chain-of-thought processing

---

### **Scenario 4: Complete Pipeline Demo**
**App**: Main App (Port 8501)
**Duration**: 10-12 minutes
**Audience**: End-to-end demonstration

#### **Walkthrough Steps:**
1. **Data Upload & Normalization**
   - Upload raw data
   - Show automatic normalization
   - Demonstrate data validation

2. **Dataset Processing**
   - Split and prepare datasets
   - Show example editing
   - Demonstrate quality checks

3. **Model Configuration**
   - Configure DSPy prompts
   - Show prompt optimization
   - Demonstrate model selection

4. **Evaluation & Results**
   - Run model evaluations
   - Show performance metrics
   - Demonstrate result analysis

#### **Key Talking Points:**
- **End-to-End Pipeline**: Complete workflow from data to results
- **DSPy Integration**: Advanced prompt engineering
- **Model Evaluation**: Comprehensive performance analysis
- **Result Visualization**: Clear insights and metrics

---

## 🎯 **Demo Flow Recommendations**

### **For Technical Audiences:**
1. **Start**: MCP Dashboard (System architecture)
2. **Continue**: RAG Query (Technical capabilities)
3. **Finish**: Enhanced QA (Practical applications)

### **For Business Audiences:**
1. **Start**: Enhanced QA (Business value)
2. **Continue**: RAG Query (User experience)
3. **Finish**: Main App (Complete solution)

### **For End-to-End Demo:**
1. **Start**: MCP Dashboard (Overview)
2. **Continue**: Enhanced QA (Processing)
3. **Continue**: RAG Query (Search)
4. **Finish**: Main App (Complete pipeline)

---

## 🔧 **Demo Preparation Checklist**

### **Pre-Demo Setup:**
- [ ] **Environment**: All dependencies installed
- [ ] **Database**: Connection tested and working
- [ ] **Documents**: Sample documents in `input/` directory
- [ ] **Credentials**: API keys configured (if needed)
- [ ] **Network**: Ports 8501-8504 available

### **Demo Materials:**
- [ ] **Sample Documents**: PDF files for processing
- [ ] **Prepared Queries**: Interesting questions to ask
- [ ] **Backup Plans**: Alternative scenarios if something fails
- [ ] **Screenshots**: Key features to highlight

### **Technical Setup:**
- [ ] **Streamlit Apps**: All apps tested and working
- [ ] **Database**: Error tracking tables populated
- [ ] **MCP Components**: All orchestrators initialized
- [ ] **Error Handling**: Graceful failure modes tested

---

## 🚨 **Troubleshooting Guide**

### **Common Issues:**

#### **App Won't Start:**
```bash
# Check if port is in use
lsof -i :8501
lsof -i :8502
lsof -i :8503
lsof -i :8504

# Kill existing processes
pkill -f streamlit
```

#### **Database Connection Issues:**
```bash
# Test database connection
python3 scripts/debug_credentials.py

# Check environment variables
echo $DATABASE_URL
```

#### **Import Errors:**
```bash
# Check Python path
python3 -c "import sys; print(sys.path)"

# Test core imports
python3 -c "from backend.mcp.orchestrators.qa_orchestrator import QAOrchestrator; print('✅ Import successful')"
```

#### **NumPy Warnings:**
- These are known compatibility warnings
- Don't affect functionality
- Can be ignored for demo purposes

### **Emergency Procedures:**
1. **App Crashes**: Restart with `./launch_demo.sh`
2. **Database Issues**: Use mock data mode
3. **Import Errors**: Check `src/` directory structure
4. **Performance Issues**: Reduce document size or complexity

---

## 📊 **Demo Metrics & Success Criteria**

### **Technical Metrics:**
- **Response Time**: < 5 seconds for queries
- **Accuracy**: > 90% for document processing
- **Error Rate**: < 5% for standard operations
- **Uptime**: 100% during demo period

### **User Experience Metrics:**
- **Ease of Use**: Intuitive interface navigation
- **Feature Discovery**: Users can find key features
- **Problem Solving**: System handles edge cases gracefully
- **Value Demonstration**: Clear business benefits shown

### **Demo Success Indicators:**
- **Engagement**: Audience asks questions
- **Understanding**: Clear comprehension of capabilities
- **Interest**: Follow-up requests for more information
- **Action**: Requests for next steps or trials

---

## 🎉 **Demo Completion Checklist**

### **Post-Demo Actions:**
- [ ] **Q&A Session**: Address audience questions
- [ ] **Next Steps**: Provide clear action items
- [ ] **Contact Information**: Share follow-up details
- [ ] **Documentation**: Provide access to guides
- [ ] **Feedback**: Collect demo feedback

### **Follow-up Materials:**
- [ ] **Technical Documentation**: Architecture guides
- [ ] **User Guides**: How-to documentation
- [ ] **API Documentation**: Integration guides
- [ ] **Case Studies**: Real-world examples
- [ ] **Contact Information**: Support channels

---

## 🔄 **Demo Customization**

### **Industry-Specific Scenarios:**
- **Financial Services**: Risk assessment documents
- **Healthcare**: Medical research papers
- **Legal**: Contract analysis
- **Research**: Academic papers
- **Manufacturing**: Technical specifications

### **Feature Highlighting:**
- **Security**: Data protection and privacy
- **Scalability**: Performance under load
- **Integration**: API and system connectivity
- **Compliance**: Regulatory requirements
- **Cost Optimization**: Resource efficiency

---

## 📞 **Support & Resources**

### **Documentation:**
- **Architecture**: `docs/architecture/`
- **API Reference**: `docs/api/`
- **User Guides**: `docs/user/`
- **Developer Guides**: `docs/developer/`

### **Contact Information:**
- **Technical Support**: [Support Email]
- **Sales Inquiries**: [Sales Email]
- **Documentation**: [Documentation URL]
- **GitHub**: [Repository URL]

### **Additional Resources:**
- **Video Tutorials**: [Video Library URL]
- **Webinars**: [Webinar Schedule]
- **Training**: [Training Program URL]
- **Community**: [Community Forum URL]

---

*This demo guide is designed to showcase the full capabilities of VectorQA Sage while providing a smooth, professional demonstration experience.*

