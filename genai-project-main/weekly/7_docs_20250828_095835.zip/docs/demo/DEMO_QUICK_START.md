
# VectorQA Sage Demo - Quick Start Guide

## 🚀 Launch Commands

### 1. MCP Dashboard (System Overview)
```bash
cd src
streamlit run mcp_dashboard.py
```

### 2. Enhanced QA Demo (Document Processing)
```bash
cd src
streamlit run enhanced_qa_demo.py
```

### 3. RAG Query Demo (Intelligent Search)
```bash
cd src
streamlit run rag_query_demo.py
```

### 4. Basic QA Demo (Simple Processing)
```bash
cd src
streamlit run qa_demo.py
```

## 🧪 Test Commands

### Mock Live Context Test
```bash
python3 scripts/test_mock_live_context.py
```

### MCP Hierarchy Test
```bash
python3 tests/test_mcp_hierarchy_simple.py
```

### Live Context Integration Test
```bash
python3 tests/test_live_context_integration.py
```

## 📄 Sample Documents
Location: `data/input/reviews/`
Use any PDF files in this directory for document processing demos.

## 🎯 Demo Flow
1. Start with MCP Dashboard to show system architecture
2. Use Enhanced QA Demo for document processing
3. Switch to RAG Query Demo for intelligent search
4. Show test results to prove system reliability

## 🚨 Emergency Commands
If Streamlit apps fail, use these command-line demos:
```bash
python3 scripts/test_mock_live_context.py
python3 scripts/test_rag_with_database.py
```
