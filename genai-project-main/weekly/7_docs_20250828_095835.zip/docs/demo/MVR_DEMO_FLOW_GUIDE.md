# 🎯 MVR Demo Flow Guide

## **How Users Progress Through the Demo**

### **📋 Demo Flow Overview**

The MVR demo has a **3-step progression** with clear visual indicators and requirements for each step:

```
Step 1: Upload Files → Step 2: Pick Report → Step 3: Review Results
```

---

## **🔓 STEP 1: Upload Files (Requirements to Unlock Step 2)**

### **✅ Files Requirement**
- **Minimum**: At least 1 valid file uploaded
- **Supported Types**: txt, pdf, docx, xlsx, csv, json, yaml, py, sql, md, xml, images (jpg, png, gif, svg, bmp, tiff, webp)
- **Size Limit**: < 50MB per file
- **Validation**: No critical issues (empty files, unsupported types, etc.)

### **✅ Template Requirement (VST - Validation Scope Template)**
- **Required For**: Models created after June 2024
- **Optional For**: Older models (automatic detection)
- **Content Requirements**: Must contain 3+ scope elements:
  - scope, objectives, criteria, methodology, testing
  - validation, performance, data, model, risk, compliance
- **Supported Formats**: json, yaml, yml, txt, csv

### **✅ MVR Report Requirement**
- **Required**: Model validation report (always required)
- **Content Requirements**: Must contain 2+ report sections + MVR keywords
- **MVR Keywords**: model, validation, risk, performance, testing
- **Report Sections**: executive summary, methodology, results, findings, recommendations, conclusions, model performance, validation, testing, risk assessment, limitations, assumptions, data quality, model monitoring
- **Supported Formats**: pdf, docx, txt, md, html

---

## **🎨 Visual Indicators & User Feedback**

### **Step 1 Status Colors**
- **🟢 Green**: All requirements passed (can proceed to Step 2)
- **🟡 Yellow**: Files uploaded but validation issues (check requirements)
- **🔵 Blue**: Partially complete (some files uploaded)
- **⚫ Gray**: Nothing uploaded yet

### **Connection Lines**
- **🟢 Green Line**: Preflight passed (Step 2 unlocked)
- **⚫ Gray Line**: Preflight not passed (Step 2 locked)

### **Step 2 Status**
- **🔵 Blue**: Available when preflight passes
- **🔒 Gray**: Locked when requirements not met

### **Step 3 Status**
- **🟠 Orange**: Active when in Step 3
- **🔒 Gray**: Locked until Step 2 completed

---

## **🚨 Emergency Demo Mode**

### **Bypass All Requirements**
- **Location**: Sidebar button "🚨 Emergency Demo Mode"
- **Purpose**: For demo emergencies when teammates break the flow
- **Action**: Creates mock successful state with pre-loaded sample files
- **Use Case**: When demo needs to proceed regardless of file uploads

---

## **🧪 Testing Scenarios for Demo Prep**

### **Scenario 1: Complete Success Path**
1. **Upload Files**: 1+ valid files (txt, pdf, etc.)
2. **Upload VST**: Template with 3+ scope elements
3. **Upload MVR**: Report with 2+ sections + MVR keywords
4. **Expected Result**: Step 1 turns green, connection line green, Step 2 unlocks

### **Scenario 2: Partial Success (VST Optional)**
1. **Upload Files**: 1+ valid files
2. **Skip VST**: Don't upload template (for older models)
3. **Upload MVR**: Valid report
4. **Expected Result**: Step 1 turns green, Step 2 unlocks (VST optional)

### **Scenario 3: Validation Issues**
1. **Upload Files**: 1+ files with issues (too large, wrong format)
2. **Upload VST**: Template with insufficient scope elements
3. **Upload MVR**: Report without MVR keywords
4. **Expected Result**: Step 1 yellow, validation messages shown, Step 2 locked

### **Scenario 4: Emergency Mode**
1. **No Files**: Don't upload anything
2. **Click Emergency Mode**: Use sidebar bypass
3. **Expected Result**: Demo proceeds with mock data

---

## **🔍 Validation Messages Users See**

### **File Validation Messages**
- `✅ X files uploaded` - Success
- `❌ At least 1 file required` - Missing files
- `⚠️ Many files uploaded - processing may be slow` - Too many files
- `File too large (>50MB) - may cause memory issues` - Size issue
- `Unsupported file type: .xyz` - Format issue

### **Template Validation Messages**
- `⚠️ Validation Scope Template not provided` - Missing VST
- `💡 VST Recommended: Upload template for better validation` - Optional VST
- `Only X scope elements found (need 3+)` - Insufficient content

### **MVR Report Validation Messages**
- `❌ Missing: model validation report` - Missing report
- `Only X report sections found (need 2+)` - Insufficient sections
- `No clear MVR content detected` - Missing MVR keywords

---

## **🎯 Demo Preparation Checklist**

### **✅ Pre-Demo Setup**
- [ ] MVR demo running on http://localhost:8501
- [ ] Test files prepared for each scenario
- [ ] Emergency demo mode tested
- [ ] All file types supported (txt, pdf, docx, xlsx, csv, json, yaml, py, sql, md, xml, images)

### **✅ Test Files to Prepare**
- [ ] **Valid Text File**: Contains MVR keywords (model, validation, risk)
- [ ] **Valid VST Template**: JSON/YAML with 3+ scope elements
- [ ] **Valid MVR Report**: Text/PDF with 2+ sections + MVR keywords
- [ ] **Invalid Files**: Too large, wrong format, empty files
- [ ] **Image Files**: JPG, PNG for testing image support

### **✅ Demo Flow Testing**
- [ ] **Complete Success Path**: All requirements met
- [ ] **Partial Success Path**: VST optional scenario
- [ ] **Validation Issues**: Show error handling
- [ ] **Emergency Mode**: Bypass functionality
- [ ] **File Type Support**: Test all supported formats

### **✅ Visual Indicators Testing**
- [ ] **Step 1 Colors**: Green, Yellow, Blue, Gray states
- [ ] **Connection Lines**: Green vs Gray
- [ ] **Step 2 Unlock**: Blue when available
- [ ] **Step 3 Progression**: Orange when active

---

## **🚀 Demo Execution Tips**

### **For Presenters**
1. **Start with Success Path**: Show the ideal flow first
2. **Demonstrate Validation**: Show what happens with invalid files
3. **Use Emergency Mode**: If anything goes wrong
4. **Highlight Visual Feedback**: Point out color changes and unlocks
5. **Show File Type Support**: Upload different file types

### **For Demo Preparation**
1. **Test All Scenarios**: Ensure each path works
2. **Prepare Backup Files**: Have multiple valid files ready
3. **Practice Emergency Mode**: Know how to use the bypass
4. **Check Visual Indicators**: Verify colors and unlocks work
5. **Test File Limits**: Know what happens with large/invalid files

---

## **🔧 Technical Implementation Details**

### **Preflight Validation Logic**
```python
# Requirements check
files_requirement = (
    len(valid_files) >= 1 and  # At least one valid file
    len([f for f in validation_status['file_analysis'] if len(f['issues']) == 0]) >= 1  # No critical issues
)

template_requirement = (
    template_file is not None and 
    validation_status.get('template_analysis', {}).get('valid', False)
)

mvr_report_requirement = (
    mvr_report_file is not None and 
    validation_status.get('mvr_report_analysis', {}).get('valid', False)
)

# Unlock Step 2
validation_status['can_proceed_to_step2'] = (
    files_requirement and template_requirement and mvr_report_requirement
)
```

### **Visual Indicator Logic**
```python
# Step 1 color logic
if preflight_passed:
    step1_color = "#28a745"  # Green
elif requirements_count >= max_requirements:
    step1_color = "#ffc107"  # Yellow
elif requirements_count >= 1:
    step1_color = "#17a2b8"  # Blue
else:
    step1_color = "#6c757d"  # Gray

# Connection line logic
line_color = "#28a745" if preflight_passed else "#6c757d"

# Step 2 unlock logic
if preflight_passed:
    step2_color = "#238196"  # Blue (available)
    step2_icon = "🔄"
else:
    step2_color = "#6c757d"  # Gray (locked)
    step2_icon = "🔒"
```

---

## **📊 Demo Success Metrics**

### **User Experience Goals**
- ✅ **Clear Requirements**: Users understand what's needed
- ✅ **Visual Feedback**: Immediate indication of progress
- ✅ **Helpful Messages**: Specific guidance on what's missing
- ✅ **Graceful Degradation**: Works even with issues
- ✅ **Emergency Recovery**: Can always proceed with demo

### **Technical Goals**
- ✅ **100% Success Rate**: All valid files processed
- ✅ **Fast Processing**: Quick file validation and analysis
- ✅ **Error Handling**: Graceful handling of invalid files
- ✅ **Unified Processing**: All file types handled consistently
- ✅ **Demo Protection**: Sabotage-resistant and reliable
