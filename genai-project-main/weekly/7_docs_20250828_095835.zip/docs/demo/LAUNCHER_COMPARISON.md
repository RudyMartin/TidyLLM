# Launcher Comparison: start_demo.py vs start_demo_simple.py

## Overview

We have two similar launchers for the QA Enhanced demo. Here are the key differences:

## 🔍 **Key Differences**

### 1. **Additional Features in `start_demo.py`**

| Feature | `start_demo.py` | `start_demo_simple.py` |
|---------|----------------|----------------------|
| **Advanced Launcher Option** | ✅ `--advanced` flag | ❌ No advanced option |
| **Enhanced Help Text** | ✅ Includes Quick Start guide | ❌ Basic help only |
| **Feature Description** | ✅ Shows features in launch message | ❌ Basic description only |
| **File Size** | 208 lines | 165 lines |

### 2. **Command Line Options**

#### `start_demo.py` Options:
```bash
python start_demo.py [OPTIONS]
  --port, -p PORT        # Port to run demo (default: 8502)
  --headless, -H         # Run in headless mode
  --install, -i          # Install streamlit if missing
  --advanced, -a         # Launch advanced launcher instead
```

#### `start_demo_simple.py` Options:
```bash
python start_demo_simple.py [OPTIONS]
  --port, -p PORT        # Port to run demo (default: 8502)
  --headless, -H         # Run in headless mode
  --install, -i          # Install streamlit if missing
```

### 3. **Help Text Comparison**

#### `start_demo.py` Help:
```
Examples:
  python start_demo.py                    # Launch demo on default port 8502
  python start_demo.py --port 8505       # Launch demo on custom port
  python start_demo.py --headless        # Launch in headless mode
  python start_demo.py --install         # Install streamlit if missing
  python start_demo.py --advanced        # Launch advanced launcher instead

Quick Start:
  1. python start_demo.py --install      # Install dependencies
  2. python start_demo.py                # Launch demo
  3. Open browser to http://localhost:8502
  4. Upload PDF documents and start chatting!
```

#### `start_demo_simple.py` Help:
```
Examples:
  python start_demo_simple.py                    # Launch demo on default port 8502
  python start_demo_simple.py --port 8505        # Launch demo on custom port
  python start_demo_simple.py --headless         # Launch in headless mode
  python start_demo_simple.py --install          # Install streamlit if missing
```

### 4. **Launch Message Comparison**

#### `start_demo.py` Launch Message:
```
🚀 Launching QA Enhanced Demo
📁 App file: /path/to/src/demo.py
🌐 URL: http://localhost:8502
📝 Description: Simple chatbox with document upload and comparison
💡 Features: Document upload, TOC extraction, Bibliography analysis, Chat interface
```

#### `start_demo_simple.py` Launch Message:
```
🚀 Launching QA Enhanced Demo
📁 App file: /path/to/src/demo.py
🌐 URL: http://localhost:8502
📝 Description: Simple chatbox with document upload and comparison
```

## 🎯 **When to Use Which**

### Use `start_demo.py` when:
- ✅ You want the **primary demo launcher**
- ✅ You might need to access the advanced launcher later
- ✅ You want more detailed help and instructions
- ✅ You're sharing with users who might need advanced features
- ✅ You want the most feature-complete demo launcher

### Use `start_demo_simple.py` when:
- ✅ You want the **absolute minimal launcher**
- ✅ You only need the demo, never the advanced features
- ✅ You want the smallest, simplest possible launcher
- ✅ You're in a constrained environment where every line matters

## 📊 **Code Differences**

### Additional Functions in `start_demo.py`:
```python
def launch_advanced_launcher():
    """Launch the advanced launcher"""
    # ... implementation to launch start_advanced.py
```

### Additional Logic in `start_demo.py`:
```python
# Launch advanced launcher if requested
if args.advanced:
    return launch_advanced_launcher()
```

### Enhanced Launch Message in `start_demo.py`:
```python
print("💡 Features: Document upload, TOC extraction, Bibliography analysis, Chat interface")
```

## 🚀 **Recommendation**

**Use `start_demo.py` as the primary launcher** because:
1. It has all the features of `start_demo_simple.py`
2. Plus the ability to launch the advanced launcher
3. Better help text and user experience
4. More informative launch messages

**Keep `start_demo_simple.py` as a backup** for:
1. Minimal deployment scenarios
2. When you need the absolute smallest launcher
3. As a reference for the core functionality

## 🔧 **Maintenance**

Both launchers share the same core functionality:
- ✅ Streamlit installation
- ✅ Environment setup
- ✅ Demo launching
- ✅ Error handling

Changes to core functionality should be made to both files, or consider consolidating them into a single launcher with a `--simple` flag if the differences become too small to justify separate files.
