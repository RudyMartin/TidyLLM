#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🔧 Manual Test Scenarios for Risk Management System

A simple script to manually test how the system responds to different risk scenarios.
This allows you to see the system in action and understand how it processes different types of problems.

Usage:
    python3 manual_test_scenarios.py

Features:
- Test different risk scenarios
- See system responses in real-time
- Generate detailed reports
- Compare different configurations
"""

import os
import sys
import json
import time
from datetime import datetime
from typing import Dict, Any, List

# Add src to path for backend imports
sys.path.insert(0, 'src')

def print_header(title: str):
    """Print a formatted header."""
    print("\n" + "="*80)
    print(f"🔧 {title}")
    print("="*80)

def print_section(title: str):
    """Print a formatted section."""
    print(f"\n📋 {title}")
    print("-" * 60)

def print_result(title: str, result: Any):
    """Print a formatted result."""
    print(f"\n✅ {title}")
    print(f"   {result}")

def print_error(title: str, error: str):
    """Print a formatted error."""
    print(f"\n❌ {title}")
    print(f"   {error}")

def print_warning(title: str, warning: str):
    """Print a formatted warning."""
    print(f"\n⚠️ {title}")
    print(f"   {warning}")

class ManualTestRunner:
    """Manual test runner for risk management scenarios."""
    
    def __init__(self):
        self.test_results = []
        self.start_time = datetime.now()
        
        # Define test scenarios
        self.scenarios = {
            "1": {
                "name": "Model Performance Degradation",
                "description": "Credit scoring model accuracy dropped from 95% to 78%",
                "risk_category": "Model Risk",
                "severity": "High",
                "expected_response": "Should identify as high-risk, recommend immediate review"
            },
            "2": {
                "name": "VaR Model Breach",
                "description": "Value at Risk exceeded limits during market volatility",
                "risk_category": "Market Risk", 
                "severity": "Critical",
                "expected_response": "Should trigger immediate action, recommend model suspension"
            },
            "3": {
                "name": "Data Quality Issues",
                "description": "Training data completeness dropped below 90% threshold",
                "risk_category": "Operational Risk",
                "severity": "Medium",
                "expected_response": "Should flag for investigation, recommend data review"
            },
            "4": {
                "name": "Credit Portfolio Concentration",
                "description": "Portfolio concentration in high-risk sectors exceeded limits",
                "risk_category": "Credit Risk",
                "severity": "High",
                "expected_response": "Should recommend portfolio rebalancing, risk assessment"
            },
            "5": {
                "name": "Real-time Fraud Detection Failure",
                "description": "Fraud detection model stopped processing transactions",
                "risk_category": "Operational Risk",
                "severity": "Critical",
                "expected_response": "Should trigger emergency response, manual review process"
            }
        }
    
    def run_single_test(self, scenario_id: str) -> Dict[str, Any]:
        """Run a single test scenario."""
        if scenario_id not in self.scenarios:
            return {"error": f"Scenario {scenario_id} not found"}
        
        scenario = self.scenarios[scenario_id]
        
        print_section(f"Testing: {scenario['name']}")
        print(f"Description: {scenario['description']}")
        print(f"Risk Category: {scenario['risk_category']}")
        print(f"Severity: {scenario['severity']}")
        print(f"Expected: {scenario['expected_response']}")
        
        # Simulate system response
        test_start = time.time()
        
        try:
            # Try to use real system if available
            response = self._get_system_response(scenario)
        except Exception as e:
            # Fallback to simulated response
            response = self._get_simulated_response(scenario)
            print_warning("System Response", f"Using simulated response: {str(e)}")
        
        test_duration = time.time() - test_start
        
        # Format the response
        result = {
            "scenario_id": scenario_id,
            "scenario_name": scenario["name"],
            "risk_category": scenario["risk_category"],
            "severity": scenario["severity"],
            "system_response": response,
            "test_duration_seconds": test_duration,
            "timestamp": datetime.now().isoformat()
        }
        
        # Display results
        print_result("System Response", response.get("summary", "No response generated"))
        print_result("Risk Score", f"{response.get('risk_score', 'N/A')}/10")
        print_result("Confidence", f"{response.get('confidence', 'N/A')}%")
        print_result("Processing Time", f"{test_duration:.3f} seconds")
        
        if "recommendations" in response:
            print_result("Recommendations", "")
            for i, rec in enumerate(response["recommendations"], 1):
                print(f"   {i}. {rec}")
        
        self.test_results.append(result)
        return result
    
    def _get_system_response(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """Get response from the real system if available."""
        try:
            from src.backend.mcp.coordinators.sme_context_coordinator import SMEContextCoordinator
            from src.backend.mcp.config.debug_config import DebugConfig
            
            # Use production configuration for testing
            config = DebugConfig.production()
            coordinator = SMEContextCoordinator(debug_config=config)
            
            # Get SME analysis
            analysis = coordinator.analyze_with_sme_context(
                scenario["description"],
                scenario["risk_category"]
            )
            
            if "error" in analysis:
                raise Exception(analysis["error"])
            
            return {
                "summary": analysis.get("analysis", "Analysis completed"),
                "risk_score": analysis.get("risk_score", "N/A"),
                "confidence": analysis.get("confidence_level", "N/A"),
                "recommendations": [analysis.get("recommendations", "No specific recommendations")],
                "status": analysis.get("status", "unknown")
            }
            
        except ImportError:
            raise Exception("SME Context Coordinator not available")
        except Exception as e:
            raise Exception(f"System error: {str(e)}")
    
    def _get_simulated_response(self, scenario: Dict[str, Any]) -> Dict[str, Any]:
        """Get simulated response when real system is not available."""
        # Simulate processing time
        time.sleep(0.5)
        
        # Generate realistic response based on scenario
        if "Model Performance" in scenario["name"]:
            return {
                "summary": "Model performance degradation detected. This requires immediate attention as it affects loan approval accuracy.",
                "risk_score": 8,
                "confidence": 85,
                "recommendations": [
                    "Immediately review model inputs and data quality",
                    "Suspend automatic loan approvals until issue is resolved",
                    "Schedule emergency model validation review",
                    "Notify stakeholders of potential impact on business operations"
                ],
                "status": "high_risk"
            }
        elif "VaR Model" in scenario["name"]:
            return {
                "summary": "VaR model breach detected during market volatility. This is a critical risk event requiring immediate action.",
                "risk_score": 9,
                "confidence": 90,
                "recommendations": [
                    "Immediately suspend VaR model and switch to manual risk assessment",
                    "Review portfolio positions and consider risk reduction measures",
                    "Notify senior management and risk committee",
                    "Implement enhanced monitoring for similar market conditions"
                ],
                "status": "critical_risk"
            }
        elif "Data Quality" in scenario["name"]:
            return {
                "summary": "Data quality issues detected affecting model training. This may impact model accuracy and reliability.",
                "risk_score": 6,
                "confidence": 75,
                "recommendations": [
                    "Investigate data pipeline and identify root cause",
                    "Review data validation procedures",
                    "Assess impact on current model performance",
                    "Implement additional data quality checks"
                ],
                "status": "medium_risk"
            }
        elif "Credit Portfolio" in scenario["name"]:
            return {
                "summary": "Credit portfolio concentration risk detected. Portfolio is over-exposed to high-risk sectors.",
                "risk_score": 7,
                "confidence": 80,
                "recommendations": [
                    "Conduct portfolio stress testing",
                    "Consider portfolio rebalancing to reduce concentration",
                    "Review credit limits for affected sectors",
                    "Implement enhanced monitoring for concentration risk"
                ],
                "status": "high_risk"
            }
        else:  # Default response
            return {
                "summary": f"Risk event detected in {scenario['risk_category']}. Analysis completed with {scenario['severity'].lower()} severity.",
                "risk_score": 5,
                "confidence": 70,
                "recommendations": [
                    "Review the specific risk event details",
                    "Assess potential impact on business operations",
                    "Consider appropriate risk mitigation measures",
                    "Monitor for similar events in the future"
                ],
                "status": "medium_risk"
            }
    
    def run_all_tests(self) -> List[Dict[str, Any]]:
        """Run all test scenarios."""
        print_header("MANUAL TEST SCENARIOS - COMPLETE TEST SUITE")
        
        print("Available test scenarios:")
        for scenario_id, scenario in self.scenarios.items():
            print(f"  {scenario_id}. {scenario['name']} ({scenario['risk_category']})")
        
        print("\nRunning all scenarios...")
        
        for scenario_id in self.scenarios.keys():
            self.run_single_test(scenario_id)
        
        return self.test_results
    
    def run_interactive_test(self):
        """Run interactive test where user chooses scenarios."""
        print_header("MANUAL TEST SCENARIOS - INTERACTIVE MODE")
        
        while True:
            print("\nAvailable test scenarios:")
            for scenario_id, scenario in self.scenarios.items():
                print(f"  {scenario_id}. {scenario['name']} ({scenario['risk_category']})")
            print("  all. Run all scenarios")
            print("  quit. Exit testing")
            
            choice = input("\nEnter your choice (1-5, 'all', or 'quit'): ").strip().lower()
            
            if choice == 'quit':
                break
            elif choice == 'all':
                self.run_all_tests()
                break
            elif choice in self.scenarios:
                self.run_single_test(choice)
            else:
                print_error("Invalid Choice", "Please enter a valid scenario number (1-5), 'all', or 'quit'")
    
    def generate_report(self, filename: str = None) -> str:
        """Generate a detailed test report."""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"manual_test_report_{timestamp}.json"
        
        report = {
            "test_summary": {
                "total_tests": len(self.test_results),
                "start_time": self.start_time.isoformat(),
                "end_time": datetime.now().isoformat(),
                "duration_seconds": (datetime.now() - self.start_time).total_seconds()
            },
            "test_results": self.test_results,
            "scenarios_tested": list(self.scenarios.keys()),
            "system_status": "operational" if self.test_results else "no_tests_run"
        }
        
        # Calculate statistics
        if self.test_results:
            risk_scores = [r["system_response"].get("risk_score", 0) for r in self.test_results if isinstance(r["system_response"].get("risk_score"), (int, float))]
            avg_risk_score = sum(risk_scores) / len(risk_scores) if risk_scores else 0
            
            durations = [r["test_duration_seconds"] for r in self.test_results]
            avg_duration = sum(durations) / len(durations) if durations else 0
            
            report["statistics"] = {
                "average_risk_score": round(avg_risk_score, 2),
                "average_response_time": round(avg_duration, 3),
                "highest_risk_score": max(risk_scores) if risk_scores else 0,
                "lowest_risk_score": min(risk_scores) if risk_scores else 0
            }
        
        # Save report
        with open(filename, 'w') as f:
            json.dump(report, f, indent=2)
        
        return filename
    
    def display_summary(self):
        """Display a summary of test results."""
        if not self.test_results:
            print_warning("No Tests Run", "No test results to display")
            return
        
        print_header("TEST SUMMARY")
        
        print(f"Total Tests Run: {len(self.test_results)}")
        print(f"Test Duration: {(datetime.now() - self.start_time).total_seconds():.2f} seconds")
        
        # Risk score distribution
        risk_scores = [r["system_response"].get("risk_score", 0) for r in self.test_results if isinstance(r["system_response"].get("risk_score"), (int, float))]
        if risk_scores:
            print(f"Average Risk Score: {sum(risk_scores) / len(risk_scores):.1f}/10")
            print(f"Highest Risk Score: {max(risk_scores)}/10")
            print(f"Lowest Risk Score: {min(risk_scores)}/10")
        
        # Response time statistics
        durations = [r["test_duration_seconds"] for r in self.test_results]
        if durations:
            print(f"Average Response Time: {sum(durations) / len(durations):.3f} seconds")
            print(f"Fastest Response: {min(durations):.3f} seconds")
            print(f"Slowest Response: {max(durations):.3f} seconds")
        
        # Risk category breakdown
        categories = {}
        for result in self.test_results:
            cat = result["risk_category"]
            categories[cat] = categories.get(cat, 0) + 1
        
        print(f"\nRisk Categories Tested:")
        for category, count in categories.items():
            print(f"  {category}: {count} test(s)")


def main():
    """Main function to run manual tests."""
    print_header("MANUAL TEST SCENARIOS FOR RISK MANAGEMENT SYSTEM")
    print("This script allows you to test how the system responds to different risk scenarios.")
    print("You can run individual tests, all tests, or use interactive mode.")
    
    runner = ManualTestRunner()
    
    # Check if user wants interactive mode
    mode = input("\nChoose mode:\n1. Interactive (choose scenarios)\n2. Run all scenarios\n3. Run single scenario\n\nEnter choice (1-3): ").strip()
    
    if mode == "1":
        runner.run_interactive_test()
    elif mode == "2":
        runner.run_all_tests()
    elif mode == "3":
        scenario_id = input("Enter scenario number (1-5): ").strip()
        if scenario_id in runner.scenarios:
            runner.run_single_test(scenario_id)
        else:
            print_error("Invalid Scenario", "Please enter a number between 1 and 5")
            return
    else:
        print_error("Invalid Mode", "Please enter 1, 2, or 3")
        return
    
    # Generate and display summary
    runner.display_summary()
    
    # Generate report
    report_file = runner.generate_report()
    print_result("Report Generated", f"Detailed report saved to: {report_file}")
    
    print_header("TESTING COMPLETE")
    print("Check the generated report for detailed results and analysis.")


if __name__ == "__main__":
    main()
