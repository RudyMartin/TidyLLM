# Unified LLM Gateway Integration with MLflow

## 🎯 **Overview**

The Unified LLM Gateway provides a single, integrated interface for all LLM interactions with comprehensive MLflow integration for experiment tracking, performance monitoring, and analytics.

## 🏗️ **Architecture**

```
┌─────────────────────────────────────────────────────────────┐
│                    Unified LLM Gateway                      │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Local LLM     │  │  Remote LLM     │  │   MLflow     │ │
│  │  (ZLLM/Ollama)  │  │  (Cloud APIs)   │  │ Integration  │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Enhanced      │  │   Metrics       │  │   Cost       │ │
│  │   Agents        │  │   Tracking      │  │ Management   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## 🚀 **Key Features**

### **1. Unified Interface**
- **Single Gateway**: One interface for local and remote LLMs
- **Automatic Fallback**: Local → Remote → Error handling
- **Model Routing**: Intelligent model selection based on task

### **2. MLflow Integration**
- **Experiment Tracking**: All LLM calls tracked in MLflow
- **Performance Metrics**: Response time, token usage, cost
- **Artifact Storage**: Prompts, responses, and metadata
- **Run Management**: Nested runs for complex workflows

### **3. Enhanced Agents**
- **Document Classification**: AI-powered categorization
- **Standards Librarian**: Intelligent document matching
- **Digest Generator**: Smart content summarization
- **Metadata Extraction**: Automated data extraction

### **4. Production Features**
- **Metrics Tracking**: Comprehensive call analytics
- **Cost Management**: Token and cost monitoring
- **Error Handling**: Robust error recovery
- **Batch Processing**: Efficient bulk operations

## 📋 **Usage Examples**

### **Basic LLM Call**
```python
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway

# Initialize gateway
gateway = UnifiedLLMGateway(
    experiment_name="my-experiment",
    enable_tracking=True
)

# Make LLM call
response = gateway.call_llm(
    agent_name="document_processor",
    task_type="classification",
    prompt="Classify this document...",
    model_preference="gpt-4"
)

print(f"Response: {response.content}")
print(f"Cost: ${response.cost:.4f}")
print(f"Tokens: {response.total_tokens}")
```

### **Enhanced Document Processing**
```python
from src.backend.llm.llm_enhanced_agents import LLMEnhancedDocumentClassifier
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway

# Initialize unified gateway
gateway = UnifiedLLMGateway(experiment_name="document-analysis")

# Initialize enhanced classifier
classifier = LLMEnhancedDocumentClassifier(gateway)

# Classify document
document = {"content": "Document content...", "filename": "report.pdf"}
classification = classifier.classify_with_llm(document)

print(f"Classification: {classification['classification']}")
print(f"Confidence: {classification['confidence']}%")
```

### **QA Orchestration**
```python
from src.backend.mcp.orchestrators.llm_enhanced_qa_orchestrator import LLMEnhancedQAOrchestrator

# Initialize orchestrator
orchestrator = LLMEnhancedQAOrchestrator(
    config_path="dev_configs/qa_criteria_simplified.yaml"
)

# Process documents with LLM enhancement
results = orchestrator.process_qa_documents_with_llm(
    input_dir="input",
    batch_id="batch_20241201_001"
)

print(f"Processed {len(results['documents'])} documents")
print(f"Total cost: ${results['total_cost']:.2f}")
```

## 🔧 **Configuration**

### **Environment Variables**
```bash
# MLflow Configuration
MLFLOW_TRACKING_URI=http://localhost:5000
MLFLOW_EXPERIMENT_NAME=unified-llm-gateway

# Gateway Configuration
ZLLM_GATEWAY_URL=http://localhost:11434
REMOTE_GATEWAY_URL=https://api.openai.com/v1

# Database Configuration
DATABASE_URL=postgresql://user:pass@localhost:5432/mlflow
```

### **Gateway Configuration**
```python
gateway = UnifiedLLMGateway(
    experiment_name="production-experiment",
    tracking_uri="http://mlflow-server:5000",
    enable_tracking=True,
    local_gateway_url="http://localhost:11434",
    remote_gateway_url="https://api.openai.com/v1",
    default_gateway="local"  # "local", "remote", or "auto"
)
```

## 📊 **MLflow Integration Details**

### **Experiment Structure**
```
unified-llm-gateway/
├── run_001_document_classifier_20241201_143022/
│   ├── params/
│   │   ├── agent_name: document_classifier
│   │   ├── task_type: classification
│   │   ├── model_preference: gpt-4
│   │   └── gateway_type: local
│   ├── metrics/
│   │   ├── response_time: 1.234
│   │   ├── input_tokens: 150
│   │   ├── output_tokens: 75
│   │   ├── total_tokens: 225
│   │   ├── cost: 0.0045
│   │   └── success: 1.0
│   └── artifacts/
│       ├── prompt_001.txt
│       ├── response_001.txt
│       └── metadata.json
```

### **Metrics Tracked**
- **Performance**: Response time, throughput
- **Usage**: Token consumption, cost analysis
- **Quality**: Success rate, error tracking
- **Gateway**: Local vs remote usage patterns

## 🗄️ **Database Integration**

### **MLflow Database Schema**
```sql
-- MLflow experiments table
CREATE TABLE experiments (
    experiment_id INTEGER PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    artifact_location VARCHAR(256),
    lifecycle_stage VARCHAR(32)
);

-- MLflow runs table
CREATE TABLE runs (
    run_uuid VARCHAR(32) PRIMARY KEY,
    name VARCHAR(250),
    source_type VARCHAR(32),
    source_name VARCHAR(500),
    entry_point_name VARCHAR(200),
    user_id VARCHAR(256),
    status VARCHAR(9),
    start_time BIGINT,
    end_time BIGINT,
    source_version VARCHAR(50),
    lifecycle_stage VARCHAR(32),
    artifact_uri VARCHAR(200),
    experiment_id INTEGER
);

-- MLflow parameters table
CREATE TABLE params (
    key VARCHAR(250) NOT NULL,
    value VARCHAR(250) NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    PRIMARY KEY (key, run_uuid)
);

-- MLflow metrics table
CREATE TABLE metrics (
    key VARCHAR(250) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    timestamp BIGINT NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    step BIGINT DEFAULT 0,
    PRIMARY KEY (key, run_uuid, timestamp, step)
);
```

### **Centralized Database Setup**
```bash
# PostgreSQL for MLflow
docker run -d \
  --name mlflow-postgres \
  -e POSTGRES_DB=mlflow \
  -e POSTGRES_USER=mlflow \
  -e POSTGRES_PASSWORD=password \
  -p 5432:5432 \
  postgres:15

# MLflow server
docker run -d \
  --name mlflow-server \
  -p 5000:5000 \
  -e MLFLOW_TRACKING_URI=postgresql://mlflow:password@mlflow-postgres:5432/mlflow \
  -e MLFLOW_DEFAULT_ARTIFACT_ROOT=s3://mlflow-artifacts \
  ghcr.io/mlflow/mlflow:latest
```

## 🔍 **Monitoring and Analytics**

### **MLflow UI Access**
```bash
# Access MLflow UI
open http://localhost:5000

# View experiments
# - Experiment: unified-llm-gateway
# - Runs: All LLM calls with metrics
# - Artifacts: Prompts, responses, metadata
```

### **Performance Dashboard**
```python
# Get batch metrics
batch_summary = gateway.metrics_tracker.get_batch_summary("batch_20241201_001")

print(f"Total calls: {batch_summary['total_calls']}")
print(f"Success rate: {batch_summary['success_rate']:.2%}")
print(f"Total cost: ${batch_summary['total_cost']:.4f}")
print(f"Gateway breakdown: {batch_summary['gateway_breakdown']}")
```

## 🚨 **Error Handling**

### **Fallback Strategy**
1. **Primary**: Local ZLLM gateway
2. **Secondary**: Remote cloud API
3. **Tertiary**: Error response with details

### **Error Tracking**
```python
# All errors logged to MLflow
try:
    response = gateway.call_llm(...)
except Exception as e:
    # Error automatically logged to MLflow
    logger.error(f"LLM call failed: {e}")
    # Fallback response returned
```

## 🔒 **Security Considerations**

### **Authentication**
- **API Keys**: Secure storage for remote APIs
- **Environment Variables**: No hardcoded credentials
- **Network Security**: HTTPS for all remote calls

### **Data Privacy**
- **Local Processing**: Sensitive data stays local
- **Encryption**: All data encrypted in transit
- **Audit Trail**: Complete MLflow audit trail

## 📈 **Scaling for 200 Users**

### **Recommended Architecture**
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Load Balancer │    │  MLflow Server  │    │ Central Database│
│   (Nginx/ALB)   │◄──►│   (Multiple)    │◄──►│  (PostgreSQL)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Application   │    │   ZLLM Cluster  │    │   S3 Storage    │
│   Instances     │    │   (Multiple)    │    │   (Artifacts)   │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

### **Deployment Steps**
1. **Centralized MLflow**: PostgreSQL backend
2. **Load Balancing**: Multiple application instances
3. **ZLLM Cluster**: Multiple local LLM servers
4. **Monitoring**: Comprehensive metrics and alerts

## ✅ **Benefits**

### **For Developers**
- **Single Interface**: One gateway for all LLM needs
- **Comprehensive Tracking**: Full MLflow integration
- **Error Handling**: Robust fallback mechanisms
- **Performance**: Optimized for production use

### **For Operations**
- **Centralized Monitoring**: MLflow dashboard
- **Cost Control**: Token and cost tracking
- **Scalability**: Designed for 200+ users
- **Reliability**: Multiple fallback options

### **For Business**
- **Analytics**: Complete usage insights
- **Compliance**: Full audit trail
- **Efficiency**: Optimized resource usage
- **Quality**: Enhanced document processing

## 🎯 **Next Steps**

1. **Deploy Centralized MLflow**: Set up PostgreSQL backend
2. **Configure Load Balancing**: Scale for 200 users
3. **Monitor Performance**: Use MLflow dashboards
4. **Optimize Costs**: Analyze usage patterns
5. **Enhance Security**: Implement additional controls

---

**The Unified LLM Gateway provides a production-ready, scalable solution for managing all LLM interactions with comprehensive MLflow integration and enhanced document processing capabilities.** 🚀
