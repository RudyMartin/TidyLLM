# MLflow Centralized Setup for 200 Users

## 🎯 **Problem Statement**

**Current Issue**: MLflow stores data in local files, which doesn't scale for 200 users across multiple servers/cluster nodes.

**Solution**: Centralized MLflow with PostgreSQL backend for shared access, scalability, and reliability.

## 🏗️ **Centralized MLflow Architecture**

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   MLflow UI     │    │  MLflow Server  │    │ PostgreSQL DB   │
│   (Web App)     │◄──►│   (API Server)  │◄──►│  (Centralized)  │
│                 │    │                 │    │                 │
│ • Dashboard     │    │ • REST API      │    │ • Experiments   │
│ • Experiments   │    │ • Authentication│    │ • Runs          │
│ • Model Registry│    │ • Authorization │    │ • Artifacts     │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         ▼                       ▼                       ▼
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Load Balancer │    │   S3 Storage    │    │   Monitoring    │
│   (Nginx/ALB)   │    │   (Artifacts)   │    │   (Prometheus)  │
└─────────────────┘    └─────────────────┘    └─────────────────┘
```

## 🚀 **Deployment Options**

### **Option 1: Docker Compose (Development/Staging)**

```yaml
# docker-compose.yml
version: '3.8'

services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: mlflow
      POSTGRES_USER: mlflow
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U mlflow"]
      interval: 30s
      timeout: 10s
      retries: 3

  mlflow:
    image: ghcr.io/mlflow/mlflow:latest
    environment:
      MLFLOW_TRACKING_URI: postgresql://mlflow:${POSTGRES_PASSWORD}@postgres:5432/mlflow
      MLFLOW_DEFAULT_ARTIFACT_ROOT: s3://${S3_BUCKET}/mlflow-artifacts
      AWS_ACCESS_KEY_ID: ${AWS_ACCESS_KEY_ID}
      AWS_SECRET_ACCESS_KEY: ${AWS_SECRET_ACCESS_KEY}
      AWS_DEFAULT_REGION: ${AWS_DEFAULT_REGION}
    ports:
      - "5000:5000"
    depends_on:
      postgres:
        condition: service_healthy
    command: mlflow server --host 0.0.0.0 --port 5000

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - mlflow

volumes:
  postgres_data:
```

### **Option 2: Kubernetes (Production)**

```yaml
# mlflow-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mlflow-server
spec:
  replicas: 3
  selector:
    matchLabels:
      app: mlflow
  template:
    metadata:
      labels:
        app: mlflow
    spec:
      containers:
      - name: mlflow
        image: ghcr.io/mlflow/mlflow:latest
        env:
        - name: MLFLOW_TRACKING_URI
          value: "postgresql://mlflow:$(POSTGRES_PASSWORD)@postgres-service:5432/mlflow"
        - name: MLFLOW_DEFAULT_ARTIFACT_ROOT
          value: "s3://$(S3_BUCKET)/mlflow-artifacts"
        - name: AWS_ACCESS_KEY_ID
          valueFrom:
            secretKeyRef:
              name: aws-secrets
              key: access-key-id
        - name: AWS_SECRET_ACCESS_KEY
          valueFrom:
            secretKeyRef:
              name: aws-secrets
              key: secret-access-key
        ports:
        - containerPort: 5000
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: mlflow-service
spec:
  selector:
    app: mlflow
  ports:
  - port: 5000
    targetPort: 5000
  type: LoadBalancer
```

## 🔧 **Setup Instructions**

### **Step 1: Database Setup**

```bash
# Create PostgreSQL database
CREATE DATABASE mlflow;

# Create user with permissions
CREATE USER mlflow WITH PASSWORD 'secure_password';
GRANT ALL PRIVILEGES ON DATABASE mlflow TO mlflow;

# Verify connection
psql -h localhost -U mlflow -d mlflow -c "SELECT version();"
```

### **Step 2: MLflow Server Configuration**

```bash
# Environment variables
export MLFLOW_TRACKING_URI="postgresql://mlflow:secure_password@localhost:5432/mlflow"
export MLFLOW_DEFAULT_ARTIFACT_ROOT="s3://your-bucket/mlflow-artifacts"
export AWS_ACCESS_KEY_ID="your-access-key"
export AWS_SECRET_ACCESS_KEY="your-secret-key"
export AWS_DEFAULT_REGION="us-east-1"

# Start MLflow server
mlflow server \
  --host 0.0.0.0 \
  --port 5000 \
  --backend-store-uri postgresql://mlflow:secure_password@localhost:5432/mlflow \
  --default-artifact-root s3://your-bucket/mlflow-artifacts
```

### **Step 3: Application Configuration**

```python
# Update your Unified LLM Gateway
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway

gateway = UnifiedLLMGateway(
    experiment_name="production-experiment",
    tracking_uri="http://mlflow-server:5000",  # Centralized server
    enable_tracking=True,
    local_gateway_url="http://localhost:11434",
    remote_gateway_url="https://api.openai.com/v1"
)
```

## 📊 **Database Schema**

### **MLflow Core Tables**

```sql
-- Experiments table
CREATE TABLE experiments (
    experiment_id INTEGER PRIMARY KEY,
    name VARCHAR(256) NOT NULL,
    artifact_location VARCHAR(256),
    lifecycle_stage VARCHAR(32)
);

-- Runs table
CREATE TABLE runs (
    run_uuid VARCHAR(32) PRIMARY KEY,
    name VARCHAR(250),
    source_type VARCHAR(32),
    source_name VARCHAR(500),
    entry_point_name VARCHAR(200),
    user_id VARCHAR(256),
    status VARCHAR(9),
    start_time BIGINT,
    end_time BIGINT,
    source_version VARCHAR(50),
    lifecycle_stage VARCHAR(32),
    artifact_uri VARCHAR(200),
    experiment_id INTEGER,
    FOREIGN KEY (experiment_id) REFERENCES experiments(experiment_id)
);

-- Parameters table
CREATE TABLE params (
    key VARCHAR(250) NOT NULL,
    value VARCHAR(250) NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    PRIMARY KEY (key, run_uuid),
    FOREIGN KEY (run_uuid) REFERENCES runs(run_uuid)
);

-- Metrics table
CREATE TABLE metrics (
    key VARCHAR(250) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    timestamp BIGINT NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    step BIGINT DEFAULT 0,
    PRIMARY KEY (key, run_uuid, timestamp, step),
    FOREIGN KEY (run_uuid) REFERENCES runs(run_uuid)
);

-- Tags table
CREATE TABLE tags (
    key VARCHAR(250) NOT NULL,
    value VARCHAR(250) NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    PRIMARY KEY (key, run_uuid),
    FOREIGN KEY (run_uuid) REFERENCES runs(run_uuid)
);
```

## 🔐 **Security Configuration**

### **Authentication Setup**

```python
# MLflow authentication
import mlflow
from mlflow.tracking import MlflowClient

# Set tracking URI
mlflow.set_tracking_uri("http://mlflow-server:5000")

# Basic authentication
mlflow.set_experiment("my-experiment")

# For production, use proper authentication
# mlflow.set_tracking_uri("http://username:password@mlflow-server:5000")
```

### **Network Security**

```bash
# Firewall rules
sudo ufw allow 5000/tcp  # MLflow server
sudo ufw allow 5432/tcp  # PostgreSQL
sudo ufw allow 80/tcp    # Load balancer
sudo ufw allow 443/tcp   # HTTPS

# SSL/TLS configuration
# Use reverse proxy (nginx) with SSL termination
```

## 📈 **Scaling for 200 Users**

### **Performance Optimization**

```sql
-- Database indexes for performance
CREATE INDEX idx_runs_experiment_id ON runs(experiment_id);
CREATE INDEX idx_runs_user_id ON runs(user_id);
CREATE INDEX idx_runs_status ON runs(status);
CREATE INDEX idx_metrics_run_uuid ON metrics(run_uuid);
CREATE INDEX idx_params_run_uuid ON params(run_uuid);

-- Partitioning for large datasets
CREATE TABLE metrics_partitioned (
    key VARCHAR(250) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    timestamp BIGINT NOT NULL,
    run_uuid VARCHAR(32) NOT NULL,
    step BIGINT DEFAULT 0
) PARTITION BY RANGE (timestamp);

-- Create partitions by month
CREATE TABLE metrics_2024_01 PARTITION OF metrics_partitioned
    FOR VALUES FROM (1704067200000) TO (1706745600000);
```

### **Load Balancing**

```nginx
# nginx.conf
upstream mlflow_backend {
    server mlflow-1:5000;
    server mlflow-2:5000;
    server mlflow-3:5000;
}

server {
    listen 80;
    server_name mlflow.yourdomain.com;

    location / {
        proxy_pass http://mlflow_backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## 🔍 **Monitoring and Health Checks**

### **Health Check Endpoint**

```python
# MLflow health check
import requests

def check_mlflow_health():
    try:
        response = requests.get("http://mlflow-server:5000/health")
        return response.status_code == 200
    except Exception as e:
        print(f"MLflow health check failed: {e}")
        return False
```

### **Database Monitoring**

```sql
-- Monitor database performance
SELECT 
    schemaname,
    tablename,
    attname,
    n_distinct,
    correlation
FROM pg_stats 
WHERE schemaname = 'public' 
ORDER BY n_distinct DESC;

-- Monitor table sizes
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
```

## 🚨 **Backup and Recovery**

### **Database Backup**

```bash
# Automated backup script
#!/bin/bash
BACKUP_DIR="/backups/mlflow"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="mlflow"

# Create backup
pg_dump -h localhost -U mlflow -d $DB_NAME > $BACKUP_DIR/mlflow_backup_$DATE.sql

# Compress backup
gzip $BACKUP_DIR/mlflow_backup_$DATE.sql

# Keep only last 30 days
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete
```

### **Artifact Backup**

```bash
# S3 backup script
aws s3 sync s3://your-bucket/mlflow-artifacts s3://backup-bucket/mlflow-artifacts --delete
```

## ✅ **Benefits of Centralized MLflow**

### **For 200 Users:**
- **Shared Access**: All users see same experiments
- **Scalability**: Handles concurrent access
- **Reliability**: No data loss if node fails
- **Performance**: Optimized database queries
- **Security**: Centralized authentication
- **Monitoring**: Unified metrics and alerts

### **For Operations:**
- **Centralized Management**: Single point of control
- **Backup Strategy**: Automated database backups
- **Monitoring**: Health checks and alerts
- **Scaling**: Easy horizontal scaling
- **Security**: Network and access controls

## 🎯 **Migration Steps**

1. **Set up centralized PostgreSQL**
2. **Deploy MLflow server with database backend**
3. **Configure load balancer**
4. **Update application configuration**
5. **Test with subset of users**
6. **Migrate existing data**
7. **Monitor performance**
8. **Scale as needed**

---

**This centralized MLflow setup provides a production-ready, scalable solution for 200 users with comprehensive monitoring, security, and backup capabilities.** 🚀
