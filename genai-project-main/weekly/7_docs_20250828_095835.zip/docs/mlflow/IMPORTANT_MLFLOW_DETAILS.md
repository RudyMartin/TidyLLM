# IMPORTANT MLflow Details - New Guy Guide

## 🎯 **What You Need to Know**

This document explains how MLflow is integrated into our system and what you need to understand to work with it effectively.

## 🏗️ **Architecture Overview**

```
┌─────────────────────────────────────────────────────────────┐
│                    Unified LLM Gateway                      │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Local LLM     │  │  Remote LLM     │  │   MLflow     │ │
│  │  (ZLLM/Ollama)  │  │  (Cloud APIs)   │  │ Integration  │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Enhanced      │  │   Metrics       │  │   Cost       │ │
│  │   Agents        │  │   Tracking      │  │ Management   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## 🔧 **Key Components**

### **1. Unified LLM Gateway (`src/backend/llm/unified_llm_gateway.py`)**
- **Purpose**: Single interface for all LLM interactions
- **Features**: 
  - Local and remote LLM support
  - Automatic fallback mechanisms
  - MLflow integration for tracking
  - Cost and performance monitoring

### **2. Environment-Aware Configuration (`src/backend/core/mlflow_config.py`)**
- **Purpose**: Handles different environments (local, staging, production, AWS)
- **Features**:
  - Auto-detects environment
  - Environment-specific settings
  - Override with environment variables
  - Validation and setup

### **3. Database Schema (`database/mlflow_integration_schema.sql`)**
- **Purpose**: PostgreSQL tables for MLflow data
- **Tables**:
  - MLflow core tables (experiments, runs, metrics, params)
  - LLM Gateway integration tables
  - Document processing tables
  - Performance analytics tables

## 🌍 **Environment Configuration**

### **Local Development**
```python
# Uses local files for MLflow
tracking_uri = "file://./mlflow_tracking"
artifact_root = "file://./mlflow_artifacts"
gateway = "local"  # ZLLM only
```

### **Staging**
```python
# Uses PostgreSQL + S3
tracking_uri = "postgresql://mlflow:password@staging-db:5432/mlflow"
artifact_root = "s3://mlflow-artifacts-staging"
gateway = "auto"  # Local + Remote
```

### **Production**
```python
# Uses PostgreSQL + S3 with security
tracking_uri = "postgresql://mlflow:password@prod-db:5432/mlflow"
artifact_root = "s3://mlflow-artifacts-production"
gateway = "auto"  # Local + Remote
```

### **AWS**
```python
# Uses environment variables
tracking_uri = "postgresql://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}"
artifact_root = "s3://${S3_BUCKET}/mlflow-artifacts"
gateway = "auto"
```

## 🚀 **How to Use**

### **Basic Usage**
```python
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway

# Automatically uses environment configuration
gateway = UnifiedLLMGateway()

# Make LLM call with tracking
response = gateway.call_llm(
    agent_name="document_processor",
    task_type="classification",
    prompt="Classify this document...",
    model_preference="gpt-4"
)
```

### **Environment-Specific Usage**
```python
# Specify environment
gateway = UnifiedLLMGateway(env_name="production")

# Or use explicit configuration
gateway = UnifiedLLMGateway(
    experiment_name="my-experiment",
    tracking_uri="postgresql://user:pass@host:5432/mlflow",
    enable_tracking=True
)
```

### **Enhanced Agents**
```python
from src.backend.llm.llm_enhanced_agents import LLMEnhancedDocumentClassifier

# Enhanced agents automatically use the unified gateway
classifier = LLMEnhancedDocumentClassifier(gateway)
classification = classifier.classify_with_llm(document)
```

## 📊 **What Gets Tracked**

### **MLflow Experiments**
- **Experiment Name**: Environment-specific (e.g., `unified-llm-gateway-production`)
- **Runs**: Each LLM call creates a run
- **Parameters**: Agent name, task type, model, gateway type
- **Metrics**: Response time, tokens, cost, success rate
- **Artifacts**: Prompts, responses, metadata

### **Database Tables**
```sql
-- Core MLflow tables
experiments, runs, params, metrics, tags

-- LLM Gateway integration
llm_call_history, llm_batch_processing, llm_gateway_config

-- Document processing
document_processing_sessions, document_classifications, document_metadata

-- Performance analytics
gateway_performance, experiment_cost_tracking
```

## 🔍 **Monitoring and Analytics**

### **MLflow UI**
```bash
# Access MLflow UI
open http://localhost:5000

# View experiments, runs, metrics, artifacts
```

### **Database Queries**
```sql
-- Performance summary
SELECT * FROM llm_gateway_performance_summary;

-- Cost tracking
SELECT * FROM experiment_cost_summary;

-- Document processing
SELECT * FROM document_processing_summary;
```

### **Health Checks**
```bash
# Check system health
python scripts/health_check.py

# Test MLflow connection
python -c "import mlflow; print(mlflow.get_tracking_uri())"
```

## 🛠️ **Setup and Deployment**

### **1. Database Setup**
```bash
# Run the complete setup
psql -d your_database -f database/prod_scripts/00_complete_setup.sql

# Or run individual scripts
psql -d your_database -f database/prod_scripts/01_extensions.sql
psql -d your_database -f database/prod_scripts/02_review_system.sql
psql -d your_database -f database/prod_scripts/03_embeddings_system.sql
psql -d your_database -f database/prod_scripts/04_event_tracking.sql
psql -d your_database -f database/prod_scripts/05_mlflow_integration.sql
```

### **2. Environment Configuration**
```bash
# Set environment variables
export VECTORQA_ENV=production
export MLFLOW_TRACKING_URI="postgresql://user:pass@host:5432/mlflow"
export MLFLOW_ARTIFACT_ROOT="s3://bucket/mlflow-artifacts"

# Or use the setup script
python scripts/setup_mlflow_integration.py
```

### **3. MLflow Server (Optional)**
```bash
# Start MLflow server
./scripts/start_mlflow_server.sh

# Or use Docker
docker-compose up -d
```

## 🔒 **Security Considerations**

### **Environment Variables**
- **Never commit secrets** to git
- **Use environment variables** for sensitive data
- **Validate configuration** before deployment

### **Database Security**
- **Use strong passwords** for database
- **Restrict network access** to database
- **Enable SSL/TLS** for connections

### **S3 Security**
- **Use IAM roles** for AWS access
- **Enable encryption** for artifacts
- **Restrict bucket access**

## 🚨 **Common Issues and Solutions**

### **Issue: MLflow not tracking**
```python
# Check if tracking is enabled
print(mlflow.get_tracking_uri())
print(mlflow.get_experiment())

# Verify environment setup
from src.backend.core.mlflow_config import validate_mlflow_config
validate_mlflow_config()
```

### **Issue: Database connection failed**
```bash
# Check database connectivity
python scripts/check_database_connectivity.py

# Verify environment variables
echo $MLFLOW_TRACKING_URI
echo $MLFLOW_DB_PASSWORD
```

### **Issue: Gateway not working**
```python
# Check gateway configuration
gateway_config = mlflow_config.get_gateway_config()
print(f"Local URL: {gateway_config['local_url']}")
print(f"Remote URL: {gateway_config['remote_url']}")

# Test gateway connection
response = gateway.call_llm("test", "test", "Hello")
```

## 📈 **Performance Optimization**

### **Batch Processing**
```python
# Use batch processing for multiple calls
gateway.start_batch("batch_001", budget_limit=10.0)

for document in documents:
    response = gateway.call_llm("processor", "classification", document)
    
gateway.end_batch()
```

### **Caching**
```python
# Enable caching for repeated calls
gateway = UnifiedLLMGateway(
    enable_tracking=True,
    cache_enabled=True
)
```

### **Async Processing**
```python
# Use async for better performance
import asyncio

async def process_documents(documents):
    tasks = []
    for doc in documents:
        task = gateway.call_llm_async("processor", "classification", doc)
        tasks.append(task)
    
    responses = await asyncio.gather(*tasks)
    return responses
```

## 🎯 **Best Practices**

### **1. Environment Management**
- **Always specify environment** when creating gateway
- **Use environment variables** for configuration
- **Validate configuration** before use

### **2. Error Handling**
```python
try:
    response = gateway.call_llm(agent, task, prompt)
except Exception as e:
    logger.error(f"LLM call failed: {e}")
    # Handle fallback or retry
```

### **3. Monitoring**
- **Monitor costs** regularly
- **Track performance** metrics
- **Set up alerts** for failures

### **4. Documentation**
- **Document experiments** with meaningful names
- **Add tags** for organization
- **Log important parameters**

## 📚 **Additional Resources**

### **Documentation Files**
- `docs/mlflow/MLFLOW_CENTRALIZED_SETUP.md` - Detailed setup guide
- `docs/mlflow/UNIFIED_LLM_GATEWAY_INTEGRATION.md` - Integration details
- `docs/MLFLOW_CENTRALIZED_SETUP.md` - Production deployment

### **Code Examples**
- `src/backend/llm/unified_llm_gateway.py` - Main gateway implementation
- `src/backend/core/mlflow_config.py` - Environment configuration
- `simple_demo.py` - Example usage in demo app

### **Scripts**
- `scripts/setup_mlflow_integration.py` - Automated setup
- `scripts/health_check.py` - Health monitoring
- `scripts/start_mlflow_server.sh` - Server startup

## 🎉 **Quick Start Checklist**

1. **✅ Database Setup**: Run `05_mlflow_integration.sql`
2. **✅ Environment Variables**: Set `VECTORQA_ENV` and database credentials
3. **✅ Configuration**: Validate with `validate_mlflow_config()`
4. **✅ Test Gateway**: Create `UnifiedLLMGateway()` and make test call
5. **✅ Monitor**: Check MLflow UI and database queries
6. **✅ Deploy**: Use in your application with proper error handling

---

**Remember**: The key is understanding that MLflow automatically tracks everything when you use the Unified LLM Gateway. Just focus on your application logic, and the tracking happens behind the scenes! 🚀
