# MLflow Integration Documentation

This folder contains comprehensive documentation for the MLflow integration with the Unified LLM Gateway system.

## 📚 **Documentation Files**

### **🎯 [IMPORTANT_MLFLOW_DETAILS.md](IMPORTANT_MLFLOW_DETAILS.md)**
**Start here if you're new!** This is the comprehensive guide for understanding how MLflow works in our system, including:
- Architecture overview
- Environment configuration
- Usage examples
- Troubleshooting
- Best practices

### **🏗️ [UNIFIED_LLM_GATEWAY_INTEGRATION.md](UNIFIED_LLM_GATEWAY_INTEGRATION.md)**
Detailed technical documentation for the Unified LLM Gateway integration, including:
- Complete architecture diagrams
- API documentation
- Configuration options
- Performance optimization
- Scaling strategies

### **🚀 [MLFLOW_CENTRALIZED_SETUP.md](MLFLOW_CENTRALIZED_SETUP.md)**
Production deployment guide for centralized MLflow setup, including:
- Database setup instructions
- Docker/Kubernetes deployment
- Security configuration
- Monitoring and backup
- Scaling for 200+ users

## 🔧 **Key Components**

### **Code Files**
- `src/backend/llm/unified_llm_gateway.py` - Main gateway implementation
- `src/backend/core/mlflow_config.py` - Environment-aware configuration
- `database/mlflow_integration_schema.sql` - Database schema

### **Scripts**
- `scripts/setup_mlflow_integration.py` - Automated setup
- `scripts/health_check.py` - Health monitoring
- `scripts/start_mlflow_server.sh` - Server startup

### **Database**
- `database/prod_scripts/05_mlflow_integration.sql` - MLflow schema
- `database/prod_scripts/00_complete_setup.sql` - Complete setup

## 🎯 **Quick Start**

1. **Read** `IMPORTANT_MLFLOW_DETAILS.md` for understanding
2. **Setup** database with `05_mlflow_integration.sql`
3. **Configure** environment variables
4. **Test** with `UnifiedLLMGateway()`
5. **Monitor** with MLflow UI

## 🌍 **Environment Support**

- **Local**: File-based tracking
- **Staging**: PostgreSQL + S3
- **Production**: PostgreSQL + S3 + Security
- **AWS**: Environment variable configuration

## 📊 **What Gets Tracked**

- **LLM Calls**: Every interaction with tracking
- **Performance**: Response time, tokens, cost
- **Documents**: Processing sessions and results
- **Analytics**: Gateway performance and cost tracking

---

**For questions or issues, refer to the troubleshooting section in `IMPORTANT_MLFLOW_DETAILS.md`** 🚀
