# IMPORTANT LLM Gateway Details - New Guy Guide

## 🎯 **What Makes This LLM Gateway Unique**

### **🏗️ Unified Architecture**
Unlike traditional single-purpose LLM systems, this gateway provides **unified access** to multiple LLM providers:

```
┌─────────────────────────────────────────────────────────────┐
│                    Unified LLM Gateway                      │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Local LLMs    │  │   Remote LLMs   │  │   MLflow     │ │
│  │  (ZLLM/Ollama)  │  │  (Cloud APIs)   │  │ Integration  │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   Cost Mgmt     │  │   Performance   │  │   Fallback   │ │
│  │   & Budgeting   │  │   Monitoring    │  │   Strategy   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### **🧠 Intelligent Routing**
- **Automatic model selection**: Chooses best model for task
- **Cost optimization**: Routes to cheapest viable option
- **Performance balancing**: Load balancing across providers
- **Fallback mechanisms**: Automatic failover if primary fails

### **📊 Comprehensive Tracking**
- **Every call tracked**: MLflow integration for all interactions
- **Cost monitoring**: Real-time cost tracking and budgeting
- **Performance metrics**: Response time, token usage, success rates
- **Quality assessment**: LLM response quality scoring

## 🔧 **Key Components**

### **1. Unified LLM Gateway**
**File**: `src/backend/llm/unified_llm_gateway.py`
- **Purpose**: Single interface for all LLM interactions
- **Features**: 
  - Local and remote LLM support
  - Automatic fallback mechanisms
  - MLflow integration for tracking
  - Cost and performance monitoring

### **2. Environment-Aware Configuration**
**File**: `src/backend/core/mlflow_config.py`
- **Purpose**: Handles different environments (local, staging, production, AWS)
- **Features**:
  - Auto-detects environment
  - Environment-specific settings
  - Override with environment variables
  - Validation and setup

### **3. LLM-Enhanced Agents**
**File**: `src/backend/llm/llm_enhanced_agents.py`
- **Purpose**: Specialized agents for document processing
- **Agents**:
  - `LLMEnhancedDocumentClassifier`
  - `LLMEnhancedStandardsLibrarian`
  - `LLMEnhancedDigestGenerator`

### **4. QA Orchestrator**
**File**: `src/backend/mcp/orchestrators/llm_enhanced_qa_orchestrator.py`
- **Purpose**: End-to-end document processing with LLM enhancement
- **Features**: Comprehensive document analysis and report generation

## 🚨 **Critical Issues & Gotchas**

### **1. Rate Limiting Nightmare**
**Issue**: Different LLM providers have different rate limits
```python
# ❌ Bad: No rate limiting
for task in tasks:
    response = gateway.call_llm(task)  # Can hit rate limits

# ✅ Good: Rate limiting and queuing
gateway = UnifiedLLMGateway(
    rate_limit=10,  # 10 calls per minute
    queue_enabled=True
)
```

### **2. Cost Explosion**
**Issue**: LLM calls can be expensive without monitoring
```python
# ❌ Bad: No cost monitoring
response = gateway.call_llm(prompt)  # No idea of cost

# ✅ Good: Cost tracking and budgeting
gateway = UnifiedLLMGateway(
    budget_limit=10.0,  # $10 budget
    cost_tracking=True
)
response = gateway.call_llm(prompt)
print(f"Cost: ${response.cost}")
```

### **3. Model Availability**
**Issue**: Models can be unavailable or deprecated
```python
# ❌ Bad: Hard-coded model names
response = gateway.call_llm(prompt, model="gpt-4")

# ✅ Good: Model fallback
response = gateway.call_llm(
    prompt, 
    model_preference="gpt-4",
    fallback_models=["gpt-3.5-turbo", "claude-3-sonnet"]
)
```

### **4. Environment Configuration**
**Issue**: Wrong environment can cause failures
```python
# ❌ Bad: No environment specification
gateway = UnifiedLLMGateway()

# ✅ Good: Explicit environment
gateway = UnifiedLLMGateway(env_name="production")
```

### **5. MLflow Integration Issues**
**Issue**: MLflow not tracking can cause data loss
```python
# ❌ Bad: No tracking verification
gateway = UnifiedLLMGateway()

# ✅ Good: Verify tracking
gateway = UnifiedLLMGateway(enable_tracking=True)
if not gateway.is_tracking_enabled():
    logger.error("MLflow tracking not working!")
```

## 🎯 **What's Unique vs. Standard LLM Usage**

### **Standard LLM Usage**
```python
# Typical approach
import openai
response = openai.ChatCompletion.create(
    model="gpt-4",
    messages=[{"role": "user", "content": prompt}]
)
# Result: Single provider, no tracking, no cost monitoring
```

### **Our Approach**
```python
# Our approach
gateway = UnifiedLLMGateway(env_name="production")
response = gateway.call_llm(
    agent_name="document_processor",
    task_type="classification",
    prompt="Classify this document...",
    model_preference="gpt-4"
)

# Result includes:
- Automatic model selection
- Cost tracking and budgeting
- MLflow experiment tracking
- Performance metrics
- Quality assessment
- Fallback handling
```

## 🚀 **How to Use (The Right Way)**

### **1. Basic Usage**
```python
from src.backend.llm.unified_llm_gateway import UnifiedLLMGateway

# Initialize with environment
gateway = UnifiedLLMGateway(env_name="production")

# Make LLM call with tracking
response = gateway.call_llm(
    agent_name="document_processor",
    task_type="classification",
    prompt="Classify this document...",
    model_preference="gpt-4"
)

# Access results
print(f"Response: {response.content}")
print(f"Cost: ${response.cost}")
print(f"Tokens: {response.token_usage}")
print(f"Model used: {response.model_used}")
```

### **2. Advanced Usage with Budgeting**
```python
# Set budget limits
gateway = UnifiedLLMGateway(
    env_name="production",
    budget_limit=50.0,  # $50 budget
    cost_tracking=True
)

# Process with budget monitoring
try:
    response = gateway.call_llm(prompt)
    print(f"Remaining budget: ${gateway.get_remaining_budget()}")
except BudgetExceededError:
    print("Budget exceeded!")
```

### **3. Batch Processing**
```python
# Process multiple tasks efficiently
gateway.start_batch("batch_001", budget_limit=10.0)

tasks = ["task1", "task2", "task3"]
responses = []

for task in tasks:
    try:
        response = gateway.call_llm(task)
        responses.append(response)
    except Exception as e:
        logger.error(f"Task failed: {e}")
        continue

gateway.end_batch()
print(f"Batch cost: ${gateway.get_batch_cost()}")
```

### **4. Enhanced Agents**
```python
from src.backend.llm.llm_enhanced_agents import LLMEnhancedDocumentClassifier

# Use enhanced agents
classifier = LLMEnhancedDocumentClassifier(gateway)
classification = classifier.classify_with_llm(document)
```

## 🔍 **Monitoring and Analytics**

### **1. MLflow UI**
```bash
# Access MLflow UI
open http://localhost:5000

# View experiments, runs, metrics, artifacts
```

### **2. Database Queries**
```sql
-- Performance summary
SELECT * FROM llm_gateway_performance_summary;

-- Cost tracking
SELECT * FROM experiment_cost_summary;

-- Model usage
SELECT model_used, COUNT(*) as usage_count 
FROM llm_call_history 
GROUP BY model_used;
```

### **3. Health Checks**
```python
# Check gateway health
status = gateway.get_health_status()
print(f"Status: {status['status']}")
print(f"Available models: {status['available_models']}")
print(f"Rate limits: {status['rate_limits']}")
```

## 🛠️ **Setup and Configuration**

### **1. Environment Setup**
```bash
# Set environment variables
export VECTORQA_ENV=production
export MLFLOW_TRACKING_URI="postgresql://user:pass@host:5432/mlflow"
export MLFLOW_ARTIFACT_ROOT="s3://bucket/mlflow-artifacts"

# LLM API keys
export OPENAI_API_KEY="your-openai-key"
export ANTHROPIC_API_KEY="your-anthropic-key"
```

### **2. Configuration File**
```yaml
# config.yaml
llm_gateway:
  default_gateway: "auto"
  rate_limit: 10
  budget_limit: 100.0
  cost_tracking: true
  
  local:
    url: "http://localhost:11434"
    models: ["llama2", "mistral"]
    
  remote:
    openai:
      api_key: "${OPENAI_API_KEY}"
      models: ["gpt-4", "gpt-3.5-turbo"]
    anthropic:
      api_key: "${ANTHROPIC_API_KEY}"
      models: ["claude-3-opus", "claude-3-sonnet"]
```

### **3. Database Setup**
```bash
# Run MLflow integration schema
psql -d your_database -f database/prod_scripts/05_mlflow_integration.sql
```

## 🚨 **Common Problems and Solutions**

### **Problem: "Rate limit exceeded"**
```python
# Reduce rate limit
gateway = UnifiedLLMGateway(rate_limit=5)

# Use caching
gateway.enable_caching(ttl=3600)

# Queue requests
gateway.enable_queuing(max_queue_size=100)
```

### **Problem: "Budget exceeded"**
```python
# Check current usage
print(f"Current cost: ${gateway.get_current_cost()}")
print(f"Budget limit: ${gateway.get_budget_limit()}")

# Increase budget or optimize
gateway = UnifiedLLMGateway(budget_limit=200.0)
```

### **Problem: "Model not available"**
```python
# Check available models
available = gateway.get_available_models()
print(f"Available: {available}")

# Use fallback models
response = gateway.call_llm(
    prompt,
    model_preference="gpt-4",
    fallback_models=["gpt-3.5-turbo", "claude-3-sonnet"]
)
```

### **Problem: "MLflow not tracking"**
```python
# Verify MLflow setup
from src.backend.core.mlflow_config import validate_mlflow_config
validate_mlflow_config()

# Check tracking URI
print(f"Tracking URI: {gateway.get_tracking_uri()}")
```

## 📊 **Performance Optimization**

### **1. Caching Strategy**
```python
# Enable intelligent caching
gateway.enable_caching(
    ttl=3600,  # 1 hour
    max_size=1000,  # Max 1000 cached responses
    compression=True  # Compress cached data
)
```

### **2. Batch Processing**
```python
# Process multiple requests efficiently
gateway.start_batch("batch_001", budget_limit=10.0)

for prompt in prompts:
    response = gateway.call_llm(prompt)
    
gateway.end_batch()
print(f"Batch efficiency: {gateway.get_batch_efficiency()}")
```

### **3. Model Selection**
```python
# Use cost-effective models for simple tasks
simple_tasks = ["classification", "summarization"]
complex_tasks = ["analysis", "generation"]

for task in tasks:
    if task.type in simple_tasks:
        model = "gpt-3.5-turbo"  # Cheaper
    else:
        model = "gpt-4"  # More capable
    
    response = gateway.call_llm(task.prompt, model_preference=model)
```

## 🎯 **Best Practices**

### **1. Always Use Error Handling**
```python
try:
    response = gateway.call_llm(prompt)
except RateLimitError as e:
    logger.warning(f"Rate limit hit: {e}")
    time.sleep(60)  # Wait and retry
except BudgetExceededError as e:
    logger.error(f"Budget exceeded: {e}")
    # Handle gracefully
except Exception as e:
    logger.error(f"Unexpected error: {e}")
    # Log and continue
```

### **2. Monitor Costs**
```python
# Regular cost monitoring
daily_cost = gateway.get_daily_cost()
if daily_cost > 50.0:
    logger.warning(f"High daily cost: ${daily_cost}")

# Set up alerts
gateway.set_cost_alert(threshold=100.0)
```

### **3. Use Appropriate Models**
```python
# Match model to task complexity
task_complexity = assess_task_complexity(prompt)

if task_complexity == "simple":
    model = "gpt-3.5-turbo"
elif task_complexity == "complex":
    model = "gpt-4"
else:
    model = "claude-3-opus"

response = gateway.call_llm(prompt, model_preference=model)
```

### **4. Regular Maintenance**
```python
# Clear old cache entries
gateway.clear_expired_cache()

# Update model availability
gateway.refresh_model_availability()

# Check for updates
gateway.check_for_updates()
```

## 📚 **Additional Resources**

### **Documentation Files**
- `docs/mlflow/IMPORTANT_MLFLOW_DETAILS.md` - MLflow integration details
- `docs/mlflow/UNIFIED_LLM_GATEWAY_INTEGRATION.md` - Technical integration
- `docs/mlflow/MLFLOW_CENTRALIZED_SETUP.md` - Production setup

### **Code Examples**
- `src/backend/llm/unified_llm_gateway.py` - Main gateway implementation
- `src/backend/core/mlflow_config.py` - Environment configuration
- `src/backend/llm/llm_enhanced_agents.py` - Enhanced agents

### **Demo Scripts**
- `llm_gateway_demo.py` - Basic gateway usage
- `mlflow_llm_demo.py` - MLflow integration demo

### **Testing**
```bash
# Test gateway functionality
python llm_gateway_demo.py

# Test MLflow integration
python mlflow_llm_demo.py

# Test enhanced agents
python -c "from src.backend.llm.llm_enhanced_agents import *; test_agents()"
```

## 🎉 **Quick Start Checklist**

1. **✅ Environment Setup**: Set `VECTORQA_ENV` and API keys
2. **✅ Database Setup**: Run MLflow integration schema
3. **✅ Configuration**: Validate MLflow configuration
4. **✅ Test Gateway**: Create `UnifiedLLMGateway()` and make test call
5. **✅ Monitor**: Check MLflow UI and cost tracking
6. **✅ Deploy**: Use in application with proper error handling

---

**Remember**: The key is understanding that this gateway provides unified access to multiple LLM providers with comprehensive tracking and cost management. Always use error handling and monitor costs! 🚀
