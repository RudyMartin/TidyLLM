#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MLflow LLM Gateway Demo

This script demonstrates the MLflow-enhanced LLM Gateway with
experiment tracking, performance analysis, and cost optimization.
"""

import logging
import time
import json
from datetime import datetime
from pathlib import Path
import argparse
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('mlflow_llm_demo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


def demo_mlflow_llm_gateway():
    """Demonstrate MLflow-enhanced LLM Gateway"""
    logger.info("=== DEMO: MLflow-Enhanced LLM Gateway ===")
    
    try:
        from src.backend.llm.mlflow_llm_gateway import MLflowLLMGateway, MLflowExperimentAnalyzer
        
        # Initialize MLflow-enhanced gateway
        gateway = MLflowLLMGateway(
            experiment_name="llm-gateway-demo",
            enable_tracking=True
        )
        
        logger.info("MLflow LLM Gateway initialized")
        
        # Start a batch for tracking
        batch_id = f"mlflow_demo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id, budget_limit=50.0)
        logger.info(f"Started batch: {batch_id}")
        
        # Test different types of LLM calls
        test_cases = [
            {
                "agent_name": "document_classifier",
                "task_type": "classification",
                "prompt": "Classify this document: Financial risk assessment report with model validation results",
                "model_preference": "gpt-4"
            },
            {
                "agent_name": "standards_librarian", 
                "task_type": "standards_extraction",
                "prompt": "Extract best practices and compliance requirements from this regulatory document",
                "model_preference": "claude-3-sonnet"
            },
            {
                "agent_name": "digest_generator",
                "task_type": "executive_summary",
                "prompt": "Generate an executive summary for the quarterly model validation report",
                "model_preference": "gpt-4"
            },
            {
                "agent_name": "document_classifier",
                "task_type": "metadata_extraction", 
                "prompt": "Extract key metadata including title, authors, date, and organization from this research paper",
                "model_preference": "gpt-3.5-turbo"
            }
        ]
        
        # Make LLM calls with tracking
        for i, test_case in enumerate(test_cases, 1):
            logger.info(f"Making LLM call {i}/{len(test_cases)}: {test_case['agent_name']} -> {test_case['task_type']}")
            
            try:
                response = gateway.call_llm(**test_case)
                logger.info(f"Response: {response.content[:100]}...")
                logger.info(f"Cost: ${response.cost:.4f}, Tokens: {response.input_tokens + response.output_tokens}")
                
            except Exception as e:
                logger.error(f"LLM call failed: {e}")
        
        # Analyze experiment performance
        logger.info("=== EXPERIMENT PERFORMANCE ANALYSIS ===")
        
        performance = gateway.get_experiment_performance()
        logger.info(f"Total runs: {performance.get('total_runs', 0)}")
        logger.info(f"Success rate: {performance.get('success_rate', 0):.1%}")
        logger.info(f"Average cost: ${performance.get('avg_cost', 0):.4f}")
        logger.info(f"Total cost: ${performance.get('total_cost', 0):.4f}")
        
        # Get cost optimization recommendations
        logger.info("=== COST OPTIMIZATION RECOMMENDATIONS ===")
        
        recommendations = gateway.get_cost_optimization_recommendations()
        
        if "best_cost_performance" in recommendations:
            best_model = recommendations["best_cost_performance"].get("model", "N/A")
            best_cost = recommendations["best_cost_performance"].get("avg_cost", 0)
            logger.info(f"Best cost-effective model: {best_model} (${best_cost:.4f} avg)")
        
        if "model_recommendations" in recommendations:
            logger.info("Model recommendations by task:")
            for task, rec in recommendations["model_recommendations"].items():
                logger.info(f"  {task}: {rec['recommended_model']} (${rec['avg_cost']:.4f})")
        
        # Export experiment data
        logger.info("=== EXPORTING EXPERIMENT DATA ===")
        
        export_file = gateway.export_experiment_data("mlflow_export")
        logger.info(f"Exported data to: {export_file}")
        
        # End batch
        gateway.end_batch(batch_id)
        logger.info(f"Ended batch: {batch_id}")
        
        # Generate performance report
        logger.info("=== GENERATING PERFORMANCE REPORT ===")
        
        analyzer = MLflowExperimentAnalyzer("llm-gateway-demo")
        report_file = analyzer.generate_performance_report("mlflow_performance_report.md")
        logger.info(f"Performance report generated: {report_file}")
        
        return True
        
    except Exception as e:
        logger.error(f"MLflow LLM Gateway demo failed: {e}")
        return False


def demo_experiment_analysis():
    """Demonstrate experiment analysis capabilities"""
    logger.info("=== DEMO: Experiment Analysis ===")
    
    try:
        from src.backend.llm.mlflow_llm_gateway import MLflowExperimentAnalyzer
        
        # Initialize analyzer
        analyzer = MLflowExperimentAnalyzer("llm-gateway-demo")
        
        # Get experiment summary
        summary = analyzer.get_experiment_summary()
        
        if "error" in summary:
            logger.warning(f"Experiment analysis failed: {summary['error']}")
            return False
        
        logger.info("=== EXPERIMENT SUMMARY ===")
        logger.info(f"Experiment: {summary.get('experiment_name', 'N/A')}")
        logger.info(f"Total runs: {summary.get('total_runs', 0)}")
        
        if "cost_analysis" in summary:
            cost_analysis = summary["cost_analysis"]
            logger.info(f"Total cost: ${cost_analysis.get('total_cost', 0):.4f}")
            logger.info(f"Average cost per run: ${cost_analysis.get('avg_cost_per_run', 0):.4f}")
        
        if "performance_analysis" in summary:
            perf_analysis = summary["performance_analysis"]
            logger.info(f"Average response time: {perf_analysis.get('avg_response_time', 0):.2f}s")
        
        # Generate detailed report
        report_file = analyzer.generate_performance_report("detailed_performance_report.md")
        logger.info(f"Detailed report generated: {report_file}")
        
        return True
        
    except Exception as e:
        logger.error(f"Experiment analysis demo failed: {e}")
        return False


def demo_cost_optimization():
    """Demonstrate cost optimization features"""
    logger.info("=== DEMO: Cost Optimization ===")
    
    try:
        from src.backend.llm.mlflow_llm_gateway import MLflowLLMGateway
        
        # Initialize gateway
        gateway = MLflowLLMGateway("llm-gateway-demo")
        
        # Test different models for same task
        task = "classification"
        prompt = "Classify this document: Model validation report with risk assessment"
        
        models_to_test = ["gpt-4", "gpt-3.5-turbo", "claude-3-sonnet"]
        
        results = {}
        
        for model in models_to_test:
            logger.info(f"Testing model: {model}")
            
            try:
                response = gateway.call_llm(
                    agent_name="model_tester",
                    task_type=task,
                    prompt=prompt,
                    model_preference=model
                )
                
                results[model] = {
                    "cost": response.cost,
                    "response_time": response.response_time,
                    "total_tokens": response.input_tokens + response.output_tokens,
                    "success": response.success
                }
                
                logger.info(f"  Cost: ${response.cost:.4f}")
                logger.info(f"  Response time: {response.response_time:.2f}s")
                logger.info(f"  Tokens: {response.input_tokens + response.output_tokens}")
                
            except Exception as e:
                logger.error(f"  Failed: {e}")
                results[model] = {"error": str(e)}
        
        # Analyze results
        logger.info("=== COST COMPARISON ===")
        
        successful_results = {k: v for k, v in results.items() if "error" not in v}
        
        if successful_results:
            best_cost_model = min(successful_results.keys(), 
                                key=lambda x: successful_results[x]["cost"])
            best_cost = successful_results[best_cost_model]["cost"]
            
            logger.info(f"Best cost model: {best_cost_model} (${best_cost:.4f})")
            
            for model, result in successful_results.items():
                cost_diff = result["cost"] - best_cost
                logger.info(f"{model}: ${result['cost']:.4f} ({cost_diff:+.4f} vs best)")
        
        return True
        
    except Exception as e:
        logger.error(f"Cost optimization demo failed: {e}")
        return False


def main():
    """Main demo function"""
    parser = argparse.ArgumentParser(description="MLflow LLM Gateway Demo")
    parser.add_argument("--demo", choices=["gateway", "analysis", "optimization", "all"], 
                       default="all", help="Which demo to run")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    logger.info("🚀 Starting MLflow LLM Gateway Demo")
    logger.info(f"Demo mode: {args.demo}")
    
    demos = {
        "gateway": demo_mlflow_llm_gateway,
        "analysis": demo_experiment_analysis,
        "optimization": demo_cost_optimization
    }
    
    if args.demo == "all":
        demo_functions = demos.values()
    else:
        demo_functions = [demos[args.demo]]
    
    results = {}
    
    for demo_func in demo_functions:
        demo_name = demo_func.__name__
        logger.info(f"\n{'='*60}")
        logger.info(f"Running: {demo_name}")
        logger.info(f"{'='*60}")
        
        start_time = time.time()
        try:
            success = demo_func()
            end_time = time.time()
            duration = end_time - start_time
            
            results[demo_name] = {
                'success': success,
                'duration': duration
            }
            
            if success:
                logger.info(f"✅ {demo_name} completed successfully in {duration:.2f}s")
            else:
                logger.error(f"❌ {demo_name} failed after {duration:.2f}s")
                
        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time
            logger.error(f"❌ {demo_name} crashed after {duration:.2f}s: {e}")
            results[demo_name] = {
                'success': False,
                'duration': duration,
                'error': str(e)
            }
    
    # Summary
    logger.info(f"\n{'='*60}")
    logger.info("DEMO SUMMARY")
    logger.info(f"{'='*60}")
    
    successful_demos = sum(1 for r in results.values() if r['success'])
    total_demos = len(results)
    total_time = sum(r['duration'] for r in results.values())
    
    logger.info(f"Total Demos: {total_demos}")
    logger.info(f"Successful: {successful_demos}")
    logger.info(f"Failed: {total_demos - successful_demos}")
    logger.info(f"Success Rate: {successful_demos/total_demos:.1%}")
    logger.info(f"Total Time: {total_time:.2f}s")
    
    for demo_name, result in results.items():
        status = "✅ PASS" if result['success'] else "❌ FAIL"
        logger.info(f"{status} {demo_name} ({result['duration']:.2f}s)")
        if not result['success'] and 'error' in result:
            logger.info(f"    Error: {result['error']}")
    
    logger.info(f"\n🎉 MLflow LLM Gateway Demo completed!")
    logger.info(f"Check 'mlflow_llm_demo.log' for detailed logs")
    logger.info(f"Check 'mlflow_export/' for exported data")
    logger.info(f"Check 'mlflow_performance_report.md' for performance report")
    logger.info(f"Check MLflow UI for experiment visualization")


if __name__ == "__main__":
    main()
