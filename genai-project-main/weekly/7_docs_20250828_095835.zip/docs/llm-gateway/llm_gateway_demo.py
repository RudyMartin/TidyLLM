#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM Gateway Demo - Comprehensive LLM Management System

This script demonstrates the complete LLM Gateway architecture including:
- Centralized LLM call management
- Comprehensive metrics tracking
- Cost management and budgeting
- Model routing and optimization
- Response caching
- Rate limiting
- LLM-enhanced document processing
- Utilization reporting
"""

import logging
import json
import time
from datetime import datetime
from pathlib import Path
import argparse
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('llm_gateway_demo.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)


def setup_demo_environment():
    """Setup demo environment with sample documents"""
    logger.info("Setting up demo environment...")
    
    # Create input directory with sample documents
    input_dir = Path("input")
    input_dir.mkdir(exist_ok=True)
    
    # Create sample documents
    sample_documents = {
        "sample_validation_report.txt": """
VALIDATION REPORT - Model Risk Assessment

Review ID: VAL-2024-001
Date: 2024-03-15
Organization: Quant Analytics Group

Executive Summary:
This report presents the validation results for the new credit risk model 
implemented in Q4 2023. The model demonstrates strong predictive performance 
with an AUC of 0.85 and maintains stability across different market conditions.

Key Findings:
- Model performance meets regulatory requirements
- Backtesting results show consistent performance
- Stress testing reveals adequate resilience
- Documentation is comprehensive and up-to-date

Recommendations:
1. Proceed with model implementation
2. Establish quarterly monitoring schedule
3. Conduct annual revalidation
4. Update model documentation

Risk Assessment: LOW
Overall Score: 85/100
""",
        
        "sample_standards_document.txt": """
BEST PRACTICES FOR MODEL VALIDATION

Document Type: Standards and Guidelines
Version: 2.1
Effective Date: 2024-01-01

1. MODEL DEVELOPMENT STANDARDS
   - All models must undergo peer review
   - Documentation must include methodology and assumptions
   - Data quality assessment is mandatory
   - Model performance metrics must be clearly defined

2. VALIDATION REQUIREMENTS
   - Independent validation by qualified personnel
   - Comprehensive testing including backtesting and stress testing
   - Regular monitoring and performance tracking
   - Annual revalidation for all production models

3. DOCUMENTATION STANDARDS
   - Clear and comprehensive model documentation
   - Regular updates to reflect model changes
   - Version control and change management
   - Audit trail for all modifications

4. GOVERNANCE FRAMEWORK
   - Model risk committee oversight
   - Clear escalation procedures
   - Regular reporting to senior management
   - Compliance with regulatory requirements
""",
        
        "sample_research_paper.txt": """
ADVANCED MACHINE LEARNING TECHNIQUES FOR FINANCIAL RISK MODELING

Authors: Dr. Sarah Johnson, Dr. Michael Chen
Institution: Financial Analytics Institute
Publication Date: 2024-02-20

Abstract:
This paper explores the application of advanced machine learning techniques 
in financial risk modeling, with particular focus on credit risk assessment 
and market risk prediction. We present a novel ensemble approach that 
combines traditional statistical methods with deep learning architectures.

Methodology:
Our approach utilizes a hybrid model architecture combining:
- Gradient Boosting Machines for feature selection
- Neural Networks for pattern recognition
- Ensemble methods for robust predictions
- Bayesian optimization for hyperparameter tuning

Results:
The proposed methodology achieves:
- 15% improvement in prediction accuracy
- 20% reduction in false positive rates
- Enhanced stability across market regimes
- Better interpretability through feature importance analysis

Conclusions:
Advanced ML techniques show significant promise for improving financial 
risk modeling, but require careful implementation and validation.
"""
    }
    
    # Write sample documents
    for filename, content in sample_documents.items():
        doc_path = input_dir / filename
        with open(doc_path, 'w') as f:
            f.write(content.strip())
    
    logger.info(f"Created {len(sample_documents)} sample documents in {input_dir}")
    return input_dir


def demo_basic_llm_gateway():
    """Demonstrate basic LLM Gateway functionality"""
    logger.info("=== DEMO: Basic LLM Gateway Functionality ===")
    
    try:
        from src.backend.llm.llm_gateway import LLMGateway
        
        # Initialize gateway
        gateway = LLMGateway()
        
        # Start a batch
        batch_id = f"demo_batch_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id, budget_limit=10.0)  # $10 budget limit
        
        # Make some LLM calls
        test_prompts = [
            ("document_classifier", "classification", "Classify this document: Financial risk assessment report"),
            ("standards_librarian", "standards_extraction", "Extract best practices from this document"),
            ("digest_generator", "executive_summary", "Generate executive summary for quarterly report"),
            ("document_classifier", "metadata_extraction", "Extract metadata from research paper")
        ]
        
        for agent_name, task_type, prompt in test_prompts:
            try:
                logger.info(f"Making LLM call: {agent_name} -> {task_type}")
                response = gateway.call_llm(agent_name, task_type, prompt)
                logger.info(f"Response: {response.content[:100]}...")
                
            except Exception as e:
                logger.error(f"LLM call failed: {e}")
        
        # Generate batch report
        report = gateway.generate_batch_report(batch_id)
        
        logger.info("=== BATCH REPORT ===")
        logger.info(f"Batch ID: {report.get('batch_id')}")
        logger.info(f"Total Calls: {report.get('processing_summary', {}).get('total_calls', 0)}")
        logger.info(f"Total Cost: ${report.get('processing_summary', {}).get('total_cost', 0):.4f}")
        logger.info(f"Success Rate: {report.get('processing_summary', {}).get('success_rate', 0):.1%}")
        
        # End batch
        gateway.end_batch(batch_id)
        
        return True
        
    except Exception as e:
        logger.error(f"Basic LLM Gateway demo failed: {e}")
        return False


def demo_llm_enhanced_agents():
    """Demonstrate LLM-enhanced agents"""
    logger.info("=== DEMO: LLM-Enhanced Agents ===")
    
    try:
        from src.backend.llm.llm_gateway import LLMGateway
        from src.backend.llm.llm_enhanced_agents import (
            LLMEnhancedDocumentClassifier,
            LLMEnhancedStandardsLibrarian,
            LLMEnhancedDigestGenerator
        )
        
        # Initialize gateway and agents
        gateway = LLMGateway()
        classifier = LLMEnhancedDocumentClassifier(gateway)
        standards_librarian = LLMEnhancedStandardsLibrarian(gateway)
        digest_generator = LLMEnhancedDigestGenerator(gateway)
        
        # Start batch
        batch_id = f"agents_demo_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id, budget_limit=20.0)
        
        # Sample document
        sample_doc = {
            'filename': 'sample_document.txt',
            'content': """
            Model Validation Report - Q1 2024
            
            This report presents the validation results for our credit risk model.
            The model shows strong performance with AUC of 0.87 and maintains
            stability across different market conditions. Key findings include
            improved prediction accuracy and reduced false positive rates.
            
            Recommendations:
            1. Proceed with model implementation
            2. Establish monitoring framework
            3. Conduct quarterly reviews
            """
        }
        
        # Test document classification
        logger.info("Testing document classification...")
        classification = classifier.classify_with_llm(sample_doc)
        logger.info(f"Classification: {classification.get('classification', 'Unknown')}")
        logger.info(f"Confidence: {classification.get('confidence', 0)}%")
        
        # Test metadata extraction
        logger.info("Testing metadata extraction...")
        metadata = classifier.extract_metadata_with_llm(sample_doc)
        logger.info(f"Title: {metadata.get('title', 'Unknown')}")
        logger.info(f"Document Type: {metadata.get('document_type', 'Unknown')}")
        
        # Test digest generation
        logger.info("Testing digest generation...")
        digest = digest_generator.generate_executive_summary(sample_doc)
        logger.info(f"Executive Summary: {digest[:200]}...")
        
        # Generate batch report
        report = gateway.generate_batch_report(batch_id)
        
        logger.info("=== AGENTS DEMO REPORT ===")
        logger.info(f"Total Calls: {report.get('processing_summary', {}).get('total_calls', 0)}")
        logger.info(f"Total Cost: ${report.get('processing_summary', {}).get('total_cost', 0):.4f}")
        logger.info(f"Agent Breakdown: {report.get('agent_breakdown', {})}")
        
        gateway.end_batch(batch_id)
        
        return True
        
    except Exception as e:
        logger.error(f"LLM-enhanced agents demo failed: {e}")
        return False


def demo_llm_enhanced_qa_orchestrator():
    """Demonstrate LLM-enhanced QA orchestrator"""
    logger.info("=== DEMO: LLM-Enhanced QA Orchestrator ===")
    
    try:
        from src.backend.mcp.orchestrators.llm_enhanced_qa_orchestrator import LLMEnhancedQAOrchestrator
        
        # Setup demo environment
        input_dir = setup_demo_environment()
        
        # Initialize orchestrator
        config_path = "dev_configs/qa_criteria_simplified.yaml"
        orchestrator = LLMEnhancedQAOrchestrator(config_path)
        
        # Process documents with LLM enhancement
        logger.info("Processing documents with LLM enhancement...")
        result = orchestrator.process_qa_documents_with_llm(
            input_dir=str(input_dir),
            budget_limit=50.0  # $50 budget limit
        )
        
        logger.info("=== ORCHESTRATOR DEMO RESULTS ===")
        logger.info(f"Batch ID: {result.get('batch_id')}")
        logger.info(f"Status: {result.get('status')}")
        logger.info(f"Documents Processed: {result.get('documents_processed', 0)}")
        
        if result.get('status') == 'completed':
            llm_report = result.get('llm_utilization_report', {})
            logger.info(f"LLM Calls: {llm_report.get('processing_summary', {}).get('total_calls', 0)}")
            logger.info(f"LLM Cost: ${llm_report.get('processing_summary', {}).get('total_cost', 0):.4f}")
            logger.info(f"Output Files: {len(result.get('output_files', {}))}")
        
        return True
        
    except Exception as e:
        logger.error(f"LLM-enhanced QA orchestrator demo failed: {e}")
        return False


def demo_gateway_features():
    """Demonstrate advanced gateway features"""
    logger.info("=== DEMO: Advanced Gateway Features ===")
    
    try:
        from src.backend.llm.llm_gateway import LLMGateway, BudgetExceededError, RateLimitExceededError
        
        # Initialize gateway
        gateway = LLMGateway()
        
        # Test 1: Budget enforcement
        logger.info("Testing budget enforcement...")
        batch_id = f"budget_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id, budget_limit=0.01)  # Very low budget
        
        try:
            response = gateway.call_llm("test_agent", "test_task", "This is a test prompt")
            logger.info("Budget test passed (unexpected)")
        except BudgetExceededError:
            logger.info("Budget enforcement working correctly")
        except Exception as e:
            logger.info(f"Budget test result: {e}")
        
        gateway.end_batch(batch_id)
        
        # Test 2: Caching
        logger.info("Testing response caching...")
        batch_id = f"cache_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id)
        
        # First call (should cache)
        response1 = gateway.call_llm("cache_test", "test_task", "Cache test prompt")
        logger.info(f"First call response: {response1.content[:50]}...")
        
        # Second call (should use cache)
        response2 = gateway.call_llm("cache_test", "test_task", "Cache test prompt")
        logger.info(f"Second call response: {response2.content[:50]}...")
        
        # Check if responses are identical (cached)
        if response1.content == response2.content:
            logger.info("Caching working correctly")
        else:
            logger.info("Caching may not be working")
        
        gateway.end_batch(batch_id)
        
        # Test 3: Model routing
        logger.info("Testing model routing...")
        batch_id = f"routing_test_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        gateway.start_batch(batch_id)
        
        # Test different task types
        tasks = [
            ("simple_classification", "Simple classification task"),
            ("complex_analysis", "Complex analysis task with detailed requirements"),
            ("summarization", "Summarization task")
        ]
        
        for task_type, prompt in tasks:
            response = gateway.call_llm("routing_test", task_type, prompt)
            logger.info(f"Task: {task_type} -> Model: {response.model_name}")
        
        gateway.end_batch(batch_id)
        
        return True
        
    except Exception as e:
        logger.error(f"Gateway features demo failed: {e}")
        return False


def demo_utilization_reporting():
    """Demonstrate comprehensive utilization reporting"""
    logger.info("=== DEMO: Utilization Reporting ===")
    
    try:
        from src.backend.llm.llm_gateway import LLMGateway
        
        # Initialize gateway
        gateway = LLMGateway()
        
        # Create multiple batches with different characteristics
        batches = [
            ("batch_1", 5.0, [("agent1", "task1", "Prompt 1"), ("agent2", "task2", "Prompt 2")]),
            ("batch_2", 10.0, [("agent1", "task1", "Prompt 3"), ("agent3", "task3", "Prompt 4")]),
            ("batch_3", 15.0, [("agent2", "task2", "Prompt 5"), ("agent1", "task1", "Prompt 6")])
        ]
        
        batch_reports = []
        
        for batch_id, budget, calls in batches:
            logger.info(f"Processing batch: {batch_id}")
            gateway.start_batch(batch_id, budget)
            
            for agent_name, task_type, prompt in calls:
                try:
                    response = gateway.call_llm(agent_name, task_type, prompt)
                    logger.info(f"Call successful: {agent_name} -> {task_type}")
                except Exception as e:
                    logger.error(f"Call failed: {e}")
            
            # Generate report
            report = gateway.generate_batch_report(batch_id)
            batch_reports.append(report)
            
            gateway.end_batch(batch_id)
        
        # Analyze reports
        logger.info("=== UTILIZATION ANALYSIS ===")
        
        total_calls = sum(r.get('processing_summary', {}).get('total_calls', 0) for r in batch_reports)
        total_cost = sum(r.get('processing_summary', {}).get('total_cost', 0) for r in batch_reports)
        total_tokens = sum(r.get('processing_summary', {}).get('total_tokens', 0) for r in batch_reports)
        
        logger.info(f"Total Calls Across All Batches: {total_calls}")
        logger.info(f"Total Cost: ${total_cost:.4f}")
        logger.info(f"Total Tokens: {total_tokens:,}")
        logger.info(f"Average Cost per Call: ${total_cost/total_calls:.4f}" if total_calls > 0 else "N/A")
        logger.info(f"Average Tokens per Call: {total_tokens/total_calls:.0f}" if total_calls > 0 else "N/A")
        
        # Agent breakdown
        all_agent_breakdowns = {}
        for report in batch_reports:
            agent_breakdown = report.get('agent_breakdown', {})
            for agent, stats in agent_breakdown.items():
                if agent not in all_agent_breakdowns:
                    all_agent_breakdowns[agent] = {'calls': 0, 'tokens': 0, 'cost': 0}
                all_agent_breakdowns[agent]['calls'] += stats.get('calls', 0)
                all_agent_breakdowns[agent]['tokens'] += stats.get('tokens', 0)
                all_agent_breakdowns[agent]['cost'] += stats.get('cost', 0)
        
        logger.info("Agent Breakdown:")
        for agent, stats in all_agent_breakdowns.items():
            logger.info(f"  {agent}: {stats['calls']} calls, {stats['tokens']} tokens, ${stats['cost']:.4f}")
        
        return True
        
    except Exception as e:
        logger.error(f"Utilization reporting demo failed: {e}")
        return False


def main():
    """Main demo function"""
    parser = argparse.ArgumentParser(description="LLM Gateway Demo")
    parser.add_argument("--demo", choices=["basic", "agents", "orchestrator", "features", "reporting", "all"], 
                       default="all", help="Which demo to run")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    logger.info("🚀 Starting LLM Gateway Demo")
    logger.info(f"Demo mode: {args.demo}")
    
    demos = {
        "basic": demo_basic_llm_gateway,
        "agents": demo_llm_enhanced_agents,
        "orchestrator": demo_llm_enhanced_qa_orchestrator,
        "features": demo_gateway_features,
        "reporting": demo_utilization_reporting
    }
    
    if args.demo == "all":
        demo_functions = demos.values()
    else:
        demo_functions = [demos[args.demo]]
    
    results = {}
    
    for demo_func in demo_functions:
        demo_name = demo_func.__name__
        logger.info(f"\n{'='*60}")
        logger.info(f"Running: {demo_name}")
        logger.info(f"{'='*60}")
        
        start_time = time.time()
        try:
            success = demo_func()
            end_time = time.time()
            duration = end_time - start_time
            
            results[demo_name] = {
                'success': success,
                'duration': duration
            }
            
            if success:
                logger.info(f"✅ {demo_name} completed successfully in {duration:.2f}s")
            else:
                logger.error(f"❌ {demo_name} failed after {duration:.2f}s")
                
        except Exception as e:
            end_time = time.time()
            duration = end_time - start_time
            logger.error(f"❌ {demo_name} crashed after {duration:.2f}s: {e}")
            results[demo_name] = {
                'success': False,
                'duration': duration,
                'error': str(e)
            }
    
    # Summary
    logger.info(f"\n{'='*60}")
    logger.info("DEMO SUMMARY")
    logger.info(f"{'='*60}")
    
    successful_demos = sum(1 for r in results.values() if r['success'])
    total_demos = len(results)
    total_time = sum(r['duration'] for r in results.values())
    
    logger.info(f"Total Demos: {total_demos}")
    logger.info(f"Successful: {successful_demos}")
    logger.info(f"Failed: {total_demos - successful_demos}")
    logger.info(f"Success Rate: {successful_demos/total_demos:.1%}")
    logger.info(f"Total Time: {total_time:.2f}s")
    
    for demo_name, result in results.items():
        status = "✅ PASS" if result['success'] else "❌ FAIL"
        logger.info(f"{status} {demo_name} ({result['duration']:.2f}s)")
        if not result['success'] and 'error' in result:
            logger.info(f"    Error: {result['error']}")
    
    logger.info(f"\n🎉 LLM Gateway Demo completed!")
    logger.info(f"Check 'llm_gateway_demo.log' for detailed logs")
    logger.info(f"Check 'llm_enhanced_output/' for generated reports")
    logger.info(f"Check 'llm_utilization_reports/' for utilization reports")


if __name__ == "__main__":
    main()
