# Naked Calls Test Suite

## Overview

The Naked Calls Test Suite is a comprehensive validation system that ensures all external service calls go through centralized systems rather than making direct "naked calls" that bypass the intended architecture.

## What Are Naked Calls?

Naked calls are direct API calls or service invocations that bypass centralized systems, leading to:

- **Inconsistent error handling**
- **No cost tracking**
- **Missing rate limiting**
- **Poor monitoring and logging**
- **Security vulnerabilities**
- **Maintenance difficulties**

## Types of Naked Calls Detected

### 1. **Database Connections**
```python
# ❌ Naked call
conn = psycopg2.connect(database_url)

# ✅ Centralized call
from backend.core.database_manager import DatabaseConnectionManager
conn = DatabaseConnectionManager.get_connection()
```

### 2. **LLM API Calls**
```python
# ❌ Naked call
import openai
response = openai.ChatCompletion.create(model="gpt-4", messages=[])

# ✅ Centralized call
from backend.llm.unified_llm_gateway import UnifiedLLMGateway
gateway = UnifiedLLMGateway()
response = gateway.generate_completion(prompt, model="gpt-4")
```

### 3. **MLflow Tracking**
```python
# ❌ Naked call
import mlflow
mlflow.set_experiment("my_experiment")
mlflow.log_metric("accuracy", 0.95)

# ✅ Centralized call
from backend.core.mlflow_config import MLflowConfig
mlflow_config = MLflowConfig()
mlflow_config.log_metric("accuracy", 0.95)
```

### 4. **AWS Services**
```python
# ❌ Naked call
import boto3
s3 = boto3.client('s3')

# ✅ Centralized call
from backend.core.aws_manager import AWSManager
aws_manager = AWSManager()
s3 = aws_manager.get_s3_client()
```

### 5. **Embedding Generation**
```python
# ❌ Naked call
from sentence_transformers import SentenceTransformer
model = SentenceTransformer('all-mpnet-base-v2')
embedding = model.encode(text)

# ✅ Centralized call
from backend.core.embedding_helper import EmbeddingHelper
helper = EmbeddingHelper(target_dimensions=1024)
embedding, metadata = helper.generate_embedding(text, content_id)
```

## Test Suite Components

### 1. **Validation Scripts**
- `scripts/validate_centralization.py` - Comprehensive centralization validator
- `scripts/validate_embedding_centralization.py` - Embedding-specific validator

### 2. **Test Suite**
- `tests/test_naked_calls.py` - Complete test suite with unit tests
- `scripts/run_naked_call_tests.py` - Simple test runner

### 3. **Integration**
- Integrated into pre-flight checks
- Automated validation in CI/CD pipeline

## Running the Tests

### Quick Test
```bash
python scripts/run_naked_call_tests.py
```

### Individual Validators
```bash
# Comprehensive validation
python scripts/validate_centralization.py

# Embedding-specific validation
python scripts/validate_embedding_centralization.py
```

### Pre-flight Integration
```bash
# Runs naked call tests as part of pre-flight checks
python scripts/pre_flight_cleanup.py --pre-flight
```

## Test Categories

### 1. **Embedding Centralization**
- Detects direct `SentenceTransformer` usage
- Validates `EmbeddingHelper` usage
- Ensures consistent embedding dimensions

### 2. **Database Connection Centralization**
- Detects direct `psycopg2.connect()` calls
- Validates connection manager usage
- Ensures proper connection pooling

### 3. **LLM Gateway Centralization**
- Detects direct OpenAI/Anthropic API calls
- Validates unified LLM gateway usage
- Ensures cost tracking and rate limiting

### 4. **MLflow Centralization**
- Detects direct MLflow calls
- Validates centralized MLflow configuration
- Ensures consistent experiment tracking

### 5. **AWS Centralization**
- Detects direct boto3 calls
- Validates centralized AWS manager usage
- Ensures proper credential management

## Allowed Files

Certain files are allowed to have naked calls for legitimate reasons:

- **Test files** (`test_*.py`, `scripts/test_*.py`)
- **Setup scripts** (`scripts/setup_*.py`)
- **Validation scripts** (the validators themselves)
- **Notebooks** (`notebooks/*.py`)
- **Centralized system implementations** (the systems themselves)

## Fixing Issues

When naked calls are detected, the test suite provides specific fix suggestions:

1. **Import the centralized system**
2. **Replace direct calls with centralized methods**
3. **Update function signatures if needed**
4. **Test the changes**

## Benefits

### **Consistency**
- All external calls go through the same interface
- Consistent error handling and logging
- Uniform configuration management

### **Monitoring**
- Centralized cost tracking
- Performance monitoring
- Usage analytics

### **Security**
- Centralized credential management
- Access control and auditing
- Security policy enforcement

### **Maintenance**
- Single point of configuration
- Easier updates and migrations
- Reduced code duplication

## Integration with Development Workflow

### **Pre-commit Hooks**
- Run naked call tests before commits
- Prevent naked calls from entering codebase

### **CI/CD Pipeline**
- Automated testing in build process
- Fail builds with naked calls
- Generate reports for review

### **Code Reviews**
- Use test results in review process
- Ensure architectural compliance
- Maintain code quality standards

## Future Enhancements

### **Additional Validators**
- Redis connection centralization
- External API call centralization
- File system access centralization

### **Advanced Detection**
- AST-based pattern matching
- Import dependency analysis
- Runtime call tracing

### **Automated Fixes**
- Automatic code transformation
- Refactoring suggestions
- Migration tools

## Troubleshooting

### **False Positives**
If legitimate code is flagged as a naked call:

1. Add the file to the allowed files list
2. Update the pattern matching rules
3. Create a more specific exclusion pattern

### **Missing Centralized Systems**
If a centralized system doesn't exist:

1. Create the centralized system first
2. Update the test suite to recognize it
3. Migrate existing code to use it

### **Performance Issues**
If tests run too slowly:

1. Optimize pattern matching
2. Add caching for file scans
3. Run tests in parallel

## Conclusion

The Naked Calls Test Suite is a critical tool for maintaining architectural integrity and ensuring that all external service calls go through properly designed centralized systems. Regular use of this test suite helps maintain code quality, security, and maintainability.
