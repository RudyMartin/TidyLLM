# S3 File Processor System for MVR Review
*Comprehensive documentation for the AWS Lambda-based file processing system*

**Created**: 2025-01-27 14:35:00  
**System**: MVR Review S3 File Processor  
**Version**: 1.0.0  
**Status**: Production Ready

---

## 🚀 **System Overview**

The S3 File Processor System is a serverless AWS Lambda function that automatically processes files when they land in an S3 bucket. It provides comprehensive file validation, Review ID extraction, classification, and organization for the MVR Review system.

### **Key Features:**
- **Automatic File Processing**: Triggers when files are uploaded to landing bucket
- **Review ID Extraction**: Uses existing MCP patterns to extract Review IDs
- **File Classification**: Automatically classifies files into MVR document types
- **Validation Checks**: Comprehensive file validation before processing
- **S3 Integration**: Handles file movement between landing, catalog, and quarantine buckets
- **SQS Notifications**: Sends processing results to SQS queue

---

## 📁 **Architecture Components**

### **1. Core Processor (`src/backend/s3_file_processor.py`)**

#### **S3FileProcessor Class**
```python
class S3FileProcessor:
    """Process files landing in S3 bucket with MVR Review validation"""
    
    def __init__(self, config_path: str = None):
        self.s3_client = boto3.client('s3')
        self.sqs_client = boto3.client('sqs')
        self.config = self._load_config(config_path)
        self.review_id_patterns = [...]  # MCP patterns
        self.file_classification = self._load_file_classification()
```

#### **Key Methods:**
- `extract_review_id(content)`: Extract Review ID using MCP patterns
- `classify_file(filename, content)`: Classify file by extension and content
- `validate_file(bucket, key, content)`: Comprehensive file validation
- `process_s3_event(event)`: Main processing pipeline
- `_move_to_catalog()`: Move valid files to catalog bucket
- `_move_to_quarantine()`: Move invalid files to quarantine bucket

### **2. CloudFormation Infrastructure (`deploy/s3_processor_lambda.yaml`)**

#### **S3 Buckets:**
- **Landing Bucket**: Receives uploaded files, triggers Lambda
- **Catalog Bucket**: Stores valid, processed files with Review ID organization
- **Quarantine Bucket**: Stores invalid files for review

#### **Lambda Function:**
- **Runtime**: Python 3.9
- **Timeout**: 300 seconds
- **Memory**: 512 MB
- **Triggers**: S3 ObjectCreated events

#### **SQS Queue:**
- **Notification Queue**: Processing results and status updates
- **Dead Letter Queue**: Failed message handling
- **Retention**: 14 days

### **3. Deployment Script (`deploy/deploy_s3_processor.sh`)**

#### **Automated Deployment:**
- Package Lambda function with dependencies
- Deploy CloudFormation stack
- Update Lambda function code
- Configure S3 event notifications

---

## 🔍 **Review ID Extraction System**

### **Pattern Recognition:**
The system uses existing MCP regex patterns from the backend:

```python
review_id_patterns = [
    r'Review ID[:\s]*([A-Z]{3}\d{5})',
    r'Review[:\s]*([A-Z]{3}\d{5})',
    r'([A-Z]{3}\d{5})',
    r'Review ID[:\s]*(\d{5})',
]
```

### **Extraction Process:**
1. **Pattern Matching**: Searches file content for Review ID patterns
2. **Format Standardization**: Ensures Review ID format (e.g., `REV00001`)
3. **Validation**: Confirms Review ID presence and format
4. **Grouping**: Groups files by Review ID for organization

### **Example Output:**
```json
{
  "review_id_groups": {
    "REV00001": [
      {
        "filename": "model_documentation.pdf",
        "size_mb": 2.3,
        "category": "Model Development Document (MDD)",
        "priority": "High"
      }
    ]
  }
}
```

---

## 📋 **File Classification System**

### **Classification Methods:**

#### **1. Content-Based Classification:**
- Analyzes first 1000 characters for keywords
- Matches against MVR document type keywords
- Requires minimum 2 keyword matches for classification

#### **2. Extension-Based Classification:**
- Falls back to file extension matching
- Maps extensions to MVR document types
- Provides default classification for unknown types

### **MVR Document Types Supported:**

| Document Type | Extensions | Category | Priority |
|---------------|------------|----------|----------|
| Unclassified | All | Unclassified (U) | Low |
| Whitepaper | .pdf, .docx, .doc, .md, .txt | Whitepaper (W) | Medium |
| Validation Scoping Template | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json | Validation Scoping Template (VST) | High |
| Annual Model Review | .pdf, .docx, .doc, .md, .txt, .xlsx, .xls | Annual Model Review (AMR) | High |
| Model Documentation Assessment | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json | Model Documentation Assessment (MDA) | High |
| Model Development Document | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .py, .r, .sql, .ipynb | Model Development Document (MDD) | High |
| Model Development Plan | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Model Development Plan (MDP) | High |
| SDC Validation Report | .pdf, .docx, .doc, .md, .txt, .xlsx, .xls | SDC Validation Report (SVR) | High |
| QA Template | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | QA Template (QAT) | Medium |
| Implementation Testing Document | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Implementation Testing Document (ITD) | High |
| Model Implementation Plan | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Model Implementation Plan (MIP) | High |
| Standards/Procedures | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Standards/Procedures (SP) | Medium |
| Model Performance Monitoring Plan | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Model Performance Monitoring (MPM) Plan | High |
| Post-Development Recalibrated Model Plan | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Post-Development Recalibrated Model (PDRM) Plan | High |
| Modeling Area Prioritization Plan | .pdf, .docx, .doc, .md, .txt, .yaml, .yml, .json, .xlsx, .xls | Modeling Area Prioritization Plan (MAPP) | High |

---

## ✅ **File Validation System**

### **Validation Checks:**

#### **1. File Size Validation:**
- **Maximum Size**: 100MB (configurable)
- **Size Calculation**: Uses S3 HeadObject API
- **Error Handling**: Files exceeding limit moved to quarantine

#### **2. File Extension Validation:**
- **Allowed Extensions**: Configurable list of supported file types
- **Extension Checking**: Validates against allowed extensions
- **Fallback**: Unknown extensions classified as "Unclassified"

#### **3. Content Validation:**
- **Empty Content Check**: Rejects files with no content
- **Suspicious Pattern Detection**: Checks for malicious content patterns
- **Encoding Validation**: Handles UTF-8 encoding with error tolerance

#### **4. Review ID Validation:**
- **Pattern Matching**: Uses MCP regex patterns
- **Format Validation**: Ensures proper Review ID format
- **Warning System**: Alerts when Review ID not found

### **Validation Result Structure:**
```json
{
  "valid": true,
  "errors": [],
  "warnings": ["No Review ID found in file content"],
  "file_size_mb": 2.3,
  "file_extension": ".pdf",
  "review_id": "REV00001",
  "classification": {
    "type": "model_development_document",
    "category": "Model Development Document (MDD)",
    "priority": "High",
    "classification_method": "content_analysis"
  }
}
```

---

## 🔄 **Processing Pipeline**

### **1. File Upload Trigger:**
```
File uploaded to landing bucket
    ↓
S3 ObjectCreated event
    ↓
Lambda function triggered
```

### **2. File Processing:**
```
Download file content from S3
    ↓
Validate file (size, extension, content)
    ↓
Extract Review ID using MCP patterns
    ↓
Classify file (content-based or extension-based)
    ↓
Determine processing path
```

### **3. File Routing:**
```
Valid File?
    ↓
Yes → Move to catalog bucket with Review ID organization
No  → Move to quarantine bucket with error metadata
```

### **4. Notification:**
```
Send processing results to SQS queue
    ↓
Include Review ID groups and summary statistics
    ↓
Log processing details to CloudWatch
```

---

## 📊 **Processing Results**

### **Summary Statistics:**
```json
{
  "summary": {
    "total_files": 5,
    "valid_files": 4,
    "invalid_files": 1,
    "moved_to_catalog": 4,
    "moved_to_quarantine": 1
  }
}
```

### **Review ID Groups:**
```json
{
  "review_id_groups": {
    "REV00001": [
      {
        "filename": "model_documentation.pdf",
        "size_mb": 2.3,
        "category": "Model Development Document (MDD)",
        "priority": "High"
      },
      {
        "filename": "validation_report.docx",
        "size_mb": 1.8,
        "category": "SDC Validation Report (SVR)",
        "priority": "High"
      }
    ]
  }
}
```

### **Error Tracking:**
```json
{
  "errors": [
    "File size 150.5MB exceeds maximum 100MB",
    "File extension .exe not allowed"
  ]
}
```

---

## 🚀 **Deployment Instructions**

### **1. Prerequisites:**
- AWS CLI configured with appropriate permissions
- Python 3.9+ installed
- Required Python packages (boto3, pyyaml)

### **2. Deploy Infrastructure:**
```bash
# Make deployment script executable
chmod +x deploy/deploy_s3_processor.sh

# Run deployment
./deploy/deploy_s3_processor.sh
```

### **3. Verify Deployment:**
```bash
# Check CloudFormation stack status
aws cloudformation describe-stacks --stack-name mvr-s3-processor

# List S3 buckets
aws s3 ls | grep mvr

# Check Lambda function
aws lambda list-functions --query 'Functions[?contains(FunctionName, `mvr-s3-processor`)]'
```

### **4. Test the System:**
```bash
# Upload test file to landing bucket
aws s3 cp test_document.pdf s3://mvr-landing-bucket-20241215/

# Check processing results
aws sqs receive-message --queue-url <SQS_QUEUE_URL>

# Monitor CloudWatch logs
aws logs tail /aws/lambda/mvr-s3-processor --follow
```

---

## 🔧 **Configuration**

### **Environment Variables:**
- `S3_LANDING_BUCKET`: Landing bucket name
- `S3_CATALOG_BUCKET`: Catalog bucket name
- `S3_QUARANTINE_BUCKET`: Quarantine bucket name
- `SQS_NOTIFICATION_QUEUE`: SQS queue ARN

### **Configuration File (`dev_configs/file_classification.yaml`):**
- File classification rules
- MVR document type definitions
- Extension mappings
- Compliance mappings

### **Customization Options:**
- **File Size Limits**: Modify `max_file_size_mb` in configuration
- **Allowed Extensions**: Update `allowed_extensions` list
- **Review ID Patterns**: Add custom regex patterns
- **Classification Keywords**: Modify content-based classification keywords

---

## 📈 **Monitoring and Logging**

### **CloudWatch Logs:**
- **Log Group**: `/aws/lambda/mvr-s3-processor`
- **Retention**: 14 days
- **Log Levels**: INFO, ERROR, WARNING

### **SQS Monitoring:**
- **Queue Metrics**: Message count, processing time
- **Dead Letter Queue**: Failed message tracking
- **Alerts**: Configure CloudWatch alarms for queue depth

### **S3 Monitoring:**
- **Bucket Metrics**: Object count, size, requests
- **Access Logging**: Enable for audit trails
- **Lifecycle Policies**: Automatic cleanup of old files

---

## 🛡️ **Security Considerations**

### **IAM Permissions:**
- **Least Privilege**: Lambda function has minimal required permissions
- **S3 Access**: Read from landing, write to catalog/quarantine
- **SQS Access**: Send messages to notification queue

### **Data Protection:**
- **Encryption**: S3 buckets use default encryption
- **Access Control**: Bucket policies restrict access
- **Audit Logging**: CloudTrail tracks API calls

### **Content Validation:**
- **Malicious Content**: Pattern detection for suspicious content
- **File Type Validation**: Extension and content validation
- **Size Limits**: Prevents resource exhaustion attacks

---

## 🔄 **Error Handling and Recovery**

### **Error Types:**
1. **File Processing Errors**: Invalid files moved to quarantine
2. **S3 Access Errors**: Retry with exponential backoff
3. **Classification Errors**: Fallback to extension-based classification
4. **Review ID Errors**: Warning logged, processing continues

### **Recovery Mechanisms:**
- **Retry Logic**: Automatic retry for transient failures
- **Dead Letter Queue**: Failed messages stored for manual review
- **Quarantine Bucket**: Invalid files preserved for analysis
- **CloudWatch Alarms**: Automatic alerting for processing failures

---

## 📚 **Integration with MVR Review System**

### **MCP Integration:**
- **Review ID Patterns**: Uses existing MCP regex patterns
- **File Classification**: Aligns with MVR document types
- **Metadata Storage**: S3 object metadata includes MVR-specific fields

### **Demo Integration:**
- **Review ID Matching**: Supports demo's Review ID extraction
- **File Classification**: Provides classification for demo uploads
- **Processing Results**: Results can be consumed by demo interface

### **Workflow Integration:**
- **Landing Zone**: Files uploaded to S3 trigger processing
- **Catalog Organization**: Processed files organized by Review ID
- **Notification System**: SQS messages trigger downstream workflows

---

## 🎯 **Future Enhancements**

### **Planned Features:**
1. **Virus Scanning**: Integration with AWS GuardDuty or third-party scanners
2. **Content Analysis**: AI-powered content classification
3. **Batch Processing**: Support for large file batches
4. **Real-time Monitoring**: WebSocket notifications for real-time updates
5. **Advanced Metadata**: Extraction of additional document metadata

### **Performance Optimizations:**
1. **Parallel Processing**: Process multiple files concurrently
2. **Caching**: Cache classification results for similar files
3. **Compression**: Compress large files before processing
4. **Streaming**: Stream file content instead of downloading entirely

---

## 📞 **Support and Troubleshooting**

### **Common Issues:**
1. **File Not Processing**: Check S3 event notifications and Lambda permissions
2. **Classification Errors**: Verify file content and classification keywords
3. **Review ID Not Found**: Check file content for Review ID patterns
4. **SQS Message Failures**: Monitor dead letter queue for failed messages

### **Debugging Steps:**
1. **Check CloudWatch Logs**: Review Lambda function logs
2. **Verify S3 Permissions**: Ensure Lambda has proper S3 access
3. **Test File Upload**: Upload test file and monitor processing
4. **Check SQS Queue**: Verify messages are being sent and received

---

*This documentation was automatically generated using the [Save to Docs] sparse command on 2025-01-27 14:35:00*
