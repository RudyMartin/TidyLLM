# 🤖 Bedrock Model Analysis & Recommendations for QA Use Case

## Overview
This document analyzes the current Bedrock model configuration and provides recommendations for the QA document processing use case, which requires at least 2-3 different Bedrock models.

---

## 🔍 **Current Bedrock Model Configuration**

### **1. Current Model Setup**
**File:** `src/backend/core/config.py`

#### **Embedding Models (Titan):**
```python
"embedding_models": {
    "amazon.titan-embed-text-v1": 768,
    "amazon.titan-embed-text-v2:0": 1024,
    "cohere.embed-english-v3": 1024,
    "anthropic.claude-v2": 1536
}
```

#### **LLM Models (Non-Bedrock):**
```python
"llm_models": {
    "anthropic": {
        "provider": "anthropic", 
        "model": "claude-3-sonnet-20240229",
        "max_tokens": 2000,
        "temperature": 0.1
    }
}
```

#### **Model Options:**
```python
MODEL_OPTIONS = {
    "titan_v1": {"id": "amazon.titan-embed-text-v1", "dimensions": 768},
    "titan_v2": {"id": "amazon.titan-embed-text-v2:0", "dimensions": 1024},
    "cohere": {"id": "cohere.embed-english-v3", "dimensions": None},
    "anthropic": {"id": "anthropic.claude-v2", "dimensions": None}
}
```

### **2. Current Bedrock Client**
```python
bedrock_client = boto3.client("bedrock-runtime", region_name=CONFIG["region_name"])
```

---

## 🎯 **QA Use Case Requirements**

### **Required Bedrock Models for QA Processing:**

#### **1. Text Embedding Model**
- **Purpose**: Convert documents to vector embeddings
- **Current**: `amazon.titan-embed-text-v2:0`
- **Status**: ✅ Configured

#### **2. Document Analysis Model**
- **Purpose**: Extract key fields from documents
- **Current**: Not configured (using external APIs)
- **Need**: Bedrock Claude model for document analysis

#### **3. Report Generation Model**
- **Purpose**: Generate QA HealthCheck reports
- **Current**: Not configured (using external APIs)
- **Need**: Bedrock Claude model for report generation

---

## 📊 **Available Bedrock Models Analysis**

### **1. Amazon Titan Models**

#### **Titan Text Embedding Models:**
```python
# Current Configuration
"amazon.titan-embed-text-v1": 768,      # ✅ Available
"amazon.titan-embed-text-v2:0": 1024,   # ✅ Available (Current Default)
```

#### **Titan Text Generation Models:**
```python
# Recommended for QA
"amazon.titan-text-express-v1": {
    "id": "amazon.titan-text-express-v1",
    "max_tokens": 8192,
    "use_case": "Document analysis, field extraction"
},
"amazon.titan-text-lite-v1": {
    "id": "amazon.titan-text-lite-v1", 
    "max_tokens": 4096,
    "use_case": "Quick responses, cost-effective"
}
```

### **2. Anthropic Claude Models (via Bedrock)**

#### **Claude 3 Models:**
```python
# Recommended for QA
"anthropic.claude-3-sonnet-20240229-v1:0": {
    "id": "anthropic.claude-3-sonnet-20240229-v1:0",
    "max_tokens": 4096,
    "use_case": "Document analysis, field extraction"
},
"anthropic.claude-3-haiku-20240307-v1:0": {
    "id": "anthropic.claude-3-haiku-20240307-v1:0",
    "max_tokens": 4096,
    "use_case": "Quick responses, cost-effective"
},
"anthropic.claude-3-opus-20240229-v1:0": {
    "id": "anthropic.claude-3-opus-20240229-v1:0",
    "max_tokens": 4096,
    "use_case": "Complex reasoning, high accuracy"
}
```

### **3. Cohere Models (via Bedrock)**

#### **Command Models:**
```python
# Recommended for QA
"cohere.command-text-v14": {
    "id": "cohere.command-text-v14",
    "max_tokens": 4096,
    "use_case": "Document analysis, structured output"
},
"cohere.command-light-text-v14": {
    "id": "cohere.command-light-text-v14",
    "max_tokens": 4096,
    "use_case": "Quick responses, cost-effective"
}
```

---

## 🔧 **Recommended Bedrock Configuration**

### **1. Enhanced Configuration**
```python
# Add to src/backend/core/config.py
CONFIG.update({
    # Bedrock Models for QA Use Case
    "bedrock_models": {
        # Embedding Models
        "embedding": {
            "primary": "amazon.titan-embed-text-v2:0",
            "fallback": "amazon.titan-embed-text-v1",
            "dimensions": 1024
        },
        
        # Document Analysis Models
        "document_analysis": {
            "primary": "anthropic.claude-3-sonnet-20240229-v1:0",
            "fallback": "amazon.titan-text-express-v1",
            "max_tokens": 4096,
            "temperature": 0.1
        },
        
        # Report Generation Models
        "report_generation": {
            "primary": "anthropic.claude-3-opus-20240229-v1:0",
            "fallback": "anthropic.claude-3-sonnet-20240229-v1:0",
            "max_tokens": 4096,
            "temperature": 0.2
        },
        
        # Quick Processing Models
        "quick_processing": {
            "primary": "anthropic.claude-3-haiku-20240307-v1:0",
            "fallback": "amazon.titan-text-lite-v1",
            "max_tokens": 2048,
            "temperature": 0.1
        }
    }
})
```

### **2. Model Selection Strategy**
```python
def get_bedrock_model_for_task(task_type: str, priority: str = "primary"):
    """Get appropriate Bedrock model for specific task."""
    
    model_config = CONFIG["bedrock_models"].get(task_type, {})
    
    if priority == "primary":
        return model_config.get("primary")
    elif priority == "fallback":
        return model_config.get("fallback")
    else:
        return model_config.get("primary", model_config.get("fallback"))
```

### **3. Task-Specific Model Mapping**
```python
# QA Processing Tasks
QA_TASK_MODELS = {
    "document_upload": "embedding",
    "field_extraction": "document_analysis", 
    "content_analysis": "document_analysis",
    "report_generation": "report_generation",
    "quick_validation": "quick_processing",
    "error_correction": "document_analysis"
}
```

---

## 🚀 **Implementation Recommendations**

### **1. Immediate Actions**

#### **Update Configuration:**
```python
# Add to src/backend/core/config.py
CONFIG.update({
    "bedrock_models": {
        "embedding": {
            "primary": "amazon.titan-embed-text-v2:0",
            "fallback": "amazon.titan-embed-text-v1"
        },
        "document_analysis": {
            "primary": "anthropic.claude-3-sonnet-20240229-v1:0",
            "fallback": "amazon.titan-text-express-v1"
        },
        "report_generation": {
            "primary": "anthropic.claude-3-opus-20240229-v1:0",
            "fallback": "anthropic.claude-3-sonnet-20240229-v1:0"
        }
    }
})
```

#### **Update Credentials:**
```bash
# Add to src/backend/config/credentials.env
BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
BEDROCK_ANALYSIS_MODEL=anthropic.claude-3-sonnet-20240229-v1:0
BEDROCK_REPORT_MODEL=anthropic.claude-3-opus-20240229-v1:0
```

### **2. Enhanced Bedrock Client Management**
```python
class BedrockModelManager:
    """Manages multiple Bedrock models for different tasks."""
    
    def __init__(self):
        self.client = boto3.client("bedrock-runtime", region_name=CONFIG["region_name"])
        self.models = CONFIG["bedrock_models"]
    
    def get_embedding(self, text: str):
        """Generate embeddings using Titan."""
        model_id = self.models["embedding"]["primary"]
        # Implementation for Titan embedding
    
    def analyze_document(self, content: str):
        """Analyze document using Claude."""
        model_id = self.models["document_analysis"]["primary"]
        # Implementation for Claude document analysis
    
    def generate_report(self, data: dict):
        """Generate QA report using Claude Opus."""
        model_id = self.models["report_generation"]["primary"]
        # Implementation for Claude report generation
```

### **3. Model Fallback Strategy**
```python
def invoke_bedrock_with_fallback(task_type: str, payload: dict):
    """Invoke Bedrock model with automatic fallback."""
    
    model_config = CONFIG["bedrock_models"][task_type]
    
    try:
        # Try primary model
        response = bedrock_client.invoke_model(
            modelId=model_config["primary"],
            body=json.dumps(payload)
        )
        return response
        
    except Exception as e:
        logger.warning(f"Primary model failed: {e}")
        
        try:
            # Try fallback model
            response = bedrock_client.invoke_model(
                modelId=model_config["fallback"],
                body=json.dumps(payload)
            )
            return response
            
        except Exception as e2:
            logger.error(f"Fallback model also failed: {e2}")
            raise
```

---

## 📈 **Cost & Performance Analysis**

### **1. Model Cost Comparison (per 1M tokens)**

| Model | Input Cost | Output Cost | Use Case |
|-------|------------|-------------|----------|
| **Titan Embed v2** | $0.0001 | N/A | Embeddings |
| **Claude 3 Haiku** | $0.25 | $1.25 | Quick processing |
| **Claude 3 Sonnet** | $3.00 | $15.00 | Document analysis |
| **Claude 3 Opus** | $15.00 | $75.00 | Report generation |

### **2. Performance Characteristics**

| Model | Speed | Accuracy | Context Window | Best For |
|-------|-------|----------|----------------|----------|
| **Titan Embed v2** | Fast | High | 8K | Embeddings |
| **Claude 3 Haiku** | Very Fast | Good | 200K | Quick tasks |
| **Claude 3 Sonnet** | Fast | High | 200K | Analysis |
| **Claude 3 Opus** | Medium | Highest | 200K | Complex tasks |

### **3. Recommended Usage Pattern**
```python
# Cost-effective QA processing
def process_qa_documents(documents):
    # 1. Generate embeddings (Titan - very cheap)
    embeddings = generate_embeddings(documents)
    
    # 2. Quick field extraction (Haiku - fast & cheap)
    fields = extract_fields_quick(documents)
    
    # 3. Detailed analysis (Sonnet - balanced)
    analysis = analyze_documents(documents)
    
    # 4. Generate report (Opus - high quality)
    report = generate_qa_report(analysis)
    
    return report
```

---

## ✅ **Implementation Plan**

### **Phase 1: Basic Bedrock Integration**
1. **Add Bedrock Models Configuration**
2. **Update Credential Management**
3. **Implement Basic Model Selection**

### **Phase 2: Task-Specific Models**
1. **Document Analysis with Claude Sonnet**
2. **Report Generation with Claude Opus**
3. **Quick Processing with Claude Haiku**

### **Phase 3: Advanced Features**
1. **Model Fallback Strategy**
2. **Cost Optimization**
3. **Performance Monitoring**

---

## 🎯 **Conclusion**

### **Current Status:**
- ✅ **1 Bedrock Model**: Titan Embed v2 (embeddings)
- ❌ **Missing**: Document analysis model
- ❌ **Missing**: Report generation model

### **Recommended Models for QA:**
1. **Titan Embed v2**: For document embeddings
2. **Claude 3 Sonnet**: For document analysis and field extraction
3. **Claude 3 Opus**: For high-quality report generation
4. **Claude 3 Haiku**: For quick processing tasks

### **Next Steps:**
1. **Update configuration** with recommended Bedrock models
2. **Implement model selection** based on task type
3. **Add fallback strategy** for reliability
4. **Monitor costs** and optimize usage

---

*This configuration will provide the 2-3 Bedrock models needed for comprehensive QA document processing while maintaining cost-effectiveness and performance.*
