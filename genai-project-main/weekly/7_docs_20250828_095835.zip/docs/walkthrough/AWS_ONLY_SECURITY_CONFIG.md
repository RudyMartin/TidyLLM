# 🔒 AWS-Only Security Configuration Guide

## Overview
This document provides configuration options to restrict VectorQA Sage to **AWS-only models** for security-sensitive environments, eliminating external API dependencies.

---

## 🚨 **Security Requirements**

### **Why AWS-Only Mode?**
- **Compliance**: Meet strict security requirements
- **Data Sovereignty**: Keep all data within AWS ecosystem
- **Access Control**: Eliminate external API dependencies
- **Audit Trail**: Centralized logging and monitoring
- **Cost Control**: Predictable AWS-only billing

### **Current External Dependencies:**
- ❌ **OpenAI API**: External to AWS
- ❌ **Cohere API**: External to AWS  
- ❌ **Google Gemini API**: External to AWS
- ❌ **Hugging Face API**: External to AWS
- ❌ **Anthropic API**: External to AWS (direct)

---

## 🔧 **AWS-Only Configuration**

### **1. Security Mode Configuration**
```python
# Add to src/backend/core/config.py
CONFIG.update({
    # Security Configuration
    "security_mode": {
        "aws_only": True,  # Restrict to AWS services only
        "allow_external_apis": False,  # Disable external API calls
        "require_iam_roles": True,  # Require IAM role authentication
        "audit_logging": True,  # Enable comprehensive logging
        "data_encryption": True  # Enable encryption at rest/transit
    },
    
    # AWS-Only Model Configuration
    "aws_models": {
        "enabled": True,
        "fallback_to_external": False,  # Never fallback to external APIs
        "preferred_providers": ["bedrock", "sagemaker", "lambda"]
    }
})
```

### **2. Environment Variable Control**
```bash
# Add to src/backend/config/credentials.env
# Security Configuration
AWS_ONLY_MODE=true
ALLOW_EXTERNAL_APIS=false
REQUIRE_IAM_ROLES=true
AUDIT_LOGGING=true

# AWS Model Configuration
BEDROCK_EMBEDDING_MODEL=amazon.titan-embed-text-v2:0
BEDROCK_ANALYSIS_MODEL=anthropic.claude-3-sonnet-20240229-v1:0
BEDROCK_REPORT_MODEL=anthropic.claude-3-opus-20240229-v1:0
BEDROCK_QUICK_MODEL=anthropic.claude-3-haiku-20240307-v1:0
```

### **3. Enhanced Configuration Loading**
```python
# Add to src/backend/core/config.py
def load_security_config():
    """Load security configuration from environment variables."""
    
    security_config = {
        "aws_only": os.getenv("AWS_ONLY_MODE", "true").lower() == "true",
        "allow_external_apis": os.getenv("ALLOW_EXTERNAL_APIS", "false").lower() == "true",
        "require_iam_roles": os.getenv("REQUIRE_IAM_ROLES", "true").lower() == "true",
        "audit_logging": os.getenv("AUDIT_LOGGING", "true").lower() == "true"
    }
    
    return security_config

# Update CONFIG with security settings
CONFIG.update({
    "security": load_security_config()
})
```

---

## 🛡️ **AWS-Only Model Implementation**

### **1. Restricted LLM Configuration**
```python
# Replace current llm_models with AWS-only versions
CONFIG.update({
    "llm_models": {
        # AWS Bedrock Models Only
        "bedrock_claude_sonnet": {
            "provider": "bedrock",
            "model": "anthropic.claude-3-sonnet-20240229-v1:0",
            "max_tokens": 4096,
            "temperature": 0.1,
            "aws_only": True
        },
        "bedrock_claude_opus": {
            "provider": "bedrock", 
            "model": "anthropic.claude-3-opus-20240229-v1:0",
            "max_tokens": 4096,
            "temperature": 0.2,
            "aws_only": True
        },
        "bedrock_claude_haiku": {
            "provider": "bedrock",
            "model": "anthropic.claude-3-haiku-20240307-v1:0", 
            "max_tokens": 2048,
            "temperature": 0.1,
            "aws_only": True
        },
        "bedrock_titan_text": {
            "provider": "bedrock",
            "model": "amazon.titan-text-express-v1",
            "max_tokens": 8192,
            "temperature": 0.1,
            "aws_only": True
        },
        "bedrock_titan_lite": {
            "provider": "bedrock",
            "model": "amazon.titan-text-lite-v1",
            "max_tokens": 4096,
            "temperature": 0.1,
            "aws_only": True
        }
    },
    
    # AWS-Only Fallback Order
    "fallback_order": [
        "bedrock_claude_sonnet",
        "bedrock_claude_haiku", 
        "bedrock_titan_text",
        "bedrock_titan_lite"
    ]
})
```

### **2. Security-Enhanced LLM Manager**
```python
# Create src/backend/core/aws_llm_manager.py
"""
AWS-Only LLM Manager for Security-Sensitive Environments

This module provides LLM functionality restricted to AWS services only,
eliminating external API dependencies for enhanced security.
"""

import boto3
import json
import logging
from typing import Dict, Any, Optional
from backend.core.config import CONFIG, bedrock_client

logger = logging.getLogger(__name__)

class AWSSecurityLLMManager:
    """AWS-only LLM manager with security restrictions."""
    
    def __init__(self):
        self.client = bedrock_client
        self.security_config = CONFIG.get("security", {})
        self.aws_only = self.security_config.get("aws_only", True)
        
        if not self.aws_only:
            raise SecurityError("AWS-only mode is required for this environment")
    
    def validate_aws_only(self):
        """Validate that only AWS services are being used."""
        if not self.aws_only:
            raise SecurityError("External API calls are not allowed in AWS-only mode")
    
    def invoke_bedrock_model(self, model_id: str, prompt: str, **kwargs) -> Dict[str, Any]:
        """Invoke AWS Bedrock model with security validation."""
        
        # Security validation
        self.validate_aws_only()
        
        # Audit logging
        if self.security_config.get("audit_logging"):
            logger.info(f"AWS Bedrock API call: {model_id}")
        
        try:
            payload = {
                "prompt": prompt,
                "max_tokens": kwargs.get("max_tokens", 4096),
                "temperature": kwargs.get("temperature", 0.1)
            }
            
            response = self.client.invoke_model(
                modelId=model_id,
                body=json.dumps(payload)
            )
            
            return json.loads(response["body"].read())
            
        except Exception as e:
            logger.error(f"Bedrock API error: {e}")
            raise
    
    def get_embedding(self, text: str) -> list:
        """Generate embeddings using AWS Titan only."""
        self.validate_aws_only()
        
        model_id = CONFIG.get("bedrock_models", {}).get("embedding", {}).get("primary")
        
        try:
            payload = {"inputText": text}
            response = self.client.invoke_model(
                modelId=model_id,
                body=json.dumps(payload)
            )
            
            result = json.loads(response["body"].read())
            return result.get("embedding", [])
            
        except Exception as e:
            logger.error(f"Embedding generation error: {e}")
            raise
    
    def analyze_document(self, content: str) -> Dict[str, Any]:
        """Analyze document using AWS Claude only."""
        self.validate_aws_only()
        
        model_id = CONFIG.get("bedrock_models", {}).get("document_analysis", {}).get("primary")
        
        prompt = f"""
        Analyze the following document and extract key information:
        
        {content}
        
        Return the analysis in JSON format with the following fields:
        - review_id: The review identifier
        - model_type: Type of model being reviewed
        - risk_tier: Risk assessment tier
        - model_id: Model identifier
        - model_name: Name of the model
        - version: Model version
        - authors: Model authors
        - date: Review date
        - validation_type: Type of validation
        """
        
        return self.invoke_bedrock_model(model_id, prompt)
    
    def generate_report(self, analysis_data: Dict[str, Any]) -> str:
        """Generate QA report using AWS Claude only."""
        self.validate_aws_only()
        
        model_id = CONFIG.get("bedrock_models", {}).get("report_generation", {}).get("primary")
        
        prompt = f"""
        Generate a comprehensive QA HealthCheck report based on the following analysis:
        
        {json.dumps(analysis_data, indent=2)}
        
        Include:
        1. Executive Summary
        2. Detailed Analysis
        3. Compliance Checklist
        4. Recommendations
        5. Risk Assessment
        
        Format as a professional report.
        """
        
        response = self.invoke_bedrock_model(model_id, prompt, max_tokens=4096)
        return response.get("completion", "")

class SecurityError(Exception):
    """Security violation exception."""
    pass
```

### **3. Security-Enhanced Credential Manager**
```python
# Update src/backend/config/credential_manager.py
def validate_aws_only_credentials(self) -> Dict[str, bool]:
    """Validate AWS-only credential requirements."""
    
    validation = {}
    
    # Check AWS credentials (required)
    aws_creds = self.get_aws_credentials()
    validation["aws"] = all([
        aws_creds["access_key_id"],
        aws_creds["secret_access_key"]
    ])
    
    # Check Bedrock configuration (required)
    bedrock_config = self.get_bedrock_config()
    validation["bedrock"] = bool(bedrock_config["model_id"])
    
    # External APIs should be disabled
    validation["external_apis_disabled"] = True
    
    # Check for any external API keys (should be None)
    external_keys = [
        self.get_openai_config()["api_key"],
        self.get_cohere_config()["api_key"],
        self.get_google_config()["api_key"],
        self.get_huggingface_config()["api_key"]
    ]
    
    validation["no_external_keys"] = all(key is None for key in external_keys)
    
    return validation

def print_aws_only_status(self):
    """Print AWS-only credential status."""
    validation = self.validate_aws_only_credentials()
    
    print("🔒 AWS-Only Security Status:")
    print("=" * 35)
    
    for provider, is_valid in validation.items():
        status = "✅" if is_valid else "❌"
        print(f"{status} {provider.replace('_', ' ').title()}")
    
    if not all(validation.values()):
        print("\n⚠️  Security Warning: AWS-only mode requirements not met!")
        print("Please ensure all external API keys are removed and AWS credentials are configured.")
```

---

## 🔐 **Security Enforcement**

### **1. Runtime Security Checks**
```python
# Add to src/backend/core/security.py
"""
Security enforcement module for AWS-only environments.
"""

import os
import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

class SecurityEnforcer:
    """Enforces security policies in AWS-only mode."""
    
    def __init__(self):
        self.aws_only = os.getenv("AWS_ONLY_MODE", "true").lower() == "true"
        self.audit_logging = os.getenv("AUDIT_LOGGING", "true").lower() == "true"
    
    def check_external_api_call(self, provider: str, endpoint: str):
        """Check if external API call is allowed."""
        if self.aws_only:
            raise SecurityViolationError(
                f"External API call to {provider} ({endpoint}) is not allowed in AWS-only mode"
            )
        
        if self.audit_logging:
            logger.warning(f"External API call: {provider} -> {endpoint}")
    
    def validate_iam_role(self):
        """Validate that IAM role is being used."""
        if not self.aws_only:
            return
        
        # Check if running on AWS infrastructure
        if not self._is_aws_environment():
            raise SecurityViolationError("AWS-only mode requires AWS infrastructure")
    
    def _is_aws_environment(self) -> bool:
        """Check if running in AWS environment."""
        # Check for AWS-specific environment variables
        aws_indicators = [
            "AWS_EXECUTION_ENV",  # Lambda
            "AWS_BATCH_JOB_ID",   # Batch
            "ECS_CONTAINER_METADATA_URI",  # ECS
            "KUBERNETES_SERVICE_HOST"  # EKS
        ]
        
        return any(os.getenv(indicator) for indicator in aws_indicators)

class SecurityViolationError(Exception):
    """Security policy violation exception."""
    pass
```

### **2. API Call Interception**
```python
# Add to src/backend/core/api_interceptor.py
"""
API call interceptor for security enforcement.
"""

import functools
from backend.core.security import SecurityEnforcer

def enforce_aws_only(func):
    """Decorator to enforce AWS-only mode."""
    
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        enforcer = SecurityEnforcer()
        
        # Check if function is trying to call external APIs
        if "openai" in func.__name__ or "cohere" in func.__name__ or "google" in func.__name__:
            enforcer.check_external_api_call("external", func.__name__)
        
        return func(*args, **kwargs)
    
    return wrapper
```

---

## 📋 **Deployment Configuration**

### **1. AWS-Only Deployment Script**
```bash
# Create scripts/deploy_aws_only.sh
#!/bin/bash

echo "🔒 Deploying VectorQA Sage in AWS-Only Security Mode"

# Set security environment variables
export AWS_ONLY_MODE=true
export ALLOW_EXTERNAL_APIS=false
export REQUIRE_IAM_ROLES=true
export AUDIT_LOGGING=true

# Validate AWS credentials
echo "Validating AWS credentials..."
aws sts get-caller-identity

# Validate Bedrock access
echo "Validating Bedrock access..."
aws bedrock list-foundation-models --region us-east-1

# Deploy application
echo "Deploying application..."
python src/run_app.py

echo "✅ AWS-Only deployment complete"
```

### **2. Security Validation Script**
```python
# Create scripts/validate_security.py
"""
Security validation script for AWS-only environments.
"""

import os
import sys
import boto3
from backend.config.credential_manager import credential_manager

def validate_aws_only_setup():
    """Validate AWS-only security setup."""
    
    print("🔒 Validating AWS-Only Security Configuration")
    print("=" * 50)
    
    # Check environment variables
    required_vars = [
        "AWS_ONLY_MODE",
        "ALLOW_EXTERNAL_APIS", 
        "REQUIRE_IAM_ROLES",
        "AUDIT_LOGGING"
    ]
    
    for var in required_vars:
        value = os.getenv(var, "not_set")
        status = "✅" if value != "not_set" else "❌"
        print(f"{status} {var}: {value}")
    
    # Validate credentials
    print("\n🔐 Validating Credentials:")
    credential_manager.print_aws_only_status()
    
    # Test Bedrock access
    print("\n🤖 Testing Bedrock Access:")
    try:
        bedrock = boto3.client("bedrock", region_name="us-east-1")
        models = bedrock.list_foundation_models()
        print(f"✅ Bedrock access: {len(models['modelSummaries'])} models available")
    except Exception as e:
        print(f"❌ Bedrock access failed: {e}")
    
    # Check for external API keys
    print("\n🚫 Checking for External API Keys:")
    external_keys = [
        "OPENAI_API_KEY",
        "COHERE_API_KEY", 
        "GOOGLE_API_KEY",
        "HUGGINGFACE_API_KEY"
    ]
    
    for key in external_keys:
        value = os.getenv(key)
        status = "❌" if value else "✅"
        print(f"{status} {key}: {'SET' if value else 'NOT SET'}")

if __name__ == "__main__":
    validate_aws_only_setup()
```

---

## 🎯 **Implementation Steps**

### **Phase 1: Basic AWS-Only Configuration**
1. **Add Security Configuration** to `config.py`
2. **Update Environment Variables** in `credentials.env`
3. **Create Security Enforcer** module

### **Phase 2: Model Restriction**
1. **Replace External Models** with Bedrock-only versions
2. **Update LLM Manager** for AWS-only operation
3. **Add Security Validation** to all API calls

### **Phase 3: Deployment & Validation**
1. **Create Deployment Scripts** for AWS-only mode
2. **Add Security Validation** tools
3. **Test Complete AWS-Only Workflow**

---

## ✅ **Benefits of AWS-Only Mode**

### **Security Benefits:**
- ✅ **No External Dependencies**: All processing within AWS
- ✅ **IAM Role Authentication**: Secure credential management
- ✅ **Audit Trail**: Complete logging of all operations
- ✅ **Data Sovereignty**: Data never leaves AWS ecosystem
- ✅ **Compliance**: Meets strict security requirements

### **Operational Benefits:**
- ✅ **Predictable Costs**: AWS-only billing
- ✅ **Centralized Management**: Single AWS account
- ✅ **Simplified Monitoring**: CloudWatch integration
- ✅ **Faster Processing**: No external API latency

---

*This AWS-only configuration ensures complete security compliance while maintaining full functionality for QA document processing.*
