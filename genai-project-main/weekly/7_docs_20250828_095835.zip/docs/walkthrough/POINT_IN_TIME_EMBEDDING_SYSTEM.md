# 🕒 Point-in-Time Benchmark Embedding System

## Overview
This document analyzes the implementation requirements for a **point-in-time benchmark embedding system** that supports Model Risk Governance with date-based standards tracking and PostgreSQL multi-index storage.

---

## 🎯 **Your Current Setup Analysis**

### **S3 Structure (Current)**
```
{bucket_name}/{prefix}/{standards_folder}/
├── 2024_01_15/
│   ├── policy_document_001.pdf
│   ├── standards_document_002.pdf
│   ├── procedure_document_003.pdf
│   └── guidance_document_004.pdf
├── 2024_02_01/
│   ├── updated_policy_001.pdf
│   ├── new_standards_005.pdf
│   └── revised_procedure_003.pdf
└── 2024_03_15/
    ├── latest_policy_001.pdf
    ├── current_standards_002.pdf
    └── final_procedure_003.pdf
```

### **Point-in-Time Logic**
- **Review Date**: `2024_01_20` → Use standards from `2024_01_15` folder
- **Review Date**: `2024_02_15` → Use standards from `2024_02_01` folder
- **Review Date**: `2024_03_20` → Use standards from `2024_03_15` folder

### **Business Value**
- ✅ **No Retroactive Application**: Old reviews use old standards
- ✅ **Compliance Accuracy**: Reviews match standards in effect at time
- ✅ **Audit Trail**: Complete history of standards evolution
- ✅ **Regulatory Compliance**: Meets Model Risk Governance requirements

---

## 🔍 **Current Backend Analysis**

### **❌ What's Missing:**

#### **1. Database Layer**
- **Status**: Placeholder only (`database/CLAUDE.md`)
- **Need**: PostgreSQL with vector extensions
- **Schema**: Multi-index with dates, categories, embeddings

#### **2. S3 Standards Integration**
- **Status**: No standards folder processing
- **Need**: Date-based folder scanning and processing
- **Integration**: MCP-style document processing

#### **3. Embedding Pipeline**
- **Status**: Placeholder implementation (`embedding_helper.py`)
- **Need**: Real Bedrock embedding generation
- **Storage**: PostgreSQL vector storage

#### **4. Point-in-Time Logic**
- **Status**: Not implemented
- **Need**: Date-based benchmark selection
- **Query**: Time-aware similarity search

---

## 🏗️ **Implementation Plan**

### **Phase 1: Database Schema Design**

#### **PostgreSQL Schema with Vector Extensions**
```sql
-- Enable vector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Standards documents table
CREATE TABLE standards_documents (
    id SERIAL PRIMARY KEY,
    s3_key VARCHAR(500) NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    document_type VARCHAR(100) NOT NULL, -- policy, standards, procedure, guidance
    effective_date DATE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    file_size BIGINT,
    content_hash VARCHAR(64),
    processing_status VARCHAR(50) DEFAULT 'pending'
);

-- Document chunks table (for embedding)
CREATE TABLE document_chunks (
    id SERIAL PRIMARY KEY,
    document_id INTEGER REFERENCES standards_documents(id),
    chunk_index INTEGER NOT NULL,
    chunk_text TEXT NOT NULL,
    chunk_embedding vector(1024), -- Titan v2 dimensions
    chunk_metadata JSONB,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    parent_category_id INTEGER REFERENCES categories(id),
    effective_date DATE NOT NULL,
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Document-category relationships
CREATE TABLE document_categories (
    id SERIAL PRIMARY KEY,
    document_id INTEGER REFERENCES standards_documents(id),
    category_id INTEGER REFERENCES categories(id),
    confidence_score FLOAT DEFAULT 1.0,
    assigned_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_standards_effective_date ON standards_documents(effective_date);
CREATE INDEX idx_standards_document_type ON standards_documents(document_type);
CREATE INDEX idx_chunks_document_id ON document_chunks(document_id);
CREATE INDEX idx_chunks_embedding ON document_chunks USING ivfflat (chunk_embedding vector_cosine_ops);
CREATE INDEX idx_document_categories_doc_id ON document_categories(document_id);
CREATE INDEX idx_document_categories_cat_id ON document_categories(category_id);
```

### **Phase 2: MCP-Style Standards Processing**

#### **Standards Processing Coordinator**
```python
# src/backend/mcp/coordinators/standards_processing_coordinator.py
"""
Standards Processing Coordinator for MCP Architecture

This coordinator handles the processing of standards documents from S3
with point-in-time awareness and category classification.
"""

import boto3
import json
import logging
from datetime import datetime, date
from typing import List, Dict, Any, Optional
from backend.core.config import CONFIG, s3_client
from backend.core.aws_llm_manager import AWSSecurityLLMManager
from backend.mcp.workers.document_processor_worker import DocumentProcessorWorker
from backend.mcp.workers.embedding_worker import EmbeddingWorker
from backend.mcp.workers.category_classifier_worker import CategoryClassifierWorker

logger = logging.getLogger(__name__)

class StandardsProcessingCoordinator:
    """Coordinates standards document processing with point-in-time awareness."""
    
    def __init__(self):
        self.llm_manager = AWSSecurityLLMManager()
        self.document_processor = DocumentProcessorWorker()
        self.embedding_worker = EmbeddingWorker()
        self.category_classifier = CategoryClassifierWorker()
        
    def scan_standards_folders(self, start_date: Optional[date] = None, end_date: Optional[date] = None) -> List[Dict[str, Any]]:
        """Scan S3 standards folders for documents within date range."""
        
        standards_folder = f"{CONFIG['prefix']}/{CONFIG.get('standards_folder', 'standards')}"
        
        try:
            # List all date folders
            response = s3_client.list_objects_v2(
                Bucket=CONFIG['bucket_name'],
                Prefix=standards_folder,
                Delimiter='/'
            )
            
            date_folders = []
            for prefix in response.get('CommonPrefixes', []):
                folder_name = prefix['Prefix'].split('/')[-2]  # Get folder name
                
                try:
                    # Parse date from folder name (YYYY_MM_DD)
                    folder_date = datetime.strptime(folder_name, '%Y_%m_%d').date()
                    
                    # Apply date filters
                    if start_date and folder_date < start_date:
                        continue
                    if end_date and folder_date > end_date:
                        continue
                    
                    date_folders.append({
                        'folder_name': folder_name,
                        'effective_date': folder_date,
                        's3_prefix': prefix['Prefix']
                    })
                    
                except ValueError:
                    logger.warning(f"Invalid date folder format: {folder_name}")
                    continue
            
            return sorted(date_folders, key=lambda x: x['effective_date'])
            
        except Exception as e:
            logger.error(f"Error scanning standards folders: {e}")
            raise
    
    def process_standards_batch(self, date_folder: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Process all documents in a specific date folder."""
        
        try:
            # List documents in the folder
            response = s3_client.list_objects_v2(
                Bucket=CONFIG['bucket_name'],
                Prefix=date_folder['s3_prefix']
            )
            
            documents = []
            for obj in response.get('Contents', []):
                if obj['Key'].endswith(('.pdf', '.docx', '.txt')):
                    document_info = {
                        's3_key': obj['Key'],
                        'document_name': obj['Key'].split('/')[-1],
                        'effective_date': date_folder['effective_date'],
                        'file_size': obj['Size'],
                        'last_modified': obj['LastModified']
                    }
                    documents.append(document_info)
            
            # Process documents in parallel
            processed_documents = []
            for doc_info in documents:
                try:
                    processed_doc = self.process_single_document(doc_info)
                    processed_documents.append(processed_doc)
                except Exception as e:
                    logger.error(f"Error processing document {doc_info['s3_key']}: {e}")
                    continue
            
            return processed_documents
            
        except Exception as e:
            logger.error(f"Error processing standards batch: {e}")
            raise
    
    def process_single_document(self, doc_info: Dict[str, Any]) -> Dict[str, Any]:
        """Process a single standards document through the MCP pipeline."""
        
        # Step 1: Extract text from document
        document_text = self.document_processor.extract_text_from_s3(
            doc_info['s3_key'], 
            CONFIG['bucket_name']
        )
        
        # Step 2: Classify document type and categories
        classification = self.category_classifier.classify_document(
            document_text, 
            doc_info['document_name']
        )
        
        # Step 3: Generate embeddings for chunks
        chunks = self.document_processor.chunk_document(document_text)
        embeddings = self.embedding_worker.generate_chunk_embeddings(chunks)
        
        # Step 4: Prepare result
        processed_doc = {
            **doc_info,
            'document_type': classification['document_type'],
            'categories': classification['categories'],
            'confidence_score': classification['confidence'],
            'chunks': [
                {
                    'text': chunk,
                    'embedding': embedding,
                    'chunk_index': i
                }
                for i, (chunk, embedding) in enumerate(zip(chunks, embeddings))
            ],
            'processing_status': 'completed'
        }
        
        return processed_doc
    
    def get_point_in_time_standards(self, review_date: date) -> List[Dict[str, Any]]:
        """Get standards that were effective at a specific point in time."""
        
        # Find the most recent standards folder before or on the review date
        date_folders = self.scan_standards_folders(end_date=review_date)
        
        if not date_folders:
            raise ValueError(f"No standards found for review date: {review_date}")
        
        # Get the most recent folder
        latest_folder = date_folders[-1]
        
        logger.info(f"Using standards from {latest_folder['folder_name']} for review date {review_date}")
        
        # Process the standards batch
        return self.process_standards_batch(latest_folder)
```

### **Phase 3: Database Integration**

#### **PostgreSQL Database Manager**
```python
# src/backend/database/postgres_manager.py
"""
PostgreSQL Database Manager for Point-in-Time Standards

This module manages the PostgreSQL database operations for standards documents,
embeddings, and point-in-time queries.
"""

import psycopg2
import psycopg2.extras
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import date
from backend.core.config import CONFIG

logger = logging.getLogger(__name__)

class PostgreSQLManager:
    """Manages PostgreSQL operations for standards and embeddings."""
    
    def __init__(self, connection_string: str):
        self.connection_string = connection_string
        self.connection = None
    
    def connect(self):
        """Establish database connection."""
        try:
            self.connection = psycopg2.connect(self.connection_string)
            self.connection.autocommit = False
            logger.info("Connected to PostgreSQL database")
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    def disconnect(self):
        """Close database connection."""
        if self.connection:
            self.connection.close()
            logger.info("Disconnected from PostgreSQL database")
    
    def store_standards_document(self, document_data: Dict[str, Any]) -> int:
        """Store a standards document in the database."""
        
        try:
            with self.connection.cursor() as cursor:
                # Insert document record
                cursor.execute("""
                    INSERT INTO standards_documents 
                    (s3_key, document_name, document_type, effective_date, file_size, content_hash, processing_status)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                """, (
                    document_data['s3_key'],
                    document_data['document_name'],
                    document_data['document_type'],
                    document_data['effective_date'],
                    document_data['file_size'],
                    document_data.get('content_hash', ''),
                    document_data['processing_status']
                ))
                
                document_id = cursor.fetchone()[0]
                
                # Insert document chunks with embeddings
                for chunk in document_data['chunks']:
                    cursor.execute("""
                        INSERT INTO document_chunks 
                        (document_id, chunk_index, chunk_text, chunk_embedding, chunk_metadata)
                        VALUES (%s, %s, %s, %s, %s)
                    """, (
                        document_id,
                        chunk['chunk_index'],
                        chunk['text'],
                        chunk['embedding'],
                        json.dumps(chunk.get('metadata', {}))
                    ))
                
                # Insert category relationships
                for category in document_data['categories']:
                    cursor.execute("""
                        INSERT INTO document_categories 
                        (document_id, category_id, confidence_score)
                        VALUES (%s, %s, %s)
                    """, (
                        document_id,
                        category['category_id'],
                        category.get('confidence', 1.0)
                    ))
                
                self.connection.commit()
                logger.info(f"Stored document {document_id}: {document_data['document_name']}")
                return document_id
                
        except Exception as e:
            self.connection.rollback()
            logger.error(f"Error storing document: {e}")
            raise
    
    def search_similar_standards(self, query_embedding: List[float], review_date: date, 
                                document_types: Optional[List[str]] = None, 
                                categories: Optional[List[str]] = None, 
                                limit: int = 10) -> List[Dict[str, Any]]:
        """Search for similar standards at a specific point in time."""
        
        try:
            with self.connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
                
                # Build the query with point-in-time logic
                query = """
                    SELECT 
                        sd.id,
                        sd.document_name,
                        sd.document_type,
                        sd.effective_date,
                        dc.chunk_text,
                        dc.chunk_embedding,
                        dc.chunk_index,
                        (dc.chunk_embedding <=> %s) as similarity_score
                    FROM standards_documents sd
                    JOIN document_chunks dc ON sd.id = dc.document_id
                    WHERE sd.effective_date <= %s
                """
                
                params = [query_embedding, review_date]
                
                # Add document type filter
                if document_types:
                    placeholders = ','.join(['%s'] * len(document_types))
                    query += f" AND sd.document_type IN ({placeholders})"
                    params.extend(document_types)
                
                # Add category filter
                if categories:
                    query += """
                        AND EXISTS (
                            SELECT 1 FROM document_categories dc2
                            JOIN categories c ON dc2.category_id = c.id
                            WHERE dc2.document_id = sd.id 
                            AND c.name = ANY(%s)
                            AND c.effective_date <= %s
                        )
                    """
                    params.extend([categories, review_date])
                
                # Order by similarity and limit results
                query += """
                    ORDER BY similarity_score ASC
                    LIMIT %s
                """
                params.append(limit)
                
                cursor.execute(query, params)
                results = cursor.fetchall()
                
                # Convert to list of dictionaries
                return [dict(row) for row in results]
                
        except Exception as e:
            logger.error(f"Error searching similar standards: {e}")
            raise
    
    def get_standards_summary(self, review_date: date) -> Dict[str, Any]:
        """Get a summary of standards available at a specific point in time."""
        
        try:
            with self.connection.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cursor:
                
                cursor.execute("""
                    SELECT 
                        document_type,
                        COUNT(*) as document_count,
                        COUNT(DISTINCT effective_date) as date_count,
                        MIN(effective_date) as earliest_date,
                        MAX(effective_date) as latest_date
                    FROM standards_documents
                    WHERE effective_date <= %s
                    GROUP BY document_type
                """, [review_date])
                
                type_summary = cursor.fetchall()
                
                cursor.execute("""
                    SELECT 
                        c.name as category_name,
                        COUNT(DISTINCT sd.id) as document_count
                    FROM categories c
                    JOIN document_categories dc ON c.id = dc.category_id
                    JOIN standards_documents sd ON dc.document_id = sd.id
                    WHERE c.effective_date <= %s AND sd.effective_date <= %s
                    GROUP BY c.name
                    ORDER BY document_count DESC
                """, [review_date, review_date])
                
                category_summary = cursor.fetchall()
                
                return {
                    'review_date': review_date,
                    'document_types': [dict(row) for row in type_summary],
                    'categories': [dict(row) for row in category_summary]
                }
                
        except Exception as e:
            logger.error(f"Error getting standards summary: {e}")
            raise
```

### **Phase 4: MCP Integration**

#### **Standards Retrieval Worker**
```python
# src/backend/mcp/workers/standards_retrieval_worker.py
"""
Standards Retrieval Worker for MCP Architecture

This worker handles point-in-time standards retrieval and similarity search
for QA document processing.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import date
from backend.core.aws_llm_manager import AWSSecurityLLMManager
from backend.database.postgres_manager import PostgreSQLManager

logger = logging.getLogger(__name__)

class StandardsRetrievalWorker:
    """Worker for retrieving relevant standards at specific points in time."""
    
    def __init__(self, db_manager: PostgreSQLManager):
        self.db_manager = db_manager
        self.llm_manager = AWSSecurityLLMManager()
    
    def retrieve_relevant_standards(self, query_text: str, review_date: date,
                                  document_types: Optional[List[str]] = None,
                                  categories: Optional[List[str]] = None,
                                  max_results: int = 10) -> List[Dict[str, Any]]:
        """Retrieve relevant standards for a query at a specific point in time."""
        
        try:
            # Generate embedding for the query
            query_embedding = self.llm_manager.get_embedding(query_text)
            
            # Search for similar standards
            similar_standards = self.db_manager.search_similar_standards(
                query_embedding=query_embedding,
                review_date=review_date,
                document_types=document_types,
                categories=categories,
                limit=max_results
            )
            
            # Enhance results with relevance scoring
            enhanced_results = []
            for standard in similar_standards:
                enhanced_standard = {
                    **standard,
                    'relevance_score': 1.0 - standard['similarity_score'],  # Convert distance to similarity
                    'retrieval_date': date.today(),
                    'query_text': query_text
                }
                enhanced_results.append(enhanced_standard)
            
            logger.info(f"Retrieved {len(enhanced_results)} relevant standards for review date {review_date}")
            return enhanced_results
            
        except Exception as e:
            logger.error(f"Error retrieving relevant standards: {e}")
            raise
    
    def get_standards_context(self, review_date: date, 
                            document_types: Optional[List[str]] = None) -> str:
        """Get a contextual summary of standards available at a specific point in time."""
        
        try:
            # Get standards summary
            summary = self.db_manager.get_standards_summary(review_date)
            
            # Format context string
            context_parts = [f"Standards available as of {review_date}:"]
            
            for doc_type in summary['document_types']:
                context_parts.append(
                    f"- {doc_type['document_type']}: {doc_type['document_count']} documents "
                    f"(effective dates: {doc_type['earliest_date']} to {doc_type['latest_date']})"
                )
            
            if summary['categories']:
                context_parts.append("\nKey categories:")
                for category in summary['categories'][:5]:  # Top 5 categories
                    context_parts.append(f"- {category['category_name']}: {category['document_count']} documents")
            
            return "\n".join(context_parts)
            
        except Exception as e:
            logger.error(f"Error getting standards context: {e}")
            raise
```

---

## 🔧 **Configuration Updates**

### **Add to CONFIG**
```python
# Add to src/backend/core/config.py
CONFIG.update({
    # Standards Processing Configuration
    "standards_folder": "standards",
    "standards_processing": {
        "chunk_size": 1000,
        "chunk_overlap": 200,
        "max_chunks_per_document": 50,
        "supported_formats": [".pdf", ".docx", ".txt"]
    },
    
    # Database Configuration
    "database": {
        "postgres_url": os.getenv("DATABASE_URL", "postgresql://user:password@localhost:5432/database"),
        "vector_dimensions": 1024,  # Titan v2
        "connection_pool_size": 10,
        "max_connections": 20
    }
})
```

### **Environment Variables**
```bash
# Add to src/backend/config/credentials.env
# Database Configuration
DATABASE_URL=postgresql://user:password@localhost:5432/database

# Standards Processing
STANDARDS_FOLDER=standards
CHUNK_SIZE=1000
CHUNK_OVERLAP=200
```

---

## 🚀 **Implementation Status**

### **✅ Ready to Implement:**
1. **Database Schema**: PostgreSQL with vector extensions
2. **S3 Integration**: Date-based folder scanning
3. **MCP Architecture**: Standards processing coordinator
4. **Point-in-Time Logic**: Date-aware standards retrieval
5. **Embedding Pipeline**: Real Bedrock integration

### **🔧 Required Components:**
1. **PostgreSQL Setup**: Database with vector extensions
2. **Standards Processing**: S3 document processing pipeline
3. **MCP Integration**: Standards retrieval worker
4. **QA Integration**: Point-in-time standards in QA process

### **📋 Next Steps:**
1. **Set up PostgreSQL** with vector extensions
2. **Implement standards processing** coordinator
3. **Create database manager** for PostgreSQL operations
4. **Integrate with QA demo** for point-in-time standards
5. **Test with your S3 standards** folder structure

---

## 🎯 **Plug-and-Play Readiness**

### **Current Status: ❌ Not Ready**
- Database layer is placeholder only
- No S3 standards processing
- No point-in-time logic
- Embedding pipeline is placeholder

### **After Implementation: ✅ Ready**
- **MCP-style processing** of S3 standards folders
- **PostgreSQL multi-index** with dates and categories
- **Point-in-time benchmarks** for accurate reviews
- **Real Bedrock embeddings** for similarity search
- **Complete audit trail** of standards evolution

---

*This system will provide the exact point-in-time benchmark functionality you need for Model Risk Governance, ensuring reviews use the standards that were actually in effect at the time of the review.*
