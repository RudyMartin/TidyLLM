# 🔧 AWS & Database Technical Details - Deep Dive

## Overview
This document provides a comprehensive technical analysis of how AWS credentials, S3 storage, Bedrock services, and database connections are configured, stored, and used throughout the VectorQA Sage system.

---

## 🔐 **Credential Storage & Management**

### **1. Primary Credential Location**
**File:** `src/backend/config/credentials.env`
```bash
# AWS Credentials
AWS_ACCESS_KEY_ID=your_aws_access_key_here
AWS_SECRET_ACCESS_KEY=your_aws_secret_key_here
AWS_REGION=us-east-1

# Amazon Bedrock Configuration
BEDROCK_MODEL_ID=amazon.titan-embed-text-v2:0

# Database Connection
DATABASE_URL=your_database_connection_string_here
```

### **2. Credential Manager Architecture**
**File:** `src/backend/config/credential_manager.py`

#### **Loading Process:**
```python
class CredentialManager:
    def __init__(self, env_file: Optional[str] = None):
        self.env_file = env_file or "config/credentials/credentials.env"
        self._load_credentials()
    
    def _load_credentials(self):
        """Load credentials from environment file."""
        env_path = Path(self.env_file)
        if env_path.exists():
            load_dotenv(self.env_file)
        else:
            logger.warning(f"Credentials file not found: {self.env_file}")
```

#### **Credential Retrieval Methods:**
```python
def get_aws_credentials(self) -> Dict[str, str]:
    return {
        "access_key_id": os.getenv("AWS_ACCESS_KEY_ID"),
        "secret_access_key": os.getenv("AWS_SECRET_ACCESS_KEY"),
        "region": os.getenv("AWS_REGION", "us-east-1")
    }

def get_database_config(self) -> Dict[str, str]:
    return {
        "url": os.getenv("DATABASE_URL")
    }
```

### **3. Security Measures**
- **Git Ignored:** `credentials.env` is in `.gitignore`
- **Template File:** `credentials_template.env` provided for setup
- **Environment Variables:** Fallback to system environment variables
- **Validation:** Credential validation methods available

---

## ☁️ **AWS Configuration & Usage**

### **1. Core Configuration**
**File:** `src/backend/core/config.py`

#### **AWS Configuration Constants:**
```python
CONFIG = {
    "bucket_name": "sagemaker-us-east-1-XXXXXXXXXXXX",
    "region_name": "us-east-1",
    "default_model": "amazon.titan-embed-text-v2:0",
    "embedding_models": {
        "amazon.titan-embed-text-v1": 768,
        "amazon.titan-embed-text-v2:0": 1024,
        "cohere.embed-english-v3": 1024,
        "anthropic.claude-v2": 1536
    }
}
```

#### **AWS Client Initialization:**
```python
try:
    s3_client = boto3.client("s3", region_name=CONFIG["region_name"])
    bedrock_client = boto3.client("bedrock-runtime", region_name=CONFIG["region_name"])
except Exception as e:
    print(f"Warning: Could not initialize AWS clients: {e}")
    s3_client = None
    bedrock_client = None
```

### **2. S3 Usage Patterns**

#### **File Upload Operations:**
**File:** `src/backend/core/extraction_helper.py`
```python
def extract_text_from_pdf_page_s3(page_key: str, next_page_key: str = None, bucket: str = None) -> Dict:
    bucket = bucket or CONFIG["bucket_name"]
    response = s3_client.get_object(Bucket=bucket, Key=page_key)
    pdf_file = response["Body"].read()
    # Process PDF content...
```

#### **List Operations:**
```python
def list_s3_pages(prefix: str, bucket: str = None) -> List[str]:
    bucket = bucket or CONFIG["bucket_name"]
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
    # Process listing results...
```

#### **Report Export to S3:**
**File:** `src/backend/core/report_export.py`
```python
def optionally_upload_to_s3(content_bytes, filename, content_type="application/pdf"):
    bucket = CONFIG["bucket_name"]
    s3_path = f"reports/{filename}"
    s3 = boto3.client("s3")
    s3.put_object(Bucket=bucket, Key=s3_path, Body=content_bytes, ContentType=content_type)
    return f"s3://{bucket}/{s3_path}"
```

### **3. Bedrock Integration**

#### **Model Configuration:**
```python
MODEL_OPTIONS = {
    "titan_v1": {"id": "amazon.titan-embed-text-v1", "dimensions": 768},
    "titan_v2": {"id": "amazon.titan-embed-text-v2:0", "dimensions": 1024},
    "cohere": {"id": "cohere.embed-english-v3", "dimensions": None},
    "anthropic": {"id": "anthropic.claude-v2", "dimensions": None}
}
```

#### **Bedrock Client Usage:**
```python
# Bedrock client is initialized globally
bedrock_client = boto3.client("bedrock-runtime", region_name=CONFIG["region_name"])

# Usage in embedding generation
def generate_embeddings_bedrock(text: str, model_id: str = None):
    model_id = model_id or CONFIG["default_model"]
    # Use bedrock_client for embedding generation
```

---

## 🗄️ **Database Configuration & Status**

### **1. Current Database Status**
**Status:** **NOT IMPLEMENTED** - Placeholder structure only

#### **Database Layer Structure:**
```
database/
├── CLAUDE.md          # Database documentation
├── README.md          # Database overview
├── schemas/           # (Empty - placeholder)
├── migrations/        # (Empty - placeholder)
└── scripts/           # (Empty - placeholder)
```

#### **Database Configuration:**
**File:** `src/backend/config/credentials.env`
```bash
# Database (if using one)
DATABASE_URL=your_database_connection_string_here
```

### **2. Database Integration Points**

#### **Credential Manager Support:**
```python
def get_database_config(self) -> Dict[str, str]:
    """Get database configuration."""
    return {
        "url": os.getenv("DATABASE_URL")
    }
```

#### **Planned Database Usage:**
**File:** `QA_DEMO_README.md`
```markdown
### **Integration Points**
1. **PostgreSQL Database**: Store processing results
2. **Admin Interface**: Folder management and user administration
3. **Notification System**: Email/SMS alerts for completed reports
4. **Analytics Dashboard**: Processing metrics and insights
```

### **3. Database Options Analysis**
**File:** `database/CLAUDE.md`

#### **Recommended Options:**
1. **PostgreSQL**: Robust relational database for complex queries
2. **MongoDB**: Document database for flexible schema
3. **SQLite**: Lightweight database for development/testing
4. **Vector Database**: Pinecone, Weaviate, or Qdrant for embeddings
5. **Hybrid Approach**: Multiple databases for different use cases

---

## 🔄 **Configuration Flow**

### **1. Application Startup Flow**
```mermaid
flowchart TD
    A[Application Starts] --> B[Load credentials.env]
    B --> C[Initialize CredentialManager]
    C --> D[Load AWS Configuration]
    D --> E[Create S3 Client]
    D --> F[Create Bedrock Client]
    E --> G[Initialize CONFIG Dictionary]
    F --> G
    G --> H[Application Ready]
    
    style A fill:#e1f5fe
    style B fill:#fff3e0
    style C fill:#fff3e0
    style D fill:#fff3e0
    style E fill:#e8f5e8
    style F fill:#e8f5e8
    style G fill:#e8f5e8
    style H fill:#e8f5e8
```

### **2. Credential Loading Process**
```mermaid
sequenceDiagram
    participant App as Application
    participant CM as CredentialManager
    participant Env as Environment
    participant AWS as AWS Services
    
    App->>CM: Initialize CredentialManager
    CM->>Env: Load credentials.env
    Env-->>CM: Environment variables
    CM->>CM: Validate credentials
    CM-->>App: Credential status
    App->>AWS: Initialize clients
    AWS-->>App: S3/Bedrock clients
```

---

## 🛡️ **Security Implementation**

### **1. Credential Protection**
- **File-based storage**: `credentials.env` (git-ignored)
- **Environment variables**: Fallback mechanism
- **Template files**: Safe examples provided
- **Validation**: Credential validation methods

### **2. AWS Security**
- **IAM Roles**: Proper AWS permissions
- **Region-specific**: All services in `us-east-1`
- **Error handling**: Graceful failure if credentials missing
- **Client validation**: Check client availability before use

### **3. Database Security** (Future)
- **Connection strings**: Environment variable storage
- **Encryption**: Database connection encryption
- **Access control**: Role-based database access
- **Audit logging**: Track database access and changes

---

## 🔧 **Technical Implementation Details**

### **1. AWS Client Usage Patterns**

#### **S3 Operations:**
```python
# File retrieval
response = s3_client.get_object(Bucket=bucket, Key=page_key)
pdf_file = response["Body"].read()

# File listing
response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")

# File upload
s3_client.put_object(Bucket=bucket, Key=s3_path, Body=content_bytes, ContentType=content_type)
```

#### **Bedrock Operations:**
```python
# Embedding generation
response = bedrock_client.invoke_model(
    modelId=model_id,
    body=json.dumps({"inputText": text})
)
```

### **2. Configuration Management**

#### **Centralized Configuration:**
```python
CONFIG = {
    "bucket_name": "sagemaker-us-east-1-XXXXXXXXXXXX",
    "prefix": "dev",
    "region_name": "us-east-1",
    "default_model": "amazon.titan-embed-text-v2:0",
    # ... other configuration
}
```

#### **Environment-Specific Loading:**
```python
def _load_credentials(self):
    env_path = Path(self.env_file)
    if env_path.exists():
        load_dotenv(self.env_file)
    else:
        logger.warning(f"Credentials file not found: {self.env_file}")
        logger.info("Using system environment variables")
```

---

## 📊 **Current Status Summary**

### **✅ Implemented:**
- **AWS S3 Integration**: Full file storage and retrieval
- **AWS Bedrock Integration**: Embedding generation
- **Credential Management**: Secure credential loading
- **Configuration System**: Centralized configuration management
- **Error Handling**: Graceful failure handling

### **🚧 Partially Implemented:**
- **Database Layer**: Structure created, implementation pending
- **Database Configuration**: Credential support ready
- **Database Integration**: Planned but not implemented

### **📋 Planned:**
- **PostgreSQL Integration**: For processing results storage
- **Database Schemas**: For structured data organization
- **Database Migrations**: For schema evolution
- **Database Utilities**: For maintenance and operations

---

## 🎯 **Next Steps for Database Implementation**

### **1. Immediate Actions:**
1. **Choose Database**: PostgreSQL recommended for production
2. **Design Schema**: Document processing results schema
3. **Create Models**: Database models for QA results
4. **Implement Connection**: Database connection management

### **2. Implementation Plan:**
1. **Setup Database**: Install and configure PostgreSQL
2. **Create Schemas**: Design database tables
3. **Implement Models**: Create database models
4. **Add Migrations**: Database migration system
5. **Update Application**: Integrate database operations

### **3. Configuration Updates:**
```bash
# Update credentials.env
DATABASE_URL=postgresql://user:password@localhost:5432/database
```

---

*This technical analysis provides complete visibility into AWS and database configuration, storage, and usage patterns throughout the VectorQA Sage system.*
