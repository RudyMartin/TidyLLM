# Streamlit Setup Notes

> 📖 **More Info**: For general project documentation, see [README.md](../README.md) and [docs/](../docs/) directory.

## Issues Encountered and Solutions

### 1. Conda Environment Python Version Mismatch

**Problem**: The `py311` conda environment was pointing to Python 2.7 instead of Python 3.11.

**Symptoms**:
- `conda activate py311 && which python` returned `/usr/local/bin/python`
- `python --version` showed `Python 2.7.13`
- Streamlit import failed with `ImportError: No module named streamlit`

**Solution**:
- Use the full path to the conda environment's Python executable
- Path: `/Users/rudy/opt/anaconda3/envs/py311/bin/python`
- Verify with: `/Users/rudy/opt/anaconda3/envs/py311/bin/python --version`

### 2. Streamlit Onboarding Email Prompt

**Problem**: Streamlit was waiting for user input during first-time setup, asking for an email address.

**Symptoms**:
- Streamlit process appeared to hang
- Log showed: "👋 Welcome to Streamlit! If you'd like to receive helpful onboarding emails..."
- Process waiting for `Email:` input

**Solution**:
- Use `echo ""` to provide empty input to skip the onboarding
- Command: `echo "" | /path/to/python -m streamlit run app.py`

### 3. Virtual Environment vs Conda Environment Conflicts

**Problem**: The launcher was using `sys.executable` which pointed to a `.venv` where streamlit wasn't installed, even when a conda environment was active.

**Symptoms**:
- `ModuleNotFoundError: No module named 'streamlit'`
- Launcher using wrong Python executable
- Streamlit not discovering network interfaces

**Solution**:
- Check `os.getenv('CONDA_DEFAULT_ENV')` to detect conda environment
- Use `os.getenv('CONDA_PREFIX')` to get the conda environment path
- Use the full path to the conda environment's Python executable

## Working Launcher Configuration

### For `start_simple.py`:

```python
# If we're in base, try to use py311
if conda_env == "base":
    print("🔄 Switching to py311 environment for streamlit...")
    try:
        # Use the full path to the py311 Python executable
        py311_python = "/Users/rudy/opt/anaconda3/envs/py311/bin/python"
        if os.path.exists(py311_python):
            # Use echo to provide empty input for streamlit onboarding
            cmd = f'echo "" | {py311_python} -m streamlit run {app_file} --server.port 8555 --server.address 0.0.0.0'
            subprocess.run(cmd, shell=True)
            return
        else:
            print("❌ py311 Python not found at expected location")
            return
    except Exception as e:
        print(f"❌ Error launching with py311: {e}")
        return
```

## Verification Steps

### 1. Check Python Version in Conda Environment
```bash
conda activate py311
which python
python --version
```

### 2. Verify Streamlit Installation
```bash
/Users/rudy/opt/anaconda3/envs/py311/bin/python -c "import streamlit; print('Streamlit version:', streamlit.__version__)"
```

### 3. Test Streamlit Launch
```bash
echo "" | /Users/rudy/opt/anaconda3/envs/py311/bin/python -m streamlit run simple.py --server.port 8555 --server.address 0.0.0.0
```

### 4. Check Server Status
```bash
lsof -i :8555
curl -s http://localhost:8555 | head -5
```

## Troubleshooting Commands

### Kill All Streamlit Processes
```bash
pkill -f streamlit
```

### Check Running Processes
```bash
ps aux | grep streamlit | grep -v grep
```

### Check Port Usage
```bash
lsof -i :8555
```

### Check Network Interfaces
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

## Environment Setup Checklist

- [ ] Verify conda environment exists: `conda info --envs`
- [ ] Check Python version in environment: `conda activate py311 && python --version`
- [ ] Install streamlit: `conda activate py311 && pip install streamlit`
- [ ] Test streamlit import: `python -c "import streamlit; print(streamlit.__version__)"`
- [ ] Configure streamlit (optional): `mkdir -p ~/.streamlit && echo "global.developmentMode = false" > ~/.streamlit/config.toml`

## Common Error Messages and Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| `No module named streamlit` | Wrong Python executable | Use full path to conda environment Python |
| `conda run` fails | Environment not found | Check `conda info --envs` and use full path |
| Streamlit hangs | Onboarding email prompt | Use `echo ""` to provide empty input |
| Port not listening | Process not started | Check logs and verify Python path |
| Network not accessible | Wrong server address | Use `--server.address 0.0.0.0` |

## Notes for Future Development

1. **Always use full paths** to conda environment Python executables
2. **Handle streamlit onboarding** with `echo ""` for automated deployment
3. **Check conda environment status** before launching
4. **Verify port availability** before starting new instances
5. **Use `nohup`** for background processes to avoid tty issues
6. **Monitor logs** for debugging streamlit startup issues
