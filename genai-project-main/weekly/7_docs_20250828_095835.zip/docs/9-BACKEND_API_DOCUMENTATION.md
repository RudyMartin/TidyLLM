# Backend API Documentation

## 🎯 Overview

This document provides comprehensive API documentation for the backend components of the MVR demo system.

---

## 🔧 Core Components

### **DocumentProcessingOrchestrator**

**Purpose**: Unified orchestrator for processing multiple document types with dedicated workers.

**Location**: `src/backend/mcp/orchestrators/document_processing_orchestrator.py`

#### **Constructor**
```python
DocumentProcessingOrchestrator(mode: ProcessingMode = ProcessingMode.SIMPLE)
```

**Parameters**:
- `mode`: Processing complexity level (SIMPLE, ENHANCED, ADVANCED)

#### **Methods**

##### **process_document(file_path: str, document_type: Optional[str] = None)**
Process a single document file.

**Parameters**:
- `file_path`: Path to the document file
- `document_type`: Optional document type override

**Returns**:
```python
{
    'success': bool,
    'data': Dict[str, Any],
    'document_type': str,
    'worker_used': str,
    'processing_time': str,
    'error': Optional[str]
}
```

##### **process_multiple_documents(file_paths: List[str])**
Process multiple document files.

**Parameters**:
- `file_paths`: List of file paths to process

**Returns**:
```python
{
    'success': bool,
    'results': List[Dict],
    'summary': {
        'total_files': int,
        'successful': int,
        'failed': int,
        'processing_time': str,
        'orchestrator_id': str
    }
}
```

##### **detect_document_type(file_path: str)**
Detect the document type based on file extension.

**Parameters**:
- `file_path`: Path to the document file

**Returns**: Document type string (yaml, json, pdf, csv, excel, word, xml, text, markdown)

##### **validate_document(file_path: str)**
Validate document without processing.

**Parameters**:
- `file_path`: Path to the document file

**Returns**:
```python
{
    'valid': bool,
    'file_path': str,
    'document_type': str,
    'file_size': int,
    'worker_available': bool,
    'processing_time': str,
    'orchestrator_id': str,
    'error': Optional[str]
}
```

##### **get_processing_stats()**
Get processing statistics.

**Returns**:
```python
{
    'orchestrator_id': str,
    'mode': str,
    'available_workers': List[str],
    'stats': {
        'files_processed': int,
        'successful_parses': int,
        'failed_parses': int,
        'by_type': Dict[str, int]
    },
    'timestamp': str
}
```

##### **get_supported_types()**
Get list of supported document types.

**Returns**: List of supported document type strings

##### **check_worker_availability()**
Check availability of all workers.

**Returns**: Dictionary mapping document types to availability status

##### **get_workers()**
Get all available workers.

**Returns**: Dictionary of worker instances

---

### **YAMLProcessingWorker**

**Purpose**: Dedicated worker for YAML file processing with library detection and fallback.

**Location**: `src/backend/mcp/workers/yaml_processing_worker.py`

#### **Constructor**
```python
YAMLProcessingWorker()
```

#### **Methods**

##### **process_document(file_path: str)**
Process a YAML document file.

**Parameters**:
- `file_path`: Path to the YAML file

**Returns**:
```python
{
    'success': bool,
    'data': Dict[str, Any],
    'document_type': 'yaml',
    'worker_used': 'yaml worker',
    'processing_time': str,
    'error': Optional[str]
}
```

##### **load_yaml_file(file_path: str)**
Load YAML file with error handling.

**Parameters**:
- `file_path`: Path to the YAML file

**Returns**: Parsed YAML data or None on error

---

### **ExtractionHelper**

**Purpose**: Wrapper class for extraction helper functions.

**Location**: `src/backend/core/extraction_helper.py`

#### **Constructor**
```python
ExtractionHelper()
```

#### **Methods**

##### **clean_text(text: str)**
Clean extracted text using the clean_text function.

**Parameters**:
- `text`: Raw text to clean

**Returns**: Cleaned text string

##### **smart_chunking(text: str, max_words: int = 200)**
Perform smart chunking on text.

**Parameters**:
- `text`: Text to chunk
- `max_words`: Maximum words per chunk

**Returns**: List of text chunks

##### **validate_page_continuity(text_current: str, text_next: str)**
Validate page continuity between two text segments.

**Parameters**:
- `text_current`: Current page text
- `text_next`: Next page text

**Returns**: Boolean indicating continuity

---

### **DataMart**

**Purpose**: Simple DataMart wrapper for easier access to DataMart functionality.

**Location**: `src/backend/core/datamart_numpy_substitution.py`

#### **Constructor**
```python
DataMart(mode: DataMartMode = DataMartMode.SIMPLE)
```

**Parameters**:
- `mode`: DataMart complexity mode (SIMPLE, ENHANCED, ADVANCED)

#### **Methods**

##### **initialize()**
Initialize DataMart.

**Returns**: Boolean indicating success

##### **add_data(data: Dict[str, Any])**
Add analysis data to DataMart.

**Parameters**:
- `data`: Analysis data dictionary

**Returns**: Boolean indicating success

##### **get_metrics()**
Get DataMart performance metrics.

**Returns**:
```python
{
    'buffer_size': int,
    'mode': str,
    'status': str
}
```

##### **get_numpy_substitute()**
Get NumPy substitute for calculations.

**Returns**: NumpySubstitute instance

---

## 📊 Supported Document Types

### **YAML (.yaml, .yml)**
- **Worker**: YAMLProcessingWorker
- **Features**: Library detection, fallback support
- **Output**: Parsed YAML data structure

### **JSON (.json)**
- **Worker**: JSONProcessingWorker
- **Features**: JSON parsing and validation
- **Output**: Parsed JSON data structure

### **CSV (.csv)**
- **Worker**: CSVProcessingWorker
- **Features**: Pandas-free CSV processing
- **Output**: Structured CSV data

### **Text (.txt)**
- **Worker**: TextProcessingWorker
- **Features**: Text analysis, cleaning
- **Output**: Analyzed text data

### **Markdown (.md)**
- **Worker**: MarkdownProcessingWorker
- **Features**: Markdown parsing, text cleaning
- **Output**: Parsed markdown content

### **PDF (.pdf)**
- **Worker**: PDFProcessingWorker
- **Features**: PDF text extraction
- **Output**: Extracted text content

### **Excel (.xlsx, .xls)**
- **Worker**: ExcelProcessingWorker
- **Features**: Excel file processing
- **Output**: Structured spreadsheet data

### **Word (.docx, .doc)**
- **Worker**: WordProcessingWorker
- **Features**: Word document processing
- **Output**: Extracted document content

### **XML (.xml)**
- **Worker**: XMLProcessingWorker
- **Features**: XML parsing and validation
- **Output**: Parsed XML structure

---

## 🔄 Processing Flow

### **1. Document Upload**
```
File Upload → DocumentProcessingOrchestrator → Worker Selection → Processing → Result
```

### **2. Worker Selection**
```
File Extension → Document Type Detection → Worker Availability Check → Worker Assignment
```

### **3. Error Handling**
```
Processing Error → Error Capture → Graceful Fallback → User Feedback
```

---

## ⚡ Performance Characteristics

### **Processing Times**
- **YAML**: ~0.033 seconds
- **Multiple files**: ~0.008 seconds per file
- **Large documents**: Linear scaling with file size

### **Memory Usage**
- **Per worker**: ~1-5 MB
- **Orchestrator**: ~10-20 MB
- **Total system**: ~50-100 MB

### **Scalability**
- **Concurrent processing**: Supported
- **File size limits**: Configurable
- **Worker pool**: Expandable

---

## 🛠️ Error Handling

### **Common Error Types**
1. **File not found**: `Document not found: {file_path}`
2. **Unsupported type**: `Unsupported document type: {type}`
3. **Processing error**: `Failed to process document: {error}`
4. **Worker unavailable**: `Worker not available for type: {type}`

### **Error Response Format**
```python
{
    'success': False,
    'error': 'Error description',
    'file_path': str,
    'processing_time': str,
    'orchestrator_id': str
}
```

---

## 🔧 Configuration

### **Environment Variables**
- `PYTHONPATH`: Include `src/backend` for imports
- `LOG_LEVEL`: Set logging level (DEBUG, INFO, WARNING, ERROR)

### **Processing Modes**
- **SIMPLE**: Basic parsing and extraction
- **ENHANCED**: Advanced features and analysis
- **ADVANCED**: Full capabilities with AI/ML

---

## 📝 Usage Examples

### **Basic Document Processing**
```python
from src.backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator

orchestrator = DocumentProcessingOrchestrator()
result = orchestrator.process_document('document.yaml')

if result['success']:
    print(f"Processed {result['document_type']} document")
    print(f"Data: {result['data']}")
else:
    print(f"Error: {result['error']}")
```

### **Multiple Document Processing**
```python
files = ['doc1.yaml', 'doc2.json', 'doc3.csv']
results = orchestrator.process_multiple_documents(files)

print(f"Processed {results['summary']['successful']} of {results['summary']['total_files']} files")
```

### **Worker Availability Check**
```python
availability = orchestrator.check_worker_availability()
for doc_type, available in availability.items():
    status = "✅" if available else "❌"
    print(f"{status} {doc_type}")
```

---

## 🚀 Production Deployment

### **Requirements**
- Python 3.11+
- Virtual environment
- Required dependencies (see requirements files)

### **Setup**
1. Clone repository
2. Create virtual environment: `python -m venv py311`
3. Activate environment: `source py311/bin/activate`
4. Install dependencies: `pip install -r requirements_streamlit.txt`
5. Test setup: `python -c "from src.backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator; print('Setup successful')"`

### **Monitoring**
- Processing statistics via `get_processing_stats()`
- Worker availability via `check_worker_availability()`
- Error logging and monitoring

---

*Last Updated: March 2025*
*Version: 1.0*
