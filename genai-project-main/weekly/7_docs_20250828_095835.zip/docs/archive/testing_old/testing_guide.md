# 🧪 Testing Guide - Manual Testing and Reports

## 🎯 Overview

This guide shows you how to manually test the risk management system and where to find all the generated reports and logs.

## 🔧 How to Run Manual Tests

### Quick Start
```bash
# Run the manual test script
python3 manual_test_scenarios.py
```

### Test Modes Available

1. **Interactive Mode** - Choose specific scenarios to test
2. **Run All Scenarios** - Test all 5 predefined scenarios
3. **Single Scenario** - Test just one specific scenario

### Available Test Scenarios

| # | Scenario | Risk Category | Severity | Description |
|---|----------|---------------|----------|-------------|
| 1 | Model Performance Degradation | Model Risk | High | Credit scoring model accuracy dropped from 95% to 78% |
| 2 | VaR Model Breach | Market Risk | Critical | Value at Risk exceeded limits during market volatility |
| 3 | Data Quality Issues | Operational Risk | Medium | Training data completeness dropped below 90% threshold |
| 4 | Credit Portfolio Concentration | Credit Risk | High | Portfolio concentration in high-risk sectors exceeded limits |
| 5 | Real-time Fraud Detection Failure | Operational Risk | Critical | Fraud detection model stopped processing transactions |

## 📊 Where Reports Are Generated

### Test Reports (Root Directory)
- `manual_test_report_YYYYMMDD_HHMMSS.json` - Latest manual test results
- `performance_test_results.json` - Performance testing results
- `realistic_performance_results.json` - Realistic performance analysis
- `production_performance_results.json` - Production configuration testing
- `log_analysis_report.json` - Log analysis and patterns

### Log Files (`logs/` Directory)
- `dspy_errors.log` - DSPy configuration and operation errors
- `fallback_usage.log` - When and why fallbacks were used
- `performance_metrics.log` - Operation timing and success rates
- `sme_analysis.log` - SME analysis results and patterns
- `context_errors.log` - Context manager failures
- `database_errors.log` - Database connection and query issues
- `import_errors.log` - Missing dependencies and import failures

## 🔍 How to View Reports

### View All Available Reports
```bash
python3 show_reports.py
```

### View Specific Report Contents
```bash
# View the latest manual test report
cat manual_test_report_20250822_043736.json

# View log analysis
cat log_analysis_report.json

# View performance results
cat production_performance_results.json
```

### Analyze Logs
```bash
# Run log analysis
python3 src/backend/mcp/utils/log_analyzer.py
```

## 📈 Understanding Test Results

### Manual Test Report Structure
```json
{
  "test_summary": {
    "total_tests": 5,
    "start_time": "2025-08-22T04:37:20.124716",
    "end_time": "2025-08-22T04:37:36.232271",
    "duration_seconds": 16.107558
  },
  "test_results": [
    {
      "scenario_id": "1",
      "scenario_name": "Model Performance Degradation",
      "risk_category": "Model Risk",
      "severity": "High",
      "system_response": {
        "summary": "Analysis result...",
        "risk_score": 6,
        "confidence": "85%",
        "recommendations": ["Action 1", "Action 2"],
        "status": "success (synthetic)"
      },
      "test_duration_seconds": 14.565,
      "timestamp": "2025-08-22T04:37:34.691116"
    }
  ],
  "statistics": {
    "average_risk_score": 6.6,
    "average_response_time": 3.221,
    "highest_risk_score": 9,
    "lowest_risk_score": 5
  }
}
```

### Key Metrics to Watch

1. **Risk Score** (1-10): How serious the system thinks the problem is
2. **Confidence** (0-100%): How confident the system is in its analysis
3. **Processing Time**: How long the analysis took
4. **Status**: Whether the system used real analysis or fallback
5. **Recommendations**: What actions the system suggests

## 🚀 Running Different Types of Tests

### Performance Testing
```bash
# Test performance impact of logging
python3 notebooks/14_realistic_performance_test.py

# Test production configurations
python3 notebooks/15_production_performance_test.py
```

### Integration Testing
```bash
# Test SME context integration
python3 notebooks/12_sme_context_integration_demo.py

# Test DSPy and MCP features
python3 notebooks/10_dspy_mcp_demo.py
```

### Log Analysis
```bash
# Analyze all logs for patterns
python3 src/backend/mcp/utils/log_analyzer.py
```

## 📋 Test Results Interpretation

### Good Results
- ✅ Risk scores match expected severity
- ✅ Processing times under 5 seconds
- ✅ Clear, actionable recommendations
- ✅ High confidence levels (>80%)

### Issues to Watch For
- ⚠️ High processing times (>10 seconds)
- ⚠️ Low confidence levels (<50%)
- ⚠️ Generic or unclear recommendations
- ⚠️ Frequent fallback usage
- ⚠️ Missing SME context for risk categories

### Performance Benchmarks
- **Average Response Time**: < 2ms (production config)
- **Success Rate**: > 90%
- **Logging Overhead**: < 10% (production config)
- **Error Rate**: < 5%

## 🔧 Customizing Tests

### Adding New Scenarios
Edit `manual_test_scenarios.py` and add to the `scenarios` dictionary:

```python
"6": {
    "name": "Your Custom Scenario",
    "description": "Description of the risk event",
    "risk_category": "Your Risk Category",
    "severity": "High/Medium/Low",
    "expected_response": "What you expect the system to do"
}
```

### Testing Different Configurations
Modify the debug configuration in the test script:

```python
# For production testing
config = DebugConfig.production()

# For development testing
config = DebugConfig.development()

# For performance testing
config = DebugConfig.performance_test()
```

## 📊 Report Analysis Tips

### What to Look For
1. **Patterns**: Are certain risk categories failing more often?
2. **Performance**: Are response times consistent?
3. **Accuracy**: Do risk scores match expected severity?
4. **Coverage**: Are all risk categories being tested?
5. **Errors**: What types of errors are occurring?

### Common Issues
- **No SME Context**: Some risk categories may not have expert data
- **DSPy Errors**: Configuration issues with the AI system
- **Slow Performance**: Logging overhead or system issues
- **Generic Responses**: System falling back to basic analysis

## 🎯 Next Steps

1. **Run the manual tests** to see how the system responds
2. **Review the reports** to understand system behavior
3. **Analyze the logs** to identify patterns and issues
4. **Customize scenarios** for your specific use cases
5. **Monitor performance** to ensure optimal operation

---

*This testing framework allows you to thoroughly evaluate the risk management system and understand how it responds to different types of problems.*
