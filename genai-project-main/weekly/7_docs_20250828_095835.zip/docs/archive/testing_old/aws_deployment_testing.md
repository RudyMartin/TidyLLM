# AWS Deployment Testing

Comprehensive testing suite for AWS deployment functionality in the QA system.

## Overview

The `test_deployed_aws.py` script provides a complete test suite for all AWS-related components used in the QA system deployment.

## Test Categories

### 🔐 AWS Credentials & Permissions
- Tests AWS credentials availability
- Validates IAM permissions
- Checks access to AWS services

### 📦 S3 Storage & Document Management
- Tests S3 bucket existence and access
- Validates file upload/download operations
- Tests document management workflows

### 🗄️ RDS Database & pgvector
- Tests RDS instance connectivity
- Validates PostgreSQL with pgvector extension
- Tests database operations

### ⚡ Lambda Functions
- Tests Lambda function deployment
- Validates function invocation
- Checks runtime configuration

### 📊 CloudWatch Logging & Monitoring
- Tests log group creation and access
- Validates log stream operations
- Tests monitoring setup

### 🐳 ECR Container Registry
- Tests ECR repository access
- Validates container image management
- Tests image push/pull operations

### 🚢 ECS Container Deployment
- Tests ECS cluster and service deployment
- Validates container orchestration
- Tests scaling and health checks

### 🔒 Security Groups & IAM
- Tests IAM roles and policies
- Validates security group configurations
- Tests network security

### 💰 Cost Optimization & Billing
- Tests Cost Explorer access
- Validates billing monitoring
- Tests cost optimization features

### ⚡ Performance & Scalability
- Tests CloudWatch metrics
- Validates performance monitoring
- Tests scalability configurations

## Usage

### Run All Tests
```bash
python3 test_deployed_aws.py
```

### Dry Run (Simulation)
```bash
python3 test_deployed_aws.py --dry-run
```

### Test Specific Category
```bash
python3 test_deployed_aws.py --category s3_storage
python3 test_deployed_aws.py --category lambda_functions
python3 test_deployed_aws.py --category rds_database
```

### List Available Categories
```bash
python3 test_deployed_aws.py --list
```

### Specify AWS Region
```bash
python3 test_deployed_aws.py --region us-west-2
```

## Prerequisites

### AWS Credentials
Set up AWS credentials using one of these methods:

1. **AWS CLI Configuration:**
   ```bash
   aws configure
   ```

2. **Environment Variables:**
   ```bash
   export AWS_ACCESS_KEY_ID=your_access_key
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```

3. **IAM Role (for EC2/ECS):**
   - Attach appropriate IAM role to instance

### Required Permissions
The test suite requires the following AWS permissions:

- **S3**: List, Get, Put, Delete objects
- **RDS**: Describe instances, connect to database
- **Lambda**: Get function, invoke function
- **CloudWatch**: Describe log groups, create log streams
- **ECR**: Describe repositories, list images
- **ECS**: Describe clusters, describe services
- **IAM**: List roles, describe policies
- **EC2**: Describe security groups
- **Cost Explorer**: Get cost and usage data

## Test Configuration

The test suite uses the following default configuration:

```python
test_config = {
    's3_bucket': 'qa-system-documents',
    'rds_instance': 'qa-system-db',
    'lambda_function': 'qa-system-processor',
    'ecr_repository': 'qa-system',
    'cloudwatch_log_group': '/aws/lambda/qa-system-processor'
}
```

## Output

### Console Output
The test suite provides detailed console output showing:
- Test progress and status
- Detailed error messages
- Recommendations for fixes

### JSON Report
A comprehensive JSON report is generated with:
- Test results and timestamps
- Error details
- Performance metrics
- Recommendations

### Example Report
```json
{
  "timestamp": "2025-08-22T16:31:27.123456",
  "duration_seconds": 2.27,
  "region": "us-east-1",
  "dry_run": true,
  "results": {
    "aws_credentials": {
      "status": "PASS",
      "description": "AWS Credentials & Permissions",
      "timestamp": "2025-08-22T16:31:24.123456"
    }
  },
  "summary": {
    "total": 10,
    "passed": 10,
    "failed": 0,
    "errors": 0
  }
}
```

## Integration with CI/CD

### GitHub Actions
```yaml
- name: Test AWS Deployment
  run: |
    python3 test_deployed_aws.py --dry-run
    python3 test_deployed_aws.py --category aws_credentials
```

### AWS CodePipeline
```yaml
- name: Pre-deployment Testing
  run: python3 test_deployed_aws.py --category s3_storage
```

## Troubleshooting

### Common Issues

1. **Missing AWS Credentials**
   ```
   ❌ AWS Credentials not available
   💡 Set up AWS credentials with: aws configure
   ```

2. **Insufficient Permissions**
   ```
   ❌ Access Denied
   💡 Check IAM permissions
   ```

3. **Resource Not Found**
   ```
   ⚠️  S3 bucket not found: qa-system-documents
   💡 Create bucket: aws s3 mb s3://example-bucket-name
   ```

### Debug Mode
Enable debug logging:
```bash
export AWS_LOG_LEVEL=debug
python3 test_deployed_aws.py
```

## Best Practices

1. **Always run dry-run first** to validate test logic
2. **Test in staging environment** before production
3. **Monitor costs** during testing
4. **Clean up test resources** after testing
5. **Use least privilege** IAM permissions
6. **Document custom configurations** for your deployment

## Security Considerations

- Never commit AWS credentials to version control
- Use IAM roles instead of access keys when possible
- Regularly rotate access keys
- Monitor AWS CloudTrail for unauthorized access
- Use VPC endpoints for private communication
