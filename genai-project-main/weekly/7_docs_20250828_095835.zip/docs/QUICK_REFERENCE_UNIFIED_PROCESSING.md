# Quick Reference: Unified Document Processing

## 🚀 Quick Start

```python
from src.backend.mcp.orchestrators.document_processing_orchestrator import DocumentProcessingOrchestrator

# Initialize and process
orchestrator = DocumentProcessingOrchestrator()
result = orchestrator.process_document("file.yaml")
```

## 📁 Supported File Types

| Type | Extensions | Worker | Key Features |
|------|------------|--------|--------------|
| **YAML** | `.yaml`, `.yml` | YAMLProcessingWorker | Structure parsing, validation |
| **JSON** | `.json` | JSONProcessingWorker | Data analysis, validation |
| **CSV** | `.csv` | CSVProcessingWorker | Data type analysis, statistics |
| **Text** | `.txt` | TextProcessingWorker | Content analysis, cleaning |
| **Markdown** | `.md` | MarkdownProcessingWorker | Structure analysis, links |
| **PDF** | `.pdf` | PDFProcessingWorker | Text extraction, metadata |
| **Excel** | `.xlsx`, `.xls` | ExcelProcessingWorker | Data extraction, sheets |
| **Word** | `.docx`, `.doc` | WordProcessingWorker | Text extraction, formatting |
| **XML** | `.xml` | XMLProcessingWorker | Structure parsing, validation |
| **Images** | `.jpg`, `.png`, `.gif`, etc. | ImageProcessingWorker | Metadata, analysis |

## 🔧 Key Components

### DocumentProcessingOrchestrator
- **File**: `src/backend/mcp/orchestrators/document_processing_orchestrator.py`
- **Purpose**: Central routing and coordination
- **Features**: Auto-detection, worker management, error handling

### TextCleaningWorker
- **File**: `src/backend/mcp/workers/text_cleaning_worker.py`
- **Purpose**: HTML/JS removal with conditional bleaching
- **Features**: Pattern detection, content preservation

### Specialized Workers
- **Location**: `src/backend/mcp/workers/`
- **Purpose**: Type-specific processing
- **Features**: Optimized algorithms, detailed analysis

## 💡 Common Usage Patterns

### Single File Processing
```python
result = orchestrator.process_document("document.txt")
if result['success']:
    print(f"✅ {result['document_type']} processed by {result['worker_used']}")
    data = result['data']
else:
    print(f"❌ Error: {result['error']}")
```

### Multiple Files
```python
files = ["file1.txt", "file2.json", "file3.csv"]
results = orchestrator.process_multiple_documents(files)
success_count = sum(1 for r in results['results'] if r['success'])
print(f"Processed {success_count}/{len(files)} files successfully")
```

### Text Cleaning
```python
from src.backend.mcp.workers.text_cleaning_worker import TextCleaningWorker

cleaner = TextCleaningWorker()
analysis = cleaner.validate_cleaning_needed(content)

if analysis['needs_cleaning']:
    result = cleaner.clean_text(content)
    cleaned_content = result['cleaned_text']
else:
    cleaned_content = content  # No cleaning needed
```

## 📊 Performance Metrics

| File Type | Typical Speed | Memory Usage | Features |
|-----------|---------------|--------------|----------|
| YAML | ~50ms | Low | Structure parsing |
| JSON | ~30ms | Low | Data validation |
| CSV | ~100ms | Low | Type analysis |
| Text | ~20ms | Low | Content analysis |
| Markdown | ~40ms | Low | Structure analysis |

## 🛠️ Configuration Options

### Processing Modes
```python
# Simple mode (basic processing)
orchestrator = DocumentProcessingOrchestrator(mode=ProcessingMode.SIMPLE)

# Enhanced mode (detailed analysis)
orchestrator = DocumentProcessingOrchestrator(mode=ProcessingMode.ENHANCED)
```

### Worker Options
```python
# Enable text cleaning
text_worker = TextProcessingWorker()
text_worker.enable_cleaning = True

# Configure YAML processing
yaml_worker = YAMLProcessingWorker()
yaml_worker.set_processing_mode(YAMLMode.ENHANCED)
```

## 🔍 Monitoring & Debugging

### Check Worker Availability
```python
availability = orchestrator.check_worker_availability()
for worker, available in availability.items():
    status = "✅" if available else "❌"
    print(f"{status} {worker}")
```

### Get Processing Statistics
```python
stats = orchestrator.get_processing_stats()
print(f"Files processed: {stats['files_processed']}")
print(f"Success rate: {stats['success_rate']:.2%}")
```

### Validate Documents
```python
validation = orchestrator.validate_document("file.txt")
if validation['is_valid']:
    print("✅ Document is valid")
else:
    print(f"❌ Issues: {validation['issues']}")
```

## 🚨 Error Handling

### Common Error Patterns
```python
try:
    result = orchestrator.process_document("file.txt")
    if result['success']:
        # Process successful result
        data = result['data']
    else:
        # Handle processing error
        print(f"Processing failed: {result['error']}")
except Exception as e:
    # Handle system error
    print(f"System error: {e}")
```

### Fallback Mechanisms
```python
# Try unified processing first
if st.session_state.get('unified_processing_ready', False):
    try:
        result = orchestrator.process_document(file_path)
    except:
        # Fall back to basic processing
        result = basic_classification(file_path)
else:
    # Use basic processing
    result = basic_classification(file_path)
```

## 🔗 Integration with MVR Demo

### Enhanced File Classification
- Automatic document type detection
- Intelligent worker routing
- Enhanced classification based on content
- Confidence scoring

### Text Cleaning Integration
- Conditional bleaching (only when needed)
- Automatic HTML/JS removal
- Content preservation when cleaning not required

### Fallback Mechanisms
- Graceful degradation to basic classification
- Error recovery and handling
- Processing status tracking

## 📚 Related Documentation

- **[Unified Document Processing Architecture](architecture/UNIFIED_DOCUMENT_PROCESSING_ARCHITECTURE.md)** - Comprehensive architecture guide
- **[DataMart Architecture](core/DATAMART_ARCHITECTURE.md)** - Data storage and retrieval
- **[MCP Protocol Implementation](mcp/MCP_PROTOCOL_IMPLEMENTATION.md)** - Model Context Protocol
- **[Text Processing Pipeline](core/TEXT_PROCESSING_PIPELINE.md)** - Text analysis and processing
- **[Performance Optimization Guide](performance/OPTIMIZATION_GUIDE.md)** - Performance tuning

## 🎯 Best Practices

### 1. File Management
- Monitor file sizes before processing
- Implement size limits for demos
- Use streaming for large files

### 2. Error Handling
- Always check `result['success']`
- Implement fallback mechanisms
- Log errors for debugging

### 3. Performance
- Use appropriate processing modes
- Monitor memory usage
- Implement caching where needed

### 4. Security
- Validate file types
- Implement size limits
- Sanitize content

## 🔮 Future Features

- **Parallel Processing**: Multi-threaded document processing
- **Caching Layer**: Result caching for performance
- **Plugin Architecture**: Extensible worker system
- **Real-time Processing**: Streaming analysis
- **API Endpoints**: RESTful API
- **WebSocket Support**: Real-time updates
