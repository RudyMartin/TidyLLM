# 23 - IMPORTANT PREFLIGHT INSTRUCTIONS

## 🚨 CRITICAL SETUP REQUIREMENTS

### **Environment Prerequisites**
```bash
# 1. MANDATORY: Activate py311 conda environment
conda activate py311

# 2. If NumPy/dependency issues occur:
python scripts/setup_before_preflight.py
```

**⚠️ WARNING**: All preflight operations **MUST** run in py311 environment or they will fail with dependency errors.

## 🛫 **COMPREHENSIVE PREFLIGHT WORKFLOW**

### **Phase 1: Export Pre-Flight** (Before Bundle Creation)
```bash
python3 scripts/export_preflight.py
```

**Validates:**
- ✅ Code quality across 602 Python files
- ✅ Import structure (handles relative imports)  
- ✅ Security scanning (API keys, credentials)
- ✅ Dependencies verification
- ✅ File structure readiness
- ✅ Configuration files presence

### **Phase 2: Main Pre-Flight** (System Readiness)
```bash
python3 scripts/pre_flight_cleanup.py
```

**Comprehensive Checks:**
- ✅ Python Environment (3.12.7+)
- ✅ Dependencies availability
- ✅ Directory structure validation
- ✅ Configuration files presence
- ✅ Demo app functionality
- ✅ **API Security** (27 exposed keys detected - requires cleanup)
- ✅ Robust bundle validation
- ✅ Environment compatibility (5/5 environments)

### **Phase 3: Deployment Pre-Flight** (Environment-Specific)
```bash
python3 scripts/deployment_preflight.py --env [local|sagemaker|docker|lambda|auto]
```

**Environment Validation:**
- ✅ Bundle structure completeness
- ✅ Environment requirements validation
- ✅ Import compatibility testing
- ✅ Configuration validation for target environment
- ✅ Launcher availability
- ✅ Validation tools presence

## 🎯 **MVR DEMO SPECIFIC PREFLIGHT**

### **Quick MVR Demo Readiness Check**
```bash
# Check if MVR demo system is ready
python3 scripts/pre_flight_cleanup.py --demo-ready

# Validate local environment for MVR demo
python3 scripts/deployment_preflight.py --env local
```

### **MVR Demo Launch Preflight**
```bash
# 1. Environment setup
conda activate py311

# 2. Run preflight validation
python3 scripts/pre_flight_cleanup.py

# 3. Launch MVR demo
PYTHONPATH=src python start_mvr_demo.py
```

## ⚠️ **KNOWN ISSUES & RESOLUTIONS**

### **Issue 1: NumPy Substitution Architecture Problem** ⚠️ **CRITICAL**
**Problem:** While we've substituted NumPy in direct usage with TidyMart/numpy_compat, **third-party packages still import NumPy directly**
**Impact:** 
- Dependency conflicts in constrained environments
- Potential memory/performance issues
- Import failures in NumPy-restricted deployments
- Architectural inconsistency

**Current Status (MAJOR UPDATES LAST 10 COMMITS):** 
- ✅ **LLMData ecosystem**: Complete TidyLLM package with `llmdata.np` (TidyMart → numpy_compat)
- ✅ **DataMart package**: New `src/backend/datamart/numpy_substitute.py` for direct substitution
- ✅ **Advanced QA refactored**: 966 lines removed, streamlined with DataMart integration
- ✅ **VectorQA-Sage**: New package with DataMart core manager
- ❌ **Third-party packages**: Still import `numpy` directly (pandas, PIL, matplotlib, sklearn, scipy, seaborn)
- 🎯 **Recent Progress**: 2 complete substitution layers created, circular dependencies resolved

**Immediate Resolution:**
```bash
python scripts/setup_before_preflight.py
```

**Identified NumPy-Dependent Packages:**
- ❌ **pandas** - Core data processing (major dependency)
- ❌ **PIL/Pillow** - Image processing 
- ❌ **matplotlib** - Plotting and visualization
- ❌ **sklearn** - Machine learning models
- ❌ **scipy** - Scientific computing
- ❌ **seaborn** - Statistical visualization

**Long-term Solution Status:**
- ✅ **Priority 1 DONE**: DataTable implemented in `llmdata.dt` (452 lines) + DataMart package (2,741 lines)
- ✅ **Priority 2 IMPLEMENTED**: NumPy substitution layers:
  - `llmdata/numpy_compat.py` (532 lines) - TidyMart → fallback 
  - `src/backend/datamart/numpy_substitute.py` (485 lines) - DataMart layer
- 🔄 **Priority 3 IN PROGRESS**: Third-party package isolation needed:
  - PIL → Wand or OpenCV-lite (still imports NumPy)
  - matplotlib → plotly (pure JS) (still imports NumPy)
  - sklearn → lightweight ML alternatives (still imports NumPy)
- 🎯 **Priority 4 NEXT**: Container isolation for remaining NumPy dependencies

### **Issue 2: API Keys Exposure** 
**Status:** 27 exposed keys detected
**Impact:** Security risk in production
**Action Required:** API key cleanup before deployment

### **Issue 3: Import Structure**
**Status:** 18 relative imports detected  
**Impact:** Cross-environment compatibility issues
**Resolution:** Export preflight handles automatically

### **Issue 4: YAML Configuration**
**Symptoms:** `ruamel-yaml not available` warnings
**Impact:** Non-blocking - fallback parsing active
**Status:** System functional with PyYAML fallback

## 🏗️ **RECENT ARCHITECTURAL CHANGES (LAST 10 COMMITS)**

### **Major Updates Requiring Updated Preflight:**

**1. Complete LLMData Ecosystem (9,366 lines added)**
- ✅ **TidyLLM Python implementation**: Full verb-based pipeline (`chat`, `embed`, `analyze_data`)
- ✅ **MLFlow Gateway integration**: Centralized LLM management
- ✅ **NumPy compatibility layer**: `llmdata/numpy_compat.py` (532 lines)
- ✅ **DataTable integration**: `llmdata/dt.py` (452 lines)
- ✅ **Advanced QA streamlined**: 966 lines removed, refactored for efficiency

**2. DataMart Package Creation (2,741 lines)**
- ✅ **Complete data processing pipeline**: `src/backend/datamart/`
- ✅ **Direct NumPy substitution**: `numpy_substitute.py` (485 lines)
- ✅ **Enhanced analytics**: `analytics.py` (474 lines)
- ✅ **Performance monitoring**: `performance.py` (366 lines)
- ✅ **Circular dependency resolution**: Clean architecture achieved

**3. VectorQA-Sage Package**
- ✅ **New package structure**: `vectorqa_sage/src/vectorqa_sage/`
- ✅ **DataMart core manager**: 364 lines of data management
- ✅ **Sage integration**: Enterprise-grade processing

### **Preflight Impact:**
- **✅ Architecture validated**: Circular dependencies resolved
- **⚠️ New dependencies**: LLMData ecosystem needs validation
- **🎯 Enhanced capabilities**: TidyLLM + DataMart + VectorQA integration
- **📊 Complexity increase**: 12,107+ lines added across packages

## 🔧 **AUTOMATED WORKFLOW INTEGRATION**

### **CI/CD Pipeline Integration**
```bash
# Pre-commit validation
python3 scripts/export_preflight.py && python3 scripts/pre_flight_cleanup.py --pre-flight

# Pre-deployment validation with results logging
python3 scripts/deployment_preflight.py --env $TARGET_ENV --save-results preflight_results.json
```

### **Complete Production Deployment Workflow**
```bash
# 1. Export Pre-Flight (validate codebase)
python3 scripts/export_preflight.py

# 2. Create production bundle
python3 scripts/create_robust_bundle.py --name production_ready_bundle

# 3. Deployment Pre-Flight (validate bundle for target)
python3 scripts/deployment_preflight.py --env sagemaker

# 4. Launch in target environment
cd migration_bundles/production_ready_bundle
python3 launchers/launch_sagemaker.py
```

## 📊 **EXPECTED PREFLIGHT RESULTS**

### **Successful Main Pre-Flight Output:**
```
🛫 PRE-FLIGHT CHECKS
============================================================
✅ Python Environment: 3.12.7
✅ Dependencies: All core packages available
✅ Directory Structure: Essential directories present  
✅ Configuration Files: Requirements files found
✅ Test Files: Core test files available
✅ Demo Readiness: Demo app functional
⚠️ API Security: 27 exposed keys found (needs cleanup)
✅ Security Hardening: Environment config ready
✅ Robust Bundle Validation: Production bundle ready
✅ Environment Compatibility: 5/5 environments tested
```

### **Successful Export Pre-Flight Output:**
```
📦 EXPORT PRE-FLIGHT CHECKS
============================================================
✅ Code Quality: 602 Python files verified
✅ Import Structure: 18 relative imports (handled)
✅ Configuration Files: 3 required files present
✅ Dependencies: 2 requirements files, 4 key deps
✅ Security: No critical security issues
✅ File Structure: 3 required directories
✅ Robust Tools: 3 deployment tools available  
✅ Environment Tests: Local test passed
```

## 🚀 **PRODUCTION READINESS INDICATORS**

### **Green Light Criteria:**
- ✅ All preflight phases pass
- ✅ py311 environment active
- ✅ No critical security issues
- ✅ Demo functionality confirmed
- ✅ Target environment compatibility validated

### **Yellow Light - Proceed with Caution:**
- ⚠️ API keys exposed (cleanup recommended)
- ⚠️ Minor import structure issues (handled automatically)
- ⚠️ YAML parsing warnings (non-blocking)

### **Red Light - DO NOT PROCEED:**
- ❌ py311 environment not activated
- ❌ Core dependencies missing
- ❌ Critical security vulnerabilities
- ❌ Demo functionality broken
- ❌ Target environment incompatibility

## 📋 **PREFLIGHT CHECKLIST**

**Before Any Demo or Deployment:**

- [ ] py311 conda environment activated
- [ ] Export pre-flight executed successfully  
- [ ] Main pre-flight executed successfully
- [ ] Deployment pre-flight executed for target environment
- [ ] API security issues addressed (if required for production)
- [ ] Demo functionality validated
- [ ] All critical errors resolved

**For MVR Demo Specifically:**

- [ ] TidyLLM capabilities system functional
- [ ] Document classification system active
- [ ] AI-powered analysis operational  
- [ ] File upload and processing working
- [ ] DataMart integration functional
- [ ] Real-time analysis capabilities available

## 🎯 **NEXT STEPS AFTER PREFLIGHT**

1. **Address any yellow/red flags** identified in preflight
2. **Run target-specific validation** for deployment environment
3. **Execute demo/deployment** with confidence
4. **Monitor system performance** post-deployment
5. **Document any issues** for future preflight improvements

---

**📋 Document Status:** Ready for immediate use  
**🔄 Last Updated:** System validation confirmed  
**🎯 Usage:** Run these checks before any MVR demo or production deployment