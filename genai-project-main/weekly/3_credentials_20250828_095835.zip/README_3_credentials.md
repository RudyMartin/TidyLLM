# 3 Credentials

## Description
Configuration and environment files (sanitized)

## Deployment Instructions
1. Extract this archive to the target environment
2. Follow the main DEPLOYMENT_MANIFEST instructions
3. Ensure proper file permissions are set

## Contents
This archive contains files matching these patterns:
- src/config/**/*
- src/environ_settings/**/*
- *.env.example
- *.env.template
- **/config.yaml
- **/config.json
- pyproject.toml
- requirements*.txt
- poetry.lock
- Pipfile*

## Generated
Created: 2025-08-28T09:58:42.173639
System: Full Site Archiver for Air-Gapped Deployment
