#!/usr/bin/env python3
"""
Comprehensive Pre-screening Test with 10 Documents

Test the MVR demo pre-screening functionality with 10 diverse documents
from the input directory to validate proper classification, digest generation,
and database matching.
"""

import sys
import os
from pathlib import Path
import time
import json
from typing import List, Dict, Any

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

def create_mock_uploaded_file(file_path: Path) -> Dict[str, Any]:
    """Create a mock uploaded file object for testing"""
    class MockUploadedFile:
        def __init__(self, path: Path):
            self.name = path.name
            self.size = path.stat().st_size if path.exists() else 0
            
            try:
                if path.suffix.lower() == '.pdf':
                    # For PDFs, we'll use a mock content since we can't easily read them here
                    if 'validation' in path.name.lower():
                        self._content = b"Model Validation Report: This document provides comprehensive validation of models used in risk management and compliance frameworks."
                    elif 'risk' in path.name.lower():
                        self._content = b"Risk Assessment Document: Analysis of operational and credit risks with mitigation strategies and control measures."
                    elif 'trend' in path.name.lower():
                        self._content = b"Trend Analysis Report: Market trends and consumer behavior analysis for strategic planning purposes."
                    else:
                        self._content = b"PDF Document: Contains important information for business operations and decision making processes."
                elif path.suffix.lower() in ['.txt', '.md']:
                    self._content = path.read_bytes() if path.exists() else b"Text document content"
                else:
                    self._content = b"Document content for analysis and classification"
            except Exception:
                self._content = b"Document content available for processing"
        
        def getvalue(self):
            return self._content
    
    return MockUploadedFile(file_path)

def test_prescreening_comprehensive():
    """Test pre-screening with 10 diverse documents"""
    print("🔍 Comprehensive Pre-screening Test - 10 Documents")
    print("=" * 60)
    
    try:
        import streamlit_mvr_demo
        demo = streamlit_mvr_demo.MVRDemo()
        print("✅ MVR Demo initialized successfully")
        
        # Select 10 diverse test documents
        test_documents = [
            # Model validation documents
            Path("data/input/reviews/Model_Validation_Template.pdf"),
            Path("data/input/reviews/Model-Development-and-Validation-Report.pdf"),
            
            # Research papers
            Path("data/input/r_research/SparseSignatures.pdf"),
            Path("data/input/2506.21734v2_hierarchy.pdf"),
            
            # Business/trend reports  
            Path("data/input/catalog/DELOITTE_Tech-trends-2024.pdf"),
            Path("data/input/catalog/PWC_Global Digital Trust Insights 2024.pdf"),
            
            # Sample documents
            Path("data/input/sample_validation_report.txt"),
            Path("data/input/sample_research_paper.txt"),
            
            # Control documents
            Path("input/REV2024001_Validation_Scoping_Template_VST.txt"),
            Path("input/REV2024001_Annual_Model_Review_AMR.txt"),
        ]
        
        print(f"📋 Testing {len(test_documents)} documents:")
        for i, doc in enumerate(test_documents, 1):
            print(f"   {i}. {doc.name}")
        print()
        
        results = []
        start_time = time.time()
        
        for i, doc_path in enumerate(test_documents, 1):
            print(f"📄 [{i}/10] Processing: {doc_path.name}")
            print("-" * 40)
            
            try:
                # Create mock uploaded file
                mock_file = create_mock_uploaded_file(doc_path)
                
                # Test pre-screening
                result = demo.pre_screen_document(mock_file)
                
                # Display results
                if result['success']:
                    print(f"✅ Success: {result['classification']}")
                    print(f"📊 Type: {result.get('doc_type', 'Unknown')}")
                    print(f"⚠️  Risk: {result.get('metadata', {}).get('risk_tier', 'Unknown')}")
                    print(f"📝 Digest: {result['digest'][:100]}...")
                    print(f"⏱️  Time: {result.get('processing_time', 0):.2f}s")
                    
                    # Check database matches
                    db_matches = result.get('db_matches', [])
                    if db_matches:
                        print(f"🔍 DB Matches: {len(db_matches)}")
                        for match in db_matches[:2]:
                            if 'error' not in match:
                                print(f"   • {match['title']} ({match['similarity_score']:.0%})")
                    else:
                        print("🔍 DB Matches: None")
                else:
                    print(f"❌ Failed: {result.get('error', 'Unknown error')}")
                
                # Store results
                result['document_name'] = doc_path.name
                result['document_path'] = str(doc_path)
                results.append(result)
                
            except Exception as e:
                print(f"❌ Error processing {doc_path.name}: {e}")
                results.append({
                    'success': False,
                    'document_name': doc_path.name,
                    'document_path': str(doc_path),
                    'error': str(e)
                })
            
            print()
        
        total_time = time.time() - start_time
        
        # Summary analysis
        print("📊 COMPREHENSIVE ANALYSIS SUMMARY")
        print("=" * 60)
        
        successful = [r for r in results if r.get('success', False)]
        failed = [r for r in results if not r.get('success', False)]
        
        print(f"✅ Successful: {len(successful)}/{len(results)} documents")
        print(f"❌ Failed: {len(failed)}/{len(results)} documents")
        print(f"⏱️  Total Time: {total_time:.2f}s")
        print(f"⚡ Avg Time: {total_time/len(results):.2f}s per document")
        print()
        
        # Classification analysis
        if successful:
            classifications = {}
            risk_tiers = {}
            digest_lengths = []
            
            for result in successful:
                # Count classifications
                doc_type = result.get('classification', 'Unknown')
                classifications[doc_type] = classifications.get(doc_type, 0) + 1
                
                # Count risk tiers
                risk_tier = result.get('metadata', {}).get('risk_tier', 'Unknown')
                risk_tiers[risk_tier] = risk_tiers.get(risk_tier, 0) + 1
                
                # Digest lengths
                digest_len = len(result.get('digest', ''))
                digest_lengths.append(digest_len)
            
            print("📋 Classification Distribution:")
            for doc_type, count in classifications.items():
                print(f"   {doc_type}: {count} documents")
            
            print("\\n⚠️  Risk Tier Distribution:")
            for risk_tier, count in risk_tiers.items():
                print(f"   {risk_tier}: {count} documents")
            
            print("\\n📝 Digest Analysis:")
            print(f"   Average length: {sum(digest_lengths)/len(digest_lengths):.0f} characters")
            print(f"   Range: {min(digest_lengths)}-{max(digest_lengths)} characters")
            
            # Database matching analysis
            total_matches = sum(len(r.get('db_matches', [])) for r in successful)
            print(f"\\n🔍 Database Matches: {total_matches} total matches found")
        
        # Failed document analysis
        if failed:
            print("\\n❌ Failed Documents Analysis:")
            error_types = {}
            for result in failed:
                error = result.get('error', 'Unknown error')
                error_key = error.split(':')[0] if ':' in error else error
                error_types[error_key] = error_types.get(error_key, 0) + 1
            
            for error_type, count in error_types.items():
                print(f"   {error_type}: {count} documents")
        
        # Save detailed results
        results_file = Path("prescreening_test_results.json")
        with open(results_file, 'w') as f:
            json.dump({
                'test_summary': {
                    'total_documents': len(results),
                    'successful': len(successful),
                    'failed': len(failed),
                    'total_time_seconds': total_time,
                    'avg_time_per_doc': total_time/len(results)
                },
                'results': results
            }, f, indent=2)
        
        print(f"\\n💾 Detailed results saved to: {results_file}")
        
        # Final assessment
        print("\\n🎯 FINAL ASSESSMENT:")
        success_rate = len(successful) / len(results) * 100
        if success_rate >= 90:
            print(f"🎉 EXCELLENT: {success_rate:.0f}% success rate - Pre-screening system is working perfectly!")
        elif success_rate >= 70:
            print(f"✅ GOOD: {success_rate:.0f}% success rate - Pre-screening system is working well with minor issues")
        elif success_rate >= 50:
            print(f"⚠️ FAIR: {success_rate:.0f}% success rate - Pre-screening system needs improvements")
        else:
            print(f"❌ POOR: {success_rate:.0f}% success rate - Pre-screening system has significant issues")
        
        return success_rate >= 70
        
    except Exception as e:
        print(f"❌ Test suite failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🧪 MVR Demo Pre-screening Comprehensive Test Suite")
    print("=" * 60)
    
    # Change to project directory
    os.chdir(Path(__file__).parent)
    
    # Set Python path
    os.environ["PYTHONPATH"] = "src"
    
    success = test_prescreening_comprehensive()
    
    print("=" * 60)
    if success:
        print("🎉 TEST SUITE PASSED - Pre-screening system is ready for production!")
    else:
        print("⚠️ TEST SUITE ISSUES - Review results and fix issues before deployment")
    print("=" * 60)