#!/usr/bin/env python3
"""
Real PDF Pre-screening Test

Test the MVR demo pre-screening functionality with actual PDF files
to validate real document processing, classification, and digest generation.
"""

import sys
import os
from pathlib import Path
import time
import json
from typing import List, Dict, Any

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent / "src"))

def create_real_uploaded_file(file_path: Path):
    """Create a realistic uploaded file object for testing with actual file content"""
    class RealUploadedFile:
        def __init__(self, path: Path):
            self.name = path.name
            self.size = path.stat().st_size if path.exists() else 0
            self.type = f"application/{path.suffix[1:]}" if path.suffix else "application/octet-stream"
            self._path = path
        
        def getvalue(self):
            return self._path.read_bytes() if self._path.exists() else b""
    
    return RealUploadedFile(file_path)

def test_real_pdf_prescreening():
    """Test pre-screening with actual PDF files and real content extraction"""
    print("🔍 Real PDF Pre-screening Test")
    print("=" * 50)
    
    try:
        import streamlit_mvr_demo
        demo = streamlit_mvr_demo.MVRDemo()
        print("✅ MVR Demo initialized successfully")
        
        # Select existing PDF files for testing
        test_files = []
        potential_files = [
            Path("data/input/reviews/Model_Validation_Template.pdf"),
            Path("data/input/2506.21734v2_hierarchy.pdf"),
            Path("input/omnibus/Rudys Attention Is All You Need.pdf"),
            Path("data/input/catalog/DELOITTE_Tech-trends-2024.pdf"),
            Path("data/input/sample_validation_report.txt"),
            Path("input/REV2024001_Validation_Scoping_Template_VST.txt"),
        ]
        
        # Check which files actually exist
        for file_path in potential_files:
            if file_path.exists():
                test_files.append(file_path)
        
        if not test_files:
            print("❌ No test files found!")
            return False
        
        print(f"📋 Testing {len(test_files)} real documents:")
        for i, doc in enumerate(test_files, 1):
            print(f"   {i}. {doc.name} ({doc.stat().st_size/1024:.1f} KB)")
        print()
        
        results = []
        start_time = time.time()
        
        for i, doc_path in enumerate(test_files, 1):
            print(f"📄 [{i}/{len(test_files)}] Processing: {doc_path.name}")
            print("-" * 50)
            
            try:
                # Create realistic uploaded file
                uploaded_file = create_real_uploaded_file(doc_path)
                
                # Test pre-screening with real file processing
                result = demo.pre_screen_document(uploaded_file)
                
                # Display results
                if result['success']:
                    print(f"✅ Success: {result['classification']}")
                    print(f"📊 Type: {result.get('doc_type', 'Unknown')}")
                    print(f"⚠️  Risk: {result.get('metadata', {}).get('risk_tier', 'Unknown')}")
                    print(f"📄 Pages: {result['pages_analyzed']}")
                    print(f"📝 Content length: {result['content_length']} chars")
                    print(f"⏱️  Time: {result.get('processing_time', 0):.2f}s")
                    
                    # Show first 200 chars of actual digest
                    digest = result['digest']
                    print(f"📖 Digest preview: {digest[:200]}...")
                    
                    # Check database matches
                    db_matches = result.get('db_matches', [])
                    if db_matches:
                        print(f"🔍 DB Matches: {len(db_matches)}")
                        for match in db_matches[:2]:
                            if 'error' not in match:
                                print(f"   • {match['title']} ({match['similarity_score']:.0%})")
                    
                    # Validate digest quality
                    if len(digest) > 50 and digest != result.get('content_preview', ''):
                        print("✅ Digest quality: Good (meaningful content generated)")
                    else:
                        print("⚠️  Digest quality: May need improvement")
                        
                else:
                    print(f"❌ Failed: {result.get('error', 'Unknown error')}")
                
                # Store results
                result['document_name'] = doc_path.name
                result['document_path'] = str(doc_path)
                result['file_size_kb'] = doc_path.stat().st_size / 1024
                results.append(result)
                
            except Exception as e:
                print(f"❌ Error processing {doc_path.name}: {e}")
                import traceback
                traceback.print_exc()
                results.append({
                    'success': False,
                    'document_name': doc_path.name,
                    'document_path': str(doc_path),
                    'error': str(e)
                })
            
            print()
        
        total_time = time.time() - start_time
        
        # Analysis
        print("📊 REAL PDF PROCESSING ANALYSIS")
        print("=" * 50)
        
        successful = [r for r in results if r.get('success', False)]
        failed = [r for r in results if not r.get('success', False)]
        
        print(f"✅ Successful: {len(successful)}/{len(results)} documents")
        print(f"❌ Failed: {len(failed)}/{len(results)} documents")
        print(f"⏱️  Total Time: {total_time:.2f}s")
        print(f"⚡ Avg Time: {total_time/len(results):.2f}s per document")
        
        if successful:
            # Content analysis
            content_lengths = [r.get('content_length', 0) for r in successful]
            digest_lengths = [len(r.get('digest', '')) for r in successful]
            processing_times = [r.get('processing_time', 0) for r in successful]
            
            print(f"\\n📖 Content Analysis:")
            print(f"   Avg extracted content: {sum(content_lengths)/len(content_lengths):.0f} characters")
            print(f"   Content range: {min(content_lengths)}-{max(content_lengths)} characters")
            print(f"   Avg digest length: {sum(digest_lengths)/len(digest_lengths):.0f} characters")
            print(f"   Avg processing time: {sum(processing_times)/len(processing_times):.2f}s")
            
            # Classification diversity
            classifications = {}
            for result in successful:
                doc_type = result.get('classification', 'Unknown')
                classifications[doc_type] = classifications.get(doc_type, 0) + 1
            
            print(f"\\n📋 Document Types:")
            for doc_type, count in classifications.items():
                print(f"   {doc_type}: {count} documents")
            
            # Digest quality assessment
            meaningful_digests = [r for r in successful if len(r.get('digest', '')) > 50]
            print(f"\\n📝 Digest Quality:")
            print(f"   Meaningful digests: {len(meaningful_digests)}/{len(successful)}")
            
            # Show sample digests
            print(f"\\n📖 Sample Digests:")
            for i, result in enumerate(successful[:3], 1):
                digest = result.get('digest', '')
                print(f"   {i}. {result['document_name'][:30]}...")
                print(f"      {digest[:150]}...")
        
        # Save results
        results_file = Path("real_pdf_prescreening_results.json")
        with open(results_file, 'w') as f:
            json.dump({
                'test_summary': {
                    'total_documents': len(results),
                    'successful': len(successful),
                    'failed': len(failed),
                    'total_time_seconds': total_time,
                    'avg_time_per_doc': total_time/len(results)
                },
                'results': results
            }, f, indent=2)
        
        print(f"\\n💾 Detailed results saved to: {results_file}")
        
        # Final assessment
        print("\\n🎯 REAL PDF PROCESSING ASSESSMENT:")
        success_rate = len(successful) / len(results) * 100
        
        if success_rate >= 90:
            print(f"🎉 EXCELLENT: {success_rate:.0f}% success rate!")
            print("   ✅ Real PDF text extraction working")
            print("   ✅ AI classification working")  
            print("   ✅ Digest generation working")
            print("   ✅ Database matching working")
            assessment = "PRODUCTION READY"
        elif success_rate >= 70:
            print(f"✅ GOOD: {success_rate:.0f}% success rate with minor issues")
            assessment = "NEARLY READY"
        else:
            print(f"⚠️ NEEDS WORK: {success_rate:.0f}% success rate")
            assessment = "NEEDS IMPROVEMENT"
        
        print(f"\\n🏆 FINAL VERDICT: {assessment}")
        return success_rate >= 70
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("🧪 Real PDF Pre-screening Test Suite")
    print("=" * 50)
    
    # Change to project directory
    os.chdir(Path(__file__).parent)
    
    # Set Python path
    os.environ["PYTHONPATH"] = "src"
    
    success = test_real_pdf_prescreening()
    
    print("=" * 50)
    if success:
        print("🎉 REAL PDF PROCESSING TEST PASSED!")
        print("The pre-screening system successfully extracts real PDF content,")
        print("generates meaningful AI digests, and provides accurate classifications!")
    else:
        print("⚠️ REAL PDF PROCESSING NEEDS ATTENTION")
        print("Review results and address issues before deployment.")
    print("=" * 50)