#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF Processing Worker

Real PDF processing worker with comprehensive text extraction capabilities.
Uses multiple fallback methods for maximum compatibility.
"""

import logging
import io
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

# PDF processing libraries with fallback priority
PDF_LIBRARIES = []

try:
    import pypdf
    PDF_LIBRARIES.append(('pypdf', 'primary'))
except ImportError:
    pass

try:
    import pdfplumber
    PDF_LIBRARIES.append(('pdfplumber', 'secondary'))  
except ImportError:
    pass

try:
    import PyPDF2
    PDF_LIBRARIES.append(('PyPDF2', 'fallback'))
except ImportError:
    pass

try:
    import fitz  # PyMuPDF
    PDF_LIBRARIES.append(('fitz', 'advanced'))
except ImportError:
    pass


class PDFProcessingWorker:
    """Real PDF processing worker with multiple extraction methods"""
    
    def __init__(self):
        self.worker_id = f"pdf_worker_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.processing_stats = {
            'files_processed': 0,
            'successful_parses': 0,
            'failed_parses': 0
        }
        self.available_libraries = PDF_LIBRARIES
        
        logger.info(f"PDF Processing Worker initialized with {len(self.available_libraries)} libraries")
        for lib_name, lib_type in self.available_libraries:
            logger.info(f"  - {lib_name} ({lib_type})")
    
    def process_document(self, file_path: str) -> Dict[str, Any]:
        """Process PDF file with real text extraction"""
        start_time = datetime.now()
        
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"PDF file not found: {file_path}")
            
            # Validate file extension
            if not file_path.suffix.lower() == '.pdf':
                return {
                    'success': False,
                    'error': 'Not a PDF file',
                    'file_path': str(file_path),
                    'processing_time': datetime.now().isoformat(),
                    'worker_id': self.worker_id
                }
            
            # Try extraction with available libraries
            text_content, metadata = self._extract_text_content(file_path)
            
            if not text_content.strip():
                return {
                    'success': False,
                    'error': 'No text content extracted from PDF',
                    'file_path': str(file_path),
                    'processing_time': datetime.now().isoformat(),
                    'worker_id': self.worker_id
                }
            
            self.processing_stats['successful_parses'] += 1
            self.processing_stats['files_processed'] += 1
            
            processing_time = (datetime.now() - start_time).total_seconds()
            
            logger.info(f"✅ PDF extracted: {len(text_content)} chars in {processing_time:.2f}s")
            
            return {
                'success': True,
                'data': {
                    'content': text_content,
                    'file_path': str(file_path),
                    'file_size': file_path.stat().st_size,
                    'metadata': metadata,
                    'processing_time_seconds': processing_time,
                    'extraction_method': metadata.get('extraction_method', 'unknown')
                },
                'file_path': str(file_path),
                'processing_time': datetime.now().isoformat(),
                'worker_id': self.worker_id
            }
            
        except Exception as e:
            self.processing_stats['failed_parses'] += 1
            self.processing_stats['files_processed'] += 1
            
            logger.error(f"❌ Failed to process PDF file {file_path}: {e}")
            return {
                'success': False,
                'error': str(e),
                'file_path': str(file_path),
                'processing_time': datetime.now().isoformat(),
                'worker_id': self.worker_id
            }
    
    def _extract_text_content(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Extract text content using available libraries"""
        
        for lib_name, lib_type in self.available_libraries:
            try:
                if lib_name == 'pypdf':
                    return self._extract_with_pypdf(file_path)
                elif lib_name == 'pdfplumber':
                    return self._extract_with_pdfplumber(file_path)
                elif lib_name == 'PyPDF2':
                    return self._extract_with_pypdf2(file_path)
                elif lib_name == 'fitz':
                    return self._extract_with_pymupdf(file_path)
            except Exception as e:
                logger.warning(f"Failed to extract with {lib_name}: {e}")
                continue
        
        # If all methods fail, return basic file info
        return self._basic_extraction(file_path)
    
    def _extract_with_pypdf(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Extract text using pypdf library"""
        import pypdf
        
        with open(file_path, 'rb') as file:
            reader = pypdf.PdfReader(file)
            text_content = ""
            
            for page_num, page in enumerate(reader.pages):
                text_content += page.extract_text() + "\n"
            
            metadata = {
                'extraction_method': 'pypdf',
                'num_pages': len(reader.pages),
                'pdf_metadata': reader.metadata if reader.metadata else {}
            }
            
            return text_content, metadata
    
    def _extract_with_pdfplumber(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Extract text using pdfplumber library"""
        import pdfplumber
        
        text_content = ""
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text_content += page_text + "\n"
            
            metadata = {
                'extraction_method': 'pdfplumber',
                'num_pages': len(pdf.pages),
                'pdf_metadata': pdf.metadata if hasattr(pdf, 'metadata') else {}
            }
        
        return text_content, metadata
    
    def _extract_with_pypdf2(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Extract text using PyPDF2 library (fallback)"""
        import PyPDF2
        
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            text_content = ""
            
            for page in reader.pages:
                text_content += page.extract_text() + "\n"
            
            metadata = {
                'extraction_method': 'PyPDF2',
                'num_pages': len(reader.pages),
                'pdf_metadata': reader.metadata if hasattr(reader, 'metadata') else {}
            }
        
        return text_content, metadata
    
    def _extract_with_pymupdf(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Extract text using PyMuPDF (fitz) library"""
        import fitz
        
        doc = fitz.open(file_path)
        text_content = ""
        
        for page in doc:
            text_content += page.get_text() + "\n"
        
        metadata = {
            'extraction_method': 'PyMuPDF',
            'num_pages': doc.page_count,
            'pdf_metadata': doc.metadata
        }
        
        doc.close()
        return text_content, metadata
    
    def _basic_extraction(self, file_path: Path) -> tuple[str, Dict[str, Any]]:
        """Basic extraction when no PDF libraries are available"""
        metadata = {
            'extraction_method': 'basic_file_info',
            'error': 'No PDF processing libraries available',
            'available_libraries': [lib[0] for lib in self.available_libraries]
        }
        
        # Return basic file information
        text_content = f"PDF File: {file_path.name}\nSize: {file_path.stat().st_size} bytes\n"
        text_content += "Note: No PDF text extraction libraries available. Install pypdf, pdfplumber, PyPDF2, or PyMuPDF for text extraction."
        
        return text_content, metadata
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """Get processing statistics"""
        return {
            'worker_id': self.worker_id,
            'stats': self.processing_stats.copy(),
            'timestamp': datetime.now().isoformat()
        }


if __name__ == "__main__":
    print("PDF Processing Worker - Placeholder Implementation")
    print("Full PDF processing will be implemented in a future update.")
