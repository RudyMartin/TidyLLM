"""
MCP Workers Package

This package contains all specialized workers for document processing:
- TOC Extractor Worker
- Bibliography Builder Worker
- Image Processing Worker
- Modern PDF Processor
- File Classification Worker (Configurable for Simple/Enhanced/Advanced modes)
- Table Extractor Worker
"""

from .toc_extractor_worker import TOCExtractorWorker
from .bibliography_builder_worker import BibliographyBuilderWorker
from .image_processing_worker import ImageProcessingWorker
from .modern_pdf_processor import ModernPDFProcessor
from .file_classification_worker import FileClassificationWorker, ClassificationMode
from .toc_extractor_worker import TOCExtractorWorker, TOCMode
from .bibliography_builder_worker import BibliographyBuilderWorker, BibliographyMode
from .image_processing_worker import ImageProcessingWorker, ImageProcessingMode

__all__ = [
    'TOCExtractorWorker',
    'TOCMode',
    'BibliographyBuilderWorker',
    'BibliographyMode',
    'ImageProcessingWorker',
    'ImageProcessingMode',
    'ModernPDFProcessor',
    'FileClassificationWorker',
    'ClassificationMode'
]

__version__ = "1.0.0"
