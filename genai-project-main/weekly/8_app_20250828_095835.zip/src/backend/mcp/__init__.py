"""
Model Context Protocol (MCP) Package

This package implements the hierarchical MCP architecture with orchestrators,
coordinators, and workers for the VectorQA Sage backend.
"""

# from .orchestrators import *
# from .coordinators import *
# from .workers import *
# from .planner import *
# from .protocol import *

__version__ = "1.0.0"
__author__ = "VectorQA Sage Team"
