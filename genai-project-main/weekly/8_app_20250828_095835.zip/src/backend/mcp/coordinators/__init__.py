"""
MCP Coordinators Package

Mid-level coordination and tactical execution components.
"""

from .document_coordinator import DocumentCoordinator
from .sme_context_coordinator import SMEContextCoordinator

__all__ = [
    'DocumentCoordinator',
    'SMEContextCoordinator'
]

__version__ = "1.0.0"
