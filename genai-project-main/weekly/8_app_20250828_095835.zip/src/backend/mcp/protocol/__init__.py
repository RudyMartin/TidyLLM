"""
MCP Protocol Package

Communication protocols, message schemas, and contracts for MCP layer communication.
"""

from .message_protocol import (
    MCPMessage,
    AuditTrail,
    MessageType,
    TaskType,
    Priority,
    MCPMessageBuilder,
    create_planner_to_coordinator_message,
    create_coordinator_to_worker_message,
    create_worker_to_coordinator_message,
    create_coordinator_to_planner_message
)
from .message_schemas import MCPMessageSchema
from .communication import MCPProtocol
from .contracts import LayerContract

__version__ = "1.0.0"
__all__ = [
    "MCPMessage",
    "AuditTrail", 
    "MessageType",
    "TaskType",
    "Priority",
    "MCPMessageBuilder",
    "create_planner_to_coordinator_message",
    "create_coordinator_to_worker_message",
    "create_worker_to_coordinator_message",
    "create_coordinator_to_planner_message",
    "MCPMessageSchema",
    "MCPProtocol",
    "LayerContract"
]
