"""
MCP Orchestrators Package

This package contains orchestrators that coordinate multiple workers:
- Document Processing Orchestrator
- RAG QA Orchestrator
- QA Orchestrator
- QA Reviewer Orchestrator
- LLM Enhanced QA Orchestrator
"""

from .document_processing_orchestrator import DocumentProcessingOrchestrator

# Optional imports - only import if available
try:
    from .rag_qa_orchestrator import RAGQAOrchestrator
    RAGQA_AVAILABLE = True
except (ImportError, Exception) as e:
    RAGQA_AVAILABLE = False
    RAGQAOrchestrator = None
    print(f"⚠️ Skipping RAGQA orchestrator due to dependency issues: {e}")

try:
    from .qa_orchestrator import QAOrchestrator
    QA_AVAILABLE = True
except (ImportError, Exception) as e:
    QA_AVAILABLE = False
    QAOrchestrator = None
    print(f"⚠️ Skipping QA orchestrator due to dependency issues: {e}")

__all__ = [
    'DocumentProcessingOrchestrator',
    'RAGQAOrchestrator',
    'QAOrchestrator'
]
