"""
Backend package for VectorQA Sage

This package contains all backend functionality including:
- MCP (Model Context Protocol) implementation
- Document processing workers
- Orchestrators
- Core utilities
"""

__version__ = "1.0.0"
__author__ = "VectorQA Sage Team"
