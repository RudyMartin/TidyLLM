#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AHA System - Automated Health Awareness

This module provides comprehensive architectural health monitoring and prevention.
"""

from .reorg_department import ReorgDepartment, HealthStatus, HealthReport
from .aha_system import AHAMonitor, AHAMode, AHADashboard, AHAAlert
from .aha_integrations import AHAIntegrationManager

__all__ = [
    'ReorgDepartment',
    'HealthStatus', 
    'HealthReport',
    'AHAMonitor',
    'AHAMode',
    'AHADashboard',
    'AHAAlert',
    'AHAIntegrationManager'
]

__version__ = "1.0.0"
__author__ = "AHA System Team"
__description__ = "Automated Health Awareness System for Architectural Monitoring"
