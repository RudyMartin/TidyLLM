#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Automated Health Awareness (AHA) System

AHA provides intelligent, continuous monitoring and proactive prevention of architectural issues.
It builds on the REORG Department to create a comprehensive health awareness ecosystem.

Key Features:
- Continuous monitoring with intelligent alerts
- Predictive health analysis
- Automated intervention recommendations
- Health trend analysis and forecasting
- Integration with development workflows
"""

import os
import json
import logging
import asyncio
import time
from pathlib import Path
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from enum import Enum
import threading
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

from .reorg_department import ReorgDepartment, HealthStatus, HealthReport

logger = logging.getLogger(__name__)


class AHAMode(Enum):
    """AHA system operating modes"""
    PASSIVE = "passive"      # Monitor only, no interventions
    ACTIVE = "active"        # Monitor and suggest interventions
    AGGRESSIVE = "aggressive"  # Monitor, suggest, and auto-fix when safe


class HealthTrend(Enum):
    """Health trend indicators"""
    IMPROVING = "improving"
    STABLE = "stable"
    DEGRADING = "degrading"
    CRITICAL = "critical"


@dataclass
class AHAAlert:
    """AHA system alert"""
    alert_id: str
    timestamp: datetime
    severity: HealthStatus
    category: str
    title: str
    description: str
    recommendations: List[str]
    auto_fixable: bool
    impact_score: float
    affected_files: List[str]


@dataclass
class AHAHealthSnapshot:
    """Comprehensive health snapshot"""
    timestamp: datetime
    overall_health_score: float
    trend: HealthTrend
    alerts: List[AHAAlert]
    metrics: Dict[str, Any]
    predictions: Dict[str, Any]


class AHAMonitor:
    """Continuous health monitoring system"""
    
    def __init__(self, codebase_root: str, mode: AHAMode = AHAMode.ACTIVE):
        self.codebase_root = Path(codebase_root)
        self.mode = mode
        self.reorg_dept = ReorgDepartment(str(codebase_root))
        self.health_history: List[HealthReport] = []
        self.alerts: List[AHAAlert] = []
        self.monitoring_active = False
        self.file_observer = None
        
        # Configuration
        self.scan_interval = 300  # 5 minutes
        self.alert_thresholds = {
            'health_score_warning': 0.7,
            'health_score_critical': 0.5,
            'violation_increase_threshold': 0.2,
            'trend_degradation_threshold': 0.1
        }
        
        # Callbacks for external integrations
        self.alert_callbacks: List[Callable[[AHAAlert], None]] = []
        self.intervention_callbacks: List[Callable[[AHAAlert], bool]] = []
        
    def start_monitoring(self):
        """Start continuous health monitoring"""
        logger.info("🚀 AHA System: Starting continuous health monitoring")
        
        self.monitoring_active = True
        
        # Start file system monitoring
        self._start_file_monitoring()
        
        # Start periodic health checks
        self._start_periodic_monitoring()
        
        logger.info("✅ AHA System: Continuous monitoring active")
    
    def stop_monitoring(self):
        """Stop continuous health monitoring"""
        logger.info("🛑 AHA System: Stopping continuous health monitoring")
        
        self.monitoring_active = False
        
        if self.file_observer:
            self.file_observer.stop()
            self.file_observer.join()
        
        logger.info("✅ AHA System: Monitoring stopped")
    
    def _start_file_monitoring(self):
        """Start file system monitoring for immediate alerts"""
        event_handler = AHAFileHandler(self)
        self.file_observer = Observer()
        self.file_observer.schedule(event_handler, str(self.codebase_root), recursive=True)
        self.file_observer.start()
    
    def _start_periodic_monitoring(self):
        """Start periodic health check monitoring"""
        def periodic_check():
            while self.monitoring_active:
                try:
                    self._run_health_check()
                    time.sleep(self.scan_interval)
                except Exception as e:
                    logger.error(f"AHA periodic check error: {e}")
                    time.sleep(60)  # Wait 1 minute on error
        
        monitoring_thread = threading.Thread(target=periodic_check, daemon=True)
        monitoring_thread.start()
    
    def _run_health_check(self):
        """Run comprehensive health check and analyze trends"""
        logger.info("🔍 AHA System: Running periodic health check")
        
        # Run REORG Department health check
        health_report = self.reorg_dept.run_health_check()
        self.health_history.append(health_report)
        
        # Analyze trends and generate alerts
        self._analyze_health_trends(health_report)
        
        # Generate predictions
        predictions = self._generate_health_predictions()
        
        # Create comprehensive snapshot
        snapshot = self._create_health_snapshot(health_report, predictions)
        
        # Take action based on mode
        self._take_aha_action(snapshot)
    
    def _analyze_health_trends(self, current_report: HealthReport):
        """Analyze health trends and generate alerts"""
        
        if len(self.health_history) < 2:
            return
        
        # Calculate trend
        recent_scores = [r.metrics['health_score'] for r in self.health_history[-5:]]
        trend = self._calculate_trend(recent_scores)
        
        # Check for degradation alerts
        if trend == HealthTrend.DEGRADING:
            self._create_trend_alert("health_degradation", 
                                   "System health is degrading", 
                                   recent_scores)
        
        # Check for critical threshold alerts
        if current_report.metrics['health_score'] < self.alert_thresholds['health_score_critical']:
            self._create_threshold_alert("critical_health_threshold",
                                       "System health below critical threshold",
                                       current_report.metrics['health_score'])
        
        # Check for violation increase alerts
        if len(self.health_history) >= 2:
            prev_violations = self.health_history[-2].metrics['total_violations']
            curr_violations = current_report.metrics['total_violations']
            
            if curr_violations > prev_violations * (1 + self.alert_thresholds['violation_increase_threshold']):
                self._create_violation_alert("violation_increase",
                                           f"Violations increased from {prev_violations} to {curr_violations}")
    
    def _calculate_trend(self, scores: List[float]) -> HealthTrend:
        """Calculate health trend from recent scores"""
        if len(scores) < 2:
            return HealthTrend.STABLE
        
        # Calculate slope
        x = list(range(len(scores)))
        slope = self._calculate_slope(x, scores)
        
        if slope > self.alert_thresholds['trend_degradation_threshold']:
            return HealthTrend.IMPROVING
        elif slope < -self.alert_thresholds['trend_degradation_threshold']:
            return HealthTrend.DEGRADING
        else:
            return HealthTrend.STABLE
    
    def _calculate_slope(self, x: List[float], y: List[float]) -> float:
        """Calculate linear regression slope"""
        n = len(x)
        if n < 2:
            return 0.0
        
        sum_x = sum(x)
        sum_y = sum(y)
        sum_xy = sum(x[i] * y[i] for i in range(n))
        sum_xx = sum(x[i] * x[i] for i in range(n))
        
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_xx - sum_x * sum_x)
        return slope
    
    def _create_trend_alert(self, category: str, title: str, data: List[float]):
        """Create trend-based alert"""
        alert = AHAAlert(
            alert_id=f"trend_{int(time.time())}",
            timestamp=datetime.now(),
            severity=HealthStatus.WARNING,
            category=category,
            title=title,
            description=f"Health trend analysis shows degradation. Recent scores: {data}",
            recommendations=[
                "Review recent code changes for architectural violations",
                "Run detailed health analysis",
                "Consider architectural refactoring"
            ],
            auto_fixable=False,
            impact_score=0.7,
            affected_files=[]
        )
        
        self.alerts.append(alert)
        self._trigger_alert_callbacks(alert)
    
    def _create_threshold_alert(self, category: str, title: str, health_score: float):
        """Create threshold-based alert"""
        alert = AHAAlert(
            alert_id=f"threshold_{int(time.time())}",
            timestamp=datetime.now(),
            severity=HealthStatus.CRITICAL,
            category=category,
            title=title,
            description=f"System health score {health_score:.2f} below critical threshold",
            recommendations=[
                "Immediate architectural review required",
                "Consider emergency intervention",
                "Review all recent changes"
            ],
            auto_fixable=False,
            impact_score=0.9,
            affected_files=[]
        )
        
        self.alerts.append(alert)
        self._trigger_alert_callbacks(alert)
    
    def _create_violation_alert(self, category: str, title: str):
        """Create violation-based alert"""
        alert = AHAAlert(
            alert_id=f"violation_{int(time.time())}",
            timestamp=datetime.now(),
            severity=HealthStatus.WARNING,
            category=category,
            title=title,
            description="Significant increase in health violations detected",
            recommendations=[
                "Review recent code changes",
                "Check for new circular dependencies",
                "Validate import patterns"
            ],
            auto_fixable=False,
            impact_score=0.6,
            affected_files=[]
        )
        
        self.alerts.append(alert)
        self._trigger_alert_callbacks(alert)
    
    def _generate_health_predictions(self) -> Dict[str, Any]:
        """Generate health predictions based on trends"""
        if len(self.health_history) < 3:
            return {"prediction": "insufficient_data"}
        
        # Simple linear prediction
        recent_scores = [r.metrics['health_score'] for r in self.health_history[-3:]]
        trend = self._calculate_trend(recent_scores)
        
        # Predict next 3 health scores
        predictions = []
        current_score = recent_scores[-1]
        
        for i in range(1, 4):
            predicted_score = current_score + (trend * i * 0.1)  # Simple linear prediction
            predicted_score = max(0.0, min(1.0, predicted_score))  # Clamp to [0, 1]
            predictions.append(predicted_score)
        
        return {
            "trend": trend.value,
            "predictions": predictions,
            "confidence": 0.7 if len(recent_scores) >= 5 else 0.5
        }
    
    def _create_health_snapshot(self, health_report: HealthReport, predictions: Dict[str, Any]) -> AHAHealthSnapshot:
        """Create comprehensive health snapshot"""
        recent_scores = [r.metrics['health_score'] for r in self.health_history[-5:]]
        trend = self._calculate_trend(recent_scores)
        
        return AHAHealthSnapshot(
            timestamp=datetime.now(),
            overall_health_score=health_report.metrics['health_score'],
            trend=trend,
            alerts=self.alerts[-10:],  # Last 10 alerts
            metrics=health_report.metrics,
            predictions=predictions
        )
    
    def _take_aha_action(self, snapshot: AHAHealthSnapshot):
        """Take action based on AHA mode and health snapshot"""
        
        if self.mode == AHAMode.PASSIVE:
            # Only log, no interventions
            logger.info(f"AHA Passive Mode: Health score {snapshot.overall_health_score:.2f}")
            return
        
        # Check for critical conditions
        if snapshot.overall_health_score < self.alert_thresholds['health_score_critical']:
            if self.mode == AHAMode.AGGRESSIVE:
                self._attempt_auto_fix(snapshot)
            else:
                logger.warning("AHA Active Mode: Critical health detected - manual intervention required")
        
        # Check for degradation trends
        if snapshot.trend == HealthTrend.DEGRADING:
            logger.warning("AHA System: Health degradation detected - proactive intervention recommended")
    
    def _attempt_auto_fix(self, snapshot: AHAHealthSnapshot):
        """Attempt automatic fixes for critical issues"""
        logger.info("🔧 AHA Aggressive Mode: Attempting auto-fix")
        
        # This would implement specific auto-fix strategies
        # For now, just log the attempt
        logger.info("Auto-fix strategies would be implemented here")
    
    def _trigger_alert_callbacks(self, alert: AHAAlert):
        """Trigger external alert callbacks"""
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                logger.error(f"Error in alert callback: {e}")
    
    def add_alert_callback(self, callback: Callable[[AHAAlert], None]):
        """Add external alert callback"""
        self.alert_callbacks.append(callback)
    
    def add_intervention_callback(self, callback: Callable[[AHAAlert], bool]):
        """Add external intervention callback"""
        self.intervention_callbacks.append(callback)
    
    def get_health_dashboard(self) -> Dict[str, Any]:
        """Get comprehensive health dashboard data"""
        if not self.health_history:
            return {"status": "no_data"}
        
        latest_report = self.health_history[-1]
        recent_scores = [r.metrics['health_score'] for r in self.health_history[-10:]]
        trend = self._calculate_trend(recent_scores)
        
        return {
            "current_health_score": latest_report.metrics['health_score'],
            "trend": trend.value,
            "total_violations": latest_report.metrics['total_violations'],
            "critical_violations": latest_report.metrics['critical_violations'],
            "recent_alerts": len(self.alerts[-5:]),
            "health_history": recent_scores,
            "mode": self.mode.value,
            "monitoring_active": self.monitoring_active
        }


class AHAFileHandler(FileSystemEventHandler):
    """File system event handler for immediate alerts"""
    
    def __init__(self, aha_monitor: AHAMonitor):
        self.aha_monitor = aha_monitor
        self.last_check = datetime.now()
        self.check_interval = 30  # Check every 30 seconds
    
    def on_modified(self, event):
        """Handle file modification events"""
        if event.is_directory:
            return
        
        if not event.src_path.endswith('.py'):
            return
        
        # Throttle checks
        now = datetime.now()
        if (now - self.last_check).seconds < self.check_interval:
            return
        
        self.last_check = now
        
        # Trigger immediate health check for critical files
        if self._is_critical_file(event.src_path):
            logger.info(f"AHA File Monitor: Critical file modified - {event.src_path}")
            self._trigger_immediate_check()
    
    def _is_critical_file(self, file_path: str) -> bool:
        """Check if file is critical for health monitoring"""
        critical_patterns = [
            'orchestrator',
            'datamart',
            'coordinator',
            '__init__.py'
        ]
        
        return any(pattern in file_path.lower() for pattern in critical_patterns)
    
    def _trigger_immediate_check(self):
        """Trigger immediate health check"""
        # Run in separate thread to avoid blocking file operations
        def immediate_check():
            try:
                self.aha_monitor._run_health_check()
            except Exception as e:
                logger.error(f"Immediate health check error: {e}")
        
        threading.Thread(target=immediate_check, daemon=True).start()


class AHADashboard:
    """AHA system dashboard and reporting"""
    
    def __init__(self, aha_monitor: AHAMonitor):
        self.aha_monitor = aha_monitor
    
    def generate_health_report(self) -> str:
        """Generate human-readable health report"""
        dashboard = self.aha_monitor.get_health_dashboard()
        
        if dashboard.get("status") == "no_data":
            return "AHA System: No health data available"
        
        report = f"""
🏥 AHA System Health Report
{'=' * 50}
Current Health Score: {dashboard['current_health_score']:.2f}
Trend: {dashboard['trend'].upper()}
Mode: {dashboard['mode'].upper()}
Monitoring: {'ACTIVE' if dashboard['monitoring_active'] else 'INACTIVE'}

Violations:
  Total: {dashboard['total_violations']}
  Critical: {dashboard['critical_violations']}

Recent Activity:
  Alerts (last 5): {dashboard['recent_alerts']}
  Health History: {[f'{score:.2f}' for score in dashboard['health_history']]}

Status: {'🟢 HEALTHY' if dashboard['current_health_score'] > 0.7 else '🟡 WARNING' if dashboard['current_health_score'] > 0.5 else '🔴 CRITICAL'}
"""
        return report
    
    def export_health_data(self, format: str = 'json') -> str:
        """Export health data in specified format"""
        dashboard = self.aha_monitor.get_health_dashboard()
        
        if format.lower() == 'json':
            return json.dumps(dashboard, indent=2, default=str)
        elif format.lower() == 'csv':
            # Convert to CSV format
            return self._convert_to_csv(dashboard)
        else:
            return "Unsupported format"
    
    def _convert_to_csv(self, data: Dict[str, Any]) -> str:
        """Convert dashboard data to CSV format"""
        csv_lines = []
        
        # Add headers
        csv_lines.append("metric,value")
        
        # Add data
        for key, value in data.items():
            if isinstance(value, list):
                csv_lines.append(f"{key},{','.join(map(str, value))}")
            else:
                csv_lines.append(f"{key},{value}")
        
        return '\n'.join(csv_lines)


def main():
    """Main entry point for AHA System"""
    import sys
    
    if len(sys.argv) > 1:
        codebase_root = sys.argv[1]
    else:
        codebase_root = "."
    
    # Initialize AHA System
    aha_monitor = AHAMonitor(codebase_root, mode=AHAMode.ACTIVE)
    dashboard = AHADashboard(aha_monitor)
    
    # Start monitoring
    aha_monitor.start_monitoring()
    
    try:
        # Run for a period or until interrupted
        print("🚀 AHA System started. Press Ctrl+C to stop.")
        
        while True:
            time.sleep(60)  # Update every minute
            print(dashboard.generate_health_report())
            
    except KeyboardInterrupt:
        print("\n🛑 Stopping AHA System...")
        aha_monitor.stop_monitoring()
        print("✅ AHA System stopped")


if __name__ == "__main__":
    main()
