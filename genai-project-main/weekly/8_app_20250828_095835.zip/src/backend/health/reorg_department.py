#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
REORG Department - Automated Architectural Health Monitoring

This system continuously monitors the codebase for unhealthy patterns that lead to:
- Circular dependencies
- Import chain violations
- Architecture degradation
- System fragility

Prevents the need for major reorganizations by catching issues early.
"""

import os
import ast
import importlib
import logging
import json
from pathlib import Path
from typing import Dict, List, Set, Tuple, Any
from dataclasses import dataclass
from datetime import datetime
from enum import Enum
import networkx as nx
import fnmatch

logger = logging.getLogger(__name__)


class HealthStatus(Enum):
    """Health status levels"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    EMERGENCY = "emergency"


@dataclass
class HealthViolation:
    """Represents a health violation found in the codebase"""
    pattern_type: str
    severity: HealthStatus
    file_path: str
    line_number: int
    description: str
    recommendation: str
    impact_score: float  # 0.0 to 1.0


@dataclass
class HealthReport:
    """Comprehensive health report"""
    timestamp: datetime
    overall_status: HealthStatus
    violations: List[HealthViolation]
    metrics: Dict[str, Any]
    recommendations: List[str]


class UnhealthyPatternDetector:
    """Detects unhealthy architectural patterns"""
    
    def __init__(self, codebase_root: str):
        self.codebase_root = Path(codebase_root)
        self.violations: List[HealthViolation] = []
        self.gitignore_patterns = self._load_gitignore_patterns()
    
    def _load_gitignore_patterns(self) -> List[str]:
        """Load .gitignore patterns to determine scan scope."""
        gitignore_path = self.codebase_root / '.gitignore'
        patterns = []
        
        if gitignore_path.exists():
            try:
                with open(gitignore_path, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            patterns.append(line)
                logger.info(f"Loaded {len(patterns)} .gitignore patterns")
            except Exception as e:
                logger.warning(f"Could not load .gitignore: {e}")
        
        return patterns
    
    def _should_ignore_file(self, file_path: Path) -> bool:
        """Check if file should be ignored based on .gitignore patterns."""
        # Convert to relative path from codebase root
        try:
            rel_path = file_path.relative_to(self.codebase_root)
        except ValueError:
            # File is outside codebase root
            return True
        
        rel_path_str = str(rel_path)
        
        # Check each .gitignore pattern
        for pattern in self.gitignore_patterns:
            # Handle directory patterns (ending with /)
            if pattern.endswith('/'):
                if rel_path_str.startswith(pattern) or rel_path_str.startswith(pattern[:-1]):
                    return True
            
            # Handle file patterns
            elif fnmatch.fnmatch(rel_path_str, pattern):
                return True
            
            # Handle patterns that should match anywhere in path
            elif fnmatch.fnmatch(rel_path_str, f"*/{pattern}"):
                return True
            
            # Handle specific directory matches
            elif pattern in rel_path_str.split('/'):
                return True
        
        # Additional hardcoded ignores for common problematic directories
        hardcoded_ignores = [
            'migration_bundles',
            'data/',
            'logs/',
            'tests/',
            'archive/',
            'optional/',
            'environ_settings/',
            'deployment_packages/',
            'knowledge_base/',
            'llm_cache/',
            'llm_metrics/',
            'mlruns/',
            '__pycache__',
            '.pytest_cache',
            'node_modules',
            'venv',
            '.venv',
            'env',
            '.env'
        ]
        
        for ignore_pattern in hardcoded_ignores:
            if ignore_pattern in rel_path_str:
                return True
        
        return False
        
    def scan_codebase(self) -> HealthReport:
        """Perform comprehensive health scan"""
        logger.info("🏥 REORG Department: Starting comprehensive health scan")
        
        # Reset violations
        self.violations = []
        
        # Run all pattern detectors
        self._detect_circular_dependencies()
        self._detect_import_violations()
        self._detect_architecture_violations()
        self._detect_code_quality_issues()
        self._detect_performance_antipatterns()
        
        # Generate report
        return self._generate_health_report()
    
    def _detect_circular_dependencies(self):
        """Detect circular import dependencies"""
        logger.info("🔍 Scanning for circular dependencies...")
        
        # Build import graph
        import_graph = self._build_import_graph()
        
        # Find cycles
        try:
            cycles = list(nx.simple_cycles(import_graph))
            
            for cycle in cycles:
                if len(cycle) > 2:  # Only report meaningful cycles
                    self.violations.append(HealthViolation(
                        pattern_type="circular_dependency",
                        severity=HealthStatus.CRITICAL,
                        file_path=", ".join(cycle),
                        line_number=0,
                        description=f"Circular dependency detected: {' → '.join(cycle)}",
                        recommendation="Extract shared functionality to separate modules",
                        impact_score=0.9
                    ))
        except Exception as e:
            logger.error(f"Error detecting cycles: {e}")
    
    def _detect_import_violations(self):
        """Detect import pattern violations"""
        logger.info("🔍 Scanning for import violations...")
        
        for py_file in self.codebase_root.rglob("*.py"):
            # Skip files that should be ignored
            if self._should_ignore_file(py_file):
                continue
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                # Parse AST
                tree = ast.parse(content)
                
                # Check for relative import violations
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom):
                        if node.level > 2:  # Too many relative levels
                            self.violations.append(HealthViolation(
                                pattern_type="deep_relative_import",
                                severity=HealthStatus.WARNING,
                                file_path=str(py_file),
                                line_number=node.lineno,
                                description=f"Deep relative import: {'.' * node.level}",
                                recommendation="Use absolute imports or restructure modules",
                                impact_score=0.6
                            ))
                
                # Check for wildcard imports
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom) and node.names[0].name == '*':
                        self.violations.append(HealthViolation(
                            pattern_type="wildcard_import",
                            severity=HealthStatus.WARNING,
                            file_path=str(py_file),
                            line_number=node.lineno,
                            description="Wildcard import detected",
                            recommendation="Import specific modules instead of using *",
                            impact_score=0.4
                        ))
                        
            except Exception as e:
                logger.error(f"Error parsing {py_file}: {e}")
    
    def _detect_architecture_violations(self):
        """Detect architecture pattern violations"""
        logger.info("🔍 Scanning for architecture violations...")
        
        # Check for orchestrator violations
        for py_file in self.codebase_root.rglob("*orchestrator*.py"):
            # Skip files that should be ignored
            if self._should_ignore_file(py_file):
                continue
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                # Check for direct coordinator instantiation
                if "self.coordinator = " in content and "Coordinator()" in content:
                    self.violations.append(HealthViolation(
                        pattern_type="direct_coordinator_instantiation",
                        severity=HealthStatus.CRITICAL,
                        file_path=str(py_file),
                        line_number=0,
                        description="Orchestrator directly instantiating coordinators",
                        recommendation="Use dependency injection or factory pattern",
                        impact_score=0.8
                    ))
                
                # Check for bypassing planning layer
                if "self.worker = " in content and "Worker()" in content:
                    self.violations.append(HealthViolation(
                        pattern_type="bypass_planning_layer",
                        severity=HealthStatus.CRITICAL,
                        file_path=str(py_file),
                        line_number=0,
                        description="Orchestrator bypassing planning layer",
                        recommendation="Route through proper MCP hierarchy",
                        impact_score=0.8
                    ))
                        
            except Exception as e:
                logger.error(f"Error checking {py_file}: {e}")
    
    def _detect_code_quality_issues(self):
        """Detect code quality issues that lead to architectural problems"""
        logger.info("🔍 Scanning for code quality issues...")
        
        for py_file in self.codebase_root.rglob("*.py"):
            # Skip files that should be ignored
            if self._should_ignore_file(py_file):
                continue
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                # Check for large files (potential god objects)
                if len(content.split('\n')) > 500:
                    self.violations.append(HealthViolation(
                        pattern_type="large_file",
                        severity=HealthStatus.WARNING,
                        file_path=str(py_file),
                        line_number=0,
                        description=f"Large file: {len(content.split('\n'))} lines",
                        recommendation="Consider breaking into smaller modules",
                        impact_score=0.5
                    ))
                
                # Check for multiple responsibilities
                class_count = content.count('class ')
                if class_count > 3:
                    self.violations.append(HealthViolation(
                        pattern_type="multiple_responsibilities",
                        severity=HealthStatus.WARNING,
                        file_path=str(py_file),
                        line_number=0,
                        description=f"Multiple classes in single file: {class_count}",
                        recommendation="Consider single responsibility principle",
                        impact_score=0.4
                    ))
                        
            except Exception as e:
                logger.error(f"Error checking {py_file}: {e}")
    
    def _detect_performance_antipatterns(self):
        """Detect performance antipatterns that indicate architectural issues"""
        logger.info("🔍 Scanning for performance antipatterns...")
        
        for py_file in self.codebase_root.rglob("*.py"):
            # Skip files that should be ignored
            if self._should_ignore_file(py_file):
                continue
            try:
                with open(py_file, 'r') as f:
                    content = f.read()
                
                # Check for heavy imports in frequently used modules
                if "import numpy" in content and "orchestrator" in str(py_file):
                    self.violations.append(HealthViolation(
                        pattern_type="heavy_import_in_orchestrator",
                        severity=HealthStatus.WARNING,
                        file_path=str(py_file),
                        line_number=0,
                        description="Heavy import in orchestrator layer",
                        recommendation="Move heavy imports to worker layer",
                        impact_score=0.6
                    ))
                        
            except Exception as e:
                logger.error(f"Error checking {py_file}: {e}")
    
    def _build_import_graph(self) -> nx.DiGraph:
        """Build directed graph of import dependencies"""
        graph = nx.DiGraph()
        
        for py_file in self.codebase_root.rglob("*.py"):
            # Skip files that should be ignored
            if self._should_ignore_file(py_file):
                continue
            try:
                module_name = self._get_module_name(py_file)
                graph.add_node(module_name)
                
                # Parse imports
                with open(py_file, 'r') as f:
                    content = f.read()
                
                tree = ast.parse(content)
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom):
                        if node.module:
                            imported_module = node.module
                            graph.add_edge(module_name, imported_module)
                            
            except Exception as e:
                logger.error(f"Error building import graph for {py_file}: {e}")
        
        return graph
    
    def _get_module_name(self, file_path: Path) -> str:
        """Convert file path to module name"""
        relative_path = file_path.relative_to(self.codebase_root)
        return str(relative_path).replace('/', '.').replace('.py', '')
    
    def _generate_health_report(self) -> HealthReport:
        """Generate comprehensive health report"""
        
        # Calculate overall status
        if any(v.severity == HealthStatus.EMERGENCY for v in self.violations):
            overall_status = HealthStatus.EMERGENCY
        elif any(v.severity == HealthStatus.CRITICAL for v in self.violations):
            overall_status = HealthStatus.CRITICAL
        elif any(v.severity == HealthStatus.WARNING for v in self.violations):
            overall_status = HealthStatus.WARNING
        else:
            overall_status = HealthStatus.HEALTHY
        
        # Calculate metrics
        metrics = {
            'total_violations': len(self.violations),
            'critical_violations': len([v for v in self.violations if v.severity == HealthStatus.CRITICAL]),
            'warning_violations': len([v for v in self.violations if v.severity == HealthStatus.WARNING]),
            'average_impact_score': sum(v.impact_score for v in self.violations) / len(self.violations) if self.violations else 0.0,
            'health_score': max(0.0, 1.0 - sum(v.impact_score for v in self.violations) / len(self.violations)) if self.violations else 1.0
        }
        
        # Generate recommendations
        recommendations = self._generate_recommendations()
        
        return HealthReport(
            timestamp=datetime.now(),
            overall_status=overall_status,
            violations=self.violations,
            metrics=metrics,
            recommendations=recommendations
        )
    
    def _generate_recommendations(self) -> List[str]:
        """Generate actionable recommendations"""
        recommendations = []
        
        # Count violation types
        violation_types = {}
        for v in self.violations:
            violation_types[v.pattern_type] = violation_types.get(v.pattern_type, 0) + 1
        
        # Generate specific recommendations
        if violation_types.get('circular_dependency', 0) > 0:
            recommendations.append("🚨 CRITICAL: Circular dependencies detected. Extract shared functionality to separate modules.")
        
        if violation_types.get('direct_coordinator_instantiation', 0) > 0:
            recommendations.append("🔴 HIGH: Orchestrators directly instantiating coordinators. Use dependency injection.")
        
        if violation_types.get('bypass_planning_layer', 0) > 0:
            recommendations.append("🔴 HIGH: Planning layer bypassed. Route through proper MCP hierarchy.")
        
        if violation_types.get('large_file', 0) > 0:
            recommendations.append("🟡 MEDIUM: Large files detected. Consider breaking into smaller modules.")
        
        if violation_types.get('deep_relative_import', 0) > 0:
            recommendations.append("🟡 MEDIUM: Deep relative imports detected. Use absolute imports.")
        
        return recommendations


class ReorgDepartment:
    """Main REORG Department orchestrator"""
    
    def __init__(self, codebase_root: str):
        self.codebase_root = codebase_root
        self.detector = UnhealthyPatternDetector(codebase_root)
        self.health_history: List[HealthReport] = []
        
    def run_health_check(self) -> HealthReport:
        """Run comprehensive health check"""
        logger.info("🏥 REORG Department: Running health check")
        
        report = self.detector.scan_codebase()
        self.health_history.append(report)
        
        # Log results
        self._log_health_report(report)
        
        # Take action based on severity
        self._take_action(report)
        
        return report
    
    def _log_health_report(self, report: HealthReport):
        """Log health report results"""
        logger.info(f"🏥 Health Check Results:")
        logger.info(f"   Status: {report.overall_status.value}")
        logger.info(f"   Violations: {report.metrics['total_violations']}")
        logger.info(f"   Health Score: {report.metrics['health_score']:.2f}")
        
        if report.violations:
            logger.warning("🚨 Violations Found:")
            for v in report.violations:
                logger.warning(f"   {v.severity.value.upper()}: {v.pattern_type} - {v.description}")
        
        if report.recommendations:
            logger.info("💡 Recommendations:")
            for rec in report.recommendations:
                logger.info(f"   {rec}")
    
    def _take_action(self, report: HealthReport):
        """Take action based on health report severity"""
        
        if report.overall_status == HealthStatus.EMERGENCY:
            logger.critical("🚨 EMERGENCY: Immediate intervention required!")
            self._emergency_intervention(report)
            
        elif report.overall_status == HealthStatus.CRITICAL:
            logger.error("🔴 CRITICAL: System health compromised!")
            self._critical_intervention(report)
            
        elif report.overall_status == HealthStatus.WARNING:
            logger.warning("🟡 WARNING: System health degrading!")
            self._warning_intervention(report)
            
        else:
            logger.info("✅ HEALTHY: System architecture is sound!")
    
    def _emergency_intervention(self, report: HealthReport):
        """Emergency intervention for critical issues"""
        # Could trigger alerts, create emergency tickets, etc.
        logger.critical("🚨 EMERGENCY INTERVENTION: Creating emergency ticket")
        
    def _critical_intervention(self, report: HealthReport):
        """Critical intervention for serious issues"""
        # Could create high-priority tickets, send notifications
        logger.error("🔴 CRITICAL INTERVENTION: Creating high-priority ticket")
        
    def _warning_intervention(self, report: HealthReport):
        """Warning intervention for minor issues"""
        # Could create regular tickets, send notifications
        logger.warning("🟡 WARNING INTERVENTION: Creating regular ticket")
    
    def get_health_trends(self) -> Dict[str, Any]:
        """Analyze health trends over time"""
        if len(self.health_history) < 2:
            return {"trend": "insufficient_data"}
        
        recent_scores = [r.metrics['health_score'] for r in self.health_history[-5:]]
        
        if len(recent_scores) >= 2:
            trend = "improving" if recent_scores[-1] > recent_scores[0] else "degrading"
        else:
            trend = "stable"
        
        return {
            "trend": trend,
            "recent_scores": recent_scores,
            "average_score": sum(recent_scores) / len(recent_scores)
        }


def main():
    """Main entry point for REORG Department"""
    import sys
    
    if len(sys.argv) > 1:
        codebase_root = sys.argv[1]
    else:
        codebase_root = "."
    
    # Initialize REORG Department
    reorg_dept = ReorgDepartment(codebase_root)
    
    # Run health check
    report = reorg_dept.run_health_check()
    
    # Print summary
    print(f"\n🏥 REORG Department Health Check Summary")
    print(f"Status: {report.overall_status.value.upper()}")
    print(f"Health Score: {report.metrics['health_score']:.2f}")
    print(f"Violations: {report.metrics['total_violations']}")
    
    if report.violations:
        print(f"\n🚨 Violations Found:")
        for v in report.violations:
            print(f"  {v.severity.value.upper()}: {v.pattern_type}")
            print(f"    {v.description}")
            print(f"    Recommendation: {v.recommendation}")
            print()
    
    if report.recommendations:
        print(f"💡 Recommendations:")
        for rec in report.recommendations:
            print(f"  {rec}")


if __name__ == "__main__":
    main()
