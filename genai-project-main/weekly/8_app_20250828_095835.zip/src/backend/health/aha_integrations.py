#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AHA System Integrations

Integration components for connecting AHA with:
- Development workflows (Git hooks, IDE plugins)
- CI/CD pipelines (GitHub Actions, Jenkins)
- External monitoring (Slack, email, ticketing systems)
- Development tools (VS Code, PyCharm)
"""

import os
import json
import logging
import subprocess
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from .aha_system import AHAMonitor, AHAAlert, AHAMode, HealthStatus

logger = logging.getLogger(__name__)


class AHAIntegrationManager:
    """Manages AHA system integrations"""
    
    def __init__(self, aha_monitor: AHAMonitor):
        self.aha_monitor = aha_monitor
        self.integrations = {}
        
        # Register default integrations
        self._register_default_integrations()
    
    def _register_default_integrations(self):
        """Register default integration handlers"""
        self.register_integration("slack", SlackIntegration())
        self.register_integration("email", EmailIntegration())
        self.register_integration("jira", JiraIntegration())
        self.register_integration("github", GitHubIntegration())
        self.register_integration("git_hook", GitHookIntegration())
    
    def register_integration(self, name: str, integration):
        """Register an integration"""
        self.integrations[name] = integration
        logger.info(f"AHA Integration: Registered {name}")
    
    def handle_alert(self, alert: AHAAlert):
        """Handle alerts through all registered integrations"""
        for name, integration in self.integrations.items():
            try:
                if hasattr(integration, 'handle_alert'):
                    integration.handle_alert(alert)
                logger.info(f"AHA Integration: {name} handled alert {alert.alert_id}")
            except Exception as e:
                logger.error(f"AHA Integration: {name} failed to handle alert: {e}")


class SlackIntegration:
    """Slack integration for AHA alerts"""
    
    def __init__(self, webhook_url: Optional[str] = None):
        self.webhook_url = webhook_url or os.getenv('SLACK_WEBHOOK_URL')
    
    def handle_alert(self, alert: AHAAlert):
        """Send alert to Slack"""
        if not self.webhook_url:
            logger.warning("Slack webhook URL not configured")
            return
        
        message = self._format_slack_message(alert)
        self._send_slack_message(message)
    
    def _format_slack_message(self, alert: AHAAlert) -> Dict[str, Any]:
        """Format alert for Slack"""
        color_map = {
            HealthStatus.EMERGENCY: "#FF0000",
            HealthStatus.CRITICAL: "#FF6B6B",
            HealthStatus.WARNING: "#FFA500",
            HealthStatus.HEALTHY: "#00FF00"
        }
        
        return {
            "attachments": [{
                "color": color_map.get(alert.severity, "#808080"),
                "title": f"🚨 AHA Alert: {alert.title}",
                "text": alert.description,
                "fields": [
                    {
                        "title": "Severity",
                        "value": alert.severity.value.upper(),
                        "short": True
                    },
                    {
                        "title": "Category",
                        "value": alert.category,
                        "short": True
                    },
                    {
                        "title": "Impact Score",
                        "value": f"{alert.impact_score:.2f}",
                        "short": True
                    },
                    {
                        "title": "Auto-fixable",
                        "value": "Yes" if alert.auto_fixable else "No",
                        "short": True
                    }
                ],
                "footer": f"AHA System • {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')}"
            }]
        }
    
    def _send_slack_message(self, message: Dict[str, Any]):
        """Send message to Slack"""
        import requests
        
        try:
            response = requests.post(
                self.webhook_url,
                json=message,
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            logger.info("Slack message sent successfully")
        except Exception as e:
            logger.error(f"Failed to send Slack message: {e}")


class EmailIntegration:
    """Email integration for AHA alerts"""
    
    def __init__(self, smtp_config: Optional[Dict[str, str]] = None):
        self.smtp_config = smtp_config or {
            'host': os.getenv('SMTP_HOST', 'localhost'),
            'port': int(os.getenv('SMTP_PORT', '587')),
            'username': os.getenv('SMTP_USERNAME'),
            'password': os.getenv('SMTP_PASSWORD'),
            'from_email': os.getenv('FROM_EMAIL', 'aha@company.com'),
            'to_email': os.getenv('TO_EMAIL', 'dev-team@company.com')
        }
    
    def handle_alert(self, alert: AHAAlert):
        """Send alert via email"""
        if alert.severity in [HealthStatus.EMERGENCY, HealthStatus.CRITICAL]:
            self._send_email(alert)
    
    def _send_email(self, alert: AHAAlert):
        """Send email alert"""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.smtp_config['from_email']
            msg['To'] = self.smtp_config['to_email']
            msg['Subject'] = f"AHA Alert: {alert.title}"
            
            body = self._format_email_body(alert)
            msg.attach(MIMEText(body, 'html'))
            
            with smtplib.SMTP(self.smtp_config['host'], self.smtp_config['port']) as server:
                if self.smtp_config.get('username'):
                    server.starttls()
                    server.login(self.smtp_config['username'], self.smtp_config['password'])
                server.send_message(msg)
            
            logger.info("Email alert sent successfully")
            
        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")
    
    def _format_email_body(self, alert: AHAAlert) -> str:
        """Format email body"""
        return f"""
        <html>
        <body>
            <h2>🚨 AHA System Alert</h2>
            <h3>{alert.title}</h3>
            <p><strong>Severity:</strong> {alert.severity.value.upper()}</p>
            <p><strong>Category:</strong> {alert.category}</p>
            <p><strong>Description:</strong> {alert.description}</p>
            <p><strong>Impact Score:</strong> {alert.impact_score:.2f}</p>
            
            <h4>Recommendations:</h4>
            <ul>
                {''.join(f'<li>{rec}</li>' for rec in alert.recommendations)}
            </ul>
            
            <p><em>Generated by AHA System at {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')}</em></p>
        </body>
        </html>
        """


class JiraIntegration:
    """Jira integration for creating tickets from AHA alerts"""
    
    def __init__(self, jira_config: Optional[Dict[str, str]] = None):
        self.jira_config = jira_config or {
            'url': os.getenv('JIRA_URL'),
            'username': os.getenv('JIRA_USERNAME'),
            'api_token': os.getenv('JIRA_API_TOKEN'),
            'project_key': os.getenv('JIRA_PROJECT_KEY', 'AHA')
        }
    
    def handle_alert(self, alert: AHAAlert):
        """Create Jira ticket for alert"""
        if alert.severity in [HealthStatus.EMERGENCY, HealthStatus.CRITICAL]:
            self._create_jira_ticket(alert)
    
    def _create_jira_ticket(self, alert: AHAAlert):
        """Create Jira ticket"""
        try:
            import requests
            
            issue_data = {
                "fields": {
                    "project": {"key": self.jira_config['project_key']},
                    "summary": f"AHA Alert: {alert.title}",
                    "description": self._format_jira_description(alert),
                    "issuetype": {"name": "Bug" if alert.severity in [HealthStatus.EMERGENCY, HealthStatus.CRITICAL] else "Task"},
                    "priority": {"name": "Highest" if alert.severity == HealthStatus.EMERGENCY else "High" if alert.severity == HealthStatus.CRITICAL else "Medium"},
                    "labels": ["aha-system", alert.category]
                }
            }
            
            auth = (self.jira_config['username'], self.jira_config['api_token'])
            response = requests.post(
                f"{self.jira_config['url']}/rest/api/2/issue",
                json=issue_data,
                auth=auth,
                headers={'Content-Type': 'application/json'}
            )
            response.raise_for_status()
            
            issue_key = response.json()['key']
            logger.info(f"Jira ticket created: {issue_key}")
            
        except Exception as e:
            logger.error(f"Failed to create Jira ticket: {e}")
    
    def _format_jira_description(self, alert: AHAAlert) -> str:
        """Format Jira ticket description"""
        return f"""
        *AHA System Alert*

        *Severity:* {alert.severity.value.upper()}
        *Category:* {alert.category}
        *Impact Score:* {alert.impact_score:.2f}
        *Auto-fixable:* {'Yes' if alert.auto_fixable else 'No'}

        *Description:*
        {alert.description}

        *Recommendations:*
        {chr(10).join(f'* {rec}' for rec in alert.recommendations)}

        *Affected Files:*
        {chr(10).join(f'* {file}' for file in alert.affected_files) if alert.affected_files else '* None specified*'}

        *Generated:* {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
        """


class GitHubIntegration:
    """GitHub integration for AHA alerts"""
    
    def __init__(self, github_config: Optional[Dict[str, str]] = None):
        self.github_config = github_config or {
            'token': os.getenv('GITHUB_TOKEN'),
            'repo': os.getenv('GITHUB_REPO'),
            'owner': os.getenv('GITHUB_OWNER')
        }
    
    def handle_alert(self, alert: AHAAlert):
        """Create GitHub issue for alert"""
        if alert.severity in [HealthStatus.EMERGENCY, HealthStatus.CRITICAL]:
            self._create_github_issue(alert)
    
    def _create_github_issue(self, alert: AHAAlert):
        """Create GitHub issue"""
        try:
            import requests
            
            issue_data = {
                "title": f"AHA Alert: {alert.title}",
                "body": self._format_github_description(alert),
                "labels": ["aha-system", alert.category, alert.severity.value]
            }
            
            headers = {
                'Authorization': f'token {self.github_config["token"]}',
                'Accept': 'application/vnd.github.v3+json'
            }
            
            response = requests.post(
                f"https://api.github.com/repos/{self.github_config['owner']}/{self.github_config['repo']}/issues",
                json=issue_data,
                headers=headers
            )
            response.raise_for_status()
            
            issue_number = response.json()['number']
            logger.info(f"GitHub issue created: #{issue_number}")
            
        except Exception as e:
            logger.error(f"Failed to create GitHub issue: {e}")
    
    def _format_github_description(self, alert: AHAAlert) -> str:
        """Format GitHub issue description"""
        return f"""
        ## AHA System Alert

        **Severity:** {alert.severity.value.upper()}
        **Category:** {alert.category}
        **Impact Score:** {alert.impact_score:.2f}
        **Auto-fixable:** {'Yes' if alert.auto_fixable else 'No'}

        ### Description
        {alert.description}

        ### Recommendations
        {chr(10).join(f'- {rec}' for rec in alert.recommendations)}

        ### Affected Files
        {chr(10).join(f'- {file}' for file in alert.affected_files) if alert.affected_files else '- None specified'}

        ---
        *Generated by AHA System at {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')}*
        """


class GitHookIntegration:
    """Git hook integration for pre-commit health checks"""
    
    def __init__(self, aha_monitor: AHAMonitor):
        self.aha_monitor = aha_monitor
    
    def setup_pre_commit_hook(self, repo_path: str):
        """Setup pre-commit hook"""
        hook_path = Path(repo_path) / '.git' / 'hooks' / 'pre-commit'
        
        hook_content = f"""#!/bin/bash
# AHA System Pre-commit Hook

echo "🔍 AHA System: Running pre-commit health check..."

# Run AHA health check
python -c "
import sys
sys.path.append('src')
from backend.health.aha_system import AHAMonitor, AHAMode

monitor = AHAMonitor('.', mode=AHAMode.PASSIVE)
report = monitor.reorg_dept.run_health_check()

if report.overall_status.value in ['critical', 'emergency']:
    print('🚨 AHA System: Critical health issues detected!')
    print('Please fix health issues before committing.')
    exit(1)
elif report.overall_status.value == 'warning':
    print('⚠️ AHA System: Health warnings detected.')
    print('Consider addressing health issues.')
else:
    print('✅ AHA System: Health check passed.')
"
"""
        
        with open(hook_path, 'w') as f:
            f.write(hook_content)
        
        # Make executable
        os.chmod(hook_path, 0o755)
        logger.info(f"Pre-commit hook installed at {hook_path}")
    
    def run_pre_commit_check(self) -> bool:
        """Run pre-commit health check"""
        try:
            report = self.aha_monitor.reorg_dept.run_health_check()
            
            if report.overall_status.value in ['critical', 'emergency']:
                logger.error("Pre-commit check failed: Critical health issues")
                return False
            elif report.overall_status.value == 'warning':
                logger.warning("Pre-commit check: Health warnings detected")
                return True  # Allow commit but warn
            else:
                logger.info("Pre-commit check passed")
                return True
                
        except Exception as e:
            logger.error(f"Pre-commit check error: {e}")
            return False


class CICDIntegration:
    """CI/CD pipeline integration"""
    
    def __init__(self, aha_monitor: AHAMonitor):
        self.aha_monitor = aha_monitor
    
    def generate_github_action(self, output_path: str = '.github/workflows/aha-health-check.yml'):
        """Generate GitHub Actions workflow"""
        workflow_content = """name: AHA Health Check

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main, develop ]
  schedule:
    - cron: '0 */6 * * *'  # Every 6 hours

jobs:
  aha-health-check:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Set up Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'
    
    - name: Install dependencies
      run: |
        pip install networkx watchdog
    
    - name: Run AHA Health Check
      run: |
        python src/backend/health/aha_system.py .
    
    - name: Upload health report
      uses: actions/upload-artifact@v3
      if: always()
      with:
        name: aha-health-report
        path: aha-health-report.json
    
    - name: Comment PR with health status
      if: github.event_name == 'pull_request'
      uses: actions/github-script@v6
      with:
        script: |
          const fs = require('fs');
          try {
            const report = JSON.parse(fs.readFileSync('aha-health-report.json', 'utf8'));
            const healthScore = report.current_health_score;
            const status = healthScore > 0.7 ? '🟢 HEALTHY' : healthScore > 0.5 ? '🟡 WARNING' : '🔴 CRITICAL';
            
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## AHA Health Check Results\n\n**Status:** ${status}\n**Health Score:** ${healthScore.toFixed(2)}\n\n[View full report](${context.serverUrl}/${context.repo.owner}/${context.repo.repo}/actions/runs/${context.runId})`
            });
          } catch (error) {
            console.log('No health report found');
          }
"""
        
        # Create directory if it doesn't exist
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w') as f:
            f.write(workflow_content)
        
        logger.info(f"GitHub Actions workflow created at {output_path}")
    
    def generate_jenkins_pipeline(self, output_path: str = 'Jenkinsfile'):
        """Generate Jenkins pipeline"""
        pipeline_content = """pipeline {
    agent any
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }
        
        stage('Setup Python') {
            steps {
                sh 'python3 --version'
                sh 'pip3 install networkx watchdog'
            }
        }
        
        stage('AHA Health Check') {
            steps {
                sh 'python3 src/backend/health/aha_system.py .'
            }
            post {
                always {
                    archiveArtifacts artifacts: 'aha-health-report.json', fingerprint: true
                }
            }
        }
        
        stage('Health Analysis') {
            steps {
                script {
                    def report = readJSON file: 'aha-health-report.json'
                    def healthScore = report.current_health_score
                    
                    if (healthScore < 0.5) {
                        error "Critical health issues detected! Health score: ${healthScore}"
                    } else if (healthScore < 0.7) {
                        echo "Health warnings detected. Score: ${healthScore}"
                    } else {
                        echo "System health is good. Score: ${healthScore}"
                    }
                }
            }
        }
    }
    
    post {
        always {
            echo "AHA Health Check completed"
        }
    }
}
"""
        
        with open(output_path, 'w') as f:
            f.write(pipeline_content)
        
        logger.info(f"Jenkins pipeline created at {output_path}")


def main():
    """Main entry point for AHA integrations"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python aha_integrations.py <command> [options]")
        print("Commands:")
        print("  setup-git-hook <repo-path>")
        print("  generate-github-action [output-path]")
        print("  generate-jenkins-pipeline [output-path]")
        return
    
    command = sys.argv[1]
    
    # Initialize AHA monitor
    aha_monitor = AHAMonitor(".", mode=AHAMode.PASSIVE)
    
    if command == "setup-git-hook":
        if len(sys.argv) < 3:
            print("Error: repo-path required")
            return
        
        repo_path = sys.argv[2]
        git_hook = GitHookIntegration(aha_monitor)
        git_hook.setup_pre_commit_hook(repo_path)
        
    elif command == "generate-github-action":
        output_path = sys.argv[2] if len(sys.argv) > 2 else '.github/workflows/aha-health-check.yml'
        cicd = CICDIntegration(aha_monitor)
        cicd.generate_github_action(output_path)
        
    elif command == "generate-jenkins-pipeline":
        output_path = sys.argv[2] if len(sys.argv) > 2 else 'Jenkinsfile'
        cicd = CICDIntegration(aha_monitor)
        cicd.generate_jenkins_pipeline(output_path)
        
    else:
        print(f"Unknown command: {command}")


if __name__ == "__main__":
    main()
