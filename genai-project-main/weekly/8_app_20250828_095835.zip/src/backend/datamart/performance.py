#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
datatable-mart Performance - Performance Monitoring and Optimization

Provides performance monitoring and optimization capabilities for datatable operations.
"""

import logging
import time
import psutil
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class DataMartPerformance:
    """Performance monitoring and optimization for datatable-mart"""
    
    def __init__(self):
        self.performance_id = f"performance_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.metrics_history = []
        self.optimization_recommendations = []
        self.performance_alerts = []
        logger.info(f"DataMart Performance initialized with ID: {self.performance_id}")
    
    def monitor_performance(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Monitor datatable performance metrics"""
        try:
            performance_metrics = {
                'timestamp': datetime.now().isoformat(),
                'performance_id': self.performance_id,
                'system_metrics': self._get_system_metrics(),
                'datatable_metrics': self._get_datatable_metrics(datamart_data),
                'optimization_metrics': self._get_optimization_metrics(datamart_data),
                'alerts': self._check_performance_alerts(datamart_data)
            }
            
            # Store metrics history
            self.metrics_history.append(performance_metrics)
            
            return performance_metrics
            
        except Exception as e:
            logger.error(f"Error monitoring performance: {e}")
            return {"error": str(e)}
    
    def _get_system_metrics(self) -> Dict[str, Any]:
        """Get system performance metrics"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            return {
                'cpu_usage': round(cpu_percent, 2),
                'memory_usage': round(memory.percent, 2),
                'memory_available': round(memory.available / (1024**3), 2),  # GB
                'disk_usage': round(disk.percent, 2),
                'disk_free': round(disk.free / (1024**3), 2),  # GB
                'system_load': self._get_system_load()
            }
        except Exception as e:
            logger.error(f"Error getting system metrics: {e}")
            return {}
    
    def _get_system_load(self) -> Dict[str, Any]:
        """Get system load information"""
        try:
            # Simulate system load calculation
            return {
                'load_1min': 0.5,
                'load_5min': 0.6,
                'load_15min': 0.7,
                'load_status': 'normal'
            }
        except Exception as e:
            logger.error(f"Error getting system load: {e}")
            return {}
    
    def _get_datatable_metrics(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get datatable-specific performance metrics"""
        try:
            total_records = datamart_data.get('total_records', 0)
            total_processing_time = datamart_data.get('total_processing_time', 0.0)
            worker_count = datamart_data.get('worker_count', 1)
            
            # Calculate datatable performance metrics
            records_per_second = total_records / total_processing_time if total_processing_time > 0 else 0
            records_per_worker = total_records / worker_count if worker_count > 0 else 0
            processing_efficiency = records_per_second / worker_count if worker_count > 0 else 0
            
            return {
                'records_per_second': round(records_per_second, 2),
                'records_per_worker': round(records_per_worker, 2),
                'processing_efficiency': round(processing_efficiency, 2),
                'total_records': total_records,
                'total_processing_time': round(total_processing_time, 2),
                'worker_count': worker_count,
                'performance_score': self._calculate_performance_score(records_per_second, processing_efficiency)
            }
        except Exception as e:
            logger.error(f"Error getting datatable metrics: {e}")
            return {}
    
    def _get_optimization_metrics(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get optimization metrics and recommendations"""
        try:
            optimization_metrics = {
                'memory_optimization': self._assess_memory_optimization(datamart_data),
                'processing_optimization': self._assess_processing_optimization(datamart_data),
                'scalability_optimization': self._assess_scalability_optimization(datamart_data),
                'overall_optimization_score': self._calculate_optimization_score(datamart_data)
            }
            
            return optimization_metrics
            
        except Exception as e:
            logger.error(f"Error getting optimization metrics: {e}")
            return {}
    
    def _assess_memory_optimization(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess memory optimization opportunities"""
        try:
            buffer_size = datamart_data.get('buffer_size', 0)
            worker_count = datamart_data.get('worker_count', 1)
            
            memory_per_worker = buffer_size / worker_count if worker_count > 0 else 0
            memory_efficiency = 1.0 / (1.0 + memory_per_worker / 1000)  # Normalize
            
            recommendations = []
            if memory_per_worker > 1000:
                recommendations.append("Consider reducing buffer size per worker")
            if memory_efficiency < 0.5:
                recommendations.append("Implement memory cleanup procedures")
            
            return {
                'memory_per_worker': round(memory_per_worker, 2),
                'memory_efficiency': round(memory_efficiency, 3),
                'optimization_needed': memory_efficiency < 0.7,
                'recommendations': recommendations
            }
        except Exception as e:
            logger.error(f"Error assessing memory optimization: {e}")
            return {}
    
    def _assess_processing_optimization(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess processing optimization opportunities"""
        try:
            records_per_second = datamart_data.get('total_records', 0) / max(datamart_data.get('total_processing_time', 1.0), 1.0)
            worker_count = datamart_data.get('worker_count', 1)
            
            processing_efficiency = records_per_second / worker_count if worker_count > 0 else 0
            
            recommendations = []
            if processing_efficiency < 50:
                recommendations.append("Consider optimizing datatable operations")
            if worker_count < 3 and records_per_second > 100:
                recommendations.append("Consider increasing worker count")
            
            return {
                'processing_efficiency': round(processing_efficiency, 2),
                'records_per_second': round(records_per_second, 2),
                'optimization_needed': processing_efficiency < 100,
                'recommendations': recommendations
            }
        except Exception as e:
            logger.error(f"Error assessing processing optimization: {e}")
            return {}
    
    def _assess_scalability_optimization(self, datamart_data: Dict[str, Any]) -> Dict[str, Any]:
        """Assess scalability optimization opportunities"""
        try:
            worker_count = datamart_data.get('worker_count', 1)
            total_records = datamart_data.get('total_records', 0)
            
            scalability_score = min(worker_count / 5, 1.0) * 0.5 + min(total_records / 1000, 1.0) * 0.5
            
            recommendations = []
            if worker_count < 3:
                recommendations.append("Consider scaling up worker count")
            if total_records > 5000:
                recommendations.append("Consider implementing data partitioning")
            
            return {
                'scalability_score': round(scalability_score, 3),
                'worker_count': worker_count,
                'total_records': total_records,
                'optimization_needed': scalability_score < 0.6,
                'recommendations': recommendations
            }
        except Exception as e:
            logger.error(f"Error assessing scalability optimization: {e}")
            return {}
    
    def _calculate_performance_score(self, records_per_second: float, processing_efficiency: float) -> float:
        """Calculate overall performance score"""
        try:
            # Normalize scores
            speed_score = min(records_per_second / 1000, 1.0)
            efficiency_score = min(processing_efficiency / 200, 1.0)
            
            # Weighted average
            performance_score = (speed_score * 0.6) + (efficiency_score * 0.4)
            
            return round(performance_score, 3)
        except Exception as e:
            logger.error(f"Error calculating performance score: {e}")
            return 0.0
    
    def _calculate_optimization_score(self, datamart_data: Dict[str, Any]) -> float:
        """Calculate overall optimization score"""
        try:
            # Get individual optimization scores
            memory_opt = datamart_data.get('memory_optimization', {}).get('memory_efficiency', 0.5)
            processing_opt = min(datamart_data.get('processing_optimization', {}).get('processing_efficiency', 0) / 200, 1.0)
            scalability_opt = datamart_data.get('scalability_optimization', {}).get('scalability_score', 0.5)
            
            # Weighted average
            optimization_score = (memory_opt * 0.3) + (processing_opt * 0.4) + (scalability_opt * 0.3)
            
            return round(optimization_score, 3)
        except Exception as e:
            logger.error(f"Error calculating optimization score: {e}")
            return 0.0
    
    def _check_performance_alerts(self, datamart_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Check for performance alerts"""
        try:
            alerts = []
            
            # Check system metrics
            system_metrics = self._get_system_metrics()
            if system_metrics.get('cpu_usage', 0) > 80:
                alerts.append({
                    'type': 'warning',
                    'message': 'High CPU usage detected',
                    'metric': 'cpu_usage',
                    'value': system_metrics.get('cpu_usage'),
                    'threshold': 80
                })
            
            if system_metrics.get('memory_usage', 0) > 85:
                alerts.append({
                    'type': 'warning',
                    'message': 'High memory usage detected',
                    'metric': 'memory_usage',
                    'value': system_metrics.get('memory_usage'),
                    'threshold': 85
                })
            
            # Check datatable metrics
            records_per_second = datamart_data.get('total_records', 0) / max(datamart_data.get('total_processing_time', 1.0), 1.0)
            if records_per_second < 50:
                alerts.append({
                    'type': 'warning',
                    'message': 'Low processing performance detected',
                    'metric': 'records_per_second',
                    'value': records_per_second,
                    'threshold': 50
                })
            
            # Store alerts
            self.performance_alerts.extend(alerts)
            
            return alerts
            
        except Exception as e:
            logger.error(f"Error checking performance alerts: {e}")
            return []
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary"""
        try:
            if not self.metrics_history:
                return {"message": "No performance data available"}
            
            latest_metrics = self.metrics_history[-1]
            
            summary = {
                'performance_id': self.performance_id,
                'total_monitoring_sessions': len(self.metrics_history),
                'latest_metrics': latest_metrics,
                'performance_trend': self._calculate_performance_trend(),
                'optimization_recommendations': self._get_optimization_recommendations(),
                'active_alerts': len([a for a in self.performance_alerts if a.get('type') == 'warning']),
                'timestamp': datetime.now().isoformat()
            }
            
            return summary
            
        except Exception as e:
            logger.error(f"Error getting performance summary: {e}")
            return {"error": str(e)}
    
    def _calculate_performance_trend(self) -> Dict[str, Any]:
        """Calculate performance trend"""
        try:
            if len(self.metrics_history) < 2:
                return {'trend': 'insufficient_data', 'direction': 'unknown'}
            
            # Compare latest with previous
            latest = self.metrics_history[-1]
            previous = self.metrics_history[-2]
            
            latest_score = latest.get('datatable_metrics', {}).get('performance_score', 0)
            previous_score = previous.get('datatable_metrics', {}).get('performance_score', 0)
            
            if latest_score > previous_score * 1.1:
                trend = 'improving'
                direction = 'up'
            elif latest_score < previous_score * 0.9:
                trend = 'declining'
                direction = 'down'
            else:
                trend = 'stable'
                direction = 'stable'
            
            return {
                'trend': trend,
                'direction': direction,
                'change_percentage': round(((latest_score - previous_score) / previous_score * 100) if previous_score > 0 else 0, 2)
            }
        except Exception as e:
            logger.error(f"Error calculating performance trend: {e}")
            return {'trend': 'error', 'direction': 'unknown'}
    
    def _get_optimization_recommendations(self) -> List[str]:
        """Get optimization recommendations"""
        try:
            recommendations = []
            
            # Collect recommendations from latest metrics
            if self.metrics_history:
                latest = self.metrics_history[-1]
                
                # Memory optimization
                memory_opt = latest.get('optimization_metrics', {}).get('memory_optimization', {})
                if memory_opt.get('optimization_needed'):
                    recommendations.extend(memory_opt.get('recommendations', []))
                
                # Processing optimization
                processing_opt = latest.get('optimization_metrics', {}).get('processing_optimization', {})
                if processing_opt.get('optimization_needed'):
                    recommendations.extend(processing_opt.get('recommendations', []))
                
                # Scalability optimization
                scalability_opt = latest.get('optimization_metrics', {}).get('scalability_optimization', {})
                if scalability_opt.get('optimization_needed'):
                    recommendations.extend(scalability_opt.get('recommendations', []))
            
            # Remove duplicates
            recommendations = list(set(recommendations))
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting optimization recommendations: {e}")
            return ["Error generating recommendations"]
    
    def clear_history(self):
        """Clear performance history"""
        self.metrics_history = []
        self.performance_alerts = []
        logger.info("Performance history cleared")
