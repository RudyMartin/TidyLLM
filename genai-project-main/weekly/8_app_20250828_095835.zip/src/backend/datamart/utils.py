#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
datatable-mart Utilities - Utility Functions and Helpers

Provides utility functions and helpers for datatable-mart operations.
"""

import logging
import json
import time
from typing import Dict, List, Any, Optional, Union
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)


class DataMartUtils:
    """Utility functions for datatable-mart operations"""
    
    def __init__(self):
        self.utils_id = f"utils_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        logger.info(f"DataMart Utils initialized with ID: {self.utils_id}")
    
    @staticmethod
    def validate_data(data: Dict[str, Any]) -> Dict[str, Any]:
        """Validate data structure for datatable-mart"""
        try:
            validation_result = {
                'is_valid': True,
                'errors': [],
                'warnings': [],
                'timestamp': datetime.now().isoformat()
            }
            
            # Check required fields
            required_fields = ['worker_name', 'worker_type', 'data_type']
            for field in required_fields:
                if field not in data:
                    validation_result['is_valid'] = False
                    validation_result['errors'].append(f"Missing required field: {field}")
            
            # Check data types
            if 'confidence_score' in data:
                confidence = data['confidence_score']
                if not isinstance(confidence, (int, float)) or confidence < 0 or confidence > 1:
                    validation_result['is_valid'] = False
                    validation_result['errors'].append("confidence_score must be a number between 0 and 1")
            
            if 'processing_time' in data:
                processing_time = data['processing_time']
                if not isinstance(processing_time, (int, float)) or processing_time < 0:
                    validation_result['is_valid'] = False
                    validation_result['errors'].append("processing_time must be a non-negative number")
            
            # Check for warnings
            if len(data) < 3:
                validation_result['warnings'].append("Data contains very few fields")
            
            if 'status' in data and data['status'] not in ['success', 'error', 'pending', 'completed']:
                validation_result['warnings'].append("Unusual status value detected")
            
            return validation_result
            
        except Exception as e:
            logger.error(f"Error validating data: {e}")
            return {
                'is_valid': False,
                'errors': [f"Validation error: {str(e)}"],
                'warnings': [],
                'timestamp': datetime.now().isoformat()
            }
    
    @staticmethod
    def format_data(data: Dict[str, Any], format_type: str = 'json') -> str:
        """Format data for output"""
        try:
            if format_type.lower() == 'json':
                return json.dumps(data, indent=2, default=str)
            elif format_type.lower() == 'compact':
                return json.dumps(data, separators=(',', ':'), default=str)
            elif format_type.lower() == 'pretty':
                return DataMartUtils._format_pretty(data)
            else:
                return str(data)
                
        except Exception as e:
            logger.error(f"Error formatting data: {e}")
            return str(data)
    
    @staticmethod
    def _format_pretty(data: Dict[str, Any]) -> str:
        """Format data in a pretty, readable format"""
        try:
            lines = []
            lines.append("=" * 50)
            lines.append("DATATABLE-MART DATA REPORT")
            lines.append("=" * 50)
            lines.append(f"Timestamp: {datetime.now().isoformat()}")
            lines.append("")
            
            for key, value in data.items():
                if isinstance(value, dict):
                    lines.append(f"{key}:")
                    for sub_key, sub_value in value.items():
                        lines.append(f"  {sub_key}: {sub_value}")
                else:
                    lines.append(f"{key}: {value}")
            
            lines.append("")
            lines.append("=" * 50)
            
            return "\n".join(lines)
            
        except Exception as e:
            logger.error(f"Error formatting pretty: {e}")
            return str(data)
    
    @staticmethod
    def calculate_metrics(data_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Calculate aggregate metrics from a list of data records"""
        try:
            if not data_list:
                return {
                    'total_records': 0,
                    'avg_confidence': 0.0,
                    'total_processing_time': 0.0,
                    'success_rate': 0.0
                }
            
            total_records = len(data_list)
            confidence_scores = [d.get('confidence_score', 0.0) for d in data_list if isinstance(d.get('confidence_score'), (int, float))]
            processing_times = [d.get('processing_time', 0.0) for d in data_list if isinstance(d.get('processing_time'), (int, float))]
            success_count = sum(1 for d in data_list if d.get('status') == 'success')
            
            metrics = {
                'total_records': total_records,
                'avg_confidence': sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0.0,
                'total_processing_time': sum(processing_times),
                'avg_processing_time': sum(processing_times) / len(processing_times) if processing_times else 0.0,
                'success_rate': (success_count / total_records) if total_records > 0 else 0.0,
                'min_confidence': min(confidence_scores) if confidence_scores else 0.0,
                'max_confidence': max(confidence_scores) if confidence_scores else 0.0,
                'min_processing_time': min(processing_times) if processing_times else 0.0,
                'max_processing_time': max(processing_times) if processing_times else 0.0
            }
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error calculating metrics: {e}")
            return {
                'total_records': 0,
                'avg_confidence': 0.0,
                'total_processing_time': 0.0,
                'success_rate': 0.0,
                'error': str(e)
            }
    
    @staticmethod
    def filter_data(data_list: List[Dict[str, Any]], filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Filter data based on criteria"""
        try:
            filtered_data = data_list.copy()
            
            for field, criteria in filters.items():
                if isinstance(criteria, dict):
                    # Range filter
                    if 'min' in criteria:
                        filtered_data = [d for d in filtered_data if d.get(field, 0) >= criteria['min']]
                    if 'max' in criteria:
                        filtered_data = [d for d in filtered_data if d.get(field, float('inf')) <= criteria['max']]
                elif isinstance(criteria, list):
                    # List filter
                    filtered_data = [d for d in filtered_data if d.get(field) in criteria]
                else:
                    # Exact match filter
                    filtered_data = [d for d in filtered_data if d.get(field) == criteria]
            
            return filtered_data
            
        except Exception as e:
            logger.error(f"Error filtering data: {e}")
            return data_list
    
    @staticmethod
    def sort_data(data_list: List[Dict[str, Any]], sort_by: str, reverse: bool = False) -> List[Dict[str, Any]]:
        """Sort data by specified field"""
        try:
            return sorted(data_list, key=lambda x: x.get(sort_by, 0), reverse=reverse)
        except Exception as e:
            logger.error(f"Error sorting data: {e}")
            return data_list
    
    @staticmethod
    def export_data(data: Union[Dict[str, Any], List[Dict[str, Any]]], 
                   file_path: str, format_type: str = 'json') -> bool:
        """Export data to file"""
        try:
            file_path = Path(file_path)
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            if format_type.lower() == 'json':
                with open(file_path, 'w') as f:
                    json.dump(data, f, indent=2, default=str)
            elif format_type.lower() == 'csv':
                DataMartUtils._export_csv(data, file_path)
            else:
                with open(file_path, 'w') as f:
                    f.write(str(data))
            
            logger.info(f"Data exported to {file_path}")
            return True
            
        except Exception as e:
            logger.error(f"Error exporting data: {e}")
            return False
    
    @staticmethod
    def _export_csv(data: Union[Dict[str, Any], List[Dict[str, Any]]], file_path: Path):
        """Export data to CSV format"""
        try:
            import csv
            
            if isinstance(data, dict):
                data = [data]
            
            if not data:
                return
            
            # Get all unique keys
            all_keys = set()
            for record in data:
                all_keys.update(record.keys())
            
            with open(file_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=sorted(all_keys))
                writer.writeheader()
                writer.writerows(data)
                
        except Exception as e:
            logger.error(f"Error exporting CSV: {e}")
    
    @staticmethod
    def import_data(file_path: str, format_type: str = 'json') -> Union[Dict[str, Any], List[Dict[str, Any]]]:
        """Import data from file"""
        try:
            file_path = Path(file_path)
            
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            
            if format_type.lower() == 'json':
                with open(file_path, 'r') as f:
                    return json.load(f)
            elif format_type.lower() == 'csv':
                return DataMartUtils._import_csv(file_path)
            else:
                with open(file_path, 'r') as f:
                    return f.read()
                    
        except Exception as e:
            logger.error(f"Error importing data: {e}")
            return {}
    
    @staticmethod
    def _import_csv(file_path: Path) -> List[Dict[str, Any]]:
        """Import data from CSV format"""
        try:
            import csv
            
            data = []
            with open(file_path, 'r', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    data.append(row)
            
            return data
            
        except Exception as e:
            logger.error(f"Error importing CSV: {e}")
            return []
    
    @staticmethod
    def benchmark_operation(operation_func, *args, **kwargs) -> Dict[str, Any]:
        """Benchmark an operation"""
        try:
            start_time = time.time()
            start_memory = DataMartUtils._get_memory_usage()
            
            result = operation_func(*args, **kwargs)
            
            end_time = time.time()
            end_memory = DataMartUtils._get_memory_usage()
            
            benchmark_result = {
                'execution_time': end_time - start_time,
                'memory_delta': end_memory - start_memory,
                'start_memory': start_memory,
                'end_memory': end_memory,
                'timestamp': datetime.now().isoformat(),
                'operation_name': operation_func.__name__,
                'result': result
            }
            
            return benchmark_result
            
        except Exception as e:
            logger.error(f"Error benchmarking operation: {e}")
            return {
                'execution_time': 0.0,
                'memory_delta': 0.0,
                'error': str(e),
                'timestamp': datetime.now().isoformat(),
                'operation_name': operation_func.__name__ if hasattr(operation_func, '__name__') else 'unknown'
            }
    
    @staticmethod
    def _get_memory_usage() -> float:
        """Get current memory usage in MB"""
        try:
            import psutil
            process = psutil.Process()
            return process.memory_info().rss / 1024 / 1024  # Convert to MB
        except Exception:
            return 0.0
    
    @staticmethod
    def create_summary_report(data_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create a comprehensive summary report"""
        try:
            if not data_list:
                return {
                    'summary': 'No data available',
                    'timestamp': datetime.now().isoformat()
                }
            
            metrics = DataMartUtils.calculate_metrics(data_list)
            
            # Group by worker
            worker_stats = {}
            for record in data_list:
                worker_name = record.get('worker_name', 'unknown')
                if worker_name not in worker_stats:
                    worker_stats[worker_name] = []
                worker_stats[worker_name].append(record)
            
            # Calculate worker-specific metrics
            worker_metrics = {}
            for worker_name, worker_data in worker_stats.items():
                worker_metrics[worker_name] = DataMartUtils.calculate_metrics(worker_data)
            
            summary_report = {
                'timestamp': datetime.now().isoformat(),
                'total_records': len(data_list),
                'overall_metrics': metrics,
                'worker_metrics': worker_metrics,
                'data_quality': DataMartUtils._assess_data_quality(data_list),
                'performance_summary': DataMartUtils._create_performance_summary(data_list)
            }
            
            return summary_report
            
        except Exception as e:
            logger.error(f"Error creating summary report: {e}")
            return {
                'summary': 'Error creating report',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    @staticmethod
    def _assess_data_quality(data_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Assess overall data quality"""
        try:
            total_records = len(data_list)
            if total_records == 0:
                return {'quality_score': 0.0, 'issues': ['No data available']}
            
            issues = []
            quality_score = 1.0
            
            # Check for missing required fields
            required_fields = ['worker_name', 'worker_type']
            missing_fields = 0
            for record in data_list:
                for field in required_fields:
                    if field not in record or record[field] is None:
                        missing_fields += 1
            
            if missing_fields > 0:
                missing_percentage = missing_fields / (total_records * len(required_fields))
                quality_score -= missing_percentage
                issues.append(f"Missing required fields: {missing_fields} instances")
            
            # Check confidence scores
            low_confidence = sum(1 for r in data_list if r.get('confidence_score', 1.0) < 0.5)
            if low_confidence > 0:
                low_confidence_percentage = low_confidence / total_records
                quality_score -= low_confidence_percentage * 0.5
                issues.append(f"Low confidence scores: {low_confidence} records")
            
            # Check for errors
            error_records = sum(1 for r in data_list if r.get('status') == 'error')
            if error_records > 0:
                error_percentage = error_records / total_records
                quality_score -= error_percentage
                issues.append(f"Error records: {error_records}")
            
            return {
                'quality_score': max(0.0, quality_score),
                'issues': issues,
                'total_records': total_records
            }
            
        except Exception as e:
            logger.error(f"Error assessing data quality: {e}")
            return {'quality_score': 0.0, 'issues': [f'Assessment error: {str(e)}']}
    
    @staticmethod
    def _create_performance_summary(data_list: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Create performance summary"""
        try:
            processing_times = [r.get('processing_time', 0.0) for r in data_list if isinstance(r.get('processing_time'), (int, float))]
            
            if not processing_times:
                return {'avg_processing_time': 0.0, 'total_processing_time': 0.0}
            
            return {
                'avg_processing_time': sum(processing_times) / len(processing_times),
                'total_processing_time': sum(processing_times),
                'min_processing_time': min(processing_times),
                'max_processing_time': max(processing_times),
                'records_per_second': len(data_list) / sum(processing_times) if sum(processing_times) > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Error creating performance summary: {e}")
            return {'avg_processing_time': 0.0, 'total_processing_time': 0.0}
