#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
datatable-mart - Everything you ever wanted to make Python datatable intelligent

A comprehensive datatable management system that provides:
- Intelligent data processing with datatable
- Progressive complexity architecture
- NumPy substitution layer
- Enhanced analytics and performance tracking
- Remote storage capabilities
- Connection management

This package resolves circular dependencies and provides a clean foundation
for high-performance data processing using datatable.
"""

# Core DataMart components
from .core_manager import DataMartManager, DataMartMode
from .numpy_substitute import DataMartNumPySubstitution, DataMart, np
from .enhanced_manager import EnhancedDataMartManager
from .service import DataMartService

# Performance and analytics
from .analytics import DataMartAnalytics
from .performance import DataMartPerformance

# Utilities
from .utils import DataMartUtils

__all__ = [
    # Core
    'DataMartManager',
    'DataMartMode',
    'DataMartNumPySubstitution',
    'DataMart',
    'np',
    
    # Enhanced features
    'EnhancedDataMartManager',
    'DataMartService',
    
    # Analytics
    'DataMartAnalytics',
    'DataMartPerformance',
    
    # Utilities
    'DataMartUtils',
]

# Package metadata
__version__ = "2.1.0"
__author__ = "VectorQA Team"
__description__ = "Everything you ever wanted to make Python datatable intelligent"
__tagline__ = "datatable-mart: Intelligent datatable management for Python"
