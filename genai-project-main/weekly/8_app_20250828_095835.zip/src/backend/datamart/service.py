#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
datatable-mart Service - Service Layer for datatable-mart

Provides service layer functionality for datatable-mart operations.
"""

import logging
from typing import Dict, List, Any, Optional
from datetime import datetime

from .core_manager import DataMartManager, DataMartMode
from .analytics import DataMartAnalytics
from .performance import DataMartPerformance

logger = logging.getLogger(__name__)


class DataMartService:
    """Service layer for datatable-mart operations"""
    
    def __init__(self, mode: DataMartMode = DataMartMode.ENHANCED):
        self.mode = mode
        self.datamart = DataMartManager(mode)
        self.analytics = DataMartAnalytics()
        self.performance = DataMartPerformance()
        self.service_id = f"service_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        logger.info(f"DataMart Service initialized with ID: {self.service_id}")
    
    def initialize_service(self) -> bool:
        """Initialize the datatable-mart service"""
        try:
            # Initialize DataMart
            datamart_success = self.datamart.initialize_datamart()
            
            if datamart_success:
                logger.info("✅ DataMart Service initialized successfully")
                return True
            else:
                logger.error("❌ DataMart Service initialization failed")
                return False
                
        except Exception as e:
            logger.error(f"Error initializing DataMart Service: {e}")
            return False
    
    def process_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process data through the complete datatable-mart pipeline"""
        try:
            start_time = datetime.now()
            
            # Store data in DataMart
            storage_success = self.datamart.store_analysis_record(data)
            
            # Generate performance report
            performance_report = self.datamart.generate_performance_report()
            
            # Analyze performance
            analytics_result = self.analytics.analyze_performance(performance_report)
            
            # Monitor performance
            performance_metrics = self.performance.monitor_performance(performance_report)
            
            end_time = datetime.now()
            processing_time = (end_time - start_time).total_seconds()
            
            result = {
                'service_id': self.service_id,
                'timestamp': datetime.now().isoformat(),
                'processing_time': processing_time,
                'storage_success': storage_success,
                'performance_report': performance_report,
                'analytics_result': analytics_result,
                'performance_metrics': performance_metrics,
                'status': 'success' if storage_success else 'partial_success'
            }
            
            logger.info(f"DataMart Service processed data in {processing_time:.2f} seconds")
            return result
            
        except Exception as e:
            logger.error(f"Error processing data in DataMart Service: {e}")
            return {
                'service_id': self.service_id,
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'status': 'error'
            }
    
    def get_service_status(self) -> Dict[str, Any]:
        """Get comprehensive service status"""
        try:
            # Get DataMart status
            datamart_report = self.datamart.generate_performance_report()
            
            # Get analytics status
            analytics_summary = self.analytics.analyze_performance(datamart_report)
            
            # Get performance status
            performance_summary = self.performance.get_performance_summary()
            
            status = {
                'service_id': self.service_id,
                'timestamp': datetime.now().isoformat(),
                'mode': self.mode.value,
                'datamart_status': datamart_report,
                'analytics_status': analytics_summary,
                'performance_status': performance_summary,
                'overall_status': self._calculate_overall_status(datamart_report, analytics_summary, performance_summary)
            }
            
            return status
            
        except Exception as e:
            logger.error(f"Error getting service status: {e}")
            return {
                'service_id': self.service_id,
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'status': 'error'
            }
    
    def _calculate_overall_status(self, datamart_report: Dict[str, Any], 
                                analytics_summary: Dict[str, Any], 
                                performance_summary: Dict[str, Any]) -> str:
        """Calculate overall service status"""
        try:
            # Check for errors
            if datamart_report.get('error') or analytics_summary.get('error') or performance_summary.get('error'):
                return 'error'
            
            # Check DataMart status
            datamart_status = datamart_report.get('status', 'unknown')
            if datamart_status == 'error':
                return 'error'
            
            # Check performance status
            performance_metrics = performance_summary.get('latest_metrics', {})
            alerts = performance_metrics.get('alerts', [])
            if len(alerts) > 2:  # More than 2 alerts indicates issues
                return 'warning'
            
            # Check analytics status
            analytics_metrics = analytics_summary.get('performance_metrics', {})
            if analytics_metrics.get('processing_speed', {}).get('performance_rating') == 'poor':
                return 'warning'
            
            return 'healthy'
            
        except Exception as e:
            logger.error(f"Error calculating overall status: {e}")
            return 'unknown'
    
    def get_analytics_report(self) -> Dict[str, Any]:
        """Get analytics report"""
        try:
            datamart_report = self.datamart.generate_performance_report()
            return self.analytics.analyze_performance(datamart_report)
        except Exception as e:
            logger.error(f"Error getting analytics report: {e}")
            return {"error": str(e)}
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Get performance report"""
        try:
            datamart_report = self.datamart.generate_performance_report()
            return self.performance.monitor_performance(datamart_report)
        except Exception as e:
            logger.error(f"Error getting performance report: {e}")
            return {"error": str(e)}
    
    def get_datamart_report(self) -> Dict[str, Any]:
        """Get DataMart report"""
        try:
            return self.datamart.generate_performance_report()
        except Exception as e:
            logger.error(f"Error getting DataMart report: {e}")
            return {"error": str(e)}
    
    def clear_service_data(self):
        """Clear all service data"""
        try:
            # Clear analytics history
            self.analytics.performance_history = []
            
            # Clear performance history
            self.performance.clear_history()
            
            # Note: DataMart buffer is managed by the DataMart itself
            logger.info("DataMart Service data cleared")
            
        except Exception as e:
            logger.error(f"Error clearing service data: {e}")
    
    def get_service_metrics(self) -> Dict[str, Any]:
        """Get comprehensive service metrics"""
        try:
            metrics = {
                'service_id': self.service_id,
                'timestamp': datetime.now().isoformat(),
                'mode': self.mode.value,
                'datamart_metrics': self.get_datamart_report(),
                'analytics_metrics': self.get_analytics_report(),
                'performance_metrics': self.get_performance_report(),
                'service_status': self.get_service_status()
            }
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error getting service metrics: {e}")
            return {"error": str(e)}
