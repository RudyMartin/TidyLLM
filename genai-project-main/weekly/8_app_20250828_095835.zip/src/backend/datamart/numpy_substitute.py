#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DataMart NumPy Substitution Layer

This module provides DataMart/datatable alternatives to NumPy functions,
ensuring compatibility while avoiding NumPy dependencies.
"""

import logging
import time
from typing import List, Dict, Any, Union, Optional
from datetime import datetime

# Import DataMart components
from .core_manager import DataMartManager, DataMartMode

logger = logging.getLogger(__name__)

# Try to import DataMart, fallback to simple implementation if not available
try:
    from .core_manager import DataMartManager, DataMartMode
    DATAMART_AVAILABLE = True
except ImportError:
    DATAMART_AVAILABLE = False
    print("⚠️ DataMart not available, using simple fallback")

# Fallback DataMart classes if not available
if not DATAMART_AVAILABLE:
    class DataMartMode:
        SIMPLE = "simple"
        ENHANCED = "enhanced"
        ADVANCED = "advanced"
    
    class DataMartManager:
        def __init__(self, mode=None):
            self.mode = mode or DataMartMode.SIMPLE
            self.buffer = []
        
        def initialize_datamart(self):
            return True


class DataMartNumPySubstitution:
    """Complete NumPy substitution using DataMart/datatable"""
    
    def __init__(self, mode: DataMartMode = DataMartMode.ENHANCED):
        self.mode = mode
        self.datamart = DataMartManager(mode)
        self._initialize_datamart()
    
    def _initialize_datamart(self):
        """Initialize DataMart for numpy operations"""
        try:
            self.datamart.initialize_datamart()
        except Exception as e:
            print(f"Warning: DataMart initialization failed: {e}")
    
    def array(self, data: List) -> List:
        """Create array-like structure"""
        try:
            if isinstance(data, list):
                return data
            else:
                return list(data)
        except Exception as e:
            logger.error(f"Error creating array: {e}")
            return []
    
    def zeros(self, shape: Union[int, tuple]) -> List:
        """Create zeros array"""
        try:
            if isinstance(shape, int):
                return [0] * shape
            elif isinstance(shape, tuple):
                if len(shape) == 1:
                    return [0] * shape[0]
                else:
                    # Multi-dimensional zeros
                    result = []
                    for _ in range(shape[0]):
                        result.append(self.zeros(shape[1:]))
                    return result
            else:
                return [0]
        except Exception as e:
            logger.error(f"Error creating zeros: {e}")
            return [0]
    
    def ones(self, shape: Union[int, tuple]) -> List:
        """Create ones array"""
        try:
            if isinstance(shape, int):
                return [1] * shape
            elif isinstance(shape, tuple):
                if len(shape) == 1:
                    return [1] * shape[0]
                else:
                    # Multi-dimensional ones
                    result = []
                    for _ in range(shape[0]):
                        result.append(self.ones(shape[1:]))
                    return result
            else:
                return [1]
        except Exception as e:
            logger.error(f"Error creating ones: {e}")
            return [1]
    
    def mean(self, data: List) -> float:
        """Calculate mean"""
        try:
            if not data:
                return 0.0
            return sum(data) / len(data)
        except Exception as e:
            logger.error(f"Error calculating mean: {e}")
            return 0.0
    
    def std(self, data: List) -> float:
        """Calculate standard deviation"""
        try:
            if not data:
                return 0.0
            mean_val = self.mean(data)
            variance = sum((x - mean_val) ** 2 for x in data) / len(data)
            return variance ** 0.5
        except Exception as e:
            logger.error(f"Error calculating std: {e}")
            return 0.0
    
    def sum(self, data: List) -> Union[float, int]:
        """Calculate sum"""
        try:
            return sum(data)
        except Exception as e:
            logger.error(f"Error calculating sum: {e}")
            return 0
    
    def min(self, data: List) -> Union[float, int]:
        """Find minimum value"""
        try:
            if not data:
                return 0
            return min(data)
        except Exception as e:
            logger.error(f"Error finding min: {e}")
            return 0
    
    def max(self, data: List) -> Union[float, int]:
        """Find maximum value"""
        try:
            if not data:
                return 0
            return max(data)
        except Exception as e:
            logger.error(f"Error finding max: {e}")
            return 0
    
    def reshape(self, data: List, shape: tuple) -> List:
        """Reshape array"""
        try:
            if not data:
                return []
            
            # Flatten the data first
            flat_data = self._flatten(data)
            
            if len(shape) == 1:
                return flat_data[:shape[0]]
            else:
                # Multi-dimensional reshape
                return self._reshape_recursive(flat_data, shape)
        except Exception as e:
            logger.error(f"Error reshaping: {e}")
            return data
    
    def _flatten(self, data: List) -> List:
        """Flatten nested list"""
        result = []
        for item in data:
            if isinstance(item, list):
                result.extend(self._flatten(item))
            else:
                result.append(item)
        return result
    
    def _reshape_recursive(self, data: List, shape: tuple) -> List:
        """Recursive reshape for multi-dimensional arrays"""
        if len(shape) == 1:
            return data[:shape[0]]
        else:
            result = []
            size_per_dim = len(data) // shape[0]
            for i in range(shape[0]):
                start_idx = i * size_per_dim
                end_idx = start_idx + size_per_dim
                result.append(self._reshape_recursive(data[start_idx:end_idx], shape[1:]))
            return result
    
    def transpose(self, data: List) -> List:
        """Transpose array"""
        try:
            if not data or not isinstance(data[0], list):
                return data
            
            # Simple 2D transpose
            rows = len(data)
            cols = len(data[0]) if data else 0
            
            result = []
            for j in range(cols):
                row = []
                for i in range(rows):
                    if j < len(data[i]):
                        row.append(data[i][j])
                    else:
                        row.append(0)
                result.append(row)
            
            return result
        except Exception as e:
            logger.error(f"Error transposing: {e}")
            return data
    
    def pad(self, data: List, pad_width: tuple, mode: str = 'constant', constant_values: Union[int, float] = 0) -> List:
        """Pad array"""
        try:
            if not data:
                return data
            
            if isinstance(data[0], list):
                # 2D padding
                return self._pad_2d(data, pad_width, mode, constant_values)
            else:
                # 1D padding
                return self._pad_1d(data, pad_width, mode, constant_values)
        except Exception as e:
            logger.error(f"Error padding: {e}")
            return data
    
    def _pad_1d(self, data: List, pad_width: tuple, mode: str, constant_values: Union[int, float]) -> List:
        """Pad 1D array"""
        left_pad, right_pad = pad_width
        
        result = []
        
        # Left padding
        if mode == 'constant':
            result.extend([constant_values] * left_pad)
        elif mode == 'edge':
            result.extend([data[0]] * left_pad)
        
        # Original data
        result.extend(data)
        
        # Right padding
        if mode == 'constant':
            result.extend([constant_values] * right_pad)
        elif mode == 'edge':
            result.extend([data[-1]] * right_pad)
        
        return result
    
    def _pad_2d(self, data: List, pad_width: tuple, mode: str, constant_values: Union[int, float]) -> List:
        """Pad 2D array"""
        if not data:
            return data
        
        ((top, bottom), (left, right)) = pad_width
        
        rows = len(data)
        cols = len(data[0]) if data else 0
        
        result = []
        
        # Top padding
        for _ in range(top):
            if mode == 'constant':
                result.append([constant_values] * (cols + left + right))
            elif mode == 'edge':
                result.append([data[0][0]] * (cols + left + right))
        
        # Original data with side padding
        for row in data:
            new_row = []
            
            # Left padding
            if mode == 'constant':
                new_row.extend([constant_values] * left)
            elif mode == 'edge':
                new_row.extend([row[0]] * left)
            
            # Original row
            new_row.extend(row)
            
            # Right padding
            if mode == 'constant':
                new_row.extend([constant_values] * right)
            elif mode == 'edge':
                new_row.extend([row[-1]] * right)
            
            result.append(new_row)
        
        # Bottom padding
        for _ in range(bottom):
            if mode == 'constant':
                result.append([constant_values] * (cols + left + right))
            elif mode == 'edge':
                result.append([data[-1][0]] * (cols + left + right))
        
        return result
    
    def datetime64(self, value: str) -> str:
        """Convert to datetime64-like string"""
        try:
            # Simple datetime conversion
            return value
        except Exception as e:
            logger.error(f"Error converting to datetime64: {e}")
            return value
    
    def ndarray(self, data: List) -> List:
        """Create ndarray-like structure"""
        return self.array(data)
    
    def random_normal(self, size: Union[int, tuple], mean: float = 0.0, std: float = 1.0) -> List:
        """Generate normal distribution"""
        try:
            import random
            
            if isinstance(size, int):
                return [random.gauss(mean, std) for _ in range(size)]
            elif isinstance(size, tuple):
                if len(size) == 1:
                    return [random.gauss(mean, std) for _ in range(size[0])]
                else:
                    # Multi-dimensional normal distribution
                    result = []
                    for _ in range(size[0]):
                        result.append(self.random_normal(size[1:], mean, std))
                    return result
            else:
                return [random.gauss(mean, std)]
        except Exception as e:
            logger.error(f"Error generating normal distribution: {e}")
            return [0.0]
    
    def to_list(self, data: Any) -> List:
        """Convert to list"""
        try:
            if isinstance(data, list):
                return data
            else:
                return list(data)
        except Exception as e:
            logger.error(f"Error converting to list: {e}")
            return []
    
    def to_array(self, data: Any) -> List:
        """Convert to array"""
        return self.to_list(data)
    
    # DataMart integration
    def add_to_datamart(self, data: List, metadata: dict = None) -> bool:
        """Add data to DataMart for analytics"""
        try:
            datamart_data = {
                'data': data,
                'metadata': metadata or {},
                'timestamp': datetime.now().isoformat(),
                'operation': 'numpy_substitution'
            }
            return self.datamart.store_analysis_record(datamart_data)
        except Exception as e:
            logger.error(f"Error adding to DataMart: {e}")
            return False
    
    def get_datamart_metrics(self) -> dict:
        """Get DataMart performance metrics"""
        try:
            return self.datamart.generate_performance_report()
        except Exception as e:
            logger.error(f"Error getting DataMart metrics: {e}")
            return {}


# Main NumPy substitute using DataMart
class DataMartNumPy:
    """Main NumPy substitute using DataMart"""
    
    def __init__(self, mode: DataMartMode = DataMartMode.ENHANCED):
        self.datamart_np = DataMartNumPySubstitution(mode)
    
    @property
    def array(self):
        return self.datamart_np.array
    
    @property
    def zeros(self):
        return self.datamart_np.zeros
    
    @property
    def ones(self):
        return self.datamart_np.ones
    
    @property
    def mean(self):
        return self.datamart_np.mean
    
    @property
    def std(self):
        return self.datamart_np.std
    
    @property
    def sum(self):
        return self.datamart_np.sum
    
    @property
    def min(self):
        return self.datamart_np.min
    
    @property
    def max(self):
        return self.datamart_np.max
    
    @property
    def reshape(self):
        return self.datamart_np.reshape
    
    @property
    def transpose(self):
        return self.datamart_np.transpose
    
    @property
    def pad(self):
        return self.datamart_np.pad
    
    @property
    def datetime64(self):
        return self.datamart_np.datetime64
    
    @property
    def ndarray(self):
        return self.datamart_np.ndarray
    
    @property
    def random_normal(self):
        return self.datamart_np.random_normal
    
    def to_list(self, data):
        return self.datamart_np.to_list(data)
    
    def to_array(self, data):
        return self.datamart_np.to_array(data)
    
    def add_to_datamart(self, data, metadata=None):
        return self.datamart_np.add_to_datamart(data, metadata)
    
    def get_datamart_metrics(self):
        return self.datamart_np.get_datamart_metrics()


# Simple DataMart wrapper for easier access
class DataMart:
    """Simple DataMart wrapper for easier access to DataMart functionality"""
    
    def __init__(self, mode: DataMartMode = DataMartMode.SIMPLE):
        self.manager = DataMartManager(mode)
    
    def initialize(self):
        """Initialize DataMart"""
        return self.manager.initialize_datamart()
    
    def add_data(self, data: Dict[str, Any]) -> bool:
        """Add analysis data to DataMart"""
        return self.manager.store_analysis_record(data)
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get DataMart performance metrics"""
        return self.manager.generate_performance_report()


# Create global np instance
np = DataMartNumPy(DataMartMode.ENHANCED)
