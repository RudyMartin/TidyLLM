#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MCP Coordinators Package

Specialized coordinators that operate within the proper MCP hierarchy:
MCPOrchestrator → Planner → Coordinator → Worker

This package contains domain-specific coordinators that have been properly 
integrated into the MCP command structure, replacing the old "orchestrator" 
pattern that bypassed the hierarchy.
"""

from .simple_qa_coordinator import SimpleQACoordinator
from .enhanced_qa_coordinator import EnhancedQACoordinator

__all__ = [
    'SimpleQACoordinator',
    'EnhancedQACoordinator',
]

# Reorg Status: Phase 2 Complete
# - SimpleQACoordinator: ✅ Migrated from SimpleQAOrchestrator  
# - EnhancedQACoordinator: ✅ Migrated from EnhancedQAOrchestrator
# - Advanced QA: 🔄 Next phase (includes DataMart separation)