#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLM Client - Core Foundation Component

Standalone LLM client for AI-powered analysis, extracted from advanced_qa_orchestrator.py
to follow single responsibility principle and reduce file size.
"""

import logging
import uuid
from typing import Dict, List, Any
from datetime import datetime

logger = logging.getLogger(__name__)


class LLMClient:
    """LLM Client for AI-powered analysis"""
    
    def __init__(self):
        self.client_id = str(uuid.uuid4())
        self.analysis_history = []
        logger.info(f"LLM Client initialized with ID: {self.client_id}")
    
    def analyze_document(self, document: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze document using LLM capabilities"""
        try:
            content = document.get('content', '')
            
            # Simulate LLM analysis
            analysis_result = {
                'sentiment_score': self._analyze_sentiment(content),
                'complexity_level': self._analyze_complexity(content),
                'key_topics': self._extract_key_topics(content),
                'writing_style': self._analyze_writing_style(content),
                'suggested_improvements': self._generate_improvements(content),
                'confidence_score': 0.85
            }
            
            self.analysis_history.append({
                'timestamp': datetime.now(),
                'document_id': document.get('file_path', 'unknown'),
                'analysis': analysis_result
            })
            
            return analysis_result
            
        except Exception as e:
            logger.error(f"Error in LLM analysis: {e}")
            return {
                'sentiment_score': 0.5,
                'complexity_level': 'medium',
                'key_topics': [],
                'writing_style': 'neutral',
                'suggested_improvements': ['Analysis failed'],
                'confidence_score': 0.0
            }
    
    def _analyze_sentiment(self, content: str) -> float:
        """Analyze document sentiment"""
        # Simple sentiment analysis simulation
        positive_words = ['good', 'excellent', 'great', 'improved', 'success', 'positive']
        negative_words = ['bad', 'poor', 'failed', 'error', 'problem', 'negative']
        
        content_lower = content.lower()
        positive_count = sum(1 for word in positive_words if word in content_lower)
        negative_count = sum(1 for word in negative_words if word in content_lower)
        
        total_words = len(content.split())
        if total_words == 0:
            return 0.5
        
        sentiment = (positive_count - negative_count) / total_words
        return max(0.0, min(1.0, 0.5 + sentiment))
    
    def _analyze_complexity(self, content: str) -> str:
        """Analyze document complexity"""
        sentences = [s.strip() for s in content.split('.') if s.strip()]
        if not sentences:
            return 'low'
        
        avg_sentence_length = sum(len(s.split()) for s in sentences) / len(sentences)
        
        if avg_sentence_length < 10:
            return 'low'
        elif avg_sentence_length < 20:
            return 'medium'
        else:
            return 'high'
    
    def _extract_key_topics(self, content: str) -> List[str]:
        """Extract key topics from document"""
        # Simple topic extraction simulation
        topics = []
        content_lower = content.lower()
        
        # Define topic keywords
        topic_keywords = {
            'risk': ['risk', 'risk management', 'model risk'],
            'credit': ['credit', 'credit risk', 'lending'],
            'compliance': ['compliance', 'regulatory', 'regulation'],
            'performance': ['performance', 'metrics', 'kpi'],
            'technology': ['technology', 'system', 'platform'],
            'data': ['data', 'analytics', 'analysis']
        }
        
        for topic, keywords in topic_keywords.items():
            if any(keyword in content_lower for keyword in keywords):
                topics.append(topic)
        
        return topics[:5]  # Return top 5 topics
    
    def _analyze_writing_style(self, content: str) -> str:
        """Analyze writing style"""
        sentences = [s.strip() for s in content.split('.') if s.strip()]
        if not sentences:
            return 'neutral'
        
        # Analyze sentence structure
        avg_sentence_length = sum(len(s.split()) for s in sentences) / len(sentences)
        
        # Check for technical terms
        technical_terms = ['algorithm', 'model', 'system', 'analysis', 'framework']
        technical_count = sum(1 for term in technical_terms if term in content.lower())
        
        if avg_sentence_length > 25 and technical_count > 3:
            return 'technical'
        elif avg_sentence_length < 15:
            return 'concise'
        else:
            return 'balanced'
    
    def _generate_improvements(self, content: str) -> List[str]:
        """Generate improvement suggestions"""
        suggestions = []
        
        # Check for common issues
        if len(content.split()) < 50:
            suggestions.append("Consider adding more detail to the content")
        
        if content.count('.') < 3:
            suggestions.append("Consider breaking content into more sentences")
        
        if not any(word in content.lower() for word in ['analysis', 'result', 'conclusion']):
            suggestions.append("Consider adding analysis or conclusions")
        
        if not suggestions:
            suggestions.append("Content appears well-structured")
        
        return suggestions
    
    def get_analysis_history(self) -> List[Dict[str, Any]]:
        """Get analysis history"""
        return self.analysis_history
    
    def clear_history(self):
        """Clear analysis history"""
        self.analysis_history = []
        logger.info("LLM Client analysis history cleared")
