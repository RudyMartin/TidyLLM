#!/usr/bin/env python3
"""
Full Site Archive Creator for Air-Gapped Deployment

Creates 8 segmented ZIP archives for secure, air-gapped environment deployment:
1. Knowledge Base - Research papers, whitepapers, reference documentation
2. Database files - All database schemas, migrations, and data
3. Credentials - Configuration files, environment settings (sanitized)  
4. Historical Data - Large historical datasets (OPTIONAL - may be very large)
5. Current Input - Current test files, examples, and notebooks
6. Output - Generated reports, logs, demo outputs
7. Docs - All documentation, guides, and references
8. App - Core application code, dependencies, and runtime files

IMPORTANT: Runs preflight cleanup before archiving to ensure clean, deployable state.
"""

import os
import sys
import shutil
import zipfile
import subprocess
from pathlib import Path
from datetime import datetime
import json
import logging
import argparse

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FullSiteArchiver:
    """Creates segmented archives for air-gapped deployment"""
    
    def __init__(self, project_root=None, archive_dir="_archive"):
        self.project_root = Path(project_root or Path.cwd())
        self.archive_dir = self.project_root / archive_dir
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Archive definitions - paths relative to project root
        self.archive_segments = {
            "1_knowledge_base": {
                "description": "Research papers, whitepapers, and reference documentation",
                "patterns": [
                    "knowledge_base/**/*"  # Only from knowledge_base folder
                ],
                "exclude_patterns": [
                    "*.zip",
                    "*.tar*"
                ]
            },
            "2_database": {
                "description": "Database schemas, migrations, and data files",
                "patterns": [
                    "database/**/*",
                    "**/*.db",
                    "**/*.sqlite",
                    "**/*.sql", 
                    "**/migrations/**/*",
                    "**/schemas/**/*",
                    "sparse/**/*",  # Sparse agreements data
                    "vectorqa_sage/**/*"  # VectorQA database components
                ]
            },
            "3_credentials": {
                "description": "Configuration and environment files (sanitized)",
                "patterns": [
                    "src/config/**/*",
                    "src/environ_settings/**/*",
                    "*.env.example",
                    "*.env.template", 
                    "**/config.yaml",
                    "**/config.json",
                    "pyproject.toml",
                    "requirements*.txt",
                    "poetry.lock",
                    "Pipfile*"
                ],
                "exclude_patterns": [
                    "*.env",  # Exclude actual env files
                    "**/*secret*",
                    "**/*key*", 
                    "**/*token*",
                    "**/*password*"
                ]
            },
            "4_historical_data": {
                "description": "Historical data and large datasets (OPTIONAL - may be large)", 
                "patterns": [
                    "data/input/2022_pre/**/*",
                    "data/input/2023/**/*",
                    "data/input/2024/**/*",
                    "input/omnibus/**/*"  # Large omnibus folder
                ],
                "exclude_patterns": [
                    "*.zip",  # Don't include nested zips
                    "*.tar*"  # Don't include nested archives
                ]
            },
            "5_current_input": {
                "description": "Current test files, examples, and notebooks", 
                "patterns": [
                    "test_files/**/*",
                    "sample_data/**/*",
                    "input/REV2024*.*",  # Current year files only
                    "input/*.pdf",  # PDFs in input root
                    "input/test_files/**/*",
                    "examples/**/*",
                    "notebooks/**/*.ipynb",  # Jupyter notebooks
                    "notebooks/**/*.py"  # Python demo scripts
                ],
                "exclude_patterns": [
                    "input/omnibus/**/*",  # Excluded - in historical
                    "data/input/**/*"  # Excluded - in historical
                ]
            },
            "6_output": {
                "description": "Generated reports, logs, and output directories",
                "patterns": [
                    "output/**/*",
                    "reports/**/*", 
                    "logs/**/*",
                    "demo_output/**/*",
                    "migration_bundles/**/*"  # Generated deployment bundles
                ],
                "exclude_patterns": [
                    "_archive/**/*",  # Don't archive archives!
                    "*.zip",  # No nested zips
                    "*.tar*",  # No nested tars
                    ".venv/**/*",  # No virtual environments
                    "mlruns/**/*"  # MLflow runs handled separately
                ]
            },
            "7_docs": {
                "description": "Documentation, guides, and references",
                "patterns": [
                    "docs/**/*",
                    "*.md",
                    "[0-9][0-9]-*.md",  # Numbered documentation files
                    "README*",
                    "LICENSE*",
                    "CHANGELOG*",
                    "**/*.rst",
                    "**/*.txt",
                    "**/*guide*",
                    "**/*manual*",
                    "**/*documentation*"
                ]
            },
            "8_app": {
                "description": "Core application code, dependencies, and runtime",
                "patterns": [
                    "src/**/*.py",
                    "llmdata/**/*",  # LLMData ecosystem
                    "scripts/**/*",
                    "start_*.py", 
                    "streamlit_*.py",
                    "test_*.py",
                    "**/__init__.py",
                    "**/requirements.txt",
                    "Dockerfile*",
                    "docker-compose*.yml",
                    ".dockerignore"
                ]
            }
        }
    
    def run_preflight_cleanup(self):
        """Run preflight cleanup before archiving"""
        logger.info("🛫 Running preflight cleanup...")
        
        try:
            # Check if in py311 environment
            python_version = sys.version
            if "3.11" not in python_version:
                logger.warning("⚠️ Not in py311 environment. Consider: conda activate py311")
            
            # Run main preflight cleanup
            preflight_script = self.project_root / "scripts" / "pre_flight_cleanup.py"
            if preflight_script.exists():
                logger.info("Running pre-flight cleanup...")
                result = subprocess.run([
                    sys.executable, str(preflight_script), "--cleanup"
                ], capture_output=True, text=True, cwd=self.project_root)
                
                if result.returncode == 0:
                    logger.info("✅ Pre-flight cleanup completed successfully")
                else:
                    logger.warning(f"⚠️ Pre-flight cleanup warnings: {result.stderr}")
            else:
                logger.warning(f"Pre-flight script not found at {preflight_script}")
            
            # Additional cleanup
            self._additional_cleanup()
            
        except Exception as e:
            logger.error(f"❌ Preflight cleanup failed: {e}")
            raise
    
    def _additional_cleanup(self):
        """Additional cleanup specific to archiving"""
        cleanup_patterns = [
            "**/__pycache__",
            "**/*.pyc", 
            "**/*.pyo",
            "**/*.pyd",
            "**/.pytest_cache",
            "**/node_modules",
            "**/.DS_Store",
            "**/Thumbs.db",
            "**/*.tmp",
            "**/*.temp",
            "**/core.*"  # Core dump files
        ]
        
        logger.info("🧹 Additional cleanup for archiving...")
        
        for pattern in cleanup_patterns:
            for path in self.project_root.glob(pattern):
                try:
                    if path.is_file():
                        path.unlink()
                        logger.debug(f"Removed file: {path}")
                    elif path.is_dir():
                        shutil.rmtree(path)
                        logger.debug(f"Removed directory: {path}")
                except Exception as e:
                    logger.warning(f"Failed to remove {path}: {e}")
    
    def create_archives(self):
        """Create all 6 segmented archives"""
        logger.info(f"📦 Creating segmented archives in {self.archive_dir}")
        
        # Create archive directory
        self.archive_dir.mkdir(exist_ok=True)
        
        # Create manifest
        manifest = {
            "creation_time": datetime.now().isoformat(),
            "project_root": str(self.project_root),
            "archives": {},
            "instructions": "Deploy in order: 1_knowledge_base, 2_database, 3_credentials, 4_input, 5_output, 6_docs, 7_app"
        }
        
        # Create each archive
        for segment_name, config in self.archive_segments.items():
            archive_path = self.archive_dir / f"{segment_name}_{self.timestamp}.zip"
            files_added = self._create_segment_archive(segment_name, config, archive_path)
            
            # Update manifest
            manifest["archives"][segment_name] = {
                "filename": archive_path.name,
                "description": config["description"], 
                "files_count": files_added,
                "size_mb": round(archive_path.stat().st_size / (1024*1024), 2) if archive_path.exists() else 0
            }
            
            logger.info(f"✅ Created {segment_name}: {files_added} files, "
                       f"{manifest['archives'][segment_name]['size_mb']} MB")
        
        # Save manifest
        manifest_path = self.archive_dir / f"DEPLOYMENT_MANIFEST_{self.timestamp}.json"
        with open(manifest_path, 'w') as f:
            json.dump(manifest, f, indent=2)
        
        # Create deployment instructions
        self._create_deployment_instructions(manifest)
        
        logger.info(f"🎯 Archive creation complete! Total archives: {len(self.archive_segments)}")
        return manifest
    
    def _create_segment_archive(self, segment_name, config, archive_path):
        """Create individual segment archive"""
        files_added = 0
        
        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            # Add files matching patterns
            for pattern in config["patterns"]:
                for file_path in self.project_root.glob(pattern):
                    if file_path.is_file():
                        # Check exclusions
                        if self._should_exclude_file(file_path, config.get("exclude_patterns", [])):
                            continue
                        
                        # Add to archive
                        relative_path = file_path.relative_to(self.project_root)
                        zf.write(file_path, relative_path)
                        files_added += 1
            
            # Add README for this segment
            readme_content = self._generate_segment_readme(segment_name, config)
            zf.writestr(f"README_{segment_name}.md", readme_content)
            files_added += 1
        
        return files_added
    
    def _should_exclude_file(self, file_path, exclude_patterns):
        """Check if file should be excluded"""
        # Global exclusions - ALWAYS exclude these
        global_excludes = [
            "_archive/**/*",  # Don't archive old archives
            "**/_archive/**/*",  # Any nested archive folders
            "**/*.zip",  # No zip files
            "**/*.tar",  # No tar files
            "**/*.tar.gz",  # No compressed tars
            ".venv/**/*",  # Virtual environments
            "**/.venv/**/*",  # Any virtual environment
            "**/venv/**/*",  # Alternative venv naming
            "**/node_modules/**/*",  # Node modules
            "**/__pycache__/**/*",  # Python cache
            "**/.git/**/*"  # Git directory
        ]
        
        # Check global exclusions first
        for pattern in global_excludes:
            if file_path.match(pattern):
                logger.debug(f"Globally excluding: {file_path}")
                return True
                
        # Check segment-specific exclusions
        for exclude_pattern in exclude_patterns:
            if file_path.match(exclude_pattern):
                return True
        return False
    
    def _generate_segment_readme(self, segment_name, config):
        """Generate README for each archive segment"""
        return f"""# {segment_name.replace('_', ' ').title()}

## Description
{config['description']}

## Deployment Instructions
1. Extract this archive to the target environment
2. Follow the main DEPLOYMENT_MANIFEST instructions
3. Ensure proper file permissions are set

## Contents
This archive contains files matching these patterns:
{chr(10).join('- ' + pattern for pattern in config['patterns'])}

## Generated
Created: {datetime.now().isoformat()}
System: Full Site Archiver for Air-Gapped Deployment
"""
    
    def _create_deployment_instructions(self, manifest):
        """Create comprehensive deployment instructions"""
        instructions = f"""# Air-Gapped Deployment Instructions

Generated: {manifest['creation_time']}

## 🎯 Overview
This deployment package contains 7 segmented archives for secure air-gapped environment setup.

## 📦 Archive Contents

"""
        
        for segment_name, info in manifest["archives"].items():
            instructions += f"""### {segment_name.replace('_', ' ').title()}
- **File**: `{info['filename']}`
- **Description**: {info['description']}
- **Files**: {info['files_count']} files
- **Size**: {info['size_mb']} MB

"""
        
        instructions += """## 🚀 Deployment Steps

### 1. Transfer Archives
Copy all 7 ZIP files to target air-gapped environment via approved method:
- USB drive
- CD/DVD 
- Secure file transfer
- Physical media

### 2. Extract in Order
```bash
# Create deployment directory
mkdir qaz_deployment
cd qaz_deployment

# Extract in order
unzip ../1_knowledge_base_*.zip
unzip ../2_database_*.zip
unzip ../3_credentials_*.zip  
unzip ../4_input_*.zip
unzip ../5_output_*.zip
unzip ../6_docs_*.zip
unzip ../7_app_*.zip
```

### 3. Setup Environment
```bash
# Activate Python environment (if available)
conda activate py311

# Install dependencies (if pip available)
pip install -r requirements.txt

# Or use offline wheel installation
pip install --no-index --find-links wheels -r requirements.txt
```

### 4. Configuration
1. Review `src/environ_settings/` for environment configuration
2. Update `src/config/` files for target environment
3. Validate database connections in `database/` directory

### 5. Validation
```bash
# Run preflight checks
python scripts/pre_flight_cleanup.py --validate

# Test application
python start_mvr_demo.py --test-mode
```

## 🔒 Security Notes
- Credentials archive contains only template files
- Actual secrets must be configured separately
- Review all configuration files before deployment

## ⚠️ Important Notes
- Extract in numerical order (1 → 7)
- Verify file permissions after extraction
- Check README files in each archive for specific instructions
- Maintain directory structure as extracted

## 🎯 Success Indicators
- All 7 archives extract without errors
- Application starts with `python start_mvr_demo.py`
- Preflight validation passes
- Demo functionality works correctly

---
Generated by Full Site Archiver for Air-Gapped Deployment
"""
        
        instructions_path = self.archive_dir / f"DEPLOYMENT_INSTRUCTIONS_{self.timestamp}.md"
        with open(instructions_path, 'w') as f:
            f.write(instructions)
        
        logger.info(f"📋 Created deployment instructions: {instructions_path.name}")

def main():
    parser = argparse.ArgumentParser(description="Create full site archives for air-gapped deployment")
    parser.add_argument("--skip-preflight", action="store_true", help="Skip preflight cleanup")
    parser.add_argument("--archive-dir", default="_archive", help="Archive directory (default: _archive)")
    parser.add_argument("--project-root", help="Project root directory (default: current)")
    
    args = parser.parse_args()
    
    try:
        archiver = FullSiteArchiver(
            project_root=args.project_root,
            archive_dir=args.archive_dir
        )
        
        # Run preflight cleanup unless skipped
        if not args.skip_preflight:
            archiver.run_preflight_cleanup()
        else:
            logger.info("⚠️ Skipping preflight cleanup")
        
        # Create archives
        manifest = archiver.create_archives()
        
        print(f"""
🎉 SUCCESS: Full site archived!

📦 Archives created in {archiver.archive_dir}:
""")
        
        for segment_name, info in manifest["archives"].items():
            print(f"  ✅ {info['filename']} - {info['files_count']} files ({info['size_mb']} MB)")
        
        print(f"""
📋 Deployment files:
  📄 DEPLOYMENT_MANIFEST_{archiver.timestamp}.json
  📖 DEPLOYMENT_INSTRUCTIONS_{archiver.timestamp}.md

🎯 Ready for air-gapped deployment!
""")
        
    except Exception as e:
        logger.error(f"❌ Archive creation failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()