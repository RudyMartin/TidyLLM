#!/usr/bin/env python3
"""
MVR Demo Launcher

Quick launcher for the MVR Review Streamlit demo.
Supports installation flags for different dependency sets.

Usage:
    python start_mvr_demo.py           # Default (minimal requirements)
    python start_mvr_demo.py --full    # Install complete requirements  
    python start_mvr_demo.py --install # Just install dependencies, don't launch
"""

import subprocess
import sys
import argparse
from pathlib import Path

def install_requirements(req_type="minimal"):
    """Install requirements based on type"""
    if req_type == "complete":
        req_file = "requirements_mvr_demo_complete.txt"
        print("📦 Installing complete MVR demo requirements...")
    else:
        req_file = "requirements_mvr_demo_minimal.txt"  
        print("📦 Installing minimal MVR demo requirements...")
    
    if not Path(req_file).exists():
        print(f"❌ Requirements file not found: {req_file}")
        return False
    
    result = subprocess.run([
        sys.executable, "-m", "pip", "install", "-r", req_file, "-q"
    ])
    
    if result.returncode == 0:
        print(f"✅ {req_type.title()} requirements installed successfully")
        return True
    else:
        print(f"❌ Failed to install {req_type} requirements")
        return False

def main():
    """Launch the MVR demo"""
    parser = argparse.ArgumentParser(description='MVR Demo Launcher')
    parser.add_argument('--full', action='store_true', 
                       help='Install complete requirements (default: minimal)')
    parser.add_argument('--install', action='store_true',
                       help='Only install requirements, do not launch demo')
    
    args = parser.parse_args()
    
    # Determine requirements type
    req_type = "complete" if args.full else "minimal"
    
    # Install requirements
    if not install_requirements(req_type):
        return
    
    # If only installing, exit here
    if args.install:
        print("🎯 Installation complete. Run without --install to launch demo.")
        return
    
    app_file = Path(__file__).parent / "streamlit_mvr_demo.py"
    
    if not app_file.exists():
        print(f"❌ App file not found: {app_file}")
        return
    
    print("🧹 Clearing any existing Streamlit processes...")
    subprocess.run(["pkill", "-f", "streamlit"], capture_output=True)
    
    print("🔍 Testing MVR Demo Dependencies...")
    test_result = subprocess.run([
        sys.executable, "-c",
        """
import streamlit_mvr_demo
demo = streamlit_mvr_demo.MVRDemo()
print('🎉 MVR Demo - All Dependencies Resolved')
print('✅ System Status:')
print(f'   📚 LLMData: {streamlit_mvr_demo.LLMDATA_AVAILABLE}')
print(f'   🛠️ MCP: {streamlit_mvr_demo.MCP_AVAILABLE}')
print(f'   🚀 System Ready: {streamlit_mvr_demo.SYSTEM_READY}')
        """
    ], env={"PYTHONPATH": "src", **subprocess.os.environ}, capture_output=True, text=True)
    
    if test_result.returncode == 0:
        print(test_result.stdout)
    else:
        print("⚠️ Warning: Some dependencies may be missing")
        print(test_result.stderr)
    
    print("🚀 Starting MVR Review Streamlit Demo...")
    print(f"📁 App: {app_file}")
    print("🌐 URL: http://localhost:8501")
    print("⏹️  Press Ctrl+C to stop")
    print("-" * 50)
    
    # Launch with streamlit
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", str(app_file),
        "--server.port", "8501",
        "--server.address", "0.0.0.0"
    ])

if __name__ == "__main__":
    main()

