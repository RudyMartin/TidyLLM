#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Verbs - TidyLLM-style Pipeline Operations

Python equivalent of tidyLLM's verb-based interface for LLM operations.
Provides chat(), embed(), analyze_data(), and other pipeline verbs that work
seamlessly with the | operator.
"""

from typing import Union, List, Dict, Any, Optional, Callable
import asyncio
import json
from datetime import datetime
import uuid

from .core import LLMMessage, Provider
from .gateway import MLFlowGateway, get_default_gateway
from . import dt
from . import numpy_compat as np

# Import attachments grammar when available
try:
    from .attachments_enhanced import attach, load, present, refine
    ATTACHMENTS_AVAILABLE = True
except ImportError:
    ATTACHMENTS_AVAILABLE = False
    print("⚠️ Attachments Enhanced not available - file processing limited")
    # Create placeholder functions if not available
    def attach(*files): 
        return None
    class load:
        @staticmethod
        def auto(): return lambda x: x
    class present:
        @staticmethod
        def markdown(): return lambda x: x
        @staticmethod
        def images(): return lambda x: x
        @staticmethod
        def data_summary(): return lambda x: x
    class refine:
        @staticmethod
        def add_headers(): return lambda x: x

# MLFlow integration
try:
    import mlflow
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False
    print("⚠️ MLFlow not available - experiment tracking disabled")


def chat(provider: Provider, stream: bool = False, **kwargs) -> Callable[[LLMMessage], LLMMessage]:
    """
    Chat verb that routes through MLFlow Gateway.
    
    TidyLLM-style verb for conversational LLM interactions with enhanced capabilities.
    
    Args:
        provider: LLM provider configuration
        stream: Enable streaming responses
        **kwargs: Additional chat parameters
        
    Returns:
        Function that processes LLMMessage through chat pipeline
        
    Examples:
        # Basic chat
        response = llm_message("Hello") | chat(claude())
        
        # With configuration
        response = llm_message("Analyze data") | chat(
            claude(model="claude-3-5-sonnet", temperature=0.1)
        )
    """
    
    def _chat(msg: LLMMessage) -> LLMMessage:
        try:
            start_time = datetime.now()
            
            # Process any attachments using Attachments grammar
            processed_content = msg.content
            combined_attachments = None
            attachment_metadata = {}
            
            if msg.attachments and ATTACHMENTS_AVAILABLE:
                try:
                    # Use Attachments pipeline for file processing
                    combined_attachments = (attach(*msg.attachments)
                                          | load.auto()
                                          | present.markdown() + present.images() + present.data_summary()
                                          | refine.add_headers())
                    
                    processed_content += f"\n\nAttached Content:\n{combined_attachments.text}"
                    attachment_metadata = {
                        'processed_files': len(msg.attachments),
                        'content_types': combined_attachments.content_types,
                        'total_size': combined_attachments.total_size
                    }
                except Exception as e:
                    print(f"⚠️ Attachment processing failed: {e}")
                    processed_content += f"\n\nNote: {len(msg.attachments)} files attached but could not be processed."
            
            # Get gateway instance
            gateway = get_default_gateway()
            
            # Prepare request data
            messages = msg.get_conversation_context() + [{
                "role": "user", 
                "content": processed_content
            }]
            
            request_data = {
                "messages": messages,
                "model": provider.model,
                "stream": stream,
                **provider.config,
                **kwargs
            }
            
            # Add images if available
            if combined_attachments and hasattr(combined_attachments, 'images'):
                request_data["images"] = combined_attachments.images
            
            # Route through MLFlow Gateway with experiment tracking
            response_content = ""
            usage_metrics = {}
            
            if MLFLOW_AVAILABLE:
                with mlflow.start_run():
                    # Log input parameters
                    mlflow.log_param("provider", provider.endpoint)
                    mlflow.log_param("model", provider.model)
                    mlflow.log_param("num_attachments", len(msg.attachments))
                    mlflow.log_param("content_length", len(processed_content))
                    
                    # Query gateway
                    response = gateway.query(
                        endpoint=provider.endpoint,
                        data=request_data
                    )
                    
                    # Extract response content
                    response_content = response.get("content", response.get("choices", [{}])[0].get("message", {}).get("content", ""))
                    
                    # Log response metrics
                    if "usage" in response:
                        usage_metrics = response["usage"]
                        mlflow.log_metric("tokens_input", usage_metrics.get("prompt_tokens", 0))
                        mlflow.log_metric("tokens_output", usage_metrics.get("completion_tokens", 0))
                        mlflow.log_metric("tokens_total", usage_metrics.get("total_tokens", 0))
                    
                    # Log timing
                    processing_time = (datetime.now() - start_time).total_seconds()
                    mlflow.log_metric("processing_time_seconds", processing_time)
                    
                    # Log attachment metadata
                    if attachment_metadata:
                        for key, value in attachment_metadata.items():
                            mlflow.log_param(f"attachment_{key}", value)
            
            else:
                # Direct gateway query without MLFlow
                response = gateway.query(
                    endpoint=provider.endpoint,
                    data=request_data
                )
                response_content = response.get("content", response.get("choices", [{}])[0].get("message", {}).get("content", ""))
            
            # Update message history
            msg.history.append({
                "role": "user", 
                "content": processed_content,
                "attachments": msg.attachments,
                "timestamp": start_time.isoformat()
            })
            
            msg.history.append({
                "role": "assistant", 
                "content": response_content,
                "provider": f"{provider.endpoint}:{provider.model}",
                "usage": usage_metrics,
                "processing_time": (datetime.now() - start_time).total_seconds(),
                "timestamp": datetime.now().isoformat()
            })
            
            # Update message metadata
            msg.metadata.update({
                "last_provider": provider.endpoint,
                "last_model": provider.model,
                "total_interactions": len([h for h in msg.history if h.get("role") == "assistant"]),
                "attachment_metadata": attachment_metadata
            })
            
            return msg
            
        except Exception as e:
            # Error handling
            error_msg = f"Chat error: {str(e)}"
            print(f"❌ {error_msg}")
            
            msg.history.append({
                "role": "error",
                "content": error_msg,
                "timestamp": datetime.now().isoformat(),
                "provider": f"{provider.endpoint}:{provider.model}"
            })
            
            return msg
    
    return _chat


def embed(provider: Provider, **kwargs) -> Callable[[LLMMessage], dt.Frame]:
    """
    Embedding verb with DataTable integration.
    
    Converts text content to vector embeddings using specified provider,
    returning results as DataTable Frame for downstream processing.
    
    Args:
        provider: LLM provider configuration (must support embeddings)
        **kwargs: Additional embedding parameters
        
    Returns:
        Function that converts LLMMessage to embedding DataTable
        
    Examples:
        # Basic embedding
        embeddings = llm_message("Customer feedback") | embed(openai())
        
        # With file processing
        doc_embeddings = llm_message("Analyze", "report.pdf") | embed(claude())
    """
    
    def _embed(msg: LLMMessage) -> dt.Frame:
        try:
            # Process text through Attachments if files present
            text_to_embed = msg.content
            
            if msg.attachments and ATTACHMENTS_AVAILABLE:
                try:
                    processed = (attach(*msg.attachments) 
                                | load.auto() 
                                | present.text())
                    text_to_embed = f"{msg.content}\n\n{processed.text}"
                except Exception as e:
                    print(f"⚠️ Attachment processing failed for embedding: {e}")
            
            # Get gateway instance
            gateway = get_default_gateway()
            
            # Prepare embedding request
            request_data = {
                "input": text_to_embed,
                "model": provider.model,
                **kwargs
            }
            
            # Get embeddings via gateway
            response = gateway.query(
                endpoint=provider.embedding_endpoint or f"{provider.endpoint.split('-')[0]}-embeddings",
                data=request_data
            )
            
            # Extract embeddings data
            embeddings_data = response.get("data", [])
            if not embeddings_data:
                # Fallback structure
                embeddings_data = [{"embedding": [0.0] * 1536}]  # Default dimension
            
            # Create DataTable Frame
            if dt.DATATABLE_AVAILABLE:
                frame = dt.Frame({
                    "message_id": [msg.message_id],
                    "text": [text_to_embed],
                    "embedding": [emb["embedding"] for emb in embeddings_data],
                    "provider": [provider.endpoint],
                    "model": [provider.model],
                    "embedding_dim": [len(embeddings_data[0]["embedding"]) if embeddings_data else 0],
                    "timestamp": [datetime.now().isoformat()]
                })
            else:
                # Fallback to simple structure
                frame = {
                    "message_id": [msg.message_id],
                    "text": [text_to_embed],
                    "embedding": [emb["embedding"] for emb in embeddings_data],
                    "provider": [provider.endpoint],
                    "model": [provider.model]
                }
            
            # Log to MLFlow if available
            if MLFLOW_AVAILABLE:
                with mlflow.start_run():
                    mlflow.log_param("embedding_provider", provider.endpoint)
                    mlflow.log_param("embedding_model", provider.model)
                    mlflow.log_param("text_length", len(text_to_embed))
                    mlflow.log_metric("embedding_dimension", len(embeddings_data[0]["embedding"]) if embeddings_data else 0)
            
            return frame
            
        except Exception as e:
            print(f"❌ Embedding error: {e}")
            # Return empty frame
            if dt.DATATABLE_AVAILABLE:
                return dt.Frame({"error": [str(e)]})
            else:
                return {"error": [str(e)]}
    
    return _embed


def analyze_data(data_source: Union[str, dt.Frame], provider: Provider, **kwargs) -> Callable[[LLMMessage], LLMMessage]:
    """
    Analyze data using LLM with DataTable backend.
    
    Enhanced verb that combines data analysis with LLM capabilities.
    Loads data using DataTable for performance, generates summaries using
    numpy compatibility layer, then routes through LLM for insights.
    
    Args:
        data_source: File path or DataTable Frame
        provider: LLM provider for analysis
        **kwargs: Additional analysis parameters
        
    Returns:
        Function that enhances LLMMessage with data analysis context
        
    Examples:
        # Analyze CSV data
        insights = (llm_message("What patterns do you see?")
                   | analyze_data("sales.csv", claude()))
        
        # Chain with chat
        report = (llm_message("Generate executive summary")
                 | analyze_data("metrics.csv", claude())
                 | chat(openai()))
    """
    
    def _analyze_data(msg: LLMMessage) -> LLMMessage:
        try:
            start_time = datetime.now()
            
            # Load data using DataTable (fast)
            if isinstance(data_source, str):
                if dt.DATATABLE_AVAILABLE:
                    df = dt.fread(data_source)
                else:
                    # Fallback - try to read as simple CSV
                    import csv
                    with open(data_source, 'r') as f:
                        reader = csv.DictReader(f)
                        df = list(reader)
            else:
                df = data_source
            
            # Generate data summary using numpy compat functions
            summary = _generate_data_summary(df)
            
            # Enhanced analysis based on data characteristics
            analysis_insights = _generate_analysis_insights(df, summary)
            
            # Combine with user message
            enhanced_content = f"""{msg.content}

## Data Analysis Context

{summary}

## Statistical Insights

{analysis_insights}

## Data-Driven Analysis Request

Please analyze this data in the context of: "{msg.content}"
Focus on patterns, trends, anomalies, and actionable insights."""
            
            # Create enhanced message with data context
            enhanced_msg = LLMMessage(enhanced_content, msg.attachments)
            enhanced_msg.message_id = msg.message_id
            enhanced_msg.history = msg.history.copy()
            enhanced_msg.metadata = msg.metadata.copy()
            
            # Add data metadata
            enhanced_msg.metadata.update({
                'data_source': str(data_source),
                'data_analysis': {
                    'summary': summary,
                    'insights': analysis_insights,
                    'processing_time': (datetime.now() - start_time).total_seconds()
                }
            })
            
            # Log data analysis to MLFlow
            if MLFLOW_AVAILABLE:
                with mlflow.start_run():
                    mlflow.log_param("data_source", str(data_source))
                    mlflow.log_param("analysis_provider", provider.endpoint)
                    
                    if dt.DATATABLE_AVAILABLE and hasattr(df, 'nrows'):
                        mlflow.log_metric("data_rows", df.nrows)
                        mlflow.log_metric("data_columns", df.ncols)
                    elif isinstance(df, list):
                        mlflow.log_metric("data_rows", len(df))
                        mlflow.log_metric("data_columns", len(df[0]) if df else 0)
            
            return enhanced_msg
            
        except Exception as e:
            print(f"❌ Data analysis error: {e}")
            
            # Return original message with error note
            error_content = f"{msg.content}\n\n⚠️ Data analysis failed: {str(e)}"
            error_msg = LLMMessage(error_content, msg.attachments)
            error_msg.message_id = msg.message_id
            error_msg.history = msg.history.copy()
            error_msg.metadata = msg.metadata.copy()
            error_msg.metadata['data_analysis_error'] = str(e)
            
            return error_msg
    
    return _analyze_data


def send_batch(messages: List[LLMMessage], provider: Provider, **kwargs) -> List[LLMMessage]:
    """
    Send batch of messages for parallel processing.
    
    Processes multiple messages concurrently using the same provider.
    Equivalent to tidyLLM's batch processing capabilities.
    
    Args:
        messages: List of LLMMessage objects
        provider: LLM provider for all messages
        **kwargs: Additional parameters for chat
        
    Returns:
        List of processed LLMMessage objects
        
    Examples:
        # Process multiple questions
        questions = [
            llm_message("Summarize Q1"),
            llm_message("Analyze Q2 trends"),
            llm_message("Forecast Q3")
        ]
        results = send_batch(questions, claude())
    """
    
    async def _process_message_async(message: LLMMessage) -> LLMMessage:
        """Process single message asynchronously."""
        return chat(provider, **kwargs)(message)
    
    async def _process_batch_async():
        """Process all messages concurrently."""
        tasks = [_process_message_async(msg) for msg in messages]
        return await asyncio.gather(*tasks, return_exceptions=True)
    
    try:
        # Run async batch processing
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        results = loop.run_until_complete(_process_batch_async())
        loop.close()
        
        # Handle any exceptions
        processed_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                # Create error message
                error_msg = messages[i]
                error_msg.history.append({
                    "role": "error",
                    "content": f"Batch processing error: {str(result)}",
                    "timestamp": datetime.now().isoformat()
                })
                processed_results.append(error_msg)
            else:
                processed_results.append(result)
        
        # Log batch metrics
        if MLFLOW_AVAILABLE:
            with mlflow.start_run():
                mlflow.log_param("batch_size", len(messages))
                mlflow.log_param("batch_provider", provider.endpoint)
                successful = sum(1 for r in processed_results if not any(h.get("role") == "error" for h in r.history))
                mlflow.log_metric("batch_success_rate", successful / len(messages))
        
        return processed_results
        
    except Exception as e:
        print(f"❌ Batch processing error: {e}")
        
        # Return all messages with error status
        for msg in messages:
            msg.history.append({
                "role": "error",
                "content": f"Batch processing failed: {str(e)}",
                "timestamp": datetime.now().isoformat()
            })
        
        return messages


def stream_chat(provider: Provider, **kwargs) -> Callable[[LLMMessage], LLMMessage]:
    """
    Streaming chat verb for real-time responses.
    
    Similar to chat() but with streaming support for real-time output.
    
    Args:
        provider: LLM provider configuration
        **kwargs: Additional streaming parameters
        
    Returns:
        Function that processes LLMMessage with streaming
    """
    return chat(provider, stream=True, **kwargs)


def retry(max_attempts: int = 3, backoff: float = 1.0) -> Callable[[Callable], Callable]:
    """
    Retry decorator for verbs.
    
    Adds retry logic to any verb operation with exponential backoff.
    
    Args:
        max_attempts: Maximum retry attempts
        backoff: Backoff multiplier
        
    Returns:
        Decorator function
        
    Examples:
        # Retry chat operation
        response = (llm_message("Hello")
                   | retry(3)(chat(claude())))
    """
    
    def _retry_decorator(verb_func: Callable) -> Callable:
        def _retry_wrapper(msg: LLMMessage) -> LLMMessage:
            last_error = None
            
            for attempt in range(max_attempts):
                try:
                    return verb_func(msg)
                except Exception as e:
                    last_error = e
                    if attempt < max_attempts - 1:
                        import time
                        time.sleep(backoff * (2 ** attempt))
                        continue
                    break
            
            # All attempts failed
            msg.history.append({
                "role": "error",
                "content": f"All {max_attempts} retry attempts failed. Last error: {str(last_error)}",
                "timestamp": datetime.now().isoformat()
            })
            
            return msg
        
        return _retry_wrapper
    
    return _retry_decorator


# Helper functions

def _generate_data_summary(df) -> str:
    """Generate LLM-friendly data summary using numpy compat."""
    try:
        if dt.DATATABLE_AVAILABLE and hasattr(df, 'nrows'):
            # DataTable Frame
            summary = f"Dataset Overview:\n"
            summary += f"- Rows: {df.nrows:,}\n"
            summary += f"- Columns: {df.ncols}\n"
            summary += f"- Column Names: {', '.join(df.names)}\n\n"
            
            # Try to get numeric summary
            try:
                numeric_cols = [name for name in df.names if df[name].type.name in ['int', 'float', 'real']]
                if numeric_cols:
                    summary += "Numeric Columns Summary:\n"
                    for col in numeric_cols[:5]:  # Limit to first 5
                        col_data = df[col].to_list()[0]
                        if isinstance(col_data, list) and col_data:
                            summary += f"- {col}: mean={np.mean(col_data):.2f}, std={np.std(col_data):.2f}\n"
            except:
                pass
                
        elif isinstance(df, list) and df:
            # List of dicts (CSV fallback)
            summary = f"Dataset Overview:\n"
            summary += f"- Rows: {len(df):,}\n"
            summary += f"- Columns: {len(df[0]) if df else 0}\n"
            summary += f"- Column Names: {', '.join(df[0].keys()) if df else 'None'}\n\n"
            
        else:
            summary = "Dataset: Unable to analyze structure\n"
            
        return summary
        
    except Exception as e:
        return f"Data Summary Error: {str(e)}\n"


def _generate_analysis_insights(df, summary: str) -> str:
    """Generate analysis insights from data."""
    try:
        insights = "Key Characteristics:\n"
        
        # Basic insights based on data shape
        if dt.DATATABLE_AVAILABLE and hasattr(df, 'nrows'):
            if df.nrows > 100000:
                insights += "- Large dataset suitable for statistical analysis\n"
            elif df.nrows > 1000:
                insights += "- Medium dataset with good sample size\n"
            else:
                insights += "- Small dataset - consider sample size limitations\n"
                
            if df.ncols > 20:
                insights += "- High-dimensional data - consider dimensionality\n"
            elif df.ncols > 5:
                insights += "- Multi-variate dataset with several features\n"
            else:
                insights += "- Simple dataset structure\n"
        
        insights += "\nRecommended Analysis Approaches:\n"
        insights += "- Descriptive statistics and distributions\n"
        insights += "- Correlation analysis between variables\n"
        insights += "- Trend identification and pattern recognition\n"
        insights += "- Outlier detection and data quality assessment\n"
        
        return insights
        
    except Exception as e:
        return f"Analysis Insights Error: {str(e)}\n"


# Advanced composition verbs

def compose(*verbs) -> Callable[[LLMMessage], LLMMessage]:
    """
    Compose multiple verbs into single pipeline operation.
    
    Args:
        *verbs: Sequence of verb functions
        
    Returns:
        Composed pipeline function
        
    Examples:
        # Create reusable pipeline
        analysis_pipeline = compose(
            analyze_data("data.csv", claude()),
            chat(openai()),
            embed(claude())
        )
        
        result = llm_message("Analyze trends") | analysis_pipeline
    """
    
    def _composed_pipeline(msg: LLMMessage) -> LLMMessage:
        current_msg = msg
        for verb in verbs:
            current_msg = verb(current_msg)
        return current_msg
    
    return _composed_pipeline


# Package exports
__all__ = [
    # Core verbs
    'chat',
    'embed', 
    'analyze_data',
    'send_batch',
    'stream_chat',
    
    # Utility verbs
    'retry',
    'compose',
    
    # Helper functions
    '_generate_data_summary',
    '_generate_analysis_insights',
]