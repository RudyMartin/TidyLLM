#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Enhanced Attachments - TidyLLM-style Attachment Processing

Provides a tidyLLM-inspired grammar for handling file attachments:
- attach(*files) | load.auto() | present.markdown + present.images
- Integrates with existing ImageProcessingWorker infrastructure  
- Supports PNG, JPG, PDF, CSV, TXT and other formats
- Pipeline-based processing with TidyLLM-style operators
"""

import logging
import base64
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
import json
from datetime import datetime

logger = logging.getLogger(__name__)

# Integration with existing infrastructure
try:
    import sys
    backend_path = Path(__file__).parent.parent / 'src'
    if str(backend_path) not in sys.path:
        sys.path.insert(0, str(backend_path))
    
    from backend.mcp.workers.image_processing_worker import ImageProcessingWorker, ImageProcessingMode
    from backend.core.mcp_message import MCPMessage
    EXISTING_INFRASTRUCTURE_AVAILABLE = True
except ImportError:
    EXISTING_INFRASTRUCTURE_AVAILABLE = False

# PIL for basic image handling
try:
    from PIL import Image
    import io
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False

class AttachmentCollection:
    """Collection of file attachments with processing pipeline capabilities"""
    
    def __init__(self, files: List[str]):
        self.files = files
        self.processed_data = {}
        self.text_content = ""
        self.images = []
        self.metadata = {}
        
    def __or__(self, operation):
        """Pipeline operator for TidyLLM-style processing"""
        return operation(self)

class LoadOperations:
    """TidyLLM-style loading operations"""
    
    @staticmethod
    def auto():
        """Automatically detect and load file types"""
        def _auto_load(collection: AttachmentCollection) -> AttachmentCollection:
            for file_path in collection.files:
                path = Path(file_path)
                
                if not path.exists():
                    logger.warning(f"File not found: {file_path}")
                    continue
                
                # Route by file extension
                suffix = path.suffix.lower()
                
                if suffix in ['.png', '.jpg', '.jpeg', '.gif', '.webp']:
                    _load_image(collection, file_path)
                elif suffix in ['.txt', '.md', '.py', '.js', '.html', '.css']:
                    _load_text(collection, file_path)
                elif suffix == '.pdf':
                    _load_pdf(collection, file_path)
                elif suffix in ['.csv', '.tsv']:
                    _load_csv(collection, file_path)
                elif suffix == '.json':
                    _load_json(collection, file_path)
                else:
                    # Try as text
                    _load_text(collection, file_path)
            
            return collection
        
        return _auto_load
    
    @staticmethod
    def text_only():
        """Load only text-based files"""
        def _text_only_load(collection: AttachmentCollection) -> AttachmentCollection:
            for file_path in collection.files:
                _load_text(collection, file_path)
            return collection
        return _text_only_load
    
    @staticmethod
    def images_only():
        """Load only image files"""
        def _images_only_load(collection: AttachmentCollection) -> AttachmentCollection:
            for file_path in collection.files:
                _load_image(collection, file_path)
            return collection
        return _images_only_load

def _load_image(collection: AttachmentCollection, file_path: str):
    """Load image using existing infrastructure or fallback"""
    
    # Try existing ImageProcessingWorker first
    if EXISTING_INFRASTRUCTURE_AVAILABLE:
        try:
            worker = ImageProcessingWorker(mode=ImageProcessingMode.ENHANCED)
            mcp_msg = MCPMessage(
                content=f"Process image: {file_path}",
                attachments=[file_path],
                metadata={"image_path": file_path}
            )
            
            result = worker.process_task(mcp_msg)
            
            if result.get('success') and result.get('processing', {}).get('images'):
                for img_data in result['processing']['images']:
                    collection.images.append({
                        'path': file_path,
                        'data': img_data.get('data', ''),
                        'mime_type': img_data.get('mime_type', 'image/jpeg'),
                        'metadata': img_data.get('metadata', {}),
                        'source': 'existing_worker'
                    })
                return
        except Exception as e:
            logger.warning(f"Existing image worker failed for {file_path}: {e}")
    
    # Fallback to basic PIL processing
    if PILLOW_AVAILABLE:
        try:
            with open(file_path, 'rb') as f:
                image_data = f.read()
            
            with Image.open(io.BytesIO(image_data)) as img:
                collection.images.append({
                    'path': file_path,
                    'data': base64.b64encode(image_data).decode('utf-8'),
                    'mime_type': f'image/{Path(file_path).suffix.lower()[1:]}',
                    'metadata': {
                        'width': img.width,
                        'height': img.height,
                        'format': img.format,
                        'mode': img.mode
                    },
                    'source': 'pillow_fallback'
                })
        except Exception as e:
            logger.error(f"Failed to load image {file_path}: {e}")

def _load_text(collection: AttachmentCollection, file_path: str):
    """Load text file content"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        collection.text_content += f"\n\n--- {Path(file_path).name} ---\n{content}"
        collection.processed_data[file_path] = {
            'type': 'text',
            'content': content,
            'size': len(content)
        }
    except Exception as e:
        logger.error(f"Failed to load text file {file_path}: {e}")

def _load_pdf(collection: AttachmentCollection, file_path: str):
    """Load PDF using existing infrastructure if available"""
    
    # Try using existing PDF processing infrastructure
    if EXISTING_INFRASTRUCTURE_AVAILABLE:
        try:
            # Import existing PDF workers
            from backend.mcp.workers.modern_pdf_processor import ModernPDFProcessor
            
            processor = ModernPDFProcessor()
            mcp_msg = MCPMessage(
                content=f"Process PDF: {file_path}",
                attachments=[file_path],
                metadata={"pdf_path": file_path}
            )
            
            result = processor.process_task(mcp_msg)
            
            if result.get('success'):
                # Extract text content
                if result.get('text'):
                    collection.text_content += f"\n\n--- {Path(file_path).name} (PDF) ---\n{result['text']}"
                
                # Extract images
                if result.get('images'):
                    for img in result['images']:
                        collection.images.append({
                            'path': file_path,
                            'data': img.get('data', ''),
                            'mime_type': 'image/png',
                            'metadata': img.get('metadata', {}),
                            'source': 'pdf_extractor'
                        })
                
                collection.processed_data[file_path] = {
                    'type': 'pdf',
                    'content': result.get('text', ''),
                    'images_count': len(result.get('images', [])),
                    'processing_method': result.get('processing_method', 'unknown')
                }
                return
                
        except Exception as e:
            logger.warning(f"PDF processing with existing infrastructure failed: {e}")
    
    # Basic fallback - treat as binary
    collection.processed_data[file_path] = {
        'type': 'pdf',
        'content': f"PDF file: {file_path} (content extraction not available)",
        'size': Path(file_path).stat().st_size if Path(file_path).exists() else 0
    }

def _load_csv(collection: AttachmentCollection, file_path: str):
    """Load CSV file"""
    try:
        import csv
        
        with open(file_path, 'r', encoding='utf-8') as f:
            # Read first few lines for preview
            content = f.read()
            lines = content.split('\n')[:20]  # First 20 lines
            preview = '\n'.join(lines)
        
        collection.text_content += f"\n\n--- {Path(file_path).name} (CSV Preview) ---\n{preview}"
        collection.processed_data[file_path] = {
            'type': 'csv',
            'content': content,
            'preview': preview,
            'line_count': len(content.split('\n'))
        }
    except Exception as e:
        logger.error(f"Failed to load CSV file {file_path}: {e}")

def _load_json(collection: AttachmentCollection, file_path: str):
    """Load JSON file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        formatted_json = json.dumps(data, indent=2)
        collection.text_content += f"\n\n--- {Path(file_path).name} (JSON) ---\n{formatted_json}"
        collection.processed_data[file_path] = {
            'type': 'json',
            'data': data,
            'content': formatted_json
        }
    except Exception as e:
        logger.error(f"Failed to load JSON file {file_path}: {e}")

class PresentOperations:
    """TidyLLM-style presentation operations"""
    
    @staticmethod
    def markdown():
        """Present content as markdown"""
        def _markdown_present(collection: AttachmentCollection) -> AttachmentCollection:
            # Format text content as markdown
            if collection.text_content:
                collection.text_content = f"# Attached Documents\n\n{collection.text_content}"
            
            return collection
        return _markdown_present
    
    @staticmethod
    def images():
        """Present images for multimodal processing"""
        def _images_present(collection: AttachmentCollection) -> AttachmentCollection:
            # Images are already processed and available in collection.images
            return collection
        return _images_present
    
    @staticmethod
    def data_summary():
        """Generate data summaries"""
        def _data_summary_present(collection: AttachmentCollection) -> AttachmentCollection:
            summary_parts = []
            
            for file_path, data in collection.processed_data.items():
                if data['type'] == 'csv':
                    summary_parts.append(f"- {Path(file_path).name}: CSV with {data.get('line_count', 0)} rows")
                elif data['type'] == 'json':
                    summary_parts.append(f"- {Path(file_path).name}: JSON data structure")
                elif data['type'] == 'pdf':
                    img_count = data.get('images_count', 0)
                    summary_parts.append(f"- {Path(file_path).name}: PDF with {img_count} images")
                else:
                    size = data.get('size', 0)
                    summary_parts.append(f"- {Path(file_path).name}: {data['type']} ({size} chars)")
            
            if len(collection.images) > 0:
                summary_parts.append(f"- Images: {len(collection.images)} total")
            
            if summary_parts:
                summary = "## Attachment Summary\n\n" + "\n".join(summary_parts)
                collection.text_content = summary + "\n\n" + collection.text_content
            
            return collection
        return _data_summary_present
    
    @staticmethod
    def text():
        """Present as plain text"""
        def _text_present(collection: AttachmentCollection) -> AttachmentCollection:
            return collection
        return _text_present

class RefineOperations:
    """TidyLLM-style refinement operations"""
    
    @staticmethod
    def add_headers():
        """Add structured headers to content"""
        def _add_headers(collection: AttachmentCollection) -> AttachmentCollection:
            if collection.text_content:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                header = f"# Document Processing Results\n*Generated: {timestamp}*\n\n"
                collection.text_content = header + collection.text_content
            
            return collection
        return _add_headers
    
    @staticmethod
    def limit_content(max_chars: int = 10000):
        """Limit content size for LLM processing"""
        def _limit_content(collection: AttachmentCollection) -> AttachmentCollection:
            if len(collection.text_content) > max_chars:
                collection.text_content = collection.text_content[:max_chars] + f"\n\n... (truncated to {max_chars} characters)"
            
            return collection
        return _limit_content

# TidyLLM-style factory functions
def attach(*files: str) -> AttachmentCollection:
    """
    Create attachment collection with TidyLLM-style interface
    
    Usage:
        processed = (attach("doc.pdf", "chart.png", "data.csv")
                    | load.auto()
                    | present.markdown() + present.images() + present.data_summary()
                    | refine.add_headers())
    """
    return AttachmentCollection(list(files))

# Create instances for TidyLLM-style access
load = LoadOperations()
present = PresentOperations()
refine = RefineOperations()

# Operator overloading for combining presentations
class CombinedPresenter:
    def __init__(self, *presenters):
        self.presenters = presenters
    
    def __call__(self, collection: AttachmentCollection) -> AttachmentCollection:
        for presenter in self.presenters:
            collection = presenter(collection)
        return collection
    
    def __add__(self, other):
        return CombinedPresenter(*self.presenters, other)

# Override presentation methods to support combination
present.markdown = lambda: CombinedPresenter(present.markdown())
present.images = lambda: CombinedPresenter(present.images())  
present.data_summary = lambda: CombinedPresenter(present.data_summary())
present.text = lambda: CombinedPresenter(present.text())

__all__ = [
    'attach', 'load', 'present', 'refine',
    'AttachmentCollection', 
    'EXISTING_INFRASTRUCTURE_AVAILABLE',
    'PILLOW_AVAILABLE'
]

logger.info("📎 LLMData Enhanced Attachments loaded")
if EXISTING_INFRASTRUCTURE_AVAILABLE:
    logger.info("🔗 Integrated with existing PDF and image processing infrastructure")
if PILLOW_AVAILABLE:
    logger.info("✅ PIL/Pillow available for image processing")
else:
    logger.info("⚠️ PIL/Pillow not available - limited image processing")