#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Gateway - MLFlow Gateway Integration

Provides centralized LLM access through MLFlow Gateway with enterprise features:
- Centralized API management
- Rate limiting and quotas
- Authentication and security
- Request/response logging
- Provider abstraction
"""

from typing import Dict, Any, Optional, List
import json
import time
from datetime import datetime
import uuid
import requests
from dataclasses import dataclass

# MLFlow integration
try:
    import mlflow
    from mlflow.gateway import MlflowGatewayClient
    MLFLOW_AVAILABLE = True
except ImportError:
    MLFLOW_AVAILABLE = False
    # Silently fall back - don't print warning in production


@dataclass
class GatewayConfig:
    """Gateway configuration."""
    base_url: str = "http://localhost:5000"
    timeout: int = 30
    max_retries: int = 3
    enable_logging: bool = True
    rate_limit: Optional[int] = None  # requests per minute


class MLFlowGateway:
    """
    MLFlow Gateway client with enhanced enterprise features.
    
    Provides unified interface to multiple LLM providers through MLFlow Gateway,
    with built-in governance, monitoring, and performance optimization.
    """
    
    def __init__(self, config: Optional[GatewayConfig] = None):
        self.config = config or GatewayConfig()
        self.client = None
        self.request_history = []
        self.rate_limiter = RateLimiter(self.config.rate_limit) if self.config.rate_limit else None
        
        # Initialize MLFlow client if available
        if MLFLOW_AVAILABLE:
            try:
                self.client = MlflowGatewayClient(gateway_uri=self.config.base_url)
            except Exception as e:
                print(f"⚠️ MLFlow Gateway client initialization failed: {e}")
                self.client = None
        
        # Fallback HTTP client
        self.session = requests.Session()
        self.session.timeout = self.config.timeout
    
    def query(
        self, 
        endpoint: str, 
        data: Dict[str, Any], 
        **kwargs
    ) -> Dict[str, Any]:
        """
        Query LLM through gateway with comprehensive error handling.
        
        Args:
            endpoint: Gateway endpoint name
            data: Request data
            **kwargs: Additional parameters
            
        Returns:
            LLM response data
            
        Examples:
            response = gateway.query(
                endpoint="claude-chat",
                data={
                    "messages": [{"role": "user", "content": "Hello"}],
                    "model": "claude-3-5-sonnet"
                }
            )
        """
        
        request_id = str(uuid.uuid4())
        start_time = datetime.now()
        
        try:
            # Rate limiting
            if self.rate_limiter:
                self.rate_limiter.wait_if_needed()
            
            # Log request if enabled
            if self.config.enable_logging:
                self._log_request(request_id, endpoint, data)
            
            # Try MLFlow Gateway first
            if self.client:
                response = self._query_mlflow(endpoint, data, **kwargs)
            else:
                response = self._query_http(endpoint, data, **kwargs)
            
            # Log successful response
            processing_time = (datetime.now() - start_time).total_seconds()
            if self.config.enable_logging:
                self._log_response(request_id, response, processing_time)
            
            return response
            
        except Exception as e:
            # Log error
            error_time = (datetime.now() - start_time).total_seconds()
            if self.config.enable_logging:
                self._log_error(request_id, str(e), error_time)
            
            # Retry logic
            return self._handle_error(endpoint, data, str(e), **kwargs)
    
    def _query_mlflow(self, endpoint: str, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """Query through MLFlow Gateway."""
        
        # Convert endpoint format for MLFlow
        route_name = self._convert_endpoint_to_route(endpoint)
        
        # Prepare MLFlow-compatible request
        if "chat" in endpoint:
            response = self.client.query(
                route=route_name,
                data={
                    "messages": data.get("messages", []),
                    "temperature": data.get("temperature", 0.1),
                    "max_tokens": data.get("max_tokens", 1000),
                    **kwargs
                }
            )
        elif "embed" in endpoint:
            response = self.client.query(
                route=route_name,
                data={
                    "input": data.get("input", ""),
                    **kwargs
                }
            )
        else:
            # Generic query
            response = self.client.query(route=route_name, data=data)
        
        return response
    
    def _query_http(self, endpoint: str, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """Fallback HTTP query when MLFlow Gateway unavailable."""
        
        # Construct URL
        url = f"{self.config.base_url}/gateway/{endpoint}"
        
        # Prepare headers
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "LLMData-Gateway/1.0"
        }
        
        # Add authentication if configured
        if hasattr(self.config, 'api_key') and self.config.api_key:
            headers["Authorization"] = f"Bearer {self.config.api_key}"
        
        # Make request with retries
        for attempt in range(self.config.max_retries):
            try:
                response = self.session.post(
                    url,
                    headers=headers,
                    json=data,
                    timeout=self.config.timeout
                )
                
                response.raise_for_status()
                return response.json()
                
            except requests.RequestException as e:
                if attempt < self.config.max_retries - 1:
                    time.sleep(2 ** attempt)  # Exponential backoff
                    continue
                raise e
    
    def _convert_endpoint_to_route(self, endpoint: str) -> str:
        """Convert endpoint name to MLFlow route name."""
        
        # Map common endpoints to MLFlow routes
        endpoint_mappings = {
            "claude-chat": "claude",
            "openai-chat": "openai",
            "ollama-chat": "ollama",
            "gemini-chat": "gemini",
            "claude-embeddings": "claude-embeddings",
            "openai-embeddings": "openai-embeddings"
        }
        
        return endpoint_mappings.get(endpoint, endpoint)
    
    def _handle_error(self, endpoint: str, data: Dict[str, Any], error: str, **kwargs) -> Dict[str, Any]:
        """Handle query errors with fallback strategies."""
        
        # Common error responses
        error_response = {
            "error": error,
            "endpoint": endpoint,
            "timestamp": datetime.now().isoformat(),
            "fallback": True
        }
        
        # Provider-specific fallbacks
        if "claude" in endpoint:
            error_response.update({
                "content": "I apologize, but I'm temporarily unavailable. Please try again.",
                "model": "claude-fallback"
            })
        elif "openai" in endpoint:
            error_response.update({
                "choices": [{
                    "message": {
                        "content": "Service temporarily unavailable. Please retry your request."
                    }
                }],
                "model": "gpt-fallback"
            })
        
        return error_response
    
    def _log_request(self, request_id: str, endpoint: str, data: Dict[str, Any]):
        """Log request details."""
        log_entry = {
            "request_id": request_id,
            "timestamp": datetime.now().isoformat(),
            "endpoint": endpoint,
            "data_size": len(json.dumps(data)),
            "has_messages": "messages" in data,
            "model": data.get("model", "unknown")
        }
        
        self.request_history.append(log_entry)
    
    def _log_response(self, request_id: str, response: Dict[str, Any], processing_time: float):
        """Log response details."""
        # Update request history with response info
        for entry in reversed(self.request_history):
            if entry.get("request_id") == request_id:
                entry.update({
                    "success": True,
                    "processing_time": processing_time,
                    "response_size": len(json.dumps(response)),
                    "usage": response.get("usage", {}),
                })
                break
    
    def _log_error(self, request_id: str, error: str, processing_time: float):
        """Log error details."""
        for entry in reversed(self.request_history):
            if entry.get("request_id") == request_id:
                entry.update({
                    "success": False,
                    "error": error,
                    "processing_time": processing_time
                })
                break
    
    def get_routes(self) -> List[Dict[str, Any]]:
        """Get available gateway routes."""
        if self.client:
            try:
                return self.client.search_routes()
            except Exception as e:
                print(f"⚠️ Could not fetch routes: {e}")
        
        # Fallback route list
        return [
            {"name": "claude", "route_type": "llm/v1/chat", "model": "claude-3-5-sonnet"},
            {"name": "openai", "route_type": "llm/v1/chat", "model": "gpt-4o"},
            {"name": "ollama", "route_type": "llm/v1/chat", "model": "llama3.1"},
        ]
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get gateway performance metrics."""
        
        if not self.request_history:
            return {"total_requests": 0}
        
        total_requests = len(self.request_history)
        successful_requests = sum(1 for req in self.request_history if req.get("success"))
        
        processing_times = [req.get("processing_time", 0) for req in self.request_history if req.get("processing_time")]
        avg_processing_time = sum(processing_times) / len(processing_times) if processing_times else 0
        
        # Usage statistics
        total_tokens = sum(
            req.get("usage", {}).get("total_tokens", 0) 
            for req in self.request_history
        )
        
        return {
            "total_requests": total_requests,
            "successful_requests": successful_requests,
            "success_rate": successful_requests / total_requests if total_requests else 0,
            "avg_processing_time": avg_processing_time,
            "total_tokens_used": total_tokens,
            "endpoints_used": list(set(req.get("endpoint") for req in self.request_history)),
            "rate_limit_enabled": self.rate_limiter is not None
        }
    
    def clear_history(self):
        """Clear request history."""
        self.request_history.clear()


class RateLimiter:
    """Simple rate limiter for API requests."""
    
    def __init__(self, requests_per_minute: int):
        self.requests_per_minute = requests_per_minute
        self.requests = []
    
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded."""
        now = time.time()
        
        # Remove old requests (older than 1 minute)
        self.requests = [req_time for req_time in self.requests if now - req_time < 60]
        
        # Check if we're at the limit
        if len(self.requests) >= self.requests_per_minute:
            # Wait until the oldest request is more than 1 minute old
            sleep_time = 60 - (now - self.requests[0])
            if sleep_time > 0:
                time.sleep(sleep_time)
        
        # Add current request
        self.requests.append(now)


# Global gateway instance
_default_gateway: Optional[MLFlowGateway] = None


def get_default_gateway() -> MLFlowGateway:
    """Get or create default gateway instance."""
    global _default_gateway
    
    if _default_gateway is None:
        _default_gateway = MLFlowGateway()
    
    return _default_gateway


def set_gateway_config(config: GatewayConfig):
    """Set configuration for default gateway."""
    global _default_gateway
    _default_gateway = MLFlowGateway(config)


def create_gateway(
    base_url: str = "http://localhost:5000",
    timeout: int = 30,
    max_retries: int = 3,
    enable_logging: bool = True,
    rate_limit: Optional[int] = None,
    **kwargs
) -> MLFlowGateway:
    """
    Create configured gateway instance.
    
    Args:
        base_url: Gateway base URL
        timeout: Request timeout in seconds
        max_retries: Maximum retry attempts
        enable_logging: Enable request/response logging
        rate_limit: Requests per minute limit
        **kwargs: Additional configuration
        
    Returns:
        Configured MLFlowGateway instance
    """
    
    config = GatewayConfig(
        base_url=base_url,
        timeout=timeout,
        max_retries=max_retries,
        enable_logging=enable_logging,
        rate_limit=rate_limit
    )
    
    # Add any additional config
    for key, value in kwargs.items():
        setattr(config, key, value)
    
    return MLFlowGateway(config)


# Package exports
__all__ = [
    'MLFlowGateway',
    'GatewayConfig', 
    'RateLimiter',
    'get_default_gateway',
    'set_gateway_config',
    'create_gateway'
]