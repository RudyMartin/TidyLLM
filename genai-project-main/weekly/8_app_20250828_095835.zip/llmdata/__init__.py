#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData - Python TidyLLM Ecosystem

A Python equivalent of tidyLLM with enhanced capabilities for enterprise LLM workflows.
Provides a verb-based interface for LLM operations with DataTable backend, MLFlow Gateway 
integration, and TidyMart numerical computing.

Features:
- TidyLLM-style verb interface: llm_message() | chat(provider())
- Enhanced file processing with Attachments grammar
- DataTable backend for high-performance data operations (not pandas!)
- MLFlow Gateway for centralized LLM management
- TidyMart integration - Enterprise NumPy alternative with graceful fallback
- MCP integration for standardized tool interfaces
- Enterprise governance and experiment tracking

TidyMart Integration:
    import llmdata
    
    # Automatic backend selection (TidyMart → numpy_compat fallback)
    data = [100, 200, 300, 400, 500]
    mean_val = llmdata.np.mean(data)  # Works with either backend
    
    # Check which backend is active
    if llmdata.TIDYMART_AVAILABLE:
        print("🎯 Using TidyMart enterprise features")
    else:
        print("🔧 Using built-in numerical functions")

Example Usage:
    # Basic chat (tidyLLM-style)
    response = (llm_message("Explain machine learning")
               | chat(claude(model="claude-3-5-sonnet")))
    
    # With file attachments (enhanced beyond tidyLLM)
    analysis = (llm_message("Analyze quarterly data", "sales.csv", "charts.pdf")
               | chat(claude()))
    
    # Data analysis workflow with numerical computing
    import llmdata.np as np
    data_summary = np.mean([1000, 1500, 2000])  # Uses TidyMart or fallback
    
    insights = (llm_message(f"Revenue average is ${data_summary}")
               | analyze_data("large_dataset.csv", claude())
               | chat(openai(model="gpt-4o")))

Architecture:
    llmdata/
    ├── __init__.py          # Main API and TidyMart integration
    ├── core.py              # LLMMessage, Provider classes
    ├── verbs.py             # chat(), embed(), analyze_data()
    ├── gateway.py           # MLFlow Gateway integration
    ├── numpy_compat.py      # NumPy fallback functions (TidyMart backend)
    ├── dt.py                # Enhanced DataTable with tidyverse syntax
    └── examples/            # Working demonstrations
"""

__version__ = "0.1.0"
__author__ = "LLMData Development Team"

# Core API (tidyLLM-style interface)
from .core import (
    LLMMessage,
    llm_message,
    Provider,
    claude,
    openai, 
    ollama
)

from .verbs import (
    chat,
    embed,
    send_batch,
    analyze_data
)

# Enhanced data operations
from . import dt

# TidyMart integration (NumPy alternative)
try:
    import tidymart as np
    TIDYMART_AVAILABLE = True
    print("🎯 Using TidyMart for numerical operations")
except ImportError:
    from . import numpy_compat as np
    TIDYMART_AVAILABLE = False

# Gateway integration
from .gateway import MLFlowGateway, get_default_gateway

# Optional MCP and Attachments integration (if available)
try:
    from .mcp.server import TidyLLMMCPServer
    MCP_AVAILABLE = True
except ImportError:
    TidyLLMMCPServer = None
    MCP_AVAILABLE = False

try:
    from .attachments_enhanced import attach, load, present, refine
    ATTACHMENTS_ENHANCED_AVAILABLE = True
except ImportError:
    attach = None
    load = None
    present = None 
    refine = None
    ATTACHMENTS_ENHANCED_AVAILABLE = False

# Multimodal capabilities
try:
    from .multimodal import (
        MultimodalMessage, multimodal_message, vision_chat, 
        multimodal_embed, batch_image_analysis, enhance_with_multimodal
    )
    MULTIMODAL_AVAILABLE = True
except ImportError:
    MultimodalMessage = None
    multimodal_message = None
    vision_chat = None
    multimodal_embed = None
    batch_image_analysis = None
    enhance_with_multimodal = None
    MULTIMODAL_AVAILABLE = False

__all__ = [
    # Core classes
    "LLMMessage",
    "llm_message", 
    "Provider",
    
    # Providers
    "claude",
    "openai",
    "ollama",
    
    # Verbs
    "chat",
    "embed", 
    "send_batch",
    "analyze_data",
    
    # Data modules
    "dt",
    "np",  # TidyMart or numpy_compat aliased as np
    
    # Infrastructure
    "MLFlowGateway",
    "get_default_gateway",
    "TIDYMART_AVAILABLE",
    "MCP_AVAILABLE",
    "ATTACHMENTS_ENHANCED_AVAILABLE",
    "MULTIMODAL_AVAILABLE",
]

# Add optional imports to __all__ if available
if MCP_AVAILABLE and TidyLLMMCPServer:
    __all__.append("TidyLLMMCPServer")

if ATTACHMENTS_ENHANCED_AVAILABLE and attach:
    __all__.extend(["attach", "load", "present", "refine"])

if MULTIMODAL_AVAILABLE and multimodal_message:
    __all__.extend([
        "MultimodalMessage", "multimodal_message", "vision_chat",
        "multimodal_embed", "batch_image_analysis", "enhance_with_multimodal"
    ])

# Package metadata
__package_info__ = {
    "name": "llmdata",
    "description": "Python TidyLLM ecosystem with enterprise capabilities",
    "keywords": ["llm", "ai", "datatable", "mlflow", "mcp", "tidyverse"],
    "license": "MIT",
    "python_requires": ">=3.8",
    "homepage": "https://github.com/llmdata/llmdata",
    "repository": "https://github.com/llmdata/llmdata.git",
    "documentation": "https://llmdata.readthedocs.io",
}

# Version compatibility
TIDYLLM_COMPAT_VERSION = "0.3.0"  # Compatible with tidyLLM R package
DATATABLE_MIN_VERSION = "1.0.0"   # Minimum datatable version
MLFLOW_MIN_VERSION = "2.0.0"      # Minimum MLFlow version