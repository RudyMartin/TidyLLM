#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Multimodal Processing

Enhanced multimodal capabilities for LLMData ecosystem including:
- Image attachment processing (PNG, JPG, JPEG)  
- Vision model embeddings
- Multimodal TidyLLM workflows
- Image + text analysis pipelines

Integrates with existing image processing infrastructure while providing
TidyLLM-style syntax for multimodal workflows.
"""

import logging
import base64
from typing import Dict, List, Any, Optional, Union
from pathlib import Path
import json
from datetime import datetime

# Core LLMData imports
from .core import LLMMessage, Provider, claude, openai
from .verbs import chat, embed

# Integration with existing image processing infrastructure
try:
    import sys
    from pathlib import Path
    
    # Add backend path for existing image processing worker
    backend_path = Path(__file__).parent.parent / 'src'
    if str(backend_path) not in sys.path:
        sys.path.insert(0, str(backend_path))
    
    from backend.mcp.workers.image_processing_worker import ImageProcessingWorker, ImageProcessingMode
    EXISTING_IMAGE_WORKER_AVAILABLE = True
except ImportError:
    EXISTING_IMAGE_WORKER_AVAILABLE = False

logger = logging.getLogger(__name__)

# Image processing availability
try:
    from PIL import Image
    import io
    PILLOW_AVAILABLE = True
except ImportError:
    PILLOW_AVAILABLE = False
    print("⚠️ Pillow not available - basic image processing only")

class MultimodalMessage(LLMMessage):
    """
    Enhanced LLMMessage with multimodal capabilities
    
    Supports images, documents, and mixed media attachments with
    automatic content type detection and processing.
    """
    
    def __init__(self, content: str, *attachments, **metadata):
        super().__init__(content, *attachments, **metadata)
        self.image_attachments = []
        self.text_attachments = []
        self._process_multimodal_attachments()
    
    def _process_multimodal_attachments(self):
        """Process and categorize attachments by type"""
        for attachment in self.attachments:
            if isinstance(attachment, str):
                path = Path(attachment)
                if path.suffix.lower() in ['.png', '.jpg', '.jpeg', '.gif', '.webp']:
                    self.image_attachments.append(attachment)
                else:
                    self.text_attachments.append(attachment)
            elif isinstance(attachment, dict) and attachment.get('type') == 'image':
                self.image_attachments.append(attachment)
            else:
                self.text_attachments.append(attachment)
        
        logger.debug(f"Processed {len(self.image_attachments)} images, {len(self.text_attachments)} text attachments")
    
    def get_image_data(self) -> List[Dict[str, Any]]:
        """Extract image data for multimodal models using existing infrastructure"""
        image_data = []
        
        # Use existing ImageProcessingWorker if available
        if EXISTING_IMAGE_WORKER_AVAILABLE:
            try:
                worker = ImageProcessingWorker(mode=ImageProcessingMode.ENHANCED)
                
                # Process through existing infrastructure
                for image_path in self.image_attachments:
                    if isinstance(image_path, str):
                        # Create MCP message format expected by worker
                        from backend.core.mcp_message import MCPMessage
                        mcp_msg = MCPMessage(
                            content=f"Process image: {image_path}",
                            attachments=[image_path],
                            metadata={"image_path": image_path}
                        )
                        
                        result = worker.process_task(mcp_msg)
                        
                        if result.get('success') and result.get('processing', {}).get('images'):
                            for img in result['processing']['images']:
                                image_data.append({
                                    'path': image_path,
                                    'data': img.get('data', ''),
                                    'mime_type': img.get('mime_type', 'image/jpeg'),
                                    'size': img.get('size', 0),
                                    'metadata': img.get('metadata', {}),
                                    'processing_method': result.get('processing_method', 'existing_worker')
                                })
                        
            except Exception as e:
                logger.warning(f"Existing image worker failed, falling back to basic processing: {e}")
                # Fall back to basic processing below
        
        # Fallback to basic processing if existing worker not available or failed
        
        for image_path in self.image_attachments:
            try:
                if isinstance(image_path, str):
                    # File path
                    path = Path(image_path)
                    if path.exists():
                        with open(path, 'rb') as f:
                            image_bytes = f.read()
                        
                        image_data.append({
                            'path': str(path),
                            'data': base64.b64encode(image_bytes).decode('utf-8'),
                            'mime_type': f'image/{path.suffix.lower()[1:]}',
                            'size': len(image_bytes)
                        })
                elif isinstance(image_path, dict):
                    # Already processed image data
                    image_data.append(image_path)
                    
            except Exception as e:
                logger.error(f"Failed to process image {image_path}: {e}")
        
        return image_data
    
    def analyze_images(self) -> Dict[str, Any]:
        """Analyze image properties and content"""
        if not PILLOW_AVAILABLE:
            return {"error": "Pillow not available for image analysis"}
        
        analysis = {
            "image_count": len(self.image_attachments),
            "images": []
        }
        
        for image_path in self.image_attachments:
            try:
                if isinstance(image_path, str) and Path(image_path).exists():
                    with Image.open(image_path) as img:
                        image_info = {
                            "path": image_path,
                            "format": img.format,
                            "mode": img.mode,
                            "size": img.size,
                            "width": img.width,
                            "height": img.height
                        }
                        
                        # Basic content analysis
                        if img.mode == 'RGB':
                            # Get dominant colors (simplified)
                            colors = img.getcolors(maxcolors=256)
                            if colors:
                                dominant_color = max(colors, key=lambda x: x[0])
                                image_info["dominant_color"] = dominant_color[1]
                        
                        analysis["images"].append(image_info)
                        
            except Exception as e:
                logger.error(f"Failed to analyze image {image_path}: {e}")
                analysis["images"].append({"path": image_path, "error": str(e)})
        
        return analysis

def multimodal_message(content: str, *attachments, **metadata) -> MultimodalMessage:
    """
    Create a multimodal message with automatic attachment processing
    
    Args:
        content: Text content
        *attachments: Files, images, documents
        **metadata: Additional metadata
        
    Returns:
        MultimodalMessage with processed attachments
        
    Example:
        msg = multimodal_message("Analyze this chart", "chart.png", "data.csv")
        response = msg | chat(claude(vision=True))
    """
    return MultimodalMessage(content, *attachments, **metadata)

def vision_chat(provider: Provider = None) -> callable:
    """
    Create a vision-enabled chat function for multimodal processing
    
    Args:
        provider: LLM provider with vision capabilities
        
    Returns:
        Chat function optimized for multimodal input
        
    Example:
        response = multimodal_message("What's in this image?", "photo.jpg") | vision_chat(claude())
    """
    if provider is None:
        provider = claude(model="claude-3-5-sonnet")  # Vision-capable model
    
    def _vision_chat(message: MultimodalMessage) -> Dict[str, Any]:
        """Process multimodal message with vision capabilities"""
        start_time = datetime.now()
        
        try:
            # Get processed image data using existing infrastructure
            image_data = message.get_image_data()
            
            # Create TidyLLM-compatible message with attachments
            from .core import llm_message
            
            # Combine text content with image descriptions
            enhanced_content = message.content
            if image_data:
                image_summaries = []
                for img in image_data:
                    summary = f"Image: {img.get('mime_type', 'unknown')} ({img.get('size', 0)} bytes)"
                    if img.get('metadata'):
                        meta = img['metadata']
                        if meta.get('width') and meta.get('height'):
                            summary += f" {meta['width']}x{meta['height']}"
                    image_summaries.append(summary)
                
                enhanced_content += "\n\nImages attached: " + "; ".join(image_summaries)
            
            # Use standard LLMData chat verb for actual processing
            llm_msg = llm_message(enhanced_content, *message.image_attachments)
            response = llm_msg | chat(provider)
            
            duration = (datetime.now() - start_time).total_seconds()
            
            result = {
                "success": True,
                "response": response.content,
                "content_parts": 1 + len(image_data),
                "images_processed": len(image_data),
                "text_attachments": len(message.text_attachments),
                "provider": provider.model,
                "processing_time": duration,
                "method": "vision_chat_with_existing_worker",
                "processing_infrastructure": "existing_image_worker" if EXISTING_IMAGE_WORKER_AVAILABLE else "basic"
            }
            
            return result
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"Vision chat failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "processing_time": duration
            }
    
    return _vision_chat

def multimodal_embed(provider: Provider = None) -> callable:
    """
    Create embeddings from multimodal content (text + images)
    
    Args:
        provider: Embedding provider with multimodal capabilities
        
    Returns:
        Embedding function for multimodal content
        
    Example:
        embeddings = multimodal_message("Product analysis", "product.jpg") | multimodal_embed(openai())
    """
    if provider is None:
        provider = openai(model="text-embedding-3-large")  # Multimodal embedding model
    
    def _multimodal_embed(message: MultimodalMessage) -> Dict[str, Any]:
        """Generate embeddings from multimodal content"""
        start_time = datetime.now()
        
        try:
            # Analyze images first
            image_analysis = message.analyze_images()
            
            # Combine text and image descriptions for embedding
            combined_text = message.content
            
            if image_analysis.get("images"):
                image_descriptions = []
                for img in image_analysis["images"]:
                    if "error" not in img:
                        desc = f"Image: {img['format']} {img['width']}x{img['height']}"
                        if "dominant_color" in img:
                            desc += f" (dominant color: {img['dominant_color']})"
                        image_descriptions.append(desc)
                
                if image_descriptions:
                    combined_text += " | Images: " + "; ".join(image_descriptions)
            
            # Generate embeddings (simulated - would use actual embedding API)
            duration = (datetime.now() - start_time).total_seconds()
            
            # Mock embedding vector (would be real embeddings)
            mock_embedding = [0.1] * 1536  # Standard embedding dimension
            
            result = {
                "success": True,
                "embedding": mock_embedding,
                "dimension": len(mock_embedding),
                "combined_text": combined_text,
                "image_count": len(message.image_attachments),
                "text_length": len(message.content),
                "provider": provider.model,
                "processing_time": duration,
                "method": "multimodal_embed"
            }
            
            return result
            
        except Exception as e:
            duration = (datetime.now() - start_time).total_seconds()
            logger.error(f"Multimodal embedding failed: {e}")
            return {
                "success": False,
                "error": str(e),
                "processing_time": duration
            }
    
    return _multimodal_embed

def batch_image_analysis(image_paths: List[str], query: str, 
                        provider: Provider = None) -> List[Dict[str, Any]]:
    """
    Batch process multiple images with the same query
    
    Args:
        image_paths: List of image file paths
        query: Analysis query for all images
        provider: Vision-capable LLM provider
        
    Returns:
        List of analysis results
        
    Example:
        results = batch_image_analysis(
            ["chart1.png", "chart2.png", "graph.jpg"],
            "Extract key metrics from these visualizations"
        )
    """
    if provider is None:
        provider = claude(model="claude-3-5-sonnet")
    
    results = []
    
    for i, image_path in enumerate(image_paths):
        try:
            # Create individual multimodal message
            msg = multimodal_message(f"{query} (Image {i+1})", image_path)
            
            # Process with vision chat
            result = msg | vision_chat(provider)
            result["image_index"] = i
            result["image_path"] = image_path
            
            results.append(result)
            
        except Exception as e:
            logger.error(f"Failed to process image {image_path}: {e}")
            results.append({
                "success": False,
                "error": str(e),
                "image_index": i,
                "image_path": image_path
            })
    
    return results

# Integration with existing image processing worker
def enhance_with_multimodal(orchestrator_class):
    """
    Decorator to enhance existing orchestrators with multimodal capabilities
    
    Args:
        orchestrator_class: Orchestrator class to enhance
        
    Returns:
        Enhanced orchestrator class with multimodal methods
    """
    
    def process_multimodal_query(self, query: str, attachments: List[str], 
                                provider: str = "claude") -> Dict[str, Any]:
        """Process query with mixed text/image attachments using existing infrastructure"""
        multimodal_msg = multimodal_message(query, *attachments)
        
        if provider == "claude":
            llm_provider = claude(model="claude-3-5-sonnet") 
        else:
            llm_provider = openai(model="gpt-4o")
        
        return multimodal_msg | vision_chat(llm_provider)
    
    def get_multimodal_embeddings(self, content: str, images: List[str]) -> Dict[str, Any]:
        """Get embeddings from text + image content using existing infrastructure"""
        multimodal_msg = multimodal_message(content, *images)
        return multimodal_msg | multimodal_embed()
    
    def process_images_with_existing_worker(self, image_paths: List[str], 
                                          mode: str = "enhanced") -> Dict[str, Any]:
        """Process images using existing ImageProcessingWorker infrastructure"""
        if not EXISTING_IMAGE_WORKER_AVAILABLE:
            return {"error": "Existing image processing worker not available"}
        
        try:
            mode_map = {
                "simple": ImageProcessingMode.SIMPLE,
                "enhanced": ImageProcessingMode.ENHANCED, 
                "advanced": ImageProcessingMode.ADVANCED
            }
            
            worker = ImageProcessingWorker(mode=mode_map.get(mode, ImageProcessingMode.ENHANCED))
            
            results = []
            for image_path in image_paths:
                from backend.core.mcp_message import MCPMessage
                mcp_msg = MCPMessage(
                    content=f"Process image: {image_path}",
                    attachments=[image_path],
                    metadata={"image_path": image_path}
                )
                
                result = worker.process_task(mcp_msg)
                results.append(result)
            
            return {
                "success": True,
                "results": results,
                "total_images": len(image_paths),
                "processing_mode": mode,
                "method": "existing_image_worker"
            }
            
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "method": "existing_image_worker"
            }
    
    # Add methods to orchestrator class
    orchestrator_class.process_multimodal_query = process_multimodal_query
    orchestrator_class.get_multimodal_embeddings = get_multimodal_embeddings
    orchestrator_class.process_images_with_existing_worker = process_images_with_existing_worker
    
    return orchestrator_class

__all__ = [
    'MultimodalMessage',
    'multimodal_message', 
    'vision_chat',
    'multimodal_embed',
    'batch_image_analysis',
    'enhance_with_multimodal',
    'PILLOW_AVAILABLE',
    'EXISTING_IMAGE_WORKER_AVAILABLE'
]

logger.info("🖼️ LLMData multimodal processing loaded")
if EXISTING_IMAGE_WORKER_AVAILABLE:
    logger.info("🔗 Integrated with existing ImageProcessingWorker infrastructure")
if PILLOW_AVAILABLE:
    logger.info("✅ Full image processing capabilities available")
else:
    logger.info("⚠️ Limited image processing - install Pillow for full features")