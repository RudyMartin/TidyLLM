#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData DataTable Integration - Enhanced DataTable with TidyVerse Syntax

Provides enhanced DataTable functionality with tidyverse-like syntax for
high-performance data operations in the LLMData ecosystem.
"""

from typing import Any, Dict, List, Optional, Union, Callable
import json
from datetime import datetime

# DataTable integration
DATATABLE_AVAILABLE = True
try:
    import datatable as _dt
    from datatable import f, by, join, sort, update
except ImportError:
    DATATABLE_AVAILABLE = False
    print("⚠️ datatable package not available - using fallback implementations")
    _dt = None


class DataTableFrame:
    """
    Enhanced DataTable Frame with tidyverse-like syntax.
    
    Wraps datatable.Frame with additional methods for LLMData ecosystem
    and provides fallback functionality when datatable is not available.
    """
    
    def __init__(self, data=None, **kwargs):
        if DATATABLE_AVAILABLE and _dt:
            if isinstance(data, _dt.Frame):
                self._frame = data
            else:
                self._frame = _dt.Frame(data, **kwargs)
        else:
            # Fallback implementation
            self._frame = self._create_fallback_frame(data)
        
        self._metadata = {
            'created_at': datetime.now().isoformat(),
            'operations': []
        }
    
    def _create_fallback_frame(self, data):
        """Create fallback frame structure when datatable unavailable."""
        if data is None:
            return {'columns': {}, 'nrows': 0, 'ncols': 0}
        
        if isinstance(data, dict):
            # Dictionary of columns
            nrows = len(next(iter(data.values()))) if data else 0
            return {
                'columns': data,
                'nrows': nrows,
                'ncols': len(data)
            }
        elif isinstance(data, list):
            if data and isinstance(data[0], dict):
                # List of rows
                columns = {}
                if data:
                    keys = data[0].keys()
                    for key in keys:
                        columns[key] = [row.get(key) for row in data]
                
                return {
                    'columns': columns,
                    'nrows': len(data),
                    'ncols': len(columns)
                }
            else:
                # Simple list
                return {
                    'columns': {'values': data},
                    'nrows': len(data),
                    'ncols': 1
                }
        else:
            return {'columns': {}, 'nrows': 0, 'ncols': 0}
    
    @property
    def nrows(self) -> int:
        """Number of rows."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'nrows'):
            return self._frame.nrows
        else:
            return self._frame.get('nrows', 0)
    
    @property 
    def ncols(self) -> int:
        """Number of columns."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'ncols'):
            return self._frame.ncols
        else:
            return self._frame.get('ncols', 0)
    
    @property
    def names(self) -> List[str]:
        """Column names."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'names'):
            return self._frame.names
        else:
            return list(self._frame.get('columns', {}).keys())
    
    def __getitem__(self, key):
        """Column/row selection with enhanced syntax."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, '__getitem__'):
            result = self._frame[key]
            if isinstance(result, _dt.Frame):
                wrapped = DataTableFrame(result)
                wrapped._metadata['operations'].append(f'select[{key}]')
                return wrapped
            return result
        else:
            # Fallback selection
            columns = self._frame.get('columns', {})
            if isinstance(key, str) and key in columns:
                return columns[key]
            elif isinstance(key, (list, tuple)):
                selected = {k: columns[k] for k in key if k in columns}
                return DataTableFrame(selected)
            else:
                return None
    
    def select(self, *columns) -> 'DataTableFrame':
        """Select specific columns (tidyverse-style)."""
        if DATATABLE_AVAILABLE:
            selected = self._frame[:, columns]
            result = DataTableFrame(selected)
        else:
            # Fallback select
            frame_columns = self._frame.get('columns', {})
            selected = {col: frame_columns[col] for col in columns if col in frame_columns}
            result = DataTableFrame(selected)
        
        result._metadata['operations'].append(f'select({", ".join(columns)})')
        return result
    
    def filter(self, condition) -> 'DataTableFrame':
        """Filter rows based on condition (tidyverse-style)."""
        if DATATABLE_AVAILABLE:
            try:
                filtered = self._frame[condition, :]
                result = DataTableFrame(filtered)
            except:
                result = self  # Fallback to original if condition fails
        else:
            # Simple fallback filtering
            result = self  # Would need more complex implementation
        
        result._metadata['operations'].append(f'filter({condition})')
        return result
    
    def mutate(self, **new_columns) -> 'DataTableFrame':
        """Add or modify columns (tidyverse-style)."""
        if DATATABLE_AVAILABLE:
            # Create copy and add new columns
            result_frame = self._frame.copy()
            for name, values in new_columns.items():
                result_frame[name] = values
            result = DataTableFrame(result_frame)
        else:
            # Fallback mutate
            new_frame_data = self._frame.get('columns', {}).copy()
            for name, values in new_columns.items():
                new_frame_data[name] = values if isinstance(values, list) else [values] * self.nrows
            result = DataTableFrame(new_frame_data)
        
        result._metadata['operations'].append(f'mutate({", ".join(new_columns.keys())})')
        return result
    
    def group_by(self, *columns) -> 'DataTableGroupedFrame':
        """Group by columns (tidyverse-style)."""
        return DataTableGroupedFrame(self, columns)
    
    def summarise(self, **aggregations) -> 'DataTableFrame':
        """Summarise data with aggregation functions."""
        if DATATABLE_AVAILABLE:
            # Use datatable aggregation
            try:
                # This would need proper datatable aggregation syntax
                result_data = {}
                for name, func in aggregations.items():
                    if callable(func):
                        # Apply function to each column
                        result_data[name] = [func(self._frame)]
                result = DataTableFrame(result_data)
            except:
                result = self
        else:
            # Simple fallback summarise
            result_data = {}
            columns = self._frame.get('columns', {})
            
            for name, expr in aggregations.items():
                if isinstance(expr, str) and expr.startswith('mean(') and expr.endswith(')'):
                    col_name = expr[5:-1]  # Extract column name from mean(col)
                    if col_name in columns:
                        values = columns[col_name]
                        result_data[name] = [sum(values) / len(values) if values else 0]
                elif isinstance(expr, str) and expr.startswith('sum(') and expr.endswith(')'):
                    col_name = expr[4:-1]
                    if col_name in columns:
                        result_data[name] = [sum(columns[col_name])]
                else:
                    result_data[name] = [0]  # Default fallback
            
            result = DataTableFrame(result_data)
        
        result._metadata['operations'].append(f'summarise({", ".join(aggregations.keys())})')
        return result
    
    def arrange(self, *columns, ascending: bool = True) -> 'DataTableFrame':
        """Sort by columns (tidyverse-style)."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'sort'):
            try:
                sorted_frame = self._frame.sort(*columns, reverse=not ascending)
                result = DataTableFrame(sorted_frame)
            except:
                result = self
        else:
            # Simple fallback sort (would need more implementation)
            result = self
        
        result._metadata['operations'].append(f'arrange({", ".join(str(c) for c in columns)})')
        return result
    
    def head(self, n: int = 6) -> 'DataTableFrame':
        """Get first n rows."""
        if DATATABLE_AVAILABLE:
            result = DataTableFrame(self._frame[:n, :])
        else:
            # Fallback head
            columns = self._frame.get('columns', {})
            head_data = {col: values[:n] for col, values in columns.items()}
            result = DataTableFrame(head_data)
        
        result._metadata['operations'].append(f'head({n})')
        return result
    
    def tail(self, n: int = 6) -> 'DataTableFrame':
        """Get last n rows."""
        if DATATABLE_AVAILABLE:
            result = DataTableFrame(self._frame[-n:, :])
        else:
            # Fallback tail
            columns = self._frame.get('columns', {})
            tail_data = {col: values[-n:] for col, values in columns.items()}
            result = DataTableFrame(tail_data)
        
        result._metadata['operations'].append(f'tail({n})')
        return result
    
    def to_list(self) -> List[Dict[str, Any]]:
        """Convert to list of dictionaries."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'to_list'):
            return self._frame.to_list()
        else:
            # Fallback conversion
            columns = self._frame.get('columns', {})
            if not columns:
                return []
            
            nrows = self.nrows
            result = []
            for i in range(nrows):
                row = {}
                for col_name, values in columns.items():
                    row[col_name] = values[i] if i < len(values) else None
                result.append(row)
            return result
    
    def to_dict(self) -> Dict[str, List]:
        """Convert to dictionary of lists."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'to_dict'):
            return self._frame.to_dict()
        else:
            return self._frame.get('columns', {})
    
    def to_pandas(self):
        """Convert to pandas DataFrame (if available)."""
        if DATATABLE_AVAILABLE and hasattr(self._frame, 'to_pandas'):
            try:
                return self._frame.to_pandas()
            except ImportError:
                print("⚠️ pandas not available")
                return None
        else:
            try:
                import pandas as pd
                return pd.DataFrame(self.to_dict())
            except ImportError:
                print("⚠️ pandas not available")
                return None
    
    def copy(self) -> 'DataTableFrame':
        """Create a copy of the frame."""
        if DATATABLE_AVAILABLE:
            return DataTableFrame(self._frame.copy())
        else:
            import copy
            return DataTableFrame(copy.deepcopy(self._frame))
    
    def glimpse(self) -> str:
        """Get a glimpse of the data (tibble-style)."""
        info = []
        info.append(f"Rows: {self.nrows:,}")
        info.append(f"Columns: {self.ncols}")
        
        if self.names:
            info.append("Columns:")
            for i, name in enumerate(self.names[:10]):  # Limit to first 10
                col_data = self[name]
                if isinstance(col_data, list):
                    sample_values = col_data[:3] if col_data else []
                    info.append(f"  {name} <{type(col_data[0]).__name__ if col_data else 'unknown'}>: {sample_values}")
        
        return "\n".join(info)
    
    def __repr__(self) -> str:
        """String representation."""
        return f"DataTableFrame({self.nrows:,} × {self.ncols})"
    
    def __str__(self) -> str:
        """Human-readable string."""
        return self.glimpse()


class DataTableGroupedFrame:
    """Grouped DataTable frame for group operations."""
    
    def __init__(self, frame: DataTableFrame, group_cols: tuple):
        self.frame = frame
        self.group_cols = group_cols
    
    def summarise(self, **aggregations) -> DataTableFrame:
        """Summarise grouped data."""
        # This would implement proper grouped aggregation
        # For now, return regular summarise
        result = self.frame.summarise(**aggregations)
        result._metadata['operations'].append(f'group_by({", ".join(self.group_cols)}) %>% summarise(...)')
        return result


# Convenience functions (tidyverse-style)

def fread(file_path: str, **kwargs) -> DataTableFrame:
    """
    Fast file reading (DataTable-style).
    
    Args:
        file_path: Path to file to read
        **kwargs: Additional parameters
        
    Returns:
        DataTableFrame with loaded data
    """
    if DATATABLE_AVAILABLE:
        frame = _dt.fread(file_path, **kwargs)
        result = DataTableFrame(frame)
    else:
        # Fallback CSV reading
        try:
            import csv
            with open(file_path, 'r') as f:
                reader = csv.DictReader(f)
                data = list(reader)
            result = DataTableFrame(data)
        except Exception as e:
            print(f"⚠️ Could not read file {file_path}: {e}")
            result = DataTableFrame()
    
    result._metadata['operations'].append(f'fread({file_path})')
    return result


def rbind(*frames) -> DataTableFrame:
    """
    Row-bind multiple frames.
    
    Args:
        *frames: DataTableFrame objects to combine
        
    Returns:
        Combined DataTableFrame
    """
    if DATATABLE_AVAILABLE and all(isinstance(f, DataTableFrame) for f in frames):
        dt_frames = [f._frame for f in frames if hasattr(f._frame, 'nrows')]
        if dt_frames:
            combined = _dt.rbind(*dt_frames)
            result = DataTableFrame(combined)
            result._metadata['operations'].append(f'rbind({len(frames)} frames)')
            return result
    
    # Fallback rbind
    all_data = []
    for frame in frames:
        if isinstance(frame, DataTableFrame):
            all_data.extend(frame.to_list())
    
    result = DataTableFrame(all_data)
    result._metadata['operations'].append(f'rbind({len(frames)} frames)')
    return result


def cbind(*frames) -> DataTableFrame:
    """
    Column-bind multiple frames.
    
    Args:
        *frames: DataTableFrame objects to combine
        
    Returns:
        Combined DataTableFrame
    """
    if DATATABLE_AVAILABLE and all(isinstance(f, DataTableFrame) for f in frames):
        # This would need proper datatable cbind implementation
        pass
    
    # Simple fallback cbind
    combined_data = {}
    for frame in frames:
        if isinstance(frame, DataTableFrame):
            frame_dict = frame.to_dict()
            combined_data.update(frame_dict)
    
    result = DataTableFrame(combined_data)
    result._metadata['operations'].append(f'cbind({len(frames)} frames)')
    return result


# Create main Frame class as alias
Frame = DataTableFrame

# Export key functions and classes
__all__ = [
    'DataTableFrame',
    'DataTableGroupedFrame',
    'Frame',
    'fread',
    'rbind', 
    'cbind',
    'DATATABLE_AVAILABLE'
]

# Add datatable functions if available
if DATATABLE_AVAILABLE:
    __all__.extend(['f', 'by', 'join', 'sort', 'update'])