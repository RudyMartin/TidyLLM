#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData NumPy Compatibility Layer

Provides NumPy-compatible functions using DataTable backend for high-performance
data operations without the heavy NumPy dependency. This is the evolution of
the former datamart_numpy_substitution.py - now part of the LLMData ecosystem.

Key Features:
- NumPy API compatibility
- DataTable backend for performance 
- No circular dependencies (standalone service)
- Enterprise-scale data processing
- Memory-efficient operations

This resolves the circular dependency that existed in:
datamart_numpy_substitution.py ↔ advanced_qa_orchestrator.py

Now DataMart is a service, and this is a clean compatibility layer.
"""

from typing import Union, List, Tuple, Any, Optional, Dict
import random as _random
import math
from datetime import datetime
import json

# Enhanced DataTable integration for LLMData ecosystem
DATATABLE_AVAILABLE = True
try:
    import datatable as dt
except ImportError:
    DATATABLE_AVAILABLE = False
    print("⚠️ datatable not available, using fallback implementations")

# DataMart service integration (optional - for enterprise deployments)
DATAMART_SERVICE_AVAILABLE = False
try:
    # This would integrate with existing DataMart service if available
    # For now, we use standalone implementations
    pass
except ImportError:
    pass


class LLMDataArray:
    """
    NumPy ndarray-compatible class using DataTable backend.
    
    Provides the NumPy interface while using DataTable for performance.
    This is the core data structure for the LLMData ecosystem.
    """
    
    def __init__(self, data: Union[List, Tuple, Any], dtype=None):
        self.data = self._convert_to_datatable(data)
        self.dtype = dtype
        self.shape = self._calculate_shape()
    
    def _convert_to_datatable(self, data):
        """Convert input data to DataTable Frame."""
        if DATATABLE_AVAILABLE:
            if isinstance(data, (list, tuple)):
                if len(data) > 0 and isinstance(data[0], (list, tuple)):
                    # 2D data
                    return dt.Frame(data)
                else:
                    # 1D data
                    return dt.Frame({"values": data})
            else:
                return dt.Frame({"values": [data]})
        else:
            # Fallback to list
            return data if isinstance(data, list) else [data]
    
    def _calculate_shape(self):
        """Calculate array shape."""
        if DATATABLE_AVAILABLE and hasattr(self.data, 'nrows'):
            return (self.data.nrows, self.data.ncols)
        elif isinstance(self.data, list):
            if len(self.data) > 0 and isinstance(self.data[0], list):
                return (len(self.data), len(self.data[0]))
            else:
                return (len(self.data),)
        else:
            return (1,)
    
    def __getitem__(self, key):
        """Array indexing."""
        if DATATABLE_AVAILABLE and hasattr(self.data, 'to_list'):
            data_list = self.data.to_list()
        else:
            data_list = self.data
        
        return data_list[key] if isinstance(data_list, list) else data_list
    
    def __len__(self):
        """Array length."""
        return self.shape[0]
    
    def tolist(self):
        """Convert to Python list."""
        if DATATABLE_AVAILABLE and hasattr(self.data, 'to_list'):
            return self.data.to_list()
        else:
            return self.data
    
    def __repr__(self):
        """String representation."""
        return f"LLMDataArray(shape={self.shape}, dtype={self.dtype})"


class LLMDataNumPy:
    """
    NumPy compatibility layer for LLMData ecosystem.
    
    Provides NumPy-compatible functions using DataTable backend and optional
    DataMart service integration for analytics.
    """
    
    def __init__(self, use_datamart_service: bool = True):
        self.use_datamart_service = use_datamart_service and DATAMART_SERVICE_AVAILABLE
        self.datamart = None
        
        if self.use_datamart_service:
            try:
                self.datamart = get_datamart_service(DataMartMode.ENHANCED)
            except Exception as e:
                print(f"⚠️ Could not connect to DataMart service: {e}")
                self.datamart = None
    
    # Array creation functions
    
    def array(self, data: Union[List, Tuple, Any], dtype=None, **kwargs) -> LLMDataArray:
        """Create array (NumPy-compatible)."""
        try:
            arr = LLMDataArray(data, dtype=dtype)
            
            # Log to DataMart service if available
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'array_creation',
                    'data_type': 'array_creation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'array', 'shape': arr.shape, 'dtype': str(dtype)}
                })
            
            return arr
        except Exception as e:
            print(f"Error creating array: {e}")
            return LLMDataArray([])
    
    def zeros(self, shape: Union[int, Tuple], dtype=None, **kwargs) -> LLMDataArray:
        """Create array filled with zeros."""
        try:
            if isinstance(shape, int):
                data = [0] * shape
            else:
                # Multi-dimensional
                total_size = math.prod(shape) if hasattr(math, 'prod') else self._prod(shape)
                data = [0] * total_size
            
            arr = LLMDataArray(data, dtype=dtype)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'array_creation',
                    'data_type': 'zeros_creation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'zeros', 'shape': shape, 'dtype': str(dtype)}
                })
            
            return arr
        except Exception as e:
            print(f"Error creating zeros array: {e}")
            return LLMDataArray([])
    
    def ones(self, shape: Union[int, Tuple], dtype=None, **kwargs) -> LLMDataArray:
        """Create array filled with ones."""
        try:
            if isinstance(shape, int):
                data = [1] * shape
            else:
                total_size = math.prod(shape) if hasattr(math, 'prod') else self._prod(shape)
                data = [1] * total_size
            
            arr = LLMDataArray(data, dtype=dtype)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'array_creation',
                    'data_type': 'ones_creation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'ones', 'shape': shape}
                })
            
            return arr
        except Exception as e:
            print(f"Error creating ones array: {e}")
            return LLMDataArray([])
    
    def _prod(self, iterable):
        """Product of iterable (for older Python versions)."""
        result = 1
        for x in iterable:
            result *= x
        return result
    
    # Statistical functions
    
    def mean(self, data: Union[List, LLMDataArray], axis=None, **kwargs) -> float:
        """Calculate mean."""
        try:
            values = self._extract_values(data)
            if not values:
                return 0.0
            
            result = __builtins__['sum'](values) / len(values)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'statistical',
                    'data_type': 'mean_calculation',
                    'confidence_score': 1.0,
                    'processing_time': 0.002,
                    'success': True,
                    'metadata': {'operation': 'mean', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating mean: {e}")
            return 0.0
    
    def std(self, data: Union[List, LLMDataArray], axis=None, **kwargs) -> float:
        """Calculate standard deviation."""
        try:
            values = self._extract_values(data)
            if not values or len(values) < 2:
                return 0.0
            
            mean_val = self.mean(values)
            variance = __builtins__['sum']((x - mean_val) ** 2 for x in values) / (len(values) - 1)
            result = math.sqrt(variance)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'statistical',
                    'data_type': 'std_calculation', 
                    'confidence_score': 1.0,
                    'processing_time': 0.003,
                    'success': True,
                    'metadata': {'operation': 'std', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating std: {e}")
            return 0.0
    
    def sum(self, data: Union[List, LLMDataArray], axis=None, **kwargs) -> float:
        """Calculate sum."""
        try:
            values = self._extract_values(data)
            result = __builtins__['sum'](values) if values else 0.0
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'statistical',
                    'data_type': 'sum_calculation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'sum', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating sum: {e}")
            return 0.0
    
    def min(self, data: Union[List, LLMDataArray], axis=None, **kwargs) -> float:
        """Calculate minimum."""
        try:
            values = self._extract_values(data)
            result = __builtins__['min'](values) if values else 0.0
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'statistical',
                    'data_type': 'min_calculation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'min', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating min: {e}")
            return 0.0
    
    def max(self, data: Union[List, LLMDataArray], axis=None, **kwargs) -> float:
        """Calculate maximum."""
        try:
            values = self._extract_values(data)
            result = __builtins__['max'](values) if values else 0.0
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'statistical',
                    'data_type': 'max_calculation',
                    'confidence_score': 1.0,
                    'processing_time': 0.001,
                    'success': True,
                    'metadata': {'operation': 'max', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating max: {e}")
            return 0.0
    
    # Random number generation
    
    def random_normal(self, loc: float = 0.0, scale: float = 1.0, 
                     size: Union[int, Tuple, None] = None, **kwargs) -> Union[float, LLMDataArray]:
        """Generate random numbers from normal distribution."""
        try:
            if size is None:
                return _random.gauss(loc, scale)
            elif isinstance(size, int):
                values = [_random.gauss(loc, scale) for _ in range(size)]
            else:
                total_size = math.prod(size) if hasattr(math, 'prod') else self._prod(size)
                values = [_random.gauss(loc, scale) for _ in range(total_size)]
            
            result = LLMDataArray(values)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'random_generation',
                    'data_type': 'normal_distribution',
                    'confidence_score': 1.0,
                    'processing_time': 0.002,
                    'success': True,
                    'metadata': {'operation': 'random_normal', 'size': size, 'loc': loc, 'scale': scale}
                })
            
            return result
        except Exception as e:
            print(f"Error generating random normal: {e}")
            return 0.0 if size is None else LLMDataArray([])
    
    def random_rand(self, *args, **kwargs) -> Union[float, LLMDataArray]:
        """Generate random numbers from uniform distribution."""
        try:
            if not args:
                return _random.random()
            elif len(args) == 1:
                values = [_random.random() for _ in range(args[0])]
            else:
                total_size = math.prod(args) if hasattr(math, 'prod') else self._prod(args)
                values = [_random.random() for _ in range(total_size)]
            
            result = LLMDataArray(values)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'random_generation',
                    'data_type': 'uniform_distribution',
                    'confidence_score': 1.0,
                    'processing_time': 0.002,
                    'success': True,
                    'metadata': {'operation': 'random_rand', 'shape': args}
                })
            
            return result
        except Exception as e:
            print(f"Error generating random values: {e}")
            return 0.0 if not args else LLMDataArray([])
    
    # Utility functions
    
    def _extract_values(self, data) -> List:
        """Extract values from various data types."""
        if isinstance(data, LLMDataArray):
            return data.tolist()
        elif isinstance(data, list):
            return data
        elif DATATABLE_AVAILABLE and hasattr(data, 'to_list'):
            return data.to_list()
        else:
            return [data] if not isinstance(data, (list, tuple)) else list(data)
    
    # Linear algebra (basic)
    
    def linalg_norm(self, data: Union[List, LLMDataArray], ord=None, **kwargs) -> float:
        """Calculate vector/matrix norm."""
        try:
            values = self._extract_values(data)
            if not values:
                return 0.0
            
            # L2 norm by default
            squared_sum = sum(x * x for x in values)
            result = math.sqrt(squared_sum)
            
            if self.datamart:
                self.datamart.add_analysis_data({
                    'worker_name': 'numpy_compat',
                    'worker_type': 'linear_algebra',
                    'data_type': 'norm_calculation',
                    'confidence_score': 1.0,
                    'processing_time': 0.002,
                    'success': True,
                    'metadata': {'operation': 'linalg_norm', 'input_size': len(values), 'result': result}
                })
            
            return result
        except Exception as e:
            print(f"Error calculating norm: {e}")
            return 0.0
    
    # DataMart integration
    
    def get_datamart_metrics(self) -> Dict[str, Any]:
        """Get DataMart performance metrics."""
        if self.datamart:
            return self.datamart.get_performance_metrics()
        else:
            return {'error': 'DataMart service not available'}
    
    def add_to_datamart(self, data: List, metadata: dict = None) -> bool:
        """Add data to DataMart for analytics."""
        if self.datamart:
            datamart_data = {
                'worker_name': 'numpy_compat',
                'worker_type': 'user_data',
                'data_type': 'user_array',
                'confidence_score': 1.0,
                'processing_time': 0.001,
                'success': True,
                'metadata': json.dumps(metadata or {})
            }
            return self.datamart.add_analysis_data(datamart_data)
        else:
            print("⚠️ DataMart service not available")
            return False


# Create global NumPy-compatible interface
_llmdata_numpy = LLMDataNumPy()

# Export NumPy-compatible functions
array = _llmdata_numpy.array
zeros = _llmdata_numpy.zeros
ones = _llmdata_numpy.ones
mean = _llmdata_numpy.mean
std = _llmdata_numpy.std
sum = _llmdata_numpy.sum
min = _llmdata_numpy.min
max = _llmdata_numpy.max
random_normal = _llmdata_numpy.random_normal
random_rand = _llmdata_numpy.random_rand
linalg_norm = _llmdata_numpy.linalg_norm

# Random module compatibility
class random:
    """NumPy random module compatibility."""
    normal = staticmethod(_llmdata_numpy.random_normal)
    rand = staticmethod(_llmdata_numpy.random_rand)
    randn = staticmethod(lambda *args: _llmdata_numpy.random_normal(0, 1, args[0] if args else None))

# Linear algebra module compatibility
class linalg:
    """NumPy linalg module compatibility.""" 
    norm = staticmethod(_llmdata_numpy.linalg_norm)

# Datetime compatibility
def datetime64(value: str) -> str:
    """NumPy datetime64 compatibility."""
    if value == 'now':
        return datetime.now().isoformat()
    else:
        return value

# Additional aliases for complete NumPy compatibility
ndarray = LLMDataArray
asarray = array
arange = lambda start, stop=None, step=1: array(list(range(start, stop or start, step)))

# Package info
__all__ = [
    # Core classes
    'LLMDataArray',
    'LLMDataNumPy',
    
    # Array creation
    'array', 'zeros', 'ones', 'asarray', 'arange',
    
    # Statistical functions
    'mean', 'std', 'sum', 'min', 'max',
    
    # Random generation
    'random_normal', 'random_rand',
    
    # Linear algebra
    'linalg_norm',
    
    # Modules
    'random', 'linalg',
    
    # Compatibility
    'datetime64', 'ndarray',
]