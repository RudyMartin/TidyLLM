#!/usr/bin/env python3
"""
Advanced Demo Launcher - LLMData Enhanced

Quick launcher for the advanced multi-tab interface with LLMData/TidyMart support.
"""

import subprocess
import sys
from pathlib import Path

def check_llmdata():
    """Check LLMData availability"""
    try:
        import llmdata
        print(f"✅ LLMData v{llmdata.__version__} available")
        print(f"🧮 TidyMart: {llmdata.TIDYMART_AVAILABLE}")
        return True
    except ImportError:
        print("⚠️ LLMData not available - install with: pip install -e .")
        print("🔧 Using legacy implementations")
        return False

def main():
    """Launch the advanced demo"""
    print("🎯 VectorQA Sage - Advanced Demo (LLMData Enhanced)")
    print("=" * 60)
    
    # Check LLMData status
    check_llmdata()
    app_file = Path(__file__).parent / "advanced.py"
    
    if not app_file.exists():
        print(f"❌ App file not found: {app_file}")
        return
    
    print("🚀 Starting Advanced Demo...")
    print(f"📁 App: {app_file}")
    print("🌐 URL: http://localhost:8501")
    print("⏹️  Press Ctrl+C to stop")
    print("-" * 50)
    
    # Launch with streamlit
    subprocess.run([
        sys.executable, "-m", "streamlit", "run", str(app_file),
        "--server.port", "8501",
        "--server.address", "0.0.0.0"
    ])

if __name__ == "__main__":
    main()
