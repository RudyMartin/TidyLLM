# 8 App

## Description
Core application code, dependencies, and runtime

## Deployment Instructions
1. Extract this archive to the target environment
2. Follow the main DEPLOYMENT_MANIFEST instructions
3. Ensure proper file permissions are set

## Contents
This archive contains files matching these patterns:
- src/**/*.py
- llmdata/**/*
- scripts/**/*
- start_*.py
- streamlit_*.py
- test_*.py
- **/__init__.py
- **/requirements.txt
- Dockerfile*
- docker-compose*.yml
- .dockerignore

## Generated
Created: 2025-08-28T10:04:50.460303
System: Full Site Archiver for Air-Gapped Deployment
