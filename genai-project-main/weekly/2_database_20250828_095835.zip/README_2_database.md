# 2 Database

## Description
Database schemas, migrations, and data files

## Deployment Instructions
1. Extract this archive to the target environment
2. Follow the main DEPLOYMENT_MANIFEST instructions
3. Ensure proper file permissions are set

## Contents
This archive contains files matching these patterns:
- database/**/*
- **/*.db
- **/*.sqlite
- **/*.sql
- **/migrations/**/*
- **/schemas/**/*
- sparse/**/*
- vectorqa_sage/**/*

## Generated
Created: 2025-08-28T09:58:41.481419
System: Full Site Archiver for Air-Gapped Deployment
