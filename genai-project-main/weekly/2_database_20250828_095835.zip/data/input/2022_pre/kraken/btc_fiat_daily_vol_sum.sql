select time, sum(volume) as jan2020 from btc_fiat_daily_mkt_jan2020 group by 1, order by 1 where pair in ('XXBTZUSD','XXBTZEUR','XXBTZGBP')
