"""
Data Schemas Package

Data schemas, models, and validation components.
"""

__version__ = "1.0.0"
