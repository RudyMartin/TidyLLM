#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DataMart Package - Standalone DataMart Management System

Provides clean, dependency-free data processing capabilities.
"""

from .core_manager import DataMartManager, DataMartMode

__all__ = ['DataMartManager', 'DataMartMode']
