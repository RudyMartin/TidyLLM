#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
VectorQA Sage - Model Risk Management (MRM) System

A comprehensive Model Risk Management system with progressive complexity architecture
for Credit Risk Assessment Model v2.1 and beyond.

Key Features:
- Progressive Complexity Architecture (Simple → Enhanced → Advanced)
- MCP (Message Control Protocol) hierarchy
- Automated Health Awareness (AHA) system
- DataMart with high-performance data processing
- Bottom-up execution strategy with safeguards
- Comprehensive testing and monitoring

Version: 2.1.0
"""

__version__ = "2.1.0"
__author__ = "VectorQA Team"
__email__ = "team@vectorqa.com"

# Core imports - only import what we know works
try:
    from .datamart import DataMartManager, DataMartMode
except ImportError:
    # Fallback if datamart module not available
    DataMartManager = None
    DataMartMode = None

try:
    from .health.reorg_department import ReorgDepartment, HealthStatus
except ImportError:
    # Fallback if health module not available
    ReorgDepartment = None
    HealthStatus = None

# MCP Components - import with fallbacks
try:
    from .mcp.orchestrators.simple_qa_orchestrator import SimpleQAOrchestrator
except ImportError:
    SimpleQAOrchestrator = None

try:
    from .mcp.orchestrators.enhanced_qa_orchestrator import EnhancedQAOrchestrator
except ImportError:
    EnhancedQAOrchestrator = None

try:
    from .mcp.orchestrators.advanced_qa_orchestrator import AdvancedQAOrchestrator
except ImportError:
    AdvancedQAOrchestrator = None

# Utilities - import with fallbacks
try:
    from .utils.config_manager import ConfigManager
except ImportError:
    ConfigManager = None

try:
    from .utils.logging_setup import setup_logging
except ImportError:
    setup_logging = None

# CLI and Demo - import with fallbacks
try:
    from .cli.main import main as cli_main
except ImportError:
    cli_main = None

try:
    from .demo.runner import main as demo_main
except ImportError:
    demo_main = None

__all__ = [
    # Core
    "DataMartManager",
    "DataMartMode",
    "ReorgDepartment", 
    "HealthStatus",
    
    # MCP Orchestrators
    "SimpleQAOrchestrator",
    "EnhancedQAOrchestrator", 
    "AdvancedQAOrchestrator",
    
    # Utilities
    "ConfigManager",
    "setup_logging",
    
    # Entry points
    "cli_main",
    "demo_main",
    
    # Version info
    "__version__",
    "__author__",
    "__email__",
]

# Package metadata
PACKAGE_INFO = {
    "name": "VectorQA Sage",
    "version": __version__,
    "description": "Model Risk Management (MRM) System with Progressive Complexity Architecture",
    "architecture": {
        "layers": [
            "Layer 1: Core Foundation (DataMart, Config)",
            "Layer 2: MCP Services (Workers, Coordinators)", 
            "Layer 3: MCP Planning (Planners)",
            "Layer 4: MCP Orchestration (Orchestrators)",
            "Layer 5: Health & Monitoring (AHA System)"
        ],
        "modes": [
            "Simple QA: Basic functionality",
            "Enhanced QA: Analytics and performance tracking",
            "Advanced QA: AI/ML capabilities and intelligent insights"
        ]
    },
    "safeguards": [
        "Bottom-up execution strategy",
        "N=5 loop prevention",
        "Time-based loop prevention", 
        "Memory-based loop prevention",
        "Dependency cycle detection",
        "Layer isolation testing",
        "Progressive complexity validation",
        "Rollback point management",
        "Health check integration",
        "Resource exhaustion prevention"
    ]
}
