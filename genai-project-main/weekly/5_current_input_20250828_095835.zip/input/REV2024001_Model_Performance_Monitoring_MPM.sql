-- Model Performance Monitoring (MPM) Plan
-- Review ID: REV2024001
-- Document Type: Model Performance Monitoring Plan
-- Created: 2024-01-27
-- Author: David Kim

-- =====================================================
-- CREDIT RISK ASSESSMENT MODEL v2.1
-- PERFORMANCE MONITORING FRAMEWORK
-- =====================================================

-- 1. MONITORING DATABASE SCHEMA
-- =====================================================

-- Model metadata table
CREATE TABLE model_metadata (
    model_id VARCHAR(50) PRIMARY KEY,
    model_name VARCHAR(100) NOT NULL,
    model_version VARCHAR(20) NOT NULL,
    deployment_date TIMESTAMP NOT NULL,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'ACTIVE',
    business_unit VARCHAR(50) NOT NULL,
    model_owner VARCHAR(100) NOT NULL
);

-- Model performance metrics table
CREATE TABLE model_performance_metrics (
    metric_id SERIAL PRIMARY KEY,
    model_id VARCHAR(50) REFERENCES model_metadata(model_id),
    metric_date DATE NOT NULL,
    metric_hour INTEGER DEFAULT 0,
    metric_name VARCHAR(50) NOT NULL,
    metric_value DECIMAL(10,4) NOT NULL,
    metric_threshold DECIMAL(10,4),
    threshold_breached BOOLEAN DEFAULT FALSE,
    created_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Model predictions table
CREATE TABLE model_predictions (
    prediction_id SERIAL PRIMARY KEY,
    model_id VARCHAR(50) REFERENCES model_metadata(model_id),
    prediction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    input_features JSONB NOT NULL,
    prediction_value DECIMAL(10,4) NOT NULL,
    prediction_probability DECIMAL(10,4) NOT NULL,
    actual_outcome DECIMAL(10,4),
    outcome_available BOOLEAN DEFAULT FALSE,
    processing_time_ms INTEGER,
    error_message TEXT
);

-- Model drift metrics table
CREATE TABLE model_drift_metrics (
    drift_id SERIAL PRIMARY KEY,
    model_id VARCHAR(50) REFERENCES model_metadata(model_id),
    drift_date DATE NOT NULL,
    feature_name VARCHAR(100) NOT NULL,
    population_stability_index DECIMAL(10,4),
    characteristic_stability_index DECIMAL(10,4),
    data_drift_score DECIMAL(10,4),
    drift_threshold DECIMAL(10,4) DEFAULT 0.25,
    drift_detected BOOLEAN DEFAULT FALSE,
    created_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Alert configuration table
CREATE TABLE alert_configuration (
    alert_id SERIAL PRIMARY KEY,
    model_id VARCHAR(50) REFERENCES model_metadata(model_id),
    alert_name VARCHAR(100) NOT NULL,
    alert_type VARCHAR(50) NOT NULL, -- 'PERFORMANCE', 'DRIFT', 'ERROR', 'SYSTEM'
    metric_name VARCHAR(50),
    threshold_value DECIMAL(10,4),
    threshold_operator VARCHAR(10), -- '>', '<', '>=', '<=', '='
    alert_severity VARCHAR(20) DEFAULT 'WARNING', -- 'INFO', 'WARNING', 'CRITICAL'
    notification_channels TEXT[], -- Array of notification methods
    is_active BOOLEAN DEFAULT TRUE,
    created_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Alert history table
CREATE TABLE alert_history (
    alert_history_id SERIAL PRIMARY KEY,
    alert_id INTEGER REFERENCES alert_configuration(alert_id),
    model_id VARCHAR(50) REFERENCES model_metadata(model_id),
    alert_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    alert_value DECIMAL(10,4),
    alert_message TEXT,
    notification_sent BOOLEAN DEFAULT FALSE,
    notification_timestamp TIMESTAMP,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_timestamp TIMESTAMP,
    resolved_by VARCHAR(100),
    resolution_notes TEXT
);

-- =====================================================
-- 2. MONITORING QUERIES AND VIEWS
-- =====================================================

-- Daily performance summary view
CREATE VIEW daily_performance_summary AS
SELECT 
    m.model_name,
    m.model_version,
    DATE(pm.metric_date) as performance_date,
    AVG(CASE WHEN pm.metric_name = 'accuracy' THEN pm.metric_value END) as avg_accuracy,
    AVG(CASE WHEN pm.metric_name = 'precision' THEN pm.metric_value END) as avg_precision,
    AVG(CASE WHEN pm.metric_name = 'recall' THEN pm.metric_value END) as avg_recall,
    AVG(CASE WHEN pm.metric_name = 'f1_score' THEN pm.metric_value END) as avg_f1_score,
    AVG(CASE WHEN pm.metric_name = 'auc_roc' THEN pm.metric_value END) as avg_auc_roc,
    AVG(CASE WHEN pm.metric_name = 'response_time_ms' THEN pm.metric_value END) as avg_response_time,
    COUNT(CASE WHEN pm.threshold_breached = TRUE THEN 1 END) as threshold_breaches,
    COUNT(*) as total_metrics
FROM model_metadata m
JOIN model_performance_metrics pm ON m.model_id = pm.model_id
WHERE pm.metric_date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY m.model_name, m.model_version, DATE(pm.metric_date)
ORDER BY performance_date DESC;

-- Model drift summary view
CREATE VIEW model_drift_summary AS
SELECT 
    m.model_name,
    m.model_version,
    dm.drift_date,
    dm.feature_name,
    dm.population_stability_index,
    dm.characteristic_stability_index,
    dm.data_drift_score,
    dm.drift_threshold,
    dm.drift_detected,
    CASE 
        WHEN dm.population_stability_index > dm.drift_threshold THEN 'HIGH_DRIFT'
        WHEN dm.population_stability_index > dm.drift_threshold * 0.8 THEN 'MEDIUM_DRIFT'
        ELSE 'LOW_DRIFT'
    END as drift_severity
FROM model_metadata m
JOIN model_drift_metrics dm ON m.model_id = dm.model_id
WHERE dm.drift_date >= CURRENT_DATE - INTERVAL '90 days'
ORDER BY dm.drift_date DESC, dm.drift_detected DESC;

-- Alert summary view
CREATE VIEW alert_summary AS
SELECT 
    m.model_name,
    m.model_version,
    ac.alert_name,
    ac.alert_type,
    ac.alert_severity,
    COUNT(ah.alert_history_id) as alert_count,
    MAX(ah.alert_timestamp) as last_alert_time,
    AVG(CASE WHEN ah.resolved = TRUE THEN 1 ELSE 0 END) as resolution_rate
FROM model_metadata m
JOIN alert_configuration ac ON m.model_id = ac.model_id
LEFT JOIN alert_history ah ON ac.alert_id = ah.alert_id
WHERE ah.alert_timestamp >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY m.model_name, m.model_version, ac.alert_name, ac.alert_type, ac.alert_severity
ORDER BY alert_count DESC;

-- =====================================================
-- 3. MONITORING STORED PROCEDURES
-- =====================================================

-- Procedure to calculate daily performance metrics
CREATE OR REPLACE FUNCTION calculate_daily_performance_metrics(
    p_model_id VARCHAR(50),
    p_metric_date DATE
) RETURNS VOID AS $$
BEGIN
    -- Calculate accuracy from predictions vs actual outcomes
    INSERT INTO model_performance_metrics (model_id, metric_date, metric_name, metric_value, metric_threshold, threshold_breached)
    SELECT 
        p_model_id,
        p_metric_date,
        'accuracy',
        AVG(CASE WHEN ABS(prediction_value - actual_outcome) < 0.1 THEN 1.0 ELSE 0.0 END),
        0.85,
        AVG(CASE WHEN ABS(prediction_value - actual_outcome) < 0.1 THEN 1.0 ELSE 0.0 END) < 0.85
    FROM model_predictions
    WHERE model_id = p_model_id 
    AND DATE(prediction_timestamp) = p_metric_date
    AND outcome_available = TRUE;
    
    -- Calculate average response time
    INSERT INTO model_performance_metrics (model_id, metric_date, metric_name, metric_value, metric_threshold, threshold_breached)
    SELECT 
        p_model_id,
        p_metric_date,
        'response_time_ms',
        AVG(processing_time_ms),
        3000,
        AVG(processing_time_ms) > 3000
    FROM model_predictions
    WHERE model_id = p_model_id 
    AND DATE(prediction_timestamp) = p_metric_date;
    
    -- Calculate prediction volume
    INSERT INTO model_performance_metrics (model_id, metric_date, metric_name, metric_value, metric_threshold, threshold_breached)
    SELECT 
        p_model_id,
        p_metric_date,
        'prediction_volume',
        COUNT(*),
        1000,
        COUNT(*) < 1000
    FROM model_predictions
    WHERE model_id = p_model_id 
    AND DATE(prediction_timestamp) = p_metric_date;
    
END;
$$ LANGUAGE plpgsql;

-- Procedure to detect model drift
CREATE OR REPLACE FUNCTION detect_model_drift(
    p_model_id VARCHAR(50),
    p_feature_name VARCHAR(100),
    p_drift_date DATE
) RETURNS VOID AS $$
DECLARE
    v_psi DECIMAL(10,4);
    v_csi DECIMAL(10,4);
    v_drift_score DECIMAL(10,4);
    v_threshold DECIMAL(10,4) := 0.25;
BEGIN
    -- Calculate Population Stability Index (PSI)
    -- This is a simplified calculation - in practice, you'd use more sophisticated methods
    SELECT 
        ABS(
            (COUNT(CASE WHEN prediction_probability < 0.5 THEN 1 END)::DECIMAL / COUNT(*)) -
            (COUNT(CASE WHEN prediction_probability >= 0.5 THEN 1 END)::DECIMAL / COUNT(*))
        ) INTO v_psi
    FROM model_predictions
    WHERE model_id = p_model_id 
    AND DATE(prediction_timestamp) = p_drift_date;
    
    -- Calculate Characteristic Stability Index (CSI)
    -- Simplified calculation
    v_csi := v_psi * 0.8;
    
    -- Calculate overall drift score
    v_drift_score := (v_psi + v_csi) / 2;
    
    -- Insert drift metrics
    INSERT INTO model_drift_metrics (
        model_id, 
        drift_date, 
        feature_name, 
        population_stability_index, 
        characteristic_stability_index, 
        data_drift_score, 
        drift_threshold, 
        drift_detected
    ) VALUES (
        p_model_id,
        p_drift_date,
        p_feature_name,
        v_psi,
        v_csi,
        v_drift_score,
        v_threshold,
        v_drift_score > v_threshold
    );
    
END;
$$ LANGUAGE plpgsql;

-- Procedure to generate alerts
CREATE OR REPLACE FUNCTION generate_alerts() RETURNS VOID AS $$
DECLARE
    alert_record RECORD;
    current_value DECIMAL(10,4);
    should_alert BOOLEAN;
BEGIN
    FOR alert_record IN 
        SELECT * FROM alert_configuration WHERE is_active = TRUE
    LOOP
        -- Get current metric value
        SELECT metric_value INTO current_value
        FROM model_performance_metrics
        WHERE model_id = alert_record.model_id
        AND metric_name = alert_record.metric_name
        AND metric_date = CURRENT_DATE
        ORDER BY created_timestamp DESC
        LIMIT 1;
        
        -- Check if alert should be generated
        CASE alert_record.threshold_operator
            WHEN '>' THEN should_alert := current_value > alert_record.threshold_value;
            WHEN '<' THEN should_alert := current_value < alert_record.threshold_value;
            WHEN '>=' THEN should_alert := current_value >= alert_record.threshold_value;
            WHEN '<=' THEN should_alert := current_value <= alert_record.threshold_value;
            WHEN '=' THEN should_alert := current_value = alert_record.threshold_value;
            ELSE should_alert := FALSE;
        END CASE;
        
        -- Generate alert if threshold is breached
        IF should_alert THEN
            INSERT INTO alert_history (
                alert_id,
                model_id,
                alert_value,
                alert_message
            ) VALUES (
                alert_record.alert_id,
                alert_record.model_id,
                current_value,
                'Threshold breached: ' || alert_record.metric_name || ' = ' || current_value || 
                ' ' || alert_record.threshold_operator || ' ' || alert_record.threshold_value
            );
        END IF;
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- =====================================================
-- 4. MONITORING DASHBOARD QUERIES
-- =====================================================

-- Real-time performance dashboard
-- Query 1: Current model status
SELECT 
    model_name,
    model_version,
    status,
    deployment_date,
    last_updated
FROM model_metadata
WHERE status = 'ACTIVE';

-- Query 2: Performance trends (last 7 days)
SELECT 
    DATE(metric_date) as date,
    AVG(CASE WHEN metric_name = 'accuracy' THEN metric_value END) as accuracy,
    AVG(CASE WHEN metric_name = 'response_time_ms' THEN metric_value END) as response_time,
    COUNT(CASE WHEN threshold_breached = TRUE THEN 1 END) as breaches
FROM model_performance_metrics
WHERE metric_date >= CURRENT_DATE - INTERVAL '7 days'
GROUP BY DATE(metric_date)
ORDER BY date DESC;

-- Query 3: Active alerts
SELECT 
    m.model_name,
    ac.alert_name,
    ac.alert_severity,
    ah.alert_timestamp,
    ah.alert_message,
    ah.resolved
FROM alert_history ah
JOIN alert_configuration ac ON ah.alert_id = ac.alert_id
JOIN model_metadata m ON ah.model_id = m.model_id
WHERE ah.resolved = FALSE
ORDER BY ah.alert_timestamp DESC;

-- Query 4: Drift detection summary
SELECT 
    feature_name,
    AVG(population_stability_index) as avg_psi,
    AVG(characteristic_stability_index) as avg_csi,
    COUNT(CASE WHEN drift_detected = TRUE THEN 1 END) as drift_events,
    MAX(drift_date) as last_drift_check
FROM model_drift_metrics
WHERE drift_date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY feature_name
ORDER BY drift_events DESC;

-- =====================================================
-- 5. MONITORING CONFIGURATION
-- =====================================================

-- Insert default alert configurations
INSERT INTO alert_configuration (model_id, alert_name, alert_type, metric_name, threshold_value, threshold_operator, alert_severity, notification_channels) VALUES
('CREDIT_RISK_V2_1', 'Low Accuracy Alert', 'PERFORMANCE', 'accuracy', 0.85, '<', 'CRITICAL', ARRAY['email', 'slack']),
('CREDIT_RISK_V2_1', 'High Response Time Alert', 'PERFORMANCE', 'response_time_ms', 3000, '>', 'WARNING', ARRAY['email']),
('CREDIT_RISK_V2_1', 'Low Prediction Volume Alert', 'PERFORMANCE', 'prediction_volume', 1000, '<', 'WARNING', ARRAY['email']),
('CREDIT_RISK_V2_1', 'Model Drift Alert', 'DRIFT', 'population_stability_index', 0.25, '>', 'CRITICAL', ARRAY['email', 'slack', 'pagerduty']);

-- Insert model metadata
INSERT INTO model_metadata (model_id, model_name, model_version, deployment_date, business_unit, model_owner) VALUES
('CREDIT_RISK_V2_1', 'Credit Risk Assessment Model', '2.1.0', '2024-01-15 10:00:00', 'Risk Management', 'John Smith');

-- =====================================================
-- 6. MONITORING SCHEDULE
-- =====================================================

/*
MONITORING SCHEDULE:

1. Real-time Monitoring:
   - Prediction processing time
   - Error rates
   - System availability

2. Hourly Monitoring:
   - Performance metrics calculation
   - Alert generation
   - Data quality checks

3. Daily Monitoring:
   - Model performance trends
   - Drift detection
   - Alert summary reports

4. Weekly Monitoring:
   - Comprehensive performance review
   - Drift analysis
   - Model retraining assessment

5. Monthly Monitoring:
   - Model validation review
   - Performance benchmarking
   - Regulatory compliance check
*/

-- =====================================================
-- END OF MONITORING FRAMEWORK
-- =====================================================


