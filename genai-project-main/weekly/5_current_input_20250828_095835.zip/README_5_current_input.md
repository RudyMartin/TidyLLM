# 5 Current Input

## Description
Current test files, examples, and notebooks

## Deployment Instructions
1. Extract this archive to the target environment
2. Follow the main DEPLOYMENT_MANIFEST instructions
3. Ensure proper file permissions are set

## Contents
This archive contains files matching these patterns:
- test_files/**/*
- sample_data/**/*
- input/REV2024*.*
- input/*.pdf
- input/test_files/**/*
- examples/**/*
- notebooks/**/*.ipynb
- notebooks/**/*.py

## Generated
Created: 2025-08-28T10:04:41.564359
System: Full Site Archiver for Air-Gapped Deployment
