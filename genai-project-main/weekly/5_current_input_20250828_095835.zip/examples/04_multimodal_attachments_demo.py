#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LLMData Multimodal Attachments Demo

Demonstrates the TidyLLM-style attachment processing with PNG/JPG images
and embedding generation using existing infrastructure integration.

This shows how we've integrated:
- Existing ImageProcessingWorker infrastructure
- TidyLLM-style attachment grammar 
- Multimodal message processing
- Vision model capabilities
- Embedding generation from images + text
"""

import sys
from pathlib import Path

# Add LLMData to path for testing
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

try:
    import llmdata
    from llmdata import (
        llm_message, multimodal_message, vision_chat, multimodal_embed,
        claude, openai, attach, load, present, refine
    )
    from llmdata.multimodal import batch_image_analysis, enhance_with_multimodal
    print("✅ LLMData with multimodal capabilities imported successfully")
except ImportError as e:
    print(f"❌ Import failed: {e}")
    print("Make sure llmdata package is installed: pip install -e .")
    sys.exit(1)

def demo_attachment_grammar():
    """Demonstrate TidyLLM-style attachment grammar"""
    print("\n" + "="*60)
    print("🔗 TidyLLM-Style Attachment Grammar Demo")
    print("="*60)
    
    # Create some sample files for demonstration
    sample_files = [
        "README.md",  # Text file
        "pyproject.toml",  # Configuration file
    ]
    
    # Check which files exist
    existing_files = [f for f in sample_files if Path(f).exists()]
    
    if existing_files:
        try:
            # TidyLLM-style attachment processing pipeline
            print(f"Processing {len(existing_files)} files with attachment grammar...")
            
            # This demonstrates the tidyLLM-inspired interface:
            processed = (attach(*existing_files)
                        | load.auto()
                        | present.markdown() + present.data_summary() 
                        | refine.add_headers())
            
            print(f"✅ Processed {len(existing_files)} attachments")
            print(f"📄 Text content length: {len(processed.text_content)} characters")
            print(f"🖼️ Images found: {len(processed.images)}")
            
            # Show first 200 characters of processed content
            if processed.text_content:
                preview = processed.text_content[:200] + "..." if len(processed.text_content) > 200 else processed.text_content
                print(f"\n📝 Content preview:\n{preview}")
            
        except Exception as e:
            print(f"⚠️ Attachment processing error: {e}")
    else:
        print("⚠️ No sample files found for attachment demo")

def demo_multimodal_messages():
    """Demonstrate multimodal message creation and processing"""
    print("\n" + "="*60)
    print("🖼️ Multimodal Message Processing Demo")
    print("="*60)
    
    # Look for sample images in the project
    potential_images = [
        "docs/assets/architecture.png",
        "docs/images/workflow.jpg", 
        "examples/sample.png",
        "test_image.jpg"
    ]
    
    sample_images = [img for img in potential_images if Path(img).exists()]
    
    if sample_images:
        print(f"Found {len(sample_images)} sample images")
        
        try:
            # Create multimodal message with images
            query = "Analyze these images and describe what you see"
            msg = multimodal_message(query, *sample_images[:2])  # Limit to 2 images
            
            print(f"✅ Created multimodal message with {len(msg.image_attachments)} images")
            print(f"📝 Query: {msg.content}")
            
            # Get image data using existing infrastructure
            image_data = msg.get_image_data()
            print(f"🔍 Processed image data: {len(image_data)} images")
            
            for i, img in enumerate(image_data):
                print(f"   Image {i+1}: {img.get('mime_type', 'unknown')} ({img.get('size', 0)} bytes)")
                if 'processing_method' in img:
                    print(f"   Processing method: {img['processing_method']}")
            
        except Exception as e:
            print(f"⚠️ Multimodal processing error: {e}")
    else:
        print("⚠️ No sample images found - creating synthetic demo")
        
        # Demonstrate with text-only multimodal message
        msg = multimodal_message("Describe the contents of this document", "README.md")
        print(f"✅ Created text-based multimodal message")
        print(f"📄 Text attachments: {len(msg.text_attachments)}")

def demo_vision_chat():
    """Demonstrate vision-enabled chat processing"""
    print("\n" + "="*60) 
    print("👁️ Vision Chat Demo")
    print("="*60)
    
    try:
        # Create a multimodal message (even if no images available)
        query = "What insights can you provide from the attached content?"
        attachments = ["README.md"] if Path("README.md").exists() else []
        
        msg = multimodal_message(query, *attachments)
        
        # Process with vision chat
        print("Processing with vision chat...")
        result = msg | vision_chat(claude(model="claude-3-5-sonnet"))
        
        print(f"✅ Vision chat completed")
        print(f"📊 Processing time: {result.get('processing_time', 0):.2f}s")
        print(f"🔧 Processing infrastructure: {result.get('processing_infrastructure', 'unknown')}")
        print(f"📈 Content parts processed: {result.get('content_parts', 0)}")
        
        # Show response preview
        response = result.get('response', '')
        if response:
            preview = response[:300] + "..." if len(response) > 300 else response
            print(f"\n💬 Response preview:\n{preview}")
        
    except Exception as e:
        print(f"⚠️ Vision chat error: {e}")

def demo_multimodal_embeddings():
    """Demonstrate multimodal embedding generation"""
    print("\n" + "="*60)
    print("🧮 Multimodal Embeddings Demo") 
    print("="*60)
    
    try:
        # Create multimodal message for embedding
        content = "This document contains technical information about data processing"
        attachments = ["README.md"] if Path("README.md").exists() else []
        
        msg = multimodal_message(content, *attachments)
        
        # Generate embeddings
        print("Generating multimodal embeddings...")
        result = msg | multimodal_embed(openai(model="text-embedding-3-large"))
        
        print(f"✅ Embeddings generated successfully")
        print(f"📊 Processing time: {result.get('processing_time', 0):.2f}s")
        print(f"📐 Embedding dimension: {result.get('dimension', 0)}")
        print(f"🖼️ Image count: {result.get('image_count', 0)}")
        print(f"📝 Text length: {result.get('text_length', 0)} characters")
        
        # Show embedding info
        embedding = result.get('embedding', [])
        if embedding:
            print(f"🔢 Embedding sample: [{embedding[0]:.4f}, {embedding[1]:.4f}, ..., {embedding[-1]:.4f}]")
        
    except Exception as e:
        print(f"⚠️ Embedding generation error: {e}")

def demo_existing_infrastructure_integration():
    """Demonstrate integration with existing ImageProcessingWorker"""
    print("\n" + "="*60)
    print("🔌 Existing Infrastructure Integration Demo")
    print("="*60)
    
    try:
        from llmdata.multimodal import EXISTING_IMAGE_WORKER_AVAILABLE
        from llmdata.attachments_enhanced import EXISTING_INFRASTRUCTURE_AVAILABLE
        
        print(f"🖼️ Existing ImageProcessingWorker: {'✅ Available' if EXISTING_IMAGE_WORKER_AVAILABLE else '❌ Not Available'}")
        print(f"🏗️ Existing Infrastructure: {'✅ Available' if EXISTING_INFRASTRUCTURE_AVAILABLE else '❌ Not Available'}")
        
        if EXISTING_INFRASTRUCTURE_AVAILABLE:
            print("\n🎯 Integration Status:")
            print("   - ImageProcessingWorker: Enhanced mode processing")
            print("   - ModernPDFProcessor: PDF text and image extraction")
            print("   - MCPMessage: Standardized message format")
            print("   - PIL/Pillow: Fallback image processing")
            
            # Test enhanced orchestrator integration
            from llmdata.multimodal import enhance_with_multimodal
            from llmdata import LLMMessage
            
            @enhance_with_multimodal
            class TestOrchestrator:
                pass
            
            orchestrator = TestOrchestrator()
            
            # Test if methods were added
            methods = ['process_multimodal_query', 'get_multimodal_embeddings', 'process_images_with_existing_worker']
            for method in methods:
                if hasattr(orchestrator, method):
                    print(f"   ✅ {method} - integrated")
                else:
                    print(f"   ❌ {method} - missing")
        else:
            print("\n⚠️ Existing infrastructure not found - using fallback processing")
    
    except Exception as e:
        print(f"⚠️ Infrastructure check error: {e}")

def demo_batch_image_analysis():
    """Demonstrate batch image processing"""
    print("\n" + "="*60)
    print("📊 Batch Image Analysis Demo")
    print("="*60)
    
    # Look for multiple images
    potential_images = [
        "docs/assets/architecture.png",
        "docs/images/workflow.jpg",
        "examples/chart.png",
        "test_data/sample1.jpg",
        "test_data/sample2.png"
    ]
    
    sample_images = [img for img in potential_images if Path(img).exists()]
    
    if len(sample_images) >= 2:
        try:
            query = "Extract key information from these images"
            results = batch_image_analysis(sample_images[:3], query, claude())
            
            print(f"✅ Batch processed {len(results)} images")
            
            for i, result in enumerate(results):
                print(f"   Image {i+1}: {'✅ Success' if result.get('success') else '❌ Failed'}")
                if result.get('error'):
                    print(f"      Error: {result['error']}")
                
        except Exception as e:
            print(f"⚠️ Batch analysis error: {e}")
    else:
        print(f"⚠️ Need at least 2 images for batch demo (found {len(sample_images)})")

def main():
    """Run comprehensive multimodal attachments demo"""
    print("🚀 LLMData Multimodal Attachments Comprehensive Demo")
    print("=" * 80)
    
    # Check overall capabilities
    print(f"🧮 TidyMart Available: {llmdata.TIDYMART_AVAILABLE}")
    print(f"📎 Attachments Enhanced: {llmdata.ATTACHMENTS_ENHANCED_AVAILABLE}")
    print(f"🔧 MCP Available: {llmdata.MCP_AVAILABLE}")
    
    # Run all demos
    demo_attachment_grammar()
    demo_multimodal_messages()
    demo_vision_chat() 
    demo_multimodal_embeddings()
    demo_existing_infrastructure_integration()
    demo_batch_image_analysis()
    
    print("\n" + "="*80)
    print("✅ Multimodal attachments demo completed!")
    print("🎯 Key capabilities demonstrated:")
    print("   - TidyLLM-style attachment grammar with | operator")
    print("   - Integration with existing ImageProcessingWorker")
    print("   - Multimodal message processing (text + images)")
    print("   - Vision-enabled chat with Claude/OpenAI")
    print("   - Multimodal embedding generation")
    print("   - Batch image analysis workflows")
    print("   - Orchestrator enhancement decorators")

if __name__ == "__main__":
    main()