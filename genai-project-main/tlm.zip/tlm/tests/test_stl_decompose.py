#!/usr/bin/env python3
"""
Test file for stl_decompose function.

Fixed: Function requires seasonal_len and trend_len parameters.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math

class TestStlDecompose(unittest.TestCase):
    """Test cases for stl_decompose function."""
    
    def test_stl_decompose_basic(self):
        """Test stl_decompose with required parameters."""
        # Create seasonal signal
        signal = []
        for i in range(100):
            trend = i * 0.1  # Linear trend
            seasonal = 5 * math.sin(2*math.pi*i/12)  # 12-period seasonality
            noise = 0.5 * (i % 3 - 1)  # Small noise
            signal.append(trend + seasonal + noise)
        
        result = tlm.stl_decompose(signal, seasonal_len=12, trend_len=25)
        
        # Should return decomposition object with trend, seasonal, remainder
        self.assertTrue(hasattr(result, 'trend'))
        self.assertTrue(hasattr(result, 'seasonal'))
        self.assertTrue(hasattr(result, 'remainder'))
    
    def test_stl_decompose_different_params(self):
        """Test with different seasonal and trend lengths."""
        signal = [10 + 3*math.sin(2*math.pi*i/20) + i*0.05 for i in range(80)]
        
        result = tlm.stl_decompose(signal, seasonal_len=20, trend_len=15)
        
        self.assertTrue(hasattr(result, 'trend'))
        self.assertIsInstance(result.trend, list)
    
    def test_robust_stl_decompose(self):
        """Test robust_stl_decompose with required parameters."""
        import random
        signal = [5 + 2*math.cos(2*math.pi*i/15) + random.gauss(0, 0.2) for i in range(75)]
        
        result = tlm.robust_stl_decompose(signal, seasonal_len=15, trend_len=31)
        
        self.assertTrue(hasattr(result, 'trend'))
        self.assertTrue(hasattr(result, 'seasonal'))

if __name__ == "__main__":
    import random
    unittest.main(verbosity=2)