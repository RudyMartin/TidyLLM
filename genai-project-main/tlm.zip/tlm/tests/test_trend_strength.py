#!/usr/bin/env python3
"""
Test file for trend_strength function.

This function has been verified to work correctly.
See test_all_remaining_functions.py for comprehensive testing scenarios.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random
import math

class TestTrendStrength(unittest.TestCase):
    """Test cases for trend_strength function."""
    
    def setUp(self):
        """Set up test data."""
        self.prices = [100.0 + random.gauss(0, 5) for _ in range(50)]
        self.ohlc_data = []
        for i, p in enumerate(self.prices):
            if i == 0:
                open_price = p
            else:
                open_price = self.prices[i-1]
            high = p + abs(random.gauss(0, 2))
            low = p - abs(random.gauss(0, 2))
            close = p
            self.ohlc_data.append((open_price, high, low, close))
        
        self.volumes = [1000000 + random.randint(-200000, 500000) for _ in range(50)]
        self.edges = [(0, 1), (1, 2), (2, 3), (3, 0), (1, 3)]
        self.graph = tlm.Graph(self.edges)
    
    def test_trend_strength_basic(self):
        """Test trend_strength with basic inputs."""
        # This test is based on successful testing in test_all_remaining_functions.py
        
        try:
            signal = [i + 5*math.sin(2*math.pi*i/20) for i in range(100)]
            decomp = tlm.additive_decompose(signal, 20)
            result = tlm.trend_strength(decomp)
            self.assertIsInstance(result, float)
            
        except Exception as e:
            self.fail(f"trend_strength failed with error: {e}")

if __name__ == "__main__":
    unittest.main(verbosity=2)
