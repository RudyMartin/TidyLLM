#!/usr/bin/env python3
"""
Test file for calculate_diversity_metrics function.

This function had generator bugs that have been fixed.
Now works correctly with list inputs.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest

class TestCalculateDiversityMetrics(unittest.TestCase):
    """Test cases for calculate_diversity_metrics function."""
    
    def test_calculate_diversity_metrics_basic(self):
        """Test calculate_diversity_metrics with basic composition."""
        composition = [30.0, 30.0, 40.0]
        result = tlm.calculate_diversity_metrics(composition)
        
        # Should return DiversityMetrics object
        self.assertTrue(hasattr(result, 'shannon_diversity'))
        self.assertTrue(hasattr(result, 'simpson_diversity'))
        self.assertTrue(hasattr(result, 'berger_parker_dominance'))
        self.assertIsInstance(result.shannon_diversity, float)
        self.assertGreater(result.shannon_diversity, 0)
    
    def test_uniform_distribution(self):
        """Test with uniform distribution (maximum diversity)."""
        composition = [25.0, 25.0, 25.0, 25.0]  # Equal parts
        result = tlm.calculate_diversity_metrics(composition)
        
        # Uniform distribution should have high diversity
        self.assertGreater(result.shannon_diversity, 1.3)  # log(4) ≈ 1.39
        self.assertGreater(result.simpson_diversity, 0.7)
    
    def test_skewed_distribution(self):
        """Test with skewed distribution (low diversity)."""
        composition = [90.0, 5.0, 3.0, 2.0]  # One dominant
        result = tlm.calculate_diversity_metrics(composition)
        
        # Skewed distribution should have lower diversity
        self.assertLess(result.shannon_diversity, 1.0)
        self.assertLess(result.simpson_diversity, 0.5)
        self.assertEqual(result.berger_parker_dominance, 0.9)  # Dominant proportion
    
    def test_binary_composition(self):
        """Test with binary composition."""
        composition = [60.0, 40.0]
        result = tlm.calculate_diversity_metrics(composition)
        
        self.assertGreater(result.shannon_diversity, 0.5)
        self.assertLess(result.shannon_diversity, 1.0)  # Less than log(2)
    
    def test_single_category(self):
        """Test with single category (no diversity)."""
        composition = [100.0]
        result = tlm.calculate_diversity_metrics(composition)
        
        # Single category should have zero diversity
        self.assertEqual(result.shannon_diversity, 0.0)
        self.assertEqual(result.simpson_diversity, 0.0)

if __name__ == "__main__":
    unittest.main(verbosity=2)