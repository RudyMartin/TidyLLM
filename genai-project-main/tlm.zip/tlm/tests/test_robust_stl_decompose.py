#!/usr/bin/env python3
"""
Test file for robust_stl_decompose function.

Fixed: Function requires seasonal_len and trend_len parameters.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math
import random

class TestRobustStlDecompose(unittest.TestCase):
    """Test cases for robust_stl_decompose function."""
    
    def test_robust_stl_decompose_basic(self):
        """Test robust_stl_decompose with required parameters."""
        # Create signal with outliers for robust decomposition
        signal = []
        for i in range(100):
            trend = i * 0.1
            seasonal = 3 * math.sin(2*math.pi*i/10)
            noise = random.gauss(0, 0.1)
            # Add some outliers
            if i % 20 == 0:
                noise += 10 * random.choice([-1, 1])  # Outliers
            signal.append(trend + seasonal + noise)
        
        result = tlm.robust_stl_decompose(signal, seasonal_len=10, trend_len=21)
        
        # Should return decomposition object
        self.assertTrue(hasattr(result, 'trend'))
        self.assertTrue(hasattr(result, 'seasonal'))
        self.assertTrue(hasattr(result, 'remainder'))
    
    def test_robust_vs_regular(self):
        """Test that robust version handles outliers better."""
        base_signal = [5 + 2*math.sin(2*math.pi*i/12) for i in range(60)]
        
        # Add outliers
        outlier_signal = base_signal.copy()
        outlier_signal[10] += 50  # Large positive outlier
        outlier_signal[30] -= 40  # Large negative outlier
        
        result = tlm.robust_stl_decompose(outlier_signal, seasonal_len=12, trend_len=25)
        self.assertTrue(hasattr(result, 'trend'))

if __name__ == "__main__":
    unittest.main(verbosity=2)