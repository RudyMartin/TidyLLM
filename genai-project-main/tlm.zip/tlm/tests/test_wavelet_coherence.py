#!/usr/bin/env python3
"""
Test file for wavelet_coherence function.

Fixed: Function requires scales parameter which was missing in original tests.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math

class TestWaveletCoherence(unittest.TestCase):
    """Test cases for wavelet_coherence function."""
    
    def test_wavelet_coherence_basic(self):
        """Test wavelet_coherence with required scales parameter."""
        # Create two related signals
        signal1 = [math.sin(2*math.pi*i/20) for i in range(100)]
        signal2 = [math.sin(2*math.pi*i/20 + 0.1) for i in range(100)]  # Slightly phase-shifted
        scales = [1, 2, 4, 8, 16]
        
        result = tlm.wavelet_coherence(signal1, signal2, scales)
        
        # Should return coherence matrix or list
        self.assertIsInstance(result, list)
        self.assertGreater(len(result), 0)
    
    def test_coherent_signals(self):
        """Test with highly coherent signals."""
        # Same frequency, same phase
        signal1 = [math.sin(2*math.pi*i/10) for i in range(50)]
        signal2 = [math.sin(2*math.pi*i/10) for i in range(50)]
        scales = [2, 4, 8]
        
        result = tlm.wavelet_coherence(signal1, signal2, scales)
        self.assertIsInstance(result, list)
    
    def test_uncorrelated_signals(self):
        """Test with uncorrelated signals."""
        signal1 = [math.sin(2*math.pi*i/5) for i in range(50)]  # Fast oscillation
        signal2 = [math.sin(2*math.pi*i/25) for i in range(50)] # Slow oscillation
        scales = [1, 5, 10, 20]
        
        result = tlm.wavelet_coherence(signal1, signal2, scales)
        self.assertIsInstance(result, list)

if __name__ == "__main__":
    unittest.main(verbosity=2)