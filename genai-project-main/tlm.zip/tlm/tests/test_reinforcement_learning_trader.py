#!/usr/bin/env python3
"""
Test file for reinforcement_learning_trader function.

Fixed: Function requires volumes parameter which was missing in original tests.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random

class TestReinforcementLearningTrader(unittest.TestCase):
    """Test cases for reinforcement_learning_trader function."""
    
    def setUp(self):
        """Set up test data."""
        # Create price and volume data
        self.prices = [100.0 + i * 0.3 + random.gauss(0, 1.5) for i in range(60)]
        self.volumes = [1000000 + random.randint(-300000, 700000) for _ in range(60)]
    
    def test_reinforcement_learning_trader_basic(self):
        """Test reinforcement_learning_trader with prices and volumes."""
        result = tlm.reinforcement_learning_trader(self.prices, self.volumes, train_episodes=20)
        
        # Should return list of ML signals
        self.assertIsInstance(result, list)
        # May be empty if training is insufficient, but should not error
        if result:
            # Each signal should be an MLSignal object
            for signal in result[:3]:  # Check first few
                self.assertTrue(hasattr(signal, 'action'))
                self.assertTrue(hasattr(signal, 'confidence'))
                self.assertTrue(hasattr(signal, 'timestamp'))
    
    def test_with_trending_data(self):
        """Test with strongly trending price data."""
        trending_prices = [100 + i * 1.2 for i in range(50)]  # Strong uptrend
        trending_volumes = [1200000 + i * 10000 for i in range(50)]  # Increasing volume
        
        result = tlm.reinforcement_learning_trader(trending_prices, trending_volumes, train_episodes=15)
        
        self.assertIsInstance(result, list)
    
    def test_insufficient_data(self):
        """Test with insufficient data (should return empty list)."""
        short_prices = self.prices[:30]  # Less than 50 required
        short_volumes = self.volumes[:30]
        
        result = tlm.reinforcement_learning_trader(short_prices, short_volumes, train_episodes=10)
        
        # Should return empty list for insufficient data
        self.assertEqual(result, [])
    
    def test_mismatched_lengths(self):
        """Test with mismatched price and volume lengths."""
        mismatched_volumes = self.volumes[:40]  # Different length
        
        result = tlm.reinforcement_learning_trader(self.prices, mismatched_volumes, train_episodes=10)
        
        # Should return empty list for mismatched lengths
        self.assertEqual(result, [])
    
    def test_different_training_episodes(self):
        """Test with different training episode counts."""
        result1 = tlm.reinforcement_learning_trader(self.prices, self.volumes, train_episodes=5)
        result2 = tlm.reinforcement_learning_trader(self.prices, self.volumes, train_episodes=50)
        
        self.assertIsInstance(result1, list)
        self.assertIsInstance(result2, list)

if __name__ == "__main__":
    unittest.main(verbosity=2)