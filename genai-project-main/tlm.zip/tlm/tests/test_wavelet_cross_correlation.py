#!/usr/bin/env python3
"""
Test file for wavelet_cross_correlation function.

Fixed: Function requires scales parameter for wavelet analysis.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math

class TestWaveletCrossCorrelation(unittest.TestCase):
    """Test cases for wavelet_cross_correlation function."""
    
    def test_wavelet_cross_correlation_basic(self):
        """Test wavelet_cross_correlation with required scales parameter."""
        # Create two related time series
        series1 = [math.sin(2*math.pi*i/20) for i in range(100)]
        series2 = [math.sin(2*math.pi*i/20 + 0.2) for i in range(100)]  # Phase shifted
        scales = [1, 2, 4, 8, 16]
        
        result = tlm.wavelet_cross_correlation(series1, series2, scales, max_lag=5)
        
        # Should return dictionary with scales as keys
        self.assertIsInstance(result, dict)
        self.assertGreater(len(result), 0)
        
        # Check that all scales are represented
        for scale in scales:
            self.assertIn(scale, result)
            self.assertIsInstance(result[scale], list)
    
    def test_identical_series(self):
        """Test with identical series - should show high correlation."""
        series = [math.cos(2*math.pi*i/15) for i in range(60)]
        scales = [2, 4, 8]
        
        result = tlm.wavelet_cross_correlation(series, series, scales, max_lag=3)
        
        self.assertIsInstance(result, dict)
        self.assertEqual(len(result), len(scales))
    
    def test_uncorrelated_series(self):
        """Test with uncorrelated series."""
        series1 = [math.sin(2*math.pi*i/5) for i in range(50)]   # Fast oscillation
        series2 = [math.sin(2*math.pi*i/30) for i in range(50)]  # Slow oscillation
        scales = [1, 3, 6, 12]
        
        result = tlm.wavelet_cross_correlation(series1, series2, scales, max_lag=10)
        
        self.assertIsInstance(result, dict)
        for scale in scales:
            self.assertIn(scale, result)
    
    def test_different_max_lag(self):
        """Test with different max_lag values."""
        series1 = [math.sin(2*math.pi*i/12) + 0.1*i for i in range(80)]
        series2 = [math.cos(2*math.pi*i/12) + 0.1*i for i in range(80)]
        scales = [2, 6, 12]
        
        # Test different lag values
        result1 = tlm.wavelet_cross_correlation(series1, series2, scales, max_lag=5)
        result2 = tlm.wavelet_cross_correlation(series1, series2, scales, max_lag=15)
        
        self.assertIsInstance(result1, dict)
        self.assertIsInstance(result2, dict)

if __name__ == "__main__":
    unittest.main(verbosity=2)