#!/usr/bin/env python3
"""
Test file for triangle_breakout function.

Fixed: Function requires OHLC data (tuples of open, high, low, close) instead of simple prices.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random

class TestTriangleBreakout(unittest.TestCase):
    """Test cases for triangle_breakout function."""
    
    def setUp(self):
        """Set up OHLC test data."""
        # Generate OHLC data (open, high, low, close)
        self.ohlc_data = []
        base_price = 100.0
        for i in range(60):
            open_price = base_price + random.gauss(0, 0.5)
            high_price = open_price + random.uniform(0.5, 2.0)
            low_price = open_price - random.uniform(0.5, 2.0)
            close_price = open_price + random.gauss(0, 1.0)
            
            # Ensure high >= max(open, close) and low <= min(open, close)
            high_price = max(high_price, open_price, close_price)
            low_price = min(low_price, open_price, close_price)
            
            self.ohlc_data.append((open_price, high_price, low_price, close_price))
            base_price = close_price  # Next candle opens near previous close
    
    def test_triangle_breakout_basic(self):
        """Test triangle_breakout with OHLC data."""
        result = tlm.triangle_breakout(self.ohlc_data, min_touches=3)
        
        # Should return list of ML signals
        self.assertIsInstance(result, list)
        # May be empty if no triangles detected
        if result:
            for signal in result[:2]:  # Check first few
                self.assertTrue(hasattr(signal, 'action'))
                self.assertTrue(hasattr(signal, 'timestamp'))
    
    def test_triangle_breakout_converging_pattern(self):
        """Test with artificially converging pattern."""
        # Create converging triangle pattern
        converging_ohlc = []
        for i in range(50):
            # Converging highs and lows
            base = 100
            high_range = 5 - (i * 0.08)  # Decreasing range
            low_range = 3 - (i * 0.05)
            
            open_price = base + random.uniform(-1, 1)
            high_price = base + high_range + random.uniform(0, 0.5)
            low_price = base - low_range - random.uniform(0, 0.5)
            close_price = base + random.uniform(-0.5, 0.5)
            
            converging_ohlc.append((open_price, high_price, low_price, close_price))
        
        result = tlm.triangle_breakout(converging_ohlc, min_touches=4)
        self.assertIsInstance(result, list)
    
    def test_insufficient_data(self):
        """Test with insufficient data (should return empty list)."""
        short_ohlc = self.ohlc_data[:30]  # Less than 50 required
        
        result = tlm.triangle_breakout(short_ohlc, min_touches=4)
        
        # Should return empty list for insufficient data
        self.assertEqual(result, [])
    
    def test_different_min_touches(self):
        """Test with different minimum touch requirements."""
        result1 = tlm.triangle_breakout(self.ohlc_data, min_touches=3)
        result2 = tlm.triangle_breakout(self.ohlc_data, min_touches=6)
        
        self.assertIsInstance(result1, list)
        self.assertIsInstance(result2, list)
        # More strict requirements may yield fewer signals
    
    def test_trending_ohlc_data(self):
        """Test with trending OHLC data."""
        trending_ohlc = []
        for i in range(55):
            base = 100 + i * 0.5  # Uptrend
            open_price = base + random.uniform(-0.3, 0.3)
            high_price = base + random.uniform(1, 2)
            low_price = base - random.uniform(0.5, 1)
            close_price = base + random.uniform(0, 1)
            
            trending_ohlc.append((open_price, high_price, low_price, close_price))
        
        result = tlm.triangle_breakout(trending_ohlc, min_touches=4)
        self.assertIsInstance(result, list)

if __name__ == "__main__":
    unittest.main(verbosity=2)