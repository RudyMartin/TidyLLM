#!/usr/bin/env python3
"""
Test file for fixed_fractional function.

Fixed: Function requires capital parameter for position sizing calculation.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest

class TestFixedFractional(unittest.TestCase):
    """Test cases for fixed_fractional function."""
    
    def test_fixed_fractional_basic(self):
        """Test fixed_fractional with capital and default risk."""
        capital = 100000.0  # $100k capital
        
        result = tlm.fixed_fractional(capital)
        
        # Should return a float representing position size
        self.assertIsInstance(result, (int, float))
        self.assertGreater(result, 0)
        # With default 2% risk, should be 2% of capital
        self.assertAlmostEqual(result, capital * 0.02, places=2)
    
    def test_fixed_fractional_custom_risk(self):
        """Test with custom risk percentage."""
        capital = 50000.0
        risk_per_trade = 0.05  # 5% risk
        
        result = tlm.fixed_fractional(capital, risk_per_trade)
        
        self.assertIsInstance(result, (int, float))
        self.assertAlmostEqual(result, capital * risk_per_trade, places=2)
    
    def test_different_capital_amounts(self):
        """Test with different capital amounts."""
        test_capitals = [10000, 250000, 1000000]
        risk = 0.01  # 1% risk
        
        for capital in test_capitals:
            result = tlm.fixed_fractional(capital, risk)
            expected = capital * risk
            self.assertAlmostEqual(result, expected, places=2)
    
    def test_low_risk_percentage(self):
        """Test with very low risk percentage."""
        capital = 100000
        low_risk = 0.001  # 0.1% risk
        
        result = tlm.fixed_fractional(capital, low_risk)
        
        self.assertIsInstance(result, (int, float))
        self.assertAlmostEqual(result, capital * low_risk, places=3)
    
    def test_high_risk_percentage(self):
        """Test with higher risk percentage."""
        capital = 25000
        high_risk = 0.1  # 10% risk
        
        result = tlm.fixed_fractional(capital, high_risk)
        
        self.assertIsInstance(result, (int, float))
        self.assertAlmostEqual(result, capital * high_risk, places=2)
    
    def test_zero_capital(self):
        """Test with zero capital."""
        result = tlm.fixed_fractional(0, 0.02)
        
        self.assertEqual(result, 0)
    
    def test_zero_risk(self):
        """Test with zero risk."""
        result = tlm.fixed_fractional(100000, 0)
        
        self.assertEqual(result, 0)

if __name__ == "__main__":
    unittest.main(verbosity=2)