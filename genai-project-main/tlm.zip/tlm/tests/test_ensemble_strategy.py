#!/usr/bin/env python3
"""
Test file for ensemble_strategy function.

Fixed: Function requires volumes parameter which was missing in original tests.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random

class TestEnsembleStrategy(unittest.TestCase):
    """Test cases for ensemble_strategy function."""
    
    def setUp(self):
        """Set up test data."""
        self.prices = [100.0 + i * 0.5 + random.gauss(0, 2) for i in range(50)]
        self.volumes = [1000000 + random.randint(-200000, 500000) for _ in range(50)]
    
    def test_ensemble_strategy_basic(self):
        """Test ensemble_strategy with prices and volumes."""
        result = tlm.ensemble_strategy(self.prices, self.volumes)
        
        # Should return some kind of strategy result
        self.assertIsNotNone(result)
        # Could be list of signals or strategy object
        self.assertTrue(hasattr(result, '__iter__') or hasattr(result, '__dict__'))
    
    def test_ensemble_strategy_different_lengths(self):
        """Test with consistent length arrays."""
        short_prices = self.prices[:30]
        short_volumes = self.volumes[:30]
        
        result = tlm.ensemble_strategy(short_prices, short_volumes)
        self.assertIsNotNone(result)
    
    def test_ensemble_strategy_trending_market(self):
        """Test with trending market data."""
        trending_prices = [100 + i * 0.8 for i in range(40)]  # Uptrend
        trending_volumes = [1000000] * 40  # Constant volume
        
        result = tlm.ensemble_strategy(trending_prices, trending_volumes)
        self.assertIsNotNone(result)

if __name__ == "__main__":
    unittest.main(verbosity=2)