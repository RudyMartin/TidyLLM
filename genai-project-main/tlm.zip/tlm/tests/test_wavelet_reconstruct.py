#!/usr/bin/env python3
"""
Test file for wavelet_reconstruct function.

Fixed: Function requires coefficients from wavelet_decompose.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math

class TestWaveletReconstruct(unittest.TestCase):
    """Test cases for wavelet_reconstruct function."""
    
    def test_wavelet_reconstruct_basic(self):
        """Test wavelet_reconstruct with coefficients from decompose."""
        # Create test signal
        signal = [math.sin(2*math.pi*i/20) for i in range(64)]  # Power of 2 length
        
        # Decompose signal first
        coeffs = tlm.wavelet_decompose(signal, wavelet='haar')
        
        # Reconstruct signal
        reconstructed = tlm.wavelet_reconstruct(coeffs, wavelet='haar')
        
        # Should return a time series (list)
        self.assertIsInstance(reconstructed, list)
        self.assertGreater(len(reconstructed), 0)
    
    def test_different_wavelets(self):
        """Test with different wavelet types if supported."""
        signal = [math.cos(2*math.pi*i/16) + 0.1*i for i in range(32)]
        
        # Test Haar wavelet
        coeffs_haar = tlm.wavelet_decompose(signal, wavelet='haar')
        reconstructed_haar = tlm.wavelet_reconstruct(coeffs_haar, wavelet='haar')
        
        self.assertIsInstance(reconstructed_haar, list)
        
        # Test if other wavelets are available
        try:
            coeffs_db = tlm.wavelet_decompose(signal, wavelet='db4')
            reconstructed_db = tlm.wavelet_reconstruct(coeffs_db, wavelet='db4')
            self.assertIsInstance(reconstructed_db, list)
        except:
            # May not be implemented
            pass
    
    def test_signal_preservation(self):
        """Test that decompose/reconstruct preserves signal structure."""
        # Simple signal
        signal = [1, 2, 3, 4, 3, 2, 1, 0] * 4  # 32 elements
        
        coeffs = tlm.wavelet_decompose(signal, wavelet='haar')
        reconstructed = tlm.wavelet_reconstruct(coeffs, wavelet='haar')
        
        self.assertIsInstance(reconstructed, list)
        # Length should be preserved or close
        self.assertLessEqual(abs(len(reconstructed) - len(signal)), 2)
    
    def test_complex_signal(self):
        """Test with more complex signal."""
        # Mixed frequency signal
        signal = []
        for i in range(128):
            val = (math.sin(2*math.pi*i/32) +     # Low frequency
                   0.5*math.sin(2*math.pi*i/8) +  # High frequency
                   0.1*math.sin(2*math.pi*i/4))   # Very high frequency
            signal.append(val)
        
        coeffs = tlm.wavelet_decompose(signal, wavelet='haar')
        reconstructed = tlm.wavelet_reconstruct(coeffs, wavelet='haar')
        
        self.assertIsInstance(reconstructed, list)
        self.assertGreater(len(reconstructed), 0)

if __name__ == "__main__":
    unittest.main(verbosity=2)