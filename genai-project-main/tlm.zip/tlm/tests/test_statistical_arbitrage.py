#!/usr/bin/env python3
"""
Test file for statistical_arbitrage function.

Fixed: Function requires list of price series (multiple assets) instead of single price series.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random
import math

class TestStatisticalArbitrage(unittest.TestCase):
    """Test cases for statistical_arbitrage function."""
    
    def setUp(self):
        """Set up multi-asset price data."""
        # Create correlated price series for arbitrage opportunities
        base_trend = [100 + i * 0.1 + random.gauss(0, 0.5) for i in range(50)]
        
        self.prices = []
        # Asset 1: follows base trend closely
        asset1 = [p + random.gauss(0, 1) for p in base_trend]
        # Asset 2: similar but with different noise
        asset2 = [p * 1.02 + random.gauss(0, 1.5) for p in base_trend]
        # Asset 3: somewhat correlated
        asset3 = [p * 0.98 + random.gauss(0, 2) for p in base_trend]
        
        self.prices = [asset1, asset2, asset3]
    
    def test_statistical_arbitrage_basic(self):
        """Test statistical_arbitrage with multiple price series."""
        result = tlm.statistical_arbitrage(self.prices, lookback=20)
        
        # Should return StrategyResult object
        self.assertTrue(hasattr(result, 'signals'))
        self.assertTrue(hasattr(result, 'positions'))
        self.assertTrue(hasattr(result, 'returns'))
        self.assertTrue(hasattr(result, 'metrics'))
    
    def test_insufficient_assets(self):
        """Test with insufficient number of assets."""
        single_asset = [self.prices[0]]  # Only one asset
        
        result = tlm.statistical_arbitrage(single_asset, lookback=20)
        
        # Should return empty StrategyResult
        self.assertEqual(result.signals, [])
        self.assertEqual(result.positions, [])
        self.assertEqual(result.returns, [])
    
    def test_insufficient_data_length(self):
        """Test with insufficient data length."""
        short_prices = [asset[:15] for asset in self.prices]  # Shorter than lookback
        
        result = tlm.statistical_arbitrage(short_prices, lookback=20)
        
        # Should return empty StrategyResult
        self.assertEqual(result.signals, [])
    
    def test_different_lookback_periods(self):
        """Test with different lookback periods."""
        result1 = tlm.statistical_arbitrage(self.prices, lookback=10)
        result2 = tlm.statistical_arbitrage(self.prices, lookback=30)
        
        self.assertTrue(hasattr(result1, 'signals'))
        self.assertTrue(hasattr(result2, 'signals'))
    
    def test_highly_correlated_assets(self):
        """Test with highly correlated assets."""
        # Create very similar price series
        base_series = [100 + i * 0.2 + math.sin(i/10) for i in range(40)]
        correlated_prices = []
        
        for j in range(4):  # 4 similar assets
            asset = [p + random.gauss(0, 0.1) + j * 0.05 for p in base_series]
            correlated_prices.append(asset)
        
        result = tlm.statistical_arbitrage(correlated_prices, lookback=15)
        
        self.assertTrue(hasattr(result, 'signals'))
        self.assertTrue(hasattr(result, 'positions'))
    
    def test_uncorrelated_assets(self):
        """Test with uncorrelated assets."""
        uncorrelated_prices = []
        
        # Create independent random walks
        for j in range(3):
            asset = [100]
            for i in range(39):
                asset.append(asset[-1] + random.gauss(0, 2))
            uncorrelated_prices.append(asset)
        
        result = tlm.statistical_arbitrage(uncorrelated_prices, lookback=20)
        
        self.assertTrue(hasattr(result, 'signals'))

if __name__ == "__main__":
    unittest.main(verbosity=2)