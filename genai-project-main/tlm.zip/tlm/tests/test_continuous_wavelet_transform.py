#!/usr/bin/env python3
"""
Test file for continuous_wavelet_transform function.

Fixed: Function requires scales parameter which was missing in original tests.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import math

class TestContinuousWaveletTransform(unittest.TestCase):
    """Test cases for continuous_wavelet_transform function."""
    
    def test_continuous_wavelet_transform_basic(self):
        """Test continuous_wavelet_transform with required scales parameter."""
        # Create test signal
        signal = [math.sin(2*math.pi*i/20) for i in range(100)]
        # Provide scales array
        scales = [1, 2, 4, 8, 16]
        
        result = tlm.continuous_wavelet_transform(signal, scales, 'morlet')
        
        # Should return list of lists (complex coefficients)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), len(scales))  # One row per scale
        if result:
            self.assertIsInstance(result[0], list)
    
    def test_different_wavelets(self):
        """Test with different wavelet types if supported."""
        signal = [math.sin(2*math.pi*i/10) + 0.5*math.sin(2*math.pi*i/5) for i in range(50)]
        scales = [1, 2, 4]
        
        # Test morlet wavelet (default)
        result = tlm.continuous_wavelet_transform(signal, scales, 'morlet')
        self.assertIsInstance(result, list)
        
        # Test other wavelets if available
        try:
            result2 = tlm.continuous_wavelet_transform(signal, scales, 'mexican_hat')
            self.assertIsInstance(result2, list)
        except:
            # May not be implemented
            pass
    
    def test_single_scale(self):
        """Test with single scale."""
        signal = [math.cos(2*math.pi*i/15) for i in range(60)]
        scales = [2]
        
        result = tlm.continuous_wavelet_transform(signal, scales)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
    
    def test_multiple_frequencies(self):
        """Test with signal containing multiple frequencies."""
        # Combine low and high frequency components
        signal = []
        for i in range(100):
            val = (math.sin(2*math.pi*i/50) +     # Low frequency
                   0.5*math.sin(2*math.pi*i/5))   # High frequency
            signal.append(val)
        
        scales = [1, 2, 4, 8, 16, 32]  # Wide range of scales
        
        result = tlm.continuous_wavelet_transform(signal, scales, 'morlet')
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), len(scales))

if __name__ == "__main__":
    unittest.main(verbosity=2)