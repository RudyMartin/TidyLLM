#!/usr/bin/env python3
"""
Test file for relative_strength_strategy function.

Fixed: Function requires list of price series (multiple assets) for relative comparison.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random

class TestRelativeStrengthStrategy(unittest.TestCase):
    """Test cases for relative_strength_strategy function."""
    
    def setUp(self):
        """Set up multi-asset price data with different performance."""
        # Create assets with different performance characteristics
        periods = 40
        
        # Strong performer
        strong_asset = [100]
        for i in range(periods - 1):
            strong_asset.append(strong_asset[-1] * (1 + random.gauss(0.003, 0.01)))
        
        # Average performer
        avg_asset = [100]
        for i in range(periods - 1):
            avg_asset.append(avg_asset[-1] * (1 + random.gauss(0.001, 0.015)))
        
        # Weak performer
        weak_asset = [100]
        for i in range(periods - 1):
            weak_asset.append(weak_asset[-1] * (1 + random.gauss(-0.001, 0.012)))
        
        # Another asset
        mixed_asset = [100]
        for i in range(periods - 1):
            mixed_asset.append(mixed_asset[-1] * (1 + random.gauss(0.0005, 0.02)))
        
        self.prices = [strong_asset, avg_asset, weak_asset, mixed_asset]
    
    def test_relative_strength_strategy_basic(self):
        """Test relative_strength_strategy with multiple price series."""
        result = tlm.relative_strength_strategy(self.prices, lookback=15)
        
        # Should return StrategyResult object
        self.assertTrue(hasattr(result, 'signals'))
        self.assertTrue(hasattr(result, 'positions'))
        self.assertTrue(hasattr(result, 'returns'))
        self.assertTrue(hasattr(result, 'metrics'))
    
    def test_insufficient_assets(self):
        """Test with insufficient number of assets."""
        single_asset = [self.prices[0]]  # Only one asset
        
        result = tlm.relative_strength_strategy(single_asset, lookback=15)
        
        # Should return empty StrategyResult
        self.assertEqual(result.signals, [])
        self.assertEqual(result.positions, [])
        self.assertEqual(result.returns, [])
    
    def test_insufficient_data_length(self):
        """Test with insufficient data length."""
        short_prices = [asset[:15] for asset in self.prices]  # Shorter than lookback
        
        result = tlm.relative_strength_strategy(short_prices, lookback=20)
        
        # Should return empty StrategyResult
        self.assertEqual(result.signals, [])
    
    def test_different_lookback_periods(self):
        """Test with different lookback periods."""
        result1 = tlm.relative_strength_strategy(self.prices, lookback=10)
        result2 = tlm.relative_strength_strategy(self.prices, lookback=25)
        
        self.assertTrue(hasattr(result1, 'signals'))
        self.assertTrue(hasattr(result2, 'signals'))
    
    def test_clear_performance_differences(self):
        """Test with assets having clear performance differences."""
        # Create assets with obvious relative strength differences
        periods = 30
        
        # Very strong performer
        winner = [100 + i * 2 + random.gauss(0, 0.5) for i in range(periods)]
        # Stable performer
        stable = [100 + i * 0.1 + random.gauss(0, 0.8) for i in range(periods)]
        # Declining performer
        loser = [100 - i * 0.5 + random.gauss(0, 0.5) for i in range(periods)]
        
        clear_prices = [winner, stable, loser]
        
        result = tlm.relative_strength_strategy(clear_prices, lookback=15)
        
        self.assertTrue(hasattr(result, 'signals'))
        self.assertTrue(hasattr(result, 'positions'))
    
    def test_similar_performing_assets(self):
        """Test with assets having similar performance."""
        # Create very similar performing assets
        base_trend = [100 + i * 0.2 for i in range(35)]
        similar_prices = []
        
        for j in range(3):
            asset = [p + random.gauss(0, 1) for p in base_trend]
            similar_prices.append(asset)
        
        result = tlm.relative_strength_strategy(similar_prices, lookback=20)
        
        self.assertTrue(hasattr(result, 'signals'))

if __name__ == "__main__":
    unittest.main(verbosity=2)