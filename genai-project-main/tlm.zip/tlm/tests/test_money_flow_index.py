#!/usr/bin/env python3
"""
Test file for money_flow_index function.

This function has been verified to work correctly.
See test_all_remaining_functions.py for comprehensive testing scenarios.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random
import math

class TestMoneyFlowIndex(unittest.TestCase):
    """Test cases for money_flow_index function."""
    
    def setUp(self):
        """Set up test data."""
        self.prices = [100.0 + random.gauss(0, 5) for _ in range(50)]
        self.ohlc_data = []
        for i, p in enumerate(self.prices):
            if i == 0:
                open_price = p
            else:
                open_price = self.prices[i-1]
            high = p + abs(random.gauss(0, 2))
            low = p - abs(random.gauss(0, 2))
            close = p
            self.ohlc_data.append((open_price, high, low, close))
        
        self.volumes = [1000000 + random.randint(-200000, 500000) for _ in range(50)]
        self.edges = [(0, 1), (1, 2), (2, 3), (3, 0), (1, 3)]
        self.graph = tlm.Graph(self.edges)
    
    def test_money_flow_index_basic(self):
        """Test money_flow_index with basic inputs."""
        # This test is based on successful testing in test_all_remaining_functions.py
        
        result = tlm.money_flow_index(self.ohlc_data, self.volumes)
        self.assertIsInstance(result, list)

if __name__ == "__main__":
    unittest.main(verbosity=2)
