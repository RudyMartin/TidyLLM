#!/usr/bin/env python3
"""
Test file for black_litterman function.

This function has been verified to work correctly.
See test_all_remaining_functions.py for comprehensive testing scenarios.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random
import math

class TestBlackLitterman(unittest.TestCase):
    """Test cases for black_litterman function."""
    
    def setUp(self):
        """Set up test data."""
        self.prices = [100.0 + random.gauss(0, 5) for _ in range(50)]
        self.ohlc_data = []
        for i, p in enumerate(self.prices):
            if i == 0:
                open_price = p
            else:
                open_price = self.prices[i-1]
            high = p + abs(random.gauss(0, 2))
            low = p - abs(random.gauss(0, 2))
            close = p
            self.ohlc_data.append((open_price, high, low, close))
        
        self.volumes = [1000000 + random.randint(-200000, 500000) for _ in range(50)]
        self.edges = [(0, 1), (1, 2), (2, 3), (3, 0), (1, 3)]
        self.graph = tlm.Graph(self.edges)
    
    def test_black_litterman_basic(self):
        """Test black_litterman with basic inputs."""
        # This test is based on successful testing in test_all_remaining_functions.py
        
        try:
            market_caps = [1e9, 2e9, 3e9]
            expected_returns = [0.08, 0.10, 0.12]
            views = {0: (0.09, 0.8), 1: (0.11, 0.7)}
            result = tlm.black_litterman(market_caps, expected_returns, views)
            self.assertIsInstance(result, list)
            
        except Exception as e:
            self.fail(f"black_litterman failed with error: {e}")

if __name__ == "__main__":
    unittest.main(verbosity=2)
