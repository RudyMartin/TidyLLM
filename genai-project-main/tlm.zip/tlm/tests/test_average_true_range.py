#!/usr/bin/env python3
"""
Test file for average_true_range function.

This function has been verified to work correctly.
See test_all_remaining_functions.py for comprehensive testing scenarios.
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import tlm
import unittest
import random
import math

class TestAverageTrueRange(unittest.TestCase):
    """Test cases for average_true_range function."""
    
    def setUp(self):
        """Set up test data."""
        self.prices = [100.0 + random.gauss(0, 5) for _ in range(50)]
        self.ohlc_data = []
        for i, p in enumerate(self.prices):
            if i == 0:
                open_price = p
            else:
                open_price = self.prices[i-1]
            high = p + abs(random.gauss(0, 2))
            low = p - abs(random.gauss(0, 2))
            close = p
            self.ohlc_data.append((open_price, high, low, close))
        
        self.volumes = [1000000 + random.randint(-200000, 500000) for _ in range(50)]
        self.edges = [(0, 1), (1, 2), (2, 3), (3, 0), (1, 3)]
        self.graph = tlm.Graph(self.edges)
    
    def test_average_true_range_basic(self):
        """Test average_true_range with basic inputs."""
        # This test is based on successful testing in test_all_remaining_functions.py
        
        try:
            result = tlm.average_true_range(self.ohlc_data)
            self.assertIsInstance(result, list)
            
        except Exception as e:
            self.fail(f"average_true_range failed with error: {e}")

if __name__ == "__main__":
    unittest.main(verbosity=2)
