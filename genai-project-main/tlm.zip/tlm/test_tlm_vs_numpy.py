#!/usr/bin/env python3
"""
TLM vs NumPy Comparison Test Suite

Comprehensive comparison between TLM (pure Python) and NumPy implementations
to validate correctness, accuracy, and compatibility.
"""

import time
import math
from typing import List, Tuple, Any

# Import TLM
import tlm
from tlm.pure.ops import (
    shape, array, zeros, ones, eye, 
    add, sub, mul, div, 
    asum, mean, var, std,
    transpose, dot, matmul,
    flatten, reshape, concatenate,
    median, percentile, correlation,
    cosine_similarity, euclidean_distance
)

# Import NumPy for comparison
try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    print("WARNING: NumPy not available. Install with: pip install numpy")
    HAS_NUMPY = False
    exit(1)


def compare_values(tlm_result, numpy_result, name: str, tolerance: float = 1e-10) -> bool:
    """Compare TLM and NumPy results with tolerance."""
    try:
        # Convert to numpy for easy comparison
        if isinstance(tlm_result, list):
            tlm_array = np.array(tlm_result, dtype=float)
        else:
            tlm_array = np.array(tlm_result, dtype=float)
            
        numpy_array = np.array(numpy_result, dtype=float)
        
        # Check shapes match
        if tlm_array.shape != numpy_array.shape:
            print(f"FAIL {name}: Shape mismatch - TLM: {tlm_array.shape}, NumPy: {numpy_array.shape}")
            return False
        
        # Check values with tolerance
        if np.allclose(tlm_array, numpy_array, rtol=tolerance, atol=tolerance):
            print(f"PASS {name}: Values match within tolerance {tolerance}")
            return True
        else:
            max_diff = np.max(np.abs(tlm_array - numpy_array))
            print(f"FAIL {name}: Values differ - Max difference: {max_diff}")
            print(f"   TLM: {tlm_result}")
            print(f"   NumPy: {numpy_result}")
            return False
            
    except Exception as e:
        print(f"ERROR {name}: Comparison failed - {e}")
        return False


def benchmark_function(func, *args, name: str, runs: int = 1000) -> Tuple[Any, float]:
    """Benchmark a function and return result + time."""
    # Warmup
    result = func(*args)
    
    # Time multiple runs
    start_time = time.perf_counter()
    for _ in range(runs):
        result = func(*args)
    end_time = time.perf_counter()
    
    avg_time = (end_time - start_time) / runs * 1000  # Convert to milliseconds
    return result, avg_time


def test_basic_operations():
    """Test basic arithmetic operations."""
    print("\n=== Testing Basic Operations ===")
    
    # Test data
    scalar = 5
    vector = [1, 2, 3, 4, 5]
    matrix = [[1, 2], [3, 4]]
    
    tests_passed = 0
    total_tests = 0
    
    # Scalar operations
    total_tests += 1
    tlm_result = add(scalar, 3)
    numpy_result = np.add(scalar, 3)
    if compare_values(tlm_result, numpy_result, "add(scalar, scalar)"):
        tests_passed += 1
    
    # Vector operations
    total_tests += 1
    tlm_result = add(vector, 2)
    numpy_result = np.add(vector, 2)
    if compare_values(tlm_result, numpy_result, "add(vector, scalar)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = mul(vector, [2, 2, 2, 2, 2])
    numpy_result = np.multiply(vector, [2, 2, 2, 2, 2])
    if compare_values(tlm_result, numpy_result, "mul(vector, vector)"):
        tests_passed += 1
    
    # Matrix operations
    total_tests += 1
    tlm_result = add(matrix, 1)
    numpy_result = np.add(matrix, 1)
    if compare_values(tlm_result, numpy_result, "add(matrix, scalar)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = sub(matrix, [[1, 1], [1, 1]])
    numpy_result = np.subtract(matrix, [[1, 1], [1, 1]])
    if compare_values(tlm_result, numpy_result, "sub(matrix, matrix)"):
        tests_passed += 1
    
    print(f"\nBasic Operations: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def test_reductions():
    """Test reduction operations."""
    print("\n=== Testing Reduction Operations ===")
    
    vector = [1, 2, 3, 4, 5]
    matrix = [[1, 2, 3], [4, 5, 6]]
    
    tests_passed = 0
    total_tests = 0
    
    # Sum operations
    total_tests += 1
    tlm_result = asum(vector)
    numpy_result = np.sum(vector)
    if compare_values(tlm_result, numpy_result, "sum(vector)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = asum(matrix)
    numpy_result = np.sum(matrix)
    if compare_values(tlm_result, numpy_result, "sum(matrix)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = asum(matrix, axis=0)
    numpy_result = np.sum(matrix, axis=0)
    if compare_values(tlm_result, numpy_result, "sum(matrix, axis=0)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = asum(matrix, axis=1)
    numpy_result = np.sum(matrix, axis=1)
    if compare_values(tlm_result, numpy_result, "sum(matrix, axis=1)"):
        tests_passed += 1
    
    # Mean operations
    total_tests += 1
    tlm_result = mean(vector)
    numpy_result = np.mean(vector)
    if compare_values(tlm_result, numpy_result, "mean(vector)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = mean(matrix)
    numpy_result = np.mean(matrix)
    if compare_values(tlm_result, numpy_result, "mean(matrix)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = mean(matrix, axis=0)
    numpy_result = np.mean(matrix, axis=0)
    if compare_values(tlm_result, numpy_result, "mean(matrix, axis=0)"):
        tests_passed += 1
    
    # Variance and standard deviation
    total_tests += 1
    tlm_result = var(vector, ddof=0)
    numpy_result = np.var(vector, ddof=0)
    if compare_values(tlm_result, numpy_result, "var(vector)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = std(vector, ddof=0)
    numpy_result = np.std(vector, ddof=0)
    if compare_values(tlm_result, numpy_result, "std(vector)"):
        tests_passed += 1
    
    print(f"\nReduction Operations: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def test_linear_algebra():
    """Test linear algebra operations."""
    print("\n=== Testing Linear Algebra ===")
    
    matrix_a = [[1, 2], [3, 4]]
    matrix_b = [[5, 6], [7, 8]]
    vector_a = [1, 2, 3]
    vector_b = [4, 5, 6]
    
    tests_passed = 0
    total_tests = 0
    
    # Dot product
    total_tests += 1
    tlm_result = dot(vector_a, vector_b)
    numpy_result = np.dot(vector_a, vector_b)
    if compare_values(tlm_result, numpy_result, "dot(vector, vector)"):
        tests_passed += 1
    
    # Matrix multiplication
    total_tests += 1
    tlm_result = matmul(matrix_a, matrix_b)
    numpy_result = np.matmul(matrix_a, matrix_b)
    if compare_values(tlm_result, numpy_result, "matmul(matrix, matrix)"):
        tests_passed += 1
    
    # Transpose
    total_tests += 1
    tlm_result = transpose(matrix_a)
    numpy_result = np.transpose(matrix_a)
    if compare_values(tlm_result, numpy_result, "transpose(matrix)"):
        tests_passed += 1
    
    # Identity matrix
    total_tests += 1
    tlm_result = eye(3)
    numpy_result = np.eye(3)
    if compare_values(tlm_result, numpy_result, "eye(3)"):
        tests_passed += 1
    
    print(f"\nLinear Algebra: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def test_array_creation():
    """Test array creation functions."""
    print("\n=== Testing Array Creation ===")
    
    tests_passed = 0
    total_tests = 0
    
    # Zeros
    total_tests += 1
    tlm_result = zeros(5)
    numpy_result = np.zeros(5)
    if compare_values(tlm_result, numpy_result, "zeros(5)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = zeros((3, 4))
    numpy_result = np.zeros((3, 4))
    if compare_values(tlm_result, numpy_result, "zeros((3, 4))"):
        tests_passed += 1
    
    # Ones
    total_tests += 1
    tlm_result = ones(3)
    numpy_result = np.ones(3)
    if compare_values(tlm_result, numpy_result, "ones(3)"):
        tests_passed += 1
    
    total_tests += 1
    tlm_result = ones((2, 3))
    numpy_result = np.ones((2, 3))
    if compare_values(tlm_result, numpy_result, "ones((2, 3))"):
        tests_passed += 1
    
    # Shape
    total_tests += 1
    test_matrix = [[1, 2, 3], [4, 5, 6]]
    tlm_result = shape(test_matrix)
    numpy_result = np.shape(test_matrix)
    if tlm_result == numpy_result:
        print(f"PASS shape(matrix): {tlm_result} == {numpy_result}")
        tests_passed += 1
    else:
        print(f"FAIL shape(matrix): {tlm_result} != {numpy_result}")
    
    print(f"\nArray Creation: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def test_statistical_functions():
    """Test statistical functions."""
    print("\n=== Testing Statistical Functions ===")
    
    data = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    matrix_data = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    
    tests_passed = 0
    total_tests = 0
    
    # Median
    total_tests += 1
    tlm_result = median(data)
    numpy_result = np.median(data)
    if compare_values(tlm_result, numpy_result, "median(data)"):
        tests_passed += 1
    
    # Percentile
    total_tests += 1
    tlm_result = percentile(data, 75)
    numpy_result = np.percentile(data, 75)
    if compare_values(tlm_result, numpy_result, "percentile(data, 75)"):
        tests_passed += 1
    
    # Correlation
    total_tests += 1
    x = [1, 2, 3, 4, 5]
    y = [2, 4, 1, 3, 5]
    tlm_result = correlation(x, y)
    numpy_result = np.corrcoef(x, y)[0, 1]
    if compare_values(tlm_result, numpy_result, "correlation(x, y)"):
        tests_passed += 1
    
    print(f"\nStatistical Functions: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def test_distance_functions():
    """Test distance and similarity functions."""
    print("\n=== Testing Distance Functions ===")
    
    vec_a = [1, 2, 3, 4]
    vec_b = [2, 3, 4, 5]
    
    tests_passed = 0
    total_tests = 0
    
    # Euclidean distance
    total_tests += 1
    tlm_result = euclidean_distance(vec_a, vec_b)
    numpy_result = np.linalg.norm(np.array(vec_a) - np.array(vec_b))
    if compare_values(tlm_result, numpy_result, "euclidean_distance"):
        tests_passed += 1
    
    # Cosine similarity
    total_tests += 1
    tlm_result = cosine_similarity(vec_a, vec_b)
    # NumPy doesn't have cosine_similarity, compute manually
    a, b = np.array(vec_a), np.array(vec_b)
    numpy_result = np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    if compare_values(tlm_result, numpy_result, "cosine_similarity"):
        tests_passed += 1
    
    print(f"\nDistance Functions: {tests_passed}/{total_tests} tests passed")
    return tests_passed, total_tests


def performance_comparison():
    """Compare performance of key operations."""
    print("\n=== Performance Comparison ===")
    
    # Test data
    large_vector = list(range(1000))
    large_matrix = [[i + j for j in range(100)] for i in range(100)]
    
    print(f"Testing with vector size: {len(large_vector)}")
    print(f"Testing with matrix size: {len(large_matrix)}x{len(large_matrix[0])}")
    
    # Vector sum
    tlm_result, tlm_time = benchmark_function(asum, large_vector, name="TLM sum", runs=100)
    numpy_result, numpy_time = benchmark_function(np.sum, large_vector, name="NumPy sum", runs=100)
    
    print(f"\nVector Sum (1000 elements, 100 runs):")
    print(f"  TLM:   {tlm_time:.3f}ms")
    print(f"  NumPy: {numpy_time:.3f}ms")
    print(f"  Ratio: {tlm_time/numpy_time:.1f}x slower")
    
    # Matrix mean
    tlm_result, tlm_time = benchmark_function(mean, large_matrix, name="TLM mean", runs=10)
    numpy_result, numpy_time = benchmark_function(np.mean, large_matrix, name="NumPy mean", runs=10)
    
    print(f"\nMatrix Mean (100x100 elements, 10 runs):")
    print(f"  TLM:   {tlm_time:.3f}ms")
    print(f"  NumPy: {numpy_time:.3f}ms")
    print(f"  Ratio: {tlm_time/numpy_time:.1f}x slower")


def main():
    """Run all comparison tests."""
    print("TLM vs NumPy Comprehensive Comparison")
    print("====================================")
    
    if not HAS_NUMPY:
        return
    
    total_passed = 0
    total_tests = 0
    
    # Run all test suites
    passed, tests = test_basic_operations()
    total_passed += passed
    total_tests += tests
    
    passed, tests = test_reductions()
    total_passed += passed
    total_tests += tests
    
    passed, tests = test_linear_algebra()
    total_passed += passed
    total_tests += tests
    
    passed, tests = test_array_creation()
    total_passed += passed
    total_tests += tests
    
    passed, tests = test_statistical_functions()
    total_passed += passed
    total_tests += tests
    
    passed, tests = test_distance_functions()
    total_passed += passed
    total_tests += tests
    
    # Performance comparison
    performance_comparison()
    
    # Final summary
    print(f"\n{'='*50}")
    print(f"FINAL RESULTS: {total_passed}/{total_tests} tests passed")
    print(f"Success Rate: {100*total_passed/total_tests:.1f}%")
    
    if total_passed == total_tests:
        print("SUCCESS: All tests passed! TLM is fully compatible with NumPy.")
    else:
        print("WARNING: Some tests failed. Check output above for details.")
    
    return total_passed == total_tests


if __name__ == "__main__":
    main()