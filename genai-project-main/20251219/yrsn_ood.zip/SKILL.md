# SKILL.md: YRSN Robotics
## Context Engineering for Physical AI Systems

---

## Overview

This skill enables YRSN context engineering for robotics applications. It adds:
- **Temporal penalty (T)**: Staleness, deadline pressure, timing drift
- **Physical penalty (P)**: Sim-real gap, kinematic errors, grounding failures
- **10 robotics-specific collapses**: Safety-critical failure detection
- **Domain-aware routing**: REAL_TIME → EMERGENCY_STOP tiers

---

## When to Use This Skill

✅ **Use robotics backend when:**
- Processing sensor data for robot decisions
- Validating sim-to-real transfer
- Implementing safety-critical pipelines
- Coordinating multi-robot systems
- Building human-robot interaction
- Working with real-time constraints

❌ **Don't use when:**
- Pure text/document analysis (use `heuristic` or `tfidf`)
- Quantum computing workflows (use `quantum_full`)
- No physical/temporal constraints exist

---

## Quick Start

### 1. Basic Sensor Assessment

```python
from yrsn_tools import YRSN

def assess_sensor(sensor_data: dict) -> dict:
    """Assess sensor data quality for robot decision-making."""
    
    y = YRSN(
        content=str(sensor_data),
        backend="robotics",
        omega=0.85,  # Sensor reliability
        domain_config={
            "deadline_ms": 100,
            "current_time_ms": sensor_data.get("age_ms", 0),
            "safety_critical": True,
        }
    )
    
    return {
        "quality": y.quality,
        "safe_to_act": y.gate_safe(0.7),
        "routing": y.route().tier.value,
        "temperature": y.temperature_extended,
        "collapses": [c.type.name for c in y.collapses],
    }

# Usage
result = assess_sensor({"lidar_ranges": [1.2, 1.5, 0.8], "age_ms": 15})
if result["safe_to_act"]:
    execute_motion()
```

### 2. Safety-Gated Action Pipeline

```python
from yrsn_tools import YRSN
from enum import Enum

class RobotAction(Enum):
    PROCEED = "proceed"
    VERIFY = "verify"  
    HUMAN_CHECK = "human_check"
    STOP = "stop"

def safety_gate(perception: dict, action: str, human_nearby: bool = False) -> RobotAction:
    """Gate robot actions through YRSN safety analysis."""
    
    y = YRSN(
        content=f"Perception: {perception}\nPlanned: {action}",
        backend="robotics",
        domain_config={
            "safety_critical": True,
            "human_nearby": human_nearby,
        }
    )
    
    # Critical collapse = immediate stop
    if y.critical_collapses:
        return RobotAction.STOP
    
    # Route by temperature
    tau = y.temperature_extended
    if tau < 1.5:
        return RobotAction.PROCEED
    elif tau < 2.0:
        return RobotAction.VERIFY
    elif tau < 3.0:
        return RobotAction.HUMAN_CHECK
    else:
        return RobotAction.STOP
```

### 3. Sim-to-Real Validation

```python
from yrsn_tools import YRSN
from yrsn_tools.collapses import RoboticsCollapse

def validate_sim_real(sim_obs: dict, real_obs: dict) -> dict:
    """Detect sim-to-real gap using YRSN."""
    
    y_sim = YRSN(
        content=str(sim_obs),
        backend="robotics",
        omega=0.60,  # Sim-only reliability
        domain_config={"sim_source": True, "real_validated": False}
    )
    
    y_real = YRSN(
        content=str(real_obs),
        backend="robotics",
        omega=0.90,  # Real sensor reliability
        domain_config={"sim_source": False, "real_validated": True}
    )
    
    # Check for SIM_REAL_GAP collapse
    gap_detected = any(
        c.type == RoboticsCollapse.SIM_REAL_GAP 
        for c in y_sim.collapses + y_real.collapses
    )
    
    # Physical penalty difference indicates gap
    p_diff = abs(y_sim.P - y_real.P)
    
    return {
        "gap_detected": gap_detected or p_diff > 0.15,
        "gap_magnitude": p_diff,
        "recommendation": "retrain" if p_diff > 0.3 else "fine_tune" if p_diff > 0.15 else "proceed"
    }
```

---

## Domain Config Reference

```python
domain_config = {
    # === TEMPORAL ===
    "deadline_ms": 100,        # Hard deadline in milliseconds
    "current_time_ms": 50,     # Elapsed time
    "data_age_ms": 20,         # Age of sensor data
    "real_time": True,         # Enable temporal collapses
    
    # === PHYSICAL ===
    "sim_source": False,       # Data from simulation?
    "real_validated": True,    # Validated against real world?
    "check_kinematics": True,  # Enable kinematic checks
    "joint_limits": {...},     # Robot joint limits
    "velocity_limits": {...},  # Motion limits
    
    # === SAFETY ===
    "safety_critical": True,   # Enable safety collapses
    "human_nearby": False,     # Human in workspace?
    "collision_threshold": 0.5, # Meters
    
    # === MULTI-AGENT ===
    "multi_agent": False,      # Multiple robots?
    "agent_id": "robot_1",     # This agent's ID
    "shared_context": {...},   # Shared state
}
```

---

## OOD Detection (Critical Component)

**OOD (Out-of-Distribution) is not optional** - it's the foundation of ω reliability. The robotics backend automatically detects multiple OOD sources:

### Robotics OOD Types

| OOD Type | What It Detects | Impact on ω |
|----------|-----------------|-------------|
| O_sensor | Readings outside calibration range | High |
| O_env | Novel environment not in training | High |
| O_kinematic | Unseen joint configurations | Medium |
| O_sim_real | Sim-to-real distribution shift | Very High |
| O_dynamics | Changed physical behavior | Very High |
| O_policy | State outside policy training data | High |

### Using OOD Detection

```python
from yrsn_tools import YRSN

y = YRSN(
    content=sensor_data,
    backend="robotics",
    # omega is DERIVED from OOD, not set manually
    domain_config={"safety_critical": True}
)

# Access OOD information
print(f"OOD score: {y.O}")        # 0 = in-distribution, 1 = OOD
print(f"Reliability: {y.omega}")  # Derived: 1 - O
print(f"Is OOD: {y.is_ood}")      # True if O > 0.5
print(f"Severity: {y.ood_severity}")  # "in_distribution", "moderate_ood", etc.

# OOD affects routing
if y.is_ood:
    print("⚠️ Context is out-of-distribution - using conservative routing")
```

### OOD-Triggered Collapses

```python
from yrsn_tools.collapses import RoboticsCollapse

# New OOD-specific collapses
RoboticsCollapse.SENSOR_OOD        # Sensor reading outside calibration
RoboticsCollapse.ENVIRONMENT_OOD  # Novel environment (critical)
RoboticsCollapse.DYNAMICS_OOD     # Unexpected physical behavior (critical)
RoboticsCollapse.POLICY_OOD       # State outside policy training data
```

### Custom OOD Detector

```python
from yrsn_tools import YRSN
from yrsn_tools.ood import RoboticsOODDetector

# Create custom detector with your calibration data
detector = RoboticsOODDetector(
    calibration_data={
        "sensor_ranges": {
            "lidar": (0.1, 30.0),
            "joint_1": (-3.14, 3.14),
        },
        "environment_embeddings": env_embeddings,
        "kinematic_bounds": (lower_limits, upper_limits),
    }
)

y = YRSN(
    content=sensor_data,
    backend="robotics",
    ood_detector=detector,  # Use custom detector
)
```

---

## ω Calibration Table

**Note:** These are **maximum ω values** when context is in-distribution. Actual ω = min(table_value, 1 - O).

| Source Type | ω_max | Notes |
|-------------|---------|-------|
| **High Confidence** |||
| motion_capture | 0.98 | Gold standard |
| lidar_calibrated | 0.95 | After calibration |
| encoder_absolute | 0.95 | Absolute encoders |
| **Medium Confidence** |||
| camera_rgb | 0.85 | Good lighting |
| imu_fused | 0.85 | Sensor fusion |
| depth_camera | 0.80 | Structured light/ToF |
| gps_rtk | 0.90 | RTK correction |
| **Lower Confidence** |||
| ultrasonic | 0.70 | Environment dependent |
| tactile | 0.75 | Contact sensors |
| wifi_rssi | 0.50 | High variance |
| **Simulation** |||
| sim_perfect | 0.99 | No noise model |
| sim_noisy | 0.85 | Realistic noise |
| sim_domain_random | 0.70 | Domain randomization |
| **Human/Computed** |||
| operator_command | 0.90 | Direct command |
| gesture_recognition | 0.65 | Vision-based |
| speech_command | 0.60 | ASR output |
| slam_map | 0.80 | Localization |
| object_detection | 0.75 | ML inference |
| llm_reasoning | 0.60 | Language model |

```python
# Helper function
def get_omega(source_type: str) -> float:
    """Get calibrated omega for source type."""
    table = {
        "lidar_calibrated": 0.95,
        "camera_rgb": 0.85,
        # ... etc
    }
    return table.get(source_type, 0.70)
```

---

## Collapse Types (10)

### Temporal Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| TEMPORAL_MISALIGNMENT | data_age > threshold | Warning | `data_age_ms > max_age_ms` |
| DEADLINE_VIOLATION | elapsed > deadline | Critical | `current_time_ms > deadline_ms` |
| ACCUMULATION_DRIFT | cumulative timing error | Warning | Drift exceeds tolerance |

### Physical Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| SIM_REAL_GAP | sim ≠ real behavior | Critical | P_sim vs P_real divergence |
| GROUNDING_FAILURE | invalid physical ref | Critical | Reference outside bounds |
| KINEMATIC_VIOLATION | impossible motion | Critical | Exceeds joint/velocity limits |

### Multi-Agent Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| COORDINATION_BREAKDOWN | agent desync | Critical | State divergence > threshold |
| SHARED_CONTEXT_DIVERGENCE | inconsistent state | Warning | Context hash mismatch |

### Human-Robot Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| TRUST_EROSION | repeated failures | Warning | Trust score degradation |
| INTENT_MISINTERPRETATION | misread human | Critical | Low intent confidence |

---

## Routing Tiers

```python
decision = y.route()
print(decision.tier)  # RoutingTier enum
```

| τ Range | Tier | Action |
|---------|------|--------|
| < 1.5 | `REAL_TIME` | Execute immediately |
| 1.5-2.0 | `SAFETY_CHECK` | Verify then execute |
| 2.0-3.0 | `HUMAN_REVIEW` | Request confirmation |
| ≥ 3.0 | `EMERGENCY_STOP` | Halt all motion |
| Any critical collapse | `EMERGENCY_STOP` | Immediate halt |

---

## Common Patterns

### Pattern 1: Real-Time Loop

```python
from yrsn_tools import YRSN
import time

class RealTimeController:
    def __init__(self, deadline_ms: float):
        self.deadline_ms = deadline_ms
        
    def control_loop(self, get_sensor, execute_action):
        while True:
            start = time.time() * 1000
            sensor_data = get_sensor()
            
            y = YRSN(
                content=str(sensor_data),
                backend="robotics",
                domain_config={
                    "deadline_ms": self.deadline_ms,
                    "current_time_ms": time.time() * 1000 - start,
                    "safety_critical": True,
                }
            )
            
            if y.critical_collapses:
                execute_action("STOP")
                break
            elif y.gate_safe(0.7):
                execute_action(self.compute_action(sensor_data))
            else:
                execute_action("HOLD")
```

### Pattern 2: Multi-Robot Coordination

```python
def check_fleet_coordination(robot_states: list, shared_goal: str) -> dict:
    """Check multi-robot coordination health."""
    
    results = []
    for i, state in enumerate(robot_states):
        y = YRSN(
            content=str(state),
            query=shared_goal,
            backend="robotics",
            domain_config={"multi_agent": True, "agent_id": f"robot_{i}"}
        )
        results.append(y)
    
    # Check divergence
    qualities = [y.quality for y in results]
    divergence = max(qualities) - min(qualities)
    
    # Collect coordination issues
    issues = []
    for i, y in enumerate(results):
        for c in y.collapses:
            if "COORDINATION" in c.type.name or "SHARED" in c.type.name:
                issues.append({"robot": i, "collapse": c.type.name})
    
    return {
        "coordinated": len(issues) == 0 and divergence < 0.2,
        "divergence": divergence,
        "issues": issues,
    }
```

### Pattern 3: Human Intent Verification

```python
def verify_human_intent(gesture: str, context: str, confidence: float) -> dict:
    """Verify detected human intent before acting."""
    
    y = YRSN(
        content=f"Gesture: {gesture}\nContext: {context}",
        query="What action does the human want?",
        backend="robotics",
        omega=confidence,  # Use detection confidence
        domain_config={
            "human_interaction": True,
            "safety_critical": True,
        }
    )
    
    return {
        "intent_clear": y.quality > 0.7 and not y.critical_collapses,
        "should_confirm": y.quality < 0.8,
        "routing": y.route().tier.value,
    }
```

---

## ROS2 Integration

```python
# yrsn_safety_node.py
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String
from yrsn_tools import YRSN

class YRSNSafetyNode(Node):
    def __init__(self):
        super().__init__('yrsn_safety')
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_cb, 10)
        self.status_pub = self.create_publisher(
            String, '/yrsn/status', 10)
        
    def scan_cb(self, msg):
        y = YRSN(
            content=str(list(msg.ranges[:20])),
            backend="robotics",
            omega=0.85,
            domain_config={"safety_critical": True}
        )
        
        status = String()
        if y.critical_collapses:
            status.data = "STOP"
        elif y.gate_safe(0.7):
            status.data = "SAFE"
        else:
            status.data = "CAUTION"
        self.status_pub.publish(status)

def main():
    rclpy.init()
    node = YRSNSafetyNode()
    rclpy.spin(node)
```

---

## Troubleshooting

| Issue | Likely Cause | Solution |
|-------|--------------|----------|
| High T penalty | Stale data | Reduce latency, increase sensor rate |
| High P penalty | Sim-real gap | Domain randomization, real validation |
| DEADLINE_VIOLATION | Slow compute | Edge compute, reduce model size |
| KINEMATIC_VIOLATION | Bad planning | Add constraint checking to planner |
| COORDINATION_BREAKDOWN | Network | Improve comms, add redundancy |
| False INTENT_MISINTERPRETATION | Low ω | Calibrate gesture recognition ω |

---

## Best Practices

1. **Always set `safety_critical=True`** for physical robots
2. **Calibrate ω per sensor** using the lookup table
3. **Monitor T in real-time loops** - temporal collapses are early warnings
4. **Gate actions at τ < 2.0** for human-safe operation
5. **Log all collapses** for post-incident analysis
6. **Validate sim→real** before any deployment
7. **Use `gate_safe()` not `gate()`** for safety-critical decisions

---

## Dependencies

```bash
pip install yrsn-tools[robotics]

# Optional: ROS2 integration
pip install rclpy
```

---

## Version

YRSN Robotics Skill v1.0
Compatible with yrsn-tools >= 2.0.0
