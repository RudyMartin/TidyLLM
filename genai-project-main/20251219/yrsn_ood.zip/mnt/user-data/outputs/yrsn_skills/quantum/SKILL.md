# SKILL.md: YRSN Quantum
## Context Engineering for Quantum Computing Workflows

---

## Overview

This skill enables YRSN context engineering for quantum computing applications. It adds:
- **Quantum penalty (Q)**: Decoherence, gate errors, trainability issues
- **Hybrid penalty (H)**: Interface overhead, encoding loss, decoding latency
- **15 quantum-specific collapses**: Circuit reliability detection
- **Domain-aware routing**: QUANTUM_FULL → CLASSICAL_FALLBACK tiers

---

## When to Use This Skill

✅ **Use quantum_full backend when:**
- Running variational quantum algorithms (VQA, VQE, QAOA)
- Assessing circuit reliability before execution
- Deciding quantum vs classical execution path
- Monitoring hybrid quantum-classical workflows
- Detecting barren plateaus in training
- Evaluating error mitigation needs

❌ **Don't use when:**
- Pure classical computation (use standard backends)
- Robotics applications (use `robotics` backend)
- Just need quantum kernel similarity (use `quantum` backend)

---

## Quick Start

### 1. Basic Circuit Assessment

```python
from yrsn_tools import YRSN

def assess_circuit(circuit_result: dict, hardware_specs: dict) -> dict:
    """Assess quantum circuit output quality."""
    
    y = YRSN(
        content=str(circuit_result),
        backend="quantum_full",
        omega=0.85,  # Measurement reliability
        domain_config={
            "n_qubits": hardware_specs["n_qubits"],
            "circuit_depth": hardware_specs["depth"],
            "t1_us": hardware_specs.get("t1", 100),
            "t2_us": hardware_specs.get("t2", 80),
            "gate_error": hardware_specs.get("gate_error", 0.001),
            "shots": circuit_result.get("shots", 1024),
        }
    )
    
    return {
        "quality": y.quality,
        "fidelity": y.fidelity,
        "routing": y.route().tier.value,
        "temperature": y.temperature_extended,
        "collapses": [c.type.name for c in y.collapses],
        "needs_mitigation": y.temperature_extended > 1.3,
    }
```

### 2. Quantum vs Classical Routing

```python
from yrsn_tools import YRSN
from enum import Enum

class ExecutionPath(Enum):
    QUANTUM_FULL = "quantum_full"
    QUANTUM_MITIGATED = "quantum_mitigated"
    HYBRID_SPLIT = "hybrid_split"
    CLASSICAL_FALLBACK = "classical_fallback"
    ABORT = "abort"

def route_execution(problem: dict, hardware: dict) -> ExecutionPath:
    """Decide optimal execution path using YRSN."""
    
    y = YRSN(
        content=str(problem),
        backend="quantum_full",
        domain_config={
            "n_qubits": hardware["n_qubits"],
            "circuit_depth": problem.get("estimated_depth", 50),
            "t1_us": hardware["t1"],
            "t2_us": hardware["t2"],
            "gate_error": hardware["gate_error"],
            "is_variational": problem.get("is_vqa", False),
        }
    )
    
    # Critical collapse = abort
    if y.critical_collapses:
        return ExecutionPath.ABORT
    
    # Route by temperature
    tau = y.temperature_extended
    if tau < 1.3:
        return ExecutionPath.QUANTUM_FULL
    elif tau < 1.8:
        return ExecutionPath.QUANTUM_MITIGATED
    elif tau < 2.5:
        return ExecutionPath.HYBRID_SPLIT
    else:
        return ExecutionPath.CLASSICAL_FALLBACK
```

### 3. VQA Training Monitor

```python
from yrsn_tools import YRSN
from yrsn_tools.collapses import QuantumCollapse

def monitor_vqa_training(gradient_history: list, params: dict) -> dict:
    """Monitor VQA training for barren plateaus."""
    
    # Recent gradient variance
    recent_grads = gradient_history[-10:]
    grad_variance = sum(g**2 for g in recent_grads) / len(recent_grads)
    
    y = YRSN(
        content=f"Gradients: {recent_grads}\nVariance: {grad_variance}",
        backend="quantum_full",
        domain_config={
            "n_qubits": params["n_qubits"],
            "circuit_depth": params["n_layers"],
            "is_variational": True,
            "gradient_variance": grad_variance,
        }
    )
    
    # Check for barren plateau
    barren = any(
        c.type == QuantumCollapse.BARREN_PLATEAU 
        for c in y.collapses
    )
    
    return {
        "healthy": not barren and y.quality > 0.6,
        "barren_plateau": barren,
        "gradient_variance": grad_variance,
        "recommendation": "stop_training" if barren else "continue",
        "collapses": [c.type.name for c in y.collapses],
    }
```

---

## Domain Config Reference

```python
domain_config = {
    # === HARDWARE SPECS ===
    "n_qubits": 8,             # Number of qubits
    "circuit_depth": 20,       # Circuit depth (layers)
    "t1_us": 100,              # T1 relaxation time (μs)
    "t2_us": 80,               # T2 dephasing time (μs)
    "gate_error": 0.001,       # Average gate error rate
    "readout_error": 0.02,     # Measurement error rate
    "zz_coupling": 0.0001,     # ZZ crosstalk strength
    
    # === EXECUTION ===
    "shots": 1024,             # Measurement shots
    "circuit_time_us": 5,      # Circuit execution time
    "uses_error_mitigation": False,  # ZNE, PEC, etc.
    "mitigation_type": None,   # "zne", "pec", "vd"
    
    # === ALGORITHM ===
    "is_variational": True,    # VQA/VQE/QAOA?
    "gradient_variance": None, # For barren plateau detection
    "n_parameters": 32,        # Trainable parameters
    "entanglement": "full",    # "full", "linear", "circular"
    
    # === HYBRID ===
    "classical_preprocessing": True,
    "encoding_compression": 0.5,  # Dimension reduction ratio
}
```

---

## OOD Detection (Critical Component)

**OOD (Out-of-Distribution) is not optional** - it's the foundation of ω reliability. The quantum_full backend automatically detects multiple OOD sources:

### Quantum OOD Types

| OOD Type | What It Detects | Impact on ω |
|----------|-----------------|-------------|
| O_noise | Noise profile differs from calibration | High |
| O_hamiltonian | Problem structure outside training | High |
| O_state | Target state inexpressible by ansatz | Very High |
| O_drift | Hardware parameters have drifted | Medium |
| O_ansatz | Ansatz-problem mismatch | High |

### Using OOD Detection

```python
from yrsn_tools import YRSN

y = YRSN(
    content=circuit_result,
    backend="quantum_full",
    # omega is DERIVED from OOD, not set manually
    domain_config={
        "n_qubits": 8,
        "calibration_age_hours": 2,  # For drift detection
    }
)

# Access OOD information
print(f"OOD score: {y.O}")        # 0 = in-distribution, 1 = OOD
print(f"Reliability: {y.omega}")  # Derived: 1 - O
print(f"Is OOD: {y.is_ood}")      # True if O > 0.5
print(f"Severity: {y.ood_severity}")  # "in_distribution", "moderate_ood", etc.

# OOD affects routing - high O pushes toward classical fallback
if y.is_ood:
    print("⚠️ Context is out-of-distribution - consider classical fallback")
```

### OOD-Triggered Collapses

```python
from yrsn_tools.collapses import QuantumCollapse

# New OOD-specific collapses
QuantumCollapse.NOISE_DRIFT       # Noise model outdated
QuantumCollapse.HAMILTONIAN_OOD   # Novel problem structure (critical)
QuantumCollapse.HARDWARE_DRIFT    # Device needs recalibration
QuantumCollapse.ANSATZ_MISMATCH   # Ansatz cannot express solution (critical)
```

### Hardware Drift Detection

```python
def check_hardware_drift(calibration_time: datetime) -> dict:
    """Check if hardware has drifted from calibration."""
    age_hours = (datetime.now() - calibration_time).total_seconds() / 3600
    
    y = YRSN(
        content="hardware_check",
        backend="quantum_full",
        domain_config={"calibration_age_hours": age_hours}
    )
    
    return {
        "needs_recalibration": y.O > 0.4,
        "ood_score": y.O,
        "recommendation": "recalibrate" if age_hours > 12 else "continue"
    }
```

---

## ω Calibration Table

**Note:** These are **maximum ω values** when context is in-distribution. Actual ω = min(table_value, 1 - O).

| Source Type | ω_max | Notes |
|-------------|---------|-------|
| **High Confidence** |||
| pure_state_prep | 0.99 | Ideal state preparation |
| calibrated_gate | 0.97 | Recent calibration |
| error_corrected | 0.95 | With QEC |
| **Medium Confidence** |||
| noisy_gate_output | 0.92 | NISQ hardware |
| tomography_result | 0.85 | State tomography |
| measurement_sample | 0.80 | Raw measurement |
| zne_mitigated | 0.88 | Zero-noise extrapolation |
| pec_mitigated | 0.90 | Probabilistic error cancellation |
| **Lower Confidence** |||
| vqa_optimized | 0.70 | After VQA optimization |
| classical_shadow | 0.65 | Shadow estimation |
| vd_mitigated | 0.75 | Virtual distillation |
| **Classical** |||
| tensor_network | 0.60 | Classical simulation |
| classical_prediction | 0.50 | Heuristic estimate |

```python
# Helper function
def get_quantum_omega(source_type: str) -> float:
    """Get calibrated omega for quantum source type."""
    table = {
        "pure_state_prep": 0.99,
        "noisy_gate_output": 0.92,
        "measurement_sample": 0.80,
        "vqa_optimized": 0.70,
        # ... etc
    }
    return table.get(source_type, 0.70)
```

---

## Collapse Types (15)

### Decoherence Domain

| Collapse | Trigger | Severity | Formula |
|----------|---------|----------|---------|
| T1_RELAXATION | Amplitude decay | Warning | `P = 1 - exp(-t/T1)` |
| T2_DEPHASING | Phase randomization | Warning | `P = 1 - exp(-t/T2)` |
| LEAKAGE | Non-computational states | Critical | `P ∝ (Ω/α)²` |

### Gate Error Domain

| Collapse | Trigger | Severity | Channel |
|----------|---------|----------|---------|
| BIT_FLIP | X error accumulation | Warning | `ρ → (1-p)ρ + pXρX` |
| PHASE_FLIP | Z error accumulation | Warning | `ρ → (1-p)ρ + pZρZ` |
| DEPOLARIZING | Complete randomization | Critical | Pauli mixture |

### Measurement Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| SHOT_NOISE | Insufficient shots | Warning | `σ > threshold` |
| READOUT_ERROR | Misclassification | Warning | Confusion matrix |
| COLLAPSE_BIAS | Systematic bias | Warning | Chi-squared test |

### Crosstalk Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| ZZ_COUPLING | Parasitic interaction | Warning | Phase accumulation |
| SPECTATOR_LEAKAGE | Neighbor affected | Warning | Frequency detuning |

### Trainability Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| BARREN_PLATEAU | Vanishing gradients | Critical | `Var(∂C/∂θ) < 2^(-n)` |
| EXPRESSIBILITY_TRAINABILITY | Tradeoff failure | Warning | Dual metric check |

### Hybrid Interface Domain

| Collapse | Trigger | Severity | Detection |
|----------|---------|----------|-----------|
| INTERFACE_BOTTLENECK | Encoding loss | Warning | Compression ratio |
| DECODING_LATENCY | QEC too slow | Critical | `decode_time > cycle` |

---

## Routing Tiers

```python
decision = y.route()
print(decision.tier)  # RoutingTier enum
```

| τ Range | Tier | Action |
|---------|------|--------|
| < 1.3 | `QUANTUM_FULL` | Pure quantum execution |
| 1.3-1.8 | `QUANTUM_MITIGATED` | Apply error mitigation |
| 1.8-2.5 | `HYBRID_SPLIT` | Split quantum/classical |
| ≥ 2.5 | `CLASSICAL_FALLBACK` | Use classical approximation |
| Critical collapse | `ABORT_CIRCUIT` | Terminate immediately |

---

## Common Patterns

### Pattern 1: Pre-Execution Assessment

```python
from yrsn_tools import YRSN

def should_run_quantum(circuit_spec: dict, hardware: dict) -> tuple:
    """Decide if circuit should run on quantum hardware."""
    
    y = YRSN(
        content=str(circuit_spec),
        backend="quantum_full",
        domain_config={
            "n_qubits": circuit_spec["n_qubits"],
            "circuit_depth": circuit_spec["depth"],
            "t1_us": hardware["t1"],
            "t2_us": hardware["t2"],
            "gate_error": hardware["error_rate"],
        }
    )
    
    tier = y.route().tier.value
    run_quantum = tier in ["QUANTUM_FULL", "QUANTUM_MITIGATED"]
    mitigation = tier == "QUANTUM_MITIGATED"
    
    return run_quantum, mitigation, y.collapses
```

### Pattern 2: Error Mitigation Selection

```python
from yrsn_tools import YRSN
from yrsn_tools.collapses import QuantumCollapse

def select_mitigation(circuit_result: dict, hardware: dict) -> str:
    """Select appropriate error mitigation technique."""
    
    y = YRSN(
        content=str(circuit_result),
        backend="quantum_full",
        domain_config=hardware
    )
    
    # Analyze collapse types
    collapse_types = {c.type for c in y.collapses}
    
    # Mitigation selection logic
    if QuantumCollapse.DEPOLARIZING in collapse_types:
        return "pec"  # Probabilistic error cancellation
    elif QuantumCollapse.T1_RELAXATION in collapse_types:
        return "zne"  # Zero-noise extrapolation
    elif QuantumCollapse.READOUT_ERROR in collapse_types:
        return "readout_correction"  # Matrix inversion
    elif y.temperature_extended > 1.5:
        return "zne"  # Default to ZNE
    else:
        return "none"
```

### Pattern 3: Hybrid Circuit Partitioning

```python
from yrsn_tools import YRSN

def partition_circuit(full_circuit: dict, hardware: dict) -> dict:
    """Partition circuit into quantum and classical parts."""
    
    y = YRSN(
        content=str(full_circuit),
        backend="quantum_full",
        domain_config={
            **hardware,
            "circuit_depth": full_circuit["total_depth"],
        }
    )
    
    tier = y.route().tier.value
    
    if tier == "QUANTUM_FULL":
        return {"quantum": full_circuit, "classical": None}
    elif tier == "HYBRID_SPLIT":
        # Use temperature to estimate split point
        tau = y.temperature_extended
        quantum_fraction = 2.5 / tau  # Higher tau = less quantum
        
        split_depth = int(full_circuit["total_depth"] * quantum_fraction)
        return {
            "quantum": {"depth": split_depth},
            "classical": {"depth": full_circuit["total_depth"] - split_depth},
        }
    else:
        return {"quantum": None, "classical": full_circuit}
```

### Pattern 4: Shot Budget Optimization

```python
from yrsn_tools import YRSN
from yrsn_tools.collapses import QuantumCollapse

def optimize_shots(target_precision: float, circuit: dict, hardware: dict) -> int:
    """Calculate optimal shot count for target precision."""
    
    base_shots = 1024
    
    y = YRSN(
        content=str(circuit),
        backend="quantum_full",
        domain_config={**hardware, "shots": base_shots}
    )
    
    # Check for shot noise collapse
    shot_noise = any(
        c.type == QuantumCollapse.SHOT_NOISE 
        for c in y.collapses
    )
    
    if shot_noise:
        # Increase shots (quadratic relationship with precision)
        current_precision = 1 / (base_shots ** 0.5)
        factor = (current_precision / target_precision) ** 2
        return int(base_shots * factor)
    else:
        return base_shots
```

### Pattern 5: Barren Plateau Early Warning

```python
from yrsn_tools import YRSN
from yrsn_tools.collapses import QuantumCollapse
import numpy as np

class BarrenPlateauMonitor:
    """Monitor VQA training for barren plateaus."""
    
    def __init__(self, n_qubits: int, n_layers: int):
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.grad_history = []
        self.theoretical_threshold = 2 ** (-n_qubits)
        
    def update(self, gradients: np.ndarray) -> dict:
        """Update with new gradients, check for barren plateau."""
        
        variance = np.var(gradients)
        self.grad_history.append(variance)
        
        y = YRSN(
            content=f"Gradient variance: {variance}",
            backend="quantum_full",
            domain_config={
                "n_qubits": self.n_qubits,
                "circuit_depth": self.n_layers,
                "is_variational": True,
                "gradient_variance": variance,
            }
        )
        
        barren = any(
            c.type == QuantumCollapse.BARREN_PLATEAU 
            for c in y.collapses
        )
        
        return {
            "variance": variance,
            "threshold": self.theoretical_threshold,
            "barren_plateau": barren,
            "trend": self._compute_trend(),
            "action": "stop" if barren else "continue",
        }
    
    def _compute_trend(self) -> str:
        if len(self.grad_history) < 5:
            return "insufficient_data"
        recent = self.grad_history[-5:]
        if all(recent[i] > recent[i+1] for i in range(4)):
            return "decreasing"  # Warning sign
        return "stable"
```

---

## PennyLane Integration

```python
import pennylane as qml
from yrsn_tools import YRSN

# Create device
dev = qml.device("lightning.qubit", wires=4)

@qml.qnode(dev)
def circuit(params):
    for i in range(4):
        qml.RY(params[i], wires=i)
    for i in range(3):
        qml.CNOT(wires=[i, i+1])
    return [qml.expval(qml.PauliZ(i)) for i in range(4)]

def run_with_yrsn(params):
    """Run circuit with YRSN quality assessment."""
    
    # Get circuit specs
    specs = qml.specs(circuit)(params)
    
    # Pre-execution assessment
    y = YRSN(
        content=str(specs),
        backend="quantum_full",
        domain_config={
            "n_qubits": 4,
            "circuit_depth": specs["depth"],
            "gate_error": 0.001,
            "t1_us": 100,
            "t2_us": 80,
        }
    )
    
    # Decide execution path
    tier = y.route().tier.value
    
    if tier == "ABORT_CIRCUIT":
        return None, y.collapses
    
    # Execute
    result = circuit(params)
    
    # Post-execution assessment
    y_post = YRSN(
        content=str(result),
        backend="quantum_full",
        omega=0.85,  # Measurement reliability
        domain_config={"shots": 1024}
    )
    
    return result, {
        "pre_quality": y.quality,
        "post_quality": y_post.quality,
        "tier": tier,
    }
```

---

## Qiskit Integration

```python
from qiskit import QuantumCircuit, transpile
from qiskit_ibm_runtime import QiskitRuntimeService
from yrsn_tools import YRSN

def run_on_ibm_with_yrsn(qc: QuantumCircuit, backend_name: str):
    """Run Qiskit circuit with YRSN assessment."""
    
    service = QiskitRuntimeService()
    backend = service.backend(backend_name)
    props = backend.properties()
    
    # Extract hardware specs
    hardware = {
        "n_qubits": backend.num_qubits,
        "t1_us": props.t1(0) * 1e6,  # Convert to μs
        "t2_us": props.t2(0) * 1e6,
        "gate_error": props.gate_error("cx", [0, 1]),
        "readout_error": props.readout_error(0),
    }
    
    # Transpile
    transpiled = transpile(qc, backend)
    
    # YRSN assessment
    y = YRSN(
        content=f"Circuit depth: {transpiled.depth()}, gates: {transpiled.count_ops()}",
        backend="quantum_full",
        domain_config={
            **hardware,
            "circuit_depth": transpiled.depth(),
        }
    )
    
    tier = y.route().tier.value
    
    if tier in ["QUANTUM_FULL", "QUANTUM_MITIGATED"]:
        # Run on quantum
        from qiskit_ibm_runtime import Sampler
        sampler = Sampler(backend)
        job = sampler.run([transpiled])
        return job.result(), tier, y.collapses
    else:
        # Fallback to simulator
        from qiskit_aer import AerSimulator
        sim = AerSimulator()
        job = sim.run(transpiled)
        return job.result(), tier, y.collapses
```

---

## Troubleshooting

| Issue | Likely Cause | Solution |
|-------|--------------|----------|
| High Q penalty | Deep circuit | Reduce depth, use hardware-efficient ansatz |
| High H penalty | Encoding mismatch | Better feature selection, data re-uploading |
| T1_RELAXATION | Long circuit time | Reduce depth, faster gates |
| T2_DEPHASING | Phase-sensitive ops | Dynamical decoupling |
| BARREN_PLATEAU | Expressible ansatz | Layer-wise training, local cost functions |
| SHOT_NOISE | Too few shots | Increase shots (quadratic cost) |
| DEPOLARIZING | High gate errors | Error mitigation (ZNE, PEC) |
| DECODING_LATENCY | Slow QEC | GPU decoders, simpler codes |

---

## Best Practices

1. **Assess before execution** - Always run YRSN pre-flight check
2. **Calibrate ω per measurement type** - Raw shots ≠ error mitigated
3. **Monitor gradient variance** - Early warning for barren plateaus
4. **Use routing tiers** - Don't force quantum when classical is better
5. **Track coherence ratio** - `t_circuit / T2` should be < 0.5
6. **Apply mitigation selectively** - Match technique to collapse type
7. **Partition long circuits** - Hybrid split reduces cumulative errors

---

## Dependencies

```bash
# Basic
pip install yrsn-tools[quantum]

# Fast CPU simulation
pip install pennylane pennylane-lightning

# GPU simulation
pip install pennylane pennylane-lightning-gpu

# IBM Quantum
pip install qiskit qiskit-ibm-runtime

# Full stack
pip install yrsn-tools[all] pennylane-lightning qiskit-ibm-runtime
```

---

## Quantum τ Formula Details

```python
# Standard temperature
τ_base = 1 / α_ω

# Coherence factor: how much of coherence time is used
coherence_factor = 1 + (t_circuit / T2)

# Depth factor: exponential error accumulation  
depth_factor = exp(depth × gate_error × n_qubits)

# Full quantum temperature
τ_quantum = τ_base × coherence_factor × depth_factor

# Example calculation:
# α_ω = 0.8, t_circuit = 5μs, T2 = 80μs
# depth = 20, gate_error = 0.001, n_qubits = 8

τ_base = 1 / 0.8 = 1.25
coherence_factor = 1 + (5 / 80) = 1.0625
depth_factor = exp(20 × 0.001 × 8) = exp(0.16) = 1.17

τ_quantum = 1.25 × 1.0625 × 1.17 = 1.55
# → Routes to QUANTUM_MITIGATED tier
```

---

## Version

YRSN Quantum Skill v1.0
Compatible with yrsn-tools >= 2.0.0
