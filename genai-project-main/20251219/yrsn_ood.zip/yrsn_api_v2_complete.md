# YRSN API v2.0
## Complete Reference with Domain Extensions

---

## Quick Start

```python
from yrsn_tools import YRSN

# Classic usage (unchanged)
y = YRSN("Your content here", query="optional query")

# Decomposition
y.R, y.S, y.N          # Components (0-1 each)

# Quality
y.quality              # α_ω (reliability-adjusted)
y.collapse_risk        # S + 1.5·N
y.temperature          # τ = 1/α_ω

# Actions
y.gate(0.7)            # True if quality >= 0.7
y.route()              # RoutingDecision (tier + temp)
y.explain()            # Print human-readable summary

# NEW: Domain-specific backends
y = YRSN(content, backend="robotics", domain_config={...})
y = YRSN(content, backend="quantum", n_qubits=4)
```

---

## What's New in v2.0

| Feature | v1 | v2 |
|---------|----|----|
| Base formula | `Y = R + S + N` | `Y = R + S + N + D` |
| Domain penalties | None | T, P (robotics), Q, H (quantum) |
| Collapse types | 4 | 29 total (4 + 10 + 15) |
| Backends | 5 | 7 (+ robotics, quantum) |
| Routing tiers | 3 | Domain-specific tiers |

---

## Theory (Updated)

### Core Principle: OOD Drives Reliability

The fundamental insight of YRSN is that **reliability (ω) should be derived from Out-of-Distribution (OOD) detection**, not set arbitrarily:

```
O = OOD_detect(context)     # How OOD is this context? (0-1)
ω = 1 - O                   # Reliability is inverse of OOD
α_ω = ω·α + (1-ω)·prior     # OOD-adjusted quality
```

When O is high (context is OOD), ω drops, which pulls α_ω toward the prior (0.5), increasing temperature and triggering conservative routing.

### Base Decomposition

**Classic**: `Y = R + S + N`

**Extended (v2)**: `Y = R + S + N + D`

Where **D** = Domain-specific penalty:

| Domain | D Expansion | Full Formula |
|--------|-------------|--------------|
| Classic | 0 | `Y = R + S + N` |
| Robotics | T + P | `Y = R + S + N + T + P` |
| Quantum | Q + H | `Y = R + S + N + Q + H` |
| Hybrid | T + P + Q + H | `Y = R + S + N + T + P + Q + H` |

```
Component Meanings:
───────────────────────────────────────────────────────
R = Relevant signal        (maximize)
S = Superfluous content    (accept, monitor)
N = Noise                  (eliminate)
T = Temporal penalty       (robotics: staleness, deadline pressure)
P = Physical penalty       (robotics: sim-real gap, kinematic errors)
Q = Quantum penalty        (quantum: decoherence, gate errors)
H = Hybrid penalty         (quantum: interface overhead, encoding loss)
```

### Quality Metric (α)

**Classic**: `α = R / (R + S + N)`

**Extended**: `α = R / (R + S + N + D)`

```python
# Accessing alpha
y.alpha           # Base: R / (R + S + N)
y.alpha_extended  # Extended: R / (R + S + N + D)  [NEW]
```

### Reliability Score (ω)

**Calibration by source type**:

```python
# === CLASSIC SOURCES ===
OMEGA_CLASSIC = {
    "verified_database": 0.95,
    "api_response": 0.85,
    "structured_file": 0.80,
    "user_input": 0.70,
    "web_scrape": 0.50,
    "llm_generated": 0.60,
}

# === ROBOTICS SOURCES (NEW) ===
OMEGA_ROBOTICS = {
    # High confidence sensors
    "lidar_calibrated": 0.95,
    "encoder_absolute": 0.95,
    "motion_capture": 0.98,
    
    # Medium confidence
    "camera_rgb": 0.85,
    "imu_fused": 0.85,
    "depth_camera": 0.80,
    
    # Lower confidence
    "ultrasonic": 0.70,
    "tactile": 0.75,
    
    # Simulation
    "sim_validated": 0.85,
    "sim_only": 0.60,
    
    # Human/computed
    "human_demonstration": 0.70,
    "llm_reasoning": 0.60,
    "path_plan": 0.85,
}

# === QUANTUM SOURCES (NEW) ===
OMEGA_QUANTUM = {
    "pure_state_prep": 0.99,
    "noisy_gate_output": 0.92,
    "tomography_result": 0.85,
    "measurement_sample": 0.80,
    "vqa_optimized": 0.70,
    "error_mitigated": 0.75,
    "classical_shadow": 0.65,
    "classical_prediction": 0.50,
}
```

### Temperature (τ)

**Classic**: `τ = 1 / α_ω`

**Robotics**: `τ = (1 / α_ω) × urgency × safety`

**Quantum**: `τ = (1 / α_ω) × coherence × depth`

```python
# Temperature formulas by domain
τ_classic  = 1 / α_ω

τ_robotics = (1 / α_ω) × (1 + t_elapsed/t_deadline) × (1 + safety_risk)

τ_quantum  = (1 / α_ω) × (t_circuit/t_coherence) × exp(depth × error_rate)
```

### Credibility c(n; K)

**Unchanged from v1**:

```python
c(n; K) = n / (n + K)

# Where:
#   n = sample size / observation count
#   K = half-saturation constant (default 10)

# Effective omega with credibility:
ω_effective = ω × c(n; K)
```

---

## Backends

```python
from yrsn_tools import list_backends
print(list_backends())
# ['heuristic', 'tfidf', 'robust_pca', 'signal', 'quantum', 'robotics', 'quantum_full']
```

### Backend Comparison (v2)

| Backend | Best For | Dependencies | Collapses | Speed |
|---------|----------|--------------|-----------|-------|
| heuristic | General text | None | 4 | ⚡ Fast |
| tfidf | Query matching | sklearn | 4 | ⚡ Fast |
| robust_pca | Embeddings/matrices | numpy | 4 | Medium |
| signal | Time series | numpy | 4 | Medium |
| quantum | Quantum kernels | pennylane | 4 | Slow |
| **robotics** | Physical AI | numpy | **14** | Medium |
| **quantum_full** | Full quantum YRSN | pennylane | **19** | Slow |

### Classic Backends (Unchanged)

#### heuristic (Default)
```python
y = YRSN("The mitochondria is the powerhouse of the cell.")
# Rule-based decomposition, zero dependencies
```

#### tfidf
```python
y = YRSN(content, query="my query", backend="tfidf")
# TF-IDF cosine similarity for relevance
```

#### robust_pca
```python
y = YRSN(content, backend="robust_pca", embed_fn=my_embedder)
# Robust PCA: Low-rank (R) + Sparse (S) + Residual (N)
```

#### signal
```python
y = YRSN("", backend="signal", signal=time_series)
# Fast Iterative Filtering: Trend (R) + Mid-freq (S) + High-freq (N)
```

#### quantum
```python
y = YRSN(content, backend="quantum")
# Quantum kernel similarity (basic, no collapse detection)
```

---

## Robotics Backend (NEW)

### Purpose
Adds temporal (T) and physical (P) penalties plus 10 robotics-specific collapse types.

### Configuration

```python
from yrsn_tools import YRSN

y = YRSN(
    content=sensor_data,
    backend="robotics",
    omega=0.85,  # Sensor reliability
    domain_config={
        # Temporal constraints
        "deadline_ms": 100,
        "current_time_ms": 75,
        "data_age_ms": 20,
        
        # Physical context
        "sim_source": False,
        "real_validated": True,
        
        # Safety
        "safety_critical": True,
        "human_nearby": False,
        
        # Multi-agent
        "multi_agent": False,
    }
)
```

### Robotics Properties

```python
# Domain penalties
y.T                    # Temporal penalty (0-1)
y.P                    # Physical penalty (0-1)
y.D                    # Total domain penalty (T + P)

# Extended metrics
y.alpha_extended       # R / (R + S + N + T + P)
y.temperature_extended # τ × urgency × safety

# Safety
y.safety_margin        # Distance to safety threshold
y.is_safety_critical   # True if any safety collapse

# Collapses
y.collapses            # All detected collapses
y.critical_collapses   # Safety-critical only
```

### Robotics Collapses (10 new)

| Type | Domain | Trigger |
|------|--------|---------|
| TEMPORAL_MISALIGNMENT | Temporal | Stale sensor data |
| DEADLINE_VIOLATION | Temporal | Missed time constraint |
| ACCUMULATION_DRIFT | Temporal | Cumulative timing error |
| SIM_REAL_GAP | Physical | Sim≠Real mismatch |
| GROUNDING_FAILURE | Physical | Invalid physical reference |
| KINEMATIC_VIOLATION | Physical | Impossible motion |
| COORDINATION_BREAKDOWN | Multi-Agent | Agent desync |
| SHARED_CONTEXT_DIVERGENCE | Multi-Agent | State inconsistency |
| TRUST_EROSION | HRI | User trust degraded |
| INTENT_MISINTERPRETATION | HRI | Misread human intent |

### Robotics Routing

```python
decision = y.route()
decision.tier  # REAL_TIME | SAFETY_CHECK | HUMAN_REVIEW | EMERGENCY_STOP
```

| τ Range | Tier | Action |
|---------|------|--------|
| < 1.5 | REAL_TIME | Proceed immediately |
| 1.5-2.0 | SAFETY_CHECK | Verify then proceed |
| 2.0-3.0 | HUMAN_REVIEW | Request confirmation |
| ≥ 3.0 | EMERGENCY_STOP | Halt operation |
| Critical collapse | EMERGENCY_STOP | Immediate halt |

---

## Quantum Full Backend (NEW)

### Purpose
Adds quantum (Q) and hybrid (H) penalties plus 15 quantum-specific collapse types.

### Configuration

```python
from yrsn_tools import YRSN

y = YRSN(
    content=quantum_result,
    backend="quantum_full",
    omega=0.85,  # Measurement reliability
    domain_config={
        # Hardware specs
        "n_qubits": 8,
        "circuit_depth": 20,
        "t1_us": 100,
        "t2_us": 80,
        "gate_error": 0.001,
        "readout_error": 0.02,
        
        # Execution
        "shots": 1024,
        "circuit_time_us": 5,
        
        # Context
        "is_variational": True,
        "uses_error_mitigation": False,
    }
)
```

### Quantum Properties

```python
# Domain penalties
y.Q                    # Quantum penalty (decoherence + errors)
y.H                    # Hybrid penalty (interface overhead)
y.D                    # Total domain penalty (Q + H)

# Extended metrics
y.alpha_extended       # R / (R + S + N + Q + H)
y.temperature_extended # τ × coherence × depth

# Quantum-specific
y.fidelity             # Estimated state fidelity
y.purity               # Tr(ρ²)
y.coherence_ratio      # t_circuit / t_coherence

# Collapses
y.collapses            # All detected collapses
y.critical_collapses   # Circuit-abort collapses
```

### Quantum Collapses (15 new)

| Type | Domain | Trigger |
|------|--------|---------|
| T1_RELAXATION | Decoherence | Amplitude decay |
| T2_DEPHASING | Decoherence | Phase randomization |
| LEAKAGE | Decoherence | Non-computational states |
| BIT_FLIP | Gate Error | X error accumulation |
| PHASE_FLIP | Gate Error | Z error accumulation |
| DEPOLARIZING | Gate Error | Complete randomization |
| SHOT_NOISE | Measurement | Insufficient shots |
| READOUT_ERROR | Measurement | Misclassification |
| COLLAPSE_BIAS | Measurement | Systematic bias |
| ZZ_COUPLING | Crosstalk | Parasitic interaction |
| SPECTATOR_LEAKAGE | Crosstalk | Neighbor qubit affected |
| BARREN_PLATEAU | Trainability | Vanishing gradients |
| EXPRESSIBILITY_TRAINABILITY | Trainability | Tradeoff failure |
| INTERFACE_BOTTLENECK | Hybrid | Encoding information loss |
| DECODING_LATENCY | Hybrid | QEC too slow |

### Quantum Routing

```python
decision = y.route()
decision.tier  # QUANTUM_FULL | QUANTUM_MITIGATED | HYBRID_SPLIT | CLASSICAL_FALLBACK
```

| τ Range | Tier | Action |
|---------|------|--------|
| < 1.3 | QUANTUM_FULL | Pure quantum execution |
| 1.3-1.8 | QUANTUM_MITIGATED | Apply error mitigation |
| 1.8-2.5 | HYBRID_SPLIT | Partition quantum/classical |
| ≥ 2.5 | CLASSICAL_FALLBACK | Use classical approximation |
| Critical collapse | ABORT_CIRCUIT | Terminate circuit |

---

## All Collapse Types (v2)

### Classic (4)

| Type | Condition | Severity |
|------|-----------|----------|
| POISONING | N > 0.4 | Critical |
| DISTRACTION | S > 0.5 | Warning |
| CONFUSION | S + N > 0.6 | Critical |
| CLASH | σ(S) high | Warning |

### Robotics (10 + 4 OOD)

| Type | Domain | Severity |
|------|--------|----------|
| TEMPORAL_MISALIGNMENT | Temporal | Warning |
| DEADLINE_VIOLATION | Temporal | Critical |
| ACCUMULATION_DRIFT | Temporal | Warning |
| SIM_REAL_GAP | Physical | Critical |
| GROUNDING_FAILURE | Physical | Critical |
| KINEMATIC_VIOLATION | Physical | Critical |
| COORDINATION_BREAKDOWN | Multi-Agent | Critical |
| SHARED_CONTEXT_DIVERGENCE | Multi-Agent | Warning |
| TRUST_EROSION | HRI | Warning |
| INTENT_MISINTERPRETATION | HRI | Critical |
| **SENSOR_OOD** | OOD | Warning |
| **ENVIRONMENT_OOD** | OOD | Critical |
| **DYNAMICS_OOD** | OOD | Critical |
| **POLICY_OOD** | OOD | Warning |

### Quantum (15 + 4 OOD)

| Type | Domain | Severity |
|------|--------|----------|
| T1_RELAXATION | Decoherence | Warning |
| T2_DEPHASING | Decoherence | Warning |
| LEAKAGE | Decoherence | Critical |
| BIT_FLIP | Gate Error | Warning |
| PHASE_FLIP | Gate Error | Warning |
| DEPOLARIZING | Gate Error | Critical |
| SHOT_NOISE | Measurement | Warning |
| READOUT_ERROR | Measurement | Warning |
| COLLAPSE_BIAS | Measurement | Warning |
| ZZ_COUPLING | Crosstalk | Warning |
| SPECTATOR_LEAKAGE | Crosstalk | Warning |
| BARREN_PLATEAU | Trainability | Critical |
| EXPRESSIBILITY_TRAINABILITY | Trainability | Warning |
| INTERFACE_BOTTLENECK | Hybrid | Warning |
| DECODING_LATENCY | Hybrid | Critical |
| **NOISE_DRIFT** | OOD | Warning |
| **HAMILTONIAN_OOD** | OOD | Critical |
| **HARDWARE_DRIFT** | OOD | Warning |
| **ANSATZ_MISMATCH** | OOD | Critical |

---

## Metrics Reference (v2)

| Metric | Formula | Access | Domain |
|--------|---------|--------|--------|
| **O** | OOD detection | `.O` | All |
| **ω** | 1 - O | `.omega` | All |
| Y_Score | R + 0.5·S | `.y_score` | All |
| α | R / (R+S+N) | `.alpha` | All |
| α_ext | R / (R+S+N+D) | `.alpha_extended` | Extended |
| α_ω | ω·α + (1-ω)·prior | `.quality` | All |
| τ | 1 / α_ω | `.temperature` | All |
| τ_ext | τ × domain_factors | `.temperature_extended` | Extended |
| Risk | S + 1.5·N | `.collapse_risk` | All |
| c(n;K) | n / (n + K) | `.credibility` | All |
| T | Temporal penalty | `.T` | Robotics |
| P | Physical penalty | `.P` | Robotics |
| Q | Quantum penalty | `.Q` | Quantum |
| H | Hybrid penalty | `.H` | Quantum |
| D | Domain penalty | `.D` | Extended |

---

## YRSN Class Reference (v2)

### Constructor

```python
YRSN(
    content,              # Text/data to analyze
    query="",             # Optional relevance query
    context="",           # Optional grounding context
    omega=None,           # If None, derived from OOD detection (RECOMMENDED)
    n=None,               # Sample size for credibility
    K=10,                 # Half-saturation constant
    backend="heuristic",  # Decomposition backend
    domain_config=None,   # Domain-specific config
    ood_detector=None,    # Custom OOD detector (NEW)
    **backend_kwargs      # Backend-specific parameters
)
```

**OOD Detection Modes:**
```python
# Mode 1: Automatic OOD detection (recommended)
y = YRSN(content, backend="robotics")  # Uses built-in detector

# Mode 2: Custom OOD detector
y = YRSN(content, ood_detector=my_detector)

# Mode 3: Manual omega (backward compatible, O inferred as 1-omega)
y = YRSN(content, omega=0.85)
```

### Properties (Complete)

```python
y = YRSN(content, backend="robotics")

# === BACKEND ===
y.backend              # Backend name

# === DECOMPOSITION ===
y.R                    # Relevant (0-1)
y.S                    # Superfluous (0-1)
y.N                    # Noise (0-1)
y.T                    # Temporal penalty (robotics)
y.P                    # Physical penalty (robotics)
y.Q                    # Quantum penalty (quantum)
y.H                    # Hybrid penalty (quantum)
y.D                    # Total domain penalty

# === OOD (KEY COMPONENT) ===
y.O                    # OOD score (0=in-distribution, 1=OOD)
y.omega                # Reliability (derived: 1 - O)
y.is_ood               # True if O > 0.5
y.ood_severity         # "in_distribution", "slight_ood", "moderate_ood", "significant_ood", "severe_ood"

# === QUALITY ===
y.alpha                # R / (R + S + N)
y.alpha_extended       # R / (R + S + N + D)
y.quality              # α_ω (OOD-adjusted)
y.y_score              # R + 0.5·S

# === TEMPERATURE ===
y.temperature          # τ = 1/α_ω
y.temperature_extended # τ × domain_factors

# === RISK ===
y.collapse_risk        # S + 1.5·N
y.safety_margin        # (robotics) Safety distance
y.coherence_margin     # (quantum) Coherence distance

# === CREDIBILITY ===
y.credibility          # c(n;K) if n provided
y.effective_omega      # ω × c(n;K)

# === COLLAPSES ===
y.collapse             # Primary collapse
y.collapses            # All collapses
y.critical_collapses   # Critical only
y.is_collapsed         # bool
```

### Methods

```python
# Gating
y.gate(threshold=0.5)       # → bool (quality >= threshold)
y.gate_safe(threshold=0.7)  # → bool (also checks critical collapses)

# Routing
y.route()                   # → RoutingDecision
y.route_with_fallback()     # → (RoutingDecision, fallback)

# Explanation
y.explain()                 # Print summary
y.explain(verbose=True)     # Include formulas
y.explain_collapses()       # Collapse-focused

# Domain conversion
y.to_dict()                 # Full state as dict
y.to_json()                 # JSON string
```

---

## Custom Backends (v2)

```python
from yrsn_tools import register_backend, YRSNBackend

class MyDomainBackend:
    """Custom backend with domain penalties."""
    
    name = "my_domain"
    has_domain_penalties = True  # NEW: Enable D component
    
    def decompose(self, content, query="", context="", **kwargs):
        """Return (R, S, N) tuple."""
        R = self._compute_relevance(content, query)
        S = self._compute_superfluous(content)
        N = self._compute_noise(content)
        total = R + S + N
        return (R/total, S/total, N/total)
    
    def compute_domain_penalty(self, content, domain_config, **kwargs):
        """NEW: Return domain penalty D."""
        # Your domain-specific penalty logic
        return 0.1  # Example fixed penalty
    
    def detect_collapses(self, R, S, N, D, domain_config, **kwargs):
        """NEW: Return list of CollapseResult."""
        collapses = []
        # Your collapse detection logic
        return collapses

register_backend("my_domain", MyDomainBackend())
```

---

## Installation

```bash
# Core (classic backends)
pip install yrsn-tools

# With robotics extension
pip install yrsn-tools[robotics]

# With quantum extension
pip install yrsn-tools[quantum]

# Full installation
pip install yrsn-tools[all]
```

---

## Migration from v1

### Breaking Changes

1. `y.collapse` returns `CollapseResult` with additional fields
2. New properties: `.alpha_extended`, `.temperature_extended`, `.D`
3. Domain backends require `domain_config` for full functionality

### Compatibility Mode

```python
# v1 code continues to work
y = YRSN("content")
print(y.quality)  # Works exactly as before

# Extended features are opt-in via backend selection
y = YRSN("content", backend="robotics", domain_config={...})
```

---

## Backend Selection Guide (v2)

```
┌─────────────────────────────────────────────────────────────────┐
│                      What's your domain?                         │
└─────────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
   Classic AI            Robotics              Quantum
        │                     │                     │
        ▼                     ▼                     ▼
┌───────────────┐    ┌───────────────┐    ┌───────────────┐
│ What input?   │    │   robotics    │    │ quantum_full  │
└───────────────┘    │  (10 collapses│    │ (15 collapses)│
   │    │    │       │   T+P penalty)│    │  Q+H penalty) │
   ▼    ▼    ▼       └───────────────┘    └───────────────┘
 Text  Matrix Signal
   │    │    │
   ▼    ▼    ▼
┌────┐┌──────┐┌──────┐
│tfidf││robust││signal│
│    ││_pca  ││      │
└────┘└──────┘└──────┘
   │
   ▼
 Query?
   │
 No ──► heuristic
```

---

## References

- Bühlmann, H. (1967). "Experience Rating and Credibility"
- YRSN Robotics Collapse Taxonomy (2025)
- YRSN Quantum Collapse Taxonomy (2025)
- See `docs/theory/` for complete mathematical derivations
