# YRSN OOD Integration Across Domains
## Restoring the Out-of-Distribution Component

---

## The Missing Piece

In the original YRSN theory, **O (Out-of-Distribution)** was a meta-dimension that modified reliability:

```
Original Theory:
────────────────
Y = R + S + N           (decomposition)
ω = f(OOD_score)        (reliability from OOD detection)
α_ω = ω·α + (1-ω)·prior (OOD-adjusted quality)
τ = 1/α_ω               (temperature)
```

The ω wasn't arbitrary - it was **derived from OOD detection**. When we extended to robotics and quantum, we preserved ω as a parameter but lost the explicit OOD detection mechanism.

---

## Corrected Formula Structure

### Full YRSN v2 with OOD

```
Y = R + S + N + D                    (decomposition)
O = OOD_detect(context, domain)      (OOD score, 0-1)
ω = 1 - O                            (reliability = inverse of OOD)
α = R / (R + S + N + D)              (base quality)
α_ω = ω·α + (1-ω)·prior              (OOD-adjusted quality)
τ = (1/α_ω) × domain_factors         (temperature)
```

Where:
- **O** = OOD score (0 = in-distribution, 1 = completely OOD)
- **ω** = reliability (derived from O, not arbitrary)
- **D** = domain penalty (T+P for robotics, Q+H for quantum)

---

## Domain-Specific OOD Detection

### Classic OOD (Text/Embeddings)

```python
class ClassicOODDetector:
    """OOD detection for text and embedding contexts."""
    
    def __init__(self, reference_embeddings: np.ndarray):
        self.reference = reference_embeddings
        self.mean = reference_embeddings.mean(axis=0)
        self.cov_inv = np.linalg.pinv(np.cov(reference_embeddings.T))
        
    def detect(self, context_embedding: np.ndarray) -> float:
        """
        Compute OOD score using Mahalanobis distance.
        
        Returns:
            O: OOD score in [0, 1]
        """
        diff = context_embedding - self.mean
        mahal_dist = np.sqrt(diff @ self.cov_inv @ diff.T)
        
        # Normalize to [0, 1] using sigmoid
        O = 1 / (1 + np.exp(-mahal_dist / self.threshold + 3))
        return float(O)
    
    def get_omega(self, context_embedding: np.ndarray) -> float:
        """Derive ω from OOD score."""
        O = self.detect(context_embedding)
        omega = 1 - O
        return max(0.1, omega)  # Floor at 0.1 to avoid division issues
```

**Classic OOD Indicators:**
| Indicator | Detection Method | Threshold |
|-----------|------------------|-----------|
| Embedding distance | Mahalanobis | > 3σ |
| Vocabulary shift | OOV token ratio | > 20% |
| Topic drift | Cosine similarity | < 0.5 |
| Length anomaly | Z-score | > 3 |
| Perplexity spike | Language model | > 2× baseline |

---

### Robotics OOD

Robotics has **multiple OOD sources** that affect reliability:

```python
class RoboticsOODDetector:
    """OOD detection for robotics contexts."""
    
    def __init__(self, calibration_data: dict):
        self.sensor_ranges = calibration_data["sensor_ranges"]
        self.env_embeddings = calibration_data["environment_embeddings"]
        self.kinematic_bounds = calibration_data["kinematic_bounds"]
        
    def detect(self, context: dict) -> dict:
        """
        Detect multiple OOD sources.
        
        Returns:
            Dict with O_sensor, O_env, O_kinematic, O_combined
        """
        # Sensor OOD: readings outside calibration range
        O_sensor = self._sensor_ood(context.get("sensor_data", {}))
        
        # Environment OOD: novel environment not in training
        O_env = self._environment_ood(context.get("environment", {}))
        
        # Kinematic OOD: configurations outside training distribution
        O_kinematic = self._kinematic_ood(context.get("joint_state", {}))
        
        # Sim-Real OOD: gap between simulation and reality
        O_sim_real = self._sim_real_ood(context)
        
        # Combined (max preserves worst case)
        O_combined = max(O_sensor, O_env, O_kinematic, O_sim_real)
        
        return {
            "O_sensor": O_sensor,
            "O_env": O_env,
            "O_kinematic": O_kinematic,
            "O_sim_real": O_sim_real,
            "O": O_combined
        }
    
    def _sensor_ood(self, sensor_data: dict) -> float:
        """Check if sensor readings are within calibration range."""
        ood_scores = []
        for sensor, value in sensor_data.items():
            if sensor in self.sensor_ranges:
                min_val, max_val = self.sensor_ranges[sensor]
                if value < min_val or value > max_val:
                    # How far outside range
                    if value < min_val:
                        deviation = (min_val - value) / (max_val - min_val)
                    else:
                        deviation = (value - max_val) / (max_val - min_val)
                    ood_scores.append(min(1.0, deviation))
                else:
                    ood_scores.append(0.0)
        return max(ood_scores) if ood_scores else 0.0
    
    def _environment_ood(self, env_features: dict) -> float:
        """Check if environment is similar to training environments."""
        if not env_features:
            return 0.5  # Unknown = moderate OOD
        
        env_vec = self._embed_environment(env_features)
        distances = np.linalg.norm(self.env_embeddings - env_vec, axis=1)
        min_dist = distances.min()
        
        # Normalize
        return float(1 / (1 + np.exp(-min_dist + 2)))
    
    def _kinematic_ood(self, joint_state: dict) -> float:
        """Check if robot configuration is within training distribution."""
        if not joint_state:
            return 0.0
        
        joint_vec = np.array(list(joint_state.values()))
        
        # Check against bounds
        lower, upper = self.kinematic_bounds
        outside = np.logical_or(joint_vec < lower, joint_vec > upper)
        
        if outside.any():
            # Fraction of joints outside bounds
            return float(outside.sum() / len(joint_vec))
        return 0.0
    
    def _sim_real_ood(self, context: dict) -> float:
        """Detect sim-to-real distribution shift."""
        if not context.get("sim_source", False):
            return 0.0  # Real data, no sim-real gap
        
        if context.get("real_validated", False):
            return 0.1  # Validated, low OOD
        
        # Unvalidated sim data = high OOD
        return 0.6
    
    def get_omega(self, context: dict) -> float:
        """Derive ω from OOD detection."""
        ood_result = self.detect(context)
        O = ood_result["O"]
        omega = 1 - O
        return max(0.1, omega)
```

**Robotics OOD Types:**

| OOD Type | What It Detects | Impact on ω |
|----------|-----------------|-------------|
| O_sensor | Readings outside calibration | High (direct measurement) |
| O_env | Novel environment | High (policy may fail) |
| O_kinematic | Unseen configurations | Medium (interpolation possible) |
| O_sim_real | Sim-to-real gap | Very High (reality mismatch) |
| O_object | Unseen object classes | High (manipulation failure) |
| O_dynamics | Changed dynamics | Very High (control failure) |

**New Robotics Collapse: OOD_EXTRAPOLATION**

```python
class RoboticsCollapse(Enum):
    # ... existing collapses ...
    
    # NEW: OOD-specific collapses
    SENSOR_OOD = "sensor_ood"           # Sensor reading outside calibration
    ENVIRONMENT_OOD = "environment_ood" # Novel environment
    DYNAMICS_OOD = "dynamics_ood"       # Unexpected physical behavior
    POLICY_OOD = "policy_ood"           # State outside policy training distribution
```

---

### Quantum OOD

Quantum systems have unique OOD challenges:

```python
class QuantumOODDetector:
    """OOD detection for quantum contexts."""
    
    def __init__(self, calibration_data: dict):
        self.noise_profile = calibration_data["noise_profile"]
        self.hamiltonian_space = calibration_data["hamiltonian_embeddings"]
        self.ansatz_expressibility = calibration_data["expressibility_bounds"]
        
    def detect(self, context: dict) -> dict:
        """
        Detect quantum OOD sources.
        
        Returns:
            Dict with O_noise, O_hamiltonian, O_state, O_combined
        """
        # Noise OOD: noise profile differs from calibration
        O_noise = self._noise_ood(context.get("measured_noise", {}))
        
        # Hamiltonian OOD: problem Hamiltonian outside training distribution
        O_hamiltonian = self._hamiltonian_ood(context.get("hamiltonian", None))
        
        # State OOD: quantum state outside expressible space
        O_state = self._state_ood(context.get("target_state", None))
        
        # Hardware drift OOD: device parameters changed
        O_drift = self._hardware_drift_ood(context)
        
        # Combined
        O_combined = max(O_noise, O_hamiltonian, O_state, O_drift)
        
        return {
            "O_noise": O_noise,
            "O_hamiltonian": O_hamiltonian,
            "O_state": O_state,
            "O_drift": O_drift,
            "O": O_combined
        }
    
    def _noise_ood(self, measured_noise: dict) -> float:
        """Check if current noise differs from calibration."""
        if not measured_noise:
            return 0.3  # Unknown noise = moderate OOD
        
        # Compare noise parameters
        deviations = []
        for param, value in measured_noise.items():
            if param in self.noise_profile:
                expected = self.noise_profile[param]
                rel_dev = abs(value - expected) / (expected + 1e-10)
                deviations.append(rel_dev)
        
        if not deviations:
            return 0.3
        
        max_dev = max(deviations)
        return float(1 / (1 + np.exp(-max_dev * 5 + 2)))
    
    def _hamiltonian_ood(self, hamiltonian) -> float:
        """Check if Hamiltonian is within training distribution."""
        if hamiltonian is None:
            return 0.0
        
        h_embedding = self._embed_hamiltonian(hamiltonian)
        distances = np.linalg.norm(self.hamiltonian_space - h_embedding, axis=1)
        min_dist = distances.min()
        
        return float(1 / (1 + np.exp(-min_dist + 1)))
    
    def _state_ood(self, target_state) -> float:
        """Check if target state is expressible by ansatz."""
        if target_state is None:
            return 0.0
        
        # Check against expressibility bounds
        # High expressibility but OOD state = still OOD
        state_vec = np.array(target_state)
        
        # Project onto expressible subspace
        projection_error = self._compute_projection_error(state_vec)
        
        return float(min(1.0, projection_error))
    
    def _hardware_drift_ood(self, context: dict) -> float:
        """Detect if hardware has drifted from calibration."""
        calibration_age_hours = context.get("calibration_age_hours", 0)
        
        # Hardware drifts over time
        if calibration_age_hours > 24:
            return 0.5  # Significant drift likely
        elif calibration_age_hours > 4:
            return 0.2  # Some drift
        else:
            return 0.0  # Recent calibration
    
    def get_omega(self, context: dict) -> float:
        """Derive ω from OOD detection."""
        ood_result = self.detect(context)
        O = ood_result["O"]
        omega = 1 - O
        return max(0.1, omega)
```

**Quantum OOD Types:**

| OOD Type | What It Detects | Impact on ω |
|----------|-----------------|-------------|
| O_noise | Noise profile drift | High (error rates wrong) |
| O_hamiltonian | Novel problem structure | High (VQA may fail) |
| O_state | Inexpressible target | Very High (impossible task) |
| O_drift | Hardware parameter drift | Medium (recalibrate) |
| O_ansatz | Ansatz-problem mismatch | High (barren plateau risk) |

**New Quantum Collapse: OOD-Related**

```python
class QuantumCollapse(Enum):
    # ... existing 15 collapses ...
    
    # NEW: OOD-specific collapses
    NOISE_DRIFT = "noise_drift"           # Noise model outdated
    HAMILTONIAN_OOD = "hamiltonian_ood"   # Problem outside training
    HARDWARE_DRIFT = "hardware_drift"     # Device recalibration needed
    ANSATZ_MISMATCH = "ansatz_mismatch"   # Ansatz can't express solution
```

---

## Updated YRSN Class with OOD

```python
class YRSN:
    """YRSN v2 with proper OOD integration."""
    
    def __init__(
        self,
        content,
        query="",
        context="",
        omega=None,           # If None, derived from OOD detection
        n=None,
        K=10,
        backend="heuristic",
        domain_config=None,
        ood_detector=None,    # NEW: Custom OOD detector
        **backend_kwargs
    ):
        self.content = content
        self.query = query
        self.context = context
        self.backend = backend
        self.domain_config = domain_config or {}
        self.n = n
        self.K = K
        
        # Get backend instance
        self._backend = get_backend(backend)
        
        # Decompose: R, S, N (+ D for extended backends)
        self.R, self.S, self.N = self._backend.decompose(
            content, query, context, **backend_kwargs
        )
        
        # Domain penalty
        if hasattr(self._backend, 'compute_domain_penalty'):
            self.D = self._backend.compute_domain_penalty(
                content, self.domain_config, **backend_kwargs
            )
            # For robotics: D = T + P
            # For quantum: D = Q + H
        else:
            self.D = 0.0
        
        # === OOD DETECTION (the key addition) ===
        if ood_detector is not None:
            self._ood_detector = ood_detector
        elif hasattr(self._backend, 'get_ood_detector'):
            self._ood_detector = self._backend.get_ood_detector()
        else:
            self._ood_detector = None
        
        # Compute OOD score and derive omega
        if omega is not None:
            # User provided omega directly
            self._O = 1 - omega  # Infer O from omega
            self._omega = omega
        elif self._ood_detector is not None:
            # Derive omega from OOD detection
            ood_context = self._build_ood_context()
            ood_result = self._ood_detector.detect(ood_context)
            self._O = ood_result["O"] if isinstance(ood_result, dict) else ood_result
            self._omega = 1 - self._O
        else:
            # Default
            self._O = 0.0
            self._omega = 1.0
        
        # Ensure omega has a floor
        self._omega = max(0.1, self._omega)
        
        # Compute metrics
        self._compute_metrics()
        
        # Detect collapses
        self._collapses = self._detect_collapses()
    
    def _build_ood_context(self) -> dict:
        """Build context dict for OOD detection."""
        return {
            "content": self.content,
            "query": self.query,
            "context": self.context,
            **self.domain_config
        }
    
    def _compute_metrics(self):
        """Compute all YRSN metrics."""
        # Base alpha
        base_total = self.R + self.S + self.N
        self._alpha = self.R / (base_total + 1e-10)
        
        # Extended alpha (with domain penalty)
        ext_total = self.R + self.S + self.N + self.D
        self._alpha_extended = self.R / (ext_total + 1e-10)
        
        # Credibility (if n provided)
        if self.n is not None:
            self._credibility = self.n / (self.n + self.K)
            effective_omega = self._omega * self._credibility
        else:
            self._credibility = 1.0
            effective_omega = self._omega
        
        # OOD-adjusted quality: α_ω = ω·α + (1-ω)·prior
        prior = 0.5
        self._quality = effective_omega * self._alpha_extended + (1 - effective_omega) * prior
        
        # Temperature
        self._temperature = 1 / (self._quality + 1e-10)
        
        # Domain-adjusted temperature
        if hasattr(self._backend, 'compute_temperature_factors'):
            factors = self._backend.compute_temperature_factors(self.domain_config)
            self._temperature_extended = self._temperature * factors
        else:
            self._temperature_extended = self._temperature
        
        # Collapse risk
        self._collapse_risk = self.S + 1.5 * self.N
    
    # === PROPERTIES ===
    
    @property
    def O(self) -> float:
        """OOD score (0 = in-distribution, 1 = OOD)."""
        return self._O
    
    @property
    def omega(self) -> float:
        """Reliability score (derived from OOD)."""
        return self._omega
    
    @property
    def alpha(self) -> float:
        """Base quality: R / (R + S + N)."""
        return self._alpha
    
    @property
    def alpha_extended(self) -> float:
        """Extended quality: R / (R + S + N + D)."""
        return self._alpha_extended
    
    @property
    def quality(self) -> float:
        """OOD-adjusted quality: α_ω."""
        return self._quality
    
    @property
    def temperature(self) -> float:
        """Base temperature: 1/α_ω."""
        return self._temperature
    
    @property
    def temperature_extended(self) -> float:
        """Domain-adjusted temperature."""
        return self._temperature_extended
    
    @property
    def is_ood(self) -> bool:
        """True if context is significantly OOD."""
        return self._O > 0.5
    
    @property
    def ood_severity(self) -> str:
        """Human-readable OOD severity."""
        if self._O < 0.2:
            return "in_distribution"
        elif self._O < 0.4:
            return "slight_ood"
        elif self._O < 0.6:
            return "moderate_ood"
        elif self._O < 0.8:
            return "significant_ood"
        else:
            return "severe_ood"
```

---

## Updated Temperature Formula with OOD

The complete temperature formula with OOD:

```python
def compute_temperature(
    R, S, N, D,           # Decomposition components
    O,                    # OOD score
    domain_factors,       # Domain-specific multipliers
    n=None, K=10          # Credibility
):
    """
    Complete YRSN temperature calculation.
    
    τ = (1/α_ω) × domain_factors
    
    Where:
        ω = 1 - O                              (reliability from OOD)
        α = R / (R + S + N + D)                (extended quality)
        c = n / (n + K) if n else 1            (credibility)
        ω_eff = ω × c                          (effective reliability)
        α_ω = ω_eff × α + (1 - ω_eff) × prior  (OOD-adjusted quality)
        τ = 1 / α_ω                            (base temperature)
        τ_final = τ × domain_factors           (domain-adjusted)
    """
    # Reliability from OOD
    omega = 1 - O
    omega = max(0.1, omega)  # Floor
    
    # Extended alpha
    alpha = R / (R + S + N + D + 1e-10)
    
    # Credibility adjustment
    if n is not None:
        credibility = n / (n + K)
        omega_eff = omega * credibility
    else:
        omega_eff = omega
    
    # OOD-adjusted quality
    prior = 0.5
    alpha_omega = omega_eff * alpha + (1 - omega_eff) * prior
    
    # Base temperature
    tau = 1 / (alpha_omega + 1e-10)
    
    # Domain adjustment
    tau_final = tau * domain_factors
    
    return tau_final
```

---

## OOD Impact on Routing

OOD should trigger more conservative routing:

```python
def route_with_ood(
    tau: float,
    O: float,
    collapses: List,
    domain: str = "classic"
) -> RoutingDecision:
    """
    Route with OOD consideration.
    
    High OOD shifts routing toward more conservative tiers.
    """
    
    # OOD adjustment: high OOD increases effective tau
    ood_multiplier = 1 + O  # O=0 → 1x, O=1 → 2x
    tau_adjusted = tau * ood_multiplier
    
    # Check for OOD-specific collapses
    ood_collapses = [c for c in collapses if "OOD" in c.type.name]
    
    if domain == "robotics":
        if any(c.is_critical for c in ood_collapses):
            return RoutingTier.EMERGENCY_STOP
        elif tau_adjusted < 1.5:
            return RoutingTier.REAL_TIME
        elif tau_adjusted < 2.0:
            return RoutingTier.SAFETY_CHECK
        elif tau_adjusted < 3.0:
            return RoutingTier.HUMAN_REVIEW
        else:
            return RoutingTier.EMERGENCY_STOP
    
    elif domain == "quantum":
        if any(c.is_critical for c in ood_collapses):
            return RoutingTier.ABORT_CIRCUIT
        elif tau_adjusted < 1.3:
            return RoutingTier.QUANTUM_FULL
        elif tau_adjusted < 1.8:
            return RoutingTier.QUANTUM_MITIGATED
        elif tau_adjusted < 2.5:
            return RoutingTier.HYBRID_SPLIT
        else:
            return RoutingTier.CLASSICAL_FALLBACK
    
    else:  # Classic
        if tau_adjusted < 1.5:
            return RoutingTier.FAST
        elif tau_adjusted < 2.5:
            return RoutingTier.BALANCED
        else:
            return RoutingTier.QUALITY
```

---

## Summary: OOD Across Domains

| Domain | OOD Sources | Detection Method | Impact |
|--------|-------------|------------------|--------|
| **Classic** | Embedding distance, vocabulary shift, topic drift | Mahalanobis, cosine similarity | Reduces ω |
| **Robotics** | Sensor range, novel environment, sim-real gap, kinematics | Range checks, embedding distance, domain randomization | Reduces ω, triggers safety collapses |
| **Quantum** | Noise drift, Hamiltonian novelty, hardware drift, ansatz mismatch | Parameter deviation, expressibility check | Reduces ω, triggers recalibration |

**Key Additions:**
1. **O** is now an explicit output: `y.O`
2. **ω derived from O**: `ω = 1 - O`
3. **Domain-specific OOD detectors**: `ClassicOODDetector`, `RoboticsOODDetector`, `QuantumOODDetector`
4. **New OOD collapses**: Per domain
5. **OOD affects routing**: High O → conservative routing

---

## Migration

```python
# v1: omega as arbitrary parameter
y = YRSN(content, omega=0.85)

# v2: omega derived from OOD detection
y = YRSN(content, ood_detector=my_detector)
print(y.O)      # OOD score
print(y.omega)  # Derived: 1 - O
print(y.is_ood) # True if O > 0.5

# Or provide omega directly (for backward compatibility)
y = YRSN(content, omega=0.85)  # Still works
```

This restores OOD to its proper place as the foundation of the reliability score ω.
