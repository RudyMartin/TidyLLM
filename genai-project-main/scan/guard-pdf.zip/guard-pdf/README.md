# guard-pdf

A **pre-ingest Security Guard** for PDFs. It decides **BLOCK** or **ALLOW** before your analyzer runs,
based on *PII/secret detection*, *harmful content keywords*, and *dangerous PDF features* (e.g., `/JavaScript`, `/Launch`).

## Install (editable for local dev)
```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e .
```

## CLI
```bash
guard-pdf scan path/to/file.pdf --rules rules/guardrail_rules.yaml --json
echo $?   # 0 = ALLOW, 2 = BLOCK, 1 = error
```

## Programmatic use
```python
from guard_pdf import scan_file, decide
decision = scan_file("file.pdf", rules_path="rules/guardrail_rules.yaml")
print(decision)  # {"decision": "BLOCK|ALLOW", "reasons": [...], "snippets": [...], "rules_triggered": [...]}
```

## Exit codes
- 0: ALLOW
- 2: BLOCK
- 1: Error (I/O, parse, etc.)

## Add rules over time
Edit `rules/guardrail_rules.yaml` and bump `version`/`last_updated`. Add new regexes/keywords and tune `decision_policy`.
