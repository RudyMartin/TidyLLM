from guard_pdf.scanner import scan_text

def test_scan_text_detects_ssn():
    text = "John's SSN is 123-45-6789."
    rules = {"content_rules": []}
    res = scan_text(text, rules)
    assert any(h["rule"] == "SSN_US" for h in res["hits"])

def test_luhn_credit_card():
    text = "Use card 4242 4242 4242 4242 for tests."
    rules = {"content_rules": []}
    res = scan_text(text, rules)
    assert any(h["rule"] == "CREDIT_CARD_LUHN" for h in res["hits"])
