from guard_pdf.decision import decide

def test_block_on_highs():
    hits = [{"rule":"CREDIT_CARD_LUHN"},{"rule":"SSN_US"}]
    pdf_features = []
    rules_pack = {"decision_policy": {"block_on":[{"count":{"severity":"high","min":2}}]}}
    out = decide(hits, pdf_features, rules_pack)
    assert out["decision"] == "BLOCK"
