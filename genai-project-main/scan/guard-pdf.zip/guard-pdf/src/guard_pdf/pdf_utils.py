from typing import List
import pikepdf

BLOCK_KEYS = {"/JavaScript","/JS","/AA","/OpenAction","/Launch","/EmbeddedFile","/RichMedia","/SubmitForm"}

def pdf_has_block_features(path: str) -> List[str]:
    """
    Opens the PDF safely and scans object keys for dangerous features.
    Returns a list of matched feature names (as strings like '/JavaScript').
    """
    hits = set()
    with pikepdf.open(path, allow_overwriting_input=False) as pdf:
        # scan trailer, catalog, and pages
        def scan_obj(obj):
            try:
                if isinstance(obj, pikepdf.Dictionary):
                    for k, v in obj.items():
                        ks = str(k)
                        if ks in BLOCK_KEYS:
                            hits.add(ks)
                        scan_obj(v)
                elif isinstance(obj, pikepdf.Array):
                    for it in obj:
                        scan_obj(it)
            except Exception:
                # Best-effort scan; ignore unreadable objects
                pass

        # trailer + catalog
        scan_obj(pdf.trailer)
        # pages
        for page in pdf.pages:
            try:
                scan_obj(page.obj)
            except Exception:
                pass

    return sorted(hits)
