import re
from typing import Dict, List, Any
from .rules import load_rules
from .pdf_utils import pdf_has_block_features
from pdfminer.high_level import extract_text

def luhn_ok(s: str) -> bool:
    ds = [int(c) for c in re.sub(r"\D", "", s)]
    if not (13 <= len(ds) <= 19): return False
    checksum = 0
    parity = len(ds) % 2
    for i, d in enumerate(ds):
        if i % 2 == parity:
            d = d * 2
            if d > 9: d -= 9
        checksum += d
    return checksum % 10 == 0

def aba_checksum_ok(s: str) -> bool:
    if not re.fullmatch(r"\d{9}", s): return False
    w = [3,7,1,3,7,1,3,7,1]
    return sum(int(d)*w[i] for i,d in enumerate(s)) % 10 == 0

BUILTIN_REGEX = {
    "SSN_US": re.compile(r"\b(?!000|666|9\d{2})\d{3}[- ]?(?!00)\d{2}[- ]?(?!0000)\d{4}\b"),
    "JWT_TOKEN": re.compile(r"\beyJ[\w-]*\.[\w-]*\.[\w-]*\b"),
    "AWS_ACCESS_KEY_ID": re.compile(r"\b(AKIA|ASIA|AGPA|AIDA)[0-9A-Z]{16}\b"),
    "GOOGLE_API_KEY": re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"),
    "GITHUB_TOKEN": re.compile(r"\bgh[pous]_[0-9A-Za-z]{36,}\b"),
    "PRIVATE_KEY_BLOCK": re.compile(r"-----BEGIN (RSA|DSA|EC|OPENSSH|PGP) PRIVATE KEY-----"),
    "PASSWORD_ASSIGNMENT": re.compile(r"(?i)password\s*[:=]\s*['\"]?.{4,}"),
    "AUTH_URI": re.compile(r"(?i)(mongodb(\+srv)?:\/\/|postgres(ql)?:\/\/|mysql:\/\/).+@"),
    "IBAN_GENERIC": re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b"),
}

SEVERITY = {
    "PRIVATE_KEY_BLOCK": "critical",
    "GITHUB_TOKEN": "critical",
    "GOOGLE_API_KEY": "critical",
    "AWS_ACCESS_KEY_ID": "critical",
    "CREDIT_CARD_LUHN": "high",
    "ABA_ROUTING": "high",
    "SSN_US": "high",
    "JWT_TOKEN": "high",
    "PASSWORD_ASSIGNMENT": "high",
    "AUTH_URI": "high",
    "IBAN_GENERIC": "high",
}

def redact(value: str) -> str:
    if len(value) <= 4: return "****"
    return "*" * (len(value)-4) + value[-4:]

def scan_text(text: str, rules: Dict[str, Any]) -> Dict[str, Any]:
    hits: List[Dict[str, str]] = []

    # Built-ins
    for rid, rx in BUILTIN_REGEX.items():
        for m in rx.finditer(text):
            hits.append({"rule": rid, "value": m.group(0)})

    # Luhn credit card
    for m in re.finditer(r"(?:\d[ -]?){13,19}", text):
        cand = re.sub(r"[^\d]", "", m.group(0))
        if luhn_ok(cand):
            hits.append({"rule": "CREDIT_CARD_LUHN", "value": cand})

    # ABA routing
    for m in re.finditer(r"\b\d{9}\b", text):
        num = m.group(0)
        if aba_checksum_ok(num):
            hits.append({"rule": "ABA_ROUTING", "value": num})

    # YAML-driven rules
    for rule in (rules.get("content_rules") or []):
        if rule.get("type") == "keyword_window":
            for kw in rule.get("keywords", []):
                if kw.lower() in text.lower():
                    hits.append({"rule": rule["id"], "value": kw})

        if rule.get("type") == "regex":
            rx = re.compile(rule["pattern"])
            for m in rx.finditer(text):
                hits.append({"rule": rule["id"], "value": m.group(0)})

    # Redact for output
    redacted = [{"rule": h["rule"], "value": redact(h["value"])} for h in hits]
    return {"hits": hits, "redacted": redacted}

def text_from_pdf(path: str) -> str:
    # Safe text-only extraction; does not execute scripts.
    return extract_text(path) or ""

def scan_file(path: str, rules_path: str) -> Dict[str, Any]:
    from .decision import decide
    from .rules import load_rules
    rp = load_rules(rules_path)
    pdf_feats = pdf_has_block_features(path)
    text = text_from_pdf(path)
    scanned = scan_text(text, rp.data)
    result = decide(scanned["hits"], pdf_feats, rp.data)
    result["snippets"] = scanned["redacted"]
    return result
