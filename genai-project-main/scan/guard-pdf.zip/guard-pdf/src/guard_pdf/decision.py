from typing import List, Dict, Any

DEFAULT_POLICY = {
    "decision_policy": {
        "block_on": [
            {"any": ["critical"]},
            {"count": {"severity": "high", "min": 2}},
            {"pdf_feature_blocklist_hit": True}
        ]
    }
}

def decide(hits: List[Dict[str,str]], pdf_features: List[str], rules_pack: Dict[str, Any]) -> Dict[str, Any]:
    policy = (rules_pack or {}).get("decision_policy") or DEFAULT_POLICY["decision_policy"]
    # severity map (could be extended from YAML, but kept here for simplicity)
    severity_map = {
        "critical": {"PRIVATE_KEY_BLOCK","GITHUB_TOKEN","GOOGLE_API_KEY","AWS_ACCESS_KEY_ID"},
        "high": {"CREDIT_CARD_LUHN","ABA_ROUTING","SSN_US","JWT_TOKEN","PASSWORD_ASSIGNMENT","AUTH_URI","IBAN_GENERIC"},
    }
    counts = {"critical": 0, "high": 0, "medium": 0}
    for h in hits:
        r = h.get("rule")
        sev = "medium"
        if r in severity_map["critical"]:
            sev = "critical"
        elif r in severity_map["high"]:
            sev = "high"
        counts[sev] += 1

    decision = "ALLOW"
    reasons: List[str] = []
    if pdf_features:
        decision = "BLOCK"
        reasons.append(f"PDF features blocked: {pdf_features}")

    for rule in policy.get("block_on", []):
        if "any" in rule:
            for sev in rule["any"]:
                if counts.get(sev, 0) > 0:
                    decision = "BLOCK"
                    reasons.append(f"Detected {sev} severity indicators")
        if "count" in rule:
            cfg = rule["count"]
            sev = cfg.get("severity", "high")
            minc = int(cfg.get("min", 1))
            if counts.get(sev, 0) >= minc:
                decision = "BLOCK"
                reasons.append(f"{counts.get(sev,0)} {sev} findings (threshold {minc})")
        if rule.get("pdf_feature_blocklist_hit", False) and pdf_features:
            decision = "BLOCK"

    return {
        "decision": decision,
        "reasons": reasons,
        "rules_triggered": sorted({h.get("rule") for h in hits})
    }
