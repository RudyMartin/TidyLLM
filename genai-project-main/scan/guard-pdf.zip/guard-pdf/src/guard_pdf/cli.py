import json
import sys
import click
from .scanner import scan_file

@click.group()
def cli():
    pass

@cli.command(help="Scan a PDF and decide BLOCK or ALLOW.")
@click.argument("path", type=click.Path(exists=True, dir_okay=False, path_type=str))
@click.option("--rules", "rules_path", type=click.Path(exists=True, dir_okay=False, path_type=str), required=True, help="Path to guardrail_rules.yaml")
@click.option("--json", "as_json", is_flag=True, help="Emit JSON")
def scan(path, rules_path, as_json):
    try:
        result = scan_file(path, rules_path=rules_path)
        if as_json:
            click.echo(json.dumps(result, ensure_ascii=False))
        else:
            click.echo(f"Decision: {result['decision']}")
            for r in result.get("reasons", []):
                click.echo(f" - {r}")
        sys.exit(0 if result["decision"] == "ALLOW" else 2)
    except Exception as e:
        if as_json:
            click.echo(json.dumps({"error": str(e)}), err=True)
        else:
            click.echo(f"ERROR: {e}", err=True)
        sys.exit(1)

def main():
    cli()

if __name__ == "__main__":
    main()
