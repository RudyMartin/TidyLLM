from .scanner import scan_text, scan_file
from .decision import decide
