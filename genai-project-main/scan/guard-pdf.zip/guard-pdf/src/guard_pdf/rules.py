import yaml
from dataclasses import dataclass
from typing import Any, Dict

@dataclass
class Rulepack:
    version: str
    last_updated: str
    data: Dict[str, Any]

def load_rules(path: str) -> Rulepack:
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    return Rulepack(
        version=str(data.get("version", "0")),
        last_updated=str(data.get("last_updated", "")),
        data=data
    )
