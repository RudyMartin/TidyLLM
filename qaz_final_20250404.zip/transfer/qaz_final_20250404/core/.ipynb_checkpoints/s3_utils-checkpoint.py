"""
[File: core/s3_utils.py]
Utility functions for interacting with AWS S3.
"""

import boto3
import logging
import json
import faiss
from typing import List
from core.logging_helper import get_logger

logger = get_logger("s3_utils")
logger.setLevel(logging.DEBUG)

from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

##  important: this IS referenced later
def get_s3_client():
    """
    Returns the S3 client from the client bundle.
    """
    return s3_client

# ---------- A ----------
def list_objects_s3(bucket: str, prefix: str, extension: str = None) -> list:
    try:
        s3 = get_s3_client()  # Use the shared S3 client.
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        if extension:
            keys = [key for key in keys if key.endswith(extension)]
        return keys
    except Exception as e:
        logger.error(f"❌ Error listing objects in bucket {bucket} with prefix {prefix}: {e}")
        return []

# ---------- C ----------
def list_pdf_files_s3(bucket: str, prefix: str = "") -> List[str]:
    return list_objects_s3(bucket, prefix, extension=".pdf")

# ---------- D ----------
def list_json_files_s3(bucket: str, prefix: str = "") -> List[str]:
    return list_objects_s3(bucket, prefix, extension=".json")

def list_s3_files_with_extension(bucket: str, prefix: str, extension: str = ".pdf") -> list:
    # If you reference streamlit's error function, be sure to import streamlit as st
    import streamlit as st
    s3 = get_client_bundle().s3
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix)
        return [obj["Key"] for obj in response.get("Contents", []) if obj["Key"].endswith(extension)]
    except Exception as e:
        st.error(f"❌ Failed to list files: {e}")
        return []

# ---------- B ----------
def list_folders_s3(bucket: str, prefix: str = "") -> List[str]:
    s3 = get_s3_client()
    try:
        response = s3.list_objects_v2(Bucket=bucket, Prefix=prefix, Delimiter="/")
        return [cp["Prefix"] for cp in response.get("CommonPrefixes", [])]
    except Exception as e:
        logger.error(f"❌ Error listing folders under {prefix}: {e}")
        return []

# ---------- E ----------
def check_s3_object_tag(bucket: str, key: str, tag_key: str) -> bool:
    s3 = get_s3_client()
    try:
        response = s3.get_object_tagging(Bucket=bucket, Key=key)
        tags = {tag["Key"]: tag["Value"] for tag in response.get("TagSet", [])}
        return tag_key in tags
    except s3.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "AccessDenied":
            logger.warning(f"⚠️ Access denied checking tags for {key}")
        else:
            logger.error(f"❌ Error checking tags for {key}: {e}")
        return False

# ---------- F ----------
def load_json_from_s3(bucket: str, key: str) -> dict:
    s3 = get_s3_client()
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(response["Body"].read().decode("utf-8"))
    except Exception as e:
        logger.error(f"❌ Failed to load JSON from s3://{bucket}/{key}: {e}")
        return {}

# ---------- G ----------
def save_json_to_s3(bucket: str, key: str, data: dict):
    s3 = get_s3_client()
    try:
        s3.put_object(
            Bucket=bucket,
            Key=key,
            Body=json.dumps(data, indent=2).encode("utf-8"),
            ContentType="application/json"
        )
        logger.info(f"✅ Saved JSON to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to save JSON to s3://{bucket}/{key}: {e}")

# ---------- H ----------
def save_metadata_to_s3(bucket: str, key: str, metadata, model_key: str, metadata_path: str = "meta", filename: str = None, overwrite: bool = True):
    s3 = get_s3_client()
    try:
        filename = filename or f"{model_key}_metadata.json"
        full_metadata_path = f"{key}/{model_key}/{metadata_path}/{filename}".strip("/")

        if not overwrite:
            try:
                s3.head_object(Bucket=bucket, Key=full_metadata_path)
                logger.warning(f"⚠️ Metadata already exists at s3://{bucket}/{full_metadata_path}. Skipping.")
                return
            except s3.exceptions.ClientError as e:
                if e.response['Error']['Code'] != "404":
                    raise

        s3.put_object(
            Bucket=bucket,
            Key=full_metadata_path,
            Body=json.dumps(metadata, indent=2),
            ContentType="application/json"
        )
        logger.info(f"✅ Metadata saved to s3://{bucket}/{full_metadata_path}")
    except Exception as e:
        logger.error(f"❌ Failed to save metadata for {model_key}: {e}")
        raise

def load_metadata_from_s3(bucket: str, key: str) -> dict:
    s3 = get_s3_client()
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        return json.loads(response["Body"].read().decode("utf-8"))
    except Exception as e:
        logger.error(f"❌ Failed to load metadata from s3://{bucket}/{key}: {e}")
        return {}

# ---------- I ----------
def save_faiss_index_to_s3(bucket, prefix, index, model_key):
    s3 = get_s3_client()
    config = initialize_config()
    try:
        model_info = config["model_options"][model_key]
        model_id = model_info["id"]
        dim = model_info["dimensions"]

        index_name = f"faiss_index_{model_id.replace(':', '_')}_{dim}.faiss"
        model_folder = f"{model_key}/{dim}"
        s3_key = f"{prefix}/{model_folder}/{index_name}".strip("/")

        index_bytes = faiss.serialize_index(index)
        s3.put_object(
            Bucket=bucket,
            Key=s3_key,
            Body=index_bytes,
            ContentType="application/octet-stream"
        )
        logger.info(f"✅ FAISS index saved to s3://{bucket}/{s3_key}")
    except Exception as e:
        logger.error(f"❌ Failed to save FAISS index: {e}")
        raise

# ---------- J ----------
def upload_file_to_s3(bucket: str, key: str, data, content_type: str = "application/octet-stream"):
    s3 = get_s3_client()
    try:
        s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
        logger.info(f"✅ Uploaded file to s3://{bucket}/{key}")
    except Exception as e:
        logger.error(f"❌ Failed to upload file to s3://{bucket}/{key}: {e}")

# ---------- K ----------
def delete_s3_object(bucket: str, key: str) -> bool:
    """Deletes a single object from the specified S3 bucket and key."""
    s3 = get_s3_client()
    try:
        s3.delete_object(Bucket=bucket, Key=key)
        logger.info(f"✅ Deleted s3://{bucket}/{key}")
        return True
    except s3.exceptions.ClientError as e:
        if e.response["Error"]["Code"] == "NoSuchKey":
            logger.warning(f"⚠️ Object not found: s3://{bucket}/{key}")
            return False
        else:
            logger.error(f"❌ Failed to delete s3://{bucket}/{key}: {e}")
            return False
    except Exception as e:
        logger.error(f"❌ Unexpected error deleting s3://{bucket}/{key}: {e}")
        return False

