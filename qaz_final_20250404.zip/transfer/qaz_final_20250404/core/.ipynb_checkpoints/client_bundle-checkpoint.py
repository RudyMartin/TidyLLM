# core/client_bundle.py


class ClientBundle:
    def __init__(self, config=None):
        self.config = config or initialize_config()
        self.s3, self.bedrock = get_clients(self.config)

def get_client_bundle():
    return ClientBundle()