"""
[File: config_tab.py]
Description: Provides UI for viewing and editing configuration settings.
"""

import streamlit as st
import json

from core.config_manager import get_config, reload_config
from core.config_editor import save_config, log_config_change, restore_defaults

from core.client_bundle import get_client_bundle

clients = get_client_bundle()
s3_client = clients.s3
config = clients.config

def render():
    config = initialize_config()
    editable = st.session_state.get('editable', False)

    st.header("\u2699\ufe0f Configuration Settings")

    st.markdown("### 🧪 Debug: S3 Raw Listing Test")

    try:
        bucket = config["bucket_name"]
        prefix = "dev/pdf/arxiv_wellsfargo/"  # Replace if needed
    
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
        keys = [obj["Key"] for obj in response.get("Contents", [])]
        
        if not keys:
            st.warning("⚠️ No keys found under this prefix.")
        else:
            st.success(f"✅ Found {len(keys)} objects.")
            st.write(keys[:10])  # Limit to first 10 results
    
    except Exception as e:
        st.error(f"❌ Failed to list objects: {e}")

    if not editable:
        st.markdown("**Configuration (View Mode)**")
        for key, value in config.items():
            st.write(f"**{key}**: {value}")

        col1, col2 = st.columns(2)
        with col1:
            # if st.button("🏠", help="Return to Main View"):
            #     st.session_state["admin_tool"] = "None"
            #     st.experimental_rerun()
            #     st.write("### Configuration Panel")
            if st.button("\u270F\ufe0f Edit Config"):
                st.session_state['editable'] = True
                st.rerun()

        with col2:
            if st.button("\U0001F504 Restore Defaults"):
                default_config = initialize_config()
                if default_config:
                    save_config(default_config, CONFIG_PATH)
                    log_config_change("Restored Defaults", default_config)
                    reinitialize_config()
                    st.success("Defaults restored.")
                    st.rerun()

    else:
        st.markdown("**Configuration (Edit Mode)**")
        new_config = {}
        for key, value in config.items():
            if isinstance(value, int):
                new_config[key] = st.number_input(key, value=value)
            elif isinstance(value, float):
                new_config[key] = st.number_input(key, value=value)
            elif isinstance(value, str):
                new_config[key] = st.text_input(key, value=value)
            elif isinstance(value, dict):
                st.markdown(f"**{key} (JSON format)**")
                json_text = st.text_area(f"{key} JSON", value=json.dumps(value, indent=2), height=200)
                try:
                    parsed = json.loads(json_text)
                    new_config[key] = parsed
                except Exception:
                    st.warning(f"Invalid JSON for {key}. Keeping original.")
                    new_config[key] = value

        col1, col2 = st.columns(2)
        with col1:
            if st.button("\U0001F4C2 Save / Reload"):
                save_config(new_config, CONFIG_PATH)
                log_config_change("Saved", new_config)
                reinitialize_config()
                st.success("Configuration saved.")
                st.session_state['editable'] = False
                st.rerun()

        with col2:
            if st.button("\u274C Cancel Edit"):
                st.session_state['editable'] = False
                st.rerun()


if __name__ == "__main__":
    render()
