"""
MCP Workers Package

Task-specific execution and processing components.
"""

__version__ = "1.0.0"
