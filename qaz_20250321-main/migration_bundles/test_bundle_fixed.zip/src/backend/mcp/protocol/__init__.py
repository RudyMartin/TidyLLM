"""
MCP Protocol Package

Communication protocols, message schemas, and contracts for MCP layer communication.
"""

from .message_schemas import MCPMessageSchema
from .communication import MCPProtocol
from .contracts import LayerContract

__version__ = "1.0.0"
__all__ = ["MCPMessageSchema", "MCPProtocol", "LayerContract"]
