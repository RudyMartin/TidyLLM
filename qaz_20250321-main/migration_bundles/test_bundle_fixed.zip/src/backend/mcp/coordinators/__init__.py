"""
MCP Coordinators Package

Mid-level coordination and tactical execution components.
"""

__version__ = "1.0.0"
