"""
MCP Aggregation Package

Result aggregation and transformation for MCP layers.
"""

from .result_aggregator import MCPResultAggregator
from .result_transformer import MCPResultTransformer
from .result_validator import MCPResultValidator
from .quality_checker import QualityChecker

__version__ = "1.0.0"
__all__ = ["MCPResultAggregator", "MCPResultTransformer", "MCPResultValidator", "QualityChecker"]
