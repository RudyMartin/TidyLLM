# Credentials package for VectorQA Sage
