"""
Custom Exceptions Package

Custom exception classes and error handling components.
"""

__version__ = "1.0.0"
