"""
API Package

API endpoints and HTTP interface components.
"""

__version__ = "1.0.0"
