"""
API Middleware Package

API middleware components for authentication, logging, CORS, and error handling.
"""

__version__ = "1.0.0"
