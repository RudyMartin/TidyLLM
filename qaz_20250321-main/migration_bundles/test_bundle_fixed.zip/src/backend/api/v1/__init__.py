"""
API v1 Package

API version 1 endpoints and models.
"""

__version__ = "1.0.0"
