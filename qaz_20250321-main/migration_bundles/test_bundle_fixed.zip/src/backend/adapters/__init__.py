"""
External Adapters Package

External service integrations and adapters for AWS, DSPy, and other services.
"""

__version__ = "1.0.0"
